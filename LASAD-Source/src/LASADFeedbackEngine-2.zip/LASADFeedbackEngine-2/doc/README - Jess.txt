The AF Engine makes use of the Java Expert System Shell (Jess). Jess itself is not 
included in the LASAD AF-Engine distrubution since Jess is not available for Open 
Source licensing under any GPL license. To license and download Jess, please visit 
the Jess website at: www.jessrules.com 


How to setup Jess in Eclipse
---
(see also http://www.jessrules.com/doc/71/eclipse.html)


1.  When using the JessDE, you don't have to put a copy of jess.jar
    anywhere. 
2. To install the JessDE, simply exit Eclipse, unzip all the 
    files from Jess71p2/eclipse into the top-level Eclipse installation directory. 
3. Confirm that a directory named "plugins/gov.sandia.jess_7.1.0" exists under 
    your Eclipse installation directory, and then restart Eclipse.
4. Under the "Help" menu, choose "about Eclipse SDK". There will be a button with 
   the Jess logo on it on the main "About Eclipse SDK" window. Press "Plug-in Details". 
   If the JessDE is installed properly, you'll find three or four Jess-related plugins 
   in the list -- in my copy of Eclipse, they appear near the bottom.