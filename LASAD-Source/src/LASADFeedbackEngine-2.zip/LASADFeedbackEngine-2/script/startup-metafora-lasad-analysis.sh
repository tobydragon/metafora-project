#!/bin/sh

# NOTE: All libs should be directly contained in $AF_HOME/lib (and not in sub-directories)  

export AF_HOME=/home/ilo/lasad_af
export CONF_HOME=${AF_HOME}/conf/default
export JAVA_HOME=/home/ilo/lasad_af/jdk1.6.0_20
export JRE_HOME=${JAVA_HOME}/jre

PATH=${JRE_HOME}/bin:${PATH}


cd $AF_HOME

#--------------------------------
# Add standard libs to classpath 
#--------------------------------
THE_CLASSPATH=
for i in `ls -R $AF_HOME/lib | grep -E .+.jar`
do
  THE_CLASSPATH=${THE_CLASSPATH}:$AF_HOME/lib/${i}
done

# Echo used variables

echo JAVA_HOME: ${JAVA_HOME}
echo JRE_HOME: ${JRE_HOME}
echo CLASSPATH: ${THE_CLASSPATH}
echo `java -version`


# start

java -cp "lasad_af.jar:$THE_CLASSPATH" -Dlasad.af.conf=$CONF_HOME de.dfki.lasad.core.AFMain &