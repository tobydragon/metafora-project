package de.dfki.lasad.session.data.objects;

import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.objects.ActionHistory.ActionType;

/**
 * 
 * @author Oliver Scheuer
 *
 */
public class HistoryAwareEUEObject {

	private EUEObjectID eueObjectID;
	private EUEObject eueObject;
	private ActionHistory actionHistory = new ActionHistory();
	
	public HistoryAwareEUEObject(EUEObject eueObject) {
		this.eueObject = eueObject;
		this.eueObjectID = eueObject.getID();
	}
	
	public EUEObject getObject(){
		return eueObject;
	}
	
	public ActionHistory getActionHistory(){
		return actionHistory;
	}
	
	public void createAndAddActionToHistory(long ts, ActionType actionType, UserID userID){
		actionHistory.addAction(ts, actionType, userID);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((eueObjectID == null) ? 0 : eueObjectID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HistoryAwareEUEObject other = (HistoryAwareEUEObject) obj;
		if (eueObjectID == null) {
			if (other.eueObjectID != null)
				return false;
		} else if (!eueObjectID.equals(other.eueObjectID))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return eueObject.toString() + ", object history = " + actionHistory;
	}

	
	
}
