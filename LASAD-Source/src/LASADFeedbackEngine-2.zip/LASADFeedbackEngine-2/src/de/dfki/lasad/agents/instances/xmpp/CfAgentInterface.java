package de.dfki.lasad.agents.instances.xmpp;

import de.dfki.lasad.session.data.SessionID;
import de.uds.cfcommunication.CfCommunicationListener;
import de.uds.commonformat.CfAction;

public interface CfAgentInterface extends CfCommunicationListener {
	
	public SessionID getSessionID();

}
