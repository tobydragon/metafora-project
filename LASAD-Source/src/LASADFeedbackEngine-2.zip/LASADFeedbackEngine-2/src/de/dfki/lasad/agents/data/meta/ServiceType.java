package de.dfki.lasad.agents.data.meta;

import java.util.Locale;

/**
 * Specification of an {@IAgent}'s service that can, in principle, be
 * offered in the end-user environment (e.g., analyzing the workspace content,
 * providing a hint or feedback).
 * 
 * @author oliverscheuer
 * 
 */
public class ServiceType {

	protected String agentID;
	protected String typeID;
	private String description = null;

	protected boolean doPublishToEndUser = false;
	protected Locale locale = Locale.ENGLISH;
	protected String localizedName = null;

	public ServiceType(String agentID, String typeID) {
		this.agentID = agentID;
		this.typeID = typeID;
	}

	/**
	 * 
	 * @return ID of the agent who can offer the service.
	 */
	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	/**
	 * 
	 * @return type of the service.
	 */
	public String getTypeID() {
		return typeID;
	}

	public void setTypeID(String typeID) {
		this.typeID = typeID;
	}

	public void setDisplayName(String name) {
		localizedName = name;
	}

	/**
	 * 
	 * @return string to be displayed in the user interface to represent the
	 *         offered service.
	 */
	public String getDisplayName() {
		if (localizedName == null) {
			return "[" + agentID + " - " + typeID + "]";
		}
		return localizedName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * 
	 * @return whether service should be offered in the user interface.
	 */
	public boolean doPublishToEndUser() {
		return doPublishToEndUser;
	}

	public void setDoPublishToEndUser(boolean doPublishToEndUser) {
		this.doPublishToEndUser = doPublishToEndUser;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agentID == null) ? 0 : agentID.hashCode());
		result = prime * result + getClass().getCanonicalName().hashCode();
		result = prime * result + ((typeID == null) ? 0 : typeID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceType other = (ServiceType) obj;
		if (agentID == null) {
			if (other.agentID != null)
				return false;
		} else if (!agentID.equals(other.agentID))
			return false;
		if (getClass().getCanonicalName() == null) {
			if (other.getClass().getCanonicalName() != null)
				return false;
		} else if (!getClass().getCanonicalName().equals(
				other.getClass().getCanonicalName()))
			return false;
		if (typeID == null) {
			if (other.typeID != null)
				return false;
		} else if (!typeID.equals(other.typeID))
			return false;
		return true;
	}

}
