package de.dfki.lasad.sessionmodel.jessfunctions;


import jess.Context;
import jess.Funcall;
import jess.JessException;
import jess.Userfunction;
import jess.Value;
import jess.ValueVector;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class CompareScalar2List implements Userfunction {

	/** Create a new CompareScalar2Set userfunction object */
	public CompareScalar2List() {
		super();
	}

	/**
	 * Get the name of the compare-s2l user function
	 * 
	 * @see jess.Userfunction#getName()
	 */
	public String getName() {
		return "compare-s2l";
	}

	/**
	 * 
	 * Call the compare-s2l user function
	 * 
	 * @see jess.Userfunction#call(jess.ValueVector, jess.Context)
	 */
	public Value call(ValueVector vv, final Context context)
			throws JessException {
		if (vv.size() != 5) {
			throw new JessException(getName(), getName()
					+ " takes exactly four arguments:"
					+ "scalar, operator, list selector, list", vv.size() - 1);
		}

		Value scalarAsValue = vv.get(1).resolveValue(context);

		Value operatorAsValue = vv.get(2).resolveValue(context);
		String operator = operatorAsValue.stringValue(context);

		Value listSelectorAsValue = vv.get(3).resolveValue(context);
		String listselector = listSelectorAsValue.stringValue(context);

		Value listAsValue = vv.get(4).resolveValue(context);
		ValueVector list = listAsValue.listValue(context);

		boolean result;
		if ("EXISTS".equalsIgnoreCase(listselector)) {
			result = compareExists(scalarAsValue, operator, list, context);
		} else if ("FORALL".equalsIgnoreCase(listselector)) {
			result = compareForall(scalarAsValue, operator, list, context);
		} else {
			throw new JessException(getName(),
					"Unable to compare value with list",
					"The third argument should be either \"EXISTS\" or \"FORALL\" ");
		}

		return new Value(result);
	}

	private boolean compareExists(Value scalarAsValue, String operator,
			ValueVector list, final Context context) throws JessException {
		for (int i = 0; i < list.size(); ++i) {
			Funcall f = new Funcall(operator, context.getEngine());
			f.add(scalarAsValue);
			f.add(list.get(i));
			Value retValue = f.execute(context);
			if (retValue.equals(Funcall.TRUE)) {
				return true;
			}
		}
		return false;
	}

	private boolean compareForall(Value scalarAsValue, String operator,
			ValueVector list, final Context context) throws JessException {
		for (int i = 0; i < list.size(); ++i) {
			Funcall f = new Funcall(operator, context.getEngine());
			f.add(scalarAsValue);
			f.add(list.get(i));
			Value retValue = f.execute(context);
			if (retValue.equals(Funcall.FALSE)) {
				return false;
			}
		}
		return true;
	}

}
