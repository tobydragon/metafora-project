package de.dfki.lasad.authoring.model.pattern;

import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * Represents a property of some element (i.e., node or link) within a
 * {@link Pattern}. {@link PropertyVariable}s are typically restricted in some
 * way to limit the set of matched elements (see {@link PropConstr}).
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class PropertyVariable {

	// standard fields
	private ElementVariable elementVar;
	private String propId;
	private String compID = PropDescr.DEFAULT_COMPONENT_ID;

	// supplemental fields
	private PropDescr prop;

	public ElementVariable getElementVar() {
		return elementVar;
	}

	public void setElementVar(ElementVariable elementVar) {
		this.elementVar = elementVar;
	}

	public String getPropId() {
		return propId;
	}

	public void setPropId(String propId) {
		this.propId = propId;
	}

	public String getCompID() {
		return compID;
	}

	public void setCompID(String compID) {
		this.compID = compID;
	}

	public PropDescr getProp() {
		return prop;
	}

	public void setProp(PropDescr prop) {
		this.prop = prop;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((compID == null) ? 0 : compID.hashCode());
		result = prime * result
				+ ((elementVar == null) ? 0 : elementVar.hashCode());
		result = prime * result + ((propId == null) ? 0 : propId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PropertyVariable other = (PropertyVariable) obj;
		if (compID == null) {
			if (other.compID != null)
				return false;
		} else if (!compID.equals(other.compID))
			return false;
		if (elementVar == null) {
			if (other.elementVar != null)
				return false;
		} else if (!elementVar.equals(other.elementVar))
			return false;
		if (propId == null) {
			if (other.propId != null)
				return false;
		} else if (!propId.equals(other.propId))
			return false;
		return true;
	}

}
