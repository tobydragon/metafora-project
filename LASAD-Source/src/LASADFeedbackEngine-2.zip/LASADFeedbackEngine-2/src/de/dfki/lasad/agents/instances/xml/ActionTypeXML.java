package de.dfki.lasad.agents.instances.xml;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.action.PriorityDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;


public class ActionTypeXML extends ServiceTypeXML {

	private static Log logger = LogFactory.getLog(ActionTypeXML.class);

	public static final String ELEMENT_NAME = "action";

	protected static ServiceID getServiceID(String agentID, Element actionElem) {
		String typeID = actionElem.getAttributeValue("id");
		return new ServiceID(agentID, typeID, ServiceClass.ACTION);
	}

	protected static PriorityDef getPriorityDef(Element actionElem) {
		Element priorityElem = actionElem.getChild(PriorityDefXML.ELEMENT_NAME);
		PriorityDef priorityDef = PriorityDefXML.fromXML(priorityElem);
		return priorityDef;
	}

	protected static Element createPatternElement() {
		return new Element(ELEMENT_NAME);
	}

	protected static void addPriorityDef(Element actionElem,
			PriorityDef priorityDef) {
		Element priorityElem = PriorityDefXML.toXML(priorityDef);
		actionElem.addContent(priorityElem);
	}
}
