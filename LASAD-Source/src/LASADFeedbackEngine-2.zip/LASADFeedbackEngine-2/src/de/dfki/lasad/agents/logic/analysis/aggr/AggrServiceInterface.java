package de.dfki.lasad.agents.logic.analysis.aggr;

import de.dfki.lasad.events.agents.SessionModelChangedEvent;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 *
 */
public interface AggrServiceInterface {
	
	public void startAggregationService();

	public void onSessionModelChanged(SessionModelChangedEvent event);

	public void onUserJoin(UserID userID);

}
