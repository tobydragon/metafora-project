package de.dfki.lasad.authoring.model.pattern;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.session.data.meta.Ontology;

/**
 * Representation of a graphical pattern described in terms of
 * {@link NodeVariable}s and {@link LinkVariable}s and constraints imposed on
 * them
 * 
 * <br/>
 * <br/>
 * (see also {@link NodeConstr} and {@link LinkConstr}).
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class Pattern {

	private static final Log logger = LogFactory.getLog(Pattern.class);

	// standard fields
	private String ID;
	private List<NodeConstr> nodeConstrs = new Vector<NodeConstr>();
	private List<LinkConstr> linkConstrs = new Vector<LinkConstr>();
	private String ontologyID;

	// supplemental fields
	private Ontology ontology;
	private Map<Integer, List<String>> constantNumID2Values = new HashMap<Integer, List<String>>();

	public List<NodeConstr> getNodeConstrs() {
		return nodeConstrs;
	}

	public void setNodeConstrs(List<NodeConstr> nodeConstrs) {
		this.nodeConstrs = nodeConstrs;
	}

	public List<LinkConstr> getLinkConstrs() {
		return linkConstrs;
	}

	public void setLinkConstrs(List<LinkConstr> linkConstrs) {
		this.linkConstrs = linkConstrs;
	}

	public String getOntologyID() {
		return ontologyID;
	}

	public void setOntologyID(String ontologyID) {
		this.ontologyID = ontologyID;
	}

	public Ontology getOntology() {
		return ontology;
	}

	public String getID() {
		return ID;
	}

	public void setID(String ID) {
		this.ID = ID;
	}

	public void setOntology(Ontology ontology) {
		this.ontology = ontology;
	}

	/**
	 * 
	 * @return List of {@link NodeConstr}s with lower sequence number than
	 *         reference {@link NodeConstr}
	 */
	public List<NodeConstr> getNodePredecessors(NodeConstr queryNode) {
		List<NodeConstr> result = new Vector<NodeConstr>();
		String varID = queryNode.getElemVar().getVarID();
		for (NodeConstr otherNode : nodeConstrs) {
			String otherVarID = otherNode.getElemVar().getVarID();
			if (varID.equals(otherVarID)) {
				return result;
			}
			result.add(otherNode);
		}
		logger.error("Error in method 'getNodePredecessors(...)': "
				+ "NodeConstr not found in Pattern.");
		return null;
	}

	/**
	 * 
	 * @return List of {@link LinkConstr}s with lower sequence number than
	 *         reference {@link LinkConstr}
	 */

	public List<LinkConstr> getLinkPredecessors(LinkConstr queryLink) {
		List<LinkConstr> result = new Vector<LinkConstr>();
		String varID = queryLink.getElemVar().getVarID();
		for (LinkConstr otherLink : linkConstrs) {
			String otherVarID = otherLink.getElemVar().getVarID();
			if (varID.equals(otherVarID)) {
				return result;
			}
			result.add(otherLink);
		}
		logger.error("Error in method 'getLinkPredecessors(...)': "
				+ "LinkConstr not found in Pattern.");
		return null;
	}

	public Map<Integer, List<String>> getConstantNumID2Values() {
		return constantNumID2Values;
	}

	public void setConstantNumID2Values(
			Map<Integer, List<String>> constantNumID2Values) {
		this.constantNumID2Values = constantNumID2Values;
	}

}
