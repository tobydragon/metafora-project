package de.dfki.lasad.agents.instances.deeploop.preprocessing;

import java.util.List;

import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.EmptyID;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;

/**
 * Translates nodes and links that are used within a single
 * {@link ObjectActionEvent} to a flat representation (see also
 * {@link FlatGraphModeler}).
 * 
 * @author Oliver Scheuer
 * 
 */
public class EventObjectFlattener {

	SimplePropertyMappingsConfiguration configuration;

	public EventObjectFlattener(
			SimplePropertyMappingsConfiguration configuration) {
		this.configuration = configuration;
	}

	public EUEObject getFlattenedObject(ObjectActionEvent objectEvent) {
		FlatGraphModeler graphModeler = new FlatGraphModeler(configuration);
		graphModeler.executeEvent(objectEvent);

		List<EUEObject> eueObjectList = objectEvent.getEueObjectList();

		EUEObject unflattenedObject;
		if (eueObjectList.size() == 0) {
			// TODO throw Exception instead of using null
			unflattenedObject = null;
		}

		else if (eueObjectList.size() == 1) {
			// can be a node, link or a node / link component
			unflattenedObject = eueObjectList.get(0);
		} else {
			// assumptions: eueObjectList.size() > 1; there is always a toplevel
			// element when more than 1 object is provided
			unflattenedObject = searchTopMostObject(eueObjectList);

		}
		return getFlattenedObject(graphModeler, unflattenedObject);
	}

	private EUEObject searchTopMostObject(List<EUEObject> eueObjectList) {
		for (EUEObject eueObject : eueObjectList) {
			if (eueObject instanceof Link) {
				// links are always topmost objects
				return eueObject;
			} else {
				Node node = (Node) eueObject;
				if (node.getParentID() instanceof EmptyID) {
					return node;
				}
			}
		}
		// TODO throw exception instead
		return null;
	}

	private EUEObject getFlattenedObject(FlatGraphModeler graphModeler,
			EUEObject eueObject) {
		if (eueObject instanceof Node) {
			return graphModeler.getNodes().iterator().next();
		} else {
			// assumption: eueObjectList.get(0) instanceof Link
			return graphModeler.getLinks().iterator().next();
		}
	}

}
