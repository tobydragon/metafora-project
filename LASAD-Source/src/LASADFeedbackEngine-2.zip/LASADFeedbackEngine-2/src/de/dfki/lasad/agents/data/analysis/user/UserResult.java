package de.dfki.lasad.agents.data.analysis.user;

import lasad.shared.dfki.meta.agents.analysis.AnalysisType;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class UserResult extends AnalysisResult {

	protected UserID userID = null;

	public UserResult(AnalysisType analysisType) {
		super(analysisType);
	}

	public UserResult(AnalysisType analysisType, UserID userID) {
		super(analysisType);
		this.userID = userID;
	}

	public UserID getUserID() {
		return userID;
	}

	public void setUserID(UserID userID) {
		this.userID = userID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((userID == null) ? 0 : userID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserResult other = (UserResult) obj;
		if (userID == null) {
			if (other.userID != null)
				return false;
		} else if (!userID.equals(other.userID))
			return false;
		return true;
	}

}
