package de.dfki.lasad.events.eue.user.object;

import java.util.List;

import de.dfki.lasad.events.eue.EUEEventID;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.objects.EUEObject;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class FocusObjectEvent extends ObjectActionEvent {

	public static final int SET_FOCUS = 1;
	public static final int REMOVE_FOCUS = 2;

	protected int focusAction = -1;

	public FocusObjectEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID, List<EUEObject> eueObject) {
		super(sessionID, srcCompId, eueEventID, userID, eueObject);
	}

	public FocusObjectEvent(SessionID sessionID, EUEEventID eueEventId,
			String srcComponentId) {
		super(sessionID, srcComponentId, eueEventId);
	}

	public FocusObjectEvent(SessionID sessionID, EUEEventID eueEventId,
			String srcComponentId, int focusAction) {
		super(sessionID, srcComponentId, eueEventId);
		this.focusAction = focusAction;
	}
	
	@Override
	public ObjectActionEvent cloneWithoutObjects() {
		FocusObjectEvent clone = new FocusObjectEvent(getSessionID(),
				getEueEventID(), getSourceComponentID());
		clone.setUserID(getUserID());
		clone.setFocusAction(getFocusAction());
		return clone;
	}

	public int getFocusAction() {
		return focusAction;
	}

	public void setFocusAction(int focusAction) {
		this.focusAction = focusAction;
	}

	@Override
	public String toString() {
		String focusAction;
		if(SET_FOCUS == this.focusAction){
			focusAction = "focus-set";
		}
		else{
			focusAction = "focus-remove";
		}
		
		return super.toString() +  ", focusAction=" + focusAction;
	}
}
