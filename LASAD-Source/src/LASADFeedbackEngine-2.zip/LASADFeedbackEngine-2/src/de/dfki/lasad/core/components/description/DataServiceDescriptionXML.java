package de.dfki.lasad.core.components.description;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class DataServiceDescriptionXML {

	private static Log logger = LogFactory
			.getLog(DataServiceDescriptionXML.class);

	public static DataServiceDescription fromXML(Element agentElem) {
		try {
			BasicDescription basicDescr = BasicDescriptionXML
					.fromXML(agentElem);
			DataServiceDescription dataDescr = new DataServiceDescription(
					basicDescr);
			dataDescr.init();
			return dataDescr;
		} catch (Exception e) {
			logger.error("Error in 'fromXML(...)'", e);
			return null;
		}

	}

	public static Element toXML(DataServiceDescription agentDescr) {
		return BasicDescriptionXML.toXML("dataservice", agentDescr);
	}

}
