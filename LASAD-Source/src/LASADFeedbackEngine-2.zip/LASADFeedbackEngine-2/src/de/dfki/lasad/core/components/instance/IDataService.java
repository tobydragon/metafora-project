package de.dfki.lasad.core.components.instance;

import de.dfki.lasad.core.ConfigurationManager;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.session.SessionManager;

/**
 * Provides connectivity to the end user environment (EUE). Typically a local
 * proxy for a remote data service
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent})
 * 
 * @author Oliver Scheuer
 * 
 */
public interface IDataService extends IComponent {

	/**
	 * Establish runtime dependencies at system initialization time.
	 */
	public void doWire(SessionManager sessionManager,
			ConfigurationManager agentManager);

	public void onOutEvent(Event event);

}
