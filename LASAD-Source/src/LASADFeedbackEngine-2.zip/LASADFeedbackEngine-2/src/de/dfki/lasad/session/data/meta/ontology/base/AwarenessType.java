package de.dfki.lasad.session.data.meta.ontology.base;

import de.dfki.lasad.session.data.meta.ontology.ComparisonGroup;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * 
 * @author oliverscheuer
 *
 */
public class AwarenessType extends BaseType {

	private static AwarenessType instance = new AwarenessType();
	
	private AwarenessType(){
		super();
		lasadElementType = "awareness";
		jessTemplateName = "elem_awareness";
		addComponentSpecification(PropDescr.DEFAULT_COMPONENT_ID, "TEXT", JessDataType.STRING, ComparisonGroup.NONE);
	}
	
	public static AwarenessType getInstance(){
		return instance;
	}
}
