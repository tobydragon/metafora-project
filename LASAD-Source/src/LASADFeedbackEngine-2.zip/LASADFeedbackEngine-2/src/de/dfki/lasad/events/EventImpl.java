package de.dfki.lasad.events;


public abstract class EventImpl implements Comparable<Event>, Event {

	private long ts;
	protected String sourceComponentID;
	private int priority = 1;

	public EventImpl(String srcCompId) {
		sourceComponentID = srcCompId;
		ts = System.currentTimeMillis();
	}

	/* (non-Javadoc)
	 * @see de.dfki.lasad.events.IEvent#getTs()
	 */
	@Override
	public long getTs() {
		return ts;
	}

	/* (non-Javadoc)
	 * @see de.dfki.lasad.events.IEvent#setTs(long)
	 */
	@Override
	public void setTs(long ts) {
		this.ts = ts;
	}

	/* (non-Javadoc)
	 * @see de.dfki.lasad.events.IEvent#getEventPriority()
	 */
	@Override
	public int getEventPriority() {
		return priority;
	}

	/* (non-Javadoc)
	 * @see de.dfki.lasad.events.IEvent#setEventPriority(int)
	 */
	@Override
	public void setEventPriority(int priority) {
		this.priority = priority;
	}

	/* (non-Javadoc)
	 * @see de.dfki.lasad.events.IEvent#setSourceComponentID(java.lang.String)
	 */
	@Override
	public void setSourceComponentID(String sourceComponentID) {
		this.sourceComponentID = sourceComponentID;
	}

	/* (non-Javadoc)
	 * @see de.dfki.lasad.events.IEvent#getSourceComponentID()
	 */
	@Override
	public String getSourceComponentID() {
		return sourceComponentID;
	}
	
	/* (non-Javadoc)
	 * @see de.dfki.lasad.events.IEvent#getClassName()
	 */
	@Override
	public String getClassName() {
		return getClass().getSimpleName();
	}

	
	@Override
	public int compareTo(Event otherEvent) {
		int priorityDiff = otherEvent.getEventPriority() - priority;
		if (priorityDiff != 0) {
			return priorityDiff;
		}
		long tsDiff = ts - otherEvent.getTs();
		if (tsDiff < 0) {
			return -1;
		} else if (tsDiff > 0) {
			return 1;
		}
		return 0;
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + ": sourceComponentID="
				+ sourceComponentID + ", ts=" + ts;
	}

}
