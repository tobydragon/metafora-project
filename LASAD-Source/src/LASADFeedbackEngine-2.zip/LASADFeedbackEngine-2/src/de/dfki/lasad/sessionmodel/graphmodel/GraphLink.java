package de.dfki.lasad.sessionmodel.graphmodel;

public class GraphLink {

}
