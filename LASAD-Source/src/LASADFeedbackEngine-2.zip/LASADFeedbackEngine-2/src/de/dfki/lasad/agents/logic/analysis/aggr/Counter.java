package de.dfki.lasad.agents.logic.analysis.aggr;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimerTask;

import lasad.shared.dfki.meta.agents.analysis.counter.CounterDef;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeGeneral;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeSpecific;
import lasad.shared.dfki.meta.agents.analysis.counter.UserRoleSetting;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.aggr.tasks.AggTask_CounterRecheckInstance;
import de.dfki.lasad.session.data.UserID;

/**
 * Counts current elements in the workspace (i.e., nodes and links) or patterns
 * (i.e., system-generated interpretations of workspace content and user
 * actions). Elements and patterns are represented as {@link CountableInstance}
 * s. Which {@link CountableInstance} are relevant is specified in the
 * {@link #counterDefinition}. {@link Counter}s are managed by and interact with
 * the {@link AggrService}.The counting state is updated on invocation of the
 * method {@link #updateCounter}. If the counter state changed a notification is
 * sent to the {@link AggrService} ({@link #notifyManager}).
 * 
 * <br/> {@link Counter}s schedule and manage {@link AggTask_CounterRecheckInstance}s
 * to re-check the fulfillment of counter conditions ( {@link CounterDef}) that
 * include restrictions on the {@link CountableInstance}'s age (e.g., count only
 * fresh instances or instances that exist for at least <i>x</i> seconds).
 * {@link AggTask_CounterRecheckInstance}s are (re-)scheduled when
 * {@link CountableInstance}s are created or modified; they are canceled when
 * the respective {@link CountableInstance} has been deleted. Tasks are added to
 * the task queue of the {@link AggrService}, which is used to manage all tasks
 * in the counting sub-system.
 * 
 * <br/>
 * <br/>
 * (see also {@link CounterDef}, {@link AggrService}, {@link CountableInstance})
 * 
 * @author oliverscheuer
 * 
 */
public class Counter {

	private Log logger = LogFactory.getLog(Counter.class);

	private String counterName;
	private AggrService manager;

	CounterDef counterDefinition;
	Set<CountableInstance> countedInstances = new HashSet<CountableInstance>();
	int count = 0;

	// instances schedules for being re-checked
	Map<CountableInstance, AggTask_CounterRecheckInstance> instance2task = new HashMap<CountableInstance, AggTask_CounterRecheckInstance>();

	public Counter(String counterName, CounterDef counterDef,
			AggrService manager) {
		this.counterName = counterName;
		this.counterDefinition = counterDef;
		this.manager = manager;
	}

	public void updateCounter(CountableInstance i, boolean deleted) {
		// logger.debug("Update counter state ...");
		boolean isCounted = countedInstances.contains(i);
		if (deleted) {
			if (isCounted) {
				countedInstances.remove(i);
				--count;
				logger.debug(counterName + ": DECREMENT (NEW: " + count + ")");
				notifyManager();
				return;
			} else {
				cancelTimerTaskIfScheduled(i);
			}
		}
		boolean doCount = doCount(i);

		if (doCount && !isCounted) {
			countedInstances.add(i);
			++count;
			logger.debug(counterName + ": INCREMENT (NEW: " + count + ")");
			notifyManager();
		} else if (!doCount && isCounted) {
			countedInstances.remove(i);
			--count;
			logger.debug(counterName + ": DECREMENT (NEW: " + count + ")");
			notifyManager();
		} else {
			logger.debug(counterName + ": NO-CHANGE (STATE: " + count + ")");
		}
	}

	public void notifyManager() {
		manager.counterChanged(this);
	}

	private void cancelTimerTaskIfScheduled(CountableInstance i) {
		TimerTask task = instance2task.remove(i);
		if (task != null) {
			task.cancel();
			manager.purgeTimer();
		}
	}

	private void scheduleTimerTask(CountableInstance i, long delay) {
		AggTask_CounterRecheckInstance task = new AggTask_CounterRecheckInstance(
				manager, this, i);
		this.manager.scheduleCounterRecheckInstanceTask(task, delay);
	}

	private boolean doCount(CountableInstance i) {
		cancelTimerTaskIfScheduled(i);

		// check type general
		InstanceTypeGeneral typeG = counterDefinition.getInstanceTypeGeneral();
		if (i.typeGeneral == InstanceTypeGeneral.NODE
				&& typeG != InstanceTypeGeneral.NODE
				&& typeG != InstanceTypeGeneral.NODE_OR_LINK) {
			return false;
		}
		if (i.typeGeneral == InstanceTypeGeneral.LINK
				&& typeG != InstanceTypeGeneral.LINK
				&& typeG != InstanceTypeGeneral.NODE_OR_LINK) {
			return false;
		}
		if (i.typeGeneral == InstanceTypeGeneral.PATTERN
				&& typeG != InstanceTypeGeneral.PATTERN) {
			return false;
		}

		// check type specific
		List<InstanceTypeSpecific> typesS = counterDefinition
				.getInstanceTypesSpecific();

		if (typesS != null && !typesS.isEmpty()
				&& !typesS.contains(i.typeSpecific)) {
			return false;
		}

		// check user
		String userIDString = counterDefinition.getUserID();
		UserRoleSetting userCrit = counterDefinition.getUserRoleSetting();
		if (userIDString != null && userCrit != UserRoleSetting.NONE) {
			UserID userID = new UserID(userIDString);
			if (userCrit == UserRoleSetting.OWNER) {
				if (!i.contributorIDs.contains(userID)
						|| i.contributorIDs.size() > 1) {
					return false;
				}
			} else if (userCrit == UserRoleSetting.CONTRIBUTOR) {
				if (!i.contributorIDs.contains(userID)) {
					return false;
				}
			} else if (userCrit == UserRoleSetting.NON_CONTRIBUTOR) {
				if (i.contributorIDs.contains(userID)) {
					return false;
				}
			}
		}

		Long objectAge = System.currentTimeMillis() - i.lastModTs;

		// check min age
		Integer minAgeInSecs = counterDefinition.getMinAgeInSecs();
		if (minAgeInSecs != null) {
			Long minAgeInMilliSecs = 1000L * minAgeInSecs;
			if (objectAge < minAgeInMilliSecs) {
				// not old enough
				// schedule timer to check whether conditions are fulfilled when
				// object is potentially old enough
				scheduleTimerTask(i, (minAgeInMilliSecs - objectAge) + 1);
				return false;
			}
		}

		// check max age
		Integer maxAgeInSecs = counterDefinition.getMaxAgeInSecs();
		if (maxAgeInSecs != null) {
			Long maxAgeInMilliSecs = 1000L * maxAgeInSecs;
			if (objectAge > maxAgeInMilliSecs) {
				// too old
				return false;
			} else {
				// schedule timer to check whether conditions are still
				// fulfilled when object is potentially too old
				scheduleTimerTask(i, (maxAgeInMilliSecs - objectAge) + 1);
			}
		}

		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((counterDefinition == null) ? 0 : counterDefinition
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Counter other = (Counter) obj;
		if (counterDefinition == null) {
			if (other.counterDefinition != null)
				return false;
		} else if (!counterDefinition.equals(other.counterDefinition))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Counter [counterDef=" + counterDefinition + ", count=" + count
				+ "]";
	}

}
