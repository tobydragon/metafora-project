package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Operator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ComparisonSimplified {

	// basic infos
	String patternID;
	String lhsVarID;
	int lhsSeqNum;
	String lhsPropID;
	String lhsPropCompID;
	Operator operator;

	// derived infos (pre-processing)
	int comparisonID;
	boolean isInternalComparison;
	Bin binClassification;
	boolean useJessConstantSetFact = false;

	// debug info to compare against derived infos (toString)
	String debugInfo;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((lhsPropCompID == null) ? 0 : lhsPropCompID.hashCode());
		result = prime * result
				+ ((lhsPropID == null) ? 0 : lhsPropID.hashCode());
		result = prime * result
				+ ((lhsVarID == null) ? 0 : lhsVarID.hashCode());
		result = prime * result
				+ ((operator == null) ? 0 : operator.hashCode());
		return result;
	}

	/**
	 * Checks all properties except
	 * 
	 * - LHS /RHS sequence number, which might change due to reordering
	 * 
	 * - comparison ID and type, which are added during pre-processing
	 * 
	 * @Override
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ComparisonSimplified other = (ComparisonSimplified) obj;
		if (lhsPropCompID == null) {
			if (other.lhsPropCompID != null)
				return false;
		} else if (!lhsPropCompID.equals(other.lhsPropCompID))
			return false;
		if (lhsPropID == null) {
			if (other.lhsPropID != null)
				return false;
		} else if (!lhsPropID.equals(other.lhsPropID))
			return false;
		if (lhsVarID == null) {
			if (other.lhsVarID != null)
				return false;
		} else if (!lhsVarID.equals(other.lhsVarID))
			return false;
		if (operator == null) {
			if (other.operator != null)
				return false;
		} else if (!operator.equals(other.operator))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "[patternID=" + patternID + ", comparisonID=" + comparisonID + ", isInternalComparison="
				+ isInternalComparison + ", bin=" + binClassification
				+ ", lhsVarID=" + lhsVarID + ", lhsSeqNum=" + lhsSeqNum
				+ ", lhsPropID=" + lhsPropID + ", lhsPropCompID="
				+ lhsPropCompID + ", operator=" + operator
				+ ", use-jess-const-fact=" + useJessConstantSetFact + ", debug-info="
				+ debugInfo + "]";
	}

	boolean isEquivalent(ComparisonSimplified other) {
		return equals(other);
	}
}
