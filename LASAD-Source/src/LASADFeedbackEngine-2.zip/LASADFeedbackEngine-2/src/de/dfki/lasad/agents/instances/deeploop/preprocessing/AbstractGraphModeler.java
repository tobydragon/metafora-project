package de.dfki.lasad.agents.instances.deeploop.preprocessing;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.DeleteObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.EUEObjectID;
import de.dfki.lasad.session.data.objects.EmptyID;
import de.dfki.lasad.session.data.objects.HistoryAwareEUEObject;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;
import de.dfki.lasad.session.data.objects.ActionHistory.ActionType;

/**
 * Aggregates a stream of {@link ObjectActionEvent}s (process
 * representation) into a graph model (product representation) that is enhanced
 * with process information ({@link HistoryAwareEUEObject}s). The model consists
 * of nodes and links, which might have an internal hierarchical structure.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AbstractGraphModeler {

	private Log logger = LogFactory.getLog(AbstractGraphModeler.class);

	// mappings (id -> object)
	protected Map<EUEObjectID, HistoryAwareEUEObject> ids2Objects = new HashMap<EUEObjectID, HistoryAwareEUEObject>();

	// mappings (objectID -> objectIDs children)
	protected Map<EUEObjectID, List<EUEObjectID>> ids2Children = new HashMap<EUEObjectID, List<EUEObjectID>>();

	// mappings (objectID -> parent objectID)
	protected Map<EUEObjectID, EUEObjectID> ids2ParentID = new HashMap<EUEObjectID, EUEObjectID>();

	// topmost elements = nodes
	protected List<HistoryAwareEUEObject> nodes = new LinkedList<HistoryAwareEUEObject>();

	protected List<HistoryAwareEUEObject> links = new LinkedList<HistoryAwareEUEObject>();

	/**
	 * Dispatch event to appropriate method based on the event type
	 */
	public void executeEvent(ObjectActionEvent objectEvent) {
		logger.debug("Start executing event: " + objectEvent);
		if (objectEvent instanceof CreateObjectEvent) {
			executeCreateEvent((CreateObjectEvent) objectEvent);
		} else if (objectEvent instanceof ModifyObjectEvent) {
			executeModifyEvent((ModifyObjectEvent) objectEvent);
		} else if (objectEvent instanceof DeleteObjectEvent) {
			executeDeleteEvent((DeleteObjectEvent) objectEvent);
		} else {
			logger.debug("Ignore Event (unhandled type): " + objectEvent);
		}

	}

	private void executeCreateEvent(CreateObjectEvent objectEvent) {
		List<EUEObject> objectList = objectEvent.getEueObjectList();

		for (EUEObject eueObject : objectList) {
			logger.debug("Add object: " + eueObject.getID());
			HistoryAwareEUEObject historyAwareObject = new HistoryAwareEUEObject(
					eueObject);
			long ts = objectEvent.getTs();
			UserID userID = objectEvent.getUserID();
			historyAwareObject.createAndAddActionToHistory(ts,
					ActionType.CREATE, userID);

			// prepare list of children ids
			List<EUEObjectID> childrenIDs = new LinkedList<EUEObjectID>();
			ids2Children.put(eueObject.getID(), childrenIDs);

			ids2Objects.put(eueObject.getID(), historyAwareObject);

			if (eueObject instanceof Link) {
				links.add(historyAwareObject);
			} else if (eueObject instanceof Node) {
				Node node = (Node) eueObject;

				if (eueObject.isTopLevelObject()) {
					// top-level element == node
					nodes.add(historyAwareObject);
				} else {
					EUEObjectID parentID = node.getParentID();

					addElementsToChildAndParentIndices(parentID, node.getID());
				}
			}

		}
	}

	private void executeModifyEvent(ModifyObjectEvent objectEvent) {

		List<EUEObject> objectList = objectEvent.getEueObjectList();

		for (EUEObject eueObject : objectList) {
			logger.debug("Modify object: " + eueObject.getID());
			HistoryAwareEUEObject historyAwareObject = ids2Objects
					.get(eueObject.getID());

			// update history
			long ts = objectEvent.getTs();
			UserID userID = objectEvent.getUserID();
			historyAwareObject.createAndAddActionToHistory(ts,
					ActionType.MODIFY, userID);

			// update properties
			EUEObject notYetUpdatedObject = historyAwareObject.getObject();
			notYetUpdatedObject.addProperties(eueObject.getProps());
			modifyGenericProperties(historyAwareObject, eueObject);
		}
	}

	private void modifyGenericProperties(
			HistoryAwareEUEObject historyAwareObject, EUEObject changeRecord) {
		EUEObject notYetUpdatedObject = historyAwareObject.getObject();

		// Note: Changing object types is currently not supported (change
		// records always contain type although types actually cannot be change)
		if (changeRecord.getType() != null) {
			// type changed
			notYetUpdatedObject.setType(changeRecord.getType());
		}

		if (notYetUpdatedObject instanceof Node) {
			Node nodeChangeRecord = (Node) changeRecord;
			Node notYetUpdatedNode = (Node) notYetUpdatedObject;

			// Note: Changing object parents is currently not supported

			// parent hasn't changed if null or equals previous parent
			if (nodeChangeRecord.getParentID() != null) {
				if (!nodeChangeRecord.getParentID().equals(
						notYetUpdatedNode.getParentID())) {
					// parent changed
					EUEObjectID parentBefore = notYetUpdatedNode.getParentID();
					notYetUpdatedNode.setParentID(nodeChangeRecord
							.getParentID());

					// change index structures if necessary

					// node has become a top-level element
					if (!(parentBefore instanceof EmptyID)
							&& (nodeChangeRecord.getParentID() instanceof EmptyID)) {
						nodes.add(historyAwareObject);
						// remove old parent
						ids2ParentID.remove(notYetUpdatedNode.getID());
						// remove as child from former parent
						ids2Children.get(parentBefore).remove(
								notYetUpdatedNode.getID());
					}
					// node has been once a top-level element but isn't anymore
					else if ((parentBefore instanceof EmptyID)
							&& !(nodeChangeRecord.getParentID() instanceof EmptyID)) {
						// remove from top-level elements
						nodes.remove(historyAwareObject);
						// update parent index (add)
						ids2ParentID.put(notYetUpdatedNode.getID(),
								notYetUpdatedNode.getParentID());
						// add as child to new parent
						ids2Children.get(nodeChangeRecord.getParentID()).add(
								notYetUpdatedNode.getID());
					}
					// parent has changed (i.e., node wasn't and will not be a
					// top-level element)
					else if (!(parentBefore instanceof EmptyID)
							&& !(nodeChangeRecord.getParentID() instanceof EmptyID)
							&& !nodeChangeRecord.getParentID().equals(
									parentBefore)) {
						// update parent index (replace)
						ids2ParentID.put(notYetUpdatedNode.getID(),
								notYetUpdatedNode.getParentID());
						// remove as child from former parent
						ids2Children.get(parentBefore).remove(
								notYetUpdatedNode.getID());
						// add as child to new parent
						ids2Children.get(nodeChangeRecord.getParentID()).add(
								notYetUpdatedNode.getID());
					}
				}
			} else if (notYetUpdatedObject instanceof Link) {
				// Note: Currently link change records always contain source and
				// target information.
				Link linkChangeRecord = (Link) changeRecord;
				Link notYetUpdatedLink = (Link) notYetUpdatedObject;
				if (linkChangeRecord.getSources() != null) {
					// sources have changed
					notYetUpdatedLink.setSources(linkChangeRecord.getSources());
				}
				if (linkChangeRecord.getTargets() != null) {
					// targets have changed
					notYetUpdatedLink.setTargets(linkChangeRecord.getTargets());
				}
			}

		}
	}

	private void executeDeleteEvent(DeleteObjectEvent objectEvent) {

		List<EUEObject> objectList = objectEvent.getEueObjectList();

		for (EUEObject eueObject : objectList) {
			deleteObjectAndChildren(eueObject);
		}
	}

	private void deleteObjectAndChildren(EUEObject eueObject) {
		logger.debug("Remove object: " + eueObject.getID());
		ids2Objects.remove(eueObject.getID());

		EUEObjectID parentID = ids2ParentID.get(eueObject.getID());
		if (parentID != null) {
			// remove child from child2parent index if parent hasn't been
			// removed yet
			List<EUEObjectID> childrenIDs = ids2Children.get(parentID);
			if (childrenIDs != null) {
				childrenIDs.remove(eueObject.getID());
			}
		}

		// only used as a key to delete objects from lists (such that equals()
		// method provides right result)
		HistoryAwareEUEObject objectAsID = new HistoryAwareEUEObject(eueObject);

		if (eueObject instanceof Node) {
			if (eueObject.isTopLevelObject()) {
				// root element == node
				nodes.remove(objectAsID);
			}
		}
		if (eueObject instanceof Link) {
			links.remove(objectAsID);
		}

		// recursion
		List<EUEObjectID> childrenIDs = ids2Children.remove(eueObject.getID());
		if (childrenIDs != null) {
			for (EUEObjectID childID : childrenIDs) {
				HistoryAwareEUEObject childObject = ids2Objects.get(childID);
				deleteObjectAndChildren(childObject.getObject());
			}
		}

	}

	private void addElementsToChildAndParentIndices(EUEObjectID parentID,
			EUEObjectID childID) {
		List<EUEObjectID> childrenIDs = ids2Children.get(parentID);
		childrenIDs.add(childID);
		ids2ParentID.put(childID, parentID);
	}

}
