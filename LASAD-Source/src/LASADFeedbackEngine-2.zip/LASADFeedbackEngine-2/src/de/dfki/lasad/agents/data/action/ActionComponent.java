package de.dfki.lasad.agents.data.action;

/**
 * A component of an action to be taken in the end-user environment.
 * 
 * @author Oliver Scheuer
 * 
 */
public interface ActionComponent {

}
