package de.dfki.lasad.events.agents.configchange;

/**
 * Notification that the Feedback-Engine configuration has changed.
 * 
 * @author oliverscheuer
 * 
 */
public class Agent2OntologyMappingAddedEvent extends AFStateChangedEvent {

	private String agentID;
	private String ontologyID;

	public Agent2OntologyMappingAddedEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public String getOntologyID() {
		return ontologyID;
	}

	public void setOntologyID(String ontologyID) {
		this.ontologyID = ontologyID;
	}

	@Override
	public String toString() {
		return "Agent2OntologyMappingAddedEvent [agentID=" + agentID
				+ ", ontologyID=" + ontologyID + "]";
	}

}
