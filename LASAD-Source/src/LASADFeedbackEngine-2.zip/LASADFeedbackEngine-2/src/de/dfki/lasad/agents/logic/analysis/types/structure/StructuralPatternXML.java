package de.dfki.lasad.agents.logic.analysis.types.structure;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableManager;
import lasad.shared.dfki.meta.agents.analysis.structure.model.LinkVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.NodeVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Num2ConstNumComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Num2NumOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Num2VarNumComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Operator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.PropConstr;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2ConstSetComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2ConstStringComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2SetOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2StringOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2VarSetComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2VarStringComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2ConstSetComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2ConstStringComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2SetOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2StringOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2VarSetComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2VarStringComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import lasad.shared.dfki.meta.agents.analysis.structure.model.VariableComparison;
import lasad.shared.dfki.meta.ontology.descr.PropDescr;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import de.dfki.lasad.util.XMLUtil;

/**
 * Used to convert xml representation of a pattern to java object representation
 * 
 * @author Almer Bolatov
 */
public class StructuralPatternXML {

	private static Log logger = LogFactory.getLog(StructuralPatternXML.class);

	public static final String ELEMENT_NAME = "structure-definition";
	public static final String NOT_PATTERN_ELEMENT_NAME = "not";
	public static final String NODE_ELEMENT_NAME = "node";
	public static final String LINK_ELEMENT_NAME = "link";
	public static final String PROP_ELEMENT_NAME = "property";

	public static final String COMP_NUM2NUM_ELEMENT_NAME = "num2num";
	public static final String COMP_STR2STR_ELEMENT_NAME = "str2str";
	public static final String COMP_SET2SET_ELEMENT_NAME = "set2set";
	public static final String COMP_SET2STR_ELEMENT_NAME = "set2str";
	public static final String COMP_STR2SET_ELEMENT_NAME = "str2set";

	public static final String COMP_VALUE_ELEMENT_NAME = "value";
	public static final String COMP_VARREF_ELEMENT_NAME = "var-ref";

	public static Element toXML(StructuralPattern pattern) {

		Element structureElem = new Element(ELEMENT_NAME);
		addNodeVariableElems(structureElem, pattern);
		addLinkVariableElems(structureElem, pattern);
		addNotPatternElems(structureElem, pattern);

		return structureElem;
	}

	private static void addNodeVariableElems(Element parentElem,
			StructuralPattern pattern) {
		for (NodeVariable n : pattern.getNodeVars()) {
			Element nodeElem = new Element(NODE_ELEMENT_NAME);
			parentElem.addContent(nodeElem);
			String id = n.getVarID();
			nodeElem.setAttribute("id", id);

			if (n.getDebugInfo() != null) {
				nodeElem.setAttribute("debug-info", n.getDebugInfo());
			}

			addPropertyElems(nodeElem, n);
		}
	}

	private static void addLinkVariableElems(Element parentElem,
			StructuralPattern pattern) {
		for (LinkVariable l : pattern.getLinkVars()) {
			Element linkElem = new Element(LINK_ELEMENT_NAME);
			parentElem.addContent(linkElem);
			String id = l.getVarID();
			linkElem.setAttribute("id", id);
			ElementVariable source = l.getSource();
			if (source != null) {
				linkElem.setAttribute("source", source.getVarID());
			}
			ElementVariable target = l.getTarget();
			if (target != null) {
				linkElem.setAttribute("target", target.getVarID());
			}
			boolean directionMatters = l.getDirectionMatters();
			linkElem.setAttribute("direction-matters",
					Boolean.toString(directionMatters));

			if (l.getDebugInfo() != null) {
				linkElem.setAttribute("debug-info", l.getDebugInfo());
			}
			addPropertyElems(linkElem, l);
		}
	}

	private static void addPropertyElems(Element parentElem,
			ElementVariable elemVar) {
		for (PropConstr propConstr : elemVar.getPropConstrs()) {
			if (propConstr.getComparisons().size() > 0) {
				Element propElem = new Element(PROP_ELEMENT_NAME);
				propElem.setAttribute("prop-id", propConstr.getPropVar()
						.getPropId());
				String lhsComponentID = propConstr.getPropVar().getCompID();
				if (!PropDescr.DEFAULT_COMPONENT_ID.equals(lhsComponentID)) {
					propElem.setAttribute("comp-id", lhsComponentID);
				}
				parentElem.addContent(propElem);
				for (Comparison comparison : propConstr.getComparisons()) {
					addComparisonElem(propElem, comparison);
				}
			}
		}
	}

	private static void addComparisonElem(Element parentElem,
			Comparison comparison) {
		Element compElem = null;
		if (comparison.getOperator() instanceof Num2NumOperator) {
			Element num2numElem = new Element(COMP_NUM2NUM_ELEMENT_NAME);
			if (comparison instanceof Num2VarNumComparison) {
				int offset = ((Num2VarNumComparison) comparison).getOffset();
				num2numElem.setAttribute("offset", Integer.toString(offset));
			}

		} else if (comparison.getOperator() instanceof Set2SetOperator) {
			Element set2setElem = new Element(COMP_SET2SET_ELEMENT_NAME);
			compElem = set2setElem;
		} else if (comparison.getOperator() instanceof String2StringOperator) {
			Element str2strElem = new Element(COMP_STR2STR_ELEMENT_NAME);
			compElem = str2strElem;
		} else if (comparison.getOperator() instanceof Set2StringOperator) {
			Element set2strElem = new Element(COMP_SET2STR_ELEMENT_NAME);
			compElem = set2strElem;
		} else if (comparison.getOperator() instanceof String2SetOperator) {
			Element str2setElem = new Element(COMP_STR2SET_ELEMENT_NAME);
			compElem = str2setElem;
		}
		compElem.setAttribute("operator",
				getOperatorString(comparison.getOperator()));

		if (comparison.getDebugInfo() != null) {
			compElem.setAttribute("debug-info", comparison.getDebugInfo());
		}
		parentElem.addContent(compElem);

		if (comparison instanceof VariableComparison) {
			addVariableComparisonArgElems(compElem,
					(VariableComparison) comparison);
		} else {
			addConstComparisonArgElems(compElem, comparison);
		}
	}

	private static void addVariableComparisonArgElems(Element compElem,
			VariableComparison comparison) {
		compElem.addContent(getVarRefElem(comparison));
	}

	private static void addConstComparisonArgElems(Element compElem,
			Comparison comparison) {
		List<Element> valueElems = getValueElems(comparison);
		for (Element valueElem : valueElems) {
			compElem.addContent(valueElem);
		}
	}

	private static String getOperatorString(Operator operator) {
		return operator.getName();
	}

	private static Element getVarRefElem(VariableComparison comparison) {
		Element varRefElem = new Element(COMP_VARREF_ELEMENT_NAME);
		varRefElem.setAttribute("elem-id", comparison.getRightExpr()
				.getElementVar().getVarID());
		varRefElem.setAttribute("prop-id", comparison.getRightExpr()
				.getPropId());
		String rhsComponentID = comparison.getRightExpr().getCompID();
		if (!PropDescr.DEFAULT_COMPONENT_ID.equals(rhsComponentID)) {
			varRefElem.setAttribute("comp-id", rhsComponentID);
		}
		boolean isNode = (comparison.getRightExpr().getElementVar() instanceof NodeVariable);
		varRefElem.setAttribute("is-node", String.valueOf(isNode));
		return varRefElem;
	}

	private static List<Element> getValueElems(Comparison comp) {
		List<Element> valueElems = new Vector<Element>();
		if (comp instanceof Num2ConstNumComparison) {
			String value = Integer.toString(((Num2ConstNumComparison) comp)
					.getRightExpr());
			Element valueElem = new Element(COMP_VALUE_ELEMENT_NAME);
			valueElem.addContent(value);
			valueElems.add(valueElem);
		} else if (comp instanceof Set2ConstSetComparison) {
			List<String> values = ((Set2ConstSetComparison) comp)
					.getRightExpr();
			for (String value : values) {
				Element valueElem = new Element(COMP_VALUE_ELEMENT_NAME);
				valueElem.addContent(value);
				valueElems.add(valueElem);
			}
		} else if (comp instanceof String2ConstStringComparison) {
			String value = ((String2ConstStringComparison) comp).getRightExpr();
			Element valueElem = new Element(COMP_VALUE_ELEMENT_NAME);
			valueElem.addContent(value);
			valueElems.add(valueElem);
		} else if (comp instanceof Set2ConstStringComparison) {
			String value = ((Set2ConstStringComparison) comp).getRightExpr();
			Element valueElem = new Element(COMP_VALUE_ELEMENT_NAME);
			valueElem.addContent(value);
			valueElems.add(valueElem);
		} else if (comp instanceof String2ConstSetComparison) {
			List<String> values = ((String2ConstSetComparison) comp)
					.getRightExpr();
			for (String value : values) {
				Element valueElem = new Element(COMP_VALUE_ELEMENT_NAME);
				valueElem.addContent(value);
				valueElems.add(valueElem);
			}
		}
		return valueElems;
	}

	private static void addNotPatternElems(Element parentElem,
			StructuralPattern pattern) {
		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			Element notPatternElem = new Element(NOT_PATTERN_ELEMENT_NAME);
			addNodeVariableElems(notPatternElem, notPattern);
			addLinkVariableElems(notPatternElem, notPattern);
			parentElem.addContent(notPatternElem);
		}
	}

	/**
	 * Constructs object representation of a pattern, build on xml
	 * representation
	 * 
	 * @param structureElem
	 * @return
	 */
	public static StructuralPattern fromXML(String typeID, Element structureElem) {
		String methodName = "[fromXML] ";

		ElementVariableManager elemVarManager = new ElementVariableManager();
		initVars(structureElem, elemVarManager);

		StructuralPattern pattern = new StructuralPattern(typeID);
		addElemVars2Pattern(structureElem, pattern, elemVarManager);

		addNotSubPatterns(structureElem, pattern, elemVarManager);

		return pattern;
	}

	public static void addNotSubPatterns(Element structureElem,
			StructuralPattern pattern, ElementVariableManager elemVarManager) {
		List<Element> notElems = structureElem
				.getChildren(NOT_PATTERN_ELEMENT_NAME);

		Iterator<Element> notElemIterator = notElems.iterator();
		while (notElemIterator.hasNext()) {
			Element notElem = notElemIterator.next();
			initVars(notElem, elemVarManager);

			StructuralPattern subPattern = pattern.createFreshSubPattern();
			addElemVars2Pattern(notElem, subPattern, elemVarManager);
			pattern.addNotSubPattern(subPattern);
		}
	}

	/**
	 * Initializes all node / link variables used in a pattern, including
	 * possible node / link types (constraints other than type constraints are
	 * not processed at this stage).
	 * 
	 * @param patternRootElem
	 * @param elemVarManager
	 */
	private static void initVars(Element patternRootElem,
			ElementVariableManager elemVarManager) {

		Iterator<Element> nodeElemIterator = patternRootElem.getChildren(
				NODE_ELEMENT_NAME).iterator();
		while (nodeElemIterator.hasNext()) {
			Element nodeElem = nodeElemIterator.next();
			String id = nodeElem.getAttributeValue("id");
			NodeVariable nodeVar = elemVarManager.createNodeVar(id);
		}
		Iterator<Element> linkElemIterator = patternRootElem.getChildren(
				LINK_ELEMENT_NAME).iterator();
		while (linkElemIterator.hasNext()) {
			Element linkElem = linkElemIterator.next();
			String id = linkElem.getAttributeValue("id");
			LinkVariable linkVar = elemVarManager.createLinkVar(id);
		}
	}

	private static void addElemVars2Pattern(Element structureElem,
			StructuralPattern pattern, ElementVariableManager elemVarManager) {

		Iterator<Element> nodeElemIterator = structureElem.getChildren(
				NODE_ELEMENT_NAME).iterator();
		while (nodeElemIterator.hasNext()) {
			Element nodeElem = nodeElemIterator.next();
			String id = nodeElem.getAttributeValue("id");
			NodeVariable nodeVar = elemVarManager.getNodeVar(id);

			String debugInfo = nodeElem.getAttributeValue("debug-info");
			nodeVar.setDebugInfo(debugInfo);

			addConstrs2ElemVar(nodeElem, nodeVar, elemVarManager);
			pattern.addNodeVar(nodeVar);
		}

		Iterator<Element> linkElemIterator = structureElem.getChildren(
				LINK_ELEMENT_NAME).iterator();
		while (linkElemIterator.hasNext()) {
			Element linkElem = linkElemIterator.next();
			String id = linkElem.getAttributeValue("id");
			LinkVariable linkVar = elemVarManager.getLinkVar(id);

			String sourceVarID = linkElem.getAttributeValue("source");
			String targetVarID = linkElem.getAttributeValue("target");
			String directionMattersStr = linkElem
					.getAttributeValue("direction-matters");

			String debugInfo = linkElem.getAttributeValue("debug-info");
			linkVar.setDebugInfo(debugInfo);

			ElementVariable sourceElemVar = elemVarManager
					.getElemVar(sourceVarID);
			linkVar.setSource(sourceElemVar);
			ElementVariable targetElemVar = elemVarManager
					.getElemVar(targetVarID);
			linkVar.setTarget(targetElemVar);
			boolean directionMatters = new Boolean(directionMattersStr);
			linkVar.setDirectionMatters(directionMatters);

			addConstrs2ElemVar(linkElem, linkVar, elemVarManager);
			pattern.addLinkVar(linkVar);
		}
	}

	private static void addConstrs2ElemVar(Element elemVarElem,
			ElementVariable parentVar, ElementVariableManager elemVarManager) {
		Iterator<Element> propsIter = elemVarElem
				.getChildren(PROP_ELEMENT_NAME).iterator();
		while (propsIter.hasNext()) {
			Element propElem = propsIter.next();
			String propID = propElem.getAttributeValue("prop-id");
			String componentID = propElem.getAttributeValue("comp-id");
			if (componentID == null) {
				componentID = PropDescr.DEFAULT_COMPONENT_ID;
			}
			ElementVariableProp lhsVarProp = parentVar.getPropVar(propID,
					componentID);
			addComparisons(propElem, lhsVarProp, elemVarManager);

		}

	}

	private static void addComparisons(Element propElem,
			ElementVariableProp lhsVarProp,
			ElementVariableManager elemVarManager) {
		Iterator<Element> compIter = propElem.getChildren().iterator();
		while (compIter.hasNext()) {
			Element comparisonElem = compIter.next();

			String operatorName = comparisonElem.getAttributeValue("operator");

			// Calculate whether it is compared to constant or to variable
			// looking at right-hand side.
			Element compRHS = comparisonElem.getChild(COMP_VALUE_ELEMENT_NAME);
			boolean isConstantComparison = (compRHS != null) ? true : false;

			// Define type of comparison
			Comparison comparison = null;

			String comparisonName = comparisonElem.getName();
			if (isConstantComparison) {
				List<String> values = parseConstantRHS(comparisonElem);
				if (comparisonName.equalsIgnoreCase(COMP_NUM2NUM_ELEMENT_NAME)) {
					Num2ConstNumComparison comp = new Num2ConstNumComparison();
					comp.setOperator(Num2NumOperator.fromString(operatorName));
					comp.setRightExpr(Integer.parseInt(values.get(0)));
					comparison = comp;
				} else if (comparisonName
						.equalsIgnoreCase(COMP_SET2SET_ELEMENT_NAME)) {
					Set2ConstSetComparison comp = new Set2ConstSetComparison();
					comp.setOperator(Set2SetOperator.fromString(operatorName));
					comp.setRightExpr(values);
					comparison = comp;
				} else if (comparisonName
						.equalsIgnoreCase(COMP_SET2STR_ELEMENT_NAME)) {
					Set2ConstStringComparison comp = new Set2ConstStringComparison();
					comp.setOperator(Set2StringOperator
							.fromString(operatorName));
					comp.setRightExpr(values.get(0));
					comparison = comp;
				} else if (comparisonName
						.equalsIgnoreCase(COMP_STR2SET_ELEMENT_NAME)) {
					String2ConstSetComparison comp = new String2ConstSetComparison();
					comp.setOperator(String2SetOperator
							.fromString(operatorName));
					comp.setRightExpr(values);
					comparison = comp;
				} else if (comparisonName
						.equalsIgnoreCase(COMP_STR2STR_ELEMENT_NAME)) {
					String2ConstStringComparison comp = new String2ConstStringComparison();
					comp.setOperator(String2StringOperator
							.fromString(operatorName));
					comp.setRightExpr(values.get(0));
					comparison = comp;
				}
			} else {
				ElementVariableProp rightExpr = parseVariableRHS(
						comparisonElem, elemVarManager);
				if (comparisonName.equals(COMP_NUM2NUM_ELEMENT_NAME)) {
					String offsetStr = comparisonElem
							.getAttributeValue("offset");
					Num2VarNumComparison comp = new Num2VarNumComparison();
					comp.setOperator(Num2NumOperator.fromString(operatorName));
					comp.setRightExpr(rightExpr);
					if (offsetStr != null) {
						comp.setOffset(Integer.parseInt(offsetStr));
					} else {
						comp.setOffset(0);
					}
					comparison = comp;
				} else if (comparisonName
						.equalsIgnoreCase(COMP_SET2SET_ELEMENT_NAME)) {
					Set2VarSetComparison comp = new Set2VarSetComparison();
					comp.setOperator(Set2SetOperator.fromString(operatorName));
					comp.setRightExpr(rightExpr);
					comparison = comp;
				} else if (comparisonName
						.equalsIgnoreCase(COMP_SET2STR_ELEMENT_NAME)) {
					Set2VarStringComparison comp = new Set2VarStringComparison();
					comp.setOperator(Set2StringOperator
							.fromString(operatorName));
					comp.setRightExpr(rightExpr);
					comparison = comp;
				} else if (comparisonName
						.equalsIgnoreCase(COMP_STR2SET_ELEMENT_NAME)) {
					String2VarSetComparison comp = new String2VarSetComparison();
					comp.setOperator(String2SetOperator
							.fromString(operatorName));
					comp.setRightExpr(rightExpr);
					comparison = comp;
				} else if (comparisonName
						.equalsIgnoreCase(COMP_STR2STR_ELEMENT_NAME)) {
					String2VarStringComparison comp = new String2VarStringComparison();
					comp.setOperator(String2StringOperator
							.fromString(operatorName));
					comp.setRightExpr(rightExpr);
					comparison = comp;
				}
			}

			comparison.setLeftExpr(lhsVarProp);

			String debugInfo = comparisonElem.getAttributeValue("debug-info");
			comparison.setDebugInfo(debugInfo);
			lhsVarProp.getElementVar().addComparisonIfNotExists(comparison);
		}
	}

	private static List<String> parseConstantRHS(Element comparisonElem) {
		List<String> values = new ArrayList<String>();
		Iterator<Element> valuesIterator = comparisonElem.getChildren(
				COMP_VALUE_ELEMENT_NAME).iterator();
		while (valuesIterator.hasNext()) {
			Element valueElement = valuesIterator.next();
			values.add(valueElement.getTextTrim());
		}
		return values;
	}

	private static ElementVariableProp parseVariableRHS(Element comparisonElem,
			ElementVariableManager elemVarManager) {
		Element varRefElem = comparisonElem.getChild(COMP_VARREF_ELEMENT_NAME);
		String elemId = varRefElem.getAttributeValue("elem-id");
		String propId = varRefElem.getAttributeValue("prop-id");

		String compId = varRefElem.getAttributeValue("comp-id");
		if (compId == null) {
			compId = PropDescr.DEFAULT_COMPONENT_ID;
		}

		String nodeVarStr = varRefElem.getAttributeValue("is-node");
		boolean isNodeVar = new Boolean(nodeVarStr);

		ElementVariable rhsElemVar = null;
		if (isNodeVar) {
			rhsElemVar = elemVarManager.getNodeVar(elemId);
		} else {
			rhsElemVar = elemVarManager.getLinkVar(elemId);
		}

		return rhsElemVar.getPropVar(propId, compId);
	}

	public static void main(String[] args) {

		String patternID = "PATTERN-ID";
		StructuralPattern patternBefore = new StructuralPattern(patternID);
		ElementVariableManager elemVarManager = new ElementVariableManager();
		NodeVariable n1 = elemVarManager.createNodeVar("n1");
		NodeVariable n2 = elemVarManager.createNodeVar("n2");
		LinkVariable l = elemVarManager.createLinkVar("l");
		patternBefore.addNodeVar(n1);
		patternBefore.addNodeVar(n2);
		patternBefore.addLinkVar(l);

		StructuralPattern notPattern = patternBefore.createFreshSubPattern();
		patternBefore.addNotSubPattern(notPattern);
		NodeVariable n3 = elemVarManager.createNodeVar("n3");
		notPattern.addNodeVar(n3);

		String2ConstSetComparison comparison1 = new String2ConstSetComparison();
		comparison1.setLeftExpr(n1.getPropVar("type",
				PropDescr.DEFAULT_COMPONENT_ID));
		comparison1.setOperator(String2SetOperator.IN);
		List<String> values1 = new Vector<String>();
		values1.add("test");
		values1.add("hypothetical");
		comparison1.setRightExpr(values1);
		n1.addComparisonIfNotExists(comparison1);
		// System.out.println(n1.toString());
		String2VarStringComparison comparison2 = new String2VarStringComparison();
		comparison2.setLeftExpr(n1.getPropVar("type",
				PropDescr.DEFAULT_COMPONENT_ID));
		comparison2.setOperator(String2StringOperator.NOT_EQUAL);
		comparison2.setRightExpr(n2.getPropVar("type",
				PropDescr.DEFAULT_COMPONENT_ID));
		n1.addComparisonIfNotExists(comparison2);

		String2ConstStringComparison comparison3 = new String2ConstStringComparison();
		comparison3.setLeftExpr(l.getPropVar("type",
				PropDescr.DEFAULT_COMPONENT_ID));
		comparison3.setOperator(String2StringOperator.EQUAL);
		comparison3.setRightExpr("distinguished");
		l.addComparisonIfNotExists(comparison3);

		String2ConstStringComparison comparison4 = new String2ConstStringComparison();
		comparison4.setLeftExpr(n3.getPropVar("type",
				PropDescr.DEFAULT_COMPONENT_ID));
		comparison4.setOperator(String2StringOperator.EQUAL);
		comparison4.setRightExpr("facts");
		n3.addComparisonIfNotExists(comparison4);

		l.setSource(n1);
		l.setTarget(n2);
		l.setDirectionMatters(true);

		System.out.println("--- BEFORE ---");
		Element xmlBefore = StructuralPatternXML.toXML(patternBefore);
		System.out.println(XMLUtil.xmlElem2docString(xmlBefore));
		StructuralPattern patternAfter = StructuralPatternXML.fromXML(
				patternID, xmlBefore);
		Element xmlAfter = StructuralPatternXML.toXML(patternAfter);
		System.out.println("--- AFTER ---");
		System.out.println(XMLUtil.xmlElem2docString(xmlAfter));

	}
}