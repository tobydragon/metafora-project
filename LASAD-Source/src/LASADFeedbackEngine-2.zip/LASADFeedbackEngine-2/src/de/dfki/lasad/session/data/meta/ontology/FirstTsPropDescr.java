package de.dfki.lasad.session.data.meta.ontology;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class FirstTsPropDescr extends StandardPropDescr {

	public FirstTsPropDescr() {
		super("first-ts", null, "creation_ts", JessDataType.NUMBER, ComparisonGroup.TS);
	}

}
