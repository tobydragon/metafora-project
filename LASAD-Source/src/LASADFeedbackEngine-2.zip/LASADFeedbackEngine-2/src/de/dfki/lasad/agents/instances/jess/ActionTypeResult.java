package de.dfki.lasad.agents.instances.jess;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.meta.AnalysisActionType;

/**
 * An {@link AnalysisActionType} and an associated {@link AnalysisResult}.
 * 
 * @author oliverscheuer
 * 
 */
public class ActionTypeResult {
	AnalysisActionType actionType;
	AnalysisResult result;
	double utility = -1;

	public ActionTypeResult(AnalysisActionType actionType, AnalysisResult result) {
		this.actionType = actionType;
		this.result = result;
	}

	public double getUtility() {
		return utility;
	}

	public void setUtility(double utility) {
		this.utility = utility;
	}

	public AnalysisActionType getActionType() {
		return actionType;
	}

	public void setActionType(AnalysisActionType actionType) {
		this.actionType = actionType;
	}

	public AnalysisResult getResult() {
		return result;
	}

	public void setResult(AnalysisResult result) {
		this.result = result;
	}

}
