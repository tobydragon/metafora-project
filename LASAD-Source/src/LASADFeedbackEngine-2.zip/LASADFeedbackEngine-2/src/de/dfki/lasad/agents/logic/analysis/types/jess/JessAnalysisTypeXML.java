package de.dfki.lasad.agents.logic.analysis.types.jess;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.analysis.AnalysisResultDatatype;
import lasad.shared.dfki.meta.agents.analysis.jess.JessAnalysisType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.CDATA;
import org.jdom.Element;

import de.dfki.lasad.agents.instances.xml.AnalysisTypeXML;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class JessAnalysisTypeXML extends AnalysisTypeXML {

	private static Log logger = LogFactory.getLog(JessAnalysisTypeXML.class);

	public static final String TYPE = "jess-rule";

	public static JessAnalysisType fromXML(String agentID, Element elem) {
		ServiceID serviceID = getServiceID(agentID, elem);
		String name = getName(elem);
		String description = getDescription(elem);

		AnalysisResultDatatype resultType = getResultClass(elem);

		Element jessElem = elem.getChild("jess");
		String def = jessElem.getText();
		JessAnalysisType patDef = new JessAnalysisType(resultType, serviceID,
				def);
		patDef.setName(name);
		patDef.setDescription(description);
		return patDef;
	}

	public static Element toXML(JessAnalysisType aType) {

		Element elem = createPatternElement();
		addServiceIDAtt(elem, aType);
		addServiceTypeAtt(elem, TYPE);
		addResultTypeAtt(elem, aType);
		addNameElemIfNotNull(elem, aType);
		addDescriptionElemIfNotNull(elem, aType);

		Element jessElem = new Element("jess");
		elem.addContent(jessElem);

		CDATA ruleDefinition = new CDATA(aType.getDefinition());
		jessElem.addContent("\n");
		jessElem.addContent(ruleDefinition);

		return elem;
	}

}