package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ConstrLHSGen {

	private JessIDAndSlotNameGenerator idGen;

	private ElementVariableProp varProp;
	private int appendixNum;
	private boolean useAppendix;

	public ConstrLHSGen(JessIDAndSlotNameGenerator idGen, ElementVariableProp varProp,
			int appendixNum, boolean useAppendix) {
		this.idGen = idGen;
		this.varProp = varProp;
		this.appendixNum = appendixNum;
		this.useAppendix = useAppendix;
	}

	public String getString() {
		return idGen
				.generatePropVarID(varProp, appendixNum, useAppendix, false);
	}
}
