package de.dfki.lasad.session.data.meta.ontology;

/**
 * (see {@link ElementDescr})
 * 
 * @author oliverscheuer
 * 
 */
public class NodeDescr extends ElementDescr {

	public NodeDescr(String elemTypeID) {
		super(elemTypeID);
	}
}
