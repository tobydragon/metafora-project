package de.dfki.lasad.core.components.collections;

import java.io.File;
import java.io.FileWriter;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.filter.ElementFilter;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

/**
 * XML (de-)serialization for {@link AgentRuntimeConfig} objects.
 * 
 * @author oliverscheuer
 * 
 */
public class AgentRuntimeConfigXML {

	static Log logger = LogFactory.getLog(AgentRuntimeConfigXML.class);

	public static AgentRuntimeConfig fromXML(Element parentElem) {
		AgentRuntimeConfig aRuntime = new AgentRuntimeConfig();

		try {
			Iterator<Element> generalIter = parentElem
					.getDescendants(new ElementFilter("general"));
			while (generalIter.hasNext()) {
				Element generalElem = generalIter.next();

				Iterator<Element> agentIter = generalElem
						.getDescendants(new ElementFilter("agent"));
				while (agentIter.hasNext()) {
					Element agentElem = agentIter.next();
					String agentID = agentElem.getAttributeValue("id");
					aRuntime.addSessionGeneralAgent(agentID);
				}
			}

			Iterator<Element> sessionIter = parentElem
					.getDescendants(new ElementFilter("session"));
			while (sessionIter.hasNext()) {
				Element sessionElem = sessionIter.next();
				String sessionID = sessionElem.getAttributeValue("id");

				Iterator<Element> agentIter = sessionElem
						.getDescendants(new ElementFilter("agent"));
				while (agentIter.hasNext()) {
					Element agentElem = agentIter.next();
					String agentID = agentElem.getAttributeValue("id");
					aRuntime.addAgent2Session(agentID, sessionID);
				}
			}

			Iterator<Element> ontologyIter = parentElem
					.getDescendants(new ElementFilter("ontology"));
			while (ontologyIter.hasNext()) {
				Element ontologyElem = ontologyIter.next();
				String ontologyID = ontologyElem.getAttributeValue("id");

				Iterator<Element> agentIter = ontologyElem
						.getDescendants(new ElementFilter("agent"));
				while (agentIter.hasNext()) {
					Element agentElem = agentIter.next();
					String agentID = agentElem.getAttributeValue("id");
					aRuntime.addAgent2Ontology(agentID, ontologyID);
				}
			}
		} catch (Exception e) {
			logger.error("Error in 'fromXML(...)'", e);
		}

		return aRuntime;
	}

	public static Element toXML(AgentRuntimeConfig aRuntime) {

		Element runtimeElem = new Element("runtime");

		Element generalAgentsElem = new Element("general");
		runtimeElem.addContent(generalAgentsElem);
		for (String agentID : aRuntime.getSessionGeneralAgents()) {
			Element agentElem = new Element("agent");
			generalAgentsElem.addContent(agentElem);
			agentElem.setAttribute("id", agentID);
		}

		Element sessionsElem = new Element("sessions");
		runtimeElem.addContent(sessionsElem);

		for (String sessionID : aRuntime.getSessionIDs()) {
			Element sessionElem = new Element("session");
			sessionsElem.addContent(sessionElem);
			sessionElem.setAttribute("id", sessionID);
			for (String agentID : aRuntime.getAgentsForSession(sessionID)) {
				Element agentElem = new Element("agent");
				sessionElem.addContent(agentElem);
				agentElem.setAttribute("id", agentID);
			}
		}

		Element ontologiesElem = new Element("ontologies");
		runtimeElem.addContent(ontologiesElem);

		for (String ontologyID : aRuntime.getOntologyIDs()) {
			Element ontologyElem = new Element("ontology");
			ontologiesElem.addContent(ontologyElem);
			ontologyElem.setAttribute("id", ontologyID);
			for (String agentID : aRuntime.getAgentsForOntology(ontologyID)) {
				Element agentElem = new Element("agent");
				ontologyElem.addContent(agentElem);
				agentElem.setAttribute("id", agentID);
			}
		}
		return runtimeElem;
	}

	public static void updateXMLFile(File file, AgentRuntimeConfig aRuntime) {
		try {
			if (file.exists()) {
				file.delete();
			}
			Element elem = toXML(aRuntime);
			XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
			Document doc = new Document();
			doc.setRootElement(elem);
			outputter.output(doc, new FileWriter(file));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
}
