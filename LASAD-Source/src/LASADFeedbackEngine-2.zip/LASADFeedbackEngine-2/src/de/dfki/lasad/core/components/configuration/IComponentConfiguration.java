package de.dfki.lasad.core.components.configuration;

import java.io.File;

import de.dfki.lasad.core.components.instance.IComponent;

/**
 * Configuration of an {@link IComponent}, will be used to instantiate specific
 * {@link IComponent} instances.
 * 
 * @author oliverscheuer
 * 
 */
public interface IComponentConfiguration {

	public void setComponentID(String componentID);

	public void load(File configFile);

	public void init();
}
