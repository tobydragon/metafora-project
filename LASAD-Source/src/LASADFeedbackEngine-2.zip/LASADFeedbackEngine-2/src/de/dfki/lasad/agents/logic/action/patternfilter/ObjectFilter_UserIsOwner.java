package de.dfki.lasad.agents.logic.action.patternfilter;

import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ObjectFilter_UserIsOwner extends ObjectFilter {

	private UserID referenceUser;

	public ObjectFilter_UserIsOwner(UserID referenceUser) {
		this.referenceUser = referenceUser;
	}

	@Override
	public boolean keep(ObjectResult oResult) {
		return oResult.getContributors().size() == 1
				&& oResult.getContributors().contains(referenceUser);

	}
}
