package de.dfki.lasad.agents.logic;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.common.ActionListDef;

import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class ActionListDefXML {

	public static ActionListDef fromXML(String agentID, Element actionsElem) {

		String allOwnTypesString = actionsElem
				.getAttributeValue("all-own-actions");
		boolean allOwnTypes = Boolean.parseBoolean(allOwnTypesString);
		if (allOwnTypes) {
			return new ActionListDef(true);
		}
		List<ServiceID> actionIDs = new Vector<ServiceID>();
		for (Element actionElem : (List<Element>) actionsElem
				.getChildren("action")) {
			ServiceID actionID = getServiceID(agentID, actionElem);
			actionIDs.add(actionID);

		}
		ActionListDef subActionDef = new ActionListDef(actionIDs);
		return subActionDef;
	}

	protected static ServiceID getServiceID(String parentAgentID,
			Element actionElem) {
		String agentID = actionElem.getAttributeValue("agent-id");
		if (agentID == null) {
			agentID = parentAgentID;
		}
		String typeID = actionElem.getAttributeValue("action-id");
		ServiceClass sClass = ServiceClass.ACTION;

		return new ServiceID(agentID, typeID, sClass);
	}

	protected static Element toXML(String elementName,
			ActionListDef actionListDef) {

		Element subActionsElem = new Element(elementName);

		if (actionListDef.isAllOwnActionTypes()) {
			subActionsElem
					.setAttribute("all-own-actions", String.valueOf(true));
		} else {
			for (ServiceID actionID : actionListDef.getServiceIDs()) {
				Element actionElem = new Element("action");
				String agentID = actionID.getAgentID();
				actionElem.setAttribute("agent-id", agentID);
				String typeID = actionID.getTypeID();
				actionElem.setAttribute("action-id", typeID);
				subActionsElem.addContent(actionElem);
			}
		}
		return subActionsElem;
	}
}
