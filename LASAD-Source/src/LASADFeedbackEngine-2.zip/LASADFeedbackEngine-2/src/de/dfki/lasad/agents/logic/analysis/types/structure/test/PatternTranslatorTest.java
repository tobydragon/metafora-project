package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.PatternJessSyntaxChecker;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.PatternTranslator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PatternTranslatorTest {

	static PatternTranslator translator = new PatternTranslator(
			TestData.largoOntology);

	static {
		translator.testModeOmitSequentialization(true);
	}

	public static void main(String[] args) {
		// StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
		// .parsePattern(TestData.TESTFILE_BINS);

		StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
				.parsePattern("R33_test_facts_without_hypos.xml");

		// StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
		// .parsePattern("R39_no_response_to_hypo.xml");

		// StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
		// .parsePattern("test_bins_2.xml");

		String jessRule = translator.generateJessRule(pattern.getServiceID(),
				pattern.getPattern());

		System.out.println(jessRule);
		printSyntaxCorrect(jessRule);

	}

	private static void printSyntaxCorrect(String jessRule) {
		String statusMessage = "GENERATED JESS CODE - SYNTAX CORRECT? ";
		try {
			PatternJessSyntaxChecker.syntaxCorrect(jessRule);
			System.out.println(statusMessage + "true");

		} catch (Exception e) {
			System.out.println(statusMessage + "false");
			e.printStackTrace();
		}
	}
}
