package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ComparisonSuppl;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ComparisonType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableSuppl;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2ConstSetComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2ConstSetComparisonSuppl;
import lasad.shared.dfki.meta.agents.analysis.structure.model.VariableComparison;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.PatternPreprocessorSequentializer;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ComparisonSimplifier {

	static List<ComparisonSimplified> generateComparisonsSimplified(
			String patternID, List<? extends ElementVariable> vars) {

		Map<String, Integer> varID2seqNum = createMappingVarID2seqNum(vars);
		List<ComparisonSimplified> comparisonsSimplified = new Vector<ComparisonSimplified>();

		for (ElementVariable var : vars) {
			for (Comparison comparison : var.getComparisons()) {
				ComparisonSimplified comparisonSimplified = createComparisonSimplified(
						comparison, null, varID2seqNum);
				comparisonSimplified.patternID = patternID;
				comparisonsSimplified.add(comparisonSimplified);
			}
		}
		return comparisonsSimplified;
	}

	static List<ComparisonSimplified> generateComparisonsSimplifiedIncludingBins(
			String patternID, List<? extends ElementVariable> vars) {

		Map<String, Integer> varID2seqNum = createMappingVarID2seqNum(vars);
		List<ComparisonSimplified> comparisonsSimplified = new Vector<ComparisonSimplified>();

		for (ElementVariable var : vars) {

			ElementVariableSuppl elemSupplData = var.getSupplData();
			if (elemSupplData != null) {
				Map<Bin, Map<ElementVariableProp, List<Comparison>>> bin2propVars2Comparisons = elemSupplData
						.getBin2propVars2Comparisons();
				for (Bin bin : bin2propVars2Comparisons.keySet()) {
					Map<ElementVariableProp, List<Comparison>> propVars2Comparisons = bin2propVars2Comparisons
							.get(bin);
					for (ElementVariableProp elemVarProp : propVars2Comparisons
							.keySet()) {
						List<Comparison> comparisons = propVars2Comparisons
								.get(elemVarProp);
						for (Comparison comparison : comparisons) {
							ComparisonSimplified comparisonSimplified = createComparisonSimplified(
									comparison, bin, varID2seqNum);
							comparisonSimplified.patternID = patternID;
							comparisonsSimplified.add(comparisonSimplified);
						}
					}
				}
			}
		}

		return comparisonsSimplified;
	}

	static Map<String, Integer> createMappingVarID2seqNum(
			List<? extends ElementVariable> vars) {
		Map<String, Integer> varID2seqNum = new HashMap<String, Integer>();
		int varSeqNum = 0;
		for (ElementVariable var : vars) {
			varID2seqNum.put(var.getVarID(), varSeqNum++);
		}
		return varID2seqNum;
	}

	static ComparisonSimplified createComparisonSimplified(
			Comparison comparison, Bin bin, Map<String, Integer> varID2seqNum) {
		ComparisonSimplified comparisonSimplified;
		if (comparison instanceof VariableComparison) {
			VariableComparison varComparison = (VariableComparison) comparison;
			ComparisonToVarSimplified comparisonToVarSimplified = createFreshVarComparisonSimplified();
			comparisonSimplified = comparisonToVarSimplified;
			comparisonToVarSimplified.rhsVarID = varComparison.getRightExpr()
					.getElementVar().getVarID();

			Integer rhsSeqNum = varID2seqNum
					.get(comparisonToVarSimplified.rhsVarID);
			if (rhsSeqNum == null) {
				// not in sequence; assume: predecessor
				rhsSeqNum = PatternPreprocessorSequentializer.PREDECESSOR_SEQ_NUM;
			}
			comparisonToVarSimplified.rhsSeqNum = rhsSeqNum;

			comparisonToVarSimplified.rhsPropID = varComparison.getRightExpr()
					.getPropId();
			comparisonToVarSimplified.rhsPropCompID = varComparison
					.getRightExpr().getCompID();

		} else {
			comparisonSimplified = new ComparisonSimplified();
		}

		ComparisonSuppl compSupplData = comparison.getSupplData();
		if (compSupplData != null) {
			comparisonSimplified.comparisonID = compSupplData.getId();
			comparisonSimplified.isInternalComparison = ComparisonType.INTERNAL
					.equals(compSupplData.getType());

			if (compSupplData instanceof Set2ConstSetComparisonSuppl) {
				comparisonSimplified.useJessConstantSetFact = ((Set2ConstSetComparisonSuppl) compSupplData)
						.isUseJessConstantSetFact();
			}
		}
		comparisonSimplified.lhsVarID = comparison.getLeftExpr()
				.getElementVar().getVarID();
		comparisonSimplified.lhsSeqNum = varID2seqNum
				.get(comparisonSimplified.lhsVarID);
		comparisonSimplified.lhsPropID = comparison.getLeftExpr().getPropId();
		comparisonSimplified.lhsPropCompID = comparison.getLeftExpr()
				.getCompID();

		comparisonSimplified.operator = comparison.getOperator();

		comparisonSimplified.debugInfo = comparison.getDebugInfo();

		comparisonSimplified.binClassification = bin;

		return comparisonSimplified;
	}

	static ComparisonToVarSimplified createFreshVarComparisonSimplified() {
		return new ComparisonToVarSimplified();
	}
}
