package de.dfki.lasad.agents.data.analysis;

import java.util.HashMap;
import java.util.Map;

import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import de.dfki.lasad.agents.data.action.ActionComponent;
import de.dfki.lasad.core.components.instance.IAgent;

/**
 * Represents the results when {@link IAgent}s analyze user actions, workspace
 * contents or other {@link AnalysisResult}s. Metadata about the analysis can be
 * accessed through the {@link AnalysisType}. {@link AnalysisResult}s can be
 * provided to the user without further processing as {@link ActionComponent}s.
 * 
 * @author Oliver Scheuer
 * 
 */
public abstract class AnalysisResult implements ActionComponent {

	protected int id;
	protected AnalysisType analysisType;

	protected Long detectionTs;

	// generic properties that are associated with the result and that can be
	// used to provide more specific feedback,
	protected Map<String, String> properties = new HashMap<String, String>();

	public AnalysisResult(AnalysisType analysisType) {
		this.analysisType = analysisType;
	}

	/**
	 * 
	 * @return Metadata about the analysis.
	 */
	public AnalysisType getAnalysisType() {
		return analysisType;
	}

	public abstract String getValueAsString();

	public void addProperty(String name, String value) {
		properties.put(name, value);
	}

	public String getPropertyValue(String name) {
		return properties.get(name);
	}

	public Map<String, String> getProperties() {
		return properties;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 * 
	 * @return detection ts or <code>null</code> of there is no meaningful
	 *         detection ts
	 */
	public Long getDetectionTs() {
		return detectionTs;
	}

	public void setDetectionTs(Long ts) {
		this.detectionTs = ts;
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + ": analysisType=[id=" + id
				+ ", analysisTypeID=" + analysisType.getServiceID()
				+ ", detectionTs=" + detectionTs + ", properties=" + properties
				+ "]";
	}

	public String toSimpleString() {
		return getClass().getSimpleName() + ": [id=" + id + ", type="
				+ analysisType.getServiceID() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((analysisType == null) ? 0 : analysisType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AnalysisResult other = (AnalysisResult) obj;
		if (analysisType == null) {
			if (other.analysisType != null)
				return false;
		} else if (!analysisType.equals(other.analysisType))
			return false;
		return true;
	}

}
