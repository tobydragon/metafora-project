package de.dfki.lasad.agents.logic.action.types.feedback;

import java.util.List;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.action.PriorityDef;
import lasad.shared.dfki.meta.agents.action.feedback.FeedbackActionType;
import lasad.shared.dfki.meta.agents.action.feedback.MsgCompDef;
import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import de.dfki.lasad.agents.instances.xml.ActionTypeXML;
import de.dfki.lasad.agents.logic.action.patternfilter.xml.PatternFilterDefListXML;
import de.dfki.lasad.agents.logic.provision.actiongen.xml.MsgCompDefListXML;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class FeedbackActionTypeXML extends ActionTypeXML {

	private static Log logger = LogFactory.getLog(FeedbackActionTypeXML.class);

	public static final String TYPE = "feedback";
	public static final String TRIGGER_ELEM_NAME = "trigger";

	public static FeedbackActionType fromXML(String agentID, Element actionElem) {
		ServiceID serviceID = getServiceID(agentID, actionElem);
		String name = getName(actionElem);
		String description = getDescription(actionElem);

		Element triggerElem = actionElem.getChild(TRIGGER_ELEM_NAME);
		ServiceID triggerAnalysisType = getTrigger(agentID, triggerElem);

		FeedbackActionType feedbackType = new FeedbackActionType(serviceID,
				triggerAnalysisType);
		feedbackType.setName(name);
		feedbackType.setDescription(description);

		Element messageElem = actionElem
				.getChild(MsgCompDefListXML.ELEMENT_NAME);
		List<MsgCompDef> msgCmps = MsgCompDefListXML.fromXML(messageElem);
		feedbackType.setMsgCompDefs(msgCmps);

		Element filtersElem = actionElem
				.getChild(PatternFilterDefListXML.ELEMENT_NAME);
		List<PatternFilterDef> filterDefs = PatternFilterDefListXML
				.fromXML(filtersElem);
		feedbackType.setFilterDefs(filterDefs);

		PriorityDef priorityDef = getPriorityDef(actionElem);
		feedbackType.setPriorityDef(priorityDef);

		return feedbackType;
	}

	protected static ServiceID getTrigger(String parentAgentID,
			Element triggerElem) {
		String agentID = triggerElem.getAttributeValue("agent-id");
		if (agentID == null) {
			agentID = parentAgentID;
		}
		String typeID = triggerElem.getAttributeValue("pattern-id");
		ServiceClass sClass = ServiceClass.ANALYSIS;

		return new ServiceID(agentID, typeID, sClass);
	}

	public static Element toXML(FeedbackActionType feedbackType) {

		Element actionElem = new Element(ActionTypeXML.ELEMENT_NAME);
		addServiceIDAtt(actionElem, feedbackType);
		addServiceTypeAtt(actionElem, TYPE);
		addNameElemIfNotNull(actionElem, feedbackType);
		addDescriptionElemIfNotNull(actionElem, feedbackType);

		ServiceID triggerID = feedbackType.getTriggerID();
		addTriggerElem(actionElem, triggerID);

		List<MsgCompDef> msgCmps = feedbackType.getMsgCompDefs();
		Element messageElem = MsgCompDefListXML.toXML(msgCmps);
		actionElem.addContent(messageElem);

		List<PatternFilterDef> filterDefs = feedbackType.getFilterDefs();
		Element filtersElem = PatternFilterDefListXML.toXML(filterDefs);
		actionElem.addContent(filtersElem);

		PriorityDef priorityDef = feedbackType.getPriorityDef();
		addPriorityDef(actionElem, priorityDef);

		return actionElem;
	}

	protected static void addTriggerElem(Element actionElem, ServiceID triggerID) {
		Element triggerElem = new Element(TRIGGER_ELEM_NAME);
		actionElem.addContent(triggerElem);

		String agentID = triggerID.getAgentID();
		triggerElem.setAttribute("agent-id", agentID);

		String typeID = triggerID.getTypeID();
		triggerElem.setAttribute("pattern-id", typeID);
	}
}
