package de.dfki.lasad.agents.logic.analysis.types.counter;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterCriterionDef;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterCriterionOperator;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterDef;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeGeneral;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeSpecific;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeSpecific_Object;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeSpecific_Pattern;
import lasad.shared.dfki.meta.agents.analysis.counter.UserRoleSetting;
import lasad.shared.dfki.meta.agents.analysis.counter.UserSelectionSetting;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import de.dfki.lasad.agents.instances.xml.AnalysisTypeXML;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class CounterAnalysisTypeXML extends AnalysisTypeXML {

	private static Log logger = LogFactory.getLog(CounterAnalysisTypeXML.class);

	public static final String TYPE = "counter-condition";

	public static CounterAnalysisType fromXML(String agentID,
			Element patternElem) {

		ServiceID serviceID = getServiceID(agentID, patternElem);
		String name = getName(patternElem);
		String description = getDescription(patternElem);

		Element instanceTypeElem = patternElem.getChild("instance-type");
		String typeGeneralString = instanceTypeElem.getAttributeValue("class");
		InstanceTypeGeneral objectTypeGeneral = getInstanceTypeGeneral(typeGeneralString);

		List<InstanceTypeSpecific> typesSpecific = getTypesSpecific(agentID,
				instanceTypeElem);

		Integer minAge = null;
		Integer maxAge = null;
		Element instanceAgeElem = patternElem.getChild("instance-age");
		if (instanceAgeElem != null) {
			String minAgeFromXML = instanceAgeElem.getAttributeValue("min");
			if (minAgeFromXML != null) {
				minAge = Integer.parseInt(minAgeFromXML);
			}

			String maxAgeFromXML = instanceAgeElem.getAttributeValue("max");
			if (maxAgeFromXML != null) {
				maxAge = Integer.parseInt(maxAgeFromXML);
			}
		}

		String userID = null;
		UserSelectionSetting userSelectionCriterion = UserSelectionSetting.NONE;
		UserRoleSetting userRoleSetting = UserRoleSetting.NONE;
		Element userElem = patternElem.getChild("user");
		if (userElem != null) {
			String userRoleFromXML = userElem.getAttributeValue("role");
			if (userRoleFromXML != null) {
				userRoleSetting = getUserRole(userRoleFromXML);

				// userID and user-selection make only sense if user-role has
				// been specified
				String userIDFromXML = userElem.getAttributeValue("user-id");
				if (userIDFromXML != null) {
					userID = userIDFromXML;
					userSelectionCriterion = UserSelectionSetting.ONE;
				} else {
					userSelectionCriterion = UserSelectionSetting.FOREACH;
				}
			}
		}

		CounterDef counterDef = new CounterDef(userSelectionCriterion, userID,
				userRoleSetting, objectTypeGeneral, typesSpecific, minAge,
				maxAge);

		CounterCriterionDef counterCriterion = getCounterCriterion(patternElem);
		CounterAnalysisType counterType;
		if(counterCriterion != null){
			counterType = new CounterAnalysisType(serviceID,
					counterDef, counterCriterion);
		}else{
			counterType = new CounterAnalysisType(serviceID,
					counterDef, new Vector<CounterCriterionDef>());
		}

		counterType.setName(name);
		counterType.setDescription(description);
		return counterType;
	}

	private static InstanceTypeGeneral getInstanceTypeGeneral(
			String typeGeneralString) {
		if ("node".equalsIgnoreCase(typeGeneralString)) {
			return InstanceTypeGeneral.NODE;
		} else if ("link".equalsIgnoreCase(typeGeneralString)) {
			return InstanceTypeGeneral.LINK;
		} else if ("node-or-link".equalsIgnoreCase(typeGeneralString)) {
			return InstanceTypeGeneral.NODE_OR_LINK;
		} else if ("pattern".equalsIgnoreCase(typeGeneralString)) {
			return InstanceTypeGeneral.PATTERN;
		} else {
			logger.error("Unhandled instance class: " + typeGeneralString);
			return null;
		}
	}

	private static List<InstanceTypeSpecific> getTypesSpecific(
			String thisAgentID, Element instanceTypeElem) {
		List<InstanceTypeSpecific> typesSpecific = new Vector<InstanceTypeSpecific>();
		List<Element> objectElems = instanceTypeElem.getChildren("object");
		for (Element objectElem : objectElems) {
			String typeID = objectElem.getAttributeValue("type");
			InstanceTypeSpecific typeSpecific = new InstanceTypeSpecific_Object(
					typeID);
			typesSpecific.add(typeSpecific);
		}
		List<Element> patternElems = instanceTypeElem.getChildren("pattern");
		for (Element patternElem : patternElems) {
			String agentID = patternElem.getAttributeValue("agent-id");
			String typeID = patternElem.getAttributeValue("type");
			if (agentID == null) {
				InstanceTypeSpecific typeSpecific = new InstanceTypeSpecific_Pattern(
						thisAgentID, typeID);
				typesSpecific.add(typeSpecific);
			} else {
				InstanceTypeSpecific typeSpecific = new InstanceTypeSpecific_Pattern(
						agentID, typeID);
				typesSpecific.add(typeSpecific);
			}
		}
		return typesSpecific;
	}

	private static UserRoleSetting getUserRole(String userRoleString) {
		if ("none".equalsIgnoreCase(userRoleString)) {
			return UserRoleSetting.NONE;
		} else if ("owner".equalsIgnoreCase(userRoleString)) {
			return UserRoleSetting.OWNER;
		} else if ("contributor".equalsIgnoreCase(userRoleString)) {
			return UserRoleSetting.CONTRIBUTOR;
		} else if ("non-contributor".equalsIgnoreCase(userRoleString)) {
			return UserRoleSetting.NON_CONTRIBUTOR;
		} else {
			logger.error("Unhandled user role criterion: " + userRoleString);
			return null;
		}
	}

	private static CounterCriterionDef getCounterCriterion(Element patternElem) {
		Element conditionElem = patternElem.getChild("condition");
		CounterCriterionDef cc = null;
		if(conditionElem != null){
			String operatorFromXML = conditionElem.getAttributeValue("operator");
			CounterCriterionOperator op = null;
			if ("equal".equalsIgnoreCase(operatorFromXML)) {
				op = CounterCriterionOperator.EQUAL;
			} else if ("greater".equalsIgnoreCase(operatorFromXML)) {
				op = CounterCriterionOperator.GREATER;
			} else if ("greater-or-equal".equalsIgnoreCase(operatorFromXML)) {
				op = CounterCriterionOperator.GREATER_OR_EQUAL;
			} else if ("less".equalsIgnoreCase(operatorFromXML)) {
				op = CounterCriterionOperator.LESS;
			} else if ("less-or-equal".equalsIgnoreCase(operatorFromXML)) {
				op = CounterCriterionOperator.LESS_OR_EQUAL;
			}
			String refValFromXML = conditionElem.getAttributeValue("ref-value");
			int refVal = Integer.parseInt(refValFromXML);
			cc = new CounterCriterionDef(op, refVal);
		}
		
		return cc;
	}

	public static Element toXML(CounterAnalysisType counterType) {

		Element patternElem = createPatternElement();
		addServiceIDAtt(patternElem, counterType);
		addServiceTypeAtt(patternElem, TYPE);
		addResultTypeAtt(patternElem, counterType);
		addNameElemIfNotNull(patternElem, counterType);
		addDescriptionElemIfNotNull(patternElem, counterType);

		CounterDef counterDef = counterType.getCounterDefinition();
		InstanceTypeGeneral typeGeneral = counterDef.getInstanceTypeGeneral();
		List<InstanceTypeSpecific> typesSpecific = counterDef
				.getInstanceTypesSpecific();
		Element instanceTypeElem = createInstanceTypeElem(typeGeneral,
				typesSpecific);
		patternElem.addContent(instanceTypeElem);

		Integer minAge = counterDef.getMinAgeInSecs();
		Integer maxAge = counterDef.getMaxAgeInSecs();
		if (minAge != null || maxAge != null) {
			Element instanceAgeElem = createInstanceAgeElem(minAge, maxAge);
			patternElem.addContent(instanceAgeElem);
		}

		UserSelectionSetting userSelection = counterDef
				.getUserSelectionSetting();
		UserRoleSetting userRole = counterDef.getUserRoleSetting();
		String userID = counterDef.getUserID();
		if (userSelection != UserSelectionSetting.NONE
				&& userRole != UserRoleSetting.NONE) {
			Element userElem = createUserElem(userSelection, userRole, userID);
			patternElem.addContent(userElem);
		}

		List<CounterCriterionDef> criterionDefs = counterType
				.getCounterCriteria();
		if (criterionDefs.size() == 0) {
			logger.warn("No counter criteria defined: "
					+ counterType.getServiceID());
		}
		for (CounterCriterionDef criterionDef : criterionDefs) {
			Element conditionElem = createConditionElem(criterionDef);
			patternElem.addContent(conditionElem);
		}

		return patternElem;
	}

	private static Element createInstanceTypeElem(
			InstanceTypeGeneral typeGeneral,
			List<InstanceTypeSpecific> typesSpecific) {
		Element instanceTypeElem = new Element("instance-type");
		if (InstanceTypeGeneral.NODE == typeGeneral) {
			instanceTypeElem.setAttribute("class", "node");
		} else if (InstanceTypeGeneral.LINK == typeGeneral) {
			instanceTypeElem.setAttribute("class", "link");
		} else if (InstanceTypeGeneral.NODE_OR_LINK == typeGeneral) {
			instanceTypeElem.setAttribute("class", "node-or-link");
		} else if (InstanceTypeGeneral.PATTERN == typeGeneral) {
			instanceTypeElem.setAttribute("class", "pattern");
		} else {
			logger.warn("Unhandled instance type general: " + typeGeneral);
		}

		for (InstanceTypeSpecific typeSpecific : typesSpecific) {
			if (typeSpecific instanceof InstanceTypeSpecific_Object) {
				InstanceTypeSpecific_Object instanceTypeObject = (InstanceTypeSpecific_Object) typeSpecific;
				Element typeSpecificElem = new Element("object");
				typeSpecificElem.setAttribute("type",
						instanceTypeObject.getTypeID());
				instanceTypeElem.addContent(typeSpecificElem);

			} else if (typeSpecific instanceof InstanceTypeSpecific_Pattern) {
				InstanceTypeSpecific_Pattern instanceTypePattern = (InstanceTypeSpecific_Pattern) typeSpecific;
				Element typeSpecificElem = new Element("pattern");
				typeSpecificElem.setAttribute("agent-id",
						instanceTypePattern.getAgentID());
				typeSpecificElem.setAttribute("type",
						instanceTypePattern.getTypeID());
				instanceTypeElem.addContent(typeSpecificElem);
			}
		}
		return instanceTypeElem;
	}

	private static Element createInstanceAgeElem(Integer minAge, Integer maxAge) {
		Element instanceAgeElem = new Element("instance-age");
		if (minAge != null) {
			instanceAgeElem.setAttribute("min", String.valueOf(minAge));
		}
		if (maxAge != null) {
			instanceAgeElem.setAttribute("max", String.valueOf(maxAge));
		}
		return instanceAgeElem;
	}

	private static Element createUserElem(UserSelectionSetting userSelection,
			UserRoleSetting userRole, String userID) {
		Element userElem = new Element("user");

		if (userRole == UserRoleSetting.OWNER) {
			userElem.setAttribute("role", "owner");
		} else if (userRole == UserRoleSetting.CONTRIBUTOR) {
			userElem.setAttribute("role", "contributor");
		} else if (userRole == UserRoleSetting.NON_CONTRIBUTOR) {
			userElem.setAttribute("role", "non-contributor");
		} else {
			logger.warn("Unhandled user role setting: " + userRole);
		}

		if (userSelection == UserSelectionSetting.ONE && userID != null) {
			userElem.setAttribute("user-id", userID);
		}

		return userElem;
	}

	private static Element createConditionElem(CounterCriterionDef criterionDef) {
		Element conditionElem = new Element("condition");
		int referenceValue = criterionDef.getReferenceValue();

		CounterCriterionOperator operator = criterionDef.getOperator();
		if (operator == CounterCriterionOperator.EQUAL) {
			conditionElem.setAttribute("operator", String.valueOf("equal"));
		} else if (operator == CounterCriterionOperator.GREATER) {
			conditionElem.setAttribute("operator", String.valueOf("greater"));
		} else if (operator == CounterCriterionOperator.GREATER_OR_EQUAL) {
			conditionElem.setAttribute("operator",
					String.valueOf("greater-or-equal"));
		} else if (operator == CounterCriterionOperator.LESS) {
			conditionElem.setAttribute("operator", String.valueOf("less"));
		} else if (operator == CounterCriterionOperator.LESS_OR_EQUAL) {
			conditionElem.setAttribute("operator",
					String.valueOf("less-or-equal"));
		} else {
			logger.warn("Unhandled condition operator setting: " + operator);
		}

		conditionElem.setAttribute("ref-value", String.valueOf(referenceValue));
		return conditionElem;
	}
}
