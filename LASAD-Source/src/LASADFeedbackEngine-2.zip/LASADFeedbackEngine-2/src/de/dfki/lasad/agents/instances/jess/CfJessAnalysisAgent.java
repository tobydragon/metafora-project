package de.dfki.lasad.agents.instances.jess;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.instances.xmpp.CfAgentInterface;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.events.eue.user.join.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.user.join.UserLeaveSessionEvent;
import de.uds.cfcommunication.CfMultiSessionCommunicationManager;
import de.uds.cfcommunication.CommunicationChannelType;
import de.uds.cfcommunication.CommunicationMethodType;
import de.uds.commonformat.CfAction;
import de.uds.commonformatparser.CfActionParser;
import de.uds.translator.EueToCfActionTranslator;

public class CfJessAnalysisAgent extends JessFeedbackAgent implements CfAgentInterface {
	
	Log logger = LogFactory.getLog(this.getClass());

	CfMultiSessionCommunicationManager communicationManager;
	
	public CfJessAnalysisAgent() {
		communicationManager = CfMultiSessionCommunicationManager.getInstance(CommunicationMethodType.xmpp, CommunicationChannelType.analysis);
	}
	
	@Override
	protected void sendActionsOut(ActionSpecEvent actionSpecEvent){
		
	
		List<CfAction> indicators = EueToCfActionTranslator.translateActionSpecEventToIndicators(actionSpecEvent, model);
		for (CfAction indicator : indicators){
			logger.debug("[sendActionsOut] to send out in CF - \n" + CfActionParser.toXml(indicator).toString());
			communicationManager.sendMessage(indicator);
		}
	}

	@Override
	protected void processEvent(Event event){
		super.processEvent(event);
	}
	
	@Override
	public void processCfAction(String user, CfAction action) {
		// TODO Auto-generated method stub
		
	}

}
