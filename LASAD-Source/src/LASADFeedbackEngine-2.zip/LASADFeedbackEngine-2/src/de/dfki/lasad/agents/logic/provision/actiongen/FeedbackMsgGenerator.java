package de.dfki.lasad.agents.logic.provision.actiongen;

import java.util.List;
import java.util.Map;

import lasad.shared.dfki.meta.agents.action.ActionType;
import lasad.shared.dfki.meta.agents.action.feedback.FeedbackActionType;
import lasad.shared.dfki.meta.agents.action.feedback.MsgCompDef;
import lasad.shared.dfki.meta.agents.action.feedback.MsgCompDef_Highlighting;
import lasad.shared.dfki.meta.agents.action.feedback.MsgCompDef_LongText;
import lasad.shared.dfki.meta.agents.action.feedback.MsgCompDef_ShortText;

import de.dfki.lasad.agents.data.action.AgentAction;
import de.dfki.lasad.agents.data.action.Message;
import de.dfki.lasad.agents.data.action.MessageWithHighlighting;
import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.object.AnalyzableEntity;
import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class FeedbackMsgGenerator {

	private String parentCmpID = null;
	private SessionID sID = null;

	private NoFeedbackMsgGenerator noFeedbackMsgGenerator = null;

	public FeedbackMsgGenerator(String parentCmpID, SessionID sID) {
		this.parentCmpID = parentCmpID;
		this.sID = sID;
		this.noFeedbackMsgGenerator = new NoFeedbackMsgGenerator(parentCmpID,
				sID);
	}

	public ActionSpecEvent generateMsg(
			List<ActionTypeResult> orderedResultList, UserID recipientID) {

		ActionSpecEvent actionSpecEvent = new ActionSpecEvent(sID, parentCmpID);

		for (ActionTypeResult actionResult : orderedResultList) {

			ActionType actionType = actionResult.getActionType();

			if (actionType instanceof FeedbackActionType) {
				FeedbackActionType feedbackType = (FeedbackActionType) actionType;
				AnalysisResult analysisResult = actionResult.getResult();

				String textShort = null;
				String textLong = null;
				boolean responsePrompt = false;
				boolean highlighting = false;
				for (MsgCompDef compDef : feedbackType.getMsgCompDefs()) {

					if (compDef instanceof MsgCompDef_ShortText) {
						textShort = ((MsgCompDef_ShortText) compDef).getText();
					} else if (compDef instanceof MsgCompDef_LongText) {
						MsgCompDef_LongText msgCompLongTextDef = (MsgCompDef_LongText) compDef;
						Map<String, String> params = analysisResult
								.getProperties();
						textLong = msgCompLongTextDef
								.getTextParametersInserted(params);
						responsePrompt = msgCompLongTextDef.isResponsePrompt();
					} else if (compDef instanceof MsgCompDef_Highlighting) {
						highlighting = true;
					}
				}

				if (analysisResult instanceof ObjectResult && highlighting) {
					AnalyzableEntity entity = ((ObjectResult) analysisResult)
							.getAnalyzedEntity();
					AgentAction action = generateMsgWithHighlighting(
							recipientID, entity, textShort, textLong,
							responsePrompt);
					actionSpecEvent.addActionSpec(action);

				} else {
					AgentAction action = generateSimpleMsg(recipientID,
							textShort, textLong, responsePrompt);
					actionSpecEvent.addActionSpec(action);
				}
			}
		}
		if (actionSpecEvent.getAgentActions().size() == 0) {
			return noFeedbackMsgGenerator.generateMsgEvent(recipientID);
		} else {
			return actionSpecEvent;
		}
	}

	private AgentAction generateSimpleMsg(UserID recipient, String textShort,
			String textLong, boolean responsePrompt) {
		AgentAction componentSpec = new AgentAction();
		componentSpec.setActionRecipient(recipient);
		Message message;
		if (textLong != null) {
			message = new Message(textShort, textLong);
			message.setResponsePrompt(responsePrompt);
		} else {
			message = new Message(textShort);
		}
		componentSpec.addActionComponent(message);
		return componentSpec;
	}

	private AgentAction generateMsgWithHighlighting(UserID recipient,
			AnalyzableEntity entity, String textShort, String textLong,
			boolean responsePrompt) {
		AgentAction componentSpec = new AgentAction();
		componentSpec.setActionRecipient(recipient);
		MessageWithHighlighting highlighting;
		if (textLong != null) {
			highlighting = new MessageWithHighlighting(textShort, textLong,
					entity);
			highlighting.setResponsePrompt(responsePrompt);
		} else {
			highlighting = new MessageWithHighlighting(textShort, entity);
		}
		componentSpec.addActionComponent(highlighting);
		return componentSpec;
	}
}
