package de.dfki.lasad.agents.logic.analysis.aggr;

import lasad.shared.dfki.meta.agents.analysis.counter.CounterAnalysisType;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class UserCounterAnalysisType {

	CounterAnalysisType analysisType;
	UserID userID;

	public UserCounterAnalysisType(CounterAnalysisType analysisType, UserID userID) {
		this.analysisType = analysisType;
		this.userID = userID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((analysisType == null) ? 0 : analysisType.hashCode());
		result = prime * result + ((userID == null) ? 0 : userID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserCounterAnalysisType other = (UserCounterAnalysisType) obj;
		if (analysisType == null) {
			if (other.analysisType != null)
				return false;
		} else if (!analysisType.equals(other.analysisType))
			return false;
		if (userID == null) {
			if (other.userID != null)
				return false;
		} else if (!userID.equals(other.userID))
			return false;
		return true;
	}

}
