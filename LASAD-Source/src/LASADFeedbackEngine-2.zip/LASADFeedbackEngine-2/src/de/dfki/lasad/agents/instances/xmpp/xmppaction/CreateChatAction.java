package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import java.util.Vector;

import lasad.shared.communication.objects.Action;

import org.apache.log4j.Logger;


import de.dfki.lasad.dataservice.lasad.LasadActionFactory;
import de.dfki.lasad.events.eue.admin.session.ManagementResponseEvent;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;

public class CreateChatAction extends CfManagementAction{

	Logger logger = Logger.getLogger(this.getClass());
	
	public CreateChatAction(CfAction cfAction) {
		super(cfAction);
	}

	@Override
	public Vector<Action> buildLasadActions() {
		Vector<Action> actions = new Vector<Action>();
		
		CfObject messageObject = cfAction.getCfObjects().get(0);
		String mapId = messageObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING);
		String username = messageObject.getPropertyValue("username");
		String message = messageObject.getPropertyValue("text");
		
		String messageText = username;
//		String [] users = username.split("|");
//		for (String user : users){
//			messageText += user + ", ";
//		}
//		if (messageText.length() > 2){
//			messageText = messageText.substring(0, messageText.length()-2);
//		}
		messageText += ": " + message;
		actions.add(LasadActionFactory.createChat(mapId, messageText));
			
		return actions;
	}

	@Override
	public boolean eventIsResponseToMe(ManagementResponseEvent mEvent) {
		return false;
	}

}
