package de.dfki.lasad.session.data.objects;


public class EmptyID extends EUEObjectID {

	public EmptyID() {
		super("");
	}
}
