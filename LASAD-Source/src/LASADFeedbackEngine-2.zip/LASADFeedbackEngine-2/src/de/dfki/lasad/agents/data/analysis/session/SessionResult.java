package de.dfki.lasad.agents.data.analysis.session;

import lasad.shared.dfki.meta.agents.analysis.AnalysisType;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class SessionResult extends AnalysisResult {

	public SessionResult(AnalysisType analysisType) {
		super(analysisType);
	}

	@Override
	public String toString() {
		return "SessionResult [getAnalysisType()=" + getAnalysisType()
				+ ", getValueAsString()=" + getValueAsString()
				+ ", getProperties()=" + getProperties() + ", getId()="
				+ getId() + ", getDetectionTs()=" + getDetectionTs()
				+ ", toString()=" + super.toString() + ", hashCode()="
				+ hashCode() + ", getClass()=" + getClass() + "]";
	}

}
