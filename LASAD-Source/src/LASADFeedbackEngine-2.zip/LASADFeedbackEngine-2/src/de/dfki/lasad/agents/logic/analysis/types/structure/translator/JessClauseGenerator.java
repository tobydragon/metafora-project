package de.dfki.lasad.agents.logic.analysis.types.structure.translator;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts.ConstFactGen;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts.ElemFactBindListElemGen;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts.ElemFactGen;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts.NeighborFactGen;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts.PropFactGen;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ComparisonType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableSuppl;
import lasad.shared.dfki.meta.agents.analysis.structure.model.LinkVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.NodeVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import lasad.shared.dfki.meta.agents.analysis.structure.model.VariableComparison;
import lasad.shared.dfki.meta.ontology.Ontology;
import lasad.shared.dfki.meta.ontology.descr.LastTsPropDescr;
import lasad.shared.dfki.meta.ontology.descr.ModifiersPropDescr;
import lasad.shared.dfki.meta.ontology.descr.NonStandardPropDescr;
import lasad.shared.dfki.meta.ontology.descr.PropDescr;
import lasad.shared.dfki.meta.ontology.descr.StandardPropDescr;

/**
 * Generates Jess clauses to match nodes, links or node / link properties. The
 * generation of these clauses is based on a pre-classification of
 * {@link Comparison}s in 20 different {@link Bin}s each of which leading to a
 * different Jess expression. Details, see external documentation.
 * 
 * @author oliverscheuer
 * 
 */
public class JessClauseGenerator {

	static final int NO_VAR_APPENDIX = -1;
	static final boolean TEMP_ELEM_VAR = true;
	static final boolean TEMP_VAR_LEFT = true;
	static final boolean TEMP_VAR_RIGHT = true;

	private Ontology ontology = null;
	private JessIDAndSlotNameGenerator idGen = null;
	private JessQuantifierGenerator qGen = null;

	private Map<ElementVariableProp, List<Comparison>> NO_PROP_SLOTS = new HashMap<ElementVariableProp, List<Comparison>>();

	public JessClauseGenerator(Ontology ontology,
			JessIDAndSlotNameGenerator idGen) {
		this.ontology = ontology;
		this.idGen = idGen;
		qGen = new JessQuantifierGenerator(ontology);
	}

	// BIN 1 - Part A
	public String generateNodeExtConstrsClause(NodeVariable nodeVar,
			List<? extends ElementVariable> predecessors,
			boolean bindLastTsAndModifiers) {

		Map<ElementVariableProp, List<Comparison>> relevantElemProps2Comparisons = getRelevantElemProps2Comparisons(
				ontology, nodeVar, Bin.BIN_1, ComparisonType.EXTERNAL, true,
				false);

		if (bindLastTsAndModifiers) {
			ElementVariableProp lastTsPropVar = nodeVar.getPropVar(
					LastTsPropDescr.PROP_ID,
					StandardPropDescr.DEFAULT_COMPONENT_ID);
			if (!relevantElemProps2Comparisons.containsKey(lastTsPropVar)) {
				relevantElemProps2Comparisons.put(lastTsPropVar,
						new Vector<Comparison>());
			}

			ElementVariableProp modifiersPropVar = nodeVar.getPropVar(
					ModifiersPropDescr.PROP_ID,
					StandardPropDescr.DEFAULT_COMPONENT_ID);
			if (!relevantElemProps2Comparisons.containsKey(modifiersPropVar)) {
				relevantElemProps2Comparisons.put(modifiersPropVar,
						new Vector<Comparison>());
			}
		}

		ElemFactGen elemGen = new ElemFactGen(idGen, ontology, nodeVar,
				relevantElemProps2Comparisons, Bin.BIN_1, predecessors);

		String clause = elemGen.getString();
		return clause;
	}

	public String generateLinkExtConstrsClause(LinkVariable linkVar,
			List<? extends ElementVariable> predecessors,
			boolean bindLastTsAndModifiers) {
		Map<ElementVariableProp, List<Comparison>> relevantElemProps2Comparisons = getRelevantElemProps2Comparisons(
				ontology, linkVar, Bin.BIN_1, ComparisonType.EXTERNAL, true,
				false);

		if (bindLastTsAndModifiers) {
			ElementVariableProp lastTsPropVar = linkVar.getPropVar(
					LastTsPropDescr.PROP_ID,
					StandardPropDescr.DEFAULT_COMPONENT_ID);
			if (!relevantElemProps2Comparisons.containsKey(lastTsPropVar)) {
				relevantElemProps2Comparisons.put(lastTsPropVar,
						new Vector<Comparison>());
			}

			ElementVariableProp modifiersPropVar = linkVar.getPropVar(
					ModifiersPropDescr.PROP_ID,
					StandardPropDescr.DEFAULT_COMPONENT_ID);
			if (!relevantElemProps2Comparisons.containsKey(modifiersPropVar)) {
				relevantElemProps2Comparisons.put(modifiersPropVar,
						new Vector<Comparison>());
			}
		}
		ElemFactGen elemGen;

		if (linkVar.getSource() != null && linkVar.getTarget() != null) {
			// source and target will be handled in neighborhood constraint and
			// can be omitted here (in fact, including them may lead to errors
			// for links for which direction does not matter).
			elemGen = new ElemFactGen(idGen, ontology, linkVar,
					relevantElemProps2Comparisons, Bin.BIN_1, predecessors,
					true, true);
		} else {
			elemGen = new ElemFactGen(idGen, ontology, linkVar,
					relevantElemProps2Comparisons, Bin.BIN_1, predecessors);
		}
		String clause = elemGen.getString();
		return clause;
	}

	// Prop Bindings needed in Comparisons of later ElemConstrs
	public String generatePropVarBindingClauses(ElementVariable elemVar) {
		List<PropDescr> props = elemVar.getSupplData().getPropsUsedAsRefVal();
		StringBuffer buf = new StringBuffer();
		List<String> clauses = new Vector<String>();
		for (PropDescr prop : props) {
			if (prop instanceof NonStandardPropDescr
					&& ((NonStandardPropDescr) prop).getMaxCardinality() <= 1) {
				List<String> componentIDs = elemVar.getSupplData()
						.getPropComponentsUsedAsRefVal(prop);
				Map<ElementVariableProp, List<Comparison>> propVars2Comparisons = new HashMap<ElementVariableProp, List<Comparison>>();
				for (String compID : componentIDs) {
					ElementVariableProp propVar = elemVar.getPropVar(
							prop.getPropID(), compID);
					List<Comparison> noComparisons = new Vector<Comparison>();
					propVars2Comparisons.put(propVar, noComparisons);
				}

				PropFactGen propFactGen = new PropFactGen(idGen, ontology,
						elemVar, prop, propVars2Comparisons, Bin.ALL_BINS,
						NO_VAR_APPENDIX, false, false, false);

				String clause = propFactGen.getString();
				clauses.add(clause);
			}
		}
		addClauses(buf, clauses);
		return buf.toString();
	}

	public String generateNeighborhoodConstrs(ElementVariable elemVar) {
		StringBuffer buf = new StringBuffer();
		ElementVariableSuppl supplData = elemVar.getSupplData();

		Iterator<LinkVariable> directedIter = supplData.getNeighborConstrs()
				.getDirectedLinkConstraintsToAdd().iterator();
		Iterator<LinkVariable> undirectedIter = supplData.getNeighborConstrs()
				.getUndirectedLinkConstraintsToAdd().iterator();
		while (directedIter.hasNext()) {
			LinkVariable dirLinkConstr = directedIter.next();
			Map<ElementVariableProp, List<Comparison>> NO_COMPARISONS = new HashMap<ElementVariableProp, List<Comparison>>();
			ElemFactGen elemGen = new ElemFactGen(idGen, ontology,
					dirLinkConstr, NO_COMPARISONS, Bin.BIN_1,
					new Vector<ElementVariable>());
			String dirLinkConstrString = elemGen.getString();
			buf.append(dirLinkConstrString);
			if (directedIter.hasNext() || undirectedIter.hasNext()) {
				buf.append("\n");
			}
		}

		while (undirectedIter.hasNext()) {
			LinkVariable undirLinkConstr = undirectedIter.next();
			NeighborFactGen neighborGen = new NeighborFactGen(idGen,
					undirLinkConstr);
			String undirLinkConstrString = neighborGen.getString();
			buf.append(undirLinkConstrString);
			if (undirectedIter.hasNext()) {
				buf.append("\n");
			}
		}
		return buf.toString();
	}

	// BIN 1 - Part B
	public String generateNodeIntConstrsClause(NodeVariable nodeVar) {
		List<NodeVariable> NO_PREDECESSORS = new Vector<NodeVariable>();

		Map<ElementVariableProp, List<Comparison>> relevantElemProps2Comparisons = getRelevantElemProps2Comparisons(
				ontology, nodeVar, Bin.BIN_1, ComparisonType.INTERNAL, false,
				true);
		ElemFactGen elemGen = new ElemFactGen(idGen, ontology, nodeVar,
				relevantElemProps2Comparisons, Bin.BIN_1, NO_PREDECESSORS);
		if (elemGen.getNumConstrainedSlots() == 0) {
			return "";
		}
		String clause = elemGen.getString();
		return clause;
	}

	public String generateLinkIntConstrsClause(LinkVariable linkVar) {
		List<LinkVariable> NO_PREDECESSORS = new Vector<LinkVariable>();

		Map<ElementVariableProp, List<Comparison>> relevantElemProps2Comparisons = getRelevantElemProps2Comparisons(
				ontology, linkVar, Bin.BIN_1, ComparisonType.INTERNAL, false,
				true);
		ElemFactGen elemGen = new ElemFactGen(idGen, ontology, linkVar,
				relevantElemProps2Comparisons, Bin.BIN_1, NO_PREDECESSORS,
				true, true);
		if (elemGen.getNumConstrainedSlots() == 0) {
			return "";
		}
		String clause = elemGen.getString();
		return clause;
	}

	// BIN 2
	public String generatePropClauses(ElementVariable elemVar, PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<String> compIDs = prop.getComponentIDs();
		Map<ElementVariableProp, List<Comparison>> propVar2Comparisons = new HashMap<ElementVariableProp, List<Comparison>>();
		for (String compID : compIDs) {
			ElementVariableProp propVar = elemVar.getPropVar(prop.getPropID(),
					compID);
			List<Comparison> comparisons = elemVar.getSupplData()
					.getComparisons(Bin.BIN_2, propVar);
			if (!comparisons.isEmpty()) {
				propVar2Comparisons.put(propVar, comparisons);
			}
		}
		if (!propVar2Comparisons.isEmpty()) {

			PropFactGen propFactGen = new PropFactGen(idGen, ontology, elemVar,
					prop, propVar2Comparisons, Bin.BIN_2, NO_VAR_APPENDIX,
					false, false, false);

			String clause = propFactGen.getString();
			buf.append(clause);
		}
		return getString(elemVar, prop, buf, Bin.BIN_2);

	}

	// BIN 3
	public String generatePropExistsClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();

		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_3, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {

			PropFactGen propFactGen = new PropFactGen(idGen, ontology,
					comparison, Bin.BIN_3, comparison.getSupplData().getId(),
					false, TEMP_VAR_LEFT, false);

			String propFactExpr = propFactGen.getString();

			String clause = qGen.generateExistsConstr(propFactExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_3);
	}

	// BIN 4
	public String generatePropForallClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_4, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {

			PropFactGen propFactMatchExprGen = new PropFactGen(idGen, ontology,
					elemVar, prop, NO_PROP_SLOTS, Bin.BIN_4, comparison
							.getSupplData().getId(), TEMP_ELEM_VAR, false,
					false);
			String propFactMatchExpr = propFactMatchExprGen.getString();

			PropFactGen forallFactConstrExprGen = new PropFactGen(idGen,
					ontology, comparison, Bin.BIN_4, comparison.getSupplData()
							.getId(), TEMP_ELEM_VAR, TEMP_VAR_LEFT, false);
			String forallFactConstrExpr = forallFactConstrExprGen.getString();
			String clause = qGen.generateForallConstr(propFactMatchExpr,
					forallFactConstrExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_4);
	}

	// BIN 5
	public String generateRefPropExistsClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_5, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);

			PropFactGen propFactGen = new PropFactGen(idGen, ontology,
					inv.comparison, Bin.BIN_5, comparison.getSupplData()
							.getId(), false, TEMP_VAR_LEFT, false);

			String propFactExpr = propFactGen.getString();

			String clause = qGen.generateExistsConstr(propFactExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_5);
	}

	// BIN 6
	public String generateRefPropForallClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_6, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);

			PropFactGen propFactMatchExprGen = new PropFactGen(idGen, ontology,
					inv.elemVar, inv.prop, NO_PROP_SLOTS, Bin.BIN_6, comparison
							.getSupplData().getId(), TEMP_ELEM_VAR, false,
					false);
			String propFactMatchExpr = propFactMatchExprGen.getString();

			PropFactGen propFactConstrExprGen = new PropFactGen(idGen,
					ontology, inv.comparison, Bin.BIN_6, comparison
							.getSupplData().getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, false);
			String propFactConstrExpr = propFactConstrExprGen.getString();

			String clause = qGen.generateForallConstr(propFactMatchExpr,
					propFactConstrExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_6);
	}

	// BIN 7
	public String generatePropExistsForallClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_7, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {

			Map<ElementVariableProp, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(comparison
					.getLeftExpr());

			PropFactGen existsFactExprGen = new PropFactGen(idGen, ontology,
					elemVar, prop, propVarWithoutComparisons, Bin.BIN_7,
					comparison.getSupplData().getId(), false, TEMP_VAR_LEFT,
					false);
			String existsFactExpr = existsFactExprGen.getString();

			InverseCompRecord inv = new InverseCompRecord(comparison);
			PropFactGen forallFactMatchExprGen = new PropFactGen(idGen,
					ontology, inv.elemVar, inv.prop, NO_PROP_SLOTS, Bin.BIN_7,
					comparison.getSupplData().getId(), TEMP_ELEM_VAR, false,
					false);
			String forallFactMatchExpr = forallFactMatchExprGen.getString();

			PropFactGen forallFactConstrExprGen = new PropFactGen(idGen,
					ontology, inv.comparison, Bin.BIN_7, comparison
							.getSupplData().getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String forallFactConstrExpr = forallFactConstrExprGen.getString();

			String clause = qGen.generateExistsForallConstr(existsFactExpr,
					forallFactMatchExpr, forallFactConstrExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_7);
	}

	// BIN 8
	public String generatePropExistsExistsClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_8, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			Map<ElementVariableProp, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(comparison
					.getLeftExpr());

			PropFactGen existsFactExpr1Gen = new PropFactGen(idGen, ontology,
					elemVar, prop, propVarWithoutComparisons, Bin.BIN_8,
					comparison.getSupplData().getId(), false, TEMP_VAR_LEFT,
					false);
			String existsFactExpr1 = existsFactExpr1Gen.getString();

			InverseCompRecord inv = new InverseCompRecord(comparison);
			PropFactGen existsFactExpr2Gen = new PropFactGen(idGen, ontology,
					inv.comparison, Bin.BIN_8, comparison.getSupplData()
							.getId(), false, TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String existsFactExpr2 = existsFactExpr2Gen.getString();

			String clause = qGen.generateExistsExistsConstr(existsFactExpr1,
					existsFactExpr2);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_8);
	}

	// BIN 9
	public String generatePropForallForallClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_9, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			Map<ElementVariableProp, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(comparison
					.getLeftExpr());

			PropFactGen propFactMatchExprVarBinding1Gen = new PropFactGen(
					idGen, ontology, elemVar, prop, propVarWithoutComparisons,
					Bin.BIN_9, comparison.getSupplData().getId(), false,
					TEMP_VAR_LEFT, false);

			String propFactMatchExprVarBinding1 = propFactMatchExprVarBinding1Gen
					.getString();

			InverseCompRecord inv = new InverseCompRecord(comparison);
			PropFactGen propFactMatchExpr2Gen = new PropFactGen(idGen,
					ontology, inv.elemVar, inv.prop, NO_PROP_SLOTS, Bin.BIN_9,
					comparison.getSupplData().getId(), TEMP_ELEM_VAR, false,
					false);
			String propFactMatchExpr2 = propFactMatchExpr2Gen.getString();

			PropFactGen propFactConstrExpr2Gen = new PropFactGen(idGen,
					ontology, inv.comparison, Bin.BIN_9, comparison
							.getSupplData().getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String propFactConstrExpr2 = propFactConstrExpr2Gen.getString();

			String clause = qGen.generateForallForallConstr(
					propFactMatchExprVarBinding1, propFactMatchExpr2,
					propFactConstrExpr2);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_9);
	}

	// BIN 10
	public String generatePropForallExistsClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_10, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			Map<ElementVariableProp, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(comparison
					.getLeftExpr());

			PropFactGen propFactMatchExprVarBindingGen = new PropFactGen(idGen,
					ontology, elemVar, prop, propVarWithoutComparisons,
					Bin.BIN_10, comparison.getSupplData().getId(), false,
					TEMP_VAR_LEFT, false);
			String propFactMatchExprVarBinding = propFactMatchExprVarBindingGen
					.getString();

			InverseCompRecord inv = new InverseCompRecord(comparison);
			PropFactGen existsFactExprGen = new PropFactGen(idGen, ontology,
					inv.comparison, Bin.BIN_10, comparison.getSupplData()
							.getId(), false, TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String existsFactExpr = existsFactExprGen.getString();

			String clause = qGen.generateForallExistsConstr(
					propFactMatchExprVarBinding, existsFactExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_10);
	}

	// BIN 11
	public String generateRefPropExistsForallClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_11, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);
			Map<ElementVariableProp, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(inv.comparison
					.getLeftExpr());
			PropFactGen existsFactExprGen = new PropFactGen(idGen, ontology,
					inv.elemVar, inv.prop, propVarWithoutComparisons,
					Bin.BIN_11, comparison.getSupplData().getId(), false,
					TEMP_VAR_LEFT, false);
			String existsFactExpr = existsFactExprGen.getString();

			PropFactGen forallFactMatchExprGen = new PropFactGen(idGen,
					ontology, elemVar, prop, NO_PROP_SLOTS, Bin.BIN_11,
					comparison.getSupplData().getId(), TEMP_ELEM_VAR, false,
					false);
			String forallFactMatchExpr = forallFactMatchExprGen.getString();

			PropFactGen forallFactConstrExprGen = new PropFactGen(idGen,
					ontology, comparison, Bin.BIN_11, comparison.getSupplData()
							.getId(), TEMP_ELEM_VAR, TEMP_VAR_LEFT,
					TEMP_VAR_RIGHT);
			String forallFactConstrExpr = forallFactConstrExprGen.getString();

			String clause = qGen.generateExistsForallConstr(existsFactExpr,
					forallFactMatchExpr, forallFactConstrExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_11);
	}

	// BIN 12
	public String generateRefPropForallExistsClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_12, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);
			Map<ElementVariableProp, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(inv.comparison
					.getLeftExpr());

			PropFactGen propFactMatchExprVarBindingGen = new PropFactGen(idGen,
					ontology, inv.elemVar, inv.prop, propVarWithoutComparisons,
					Bin.BIN_12, comparison.getSupplData().getId(), false,
					TEMP_VAR_LEFT, false);

			String propFactMatchExprVarBinding = propFactMatchExprVarBindingGen
					.getString();

			PropFactGen existsFactExprGen = new PropFactGen(idGen, ontology,
					comparison, Bin.BIN_12, comparison.getSupplData().getId(),
					false, TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String existsFactExpr = existsFactExprGen.getString();

			String clause = qGen.generateForallExistsConstr(
					propFactMatchExprVarBinding, existsFactExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_12);
	}

	// BIN 13
	public String generateElemExistsForallClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_13, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {

			ElemFactBindListElemGen existsFactExprGen = new ElemFactBindListElemGen(
					ontology, idGen, comparison);
			String existsFactExpr = existsFactExprGen.getString();

			InverseCompRecord inv = new InverseCompRecord(comparison);
			PropFactGen forallFactMatchExprGen = new PropFactGen(idGen,
					ontology, inv.elemVar, inv.prop, NO_PROP_SLOTS, Bin.BIN_13,
					comparison.getSupplData().getId(), TEMP_ELEM_VAR, false,
					false);
			String forallFactMatchExpr = forallFactMatchExprGen.getString();

			PropFactGen forallFactConstrExprGen = new PropFactGen(idGen,
					ontology, inv.comparison, Bin.BIN_13, comparison
							.getSupplData().getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String forallFactConstrExpr = forallFactConstrExprGen.getString();

			String clause = qGen.generateExistsForallConstr(existsFactExpr,
					forallFactMatchExpr, forallFactConstrExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_13);
	}

	// BIN 14
	public String generateElemExistsExistsClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_14, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			ElemFactBindListElemGen existsFactExpr1Gen = new ElemFactBindListElemGen(
					ontology, idGen, comparison);
			String existsFactExpr1 = existsFactExpr1Gen.getString();

			InverseCompRecord inv = new InverseCompRecord(comparison);
			PropFactGen existsFactExpr2Gen = new PropFactGen(idGen, ontology,
					inv.comparison, Bin.BIN_14, comparison.getSupplData()
							.getId(), false, TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String existsFactExpr2 = existsFactExpr2Gen.getString();

			String clause = qGen.generateExistsExistsConstr(existsFactExpr1,
					existsFactExpr2);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_14);
	}

	// BIN 15
	public String generateElemForallForallClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_15, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			ElemFactBindListElemGen propFactMatchExprVarBinding1Gen = new ElemFactBindListElemGen(
					ontology, idGen, comparison);
			String propFactMatchExprVarBinding1 = propFactMatchExprVarBinding1Gen
					.getString();

			InverseCompRecord inv = new InverseCompRecord(comparison);
			PropFactGen propFactMatchExpr2Gen = new PropFactGen(idGen,
					ontology, inv.elemVar, inv.prop, NO_PROP_SLOTS, Bin.BIN_15,
					comparison.getSupplData().getId(), TEMP_ELEM_VAR, false,
					false);
			String propFactMatchExpr2 = propFactMatchExpr2Gen.getString();

			PropFactGen propFactConstrExpr2Gen = new PropFactGen(idGen,
					ontology, inv.comparison, Bin.BIN_15, comparison
							.getSupplData().getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String propFactConstrExpr2 = propFactConstrExpr2Gen.getString();

			String clause = qGen.generateForallForallConstr(
					propFactMatchExprVarBinding1, propFactMatchExpr2,
					propFactConstrExpr2);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_15);
	}

	// BIN 16
	public String generateElemForallExistsClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_16, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			ElemFactBindListElemGen propFactMatchExprVarBindingGen = new ElemFactBindListElemGen(
					ontology, idGen, comparison);
			String propFactMatchExprVarBinding = propFactMatchExprVarBindingGen
					.getString();

			InverseCompRecord inv = new InverseCompRecord(comparison);
			PropFactGen existsFactExprGen = new PropFactGen(idGen, ontology,
					inv.comparison, Bin.BIN_16, comparison.getSupplData()
							.getId(), false, TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String existsFactExpr = existsFactExprGen.getString();

			String clause = qGen.generateForallExistsConstr(
					propFactMatchExprVarBinding, existsFactExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_16);
	}

	// BIN 17
	public String generateRefElemExistsForallClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_17, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);
			ElemFactBindListElemGen existsFactExprGen = new ElemFactBindListElemGen(
					ontology, idGen, inv.comparison);
			String existsFactExpr = existsFactExprGen.getString();

			PropFactGen forallFactMatchExprGen = new PropFactGen(idGen,
					ontology, elemVar, prop, NO_PROP_SLOTS, Bin.BIN_17,
					comparison.getSupplData().getId(), TEMP_ELEM_VAR, false,
					false);
			String forallFactMatchExpr = forallFactMatchExprGen.getString();

			PropFactGen forallFactConstrExprGen = new PropFactGen(idGen,
					ontology, comparison, Bin.BIN_17, comparison.getSupplData()
							.getId(), TEMP_ELEM_VAR, TEMP_VAR_LEFT,
					TEMP_VAR_RIGHT);
			String forallFactConstrExpr = forallFactConstrExprGen.getString();

			String clause = qGen.generateExistsForallConstr(existsFactExpr,
					forallFactMatchExpr, forallFactConstrExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_17);
	}

	// BIN 18
	public String generateRefElemForallExistsClauses(ElementVariable elemVar,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_18, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);
			ElemFactBindListElemGen propFactMatchExprVarBindingGen = new ElemFactBindListElemGen(
					ontology, idGen, inv.comparison);
			String propFactMatchExprVarBinding = propFactMatchExprVarBindingGen
					.getString();

			PropFactGen existsFactExprGen = new PropFactGen(idGen, ontology,
					comparison, Bin.BIN_18, comparison.getSupplData().getId(),
					false, TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String existsFactExpr = existsFactExprGen.getString();

			String clause = qGen.generateForallExistsConstr(
					propFactMatchExprVarBinding, existsFactExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_18);
	}

	// BIN 19
	public String generateRefConstForallExistsClauses(String agentID,
			StructuralPattern pattern, ElementVariable elemVar, PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_19, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {

			ConstFactGen nodeFactMatchExprVarBindingGen = new ConstFactGen(
					idGen, agentID, pattern.getID(), comparison.getSupplData()
							.getId());

			String nodeFactMatchExprVarBinding = nodeFactMatchExprVarBindingGen
					.getString();

			PropFactGen existsFactExprGen = new PropFactGen(idGen, ontology,
					comparison, Bin.BIN_19, comparison.getSupplData().getId(),
					false, TEMP_VAR_LEFT, TEMP_VAR_RIGHT);
			String existsFactExpr = existsFactExprGen.getString();

			String clause = qGen.generateForallExistsConstr(
					nodeFactMatchExprVarBinding, existsFactExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_19);
	}

	// BIN 20
	public String generateRefConstExistsForallClauses(String agentID,
			StructuralPattern pattern, ElementVariable elemVar, PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemVar.getSupplData().getComparisons(
				elemVar, Bin.BIN_20, prop);
		List<String> clauses = new Vector<String>();
		for (Comparison comparison : comparisons) {

			ConstFactGen existsFactExprGen = new ConstFactGen(idGen, agentID,
					pattern.getID(), comparison.getSupplData().getId());
			String existsFactExpr = existsFactExprGen.getString();

			PropFactGen forallFactMatchExprGen = new PropFactGen(idGen,
					ontology, elemVar, prop, NO_PROP_SLOTS, Bin.BIN_20,
					comparison.getSupplData().getId(), TEMP_ELEM_VAR, false,
					false);
			String forallFactMatchExpr = forallFactMatchExprGen.getString();

			PropFactGen forallFactConstrExprGen = new PropFactGen(idGen,
					ontology, comparison, Bin.BIN_20, comparison.getSupplData()
							.getId(), TEMP_ELEM_VAR, TEMP_VAR_LEFT,
					TEMP_VAR_RIGHT);
			String forallFactConstrExpr = forallFactConstrExprGen.getString();

			String clause = qGen.generateExistsForallConstr(existsFactExpr,
					forallFactMatchExpr, forallFactConstrExpr);
			clauses.add(clause);
		}
		addClauses(buf, clauses);
		return getString(elemVar, prop, buf, Bin.BIN_20);
	}

	private void addClauses(StringBuffer aggregator, List<String> clauses) {
		Iterator<String> iter = clauses.iterator();
		while (iter.hasNext()) {
			String propFact = iter.next();
			aggregator.append(propFact);
			if (iter.hasNext()) {
				aggregator.append("\n");
			}
		}
	}

	private Map<ElementVariableProp, List<Comparison>> getMapPropVarWithoutComparisons(
			ElementVariableProp propVar) {
		Map<ElementVariableProp, List<Comparison>> propVarWithoutComparisons = new HashMap<ElementVariableProp, List<Comparison>>();
		List<Comparison> noComparisons = new Vector<Comparison>();
		propVarWithoutComparisons.put(propVar, noComparisons);
		return propVarWithoutComparisons;
	}

	private class InverseCompRecord {

		VariableComparison comparison;
		ElementVariable elemVar;
		ElementVariableProp propVar;
		PropDescr prop;

		public InverseCompRecord(Comparison comparison) {
			VariableComparison varComp = (VariableComparison) comparison;
			this.comparison = varComp.getInverse();
			this.propVar = this.comparison.getLeftExpr();
			this.prop = propVar.getPropDescr(ontology);
			this.elemVar = propVar.getElementVar();
		}
	}

	private String getString(ElementVariable elemVar, PropDescr prop,
			StringBuffer buf, Bin binID) {
		if (buf.length() > 0) {
			String preface = ";; " + elemVar.getVarID() + "//"
					+ prop.getPropID() + ": BIN-" + binID.getNum() + "\n";
			return preface + buf.toString();
		}
		return buf.toString();
	}

	private Map<ElementVariableProp, List<Comparison>> getRelevantElemProps2Comparisons(
			Ontology ontology, ElementVariable elemVar, Bin bin,
			ComparisonType typeSelector,
			boolean propMustBeReferencedOrConstrained,
			boolean propMustBeConstrained) {

		Map<ElementVariableProp, List<Comparison>> relevantElemProps2Comparisons = new HashMap<ElementVariableProp, List<Comparison>>();

		List<PropDescr> props = elemVar.getPropDescrs(ontology);
		List<PropDescr> referencedProps = elemVar.getSupplData()
				.getPropsUsedAsRefVal();

		for (Iterator<PropDescr> iter = props.iterator(); iter.hasNext();) {
			PropDescr prop = iter.next();
			if (prop.isInJessElementFact()) {
				List<Comparison> relevantComparisons = new Vector<Comparison>();
				ElementVariableProp propVar = elemVar.getPropVar(
						prop.getPropID(), PropDescr.DEFAULT_COMPONENT_ID);

				List<Comparison> allComparisons = elemVar.getSupplData()
						.getComparisons(bin, propVar);

				for (Comparison c : allComparisons) {
					ComparisonType compType = c.getSupplData().getType();
					if (ComparisonType.ALL.equals(typeSelector)
							|| typeSelector.equals(compType)) {
						// relevant
						relevantComparisons.add(c);
					}
				}

				boolean constrained = !relevantComparisons.isEmpty();
				boolean referenced = referencedProps.contains(prop);

				if (propMustBeConstrained) {
					if (constrained) {
						relevantElemProps2Comparisons.put(propVar,
								relevantComparisons);
					}
				} else if (propMustBeReferencedOrConstrained) {
					if (referenced || constrained) {
						relevantElemProps2Comparisons.put(propVar,
								relevantComparisons);
					}
				} else {
					relevantElemProps2Comparisons.put(propVar,
							relevantComparisons);
				}
			}

		}
		return relevantElemProps2Comparisons;
	}

}
