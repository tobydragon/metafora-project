package de.dfki.lasad.events.eue.user;

import de.dfki.lasad.events.eue.EUEEventID;
import de.dfki.lasad.events.eue.EUESessionEvent;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.uds.xml.XmlFragment;
import de.uds.xml.XmlFragmentInterface;

/**
 * Event associated with some activity of a user within an EUE session
 * 
 * @author Oliver Scheuer
 * 
 */
public class UserEvent extends EUESessionEvent {

	protected UserID userID;

	public UserEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID) {
		super(sessionID, srcCompId, eueEventID);
	}

	public UserEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID) {
		super(sessionID, srcCompId, eueEventID);
		this.userID = userID;
	}

	public void setUserID(UserID userID) {
		this.userID = userID;
	}

	public UserID getUserID() {
		return userID;
	}

	@Override
	public String toString() {
		return super.toString() + ", userID=" + userID + "";
	}
	

	public XmlFragmentInterface toXml(){

		XmlFragmentInterface element = new XmlFragment("UserEvent");
		element.setAttribute("userActionEventType", getUserEventType());
		element.setAttribute("sourceComponentId", sourceComponentID);
		element.addContent(userID.toXml());
		element.addContent(sessionID.toXml());
		element.addContent(eueEventID.toXml());
		
		return element;	

	}
	
	public String getUserEventType(){
		return getClass().getSimpleName();
	}

}
