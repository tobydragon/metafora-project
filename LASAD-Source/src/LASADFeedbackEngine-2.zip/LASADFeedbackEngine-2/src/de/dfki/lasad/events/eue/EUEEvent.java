package de.dfki.lasad.events.eue;

import de.dfki.lasad.events.Event;

/**
 * Marker interface.
 * @author Oliver Scheuer
 *
 */
public interface EUEEvent extends Event{

	public long getTs();

	public void setTs(long ts);
	
}
