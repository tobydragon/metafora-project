package de.dfki.lasad.session.data.meta.ontology.base;

import de.dfki.lasad.session.data.meta.ontology.ComparisonGroup;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * 
 * @author oliverscheuer
 *
 */
public class FrameType extends BaseType {

	private static FrameType instance = new FrameType();
	
	private FrameType(){
		super();
		lasadElementType = "frame";
		jessTemplateName = "elem_frame";
		addComponentSpecification(PropDescr.DEFAULT_COMPONENT_ID, "LINK", JessDataType.STRING, ComparisonGroup.NONE);
	}
	
	public static FrameType getInstance(){
		return instance;
	}
}
