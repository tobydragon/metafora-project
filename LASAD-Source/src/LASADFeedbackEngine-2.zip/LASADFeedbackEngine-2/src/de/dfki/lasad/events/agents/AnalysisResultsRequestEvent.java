package de.dfki.lasad.events.agents;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.instances.action.UserServiceID;
import de.dfki.lasad.events.EventCallback;
import de.dfki.lasad.events.EventImpl;

/**
 * Request {@link AnalysisResult}s for a given set of {@link AnalysisType}s.
 * Feedback-Engine internal communication.
 * 
 * @author oliverscheuer
 * 
 */
public class AnalysisResultsRequestEvent extends EventImpl {

	private Set<AnalysisType> analysisTypes = new HashSet<AnalysisType>();

	private UUID transactionID = UUID.randomUUID();
	private UserServiceID userServiceID = null;

	private EventCallback callback = null;

	public AnalysisResultsRequestEvent(String srcCompId) {
		super(srcCompId);
	}

	public Set<AnalysisType> getAnalysisTypes() {
		return analysisTypes;
	}

	public void setAnalysisTypes(Set<AnalysisType> analysisTypes) {
		this.analysisTypes = analysisTypes;
	}

	public void addAnalysisType(AnalysisType analysisType) {
		analysisTypes.add(analysisType);
	}

	public UUID getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(UUID transactionID) {
		this.transactionID = transactionID;
	}

	public UserServiceID getUserServiceID() {
		return userServiceID;
	}

	public void setUserServiceID(UserServiceID userServiceID) {
		this.userServiceID = userServiceID;
	}

	public EventCallback getCallback() {
		return callback;
	}

	public void setCallback(EventCallback callback) {
		this.callback = callback;
	}

	@Override
	public String toString() {
		return "AnalysisResultsRequestEvent [analysisTypes=" + analysisTypes
				+ ", transactionID=" + transactionID + ", callback=" + callback
				+ ", sourceComponentID=" + sourceComponentID + "]";
	}

}
