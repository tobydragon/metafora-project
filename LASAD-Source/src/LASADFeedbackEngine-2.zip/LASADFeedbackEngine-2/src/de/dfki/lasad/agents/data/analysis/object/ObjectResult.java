package de.dfki.lasad.agents.data.analysis.object;

import java.util.Set;

import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class ObjectResult extends AnalysisResult {

	protected AnalyzableEntity analyzedEntity = null;

	// derived data (is based on analyzedEntity)
	protected Set<UserID> contributors = null;
	protected Long lastModificationTime = null;

	public ObjectResult(AnalysisType analysisType) {
		super(analysisType);
	}

	public ObjectResult(AnalysisType analysisType,
			AnalyzableEntity analyzedEntity) {
		super(analysisType);
		this.analyzedEntity = analyzedEntity;
	}

	public boolean processDataInitialized() {
		return contributors != null && lastModificationTime != null;
	}

	public void setAnalyzedEntity(AnalyzableEntity analyzedEntity) {
		this.analyzedEntity = analyzedEntity;
	}

	public AnalyzableEntity getAnalyzedEntity() {
		return analyzedEntity;
	}

	public Set<UserID> getContributors() {
		return contributors;
	}

	public void setContributors(Set<UserID> contributors) {
		this.contributors = contributors;
	}

	public Long getLastModificationTime() {
		return lastModificationTime;
	}

	public void setLastModificationTime(Long lastModificationTime) {
		this.lastModificationTime = lastModificationTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((analyzedEntity == null) ? 0 : analyzedEntity.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ObjectResult other = (ObjectResult) obj;
		if (analyzedEntity == null) {
			if (other.analyzedEntity != null)
				return false;
		} else if (!analyzedEntity.equals(other.analyzedEntity))
			return false;
		return true;
	}

}
