package de.dfki.lasad.sessionmodel.counter.jess;

import java.util.Set;

import jess.JessException;
import jess.RU;
import jess.Value;
import de.dfki.lasad.sessionmodel.counter.GraphObject;
import de.dfki.lasad.sessionmodel.counter.Index;
import de.dfki.lasad.sessionmodel.counter.constraints.NumConstr;
import de.dfki.lasad.sessionmodel.counter.constraints.SetConstr;

/**
 * Analyzes an input list of
 * 
 * @author oliverscheuer
 */
public class LinkCounter extends ElementCounter {

	/** Create a new EventListSearch user function object */
	public LinkCounter() {
		super();
	}

	@Override
	public String getName() {
		return "count-links";
	}

	@Override
	protected Value runAnalysis(Index index, int hash, SetConstr[] typeConstrs,
			SetConstr[] creatorConstrs, SetConstr[] modifiersConstrs,
			NumConstr[] firstTSConstrs, NumConstr[] lastTSConstrs)
			throws JessException {
		Set<GraphObject> matches = index.applyGlobalLinkConstraints(hash,
				typeConstrs, creatorConstrs, modifiersConstrs, firstTSConstrs,
				lastTSConstrs);
		return new Value(matches.size(), RU.INTEGER);
	}
}
