package de.dfki.lasad.sessionmodel.jessfunctions;

import java.util.HashSet;

import jess.Context;
import jess.JessException;
import jess.RU;
import jess.Userfunction;
import jess.Value;
import jess.ValueVector;

/**
 * Returns a ValueVector with all duplicate values removed.
 * 
 * Note: numeric values like 2 and 2.0 are not identified as duplicates!
 * 
 * @author Oliver Scheuer
 * 
 * 
 */
public class ListRemoveDuplicates implements Userfunction {

	/** Create a new ListRemoveDuplicates userfunction object */
	public ListRemoveDuplicates() {
		super();
	}

	/**
	 * Get the name of the ListRemoveDuplicates userfunction
	 * 
	 * @see jess.Userfunction#getName()
	 */
	public String getName() {
		return "remove-duplicates";
	}

	/**
	 * Call the sort ValueVector user function
	 * 
	 * @see jess.Userfunction#call(jess.ValueVector, jess.Context)
	 */
	public Value call(ValueVector vv, final Context context)
			throws JessException {
		if (vv.size() != 2) {
			throw new JessException(
					getName(),
					getName()
							+ " takes exactly one argument, the multifield to "
							+ "filter for duplicates",
					vv.size() - 1);
		}

		ValueVector vector = vv.get(1).listValue(context);
		HashSet<Value> seenValues = new HashSet<Value>();
		
		ValueVector resultVector = new ValueVector();
		Value valueInVector;
		for (int i = 0; i < vector.size(); ++i) {
			valueInVector = vector.get(i);
			if (!seenValues.contains(valueInVector)) {
				seenValues.add(valueInVector);
				resultVector.add(valueInVector);
			}
		}
		return new Value(resultVector, RU.LIST);
	}

}
