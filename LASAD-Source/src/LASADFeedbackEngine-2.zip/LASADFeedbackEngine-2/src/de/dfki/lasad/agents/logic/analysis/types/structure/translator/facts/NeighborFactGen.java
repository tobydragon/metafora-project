package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import lasad.shared.dfki.meta.agents.analysis.structure.model.LinkVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.NodeVariable;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.Indent;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class NeighborFactGen {

	protected JessIDAndSlotNameGenerator idGen;

	// in
	private LinkVariable linkVar;

	public NeighborFactGen(JessIDAndSlotNameGenerator idGen,
			LinkVariable linkVar) {
		this.idGen = idGen;
		this.linkVar = linkVar;
	}

	public String getString() {

		StringBuffer buf = new StringBuffer();

		String sourceID = idGen.generateElemIDVar(linkVar.getSource());
		String targetID = idGen.generateElemIDVar(linkVar.getTarget());
		String linkID = idGen.generateElemIDVar(linkVar);

		String elemIDSlot = "(elem_id " + sourceID + ")";
		String linkIDSlot = "(link_id " + linkID + ")";
		String neighborIDSlot = "(neighbor_id " + targetID + ")";

		buf.append("(neighbor");
		buf.append("\n");
		buf.append(Indent.apply(elemIDSlot, Indentations.INDENT_LINK));
		buf.append("\n");
		buf.append(Indent.apply(linkIDSlot, Indentations.INDENT_LINK));
		buf.append("\n");
		buf.append(Indent.apply(neighborIDSlot, Indentations.INDENT_LINK));
		buf.append(")");
		return buf.toString();
	}
}
