package de.dfki.lasad.authoring.model.pattern;

/**
 * Operator used to compare values (see {@link Comparison}).
 * 
 * @author oliverscheuer
 * 
 */
public interface Operator {

}
