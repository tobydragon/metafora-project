package de.dfki.lasad.agents.logic.provision.actionsort;

import java.util.List;

import lasad.shared.dfki.meta.agents.provision.priority.MsgSortCriterion;
import lasad.shared.dfki.meta.agents.provision.priority.MsgSortCriterion_MsgPriority;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.provision.phases.PhaseModelerInterface;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgSortServiceFactory {

	private static Log logger = LogFactory.getLog(MsgSortServiceFactory.class);

	public static MsgSortServiceInterface createMsgSortService(
			List<MsgSortCriterion> sortCriteriaInOrder, UserID u,
			PhaseModelerInterface phaseModelerRef) {
		int lastIndex = sortCriteriaInOrder.size() - 1;
		MsgSortComparator outmostComparator = new MsgSortComparator_AllEqual(null);
		for (int i = lastIndex; i >= 0; --i) {
			MsgSortCriterion criterion = sortCriteriaInOrder.get(i);
			if (criterion instanceof MsgSortCriterion_MsgPriority) {
				MsgSortComparator_AssignedPriority phasePriorityComparator = new MsgSortComparator_AssignedPriority(
						outmostComparator);
				outmostComparator = phasePriorityComparator;
			} else {
				logger.error("Unhandled msg sort criterion: " + criterion);
				return null;
			}
		}
		return new MsgSortService(outmostComparator, phaseModelerRef);
	}
}
