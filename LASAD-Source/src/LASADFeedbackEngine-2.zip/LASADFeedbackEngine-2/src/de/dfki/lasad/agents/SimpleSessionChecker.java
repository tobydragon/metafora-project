package de.dfki.lasad.agents;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import lasad.shared.dfki.meta.ontology.Ontology;

import de.dfki.lasad.session.Session;

/**
 * Checks whether {@link Session} is supported, based on the {@link Session}'s
 * {@link Ontology}.
 * 
 * @author Oliver Scheuer
 * 
 */
public class SimpleSessionChecker implements SessionChecker {

	private Set<String> supportedOntologyIDs = new HashSet<String>();
	private List<String> supportedOntologyIDList = new Vector<String>();

	private boolean supportAll = true;

	/**
	 * All ontologies will be supported.
	 */
	public SimpleSessionChecker() {
		supportAll = true;
	}

	/**
	 * Selected ontologies will be supported.
	 * 
	 * @param supportedOntologyIDs
	 *            supported ontologies
	 */
	public SimpleSessionChecker(List<String> supportedOntologyIDList) {
		this.supportedOntologyIDList = supportedOntologyIDList;
		this.supportedOntologyIDs.addAll(supportedOntologyIDList);
		supportAll = false;
	}

	@Override
	public boolean isSessionSupported(Session session) {
		if (supportAll) {
			return true;
		}
		Ontology ontology = session.getOntology();
		String ontologyID = ontology.getOntologyID();
		return supportedOntologyIDs.contains(ontologyID);
	}

	public List<String> getSupportedOntologies() {
		return supportedOntologyIDList;
	}

	public boolean allOntologiesSupported() {
		return supportAll;
	}
}
