package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.agents.analysis.structure.model.NodeVariable;
import lasad.shared.dfki.meta.ontology.Ontology;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.Indent;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ElemFactBindListElemGen {

	private Ontology ontology;
	private JessIDAndSlotNameGenerator idGen;
	private Comparison comparison;

	public ElemFactBindListElemGen(Ontology ontology,
			JessIDAndSlotNameGenerator idGen, Comparison comparison) {
		this.ontology = ontology;
		this.idGen = idGen;
		this.comparison = comparison;
	}

	public String getString() {
		StringBuffer buf = new StringBuffer();

		ElementVariableProp propVar = comparison.getLeftExpr();
		ElementVariable elemVar = propVar.getElementVar();
		String elemVarID = idGen.generateElemIDVar(elemVar);
		String idSlot = "(id " + elemVarID + ")";
		String propSlotName = idGen.generateSlotName(propVar);
		String propVarID = idGen.generatePropVarID(propVar, comparison
				.getSupplData().getId(), true, true);
		String propSlot = "(" + propSlotName + " " + "$? " + propVarID + " $?"
				+ ")";
		String deletedSlot = "(deleted FALSE)";

		if (elemVar instanceof NodeVariable) {
			buf.append("(node");
		} else {
			buf.append("(link");
		}
		buf.append("\n");
		buf.append(Indent.apply(idSlot, Indentations.INDENT_NODE));
		buf.append("\n");
		buf.append(Indent.apply(propSlot, Indentations.INDENT_NODE));
		buf.append("\n");
		buf.append(Indent.apply(deletedSlot, Indentations.INDENT_NODE));
		buf.append(")");
		return buf.toString();
	}
}
