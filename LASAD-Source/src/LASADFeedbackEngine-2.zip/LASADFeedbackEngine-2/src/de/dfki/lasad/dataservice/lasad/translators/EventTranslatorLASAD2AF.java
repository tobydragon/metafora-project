package de.dfki.lasad.dataservice.lasad.translators;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.Parameter;
import lasad.gwt.client.communication.objects.categories.Categories;
import lasad.gwt.client.communication.objects.commands.Commands;
import lasad.gwt.client.communication.objects.parameters.ParameterTypes;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.instances.xmpp.CfAbstractAgent;
import de.dfki.lasad.core.DisplayedObjectIDTracker;
import de.dfki.lasad.dataservice.lasad.AnalysisAndFeedbackTypeAdapter;
import de.dfki.lasad.dataservice.lasad.rmi.LASADDataService;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.EUEEventID;
import de.dfki.lasad.events.eue.admin.config.OntologyInfoEvent;
import de.dfki.lasad.events.eue.admin.config.OntologyListEvent;
import de.dfki.lasad.events.eue.admin.session.ManagementResponseEvent;
import de.dfki.lasad.events.eue.admin.session.SessionOntologyInfoEvent;
import de.dfki.lasad.events.eue.admin.session.SessionOverviewEvent;
import de.dfki.lasad.events.eue.admin.session.SessionToolsInfoEvent;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestEvent;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestSpec;
import de.dfki.lasad.events.eue.user.feedback.FeedbackTypeID;
import de.dfki.lasad.events.eue.user.join.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.user.join.UserLeaveSessionEvent;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.DeleteObjectEvent;
import de.dfki.lasad.events.eue.user.object.FocusObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.meta.Ontology;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.EUEObjectID;
import de.dfki.lasad.session.data.objects.EmptyID;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;
import de.dfki.lasad.session.data.objects.ObjectProperty;
import de.dfki.lasad.session.data.objects.SimpleProperty;

public class EventTranslatorLASAD2AF {

	private static Log logger = LogFactory
			.getLog(EventTranslatorLASAD2AF.class);

	// debugging setting
	private boolean REQUEST_RAW_RESULTS = false;

	private HashMap<EUEObjectID, EUEObjectBasicData> objectTracker = new HashMap<EUEObjectID, EUEObjectBasicData>();

	private HashMap<String, GUIAction> guiActionTracker = new HashMap<String, GUIAction>();
	private HashSet<String> replayedGuiActionTracker = new HashSet<String>();

	// flag indicating that replayed events should be generated
	private boolean generateReplayedEvent = false;

	// used to generate unique event ids in case of replayed actions
	private int replayedEventCounter = 0; //

	private Map<String, Set<String>> mapID2feedbackElementIDs = new HashMap<String, Set<String>>();
	private Map<String, Set<String>> mapID2feedbackMenuItemIDs = new HashMap<String, Set<String>>();

	public List<EUEEvent> translate(ActionPackage lasadEvent) {

		logger.info("[translate] Start translating ActionPackage...");
		//logger.debug("ActionPackage contents: \n"
		//		+ ActionPackageXmlConverter.toXml(lasadEvent));

		List<EUEEvent> translation = translateActionPackage(lasadEvent);
		Collections.sort(translation, new Comparator<EUEEvent>() {
			@Override
			public int compare(EUEEvent o1, EUEEvent o2) {
				long tsDiff = o1.getTs() - o2.getTs();
				if (tsDiff < 0) {
					return -1;
				} else if (tsDiff > 0) {
					return 1;
				}
				return 0;
			}
		});
		logger.debug("Number of produced Events: " + translation.size());
		for (Event event : translation) {
			String eventAsString = event.toString().replace("\\s", " ");
			logger.debug("... Events: " + eventAsString);
		}

		return translation;
	}

	/**
	 * Processes all actions relevant to a session
	 * <ul>
	 * <li>feedback requests</li>
	 * <li>new user joins a session</li>
	 * <li>user creates, modifies or deletes an object within a session</li>
	 * <li><i>... ignore all other actions ...</i></li>
	 * </ul>
	 * 
	 * @param aPackage
	 * @return
	 */
	private List<EUEEvent> translateActionPackage(ActionPackage aPackage) {

		List<EUEEvent> generatedEventsList = new Vector<EUEEvent>();

		List<Action> actionList = aPackage.getActions();

		for (Action action : actionList) {
			Categories category = action.getCategory();
			Commands command = action.getCmd();
			ParamMap paramMap = extractParams(action.getParameters());
			
			
//			switch(){
//				case Categories.Auth:{
//					break;
//				}
//				case Authoring:{
//					break;
//				} 
//				case Error:{
//					break;
//				} 
//				case Info:{
//					break;
//				} 
//				case Management:{
//					break;
//				} 
//				case Map:{
//					break;
//				} 
//				case Notify:{
//					break;
//				} 
//				case Replay:{
//					break;
//				} 
//				case Session:{
//					break;
//				}
//				case UserEvent:{
//					break;
//				} 
//				case None:{
//					break;
//				} 
//				case Communication:{
//					break;
//				} 
//				case Feedback:{
//					break;
//				} 
//				case Questionnaire:{
//					break;
//				} 
//				case File:{
//					break;
//				}
//				case Heartbeat:{
//					break;
//				}
//				case FeedbackAuthoring:{
//					break;
//				}
//			}

			// translate feedback request
			if (isFeedbackRequest(category, command)) {
				FeedbackRequestEvent feedbackRequestEvent = translateFeedbackRequestAction(action);
				generatedEventsList.add(feedbackRequestEvent);

				// translate session meta data
			} else if (isListMap(category, command)) {
				SessionOverviewEvent e = translateListMapAction(action);
				generatedEventsList.add(e);

			} else if (isOntology(category, command)) {
				SessionOntologyInfoEvent e = translateOntologyInfoAction(action);
				generatedEventsList.add(e);
			} else if (isOntologyIDsList(category, command)) {
				OntologyListEvent e = translateOntologyIDsListAction(action);
				generatedEventsList.add(e);
			} else if (isOntologyDetails(category, command)) {
				OntologyInfoEvent e = translateOntologyDetailsAction(action);
				generatedEventsList.add(e);

			} else if (isMapDetails(category, command)) {
				SessionToolsInfoEvent e = translateMapDetailsAction(action);
				generatedEventsList.add(e);

			} else if (isFeedbackClusterDisplayed(category, command, paramMap)) {
				// process feedback presentation to user
				processFeedbackElementDisplayedAction(action, paramMap);

			} else if (isFeedbackMenuItemDisplayed(category, command, paramMap)) {
				// process feedback menu item made available to user
				processFeedbackMenuItemDisplayedAction(action, paramMap);

				// translate user join session
			} else if (isUserJoin(category, command)) {
				UserJoinSessionEvent e = translateJoinEvent(action);
				if (e != null) {
					generatedEventsList.add(e);
				}
			} else if (isUserLeave(category, command)) {
				UserLeaveSessionEvent e = translateLeaveEvent(action);
				generatedEventsList.add(e);
			} else if (isUserList(category, command)) {
				List<UserJoinSessionEvent> e = translateUserListEvent(action);
				generatedEventsList.addAll(e);

			} else if (isCreateUpdateDelete(category, command)) {
				// translate session actions (create, modify, delete object)
				String guiActionID = translateCreateUpdateDeleteAction(action,
						paramMap);
				if (guiActionID == null) {
					logger.debug("IGNORE Action: Property '"
							+ ParameterTypes.UserActionId + "' is not present");
				} else {
					GUIAction guiAction = guiActionTracker.get(guiActionID);
					if (guiAction != null && guiAction.isComplete()
							&& !guiAction.isReplayedAction()) {
						guiActionTracker.remove(guiActionID);
						List<UserEvent> evList = createEvent(guiAction);
						generatedEventsList.addAll(evList);
					}
				}

			} else if (isCreateMap(category, command)) {
				SessionOverviewEvent e = translateCreateMapAction(action);
				generatedEventsList.add(e);

			} else if (isManagementResponse(category, command)) {
				// TD: may cause problems due to null sessionID, but plain
				// EUEEvents are not part of the schema for messages to
				// actionAgents
				generatedEventsList.add(new ManagementResponseEvent(null,
						CfAbstractAgent.class.getName(), command, paramMap
								.getFirstValue(ParameterTypes.Message)));

			} else {
				logger.debug("IGNORE Action: ActionCommand '" + command + "'");
			}
		}

		logger.debug("Replayed Actions? " + generateReplayedEvent
				+ ", number of replayed Actions:"
				+ replayedGuiActionTracker.size());
		if (generateReplayedEvent) {
			List<UserEvent> replayedEvents = generateReplayedEvents();
			generatedEventsList.addAll(replayedEvents);
			generateReplayedEvent = false;
		}
		return generatedEventsList;

	}

	private boolean isManagementResponse(Categories category, Commands command) {
		boolean managementError = (Categories.Info == category)
				&& (Commands.AuthoringFailed == command);

		boolean managementSuccess = (Categories.Notify == category)
				&& (Commands.UserCreated == command || Commands.SessionCreated == command);
		return managementError || managementSuccess;
	}

	private boolean isFeedbackRequest(Categories category, Commands command) {
		boolean isFeedbackRequest = (Commands.Request == command)
				&& (Categories.Feedback == category);
		return isFeedbackRequest;
	}

	private boolean isFeedbackClusterDisplayed(Categories category,
			Commands command, ParamMap paramMap) {
		String type = paramMap.getFirstValue(ParameterTypes.Type);
		return (Commands.CreateElement == command)
				&& LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK_CLUSTER
						.equalsIgnoreCase(type);
	}

	private boolean isFeedbackMenuItemDisplayed(Categories category,
			Commands command, ParamMap paramMap) {
		String type = paramMap.getFirstValue(ParameterTypes.Type);
		return (Commands.CreateElement == command)
				&& LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK_AGENT
						.equalsIgnoreCase(type);
	}

	private boolean isListMap(Categories category, Commands command) {
		return (Commands.ListMap == command);
	}

	private boolean isOntologyIDsList(Categories category, Commands command) {
		return (Commands.ListOntologies == command);
	}

	private boolean isOntologyDetails(Categories category, Commands command) {
		return (Commands.OntologyDetails == command);
	}

	private boolean isOntology(Categories category, Commands command) {
		return (Commands.Ontology == command);
	}

	private boolean isMapDetails(Categories category, Commands command) {
		return (Commands.MapDetails == command);
	}

	private boolean isUserJoin(Categories category, Commands command) {
		return (Commands.UserJoin == command);
	}

	private boolean isUserLeave(Categories category, Commands command) {
		return (Commands.UserLeave == command);
	}

	private boolean isUserList(Categories category, Commands command) {
		return (Commands.UserList == command);
	}

	private boolean isCreateUpdateDelete(Categories category, Commands command) {
		boolean isCreateUpdateDelete = (Commands.CreateElement == command)
				|| (Commands.UpdateElement == command)
				|| (Commands.DeleteElement == command);
		return isCreateUpdateDelete;
	}

	private boolean isCreateMap(Categories category, Commands command) {
		return (Categories.Authoring == category)
				&& (Commands.AddMapToList == command);
	}

	private String userlistDisplayName2userID(String displayName) {
		return displayName.replace(" (Standard)", "").trim();
	}

	private boolean isUserAFAgent(String userID) {
		return "DFKI".equals(userID);
	}

	private void processFeedbackElementDisplayedAction(Action action,
			ParamMap paramMap) {
		String mapID = paramMap.getFirstValue(ParameterTypes.MapId);
		String objectID = paramMap.getFirstValue(ParameterTypes.Id);

		Set<String> objectsForMap = mapID2feedbackElementIDs.get(mapID);
		if (objectsForMap == null) {
			objectsForMap = new HashSet<String>();
			mapID2feedbackElementIDs.put(mapID, objectsForMap);
		}
		objectsForMap.add(objectID);
	}

	private void processFeedbackMenuItemDisplayedAction(Action action,
			ParamMap paramMap) {
		String mapID = paramMap.getFirstValue(ParameterTypes.MapId);
		String objectID = paramMap.getFirstValue(ParameterTypes.Id);

		Set<String> menuItemsForMap = mapID2feedbackMenuItemIDs.get(mapID);
		if (menuItemsForMap == null) {
			menuItemsForMap = new HashSet<String>();
			mapID2feedbackMenuItemIDs.put(mapID, menuItemsForMap);
		}
		menuItemsForMap.add(objectID);
	}

	private List<UserEvent> generateReplayedEvents() {
		logger.debug("Start generating Events for replayed Actions ...");
		resetReplayedEventCounter();
		List<UserEvent> replayedEvents = createReplayedEvents();
		logger.debug("Number of generated replayed Events:"
				+ replayedEvents.size());
		return replayedEvents;
	}

	private int getReplayedEventCount() {
		return replayedEventCounter;
	}

	private int getReplayedEventCountAndIncrement() {
		return ++replayedEventCounter;
	}

	private void resetReplayedEventCounter() {
		replayedEventCounter = 0;
	}

	private UserJoinSessionEvent translateJoinEvent(Action action) {

		String mapID = null;
		String userDisplayName = null;

		for (Parameter aParam : action.getParameters()) {
			ParameterTypes paramType = aParam.getType();
			if (ParameterTypes.MapId == paramType) {
				mapID = aParam.getValue();
			} else if (ParameterTypes.UserName == paramType) {
				userDisplayName = aParam.getValue();
			}
		}

		String userID = userlistDisplayName2userID(userDisplayName);
		if (isUserAFAgent(userID)) {
			return null;
		}

		EUEEventID eueEventID = EUEEventIDGenerator.getNextID();
		UserJoinSessionEvent e = new UserJoinSessionEvent(new SessionID(mapID),
				LASADDataService.class.toString(), eueEventID, new UserID(
						userID));
		return e;
	}

	private UserLeaveSessionEvent translateLeaveEvent(Action action) {

		String mapID = null;
		String userDisplayName = null;

		for (Parameter aParam : action.getParameters()) {
			ParameterTypes paramType = aParam.getType();
			if (ParameterTypes.MapId == paramType) {
				mapID = aParam.getValue();
			} else if (ParameterTypes.UserName == paramType) {
				userDisplayName = aParam.getValue();
			}
		}

		String userID = userlistDisplayName2userID(userDisplayName);
		if (isUserAFAgent(userID)) {
			return null;
		}

		EUEEventID eueEventID = EUEEventIDGenerator.getNextID();
		UserLeaveSessionEvent e = new UserLeaveSessionEvent(
				new SessionID(mapID), LASADDataService.class.toString(),
				eueEventID, new UserID(userID));
		return e;
	}

	private List<UserJoinSessionEvent> translateUserListEvent(Action action) {

		String mapID = null;
		List<String> userDisplayNames = new Vector<String>();

		for (Parameter aParam : action.getParameters()) {
			ParameterTypes paramType = aParam.getType();
			if (ParameterTypes.MapId == paramType) {
				mapID = aParam.getValue();
			} else if (ParameterTypes.UserName == paramType) {
				userDisplayNames.add(aParam.getValue());
			}
		}
		List<UserJoinSessionEvent> events = new Vector<UserJoinSessionEvent>();
		for (String userDisplayName : userDisplayNames) {
			String userID = userlistDisplayName2userID(userDisplayName);
			if (!isUserAFAgent(userID)) {
				EUEEventID eueEventID = EUEEventIDGenerator.getNextID();
				UserJoinSessionEvent e = new UserJoinSessionEvent(
						new SessionID(mapID),
						LASADDataService.class.toString(), eueEventID,
						new UserID(userID));
				e.setTs(-1);
				events.add(e);
			}
		}
		return events;
	}

	private SessionOverviewEvent translateListMapAction(Action action) {

		String mapID = null;
		String ontologyName = null;
		String templateName = null;
		for (Parameter aParam : action.getParameters()) {
			ParameterTypes paramType = aParam.getType();
			if (ParameterTypes.MapId == paramType) {
				mapID = aParam.getValue();
			} else if (ParameterTypes.OntologyName == paramType) {
				ontologyName = aParam.getValue();
			} else if (ParameterTypes.TemplateName == paramType) {
				templateName = aParam.getValue();
			}
		}

		SessionOverviewEvent e = new SessionOverviewEvent(
				LASADDataService.class.toString());
		e.setSessionID(new SessionID(mapID));
		e.setOntologyID(ontologyName);
		e.setTemplateID(templateName);
		e.setTs(System.currentTimeMillis());

		return e;
	}

	private SessionOverviewEvent translateCreateMapAction(Action action) {
		return translateListMapAction(action);
	}

	private SessionOntologyInfoEvent translateOntologyInfoAction(Action action) {

		String mapID = null;
		String ontologyXML = null;
		for (Parameter aParam : action.getParameters()) {
			ParameterTypes paramType = aParam.getType();
			if (ParameterTypes.MapId == paramType) {
				mapID = aParam.getValue();
			} else if (ParameterTypes.Ontology == paramType) {
				ontologyXML = aParam.getValue();
			}
		}
		SessionOntologyInfoEvent e = new SessionOntologyInfoEvent(
				LASADDataService.class.toString());
		e.setSessionID(new SessionID(mapID));
		e.setOntologyXML(ontologyXML);
		e.setOntology(LASADOntologyParser.parseOntology(ontologyXML));
		e.setTs(System.currentTimeMillis());

		return e;
	}

	private OntologyListEvent translateOntologyIDsListAction(Action action) {

		List<String> ontologyIDList = new Vector<String>();
		for (Parameter aParam : action.getParameters()) {
			ParameterTypes paramType = aParam.getType();
			if (ParameterTypes.OntologyName == paramType) {
				String ontologyID = aParam.getValue();
				ontologyIDList.add(ontologyID);
			}
		}
		OntologyListEvent e = new OntologyListEvent(
				LASADDataService.class.toString());
		e.setOntologyIDs(ontologyIDList);
		e.setTs(System.currentTimeMillis());
		return e;
	}

	private OntologyInfoEvent translateOntologyDetailsAction(Action action) {

		String ontologyXML = null;
		for (Parameter aParam : action.getParameters()) {
			ParameterTypes paramType = aParam.getType();
			if (ParameterTypes.Ontology == paramType) {
				ontologyXML = aParam.getValue();
			}
		}
		OntologyInfoEvent e = new OntologyInfoEvent(
				LASADDataService.class.toString());
		e.setOntologyXML(ontologyXML);
		e.setOntology(LASADOntologyParser.parseOntology(ontologyXML));
		e.setTs(System.currentTimeMillis());

		return e;
	}

	private SessionToolsInfoEvent translateMapDetailsAction(Action action) {
		String mapID = null;
		String ontologyID = null;
		String templateID = null;
		String templateXML = null;
		for (Parameter aParam : action.getParameters()) {
			ParameterTypes paramType = aParam.getType();
			if (ParameterTypes.MapId == paramType) {
				mapID = aParam.getValue();
			} else if (ParameterTypes.OntologyName == paramType) {
				ontologyID = aParam.getValue();
			} else if (ParameterTypes.TemplateName == paramType) {
				templateID = aParam.getValue();
			} else if (ParameterTypes.TemplateXML == paramType) {
				templateXML = aParam.getValue();
			}
		}
		SessionToolsInfoEvent e = new SessionToolsInfoEvent(
				LASADDataService.class.toString());
		e.setSessionID(new SessionID(mapID));
		e.setOntologyID(ontologyID);
		e.setTemplateID(templateID);
		e.setTemplateXML(templateXML);

		e.setToolContext(LASADTemplateParser.parseToolContext(templateXML));

		e.setTs(System.currentTimeMillis());

		return e;
	}

	private String translateCreateUpdateDeleteAction(Action action,
			ParamMap paramMap) {
		Commands actionCommand = action.getCmd();

		String displayedID = paramMap
				.getFirstValue(ParameterTypes.RootElementId);
		String sessionID = paramMap.getFirstValue(ParameterTypes.MapId);
		String objectID = paramMap.getFirstValue(ParameterTypes.Id);

		if (isFeedbackElement(sessionID, objectID)) {
			// ignore
			return null;
		}

		if (displayedID != null && sessionID != null) {
			// top-level element: we extract the displayed id (== ROOTELEMENTID)
			DisplayedObjectIDTracker.addMapping(new SessionID(sessionID),
					new EUEObjectID(objectID), displayedID);
		}

		String guiActionID = getGuiActionID(paramMap);

		if (guiActionID == null) {
			logger.error(ParameterTypes.UserActionId
					+ " is not present, action discarded - " + action);
		} else {
			if (guiActionTracker.containsKey(guiActionID)) {
				// we receive a new action of an existing UserActionEvent
				processExistingGuiActionID(guiActionID, actionCommand, paramMap);

			} else {
				// we receive a new action, and the GuiActionID is new too,
				// start tracking it.
				processNewGuiAction(guiActionID, actionCommand, paramMap);
			}
		}

		return guiActionID;
	}

	private void processNewGuiAction(String guiActionID, Commands command,
			ParamMap paramMap) {

		GUIAction guiAction = new GUIAction(guiActionID);

		guiAction.setUserEventType(command);

		String sessionID = paramMap.removeAndGetFirst(ParameterTypes.MapId);
		String userID = paramMap.removeAndGetFirst(ParameterTypes.UserName);
		String numActions = paramMap
				.removeAndGetFirst(ParameterTypes.NumActions);
		String time = paramMap.removeAndGetFirst(ParameterTypes.Time); // TIME
		String focusStatus = paramMap.removeAndGetFirst(ParameterTypes.Status);

		guiAction.setSessionID(new SessionID(sessionID));

		if (userID == null) {
			// update and delete actions don't have an userID, i.e. it's not
			// provided...
			// ... Look up userID in tracker system.
			logger.warn("Param 'username' not available in Modify/Delete-Action (session: "
					+ sessionID + "). Use stored Create-User.");
			String objectID = paramMap.getFirstValue(ParameterTypes.Id);
			if (objectID != null) {
				EUEObjectID objectIDObj = new EUEObjectID(objectID);
				EUEObjectBasicData objectBasicData = getEUEObjectFromTracker(objectIDObj);
				if (objectBasicData == null) {
					logger.error(ParameterTypes.UserName
							+ " was not provided," + " node: " + objectID
							+ " is not in tracking system, "
							+ "we cannot determine the owner");
					return;
				} else {
					userID = objectBasicData.getUserID();
				}
			} else {
				logger.error("Param 'objectID' not available in Action.");
			}
		}

		guiAction.setUserID(new UserID(userID));
		guiAction.setNumActions(Integer.parseInt(numActions));
		guiAction.setGuiActionID(guiActionID);
		if (time != null) {
			guiAction.setTime(Long.parseLong(time));
		} else {
			guiAction.setTime(getCurrentTimeAsLong());
		}

		if (paramMap.getFirstValue(ParameterTypes.Replay) != null) {
			generateReplayedEvent = true;

			String creationDate = paramMap
					.removeAndGetFirst(ParameterTypes.CreationDate);
			if (creationDate != null) {
				guiAction.setCreationDate(Long.parseLong(creationDate));
			}
			String modDate = paramMap
					.removeAndGetFirst(ParameterTypes.ModificationDate);
			if (modDate != null) {
				guiAction.setModificationDate(Long.parseLong(modDate));
			}

			String firstModDate = paramMap
					.removeAndGetFirst(ParameterTypes.FirstModificationDate);
			if (firstModDate != null) {
				guiAction.setFirstModDate(Long.parseLong(firstModDate));
			}

			// remove parameters that are not required
			paramMap.remove(ParameterTypes.Replay);

			guiAction.setIsReplayedAction(true);

		} else {
			// TODO each time we receive one of this actions check if
			// list of replay action is empty, if not generate event.
			// not from a graph
		}

		if (paramMap.containsKey(ParameterTypes.Direction)) {
			String paramValue = paramMap
					.removeAndGetFirst(ParameterTypes.Direction);

			String[] sourceAndTarget = paramValue.split(",");
			String newSourceID = sourceAndTarget[0].trim();
			String newTargetID = sourceAndTarget[1].trim();

			paramMap.addParam(ParameterTypes.Parent, newSourceID);
			paramMap.addParam(ParameterTypes.Parent, newTargetID);
		}

		EUEObject eueObject = createEUEObjectNew(paramMap);

		if (eueObject != null) {
			EUEObjectBasicData objBasicDesc = createEUEObjectBasicData(
					eueObject, userID);

			if (eueObject instanceof Node) {
				objBasicDesc.setParentID(((Node) eueObject).getParentID()
						.getIdAsString());
			}
			// guiAction.addEueObject(eueObject);
			guiAction.increaseCurrentActionsByOne();

			// track/untrack the node/link/child
			if (Commands.CreateElement == command) {
				guiAction.addEueObject2CreateList(eueObject);
				addEUEObjectToTracker(objBasicDesc);
			} else if (Commands.UpdateElement == command) {

				if (LASADVocabulary.ACTION_PROP_VALUE_LOCK.equals(focusStatus)) {
					guiAction.addEueObject2FocusSetList(eueObject);
				} else if (LASADVocabulary.ACTION_PROP_VALUE_UNLOCK
						.equals(focusStatus)) {
					guiAction.addEueObject2FocusRemovedList(eueObject);
				} else { // "normal" update action

					guiAction.addEueObject2UpdateList(eueObject);
				}

				// this is the timestamp we will use for the update event when
				// creates and updates are mixed
				if (time != null) {
					guiAction.setModificationDate(Long.parseLong(time));
				} else {
					guiAction.setModificationDate(getCurrentTimeAsLong());
				}
				// updateEUEObjectToTracker(objBasicDesc);
			} else if (Commands.DeleteElement == command) {
				guiAction.addEueObject2DeleteList(eueObject);
				if (time != null) {
					guiAction.setModificationDate(Long.parseLong(time));
				} else {
					guiAction.setModificationDate(getCurrentTimeAsLong());
				}
				deleteEUEObjectFromTracker(objBasicDesc.getId());
			}
			// track/untrack the node/link/child
			// if (actionCommand
			// .equalsIgnoreCase(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT)) {
			// addEUEObjectToTracker(objBasicDesc);
			// } else if (actionCommand
			// .equalsIgnoreCase(LASADVocabulary.ACTION_CMD_DELETE_ELEMENT)) {
			// deleteEUEObjectFromTracker(objBasicDesc.getId());
			// }
		} else {
			// the action was a timestamp, action was malformed or a problem
			// occurred, then decrease the total number of actions for that
			// userActionID
			guiAction.decreaseNumActionsByOne();
		}
		if (guiAction.getNumActions() > 0) {
			guiActionTracker.put(guiActionID, guiAction);
			if (guiAction.isReplayedAction()) {
				replayedGuiActionTracker.add(guiActionID);
			}
		}
	}

	private void processExistingGuiActionID(String guiActionID,
			Commands command, ParamMap paramMap) {

		// we receive a new action of an existing UserActionEvent
		GUIAction guiAction = guiActionTracker.remove(guiActionID);

		String userID = guiAction.getUserID().getIdAsString();

		String time = paramMap.removeAndGetFirst(ParameterTypes.Time); // TIME
		String focusStatus = paramMap.removeAndGetFirst(ParameterTypes.Status);

		// remove parameters that are not required
		paramMap.remove(ParameterTypes.Replay);
		paramMap.remove(ParameterTypes.NumActions);
		// paramMap.remove(LASADVocabulary.ACTION_PROP_USERNAME);

		if (paramMap.containsKey(ParameterTypes.Direction)) {
			String paramValue = paramMap
					.removeAndGetFirst(ParameterTypes.Direction);

			String[] sourceAndTarget = paramValue.split(",");
			String newSourceID = sourceAndTarget[0].trim();
			String newTargetID = sourceAndTarget[1].trim();

			paramMap.addParam(ParameterTypes.Parent, newSourceID);
			paramMap.addParam(ParameterTypes.Parent, newTargetID);
		}
		EUEObject eueObject = createEUEObjectNew(paramMap);

		if (eueObject != null) {
			EUEObjectBasicData objBasicDesc = createEUEObjectBasicData(
					eueObject, userID);
			if (eueObject instanceof Node) {
				objBasicDesc.setParentID(((Node) eueObject).getParentID()
						.getIdAsString());
			}

			guiAction.increaseCurrentActionsByOne();
			// System.out.println(objBasicDesc);
			// track/untrack the node/link/child
			if (Commands.CreateElement == command) {
				if (time != null) {
					guiAction.setCreationDate(Long.parseLong(time));
				}
				guiAction.addEueObject2CreateList(eueObject);
				addEUEObjectToTracker(objBasicDesc);
			} else if (Commands.UpdateElement == command) {

				if (LASADVocabulary.ACTION_PROP_VALUE_LOCK.equals(focusStatus)) {
					guiAction.addEueObject2FocusSetList(eueObject);
				} else if (LASADVocabulary.ACTION_PROP_VALUE_UNLOCK
						.equals(focusStatus)) {
					guiAction.addEueObject2FocusRemovedList(eueObject);
				} else { // "normal" update action

					guiAction.addEueObject2UpdateList(eueObject);
				}
				// this is the timestamp we will use for the update event
				// when creates and updates are mixed
				// updateEUEObjectToTracker(objBasicDesc);
				if (time != null) {
					guiAction.setModificationDate(Long.parseLong(time));
				} else {
					guiAction.setModificationDate(guiAction.getCreationDate());
				}

			} else if (Commands.DeleteElement == command) {
				guiAction.addEueObject2DeleteList(eueObject);
				deleteEUEObjectFromTracker(objBasicDesc.getId());
				if (time != null) {
					guiAction.setModificationDate(Long.parseLong(time));
				} else {
					guiAction.setModificationDate(guiAction.getCreationDate());
				}
			}
			// track/untrack the node/link/child
			// if (actionCommand
			// .equalsIgnoreCase(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT)) {
			// addEUEObjectToTracker(objBasicDesc);
			// } else if (actionCommand
			// .equalsIgnoreCase(LASADVocabulary.ACTION_CMD_DELETE_ELEMENT)) {
			// deleteEUEObjectFromTracker(objBasicDesc.getId());
			// }

		} else {
			// the action was a timestamp, action was malformed or a problem
			// occurred, then decrease the total number of actions for that
			// guiActionID
			guiAction.decreaseNumActionsByOne();
		}

		// After the insertions/deletions check if we should continue tracking
		// this guiActionID
		if (guiAction.getNumActions() > 0) {
			guiActionTracker.put(guiActionID, guiAction);
		}
	}

	private String getGuiActionID(ParamMap paramMap) {

		String guiActionID = null;

		String replayValueAsString = paramMap
				.getFirstValue(ParameterTypes.Replay);
		boolean replayParam = Boolean.valueOf(replayValueAsString);

		if (replayParam) {
			// Since the USERACTION-ID (i.e., guiActionID) value might be the
			// same for different action packages we need to generate unique
			// values for each action package.
			paramMap.remove(ParameterTypes.UserActionId);

			if (!paramMap.containsKey(ParameterTypes.CreationDate)) {
				// it is a root, i.e. is the box node
				guiActionID = String.valueOf(getReplayedEventCount());
			} else {
				// it is a child of the box, e.g., header or comment section
				guiActionID = String
						.valueOf(getReplayedEventCountAndIncrement());
			}
		} else {
			// we can get the USERACTION-ID value directly, it's a unique value
			// for each actionpackage
			guiActionID = paramMap
					.removeAndGetFirst(ParameterTypes.UserActionId);
		}
		return guiActionID;
	}

	private List<UserEvent> createEvent(GUIAction guiAction) {
		// UserObjectActionEvent eueEvent = null;

		List<UserEvent> eueEventList = new Vector<UserEvent>();

		String srcCompID = LASADDataService.class.toString();
		EUEEventID eueEventIDObj = EUEEventIDGenerator.getNextID();

		if (guiAction.getCreateEueObjectList().size() > 0) {
			ObjectActionEvent eueEventCreate = new CreateObjectEvent(
					guiAction.getSessionID(), eueEventIDObj, srcCompID);
			eueEventCreate.setUserID(guiAction.getUserID());
			eueEventCreate.setTs(guiAction.getTime());
			List<EUEObject> objList = guiAction.getCreateEueObjectList();
			for (EUEObject obj : objList) {
				eueEventCreate.addEueObject(obj);
			}
			eueEventList.add(eueEventCreate);
		}
		if (guiAction.getUpdateEueObjectList().size() > 0) {
			ObjectActionEvent eueEventUpdate = new ModifyObjectEvent(
					guiAction.getSessionID(), eueEventIDObj, srcCompID);
			eueEventUpdate.setUserID(guiAction.getUserID());
			eueEventUpdate.setTs(guiAction.getTime());
			List<EUEObject> objList = guiAction.getUpdateEueObjectList();
			for (EUEObject obj : objList) {
				eueEventUpdate.addEueObject(obj);
			}
			eueEventList.add(eueEventUpdate);
		}
		if (guiAction.getDeleteEueObjectList().size() > 0) {
			ObjectActionEvent eueEventDelete = new DeleteObjectEvent(
					guiAction.getSessionID(), eueEventIDObj, srcCompID);
			eueEventDelete.setUserID(guiAction.getUserID());
			eueEventDelete.setTs(guiAction.getTime());
			List<EUEObject> objList = guiAction.getDeleteEueObjectList();
			for (EUEObject obj : objList) {
				eueEventDelete.addEueObject(obj);
			}
			eueEventList.add(eueEventDelete);
		}
		if (guiAction.getFocusSetEueObjectList().size() > 0) {
			FocusObjectEvent eueEvent = new FocusObjectEvent(
					guiAction.getSessionID(), eueEventIDObj, srcCompID,
					FocusObjectEvent.SET_FOCUS);

			eueEvent.setUserID(guiAction.getUserID());
			eueEvent.setTs(guiAction.getTime());
			List<EUEObject> objList = guiAction.getFocusSetEueObjectList();
			for (EUEObject obj : objList) {
				eueEvent.addEueObject(obj);
			}
			eueEventList.add(eueEvent);
		}
		if (guiAction.getFocusRemovedEueObjectList().size() > 0) {
			FocusObjectEvent eueEvent = new FocusObjectEvent(
					guiAction.getSessionID(), eueEventIDObj, srcCompID,
					FocusObjectEvent.REMOVE_FOCUS);

			eueEvent.setUserID(guiAction.getUserID());
			eueEvent.setTs(guiAction.getTime());
			List<EUEObject> objList = guiAction.getFocusRemovedEueObjectList();
			for (EUEObject obj : objList) {
				eueEvent.addEueObject(obj);
			}
			eueEventList.add(eueEvent);
		}
		return eueEventList;
	}

	private List<UserEvent> createReplayedEvents() {

		List<UserEvent> eventList = new Vector<UserEvent>();
		Vector<String> completedGuiActionIDs = new Vector<String>();

		for (String replayedGuiActionID : replayedGuiActionTracker) {
			if (guiActionTracker.containsKey(replayedGuiActionID)) {
				GUIAction guiAction = guiActionTracker.get(replayedGuiActionID);

				String srcCompID = LASADDataService.class.toString();
				// List<EUEObject> objList = guiAction.getEueObjectList();
				List<EUEObject> objList = guiAction.getCreateEueObjectList();

				long creationDate = guiAction.getCreationDate();
				if (creationDate > 0L) {
					CreateObjectEvent createEvent = new CreateObjectEvent(
							guiAction.getSessionID(),
							EUEEventIDGenerator.getNextID(), srcCompID);
					createEvent.setTs(creationDate);
					createEvent.setUserID(guiAction.getUserID());

					for (EUEObject obj : objList) {
						createEvent.addEueObject(obj);
					}
					eventList.add(createEvent);
				}

				long firstModDate = guiAction.getFirstModDate();
				if (firstModDate > 0L) {
					ModifyObjectEvent firstModEvent = new ModifyObjectEvent(
							guiAction.getSessionID(),
							EUEEventIDGenerator.getNextID(), srcCompID);
					firstModEvent.setTs(firstModDate);
					firstModEvent.setUserID(guiAction.getUserID());

					for (EUEObject obj : objList) {
						EUEObject objNoProp = createEUEObjectWithoutProps(
								obj.getID(), null, obj.getType());
						firstModEvent.addEueObject(objNoProp);
					}
					eventList.add(firstModEvent);
				}

				long modificationDate = guiAction.getModificationDate();
				if (modificationDate > 0L) {
					ModifyObjectEvent modEvent = new ModifyObjectEvent(
							guiAction.getSessionID(),
							EUEEventIDGenerator.getNextID(), srcCompID);
					modEvent.setTs(modificationDate);
					modEvent.setUserID(guiAction.getUserID());

					for (EUEObject obj : objList) {
						EUEObject objNoProp = createEUEObjectWithoutProps(
								obj.getID(), null, obj.getType());
						modEvent.addEueObject(objNoProp);
					}
					eventList.add(modEvent);
				}

			} else {
				logger.error(replayedGuiActionID + " does not exist in tracker");
			}
			completedGuiActionIDs.add(replayedGuiActionID);
		}

		// remove entries from tracker
		for (String key : completedGuiActionIDs) {
			guiActionTracker.remove(key);
		}
		replayedGuiActionTracker.clear();
		return eventList;

	}

	public EUEObject createEUEObjectNew(ParamMap paramMap) {

		EUEObject eueObject = null;

		Map<String, ObjectProperty> props = new HashMap<String, ObjectProperty>();

		// get time and discard action
		String dataType = paramMap.removeAndGetFirst(ParameterTypes.Type); // TYPE
		if (LASADVocabulary.ACTION_PROP_VALUE_AWARENESS
				.equalsIgnoreCase(dataType)
				|| LASADVocabulary.ACTION_PROP_VALUE_AWARENESS_CURSOR
						.equalsIgnoreCase(dataType)
				|| LASADVocabulary.ACTION_PROP_VALUE_GROUP_CURSOR
						.equalsIgnoreCase(dataType)) {
			return null;
		}

		// EUEObject fields
		String objectID = paramMap.removeAndGetFirst(ParameterTypes.Id); // ID
		String nodeType = paramMap.removeAndGetFirst(ParameterTypes.ElementId); // ELEMENT_ID

		// remove params not required
		paramMap.remove(ParameterTypes.Status);

		// "ELEMENT-ID" and "TYPE" are not provided in COMMANDs of type
		// UPDATE-ELEMENT and DELETE-ELEMENT
		if (nodeType == null) {
			if (objectID != null) {
				EUEObjectID objectIDObj = new EUEObjectID(objectID);
				EUEObjectBasicData objPreviousState = getEUEObjectFromTracker(objectIDObj);
				if (objPreviousState == null) {
					logger.debug("node: " + objectID
							+ " is not in tracking system, should have type:"
							+ LASADVocabulary.ACTION_PROP_VALUE_AWARENESS);
					return null;
				}
				nodeType = objPreviousState.getNodeType();
			} else {
				logger.error("Param userID not available");
			}
		}
		if (dataType == null) {
			if (objectID != null) {
				EUEObjectID objectIDObj = new EUEObjectID(objectID);
				EUEObjectBasicData objPreviousState = getEUEObjectFromTracker(objectIDObj);
				if (null == objPreviousState) {
					logger.info("node: " + objectID
							+ " is not in tracking system, should have type:"
							+ LASADVocabulary.ACTION_PROP_VALUE_AWARENESS);
					return null;
				}
				dataType = objPreviousState.getDataType();
			} else {
				logger.error("Param userID not available");
			}
		}

		// create objects and add parent props (i.e., parent of child elements,
		// sources and targets of links)
		if (dataType
				.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_RELATION)) {
			eueObject = createLinkWithoutProps(paramMap);
		} else if (dataType
				.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_BOX)) {
			eueObject = createNodeWithoutProps();
		} else {
			eueObject = createChildElementWithoutProps(paramMap, objectID);
		}

		// add basic props
		EUEObjectID objectIDObj = new EUEObjectID(objectID);
		eueObject.setID(objectIDObj);
		eueObject.setType(nodeType);
		eueObject.setDataType(dataType);

		// add generic props
		Iterator<ParameterTypes> iter = paramMap.keySet().iterator();
		while (iter.hasNext()) {
			ParameterTypes paramType = iter.next();
			String paramValue = paramMap.getFirstValue(paramType);
			String paramTypeString = paramType.getOldParameter();
			SimpleProperty property = new SimpleProperty(paramTypeString,
					paramValue);
			props.put(paramTypeString, property);
		}
		eueObject.addProperties(props);

		// objCurrentState.setId(objectID);
		// objCurrentState.setDataType(dataType);
		// objCurrentState.setNodeType(nodeType);
		// objCurrentState.setUserID(userID);

		return eueObject;

	}

	public EUEObjectBasicData createEUEObjectBasicData(EUEObject newEUEObject,
			String userID) {

		EUEObjectBasicData objBasicData = new EUEObjectBasicData();

		String objID = newEUEObject.getID().getIdAsString();
		objBasicData.setId(objID);
		objBasicData.setDataType(newEUEObject.getDataType());
		objBasicData.setNodeType(newEUEObject.getType());
		objBasicData.setUserID(userID);

		String dataType = newEUEObject.getDataType();
		if (dataType
				.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_RELATION)) {
			objBasicData.getSourceList().addAll(
					((Link) newEUEObject).getSources());
			objBasicData.getTargetList().addAll(
					((Link) newEUEObject).getTargets());
		}

		return objBasicData;
	}

	public EUEObject createEUEObjectWithoutProps(EUEObjectID objectIDObj,
			String dataType, String nodeType) {

		EUEObject eueObject = null;

		if (objectIDObj == null) {
			logger.error("userID not available");
			return null;
		}

		if (nodeType == null) {
			EUEObjectBasicData objectBasicData = getEUEObjectFromTracker(objectIDObj);
			if (null == objectBasicData) {
				logger.info("node: " + objectIDObj.getIdAsString()
						+ " is not in tracking system, :-S:");
				return null;
			}
			nodeType = objectBasicData.getNodeType();
		}
		if (dataType == null) {
			EUEObjectBasicData objectBasicData = getEUEObjectFromTracker(objectIDObj);
			if (objectBasicData == null) {
				logger.info("node: " + objectIDObj.getIdAsString()
						+ " is not in tracking system, :-S:");
				return null;
			}
			dataType = objectBasicData.getDataType();
		}

		// CREATE-ELEMENT
		if (dataType
				.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_RELATION)) {
			eueObject = new Link();
		} else if (dataType
				.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_BOX)) {
			eueObject = new Node();
		} else if (dataType
				.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_GRAPH)) {
		} else {
			eueObject = new Node();
		}

		eueObject.setID(objectIDObj);
		eueObject.setType(nodeType);
		eueObject.setDataType(dataType);

		return eueObject;
	}

	/**
	 * Received ActionPackage: ActionPackage (SESSION-ID->
	 * http://localhost:8081/LASADClientWS) { [ACTION: CATEGORY: FEEDBACK,
	 * COMMAND: REQUEST, PARAMETERS: MAP-ID-> 58, USERNAME-> t1, AGENT-ID->
	 * Event Counter, TYPE-ID-> COUNT_OBJECT_ACTIONS, AGENT-TYPE-> ANALYSIS]}
	 */
	private FeedbackRequestEvent translateFeedbackRequestAction(Action action) {

		String mapID = null;
		String userName = null;
		String agentID = null;
		String serviceID = null;
		String agentType = null;

		for (Parameter aParam : action.getParameters()) {
			ParameterTypes paramType = aParam.getType();
			if (ParameterTypes.MapId == aParam.getType()) {
				mapID = aParam.getValue();
			} else if (ParameterTypes.UserName == paramType) {
				userName = aParam.getValue();
			} else if (ParameterTypes.AgentId == paramType) {
				agentID = aParam.getValue();
			} else if (ParameterTypes.TypeId == paramType) {
				serviceID = aParam.getValue();
			} else if (ParameterTypes.AgentType == paramType) {
				agentType = aParam.getValue();
			}
		}
		if (mapID == null || userName == null || agentID == null
				|| serviceID == null || agentType == null) {
			logger.warn("Incomplete information while creating UserFeedbackRequestEvent: mapID='"
					+ mapID
					+ "', userName='"
					+ userName
					+ "', agentID='"
					+ agentID
					+ "', serviceID='"
					+ serviceID
					+ "', agentType='"
					+ agentType + "'.");
		}

		serviceID = AnalysisAndFeedbackTypeAdapter.getServiceTypeID(mapID,
				serviceID);
		boolean isAnalysisType = LASADVocabulary.ACTION_PROP_VALUE_ANALYSIS
				.equals(agentType) ? true : false;

		FeedbackTypeID feedbackTypeID = new FeedbackTypeID(agentID, serviceID,
				isAnalysisType);
		FeedbackRequestSpec feedbackRequestSpec = new FeedbackRequestSpec(
				feedbackTypeID);

		feedbackRequestSpec.setRequestRawResults(REQUEST_RAW_RESULTS);

		FeedbackRequestEvent feedbackRequestEvent = new FeedbackRequestEvent(
				feedbackRequestSpec, new SessionID(mapID),
				LASADDataService.class.toString(),
				EUEEventIDGenerator.getNextID(), new UserID(userName));
		return feedbackRequestEvent;
	}

	public Ontology translateOntologyInfoEvent(String forMapID,
			ActionPackage actionPackage) {

		List<Action> actions = actionPackage.getActions();
		for (Iterator<Action> iter = actions.iterator(); iter.hasNext();) {

			Action action = iter.next();
			Commands actionCommand = action.getCmd();

			if (Commands.Ontology == actionCommand) {
				// remove action from ActionPackage
				iter.remove();

				String ontologyXML = null;
				String mapID = null;
				for (Parameter aParam : action.getParameters()) {
					ParameterTypes paramType = aParam.getType();
					if (ParameterTypes.MapId == paramType) {
						mapID = aParam.getValue();
					} else if (ParameterTypes.Ontology == paramType) {
						ontologyXML = aParam.getValue();
					}
				}
				if (forMapID.equals(mapID)) {
					return LASADOntologyParser.parseOntology(ontologyXML);
				}
			}
		}
		return null;
	}

	public String getMapIdFromAP(ActionPackage actionPackage) {
		List<Action> actions = actionPackage.getActions();
		Action action = actions.get(0);

		String mapID = null;
		for (Parameter aParam : action.getParameters()) {
			ParameterTypes paramType = aParam.getType();
			if (ParameterTypes.MapId == paramType) {
				mapID = aParam.getValue();
				break;
			}
		}

		return mapID;
	}

	private ParamMap extractParams(List<Parameter> paramList) {
		ParamMap paramMap = new ParamMap();

		for (Parameter param : paramList) {
			ParameterTypes paramType = param.getType();
			String paramValue = param.getValue();

			paramMap.addParam(paramType, paramValue);
		}

		return paramMap;
	}

	public boolean containsHeartbeatRequest(ActionPackage aPackage) {
		List<Action> actionList = aPackage.getActions();
		for (Action action : actionList) {
			if (Commands.HeartbeatRequest == action.getCmd()) {
				return true;
			}
		}
		return false;
	}

	public Node createNodeWithoutProps() {
		Node eueObject = new Node();
		EmptyID parentID = new EmptyID();
		eueObject.setParentID(parentID);
		return eueObject;
	}

	public Node createChildElementWithoutProps(ParamMap paramMap,
			String objectID) {
		Node childElem = new Node();

		List<String> parentPropValues = paramMap
				.getAllValues(ParameterTypes.Parent);

		if (parentPropValues == null) {
			if (objectID != null) {
				EUEObjectID objectIDObj = new EUEObjectID(objectID);
				EUEObjectBasicData objPreviousState = getEUEObjectFromTracker(objectIDObj);
				if (objPreviousState != null) {
					EUEObjectID parentID = new EUEObjectID(
							objPreviousState.getParentID());
					childElem.setParentID(parentID);
				}
			} else {
				logger.error("Param userID not available");
			}
		} else if (parentPropValues.size() >= 1) {
			int source = 0;
			EUEObjectID parentID = new EUEObjectID(parentPropValues.get(source));
			childElem.setParentID(parentID);
		}
		return childElem;
	}

	public Link createLinkWithoutProps(ParamMap paramMap) {
		Link link = new Link();

		List<String> parentPropValues = paramMap.remove(ParameterTypes.Parent);

		if (parentPropValues == null) {
			return link;
		}

		if (parentPropValues.size() >= 1) {
			int source = 0;
			link.addSource(new EUEObjectID(parentPropValues.get(source)));
			logger.debug("Adding source:" + parentPropValues.get(source));
		}
		if (parentPropValues.size() >= 2) {
			int target = 1;
			link.addTarget(new EUEObjectID(parentPropValues.get(target)));
			logger.debug("Adding target:" + parentPropValues.get(target));
		}
		return link;
	}

	private boolean addEUEObjectToTracker(EUEObjectBasicData eueObject) {
		boolean flag = false;
		EUEObjectID eueObjectID = new EUEObjectID(eueObject.getId());
		if (!objectTracker.containsKey(eueObjectID)) {
			objectTracker.put(eueObjectID, eueObject);
			flag = true;
		}
		return flag;
	}

	private boolean deleteEUEObjectFromTracker(String objectID) {
		boolean flag = false;
		EUEObjectID eueObjectID = new EUEObjectID(objectID);
		if (objectTracker.containsKey(eueObjectID)) {
			objectTracker.remove(eueObjectID);
			flag = true;
		}
		return flag;
	}

	private EUEObjectBasicData getEUEObjectFromTracker(EUEObjectID eueObjectID) {
		EUEObjectBasicData tmpEUEObject = null;
		if (objectTracker.containsKey(eueObjectID)) {
			tmpEUEObject = objectTracker.get(eueObjectID);
		}
		return tmpEUEObject;
	}

	private boolean isFeedbackElement(String mapID, String objectID) {
		Set<String> objectsForMap = mapID2feedbackElementIDs.get(mapID);
		if (objectsForMap == null) {
			return false;
		}
		return objectsForMap.contains(objectID);
	}

	public Set<String> getFeedbackMenuItemIDs(String mapID) {
		Set<String> objectsForMap = mapID2feedbackMenuItemIDs.get(mapID);
		if (objectsForMap == null) {
			return new HashSet<String>();
		}
		return objectsForMap;
	}

	public static String getCurrentTime() {
		return String.valueOf(System.currentTimeMillis());
	}

	public static long getCurrentTimeAsLong() {
		return System.currentTimeMillis();
	}

	private class ParamMap {

		private Map<ParameterTypes, List<String>> paramName2ValueList = new HashMap<ParameterTypes, List<String>>();

		public void addParam(ParameterTypes paramType, String paramValue) {
			List<String> paramValues = paramName2ValueList.get(paramType);
			if (paramValues == null) {
				paramValues = new Vector<String>();
				paramName2ValueList.put(paramType, paramValues);
			}
			paramValues.add(paramValue);
		}

		public List<String> getAllValues(ParameterTypes paramType) {
			return paramName2ValueList.get(paramType);
		}

		public String getFirstValue(ParameterTypes paramType) {
			List<String> paramValues = paramName2ValueList.get(paramType);
			if (paramValues == null) {
				return null;
			}
			return paramValues.get(0);
		}

		public List<String> remove(ParameterTypes paramType) {
			return paramName2ValueList.remove(paramType);
		}

		public String removeAndGetFirst(ParameterTypes paramType) {
			List<String> paramValues = paramName2ValueList.remove(paramType);
			if (paramValues == null) {
				return null;
			}
			return paramValues.get(0);
		}

		public boolean containsKey(ParameterTypes paramType) {
			return paramName2ValueList.containsKey(paramType);
		}

		public Set<ParameterTypes> keySet() {
			return paramName2ValueList.keySet();
		}
	}
}
