package de.dfki.lasad.agents.logic.analysis.aggr.tasks;

import java.util.TimerTask;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class AggTask extends TimerTask {

}
