package de.dfki.lasad.sessionmodel.jessfunctions;

/**
 * 
 * @author oliverscheuer
 *
 */
public class SetSelectors {

	public static final String ALL = "ALL";
	public static final String EXISTS = "EXISTS";
	public static final String SET = "SET";
}
