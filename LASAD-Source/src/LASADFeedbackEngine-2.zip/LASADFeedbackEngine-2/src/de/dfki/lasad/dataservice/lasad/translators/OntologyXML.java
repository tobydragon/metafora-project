package de.dfki.lasad.dataservice.lasad.translators;

import java.io.BufferedReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import lasad.shared.dfki.meta.ontology.Ontology;
import lasad.shared.dfki.meta.ontology.base.BaseType;
import lasad.shared.dfki.meta.ontology.base.DropDownType;
import lasad.shared.dfki.meta.ontology.base.MatchedPassageType;
import lasad.shared.dfki.meta.ontology.base.RadioButtonsType;
import lasad.shared.dfki.meta.ontology.base.TranscriptType;
import lasad.shared.dfki.meta.ontology.descr.ElementDescr;
import lasad.shared.dfki.meta.ontology.descr.LinkDescr;
import lasad.shared.dfki.meta.ontology.descr.NodeDescr;
import lasad.shared.dfki.meta.ontology.descr.NonStandardPropDescr;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;


/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class OntologyXML {

	private static Log logger = LogFactory.getLog(OntologyXML.class);

	public static Ontology parseOntology(String ontologyXML) {
		try {
			// Namespace classifierNs = Namespace
			// .getNamespace(classifierDescriptionNS);
			SAXBuilder builder = new SAXBuilder();
			Reader ontologyReader = new StringReader(ontologyXML);
			BufferedReader bufOntologyReader = new BufferedReader(
					ontologyReader);
			Document doc = builder.build(bufOntologyReader);
			Element ontologyElem = doc.getRootElement();

			Attribute ontologyTypeAttr = ontologyElem.getAttribute("type");
			String ontologyTypeText = ontologyTypeAttr.getValue();

			Ontology ontology = new Ontology(ontologyTypeText);

			List<Element> boxesAndLinksElems = ontologyElem
					.getChild("elements").getChildren("element");

			for (Element boxOrLinkElem : boxesAndLinksElems) {
				String elemType = boxOrLinkElem
						.getAttributeValue("elementtype");
				String elemID = boxOrLinkElem.getAttributeValue("elementid");
				ElementDescr elemDescr = null;
				if ("box".equals(elemType)) {
					elemDescr = new NodeDescr(elemID);
					ontology.addNodeDescription((NodeDescr) elemDescr);
				} else if ("relation".equals(elemType)) {
					elemDescr = new LinkDescr(elemID);
					ontology.addLinkDescription((LinkDescr) elemDescr);
				}
				if (elemDescr != null) {
					List<Element> propElems = boxOrLinkElem.getChild(
							"childelements").getChildren("element");

					for (Element propElem : propElems) {
						String propID = propElem.getAttributeValue("elementid");
						String propType = propElem
								.getAttributeValue("elementtype");
						int minquantity = Integer.parseInt(propElem
								.getAttributeValue("minquantity"));
						int maxquantity = Integer.parseInt(propElem
								.getAttributeValue("maxquantity"));

						BaseType baseType = BaseType.getBaseType(propType);

						if (baseType != null) {
							NonStandardPropDescr propDescr = new NonStandardPropDescr(
									baseType, propID, minquantity,
									maxquantity);
							elemDescr.addPropDescr(propDescr);
							if (baseType instanceof RadioButtonsType) {
								List<Element> radiobuttonItemsElems = propElem
										.getChild("radiobuttonitems")
										.getChildren("radiobuttonitem");
								int code = 0;
								Map<String, String> code2value = new HashMap<String, String>();
								for (Element radiobuttonItemElem : radiobuttonItemsElems) {
									String value = radiobuttonItemElem
											.getAttributeValue("label");
									code2value.put(String.valueOf(code), value);
									boolean selected = "1"
											.equals(radiobuttonItemElem
													.getAttributeValue("checked"));
									if (selected) {
										propDescr.setDefaultValue(value);
									}
									++code;
								}
								propDescr.setCodedValues(code2value);
							}

							else if (baseType instanceof DropDownType) {
								Element elemOptionsElem = propElem
										.getChild("elementoptions");
								String defaultValue = elemOptionsElem
										.getAttributeValue("selectedoption");
								propDescr.setDefaultValue(defaultValue);

								String valuesString = elemOptionsElem
										.getAttributeValue("options");
								String[] values = valuesString.split(",");

								Map<String, String> code2value = new HashMap<String, String>();
								for (int code = 0; code < values.length; ++code) {
									String value = values[code].trim();
									code2value.put(String.valueOf(code), value);
								}
								propDescr.setCodedValues(code2value);
							}

							else if (baseType instanceof TranscriptType) {
								NonStandardPropDescr matchedPassagePropDescr = new NonStandardPropDescr(
										MatchedPassageType.getInstance(), propID + "-mp", 0,
										NonStandardPropDescr.UNRESTRICTED);
								elemDescr.addPropDescr(matchedPassagePropDescr);
							}
						} else {
							logger.warn("Unknown propType: " + propType);

						}
					}
				}
			}

			/**
			 * TODO Parse ontology details
			 */
			return ontology;

		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}

	public static SortedSet<String> parseMapTemplateXMLAndExtractResourceIDs(
			String mapTemplateXML) {
		try {

			SortedSet<String> resourceIDs = new TreeSet<String>();

			// Namespace classifierNs = Namespace
			// .getNamespace(classifierDescriptionNS);
			SAXBuilder builder = new SAXBuilder();
			Reader transcriptReader = new StringReader(mapTemplateXML);
			BufferedReader bufTranscriptReader = new BufferedReader(
					transcriptReader);
			Document doc = builder.build(bufTranscriptReader);

			@SuppressWarnings("unchecked")
			List<Element> transcriptElems = doc.getRootElement().getChildren(
					"transcript");

			for (Element transcriptElem : transcriptElems) {
				Attribute transcriptIDAttr = transcriptElem.getAttribute("id");
				String transcriptID = transcriptIDAttr.getValue();
				resourceIDs.add(transcriptID);
			}

			return resourceIDs;

		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}

}
