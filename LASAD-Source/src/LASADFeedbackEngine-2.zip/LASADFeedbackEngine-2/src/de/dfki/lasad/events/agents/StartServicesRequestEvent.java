package de.dfki.lasad.events.agents;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.agents.data.meta.ServiceType;
import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.session.data.SessionID;

/**
 * Request to publish feedback services in the EUE for a given session
 * 
 * @author oliverscheuer
 * 
 */
public class StartServicesRequestEvent extends SessionEvent {

	private List<ServiceType> services = new Vector<ServiceType>();

	public StartServicesRequestEvent(SessionID sessionID, String srcCompId) {
		super(sessionID, srcCompId);
	}

	public List<ServiceType> getServices() {
		return services;
	}

	public void setServices(List<ServiceType> services) {
		this.services = services;
	}

}
