package de.dfki.lasad.agents.logic.provision.phases.xml;

import lasad.shared.dfki.meta.agents.analysis.phases.PhaseModelerDef_Empirical;
import lasad.shared.dfki.meta.agents.analysis.phases.PhasesDef;
import lasad.shared.dfki.meta.agents.common.ActionListDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class PhaseModelerDef_EmpiricalXML extends PhaseModelerDefXML {

	private static Log logger = LogFactory
			.getLog(PhaseModelerDef_EmpiricalXML.class);

	public static final String TYPE = "empirical";

	public static PhaseModelerDef_Empirical fromXML(String agentID,
			Element phaseModelerElem) {

		PhasesDef phasesDef = getPhasesDef(phaseModelerElem);
		ActionListDef relevantActions = getRelevantActionsDef(agentID,
				phaseModelerElem);

		PhaseModelerDef_Empirical phaseModelerDef = new PhaseModelerDef_Empirical(
				phasesDef, relevantActions);
		return phaseModelerDef;
	}

	protected static ActionListDef getRelevantActionsDef(String agentID,
			Element phaseModelerEmpElem) {
		Element relActionsElem = phaseModelerEmpElem
				.getChild(RelevantActionsDefXML.ELEMENT_NAME);
		ActionListDef relActions = RelevantActionsDefXML.fromXML(agentID,
				relActionsElem);
		return relActions;
	}

	public static Element toXML(PhaseModelerDef_Empirical phaseModelDef) {
		Element phaseModelElem = createPhaseModelElement(TYPE);

		PhasesDef phasesDef = phaseModelDef.getPhaseDef();
		addPhasesDefElem(phaseModelElem, phasesDef);

		ActionListDef relActionsDef = phaseModelDef.getRelevantActions();
		addRelevantActionsDefElem(phaseModelElem, relActionsDef);

		return phaseModelElem;
	}

	protected static void addRelevantActionsDefElem(Element phaseModelElem,
			ActionListDef relActionsDef) {
		Element relActionsDefElem = RelevantActionsDefXML.toXML(relActionsDef);
		phaseModelElem.addContent(relActionsDefElem);
	}
}
