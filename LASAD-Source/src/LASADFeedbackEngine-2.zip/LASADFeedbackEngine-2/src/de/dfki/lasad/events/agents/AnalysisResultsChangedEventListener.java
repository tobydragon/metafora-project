package de.dfki.lasad.events.agents;

/**
 * 
 * @author oliverscheuer
 * 
 */
public interface AnalysisResultsChangedEventListener {

	public void onAnalysisResultsChangedEvent(AnalysisResultsChangedEvent event);
}
