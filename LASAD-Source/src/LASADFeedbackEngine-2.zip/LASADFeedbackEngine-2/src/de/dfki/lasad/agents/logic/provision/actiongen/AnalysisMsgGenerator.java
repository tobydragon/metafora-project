package de.dfki.lasad.agents.logic.provision.actiongen;

import java.util.List;

import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import de.dfki.lasad.agents.data.action.AgentAction;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.NoAnalysisResults;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AnalysisMsgGenerator {

	private String parentCmpID = null;
	private SessionID sID = null;

	public AnalysisMsgGenerator(String parentCmpID, SessionID sID) {
		this.parentCmpID = parentCmpID;
		this.sID = sID;
	}

	public ActionSpecEvent generateMsg(AnalysisType aType,
			List<AnalysisResult> orderedResultList, UserID recipientID) {
		ActionSpecEvent actionSpecEvent = new ActionSpecEvent(sID, parentCmpID);

		AgentAction aSpec = new AgentAction();

		if (orderedResultList.size() == 0) {
			// add indicator for no result
			NoAnalysisResults noResults = new NoAnalysisResults(aType);
			orderedResultList.add(noResults);
		}
		for (AnalysisResult result : orderedResultList) {
			aSpec.addActionComponent(result);
		}
		aSpec.setActionRecipient(recipientID);
		actionSpecEvent.addActionSpec(aSpec);
		return actionSpecEvent;
	}
}
