package de.dfki.lasad.agents.logic.analysis.types.structure.test;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ComparisonToVarSimplified extends ComparisonSimplified {

	String rhsVarID;
	int rhsSeqNum;
	String rhsPropID;
	String rhsPropCompID;

	@Override
	boolean isEquivalent(ComparisonSimplified other) {
		if (equals(other)) {
			return true;
		}
		if (!(other instanceof ComparisonToVarSimplified)) {
			return false;
		}
		ComparisonToVarSimplified otherVarComparison = (ComparisonToVarSimplified) other;

		// check whether 'other' is a correct 'inverse' comparison
		boolean varIDCorrect = lhsVarID.equals(otherVarComparison.rhsVarID);
		boolean propIDCorrect = lhsPropID.equals(otherVarComparison.rhsPropID);
		boolean propCompIDCorrect = lhsPropCompID
				.equals(otherVarComparison.rhsPropCompID);
		boolean operatorCorrect = operator.invert().equals(
				otherVarComparison.operator);

		return varIDCorrect && propIDCorrect && propCompIDCorrect
				&& operatorCorrect;
	}

	boolean rightOrder() {
		return lhsSeqNum >= rhsSeqNum;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((rhsPropCompID == null) ? 0 : rhsPropCompID.hashCode());
		result = prime * result
				+ ((rhsPropID == null) ? 0 : rhsPropID.hashCode());
		result = prime * result
				+ ((rhsVarID == null) ? 0 : rhsVarID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ComparisonToVarSimplified other = (ComparisonToVarSimplified) obj;
		if (rhsPropCompID == null) {
			if (other.rhsPropCompID != null)
				return false;
		} else if (!rhsPropCompID.equals(other.rhsPropCompID))
			return false;
		if (rhsPropID == null) {
			if (other.rhsPropID != null)
				return false;
		} else if (!rhsPropID.equals(other.rhsPropID))
			return false;
		if (rhsVarID == null) {
			if (other.rhsVarID != null)
				return false;
		} else if (!rhsVarID.equals(other.rhsVarID))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "[patternID=" + patternID + ", comparisonID=" + comparisonID
				+ ", isInternalComparison=" + isInternalComparison + ", bin="
				+ binClassification + ", lhsVarID=" + lhsVarID + ", lhsSeqNum="
				+ lhsSeqNum + ", lhsPropID=" + lhsPropID + ", lhsPropCompID="
				+ lhsPropCompID + ", operator=" + operator + ", rhsVarID="
				+ rhsVarID + ", rhsSeqNum=" + rhsSeqNum + ", rhsPropID="
				+ rhsPropID + ", rhsPropCompID=" + rhsPropCompID
				+ ", use-jess-const-fact=" + useJessConstantSetFact
				+ ", debug-info=" + debugInfo + "]";
	}

}
