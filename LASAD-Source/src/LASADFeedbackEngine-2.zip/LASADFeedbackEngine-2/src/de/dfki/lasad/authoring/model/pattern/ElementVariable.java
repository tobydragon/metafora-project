package de.dfki.lasad.authoring.model.pattern;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import de.dfki.lasad.session.data.meta.ontology.ElementDescr;
import de.dfki.lasad.session.data.meta.ontology.NonStandardPropDescr;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;
import de.dfki.lasad.session.data.meta.ontology.StandardPropDescr;

/**
 * Represents an element (i.e., node or link) within a {@link Pattern}.
 * {@link ElementVariable}s are typically restricted in some way to match only
 * specific elements (see {@link ElementConstr}).
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public abstract class ElementVariable {

	// standard fields
	private String varID;

	// supplemental fields
	/**
	 * All types this {@link ElementVariable} can potentially have, based on the
	 * given type constraints defined in the corresponding {@link ElementConstr}
	 * .
	 */
	private List<ElementDescr> possibleTypes = new Vector<ElementDescr>();

	/**
	 * All standard properties this {@link ElementVariable} has for sure.
	 */
	private List<StandardPropDescr> standardProps = new Vector<StandardPropDescr>();

	/**
	 * All non-standard properties this {@link ElementVariable} has for sure.
	 * This is the intersection of all non-standard properties of all
	 * {@link #possibleTypes}.
	 */
	private List<NonStandardPropDescr> nonStandardProps = new Vector<NonStandardPropDescr>();

	/**
	 * Index data structure that allows retrieving {@link PropertyVariable}s of
	 * this {@link ElementVariable} based on a {@link PropDescr} and a property
	 * component ID.
	 */
	private Map<PropDescr, Map<String, PropertyVariable>> prop2Comps2Vars = new HashMap<PropDescr, Map<String, PropertyVariable>>();

	public String getVarID() {
		return varID;
	}

	public void setVarID(String varID) {
		this.varID = varID;
	}

	public List<ElementDescr> getPossibleTypes() {
		return possibleTypes;
	}

	public void setPossibleTypes(List<ElementDescr> possibleTypes) {
		this.possibleTypes = possibleTypes;
	}

	public List<StandardPropDescr> getStandardProps() {
		return standardProps;
	}

	public void setStandardProps(List<StandardPropDescr> standardProps) {
		this.standardProps = standardProps;
	}

	public Map<PropDescr, Map<String, PropertyVariable>> getProp2Comps2Vars() {
		return prop2Comps2Vars;
	}

	public void setProp2Comps2Vars(
			Map<PropDescr, Map<String, PropertyVariable>> prop2Comps2Vars) {
		this.prop2Comps2Vars = prop2Comps2Vars;
	}

	public List<NonStandardPropDescr> getNonStandardProps() {
		return nonStandardProps;
	}

	public void setNonStandardProps(List<NonStandardPropDescr> nonStandardProps) {
		this.nonStandardProps = nonStandardProps;
	}

	public List<PropDescr> getProps() {
		List<PropDescr> props = new Vector<PropDescr>();
		props.addAll(getStandardProps());
		props.addAll(getNonStandardProps());
		return props;
	}

	public PropertyVariable getPropVar(PropDescr prop, String componentID) {
		Map<String, PropertyVariable> compID2Var = prop2Comps2Vars.get(prop);
		if (compID2Var == null) {
			return null;
		}
		PropertyVariable propVar = compID2Var.get(componentID);
		return propVar;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((varID == null) ? 0 : varID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ElementVariable other = (ElementVariable) obj;
		if (varID == null) {
			if (other.varID != null)
				return false;
		} else if (!varID.equals(other.varID))
			return false;
		return true;
	}

	public PropDescr getProperty(String propId) {
		PropDescr prop = null;
		for (PropDescr p : getProps()) {
			if (propId.equals(p.getPropID())) {
				prop = p;
				break;
			}
		}
		return prop;
	}

}
