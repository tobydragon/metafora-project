package de.dfki.lasad.session.data.meta.ontology;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ModifiersPropDescr extends StandardPropDescr {

	public ModifiersPropDescr() {
		super("modifiers", "elem_modifier", "user", JessDataType.STRING, ComparisonGroup.USER);
	}
}
