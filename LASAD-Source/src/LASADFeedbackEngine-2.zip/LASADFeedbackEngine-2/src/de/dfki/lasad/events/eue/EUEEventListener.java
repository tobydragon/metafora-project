package de.dfki.lasad.events.eue;




public interface EUEEventListener {

	public void onEUEEvent(EUEEvent event);
}
