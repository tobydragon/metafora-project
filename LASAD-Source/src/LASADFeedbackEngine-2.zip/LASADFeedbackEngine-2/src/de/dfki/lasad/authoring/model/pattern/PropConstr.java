package de.dfki.lasad.authoring.model.pattern;

import java.util.List;

/**
 * All constraints (see {@link Comparison}s) that apply to a some
 * {@link PropertyVariable}.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class PropConstr {
	private PropertyVariable propVar;
	private List<Comparison> comparisons;

	public PropertyVariable getPropVar() {
		return propVar;
	}

	public void setPropVar(PropertyVariable propVar) {
		this.propVar = propVar;
	}

	public List<Comparison> getComparisons() {
		return comparisons;
	}

	public void setComparisons(List<Comparison> comparisons) {
		this.comparisons = comparisons;
	}

	public void removeComparison(Comparison comparison) {
		for (int i = 0; i < comparisons.size(); i++) {
			Comparison c = comparisons.get(i);
			if (c.equals(comparison)) {
				comparisons.remove(i);
			}
		}
	}
}
