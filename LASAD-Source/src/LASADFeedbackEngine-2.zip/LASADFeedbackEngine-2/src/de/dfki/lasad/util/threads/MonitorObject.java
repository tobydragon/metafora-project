package de.dfki.lasad.util.threads;

/**
 * 
 * @author oliverscheuer
 *
 */
public class MonitorObject {

}
