package de.dfki.lasad.authoring.converter.pattern2jess;

import java.util.List;

import de.dfki.lasad.authoring.model.pattern.ElementConstr;
import de.dfki.lasad.authoring.model.pattern.ElementVariable;
import de.dfki.lasad.authoring.model.pattern.LinkConstr;
import de.dfki.lasad.authoring.model.pattern.NodeConstr;
import de.dfki.lasad.authoring.model.pattern.Pattern;
import de.dfki.lasad.session.data.meta.Ontology;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PatternTranslator {

	private PatternPreprocessor preprocessor = new PatternPreprocessor();
	private JessConstValDeffactGenerator constGen = new JessConstValDeffactGenerator();
	private JessClauseGenerator clauseGen = new JessClauseGenerator();

	public static final String INDENT_L0 = "";
	public static final String INDENT_L1 = " ";
	public static final String INDENT_L2 = "   ";

	public String generateJessPattern(String agentID, Pattern pattern,
			Ontology ontology) {

		StringBuffer result = new StringBuffer();
		result.append(";; Pattern-ID: " + pattern.getID() + "\n");

		preprocessor.preprocess(pattern, ontology);

		result.append(Indent.apply(generateImports() + "\n\n", INDENT_L0));
		result.append(Indent.apply(";; Constant values used as constraints " + "\n",INDENT_L0));
		result.append(Indent.apply(";;;;;;;;;;; " + "\n", INDENT_L0));
		result.append(Indent.apply(generateConstValDeffacts(pattern),INDENT_L0));
		result.append(Indent.apply("(defrule " + pattern.getID() + "\n", INDENT_L0));
		result.append(Indent.apply("(logical" + "\n", INDENT_L1));

		result.append(Indent.apply(";; Node constraints " + "\n", INDENT_L2));
		result.append(Indent.apply(";;;;;;;;;;; " + "\n", INDENT_L2));
		result.append(Indent.apply(generateNodeConstrs(pattern), INDENT_L2));

		result.append(Indent.apply(";; Link constraints " + "\n", INDENT_L2));
		result.append(Indent.apply(";;;;;;;;;;; " + "\n", INDENT_L2));
		result.append(Indent.apply(generateLinkConstrs(pattern) + ")\n", INDENT_L2));
		
		result.append(Indent.apply("=>" + "\n", INDENT_L1));
		result.append(Indent.apply("(printout t \"MATCH: \" " + generateRuleID(agentID, pattern) + " crlf))" + "\n", INDENT_L1));

		return result.toString();
	}

	public String generateConstValDeffacts(Pattern pattern) {
		return constGen.generateConstValDeffacts(pattern) + "\n";
	}

	public String generateNodeConstrs(Pattern pattern) {
		return generateElemConstrs(pattern, pattern.getNodeConstrs());
	}

	public String generateLinkConstrs(Pattern pattern) {
		return generateElemConstrs(pattern, pattern.getLinkConstrs());
	}

	private String generateElemConstrs(Pattern pattern,
			List<? extends ElementConstr> elemConstrs) {
		StringBuffer result = new StringBuffer();

		for (ElementConstr elemConstr : elemConstrs) {
			List<? extends ElementConstr> predecessors;
			if (elemConstr instanceof NodeConstr) {
				NodeConstr nodeConstr = (NodeConstr) elemConstr;
				predecessors = pattern.getNodePredecessors(nodeConstr);

				result.append(";; Bin-1-External" + "\n");
				result.append(clauseGen.generateNodeExtConstrsClause(
						nodeConstr, predecessors));
				result.append(";; PropFact Variable bindings " + "\n");
				result.append(clauseGen
						.generatePropVarBindingClauses(nodeConstr));
				result.append(";; Bin-1-Internal " + "\n");
				result.append(clauseGen
						.generateNodeIntConstrsClause(nodeConstr));

			} else {
				// LinkConstr
				LinkConstr linkConstr = (LinkConstr) elemConstr;
				predecessors = pattern.getLinkPredecessors(linkConstr);

				result.append(";; Bin-1-External" + "\n");
				result.append(clauseGen.generateLinkExtConstrsClause(
						linkConstr, predecessors));
				result.append(";; PropFact Variable bindings " + "\n");
				result.append(clauseGen
						.generatePropVarBindingClauses(linkConstr));
				result.append(";; Bin-1-Internal " + "\n");
				result.append(clauseGen
						.generateLinkIntConstrsClause(linkConstr));

			}

			ElementVariable elemVar = elemConstr.getElemVar();
			for (PropDescr prop : elemVar.getProps()) {

				result.append(";; Property: " + prop.getPropID() + "\n");
				result.append(clauseGen.generatePropClauses(elemConstr, prop));

				result.append(clauseGen.generatePropExistsClauses(elemConstr,
						prop));
				result.append(clauseGen.generatePropForallClauses(elemConstr,
						prop));
				result.append(clauseGen.generateRefPropExistsClauses(
						elemConstr, prop));
				result.append(clauseGen.generateRefPropForallClauses(
						elemConstr, prop));

				result.append(clauseGen.generatePropExistsForallClauses(
						elemConstr, prop));
				result.append(clauseGen.generatePropExistsExistsClauses(
						elemConstr, prop));
				result.append(clauseGen.generatePropForallForallClauses(
						elemConstr, prop));
				result.append(clauseGen.generatePropForallExistsClauses(
						elemConstr, prop));
				result.append(clauseGen.generateRefPropExistsForallClauses(
						elemConstr, prop));
				result.append(clauseGen.generateRefPropForallExistsClauses(
						elemConstr, prop));

				result.append(clauseGen.generateElemExistsForallClauses(
						elemConstr, prop));
				result.append(clauseGen.generateElemExistsExistsClauses(
						elemConstr, prop));
				result.append(clauseGen.generateElemForallForallClauses(
						elemConstr, prop));
				result.append(clauseGen.generateElemForallExistsClauses(
						elemConstr, prop));
				result.append(clauseGen.generateRefElemExistsForallClauses(
						elemConstr, prop));
				result.append(clauseGen.generateRefElemForallExistsClauses(
						elemConstr, prop));

				result.append(clauseGen.generateRefConstForallExistsClauses(
						pattern, elemConstr, prop));
				result.append(clauseGen.generateRefConstExistsForallClauses(
						pattern, elemConstr, prop));
			}
		}
		return result.toString();
	}

	private String generateRuleID(String agentID, Pattern p) {
		return agentID + p.getID();
	}

	private String generateImports() {
		return "(require basic_definitions)";
	}

	
}
