package de.dfki.lasad.dataservice.lasad.translators;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.ActionPackage;
import lasad.shared.communication.objects.parameters.ParameterTypes;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.action.ActionComponent;
import de.dfki.lasad.agents.data.action.AgentAction;
import de.dfki.lasad.agents.data.action.Message;
import de.dfki.lasad.agents.data.action.MessageWithHighlighting;
import de.dfki.lasad.agents.data.action.XmppActionComponent;
import de.dfki.lasad.agents.data.action.XmppActionSpec;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.NoAnalysisResults;
import de.dfki.lasad.agents.data.analysis.object.AnalyzableEntity;
import de.dfki.lasad.agents.data.analysis.object.ObjectBinaryResult;
import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.agents.instances.xmpp.xmppaction.CfActionDuringExecution;
import de.dfki.lasad.core.DisplayedObjectIDTracker;
import de.dfki.lasad.dataservice.lasad.ActionPackageFactory;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.session.data.EUEID;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.UserIDAll;
import de.dfki.lasad.session.data.objects.EUEObjectID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class EventTranslatorAF2LASAD {

	Log logger = LogFactory.getLog(EventTranslatorAF2LASAD.class);

	private ActionPackageFactory packageFactory;

	public EventTranslatorAF2LASAD(ActionPackageFactory packageFactory) {
		this.packageFactory = packageFactory;
	}

	public List<ActionPackage> translate(ActionSpecEvent actionSpecEvent) {
		SessionID sessionID = actionSpecEvent.getSessionID();

		List<ActionPackage> actionPackages = new Vector<ActionPackage>();
		for (AgentAction action : actionSpecEvent.getAgentActions()) {
			actionPackages.addAll(translateActionSpec(action, sessionID));
		}

		return actionPackages;
	}

	private List<ActionPackage> translateActionSpec(AgentAction agentAction,
			SessionID sessionID) {
		UserID userID = agentAction.getActionRecipient();
		List<ActionPackage> actionPackages = new Vector<ActionPackage>();
		List<Action> actionsToSend = new Vector<Action>();

		// this actions may happen outside of a session(map) so they do not need
		// a sessionID
		if (agentAction instanceof XmppActionSpec) {
			actionPackages.add(translateXmppActionSpec(
					(XmppActionSpec) agentAction, sessionID));
		}

		// these actions require a sessionID
		if (sessionID != null) {

			Set<ActionComponent> actionComponents = agentAction
					.getActionComponents();

			String mapID = sessionID.getIdAsString();
			String recipientID = getRecipientID(userID);

			Map<AnalysisType, Boolean> types2AtLeast1PosResults = new HashMap<AnalysisType, Boolean>();

			boolean createAction = false;
			for (ActionComponent aComp : actionComponents) {
				List<String> highlightableObjectIDs = new Vector<String>();
				Map<ParameterTypes, String> additionalParams = new HashMap<ParameterTypes, String>();
				String shortMessageString = "NOT SPECIFIED";
				String longMessageString = null;

				if (aComp instanceof Message) {
					Message message = (Message) aComp;
					shortMessageString = message.getMessageShort();
					longMessageString = message.getMessageLong();
					if (message.isResponsePrompt()) {
						additionalParams.put(ParameterTypes.ResponseRequired,
								String.valueOf(true));
					} else{
						additionalParams.put(ParameterTypes.ResponseRequired,
								String.valueOf(false));
					}
					createAction = true;
				}
				if (aComp instanceof MessageWithHighlighting) {
					MessageWithHighlighting highlighting = (MessageWithHighlighting) aComp;
					AnalyzableEntity entity = highlighting
							.getAnalyzableEntity();
					for (EUEID componentID : entity.getEntityComponents()) {
						highlightableObjectIDs.add(componentID.getIdAsString());
					}
				}
				if (aComp instanceof AnalysisResult) {
					AnalysisResult analysisResult = (AnalysisResult) aComp;
					AnalysisType aType = analysisResult.getAnalysisType();

					if (!types2AtLeast1PosResults.containsKey(aType)) {
						types2AtLeast1PosResults.put(aType, false);
					}

					if (!isNegativeBinaryResults(analysisResult)
							&& !noResultsForGivenAnalysisType(analysisResult)) {
						types2AtLeast1PosResults.put(aType, true);
						createAction = true;
						AnalysisType analysisType = analysisResult
								.getAnalysisType();
						String messageP1_category = analysisType.getName();
						if (messageP1_category == null) {
							messageP1_category = analysisType.getServiceID()
									.toString();
						}

						String messageP2_objectDisplayIDs = composeDisplayIDsString(
								analysisResult, sessionID);
						String messageP3_value = composeValueString(analysisResult);

						shortMessageString = messageP1_category
								+ messageP2_objectDisplayIDs + messageP3_value;

						highlightableObjectIDs = getHighlightableObjects(analysisResult);
					}
				}

				if (createAction) {
					Action textMessageAction = packageFactory
							.createFeedbackMessage(mapID, recipientID,
									shortMessageString, longMessageString,
									highlightableObjectIDs, additionalParams);
					actionsToSend.add(textMessageAction);
					createAction = false;
				}
			}

			for (AnalysisType aType : types2AtLeast1PosResults.keySet()) {
				boolean atLeast1PosResults = types2AtLeast1PosResults
						.get(aType);
				if (!atLeast1PosResults) {
					Action noResult = getNoPositiveResultsMessage(sessionID,
							userID, aType);
					actionsToSend.add(noResult);
				}
			}

			if (actionsToSend.size() > 0) {
				ActionPackage aPackage = packageFactory
						.createActionPackage(actionsToSend);
				actionPackages.add(aPackage);
			}
		}
		return actionPackages;
	}

	private ActionPackage translateXmppActionSpec(XmppActionSpec actionSpec,
			SessionID username) {
		List<Action> actionsToSend = new Vector<Action>();

		for (ActionComponent aComponent : actionSpec.getActionComponents()) {
			if (aComponent instanceof XmppActionComponent) {
				CfActionDuringExecution xmppAction = ((XmppActionComponent) aComponent)
						.getAction();
				actionsToSend.addAll(xmppAction.buildLasadActions());
			}
		}

		ActionPackage aPackage = packageFactory
				.createActionPackage(actionsToSend);
		return aPackage;
	}

	private Action getNoPositiveResultsMessage(SessionID sessionID,
			UserID userID, AnalysisType aType) {

		String displayName = aType.getName();
		if (displayName == null) {
			displayName = aType.getServiceID().toString();
		}
		String message = "No results for " + displayName;

		String mapID = sessionID.getIdAsString();
		String recipientID = getRecipientID(userID);

		List<String> highlightableObjectIDs = new Vector<String>();

		Action clusterIndicator = packageFactory.createFeedbackMessage(mapID,
				recipientID, message, null, highlightableObjectIDs,
				new HashMap<ParameterTypes, String>());

		return clusterIndicator;
	}

	private String composeDisplayIDsString(AnalysisResult analysisResult,
			SessionID sessionID) {
		String messageP2_objectDisplayIDs = "";

		if (analysisResult instanceof ObjectBinaryResult) {
			ObjectBinaryResult pattern = (ObjectBinaryResult) analysisResult;
			boolean isFirst = true;
			for (EUEID eueID : pattern.getAnalyzedEntity()
					.getEntityComponents()) {
				String displayID = DisplayedObjectIDTracker.getDisplayID(
						sessionID, eueID);

				String entityType = "";
				if (eueID instanceof EUEObjectID) {
					entityType = "Element(s)";
				}

				if (displayID != null) {
					if (isFirst) {
						messageP2_objectDisplayIDs += "; " + entityType + ": ";
					} else {
						messageP2_objectDisplayIDs += ", ";
					}
					messageP2_objectDisplayIDs += displayID;
					isFirst = false;
				}
			}
		}
		return messageP2_objectDisplayIDs;
	}

	private String composeValueString(AnalysisResult analysisResult) {
		if (analysisResult instanceof ObjectBinaryResult) {
			return "";
		} else {
			return analysisResult.getValueAsString();
		}
	}

	private String getRecipientID(UserID userID) {
		if (userID instanceof UserIDAll) {
			return "";
		} else {
			return userID.getIdAsString();
		}
	}

	private boolean isNegativeBinaryResults(AnalysisResult analysisResult) {
		if (analysisResult instanceof ObjectBinaryResult) {
			ObjectBinaryResult bResult = (ObjectBinaryResult) analysisResult;
			if (bResult.getValue() == false) {
				return true;
			}

		}
		return false;
	}

	private boolean noResultsForGivenAnalysisType(AnalysisResult analysisResult) {
		return analysisResult instanceof NoAnalysisResults;
	}

	private List<String> getHighlightableObjects(AnalysisResult analysisResult) {
		List<String> idList = new Vector<String>();

		if (analysisResult instanceof ObjectResult) {
			ObjectResult objectResult = (ObjectResult) analysisResult;
			for (EUEID eueID : objectResult.getAnalyzedEntity()
					.getEntityComponents()) {
				if (eueID instanceof EUEObjectID) {
					idList.add(eueID.getIdAsString());
				}
			}
		}
		return idList;
	}
}
