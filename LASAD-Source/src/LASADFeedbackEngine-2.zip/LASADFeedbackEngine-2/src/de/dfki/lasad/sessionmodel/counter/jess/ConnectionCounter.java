package de.dfki.lasad.sessionmodel.counter.jess;

import java.util.Arrays;
import java.util.Set;

import jess.Context;
import jess.JessException;
import jess.RU;
import jess.Userfunction;
import jess.Value;
import jess.ValueVector;

import de.dfki.lasad.sessionmodel.counter.GraphObject;
import de.dfki.lasad.sessionmodel.counter.Index;
import de.dfki.lasad.sessionmodel.counter.constraints.NumConstr;
import de.dfki.lasad.sessionmodel.counter.constraints.SetConstr;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ConnectionCounter implements Userfunction {

	private Log logger = LogFactory.getLog(ConnectionCounter.class);

	public ConnectionCounter() {
		super();
	}

	@Override
	public String getName() {
		return "count-connections";
	}

	@Override
	public Value call(ValueVector vv, final Context context)
			throws JessException {

		logger.info("Counting function called ... ");

		if (vv.size() != 14) {
			throw new JessException(
					getName(),
					getName()
							+ " takes 13 arguments: the index ds, a ref node ID, the ref node role, "
							+ "a link type constrs list, a link creator constrs list, "
							+ "a link modifiers constrs list, a link first-ts constrs list, "
							+ "a link last-ts constrs list, a node type constrs list, "
							+ "a node creator constrs list, a node modifiers constrs list, "
							+ "a node first-ts constrs list, and a node last-ts constrs list.",
					vv.size() - 1);
		}

		Value indexVal = vv.get(1).resolveValue(context);
		Index index = (Index) indexVal.javaObjectValue(context);

		Value refNodeIDVal = vv.get(2).resolveValue(context);
		String refNodeID = refNodeIDVal.stringValue(context);

		Value refNodeRoleVal = vv.get(3).resolveValue(context);
		String refNodeRole = refNodeRoleVal.stringValue(context);

		ValueVector linkTypeConstrsVal = vv.get(4).listValue(context);
		SetConstr[] linkTypeConstrs = new SetConstr[linkTypeConstrsVal.size()];
		for (int i = 0; i < linkTypeConstrsVal.size(); ++i) {
			// VALID OPERATORS: (SCALAR REF-VAL) EQUALS, NOT_EQUALS, (SET
			// REF-VAL) IN, NOT_IN
			SetConstr constr = (SetConstr) linkTypeConstrsVal.get(i)
					.javaObjectValue(context);
			linkTypeConstrs[i] = constr;
		}

		ValueVector linkCreatorConstrsVal = vv.get(5).listValue(context);
		SetConstr[] linkCreatorConstrs = new SetConstr[linkCreatorConstrsVal
				.size()];
		for (int i = 0; i < linkCreatorConstrsVal.size(); ++i) {
			// VALID OPERATORS: (SCALAR REF-VAL) EQUALS, NOT_EQUALS, (SET
			// REF-VAL) IN, NOT_IN
			SetConstr constr = (SetConstr) linkCreatorConstrsVal.get(i)
					.javaObjectValue(context);
			linkCreatorConstrs[i] = constr;
		}

		ValueVector linkModifiersConstrsVal = vv.get(6).listValue(context);
		SetConstr[] linkModifiersConstrs = new SetConstr[linkModifiersConstrsVal
				.size()];
		for (int i = 0; i < linkModifiersConstrsVal.size(); ++i) {
			// VALID OPERATORS: EQUALS, NOT_EQUALS, SUBSET, NOT_SUBSET,
			// SUPERSET, NOT_SUPERSET
			// DISJOINT, NOT_DISJOINT
			SetConstr constr = (SetConstr) linkModifiersConstrsVal.get(i)
					.javaObjectValue(context);
			linkModifiersConstrs[i] = constr;
		}

		ValueVector linkFirstTSConstrsVal = vv.get(7).listValue(context);
		NumConstr[] linkFirstTSConstrs = new NumConstr[linkFirstTSConstrsVal
				.size()];
		for (int i = 0; i < linkFirstTSConstrsVal.size(); ++i) {
			// VALID OPERATORS: GREATER, LESS
			NumConstr constr = (NumConstr) linkFirstTSConstrsVal.get(i)
					.javaObjectValue(context);
			linkFirstTSConstrs[i] = constr;
		}

		ValueVector linkLastTSConstrsVal = vv.get(8).listValue(context);
		NumConstr[] linkLastTSConstrs = new NumConstr[linkLastTSConstrsVal
				.size()];
		for (int i = 0; i < linkLastTSConstrsVal.size(); ++i) {
			// VALID OPERATORS: GREATER, LESS
			NumConstr constr = (NumConstr) linkLastTSConstrsVal.get(i)
					.javaObjectValue(context);
			linkLastTSConstrs[i] = constr;
		}

		ValueVector nodeTypeConstrsVal = vv.get(9).listValue(context);
		SetConstr[] nodeTypeConstrs = new SetConstr[nodeTypeConstrsVal.size()];
		for (int i = 0; i < nodeTypeConstrsVal.size(); ++i) {
			// VALID OPERATORS: (SCALAR REF-VAL) EQUALS, NOT_EQUALS, (SET
			// REF-VAL) IN, NOT_IN
			SetConstr constr = (SetConstr) nodeTypeConstrsVal.get(i)
					.javaObjectValue(context);
			nodeTypeConstrs[i] = constr;
		}

		ValueVector nodeCreatorConstrsVal = vv.get(10).listValue(context);
		SetConstr[] nodeCreatorConstrs = new SetConstr[nodeCreatorConstrsVal
				.size()];
		for (int i = 0; i < nodeCreatorConstrsVal.size(); ++i) {
			// VALID OPERATORS: (SCALAR REF-VAL) EQUALS, NOT_EQUALS, (SET
			// REF-VAL) IN, NOT_IN
			SetConstr constr = (SetConstr) nodeCreatorConstrsVal.get(i)
					.javaObjectValue(context);
			nodeCreatorConstrs[i] = constr;
		}

		ValueVector nodeModifiersConstrsVal = vv.get(11).listValue(context);
		SetConstr[] nodeModifiersConstrs = new SetConstr[nodeModifiersConstrsVal
				.size()];
		for (int i = 0; i < nodeModifiersConstrsVal.size(); ++i) {
			// VALID OPERATORS: EQUALS, NOT_EQUALS, SUBSET, NOT_SUBSET,
			// SUPERSET, NOT_SUPERSET
			// DISJOINT, NOT_DISJOINT
			SetConstr constr = (SetConstr) nodeModifiersConstrsVal.get(i)
					.javaObjectValue(context);
			nodeModifiersConstrs[i] = constr;
		}

		ValueVector nodeFirstTSConstrsVal = vv.get(12).listValue(context);
		NumConstr[] nodeFirstTSConstrs = new NumConstr[nodeFirstTSConstrsVal
				.size()];
		for (int i = 0; i < nodeFirstTSConstrsVal.size(); ++i) {
			// VALID OPERATORS: GREATER, LESS
			NumConstr constr = (NumConstr) nodeFirstTSConstrsVal.get(i)
					.javaObjectValue(context);
			nodeFirstTSConstrs[i] = constr;
		}

		ValueVector nodeLastTSConstrsVal = vv.get(13).listValue(context);
		NumConstr[] nodeLastTSConstrs = new NumConstr[nodeLastTSConstrsVal
				.size()];
		for (int i = 0; i < nodeLastTSConstrsVal.size(); ++i) {
			// VALID OPERATORS: GREATER, LESS
			NumConstr constr = (NumConstr) nodeLastTSConstrsVal.get(i)
					.javaObjectValue(context);
			nodeLastTSConstrs[i] = constr;
		}

		int hash = Arrays.deepHashCode(new Object[][] {
				new String[] { refNodeID, refNodeRole },
				linkTypeConstrs, linkCreatorConstrs, linkModifiersConstrs,
				linkFirstTSConstrs, linkLastTSConstrs, nodeTypeConstrs,
				nodeCreatorConstrs, nodeModifiersConstrs, nodeFirstTSConstrs,
				nodeLastTSConstrs });

		Value v = runAnalysis(index, hash, refNodeID, refNodeRole,
				linkTypeConstrs, linkCreatorConstrs, linkModifiersConstrs,
				linkFirstTSConstrs, linkLastTSConstrs, nodeTypeConstrs,
				nodeCreatorConstrs, nodeModifiersConstrs, nodeFirstTSConstrs,
				nodeLastTSConstrs);
		logger.info("... Result: " + v.toString());
		return v;
	}

	protected Value runAnalysis(Index index, int hash, String refNodeID,
			String refNodeRole, SetConstr[] linkTypeConstrs,
			SetConstr[] linkCreatorConstrs, SetConstr[] linkModifiersConstrs,
			NumConstr[] linkFirstTSConstrs, NumConstr[] linkLastTSConstrs,
			SetConstr[] nodeTypeConstrs, SetConstr[] nodeCreatorConstrs,
			SetConstr[] nodeModifiersConstrs, NumConstr[] nodeFirstTSConstrs,
			NumConstr[] nodeLastTSConstrs) throws JessException {

		logger.debug("RUN ANALYSIS (ref node=" + refNodeID + ")");

		Set<GraphObject> matches = index.applyBoundConstraints(hash, refNodeID,
				refNodeRole, linkTypeConstrs, linkCreatorConstrs,
				linkModifiersConstrs, linkFirstTSConstrs, linkLastTSConstrs,
				nodeTypeConstrs, nodeCreatorConstrs, nodeModifiersConstrs,
				nodeFirstTSConstrs, nodeLastTSConstrs);

		logger.debug("MATCHES: " + matches);

		return new Value(matches.size(), RU.INTEGER);
	}

}
