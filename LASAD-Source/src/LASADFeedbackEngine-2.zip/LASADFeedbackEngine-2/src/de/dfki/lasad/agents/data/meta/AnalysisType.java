package de.dfki.lasad.agents.data.meta;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;

/**
 * Metadata about a type of analysis an {@link IAgent} can carry out.
 * 
 * @author Oliver Scheuer, isha
 * 
 */
public class AnalysisType extends ServiceType {

	private Log logger = LogFactory.getLog(AnalysisType.class);

	private Class<? extends AnalysisResult> resultType;

	public AnalysisType(Class<? extends AnalysisResult> resultType,
			String agentID, String typeID, boolean doPublishToEndUser) {
		super(agentID, typeID);
		this.resultType = resultType;
		this.doPublishToEndUser = doPublishToEndUser;
	}

	public AnalysisType(Class<? extends AnalysisResult> resultType,
			String agentID, String typeID) {
		super(agentID, typeID);
		this.resultType = resultType;
	}

	public AnalysisType(String agentID, String typeID) {
		super(agentID, typeID);
	}

	public Object getResultType() {
		return resultType;

	}
}
