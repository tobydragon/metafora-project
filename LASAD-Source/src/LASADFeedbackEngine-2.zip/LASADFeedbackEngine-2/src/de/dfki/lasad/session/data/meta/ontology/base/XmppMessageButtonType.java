package de.dfki.lasad.session.data.meta.ontology.base;

import de.dfki.lasad.session.data.meta.ontology.ComparisonGroup;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class XmppMessageButtonType extends BaseType {

	private static XmppMessageButtonType instance = new XmppMessageButtonType();

	private XmppMessageButtonType() {
		super();
		lasadElementType = "xmppMessageButton";
		jessTemplateName = "elem_xmppMessageButton";
		addComponentSpecification(PropDescr.DEFAULT_COMPONENT_ID, "LINK", JessDataType.STRING, ComparisonGroup.NONE);
	}

	public static XmppMessageButtonType getInstance() {
		return instance;
	}
}
