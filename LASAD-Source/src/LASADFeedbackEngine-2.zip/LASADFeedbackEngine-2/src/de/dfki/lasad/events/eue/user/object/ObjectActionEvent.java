package de.dfki.lasad.events.eue.user.object;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.events.eue.EUEEventID;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.uds.xml.XmlFragment;
import de.uds.xml.XmlFragmentInterface;

/**
 * Event describing a manipulation of an object by a user within an EUE session
 * 
 * @author oliverscheuer
 * 
 */
public abstract class ObjectActionEvent extends UserEvent {
	protected List<EUEObject> eueObjectList = new Vector<EUEObject>();

	public ObjectActionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID) {
		super(sessionID, srcCompId, eueEventID);
	}

	public ObjectActionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID) {
		super(sessionID, srcCompId, eueEventID, userID);
	}

	public ObjectActionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID, List<EUEObject> eueObjectList) {
		super(sessionID, srcCompId, eueEventID, userID);
		this.eueObjectList = eueObjectList;
	}

	public void setEueObjectList(List<EUEObject> eueObjectList) {
		this.eueObjectList = eueObjectList;
	}

	public List<EUEObject> getEueObjectList() {
		return eueObjectList;
	}

	public void addEueObject(EUEObject eueObject) {
		eueObjectList.add(eueObject);
	}

	public int getEueObjectIndex(EUEObject eueObject) {
		int index = -1;
		for (int i = 0; i < eueObjectList.size(); i++) {
			if (eueObjectList.get(i).equals(eueObject)) {
				index = i;
				break;
			}
		}
		return index;
	}

	public boolean deleteEueObjectWithIndex(int index) {
		boolean flag = false;
		if ((0 == eueObjectList.size()) || (index < 0)
				|| (index > eueObjectList.size() - 1)) {
			return flag;
		} else {
			eueObjectList.remove(index);
			flag = true;
		}
		return flag;
	}

	@Override
	public String toString() {
		return super.toString() + ", eueObjectList=" + eueObjectList;
	}

	public abstract ObjectActionEvent cloneWithoutObjects();

	public XmlFragmentInterface toXml() {
		XmlFragmentInterface xmlFragment = super.toXml();
		XmlFragment objectElement = new XmlFragment("Objects");
		for (EUEObject obj : eueObjectList) {
			objectElement.addContent(obj.toXml());
		}
		xmlFragment.addContent(objectElement);
		return xmlFragment;
	}

}
