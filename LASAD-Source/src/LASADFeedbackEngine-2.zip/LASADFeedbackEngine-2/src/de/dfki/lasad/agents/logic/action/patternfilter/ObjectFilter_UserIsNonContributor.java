package de.dfki.lasad.agents.logic.action.patternfilter;

import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ObjectFilter_UserIsNonContributor extends ObjectFilter {

	private UserID referenceUser;

	public ObjectFilter_UserIsNonContributor(UserID referenceUser) {
		this.referenceUser = referenceUser;
	}

	@Override
	public boolean keep(ObjectResult oResult) {
		return !oResult.getContributors().contains(referenceUser);

	}

}
