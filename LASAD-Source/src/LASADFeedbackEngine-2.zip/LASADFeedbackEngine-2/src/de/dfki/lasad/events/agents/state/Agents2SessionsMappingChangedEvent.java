package de.dfki.lasad.events.agents.state;

/**
 * Notification that the Feedback-Engine configuration has changed.
 * 
 * @author oliverscheuer
 * 
 */
public class Agents2SessionsMappingChangedEvent extends AFStateChangedEvent {

	public Agents2SessionsMappingChangedEvent(String srcCompId) {
		super(srcCompId);
	}
}
