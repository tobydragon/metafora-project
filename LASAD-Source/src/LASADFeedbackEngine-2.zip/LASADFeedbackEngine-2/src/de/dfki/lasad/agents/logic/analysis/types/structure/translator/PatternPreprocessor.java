package de.dfki.lasad.agents.logic.analysis.types.structure.translator;

import java.util.*;

import lasad.shared.dfki.meta.agents.analysis.structure.model.*;
import lasad.shared.dfki.meta.ontology.Ontology;
import lasad.shared.dfki.meta.ontology.descr.*;

/**
 * 
 * @author oliverscheuer, Almer Bolatov
 * 
 */
public class PatternPreprocessor {

	public boolean testModePrintIntermediateResults = false;
	public boolean testModeOmitSequentialization = false;

	private Ontology ontology = null;
	private PatternPreprocessorSequentializer sequentializer = null;
	private PatternPreprocessorNeighbors neighborAnalyzer = null;
	private PatternPreprocessorBinClassifier binClassifier = null;

	public PatternPreprocessor(Ontology ontology) {
		this.ontology = ontology;
		this.sequentializer = new PatternPreprocessorSequentializer(ontology);
		this.neighborAnalyzer = new PatternPreprocessorNeighbors();
		this.binClassifier = new PatternPreprocessorBinClassifier(ontology);
	}

	/**
	 * IMPORTANT: The sequence of method invocation is important because later
	 * computations may depend on previous ones.
	 */
	public void preprocess(StructuralPattern pattern) {
		initSupplData(pattern);

		if (!testModeOmitSequentialization) {
			sequentializeVariables(pattern);
		}
		addNeighborConstrs(pattern);
		addComparisonIDAndType(pattern, 0);
		addBinClassifications(pattern);
		addElemPropsUsedAsRefValues(pattern);
		addPatternConstantNumID2Values(pattern);
	}

	private void initSupplData(StructuralPattern pattern) {

		pattern.setSupplData(new StructuralPatternSuppl());

		for (NodeVariable nodeVar : pattern.getNodeVars()) {
			ElementVariableSuppl supplData = new ElementVariableSuppl();
			nodeVar.setSupplData(supplData);
			for (Comparison c : nodeVar.getComparisons()) {
				if (c instanceof Set2ConstSetComparison) {
					((Set2ConstSetComparison) c)
							.setSupplData(new Set2ConstSetComparisonSuppl());
				} else {
					c.setSupplData(new ComparisonSuppl());
				}
			}
		}
		for (LinkVariable linkVar : pattern.getLinkVars()) {
			ElementVariableSuppl supplData = new ElementVariableSuppl();
			linkVar.setSupplData(supplData);
			for (Comparison c : linkVar.getComparisons()) {
				if (c instanceof Set2ConstSetComparison) {
					((Set2ConstSetComparison) c)
							.setSupplData(new Set2ConstSetComparisonSuppl());
				} else {
					c.setSupplData(new ComparisonSuppl());
				}
			}
		}
		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			initSupplData(notPattern);
		}
	}

	/**
	 * Rearranging elements in pattern to obtain a "valid" and "optimal"
	 * ordering of elements (for details, see
	 * {@link PatternPreprocessorSequentializer).
	 */
	private void sequentializeVariables(StructuralPattern pattern) {
		sequentializer.sequentializeVariables(pattern,
				new Vector<ElementVariable>());

		List<ElementVariable> predecessors = new Vector<ElementVariable>();
		predecessors.addAll(pattern.getNodeVars());
		predecessors.addAll(pattern.getLinkVars());
		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			sequentializer.sequentializeVariables(notPattern, predecessors);
		}
	}

	/**
	 * Processes {@link LinkVariable}s in order to derive neighborhood
	 * relationships between {@link NodeVariable}s
	 */
	private void addNeighborConstrs(StructuralPattern pattern) {
		neighborAnalyzer.addNeighborConstrs(pattern);
	}

	/**
	 * Determines the {@link ComparisonType} of all {@link Comparison}s and
	 * generates an ID value for each {@link Comparison}.
	 */
	private void addComparisonIDAndType(StructuralPattern pattern, int startID) {
		int idState = addComparisonIDAndType(pattern.getNodeVars(), 0);
		idState = addComparisonIDAndType(pattern.getLinkVars(), idState);

		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			idState = addComparisonIDAndType(notPattern.getNodeVars(), idState);
			idState = addComparisonIDAndType(notPattern.getLinkVars(), idState);
		}
	}

	/**
	 * For each {@link ElementVariable}, classify all of its constraints (
	 * {@link Comparison}) into one of 20 predefined bins later used to generate
	 * different kinds of Jess clauses. For details, see external documentation.
	 */
	private void addBinClassifications(StructuralPattern pattern) {
		binClassifier.addBinClassifications(pattern);

		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			binClassifier.addBinClassifications(notPattern);
		}
	}

	/**
	 * For each {@link ElementVariable}, determine which of its
	 * {@link ElementVariableProp}s are referenced in constraints (
	 * {@link Comparison}) attached to other {@link ElementVariable}s.
	 */
	private void addElemPropsUsedAsRefValues(StructuralPattern pattern) {
		addElemPropsUsedAsRefValues(pattern.getNodeVars());
		addElemPropsUsedAsRefValues(pattern.getLinkVars());

		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			addElemPropsUsedAsRefValues(notPattern.getNodeVars());
			addElemPropsUsedAsRefValues(notPattern.getLinkVars());
		}
	}

	private int addComparisonIDAndType(
			List<? extends ElementVariable> elemVars, int id) {

		for (ElementVariable elemVar : elemVars) {

			for (Comparison c : elemVar.getComparisons()) {
				ComparisonSuppl supplData = c.getSupplData();

				supplData.setId(id++);

				// default external
				supplData.setType(ComparisonType.EXTERNAL);
				if (c instanceof VariableComparison) {
					VariableComparison vc = (VariableComparison) c;
					ElementVariable otherElemVar = vc.getRightExpr()
							.getElementVar();
					if (elemVar.equals(otherElemVar)) {
						supplData.setType(ComparisonType.INTERNAL);
					}
				}
			}
		}
		return id;
	}

	private void addElemPropsUsedAsRefValues(
			List<? extends ElementVariable> elemVars) {

		Set<Bin> addRHSReference = new HashSet<Bin>();
		addRHSReference.add(Bin.BIN_1);
		addRHSReference.add(Bin.BIN_2);
		addRHSReference.add(Bin.BIN_3);
		addRHSReference.add(Bin.BIN_4);

		Set<Bin> addLHSReference = new HashSet<Bin>();
		addLHSReference.add(Bin.BIN_5);
		addLHSReference.add(Bin.BIN_6);

		for (ElementVariable elemVar : elemVars) {
			for (Comparison c : elemVar.getComparisons()) {
				if (c instanceof VariableComparison) {
					VariableComparison varComp = (VariableComparison) c;

					ElementVariableProp referencedElemVarProp = null;

					Bin bin = c.getSupplData().getBin();
					if (addRHSReference.contains(bin)) {
						referencedElemVarProp = varComp.getRightExpr();

					} else if (addLHSReference.contains(bin)) {
						referencedElemVarProp = varComp.getLeftExpr();
					}
					if (referencedElemVarProp != null) {
						PropDescr referencedProp = referencedElemVarProp
								.getPropDescr(ontology);
						String referencedComponentID = referencedElemVarProp
								.getCompID();
						ElementVariable referencedElemVar = referencedElemVarProp
								.getElementVar();
						ElementVariableSuppl elemSupplData = referencedElemVar
								.getSupplData();

						Map<PropDescr, List<String>> props2compsUsedAsRefValues = elemSupplData
								.getProp2CompsUsedAsReferenceValues();

						List<String> compsUsedAsRefValues = props2compsUsedAsRefValues
								.get(referencedProp);
						if (compsUsedAsRefValues == null) {
							compsUsedAsRefValues = new Vector<String>();
							props2compsUsedAsRefValues.put(referencedProp,
									compsUsedAsRefValues);
						}
						if (!compsUsedAsRefValues
								.contains(referencedComponentID)) {
							compsUsedAsRefValues.add(referencedComponentID);
						}
					}
				}
			}
		}
	}

	private void addPatternConstantNumID2Values(StructuralPattern pattern) {

		Map<Integer, List<String>> constantNumID2Values = new HashMap<Integer, List<String>>();
		List<NodeVariable> nodeConstrs = pattern.getNodeVars();
		List<LinkVariable> linkConstrs = pattern.getLinkVars();

		addPatternConstantNumID2Values(constantNumID2Values, nodeConstrs,
				Bin.BIN_19);
		addPatternConstantNumID2Values(constantNumID2Values, nodeConstrs,
				Bin.BIN_20);
		addPatternConstantNumID2Values(constantNumID2Values, linkConstrs,
				Bin.BIN_19);
		addPatternConstantNumID2Values(constantNumID2Values, linkConstrs,
				Bin.BIN_20);

		pattern.getSupplData().setConstantNumID2Values(constantNumID2Values);

		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			addPatternConstantNumID2Values(notPattern);
		}

	}

	private void addPatternConstantNumID2Values(
			Map<Integer, List<String>> constantNumID2Values,
			List<? extends ElementVariable> elemVars, Bin bin) {

		boolean wrongBin = !Bin.BIN_19.equals(bin) && !Bin.BIN_20.equals(bin);
		if (wrongBin) {
			return;
		}
		for (ElementVariable elemVar : elemVars) {
			Map<Bin, Map<ElementVariableProp, List<Comparison>>> bin2propVar2Comparisons = elemVar
					.getSupplData().getBin2propVars2Comparisons();
			Map<ElementVariableProp, List<Comparison>> propVar2Comparisons = bin2propVar2Comparisons
					.get(bin);

			if (propVar2Comparisons != null) {
				for (ElementVariableProp key : propVar2Comparisons.keySet()) {
					List<Comparison> comparisons = propVar2Comparisons.get(key);
					for (Comparison c : comparisons) {
						// BIN-19/20: must be of type "Set2ConstSetComparison"
						Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
						Set2ConstSetComparisonSuppl supplData = (Set2ConstSetComparisonSuppl) comparison
								.getSupplData();
						supplData.setUseJessConstantSetFact(true);
						List<String> rightExpr = comparison.getRightExpr();
						constantNumID2Values.put(supplData.getId(), rightExpr);
					}
				}
			}
		}
	}

}
