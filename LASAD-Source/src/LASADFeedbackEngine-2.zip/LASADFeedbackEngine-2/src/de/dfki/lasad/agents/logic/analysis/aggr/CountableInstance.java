package de.dfki.lasad.agents.logic.analysis.aggr;

import java.util.HashSet;
import java.util.Set;

import lasad.shared.dfki.meta.agents.analysis.counter.CounterDef;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeGeneral;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeSpecific;

import de.dfki.lasad.session.data.UserID;

/**
 * Light-weight representation of nodes, links and patterns based on all
 * properties that are relevant to decide whether the {@link CountableInstance}
 * should be counted or not.
 * 
 * <br/>
 * <br/>
 * (see also {@link CounterDef})
 * 
 * @author oliverscheuer
 * 
 */
public class CountableInstance {

	public InstanceTypeGeneral typeGeneral;
	public InstanceTypeSpecific typeSpecific;
	public String instanceID;

	public UserID creatorID;
	public Set<UserID> contributorIDs = new HashSet<UserID>();

	public Long lastModTs = -1L;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((instanceID == null) ? 0 : instanceID.hashCode());
		result = prime * result
				+ ((typeGeneral == null) ? 0 : typeGeneral.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CountableInstance other = (CountableInstance) obj;
		if (instanceID == null) {
			if (other.instanceID != null)
				return false;
		} else if (!instanceID.equals(other.instanceID))
			return false;
		if (typeGeneral != other.typeGeneral)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CountableInstance [typeGeneral=" + typeGeneral
				+ ", typeSpecific=" + typeSpecific + ", instanceID="
				+ instanceID + ", creatorID=" + creatorID + ", contributorIDs="
				+ contributorIDs + ", lastModTs=" + lastModTs + "]";
	}

}
