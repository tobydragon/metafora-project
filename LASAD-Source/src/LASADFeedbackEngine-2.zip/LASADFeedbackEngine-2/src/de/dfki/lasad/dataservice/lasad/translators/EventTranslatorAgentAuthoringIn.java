package de.dfki.lasad.dataservice.lasad.translators;

/**
 * 
 * @author oliverscheuer
 *
 */
public class EventTranslatorAgentAuthoringIn {

	// TODO
}
