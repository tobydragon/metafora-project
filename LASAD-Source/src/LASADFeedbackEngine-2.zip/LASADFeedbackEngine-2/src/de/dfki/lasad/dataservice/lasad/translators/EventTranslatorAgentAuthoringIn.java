package de.dfki.lasad.dataservice.lasad.translators;

import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.categories.Categories;
import lasad.shared.communication.objects.commands.Commands;
import lasad.shared.communication.objects.parameters.ParameterTypes;
import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;
import lasad.shared.dfki.meta.agents.ServiceClass;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.dataservice.lasad.rmi.LASADDataService;
import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;
import de.dfki.lasad.events.eue.admin.agent.in.AddAgentToOntologyEvent;
import de.dfki.lasad.events.eue.admin.agent.in.AddAgentToSessionEvent;
import de.dfki.lasad.events.eue.admin.agent.in.AddOrUpdateAgentEvent;
import de.dfki.lasad.events.eue.admin.agent.in.CompileAgentEvent;
import de.dfki.lasad.events.eue.admin.agent.in.DeleteAgentEvent;
import de.dfki.lasad.events.eue.admin.agent.in.GetFreshAgentIDEvent;
import de.dfki.lasad.events.eue.admin.agent.in.GetFreshServiceIDEvent;
import de.dfki.lasad.events.eue.admin.agent.in.RemoveAgentFromOntologyEvent;
import de.dfki.lasad.events.eue.admin.agent.in.RemoveAgentFromSessionEvent;
import de.dfki.lasad.events.eue.admin.agent.in.StartSessionEvent;
import de.dfki.lasad.events.eue.admin.agent.in.StopSessionEvent;

/**
 * 
 * @author oliverscheuer, anahuacv
 *
 */
public class EventTranslatorAgentAuthoringIn {
	
	private static Log logger = LogFactory
	.getLog(EventTranslatorAgentAuthoringIn.class);
	
	/*
	 * Translate a Feedback Authoring action
	 * Returns the respective event or null if the Category or command are not valid
	 */
	public static EUEAgentAdminEvent translate(Action action) {
		EUEAgentAdminEvent event = null;
		Categories cat = action.getCategory();
		Commands cmd = action.getCmd();
		if(cat.compareTo(Categories.FeedbackAuthoring) == 0){
			switch (cmd){
				case AddAgentToOntology:
					event = translateAddAgentToOntologyAction(action);
					break;
				case AddAgentToSession:
					event = translateAddAgentToSessionAction(action);
					break;
				case RemoveAgentFromOntology:
					event = translateRemoveAgentFromOntologyAction(action);
					break;
				case RemoveAgentFromSession:
					event = translateRemoveAgentFromSessionAction(action);
					break;
				case AddOrUpdateAgent:
					event = translateAddOrUpdateAgentAction(action);
					break;
				case DeleteAgent:
					event = translateDeleteAgentAction(action);
					break;
				case StartSession:
					event = translateStartSessionAction(action);
					break;
				case StopSession:
					event = translateStopSessionAction(action);
					break;
				case CompileAgent:
					event = translateCompileAgentAction(action);
					break;
				case GetFreshAgentId:
					event = translateGetFreshAgentIdAction(action);
					break;
				case GetFreshPatternId:
					event = translateGetFreshPatternIdAction(action);
					break;
				default:
					logger.error("Invalid command: " + cmd.toString());
			}
		}
		return event;
		
	}
	
	private static AddAgentToOntologyEvent translateAddAgentToOntologyAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		
		AddAgentToOntologyEvent event = new AddAgentToOntologyEvent(srcCompId);
		String agentId = action.getParameterValue(ParameterTypes.AgentId);
		String ontologyId = action.getParameterValue(ParameterTypes.Ontology);
		event.setAgentID(agentId);
		event.setOntologyID(ontologyId);
		event.setTs(EventTranslatorLASAD2AF.getCurrentTimeAsLong());
		return event;
	}
	
	private static AddAgentToSessionEvent translateAddAgentToSessionAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		AddAgentToSessionEvent event = new AddAgentToSessionEvent(srcCompId);
		String agentId = action.getParameterValue(ParameterTypes.AgentId);
		String sessionId = action.getParameterValue(ParameterTypes.SessionId);
		event.setAgentID(agentId);
		event.setSessionID(sessionId);
		event.setTs(EventTranslatorLASAD2AF.getCurrentTimeAsLong());
		return event;
	}
	
	private static AddOrUpdateAgentEvent translateAddOrUpdateAgentAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		AddOrUpdateAgentEvent event = new AddOrUpdateAgentEvent(srcCompId);
		AgentDescriptionFE agentDescriptionFE = (AgentDescriptionFE)action.getObjectFE();
		event.setAgentDescriptionFE(agentDescriptionFE);
		event.setTs(EventTranslatorLASAD2AF.getCurrentTimeAsLong());
		return event;
	}
	
	private static DeleteAgentEvent translateDeleteAgentAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		DeleteAgentEvent event = new DeleteAgentEvent(srcCompId);
		String agentId = action.getParameterValue(ParameterTypes.AgentId);
		event.setAgentID(agentId);
		event.setTs(EventTranslatorLASAD2AF.getCurrentTimeAsLong());
		return event;
	}
	
	private static RemoveAgentFromOntologyEvent translateRemoveAgentFromOntologyAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		RemoveAgentFromOntologyEvent event = new RemoveAgentFromOntologyEvent(srcCompId);
		String agentId = action.getParameterValue(ParameterTypes.AgentId);
		String ontologyId = action.getParameterValue(ParameterTypes.Ontology);
		event.setAgentID(agentId);
		event.setOntologyID(ontologyId);
		event.setTs(EventTranslatorLASAD2AF.getCurrentTimeAsLong());
		return event;
	}
	
	private static RemoveAgentFromSessionEvent translateRemoveAgentFromSessionAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		RemoveAgentFromSessionEvent event = new RemoveAgentFromSessionEvent(srcCompId);
		String agentId = action.getParameterValue(ParameterTypes.AgentId);
		String sessionId = action.getParameterValue(ParameterTypes.SessionId);
		event.setAgentID(agentId);
		event.setSessionID(sessionId);
		event.setTs(EventTranslatorLASAD2AF.getCurrentTimeAsLong());
		return event;
	}
	
	private static StartSessionEvent translateStartSessionAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		StartSessionEvent event = new StartSessionEvent(srcCompId);
		String sessionId = action.getParameterValue(ParameterTypes.SessionId);
		event.setSessionID(sessionId);
		event.setTs(EventTranslatorLASAD2AF.getCurrentTimeAsLong());
		return event;
	}
	
	private static StopSessionEvent translateStopSessionAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		StopSessionEvent event = new StopSessionEvent(srcCompId);
		String sessionId = action.getParameterValue(ParameterTypes.SessionId);
		event.setSessionID(sessionId);
		event.setTs(EventTranslatorLASAD2AF.getCurrentTimeAsLong());
		return event;
	}
	
	private static CompileAgentEvent translateCompileAgentAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		CompileAgentEvent event = new CompileAgentEvent(srcCompId);
		String agentId = action.getParameterValue(ParameterTypes.AgentId);
		event.setAgentID(agentId);
		event.setTs(EventTranslatorLASAD2AF.getCurrentTimeAsLong());
		return event;
	}
	
	private static GetFreshAgentIDEvent translateGetFreshAgentIdAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		GetFreshAgentIDEvent event = new GetFreshAgentIDEvent(srcCompId);
		String requestId = action.getParameterValue(ParameterTypes.RequestId);
		event.setRequestID(requestId);
		return event;
	}
	
	private static GetFreshServiceIDEvent translateGetFreshPatternIdAction(Action action){
		String srcCompId = LASADDataService.class.toString();
		GetFreshServiceIDEvent event = new GetFreshServiceIDEvent(srcCompId);
		String requestId = action.getParameterValue(ParameterTypes.RequestId);
		String agentId = action.getParameterValue(ParameterTypes.AgentId);
		event.setRequestID(requestId);
		event.setAgentID(agentId);
		event.setServiceClass(ServiceClass.ANALYSIS);
		return event;
	}
}
