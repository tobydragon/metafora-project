package de.dfki.lasad.agents.logic.action.patternfilter;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef;
import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef_LastModTime;
import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef_LastModTimeSetting;
import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef_User;
import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef_UserSetting;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.instances.TaskScheduler;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PatternFilterServiceFactory {

	private static Log logger = LogFactory
			.getLog(PatternFilterServiceFactory.class);

	public static PatternFilterServiceInterface createPatternFilterService(
			UserID referenceUser, List<PatternFilterDef> filterDefinitions,
			TaskScheduler taskSchedulerRef) {
		List<ObjectFilter> objectFilters = createObjectFilters(referenceUser,
				filterDefinitions, taskSchedulerRef);
		Collections.sort(objectFilters, new Comparator_TimeBasedFiltersLast());
		return new PatternFilterService(referenceUser, objectFilters);
	}

	private static List<ObjectFilter> createObjectFilters(UserID referenceUser,
			List<PatternFilterDef> filterDefinitions,
			TaskScheduler taskSchedulerRef) {
		List<ObjectFilter> objectFilters = new Vector<ObjectFilter>();

		for (PatternFilterDef filter : filterDefinitions) {

			if (filter instanceof PatternFilterDef_LastModTime) {
				PatternFilterDef_LastModTime lastModFilter = (PatternFilterDef_LastModTime) filter;
				if (lastModFilter.getSetting() == PatternFilterDef_LastModTimeSetting.MIN_AGE) {
					ObjectFilter_LastModTimeMinAge checker = new ObjectFilter_LastModTimeMinAge(
							lastModFilter.getReferenceValue(), taskSchedulerRef);
					objectFilters.add(checker);
				} else if (lastModFilter.getSetting() == PatternFilterDef_LastModTimeSetting.MAX_AGE) {
					ObjectFilter_LastModTimeMaxAge checker = new ObjectFilter_LastModTimeMaxAge(
							lastModFilter.getReferenceValue(), taskSchedulerRef);
					objectFilters.add(checker);
				}
			} else if (filter instanceof PatternFilterDef_User) {
				PatternFilterDef_User userFilter = (PatternFilterDef_User) filter;
				if (userFilter.getSetting() == PatternFilterDef_UserSetting.OWNER) {
					ObjectFilter_UserIsOwner checker = new ObjectFilter_UserIsOwner(
							referenceUser);
					objectFilters.add(checker);
				} else if (userFilter.getSetting() == PatternFilterDef_UserSetting.CONTRIBUTOR) {
					ObjectFilter_UserIsContributor checker = new ObjectFilter_UserIsContributor(
							referenceUser);
					objectFilters.add(checker);
				} else if (userFilter.getSetting() == PatternFilterDef_UserSetting.NON_CONTRIBUTOR) {
					ObjectFilter_UserIsNonContributor checker = new ObjectFilter_UserIsNonContributor(
							referenceUser);
					objectFilters.add(checker);
				}
			} else {
				logger.error("Unhandled pattern filter type: " + filter);
				return null;
			}
		}
		return objectFilters;
	}

	static class Comparator_TimeBasedFiltersLast implements
			Comparator<ObjectFilter> {

		@Override
		public int compare(ObjectFilter o1, ObjectFilter o2) {
			if ((o1 instanceof ObjectFilter_LastModTime)
					&& !(o2 instanceof ObjectFilter_LastModTime)) {
				return 1;
			}
			return 0;
		}
	}
}
