package de.dfki.lasad.agents.logic.analysis.types.structure.translator;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import lasad.shared.dfki.meta.ontology.Ontology;

/**
 * Generates Jess 'deffacts' expressions to insert constant values, which are
 * needed for some {@link Comparison}s, into the Jess working memory.
 * 
 * @author oliverscheuer
 * 
 */
public class JessConstValDeffactGenerator {

	public static final String INDENT_L1 = " ";
	public static final String INDENT_L2 = "   ";

	private Ontology ontology = null;
	private JessIDAndSlotNameGenerator idGen = null;

	public JessConstValDeffactGenerator(Ontology ontology,
			JessIDAndSlotNameGenerator idGen) {
		this.ontology = ontology;
		this.idGen = idGen;
	}

	public String generateConstValDeffacts(String agentID,
			StructuralPattern pattern) {
		StringBuffer buf = new StringBuffer();
		String patternID = pattern.getID();

		Map<Integer, List<String>> constantNumID2Values = pattern
				.getSupplData().getConstantNumID2Values();
		if (constantNumID2Values.isEmpty()) {
			return "";
		}
		buf.append("(deffacts " + "const-vals-pattern-" + patternID + " ");
		buf.append("\"Constant values used in pattern " + patternID + "\"");
		buf.append("\n");
		for (Iterator<Integer> iter = constantNumID2Values.keySet().iterator(); iter
				.hasNext();) {
			int constID = iter.next();
			String factID = idGen.generateConstantFactID(agentID, patternID,
					constID);
			List<String> values = constantNumID2Values.get(constID);

			buf.append(Indent.apply("(constant-set\n", INDENT_L1));
			buf.append(Indent.apply("(id \"" + factID + "\")\n", INDENT_L2));
			buf.append(Indent.apply("(values " + generateValueList(values)
					+ "))", INDENT_L2));
			if (iter.hasNext()) {
				buf.append("\n");
			}
		}
		buf.append(")");
		return buf.toString();
	}

	public String generateValueList(List<String> values) {
		StringBuffer buf = new StringBuffer();
		for (Iterator<String> vIter = values.iterator(); vIter.hasNext();) {
			String val = vIter.next();
			buf.append("\"" + val + "\"");
			if (vIter.hasNext()) {
				buf.append(" ");
			}
		}
		return buf.toString();
	}
}
