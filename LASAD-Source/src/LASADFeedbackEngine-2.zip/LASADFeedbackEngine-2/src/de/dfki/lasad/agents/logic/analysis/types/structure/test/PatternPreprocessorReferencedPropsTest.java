package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import java.util.Iterator;
import java.util.List;

import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableSuppl;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import lasad.shared.dfki.meta.ontology.descr.PropDescr;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.PatternPreprocessor;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PatternPreprocessorReferencedPropsTest {

	static PatternPreprocessor preprocessor = new PatternPreprocessor(
			TestData.largoOntology);

	static {
		preprocessor.testModePrintIntermediateResults = false;
		preprocessor.testModeOmitSequentialization = true;
	}

	public static void main(String[] args) {
		printPreparedCase();
	}

	static void printPreparedCase() {
		StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
				.parsePattern(TestData.TESTFILE_PROPS_USED_AS_REF_VALUES);
		preprocessor.preprocess(pattern.getPattern());
		System.out.println("----- CONTROL -----");
		System.out.println(pattern.getPattern().toPrettyString(""));

		System.out.println("----- ACTUAL -----");

		printReferencedProps(pattern.getPattern());
	}

	static void printReferencedProps(StructuralPattern pattern) {
		printReferencedProps(pattern.getNodeVars());
		printReferencedProps(pattern.getLinkVars());
		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			printReferencedProps(notPattern);
		}
	}

	static void printReferencedProps(List<? extends ElementVariable> vars) {
		StringBuffer buf = new StringBuffer();
		for (ElementVariable var : vars) {
			buf.append(var.getVarID() + ": " + "\n");
			ElementVariableSuppl supplData = var.getSupplData();
			List<PropDescr> propsAsRef = supplData.getPropsUsedAsRefVal();
			Iterator<PropDescr> propIter = propsAsRef.iterator();
			while (propIter.hasNext()) {
				PropDescr prop = propIter.next();
				List<String> componentIDs = supplData
						.getPropComponentsUsedAsRefVal(prop);
				buf.append("..." + prop.getPropID() + "/" + componentIDs + "\n");
			}
		}
		System.out.println(buf.toString());
	}
}
