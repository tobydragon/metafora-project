package de.dfki.lasad.dataservice.lasad;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.Parameter;
import lasad.gwt.client.communication.objects.categories.Categories;
import lasad.gwt.client.communication.objects.commands.Commands;
import lasad.gwt.client.communication.objects.parameters.ParameterTypes;

import de.dfki.lasad.dataservice.lasad.translators.LASADVocabulary;

/**
 import lasad.ejb.Action;
 import lasad.ejb.ActionPackage;
 import lasad.ejb.Parameter;
 */

/**
 * Factory to create {@link ActionPackage}s that can be processed by the remote
 * LASAD-WS.
 * 
 * @author Oliver Scheuer
 * 
 */
public class ActionPackageFactory {

	static Log logger = LogFactory.getLog(ActionPackageFactory.class);

	private Parameter sessionParam;
	private Parameter usernameParam;
	private Parameter passwordParam;
	private String method = LASADVocabulary.ACTION_METHOD_PUSH;

	public ActionPackageFactory(String sessionId, String username,
			String password) {
		sessionParam = new Parameter();
		sessionParam.setType(ParameterTypes.SessionId);
		sessionParam.setValue(sessionId);

		usernameParam = new Parameter();
		usernameParam.setType(ParameterTypes.UserName);
		usernameParam.setValue(username);

		passwordParam = new Parameter();
		passwordParam.setType(ParameterTypes.Password);
		passwordParam.setValue(password);
	}

	public ActionPackageFactory(String sessionId, String username,
			String password, String method) {
		sessionParam = new Parameter();
		sessionParam.setType(ParameterTypes.SessionId);
		sessionParam.setValue(sessionId);

		usernameParam = new Parameter();
		usernameParam.setType(ParameterTypes.UserName);
		usernameParam.setValue(username);

		passwordParam = new Parameter();
		passwordParam.setType(ParameterTypes.Password);
		passwordParam.setValue(password);

		this.method = method;
	}

	public Parameter getSessionParam() {
		return sessionParam;
	}
	
	public ActionPackage createLoginMessage() {
		ActionPackage retVal;
		if (method.equals(LASADVocabulary.ACTION_METHOD_PUSH)) {
			retVal = createLoginMessageWS();
		} else {
			retVal = createLoginMessageRMI();
		}
		return retVal;
	}

	public ActionPackage createLoginMessageWS() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action loginAction = new Action();
		loginAction.setCmd(Commands.Login);
		loginAction.setCategory(Categories.Management);

		loginAction.getParameters().add(usernameParam);
		loginAction.getParameters().add(passwordParam);

		Parameter methodParam = new Parameter();
		methodParam.setType(ParameterTypes.Method);
		methodParam.setValue(LASADVocabulary.ACTION_METHOD_PUSH);
		loginAction.getParameters().add(methodParam);

		actionPackage.getActions().add(loginAction);

		return actionPackage;
	}

	public ActionPackage createLoginMessageRMI() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action loginAction = new Action();
		loginAction.setCmd(Commands.Login);
		loginAction.setCategory(Categories.Management);

		loginAction.getParameters().add(usernameParam);
		loginAction.getParameters().add(passwordParam);

		Parameter methodParam = new Parameter();
		methodParam.setType(ParameterTypes.Method);
		methodParam.setValue(LASADVocabulary.ACTION_METHOD_RMI);
		loginAction.getParameters().add(methodParam);

		actionPackage.getActions().add(loginAction);

		return actionPackage;
	}

	public ActionPackage createListMapsMessage() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCmd(Commands.List);
		action.setCategory(Categories.Management);
		actionPackage.getActions().add(action);

		return actionPackage;
	}

	public ActionPackage createGetOntologyMessage(String mapID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCmd(Commands.GetOntology);
		action.setCategory(Categories.Management);

		Parameter mapIDParam = new Parameter();
		mapIDParam.setType(ParameterTypes.MapId);
		mapIDParam.setValue(mapID);
		action.getParameters().add(mapIDParam);
		actionPackage.getActions().add(action);

		return actionPackage;
	}

	public ActionPackage createGetOntologyIDsMessage() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCmd(Commands.GetOntologies);
		action.setCategory(Categories.Authoring);
		actionPackage.getActions().add(action);
		return actionPackage;
	}

	public ActionPackage createGetOntologyDetailsMessage(String ontologyID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCmd(Commands.GetOntologyDetails);
		action.setCategory(Categories.Authoring);

		Parameter ontologyIDParam = new Parameter();
		ontologyIDParam.setType(ParameterTypes.OntologyName);
		ontologyIDParam.setValue(ontologyID);
		action.getParameters().add(ontologyIDParam);

		actionPackage.getActions().add(action);
		return actionPackage;
	}

	public ActionPackage createGetMapDetailsMessage(String mapID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCmd(Commands.MapDetails);
		action.setCategory(Categories.Management);

		Parameter mapIDParam = new Parameter();
		mapIDParam.setType(ParameterTypes.MapId);
		mapIDParam.setValue(mapID);
		action.getParameters().add(mapIDParam);
		actionPackage.getActions().add(action);

		return actionPackage;
	}

	public ActionPackage createJoinMapMessage(String mapID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action a = new Action();
		a.setCmd(Commands.Join);
		a.setCategory(Categories.Management);

		Parameter mapIDParam = new Parameter();
		mapIDParam.setType(ParameterTypes.MapId);
		mapIDParam.setValue(mapID);
		a.getParameters().add(mapIDParam);

		actionPackage.getActions().add(a);
		return actionPackage;
	}

	public ActionPackage createPublishServiceMessage(String mapID,
			String agentID, String serviceID, boolean isAnalysisType) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCategory(Categories.Map);
		action.setCmd(Commands.CreateElement);

		Parameter typeParam = createParameter(ParameterTypes.Type,
				LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK_AGENT);
		action.getParameters().add(typeParam);

		Parameter mapIDParam = createParameter(ParameterTypes.MapId, mapID);
		action.getParameters().add(mapIDParam);

		Parameter agentIDParam = createParameter(ParameterTypes.AgentId,
				agentID);
		action.getParameters().add(agentIDParam);

		Parameter serviceIDParam = createParameter(ParameterTypes.TypeId,
				serviceID);
		action.getParameters().add(serviceIDParam);

		String agentType = isAnalysisType ? LASADVocabulary.ACTION_PROP_VALUE_ANALYSIS
				: LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK;
		Parameter agentTypeParam = createParameter(ParameterTypes.AgentType,
				agentType);
		action.getParameters().add(agentTypeParam);

		actionPackage.getActions().add(action);

		return actionPackage;
	}

	public ActionPackage createHeartbeatMessage() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCategory(Categories.Session);
		action.setCmd(Commands.Heartbeat);
		// action.getParameters().add(createParameter("DUMMY",
		// "PLEASE IGNORE"));
		actionPackage.getActions().add(action);
		return actionPackage;
	}

	public Action createFeedbackMessage(String mapID, String recipientID,
			String message, String longMessage,
			List<String> objectsToBeHighlighted,
			Map<String, String> additionalParameters) {

		Action action = new Action();

		// basic data
		action.setCategory(Categories.Map);
		action.setCmd(Commands.CreateElement);

		Parameter typeParam = createParameter(ParameterTypes.Type,
				LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK_CLUSTER);
		action.getParameters().add(typeParam);

		Parameter usernameParam = createParameter(ParameterTypes.ForUser,
				recipientID);
		action.getParameters().add(usernameParam);

		Parameter mapIDParam = createParameter(ParameterTypes.MapId, mapID);
		action.getParameters().add(mapIDParam);

		Parameter messageParam = createParameter(ParameterTypes.Message,
				message);
		action.getParameters().add(messageParam);

		if (longMessage != null) {
			Parameter longMessageParam = createParameter(
					ParameterTypes.Details, longMessage);
			action.getParameters().add(longMessageParam);
		}

		for (String objectID : objectsToBeHighlighted) {
			Parameter highlightElemParam = createParameter(
					ParameterTypes.HighlightElementId, objectID);
			action.getParameters().add(highlightElemParam);
		}

		for (String paramName : additionalParameters.keySet()) {
			String paramValue = additionalParameters.get(paramName);

			Parameter additionalParam = createParameter(paramName, paramValue);
			action.getParameters().add(additionalParam);
		}

		return action;
	}

	public ActionPackage createActionPackage(List<Action> actions) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);
		for (Action action : actions) {
			actionPackage.getActions().add(action);
		}
		return actionPackage;
	}

	private Action createHighlightAction(String mapID, String eueID) {
		Action action = new Action();

		action.setCategory(Categories.Feedback);
		action.setCmd(Commands.Highlight);

		Parameter parentParam = createParameter(ParameterTypes.Parent,
				LASADVocabulary.ACTION_PROP_VALUE_LAST_ID);
		action.getParameters().add(parentParam);

		Parameter mapIDParam = createParameter(ParameterTypes.MapId, mapID);
		action.getParameters().add(mapIDParam);

		return action;
	}

	public ActionPackage createDeleteElementMessage(String mapID,
			String elementID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action deleteAction = new Action();

		// basic data
		deleteAction.setCategory(Categories.Map);
		deleteAction.setCmd(Commands.DeleteElement);

		Parameter mapIDParam = createParameter(ParameterTypes.MapId, mapID);
		deleteAction.getParameters().add(mapIDParam);

		Parameter idParam = createParameter(ParameterTypes.Id, elementID);
		deleteAction.getParameters().add(idParam);

		actionPackage.getActions().add(deleteAction);

		return actionPackage;
	}

	public ActionPackage createLeaveMapMessage(String mapID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action leaveAction = new Action();

		// basic data
		leaveAction.setCategory(Categories.Management);
		leaveAction.setCmd(Commands.Leave);

		Parameter mapIDParam = createParameter(ParameterTypes.MapId, mapID);
		leaveAction.getParameters().add(mapIDParam);

		actionPackage.getActions().add(leaveAction);
		return actionPackage;
	}

	public ActionPackage createLogoutMessage() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action logoutAction = new Action();

		// basic data
		logoutAction.setCategory(Categories.Management);
		logoutAction.setCmd(Commands.Logout);

		logoutAction.getParameters().add(usernameParam);

		actionPackage.getActions().add(logoutAction);
		return actionPackage;
	}
	
	
	/*
	 * Feedback Authoring tool
	 */
	public ActionPackage createListAgentsInfo(boolean changed, String details){
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);
		Action action = new Action(Commands.ListAgentsInfo, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, changed+"");
		action.addParameter(ParameterTypes.Details, details);
		actionPackage.addAction(action);
		
		return actionPackage;
	}
	/*
	 * end of Feedback Authoring tool
	 */
	
	
	private Parameter createParameter(String type, String value) {
		Parameter param = new Parameter();
		param.setType(Enum.valueOf(ParameterTypes.class, type));
		param.setValue(value);

		return param;
	}

	private Parameter createParameter(ParameterTypes type, String value) {
		Parameter param = new Parameter();
		param.setType(type);
		param.setValue(value);

		return param;
	}

	// //Added by TD straight from ActionFactory, 18.04.2011

	public Action createMap(String useMapName, String useTemplate,
			String useRestriction) {
		Action a = new Action(Commands.CreateMap, Categories.Authoring);
		a.addParameter(ParameterTypes.MapName, useMapName);
		a.addParameter(ParameterTypes.Template, useTemplate);
		a.addParameter(ParameterTypes.RestrictedTo, useRestriction);
		return a;
	}

	// ROLE: Standard, Developer, Guest
	public Action createUser(String useNickname, String usePassword,
			String useRole) {
		Action a = new Action(Commands.CreateUser, Categories.Authoring);
		a.addParameter(ParameterTypes.UserName, useNickname);
		a.addParameter(ParameterTypes.Password, usePassword);
		a.addParameter(ParameterTypes.Role, useRole);
		return a;
	}
}
