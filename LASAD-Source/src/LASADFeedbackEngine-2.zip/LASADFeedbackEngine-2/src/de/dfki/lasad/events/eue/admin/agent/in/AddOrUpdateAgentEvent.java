package de.dfki.lasad.events.eue.admin.agent.in;

import de.dfki.lasad.authoring.model.AgentDescriptionFE;
import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AddOrUpdateAgentEvent extends EUEAgentAdminEvent {

	private AgentDescriptionFE agentDescriptionFE;

	public AddOrUpdateAgentEvent(String srcCompId) {
		super(srcCompId);
	}

	public AgentDescriptionFE getAgentDescriptionFE() {
		return agentDescriptionFE;
	}

	public void setAgentDescriptionFE(AgentDescriptionFE agentDescriptionFE) {
		this.agentDescriptionFE = agentDescriptionFE;
	}

	@Override
	public String toString() {
		return "AddOrUpdateAgentEvent [agentDescriptionFE="
				+ agentDescriptionFE + "]";
	}

}
