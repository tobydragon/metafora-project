package de.dfki.lasad.sessionmodel.counter.constraints;

import java.util.HashSet;
import java.util.Set;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class SetConstr extends Constr {

	public static final String OPERATOR_IN = "IN";
	public static final String OPERATOR_NOT_IN = "NOT_IN";
	public static final String OPERATOR_SUBSET = "SUBSET";
	public static final String OPERATOR_NOT_SUBSET = "NOT_SUBSET";
	public static final String OPERATOR_SUPERSET = "SUPERSET";
	public static final String OPERATOR_NOT_SUPERSET = "NOT_SUPERSET";
	public static final String OPERATOR_DISJOINT = "DISJOINT";
	public static final String OPERATOR_NOT_DISJOINT = "NOT_DISJOINT";
	public static final String OPERATOR_EQUALS = "EQUALS";
	public static final String OPERATOR_NOT_EQUALS = "NOT_EQUALS";

	Set<String> refSet;

	public SetConstr(String operator, Set<String> refSet) {
		this.refSet = refSet;
		super.operator = operator;
	}

	public SetConstr(String operator, String[] refArray) {
		refSet = new HashSet<String>();
		for (int i = 0; i < refArray.length; ++i) {
			refSet.add(refArray[i]);
		}
		super.operator = operator;
	}

	public SetConstr(String operator, String refVal) {
		refSet = new HashSet<String>();
		refSet.add(refVal);
		if (OPERATOR_EQUALS.equals(operator)) {
			super.operator = OPERATOR_IN;
		} else if (OPERATOR_NOT_EQUALS.equals(operator)) {
			super.operator = OPERATOR_NOT_IN;
		} else {
			super.operator = operator;
		}

	}

	public Set<String> getRefSet() {
		return refSet;
	}

	public void setRefSet(Set<String> refSet) {
		this.refSet = refSet;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + refSet.hashCode();
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		SetConstr other = (SetConstr) obj;
		if (refSet == null) {
			if (other.refSet != null)
				return false;
		} else if (!refSet.equals(other.refSet))
			return false;
		return true;
	}

}
