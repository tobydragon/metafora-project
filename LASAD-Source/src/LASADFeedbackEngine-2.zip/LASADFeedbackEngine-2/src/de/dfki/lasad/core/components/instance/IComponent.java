package de.dfki.lasad.core.components.instance;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.events.agents.state.AFStateChangedEventListener;

/**
 * Feedback-Engine components with an explicit description of its attributes (
 * {@link #getDescription()}) and whose life-cycle is controlled by the
 * framework ( {@link #startService()} and {@link #stopService()}).
 * 
 * @author oliverscheuer
 * 
 */
public interface IComponent {

	public void configure(AbstractComponentDescription description)
			throws ComponentInitException;

	public String getComponentID();

	public AbstractComponentDescription getDescription();

	public void startService();

	public void stopService();

	public ServiceStatus getServiceStatus();

	public void setServiceStatus(ServiceStatus serviceStatus);

	public void addListener(AFStateChangedEventListener l);
}
