package de.dfki.lasad.core.components.instance;

import lasad.shared.dfki.meta.ServiceStatus;
import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.events.agents.configchange.AFStateChangedEventListener;
import de.dfki.lasad.session.SessionConfig;
import de.dfki.lasad.session.data.SessionID;

/**
 * Feedback-Engine components with an explicit description of its attributes (
 * {@link #getDescription()}) and whose life-cycle is controlled by the
 * framework ( {@link #startService()} and {@link #stopService()}).
 * 
 * @author oliverscheuer
 * 
 */
public interface IComponent {

	/**
	 * 
	 * @param description
	 * @param sConf
	 *            {@link SessionConfig} containing all session configuration
	 *            settings if component is tied to specific session, or
	 *            <code>null</code> if component is not tied to specific session
	 * @throws ComponentInitException
	 */
	public void init(AbstractComponentDescription description,
			SessionConfig sConf) throws ComponentInitException;

	public String getComponentID();

	public AbstractComponentDescription getDescription();

	/**
	 * 
	 * @param sID
	 *            sessionID or <code>null</code> if component is not tied to a
	 *            specific session
	 */
	public void startService(SessionID sID);

	/**
	 * 
	 * @param sID
	 *            sessionID or <code>null</code> if component is not tied to a
	 *            specific session
	 */
	public void stopService(SessionID sID);

	public ServiceStatus getServiceStatus();

	public void setServiceStatus(ServiceStatus serviceStatus);

	public void addListener(AFStateChangedEventListener l);
}
