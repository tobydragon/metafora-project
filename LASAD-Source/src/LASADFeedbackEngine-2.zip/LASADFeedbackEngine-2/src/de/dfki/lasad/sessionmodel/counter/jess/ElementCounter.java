package de.dfki.lasad.sessionmodel.counter.jess;

import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jess.Context;
import jess.JessException;
import jess.Userfunction;
import jess.Value;
import jess.ValueVector;
import de.dfki.lasad.sessionmodel.counter.Index;
import de.dfki.lasad.sessionmodel.counter.constraints.Constr;
import de.dfki.lasad.sessionmodel.counter.constraints.NumConstr;
import de.dfki.lasad.sessionmodel.counter.constraints.SetConstr;

/**
 * Analyzes an input list of
 * 
 * @author oliverscheuer
 */
public abstract class ElementCounter implements Userfunction {

	private Log logger = LogFactory.getLog(ElementCounter.class);

	public ElementCounter() {
		super();
	}

	@Override
	public abstract String getName();

	@Override
	public Value call(ValueVector vv, final Context context)
			throws JessException {

		logger.info("Counting function called ...");

		if (vv.size() != 7) {
			throw new JessException(getName(), getName()
					+ " takes 6 arguments: the index ds, a type constrs list, "
					+ "a creator constrs list, a modifiers constrs list, "
					+ "a first-ts constrs list, and a last-ts constrs list.",
					vv.size() - 1);
		}

		Value indexVal = vv.get(1).resolveValue(context);
		Index index = (Index) indexVal.javaObjectValue(context);

		ValueVector typeConstrsVal = vv.get(2).listValue(context);
		SetConstr[] typeConstrs = new SetConstr[typeConstrsVal.size()];
		for (int i = 0; i < typeConstrsVal.size(); ++i) {
			// VALID OPERATORS: (SCALAR REF-VAL) EQUALS, NOT_EQUALS, (SET
			// REF-VAL) IN, NOT_IN
			SetConstr constr = (SetConstr) typeConstrsVal.get(i)
					.javaObjectValue(context);
			typeConstrs[i] = constr;
		}

		ValueVector creatorConstrsVal = vv.get(3).listValue(context);
		SetConstr[] creatorConstrs = new SetConstr[creatorConstrsVal.size()];
		for (int i = 0; i < creatorConstrsVal.size(); ++i) {
			// VALID OPERATORS: (SCALAR REF-VAL) EQUALS, NOT_EQUALS, (SET
			// REF-VAL) IN, NOT_IN
			SetConstr constr = (SetConstr) creatorConstrsVal.get(i)
					.javaObjectValue(context);
			creatorConstrs[i] = constr;
		}

		ValueVector modifiersConstrsVal = vv.get(4).listValue(context);
		SetConstr[] modifiersConstrs = new SetConstr[modifiersConstrsVal.size()];
		for (int i = 0; i < modifiersConstrsVal.size(); ++i) {
			// VALID OPERATORS: EQUALS, NOT_EQUALS, SUBSET, NOT_SUBSET,
			// SUPERSET, NOT_SUPERSET
			// DISJOINT, NOT_DISJOINT
			SetConstr constr = (SetConstr) modifiersConstrsVal.get(i)
					.javaObjectValue(context);
			modifiersConstrs[i] = constr;
		}

		ValueVector firstTSConstrsVal = vv.get(5).listValue(context);
		NumConstr[] firstTSConstrs = new NumConstr[firstTSConstrsVal.size()];
		for (int i = 0; i < firstTSConstrsVal.size(); ++i) {
			// VALID OPERATORS: GREATER, LESS
			NumConstr constr = (NumConstr) firstTSConstrsVal.get(i)
					.javaObjectValue(context);
			firstTSConstrs[i] = constr;
		}

		ValueVector lastTSConstrsVal = vv.get(6).listValue(context);
		NumConstr[] lastTSConstrs = new NumConstr[lastTSConstrsVal.size()];
		for (int i = 0; i < lastTSConstrsVal.size(); ++i) {
			// VALID OPERATORS: GREATER, LESS
			NumConstr constr = (NumConstr) lastTSConstrsVal.get(i)
					.javaObjectValue(context);
			lastTSConstrs[i] = constr;
		}

		int hash = Arrays
				.deepHashCode(new Constr[][] { typeConstrs, creatorConstrs,
						modifiersConstrs, firstTSConstrs, lastTSConstrs });

		Value v = runAnalysis(index, hash, typeConstrs, creatorConstrs,
				modifiersConstrs, firstTSConstrs, lastTSConstrs);
		logger.info("... Result: " + v.toString());
		return v;
	}

	protected abstract Value runAnalysis(Index index, int hash,
			SetConstr[] typeConstrs, SetConstr[] creatorConstrs,
			SetConstr[] modifiersConstrs, NumConstr[] firstTSConstrs,
			NumConstr[] lastTSConstrs) throws JessException;
}
