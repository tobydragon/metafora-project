package de.dfki.lasad.agents.logic.provision.types;

import lasad.shared.dfki.meta.agents.provision.RecipientDef;
import lasad.shared.dfki.meta.agents.provision.RecipientDef_Group;
import lasad.shared.dfki.meta.agents.provision.RecipientDef_Individuals;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class RecipientDefXML {

	public static final String ELEMENT_NAME = "recipient";

	private static Log logger = LogFactory.getLog(RecipientDefXML.class);

	public static RecipientDef fromXML(Element recipientElem) {
		String type = recipientElem.getAttributeValue("type");
		if ("individual".equalsIgnoreCase(type)) {
			RecipientDef_Individuals recipientDef = new RecipientDef_Individuals();
			return recipientDef;
		} else if ("group".equalsIgnoreCase(type)) {
			RecipientDef_Group recipientDef = new RecipientDef_Group();
			return recipientDef;
		} else {
			logger.error("(fromXML) recipient type not handled: " + type);
			return null;
		}
	}

	public static Element toXML(RecipientDef recipientDef) {

		Element recipientElem = new Element(ELEMENT_NAME);

		if (recipientDef instanceof RecipientDef_Individuals) {
			recipientElem.setAttribute("type", "individual");
			return recipientElem;
		} else if (recipientDef instanceof RecipientDef_Group) {
			recipientElem.setAttribute("type", "group");
			return recipientElem;
		} else {
			logger.error("(toXML) recipient type not handled: " + recipientDef);
			return null;
		}
	}
}
