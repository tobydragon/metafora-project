package de.dfki.lasad.events.agents;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceID;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.instances.action.UserServiceID;
import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.session.data.SessionID;

/**
 * Provides {@link AnalysisResult} previously requested through a
 * {@link AnalysisResultsRequestEvent}. Feedback-Engine internal communication.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AnalysisResultsProvisionEvent extends SessionEvent {

	private Map<ServiceID, List<AnalysisResult>> resultMap = new HashMap<ServiceID, List<AnalysisResult>>();

	private UUID transactionID = null;
	private UserServiceID userServiceID = null;

	public AnalysisResultsProvisionEvent(SessionID sessionID, String srcCompId,
			Map<ServiceID, List<AnalysisResult>> resultMap) {
		super(sessionID, srcCompId);
		this.resultMap = resultMap;
	}

	public void addResult(AnalysisResult result) {
		List<AnalysisResult> results = resultMap.get(result.getAnalysisType());
		if (results == null) {
			results = new Vector<AnalysisResult>();
			resultMap.put(result.getAnalysisType().getServiceID(), results);
		}
		results.add(result);
	}

	public void addResults(List<AnalysisResult> results) {
		for (AnalysisResult result : results) {
			addResult(result);
		}
	}

	public List<AnalysisResult> getResults(ServiceID aTypeID) {
		return resultMap.get(aTypeID);
	}

	public Map<ServiceID, List<AnalysisResult>> getResults() {
		return resultMap;
	}

	public UserServiceID getUserServiceID() {
		return userServiceID;
	}

	public void setUserServiceID(UserServiceID userServiceID) {
		this.userServiceID = userServiceID;
	}

	public Set<ServiceID> getAnalysisTypeIDs() {
		return resultMap.keySet();
	}

	/**
	 * 
	 * @return transactionID or <code>null</code> if event not part of an
	 *         transaction
	 */
	public UUID getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(UUID transactionID) {
		this.transactionID = transactionID;
	}

	@Override
	public String toString() {
		return "AnalysisResultsProvisionEvent [resultMap=" + resultMap
				+ ", transactionID=" + transactionID + ", sessionID="
				+ sessionID + ", sourceComponentID=" + sourceComponentID + "]";
	}

}
