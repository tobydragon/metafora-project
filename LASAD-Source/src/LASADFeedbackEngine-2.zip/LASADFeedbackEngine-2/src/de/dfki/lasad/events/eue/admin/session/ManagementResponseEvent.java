package de.dfki.lasad.events.eue.admin.session;

import lasad.gwt.client.communication.objects.commands.Commands;
import de.dfki.lasad.agents.instances.xmpp.CfAbstractAgent;
import de.dfki.lasad.events.eue.EUESessionEvent;
import de.dfki.lasad.events.eue.admin.EUEAdminEvent;
import de.dfki.lasad.session.data.SessionID;

public class ManagementResponseEvent extends EUESessionEvent implements
		EUEAdminEvent {

	Commands command;
	String message;

	public ManagementResponseEvent(SessionID sessionID, String srcCompId,
			Commands command, String message) {
		super(sessionID, srcCompId);
		this.command = command;
		this.message = message;
	}

	public String toString() {
		return "[command - " + command + "] [message - " + message + "]";
	}

	public Commands getCommand() {
		return command;
	}

	public String getMessage() {
		return message;
	}

	public boolean isSuccess() {
		if (command.equals("AUTHORING-FAILED")) {
			return false;
		}
		return true;
	}

	public static ManagementResponseEvent getTestableInstance() {
		return new ManagementResponseEvent(null,
				CfAbstractAgent.class.getName(), Commands.AuthoringFailed,
				"Username already exists, please choose another one.");
	}

}
