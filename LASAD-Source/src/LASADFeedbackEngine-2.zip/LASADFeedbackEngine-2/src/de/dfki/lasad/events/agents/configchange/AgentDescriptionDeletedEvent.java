package de.dfki.lasad.events.agents.configchange;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescriptionDeletedEvent extends AFStateChangedEvent {

	private String agentID;

	public AgentDescriptionDeletedEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	@Override
	public String toString() {
		return "AgentDescriptionDeletedEvent [agentID=" + agentID + "]";
	}

}
