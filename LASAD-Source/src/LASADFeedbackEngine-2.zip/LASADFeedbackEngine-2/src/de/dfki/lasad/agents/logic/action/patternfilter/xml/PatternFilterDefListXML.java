package de.dfki.lasad.agents.logic.action.patternfilter.xml;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef;
import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef_LastModTime;
import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef_LastModTimeSetting;
import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef_User;
import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef_UserSetting;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class PatternFilterDefListXML {

	private static Log logger = LogFactory
			.getLog(PatternFilterDefListXML.class);

	public static final String ELEMENT_NAME = "pattern-filters";

	public static List<PatternFilterDef> fromXML(Element filtersElem) {
		List<PatternFilterDef> filterDefs = new Vector<PatternFilterDef>();
		for (Element filterElem : (List<Element>) filtersElem
				.getChildren("pattern-filter")) {

			String type = filterElem.getAttributeValue("type");
			if ("last-mod-ts".equalsIgnoreCase(type)) {
				PatternFilterDef_LastModTime filterDef = fromXML_LastModTime(filterElem);
				filterDefs.add(filterDef);
			} else if ("user".equalsIgnoreCase(type)) {
				PatternFilterDef_User filterDef = fromXML_UserFilter(filterElem);
				filterDefs.add(filterDef);
			} else {
				logger.warn("Unhandled filter type: " + type);
			}
		}
		return filterDefs;

	}

	protected static PatternFilterDef_LastModTime fromXML_LastModTime(
			Element filterElem) {
		String settingString = filterElem.getAttributeValue("setting");
		if ("none".equalsIgnoreCase(settingString)) {
			PatternFilterDef_LastModTime filterDef = new PatternFilterDef_LastModTime(
					PatternFilterDef_LastModTimeSetting.NONE, null);
			return filterDef;
		} else if ("min-age".equalsIgnoreCase(settingString)) {
			String refValueString = filterElem.getAttributeValue("ref-value");
			int refValue = Integer.valueOf(refValueString);
			PatternFilterDef_LastModTime filterDef = new PatternFilterDef_LastModTime(
					PatternFilterDef_LastModTimeSetting.MIN_AGE, refValue);
			return filterDef;
		} else if ("max-age".equalsIgnoreCase(settingString)) {
			String refValueString = filterElem.getAttributeValue("ref-value");
			int refValue = Integer.valueOf(refValueString);
			PatternFilterDef_LastModTime filterDef = new PatternFilterDef_LastModTime(
					PatternFilterDef_LastModTimeSetting.MAX_AGE, refValue);
			return filterDef;
		} else {
			logger.warn("Unhandled last mode time filter setting: "
					+ settingString);
			return null;
		}
	}

	protected static PatternFilterDef_User fromXML_UserFilter(Element filterElem) {
		String settingString = filterElem.getAttributeValue("setting");
		if ("none".equalsIgnoreCase(settingString)) {
			PatternFilterDef_User filterDef = new PatternFilterDef_User(
					PatternFilterDef_UserSetting.NONE);
			return filterDef;
		} else if ("owner".equalsIgnoreCase(settingString)) {
			PatternFilterDef_User filterDef = new PatternFilterDef_User(
					PatternFilterDef_UserSetting.OWNER);
			return filterDef;
		} else if ("contributor".equalsIgnoreCase(settingString)) {
			PatternFilterDef_User filterDef = new PatternFilterDef_User(
					PatternFilterDef_UserSetting.CONTRIBUTOR);
			return filterDef;
		} else if ("non-contributor".equalsIgnoreCase(settingString)) {
			PatternFilterDef_User filterDef = new PatternFilterDef_User(
					PatternFilterDef_UserSetting.NON_CONTRIBUTOR);
			return filterDef;
		} else {
			logger.warn("Unhandled user filter setting: " + settingString);
			return null;
		}
	}

	public static Element toXML(List<PatternFilterDef> filterDefs) {
		Element filtersElem = new Element(ELEMENT_NAME);
		for (PatternFilterDef filterDef : filterDefs) {
			Element filterElem = new Element("pattern-filter");
			filtersElem.addContent(filterElem);
			if (filterDef instanceof PatternFilterDef_LastModTime) {
				filterElem.setAttribute("type", "last-mod-ts");
				PatternFilterDef_LastModTime lastModTimeFilterDef = (PatternFilterDef_LastModTime) filterDef;
				PatternFilterDef_LastModTimeSetting setting = lastModTimeFilterDef
						.getSetting();
				if (setting == PatternFilterDef_LastModTimeSetting.NONE) {
					filterElem.setAttribute("setting", "none");
				} else if (setting == PatternFilterDef_LastModTimeSetting.MIN_AGE) {
					filterElem.setAttribute("setting", "min-age");
				} else if (setting == PatternFilterDef_LastModTimeSetting.MAX_AGE) {
					filterElem.setAttribute("setting", "max-age");
				} else {
					logger.warn("Unhandled last mod filter setting: " + setting);
				}
				int refValue = lastModTimeFilterDef.getReferenceValue();
				filterElem.setAttribute("ref-value", String.valueOf(refValue));
			} else if (filterDef instanceof PatternFilterDef_User) {
				filterElem.setAttribute("type", "user");
				PatternFilterDef_User userFilterDef = (PatternFilterDef_User) filterDef;
				PatternFilterDef_UserSetting setting = userFilterDef
						.getSetting();
				if (setting == PatternFilterDef_UserSetting.NONE) {
					filterElem.setAttribute("setting", "none");
				} else if (setting == PatternFilterDef_UserSetting.OWNER) {
					filterElem.setAttribute("setting", "owner");
				} else if (setting == PatternFilterDef_UserSetting.CONTRIBUTOR) {
					filterElem.setAttribute("setting", "contributor");
				} else if (setting == PatternFilterDef_UserSetting.NON_CONTRIBUTOR) {
					filterElem.setAttribute("setting", "non-contributor");
				} else {
					logger.warn("Unhandled user filter setting: " + setting);
				}

			} else {
				logger.warn("Unhandled filter type: " + filterDef);
			}

		}
		return filtersElem;
	}
}
