package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import java.util.Vector;

import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.ActionPackage;

import de.dfki.lasad.dataservice.lasad.xml.ActionPackageXmlConverter;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;
import de.uds.xml.XmlFragment;

public abstract class CfCreateObjectAction extends CfActionDuringExecution{	
	
	public CfCreateObjectAction(CfAction cfAction) {
		super(cfAction);
	}
	
	public abstract void moveToUpdatePhase(CreateObjectEvent uEvent);
	
	Vector<Action> buildCreateActions(String filename){
		CfObject elementObject = cfAction.getCfObjects().get(0);
		String mapId = elementObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING);
		
		String username = elementObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_USERNAME_STRING);
		if (username == null){
			username  = "unknown";
		}
		
		ActionPackage actionPackage = ActionPackageXmlConverter.createFromXml((XmlFragment)XmlFragment.getFragmentFromFile(filename));
		Vector<Action> actions = actionPackage.getActions();
		replaceInfo(actions, mapId, username);
		return actionPackage.getActions();
	}
	
	public boolean eventIsResponseToMe(CreateObjectEvent createEvent) {
		
		if (state == CfActionState.create){
			String createdType = createEvent.getEueObjectList().get(0).getType();
			String typeToCheck = cfAction.getCfObjects().get(0).getPropertyValue(MetaforaStrings.PROPERTY_TYPE_ELEMENT_TYPE_STRING);
			String createdMapId = createEvent.getSessionID().getIdAsString();
			String mapIdToCheck = cfAction.getCfObjects().get(0).getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING);
			
			typeToCheck = convertCfTypeToLasadType(typeToCheck);
			if ((createdType.equalsIgnoreCase(typeToCheck)) && createdMapId.equalsIgnoreCase(mapIdToCheck)){
				return true;
			}
		}
		return false;
	}
	
	private String convertCfTypeToLasadType(String cfName){
		if (cfName.equalsIgnoreCase(MetaforaStrings.OBJECT_TYPE_MY_MICROWORLD_STRING)){
			return "My Microworld";
		}
		if (cfName.equalsIgnoreCase(MetaforaStrings.OBJECT_TYPE_HELP_REQUEST_STRING)){
			return "Help Request";
		}
		return cfName;
	}
	
	
	
	

}
