package de.dfki.lasad.events.agents.configchange;

import de.dfki.lasad.events.EventImpl;

/**
 * Notification that the Feedback-Engine configuration or runtime has changed.
 * 
 * @author oliverscheuer
 * 
 */
public class AFStateChangedEvent extends EventImpl {

	private boolean changed = true;

	public AFStateChangedEvent(String srcCompId) {
		super(srcCompId);
	}

	public boolean isChanged() {
		return changed;
	}

	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	@Override
	public String toString() {
		return "AFStateChangedEvent [changed=" + changed + "]";
	}

}
