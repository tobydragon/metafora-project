package de.dfki.lasad.agents.data.meta;

/**
 * Metadata how to generate system actions (pedagogical strategies).
 * 
 * @author Oliver Scheuer
 * 
 */
public abstract class ActionType extends ServiceType {

	public ActionType(String agentID, String typeID) {
		super(agentID, typeID);
	}

}
