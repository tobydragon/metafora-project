package de.dfki.lasad.core.components.description;

import java.io.File;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.ConfigurationDatabase;
import de.dfki.lasad.core.components.configuration.IComponentConfiguration;
import de.dfki.lasad.core.components.instance.IComponent;
import de.dfki.lasad.session.SessionConfig;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class AbstractComponentDescription {

	static Log logger = LogFactory.getLog(AbstractComponentDescription.class);

	protected BasicDescription basicDescr;

	protected IComponentConfiguration configuration = null;

	public AbstractComponentDescription(BasicDescription basicDescr) {
		this.basicDescr = basicDescr;
	}

	public BasicDescription getBasicDescr() {
		return basicDescr;
	}

	public void setConfiguration(IComponentConfiguration configuration) {
		this.configuration = configuration;
	}

	public String getComponentID() {
		return basicDescr.id;
	}

	public String getClassName() {
		return basicDescr.classs;
	}

	public IComponentConfiguration getConfiguration() {
		return configuration;
	}

	/**
	 * 
	 * @param sConf
	 *            {@link SessionConfig} containing all session configuration
	 *            settings if component is tied to specific session, or
	 *            <code>null</code> if component is not tied to specific session
	 * @return
	 * @throws ComponentInitException
	 */
	public IComponent createInstance(SessionConfig sConf)
			throws ComponentInitException {
		IComponent component = null;
		try {
			component = (IComponent) Class.forName(basicDescr.classs)
					.newInstance();
			component.init(this, sConf);
			logger.info("Component created: " + component.toString());
		} catch (Exception e) {
			logger.error("Error: " + e.getMessage(), e);
			throw new ComponentInitException(
					"Error while trying to instantiate " + basicDescr.classs, e);
		}
		return component;
	}

	// should be called once all information is complete
	public void init() throws Exception {
		logger.debug("Init ComponentDescription: ["
				+ getClass().getSimpleName() + "], target component = "
				+ basicDescr.id);
		if (configuration == null && basicDescr.classs != null
				&& basicDescr.confclass != null) {
			// try to instantiate new configuration
			logger.debug("Instantiate config class: [" + basicDescr.confclass
					+ "] ...");

			IComponentConfiguration conf = (IComponentConfiguration) Class
					.forName(basicDescr.confclass).newInstance();
			conf.setComponentID(basicDescr.id);

			logger.debug("... DONE.");
			if (basicDescr.conffile != null) {
				File configHome = ConfigurationDatabase.getConfigHome();
				File compConfigFile = new File(configHome, basicDescr.conffile);

				logger.debug("Load config file "
						+ compConfigFile.getAbsolutePath() + " ...");
				conf.load(compConfigFile);
				logger.debug(" ... DONE.");
			}
			conf.init();
			this.configuration = conf;
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((basicDescr.id == null) ? 0 : basicDescr.id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)

			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractComponentDescription other = (AbstractComponentDescription) obj;
		if (basicDescr.id == null) {
			if (other.basicDescr.id != null)
				return false;
		} else if (!basicDescr.id.equals(other.basicDescr.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuffer retVal = new StringBuffer();

		retVal.append(getClass().getSimpleName());
		retVal.append(" [componentID=" + basicDescr.id + ", className="
				+ basicDescr.classs + ", configClassName="
				+ basicDescr.confclass + ", configFilePath="
				+ basicDescr.conffile + "]");

		return retVal.toString();
	}

}
