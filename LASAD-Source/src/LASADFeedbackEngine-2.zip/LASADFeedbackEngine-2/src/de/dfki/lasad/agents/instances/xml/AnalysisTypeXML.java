package de.dfki.lasad.agents.instances.xml;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.analysis.AnalysisResultDatatype;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class AnalysisTypeXML extends ServiceTypeXML {

	private static Log logger = LogFactory.getLog(AnalysisTypeXML.class);

	public static final String ELEMENT_NAME = "pattern";

	protected static ServiceID getServiceID(String agentID, Element elem) {
		String typeID = elem.getAttributeValue("id");
		return new ServiceID(agentID, typeID, ServiceClass.ANALYSIS);
	}

	protected static AnalysisResultDatatype getResultClass(Element elem) {
		String resultTypeString = elem.getAttributeValue("result-type");
		if ("object-binary-result".equals(resultTypeString)) {
			return AnalysisResultDatatype.object_binary_result;
		} else if ("user-binary-result".equals(resultTypeString)) {
			return AnalysisResultDatatype.user_binary_result;
		} else if ("session-binary-result".equals(resultTypeString)) {
			return AnalysisResultDatatype.session_binary_result;
		} else {
			logger.warn("(fromXML) Result type not handled: "
					+ resultTypeString);
			return null;
		}
	}

	protected static Element createPatternElement() {
		return new Element(ELEMENT_NAME);
	}

	protected static void addResultTypeAtt(Element patternElem,
			AnalysisType aType) {
		AnalysisResultDatatype resultClass = aType.getResultDatatype();
		String resultType = null;
		if (AnalysisResultDatatype.object_binary_result == resultClass) {
			resultType = "object-binary-result";
		} else if (AnalysisResultDatatype.user_binary_result == resultClass) {
			resultType = "user-binary-result";
		} else if (AnalysisResultDatatype.session_binary_result == resultClass) {
			resultType = "session-binary-result";
		} else {
			logger.warn("(toXML) Result type not handled: " + resultClass);
			return;
		}
		patternElem.setAttribute("result-type", resultType);
	}
}
