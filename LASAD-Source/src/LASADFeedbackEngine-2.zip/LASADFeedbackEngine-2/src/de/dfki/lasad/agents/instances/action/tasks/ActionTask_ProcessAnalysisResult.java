package de.dfki.lasad.agents.instances.action.tasks;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.instances.action.ActionAgent;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ActionTask_ProcessAnalysisResult extends ActionTask {

	private ActionAgent agent = null;
	private AnalysisResult result = null;

	public ActionTask_ProcessAnalysisResult(ActionAgent agent,
			AnalysisResult result) {
		this.agent = agent;
		this.result = result;
	}

	@Override
	public void run() {
		agent.processRecheckAnalysisResult(result);
	}

}
