package de.dfki.lasad.agents.logic.provision.actionsort;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgSortComparator_AllEqual extends MsgSortComparator {

	public MsgSortComparator_AllEqual(MsgSortComparator tieBreaker) {
		super(null);
	}

	@Override
	public int compare(ActionTypeResult result1, ActionTypeResult result2) {
		return 0;
	}

	@Override
	protected int compareImpl(ActionTypeResult result1, ActionTypeResult result2) {
		return 0;
	}

}
