package de.dfki.lasad.events.eue.admin.agent;

import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.eue.admin.EUEAdminEvent;

/**
 * Event regarding the administration of agents within the EUE graphical
 * front-end to administer and configure agents.
 * 
 * @author oliverscheuer
 * 
 */
public class EUEAgentAdminEvent extends EventImpl implements EUEAdminEvent {

	public EUEAgentAdminEvent(String srcCompId) {
		super(srcCompId);
	}
}
