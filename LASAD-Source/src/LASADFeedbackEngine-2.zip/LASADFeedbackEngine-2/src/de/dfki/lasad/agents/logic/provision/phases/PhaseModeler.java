package de.dfki.lasad.agents.logic.provision.phases;

import java.util.List;

import lasad.shared.dfki.meta.agents.action.ActionType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.sessionmodel.SessionModelChangeRecord;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class PhaseModeler implements PhaseModelerInterface {

	private static Log logger = LogFactory.getLog(PhaseModeler.class);

	protected boolean computePriorityFromMostLikelyPhaseOnly = true;
	protected PhaseModel phaseModel = null;

	@Override
	public abstract void processModelChanged(
			SessionModelChangeRecord changeRecord);

	@Override
	public List<Phase> getPhasesInDefinitionOrder() {
		return phaseModel.getPhasesInDefinitionOrder();
	}

	@Override
	public abstract void updatePhaseProbabilitiesIfNeeded();

	@Override
	public void assignPriority(ActionTypeResult typeResult) {
		updatePhaseProbabilitiesIfNeeded();
		ActionType actionType = typeResult.getActionType();
		double utility = 0;
		if (computePriorityFromMostLikelyPhaseOnly) {
			Phase mostLikelyPhase = phaseModel.getMostLikelyPhase();
			double typePriority = actionType.getPriorityDef().getPriority(
					mostLikelyPhase.getPhaseID());
			utility = typePriority;
		} else {
			double weightedPriority = 0;
			for (Phase phase : phaseModel.getPhasesInProbabilisticOrder()) {
				double phaseProb = phase.getProbability();
				double typePriority = actionType.getPriorityDef().getPriority(
						phase.getPhaseID());
				weightedPriority += (phaseProb * typePriority);
			}
			utility = weightedPriority;
		}
		logger.debug(typeResult.getActionType().getServiceID()
				+ ": assigned UTILITY value=" + utility);
		typeResult.setUtility(utility);
	}
}
