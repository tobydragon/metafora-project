package de.dfki.lasad.session.data.meta.ontology.base;

import de.dfki.lasad.session.data.meta.ontology.ComparisonGroup;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * Attribute derived from transcript type 
 * @author oliverscheuer
 *
 */
public class MatchedPassageType extends BaseType {

	private static MatchedPassageType instance = new MatchedPassageType();
	
	private MatchedPassageType(){
		super();
		lasadElementType = null;
		jessTemplateName = "matched-passage";
		addComponentSpecification(PropDescr.DEFAULT_COMPONENT_ID, "type_actual", JessDataType.STRING, ComparisonGroup.TEXT);
	}
	
	public static MatchedPassageType getInstance(){
		return instance;
	}
}
