package de.dfki.lasad.authoring.converter.pattern2jess;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.authoring.model.pattern.Comparison;
import de.dfki.lasad.authoring.model.pattern.Num2NumOperator;
import de.dfki.lasad.authoring.model.pattern.Operator;
import de.dfki.lasad.authoring.model.pattern.Set2SetOperator;
import de.dfki.lasad.authoring.model.pattern.Set2StringOperator;
import de.dfki.lasad.authoring.model.pattern.String2SetOperator;
import de.dfki.lasad.authoring.model.pattern.String2StringOperator;

/**
 * Generates Jess strings which represent {@link Comparison}s (constraints),
 * based on the kind of {@link Comparison} (value-2-value, component-2-value,
 * component-2-component). 'Values' are non-quantified expressions (constants
 * and variables bound to a fixed value); 'Components' are quantified
 * expressions (variables used within a 'forall' or 'exist' construct, i.e., the
 * variable represents one component of a set of values).
 * 
 * @author oliverscheuer
 * 
 */
public class JessComparisonGenerator {

	private static final Log logger = LogFactory
			.getLog(JessComparisonGenerator.class);

	public String getValue2ValueComparison(Comparison comparison,
			String leftExp, String rightExp) {
		Operator operator = comparison.getOperator();
		if (operator.equals(String2StringOperator.EQUAL)
				|| operator.equals(Num2NumOperator.EQUAL)) {
			return "&:(eq* " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(String2StringOperator.NOT_EQUAL)
				|| operator.equals(Num2NumOperator.NOT_EQUAL)) {
			return "&:(not (eq* " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Num2NumOperator.LESS)) {
			return "&:(< " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Num2NumOperator.LESS_OR_EQUAL)) {
			return "&:(<= " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Num2NumOperator.GREATER)) {
			return "&:(> " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Num2NumOperator.GREATER_OR_EQUAL)) {
			return "&:(>= " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(String2SetOperator.IN)) {
			return "&:(member$ " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(String2SetOperator.NOT_IN)) {
			return "&:(not(member$ " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Set2StringOperator.CONTAINS)) {
			return "&:(member$ " + rightExp + " " + leftExp + ")";
		} else if (operator.equals(Set2StringOperator.NOT_CONTAINS)) {
			return "&:(not(member$ " + rightExp + " " + leftExp + "))";
		} else if (operator.equals(Set2SetOperator.SUBSET)) {
			return "&:(= length$(complement$ " + leftExp + " " + rightExp
					+ ") 0)";
		} else if (operator.equals(Set2SetOperator.NOT_SUBSET)) {
			return "&:(> length$(complement$ " + leftExp + " " + rightExp
					+ ") 0)";
		} else if (operator.equals(Set2SetOperator.SUPERSET)) {
			return "&:(= length$(complement$ " + rightExp + " " + leftExp
					+ ") 0)";
		} else if (operator.equals(Set2SetOperator.NOT_SUPERSET)) {
			return "&:(> length$(complement$ " + rightExp + " " + leftExp
					+ ") 0)";
		} else if (operator.equals(Set2SetOperator.INTERSECT)) {
			return "&:(> length$(intersection$ " + leftExp + " " + rightExp
					+ ") 0)";
		} else if (operator.equals(Set2SetOperator.NOT_INTERSECT)) {
			return "&:(= length$(intersection$ " + leftExp + " " + rightExp
					+ ") 0)";
		}
		logger.error("Unhandled operator in 'getValue2ValueComparison()': "
				+ operator);
		return null;
	}

	public String getComponent2ValueComparison(Comparison comparison,
			String leftExp, String rightExp) {
		Operator operator = comparison.getOperator();
		if (operator.equals(Set2StringOperator.CONTAINS)) {
			// nested in EXISTS expression
			return "&:(eq " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2StringOperator.NOT_CONTAINS)) {
			// nested in FORALL expression
			return "&:(not(eq " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Set2SetOperator.SUBSET)) {
			// nested in EXISTS expression
			return "&:(member$ " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2SetOperator.NOT_SUBSET)) {
			// nested in FORALL expression
			return "&:(not(member$ " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Set2SetOperator.INTERSECT)) {
			// nested in EXISTS expression
			return "&:(member$ " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2SetOperator.NOT_INTERSECT)) {
			// nested in FORALL expression
			return "&:(not(member$ " + leftExp + " " + rightExp + "))";
		}
		logger.error("Unhandled operator in 'getComponent2ValueComparison()': "
				+ operator);
		return null;
	}

	public String getComponent2ComponentComparison(Comparison comparison,
			String leftExp, String rightExp) {
		Operator operator = comparison.getOperator();
		if (operator.equals(Set2SetOperator.SUBSET)) {
			return "&:(eq " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2SetOperator.SUPERSET)) {
			return "&:(eq " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2SetOperator.INTERSECT)) {
			return "&:(eq " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2SetOperator.NOT_SUBSET)) {
			return "&:(not(eq " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Set2SetOperator.NOT_SUPERSET)) {
			return "&:(not(eq " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Set2SetOperator.NOT_INTERSECT)) {
			return "&:(not(eq " + leftExp + " " + rightExp + "))";
		}
		logger.error("Unhandled operator in 'getComponent2ComponentComparison(): "
				+ operator);
		return null;
	}
}
