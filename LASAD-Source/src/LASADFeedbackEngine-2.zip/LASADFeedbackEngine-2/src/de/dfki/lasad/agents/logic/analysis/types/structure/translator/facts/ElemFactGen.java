package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import java.util.List;
import java.util.Map;

import de.dfki.lasad.agents.logic.analysis.types.structure.translator.Indent;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.agents.analysis.structure.model.LinkVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.NodeVariable;
import lasad.shared.dfki.meta.ontology.Ontology;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ElemFactGen {

	protected Ontology ontology;
	protected JessIDAndSlotNameGenerator idGen;

	// in
	private ElementVariable elemVar;
	private Map<ElementVariableProp, List<Comparison>> relevantElemProps2Comparisons;
	protected Bin bin;
	protected List<? extends ElementVariable> predecessors;
	protected boolean omitLinkSourceSlot = false;
	protected boolean omitLinkTargetSlot = false;

	// generated
	private ElemFactPropSlotsGen propSlotsGen;

	public ElemFactGen(JessIDAndSlotNameGenerator idGen, Ontology ontology,
			ElementVariable elemVar,
			Map<ElementVariableProp, List<Comparison>> propVars2Comparisons,
			Bin bin, List<? extends ElementVariable> predecessors) {
		this.idGen = idGen;
		this.ontology = ontology;
		this.elemVar = elemVar;
		this.relevantElemProps2Comparisons = propVars2Comparisons;
		this.bin = bin;
		this.predecessors = predecessors;

		propSlotsGen = new ElemFactPropSlotsGen(idGen, ontology,
				relevantElemProps2Comparisons, bin);
	}

	public ElemFactGen(JessIDAndSlotNameGenerator idGen, Ontology ontology,
			ElementVariable elemVar,
			Map<ElementVariableProp, List<Comparison>> propVars2Comparisons,
			Bin bin, List<? extends ElementVariable> predecessors,
			boolean omitLinkSourceSlot, boolean omitLinkTargetSlot) {
		this(idGen, ontology, elemVar, propVars2Comparisons, bin, predecessors);
		this.omitLinkSourceSlot = omitLinkSourceSlot;
		this.omitLinkTargetSlot = omitLinkTargetSlot;
	}

	public int getNumConstrainedSlots() {
		return propSlotsGen.getNumConstrainedSlots();
	}

	public String getString() {
		StringBuffer buf = new StringBuffer();

		String elemVarID = idGen.generateElemIDVar(elemVar);
		String predecessorIDConstrs = generateElemIDConstrs(predecessors);
		String idSlot = "(id " + elemVarID + predecessorIDConstrs + ")";

		String propSlots = propSlotsGen.getString();
		String deletedSlot = "(deleted FALSE)";

		if (elemVar instanceof NodeVariable) {
			buf.append("(node");
		} else {
			LinkVariable linkVar = (LinkVariable) elemVar;
			buf.append("(link");
			if (linkVar.getSource() != null && !omitLinkSourceSlot) {
				String sourceSlot = "(source_id "
						+ idGen.generateElemIDVar(linkVar.getSource()) + ")";
				buf.append("\n");
				buf.append(Indent.apply(sourceSlot, Indentations.INDENT_LINK));
			}
			if (linkVar.getTarget() != null && !omitLinkTargetSlot) {
				String targetSlot = "(target_id "
						+ idGen.generateElemIDVar(linkVar.getTarget()) + ")";
				buf.append("\n");
				buf.append(Indent.apply(targetSlot, Indentations.INDENT_LINK));
			}
		}
		buf.append("\n");
		buf.append(Indent.apply(idSlot, Indentations.INDENT_LINK));
		buf.append("\n");
		if (propSlots.length() > 0) {
			buf.append(Indent.apply(propSlots, Indentations.INDENT_LINK));
			buf.append("\n");
		}
		buf.append(Indent.apply(deletedSlot, Indentations.INDENT_LINK));
		buf.append(")");
		return buf.toString();
	}

	/**
	 * Generates element id constraints (i.e., an element id is unequal to all
	 * predecessor ids), to be used within an 'id' slot
	 * 
	 * @param predecessors
	 * @return
	 */
	private String generateElemIDConstrs(
			List<? extends ElementVariable> predecessors) {
		StringBuffer buf = new StringBuffer();
		for (ElementVariable pred : predecessors) {
			buf.append("&~" + idGen.generateElemIDVar(pred));
		}
		return buf.toString();
	}

}
