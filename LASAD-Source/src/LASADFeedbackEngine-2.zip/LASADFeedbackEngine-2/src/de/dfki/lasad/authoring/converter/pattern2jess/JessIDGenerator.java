package de.dfki.lasad.authoring.converter.pattern2jess;

import de.dfki.lasad.authoring.model.pattern.ElementVariable;
import de.dfki.lasad.authoring.model.pattern.PropertyVariable;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * Generates IDs, to be used within Jess, in a uniform way.
 * @author oliverscheuer
 * 
 */
public class JessIDGenerator {

	public static final int NO_APPENDIX = -1;

	public String generateConstantFactID(String patternID,
			int constNumID) {
		return "const_" + patternID + "_" + constNumID;
	}

	public String generateConstantFactValueTempVar(int constNumID) {
		return "?const_" + constNumID;
	}

	public String generateElemIDVar(ElementVariable elemVar) {
		return "?elem" + elemVar.getVarID();
	}

	public String generateElemIDTempVar(ElementVariable elemVar,
			int appendixNum) {
		return "?elem_" + elemVar.getVarID() + appendixNum;
	}

	public String generateNodeInNeigborsVar(ElementVariable elemVar) {
		return "$?inneighbors_" + elemVar.getVarID();
	}
	
	public String generateNodeOutNeigborsVar(ElementVariable elemVar) {
		return "$?outneighbors_" + elemVar.getVarID();
	}
	
	public String generateNodeNeigborsVar(ElementVariable elemVar) {
		return "$?neighbors_" + elemVar.getVarID();
	}
	
	public String generatePropVarID(PropertyVariable propVar,
			int appendixNum, boolean useAppendix, boolean listElem) {

		ElementVariable elemVar = propVar.getElementVar();
		PropDescr prop = propVar.getProp();

		String baseID = "prop_";
		if (prop.hasOnlySingleComponent()) {
			baseID = baseID + elemVar.getVarID() + "_" + propVar.getProp();
		} else {
			baseID = baseID + elemVar.getVarID() + "_" + propVar.getPropId()
					+ "_" + propVar.getCompID();
		}

		String prefix = "";
		if (listElem) {
			prefix = "?";
		} else {
			JessDataType jessDataType = prop.getSlotDataType(propVar
					.getCompID());
			prefix = (jessDataType.equals(JessDataType.LIST)) ? "$?" : "?";
		}

		String appendix = "";
		if (useAppendix) {
			appendix = "_c" + appendixNum;
		}

		return prefix + baseID + appendix;
	}

}
