package de.dfki.lasad.agents.logic.action.patternfilter;

import de.dfki.lasad.agents.data.analysis.user.UserResult;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.UserIDAll;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class UserFilter_IsUser extends UserFilter {

	private UserID referenceUser;

	public UserFilter_IsUser(UserID referenceUser) {
		this.referenceUser = referenceUser;
	}

	@Override
	public boolean keep(UserResult result) {
		return (referenceUser instanceof UserIDAll)
				|| referenceUser.equals(result.getUserID());
	}

}
