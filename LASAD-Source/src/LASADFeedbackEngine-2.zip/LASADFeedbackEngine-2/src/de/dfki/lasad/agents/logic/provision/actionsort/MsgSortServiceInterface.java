package de.dfki.lasad.agents.logic.provision.actionsort;

import java.util.List;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public interface MsgSortServiceInterface {

	public void sort(List<ActionTypeResult> results);

}