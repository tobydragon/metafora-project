package de.dfki.lasad.events.eue.admin.config;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.eue.admin.EUEAdminEvent;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class SessionListEvent extends EUEConfigInfoEvent {

	private List<String> sessionIDs = new Vector<String>();

	public SessionListEvent(String srcCompId) {
		super(srcCompId);
	}

	public List<String> getSessionIDs() {
		return sessionIDs;
	}

	public void setSessionIDs(List<String> sessionIDs) {
		this.sessionIDs = sessionIDs;
	}

	@Override
	public String toString() {
		return "SessionListEvent [sessionIDs=" + sessionIDs + "]";
	}

}
