package de.dfki.lasad.agents.logic.provision.phases;

import java.util.List;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.sessionmodel.SessionModelChangeRecord;

public interface PhaseModelerInterface {

	/**
	 * If phase model considers the current state in session model
	 * 
	 * @param changeRecord
	 */
	public abstract void processModelChanged(
			SessionModelChangeRecord changeRecord);

	public abstract List<Phase> getPhasesInDefinitionOrder();

	public abstract void updatePhaseProbabilitiesIfNeeded();

	public abstract void assignPriority(ActionTypeResult typeResult);

}