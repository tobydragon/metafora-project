package de.dfki.lasad.authoring.model.pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author Almer Bolatov, Oliver Scheuer
 *
 */
public enum String2StringOperator implements Operator{
	EQUAL("STRING_EQUAL"),
	NOT_EQUAL("STRING_NOT_EQUAL");
//	contains_kw,			RED
//	not_contains_kw			RED
	
	private static final Log logger = LogFactory.getLog(String2StringOperator.class);
	
	private final String operator;

	String2StringOperator(String operator) {
		this.operator = operator;
	}
	
	public String2StringOperator invert() {
		if (equals(EQUAL)) {
			return EQUAL;
		} else if (equals(NOT_EQUAL)) {
			return NOT_EQUAL;
		} else {
			logger.error("Error in method invert()");
			return null;
		}
	}
}
