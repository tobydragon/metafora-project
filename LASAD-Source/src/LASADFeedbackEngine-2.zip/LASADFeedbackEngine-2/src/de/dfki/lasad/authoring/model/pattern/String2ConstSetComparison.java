package de.dfki.lasad.authoring.model.pattern;

import java.util.List;

/**
 * Comparison of a string variable to some constant value set.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class String2ConstSetComparison extends Comparison{
	private String2SetOperator operator;
	private List<String> rightExpr;

	public String2SetOperator getOperator() {
		return operator;
	}

	public void setOperator(String2SetOperator operator) {
		this.operator = operator;
	}

	public List<String> getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(List<String> rightExpr) {
		this.rightExpr = rightExpr;
	}

}
