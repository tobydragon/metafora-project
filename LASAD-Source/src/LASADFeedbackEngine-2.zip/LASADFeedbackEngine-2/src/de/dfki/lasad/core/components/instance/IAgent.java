package de.dfki.lasad.core.components.instance;

import java.util.List;

import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.ServiceType;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.session.Session;
import de.dfki.lasad.session.SessionActiveRuntime;

/**
 * {@link IComponent} that can be attached to a {@link Session} to provide
 * analysis services ({@link getAnalysisTypes()}) and feedback services ({@link
 * getActionTypes()}).
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent})
 * 
 * @author oliverscheuer
 * 
 */
public interface IAgent extends IComponent {

	public void doWire(IDataService dataService,
			SessionActiveRuntime activeRuntime);

	// notification methods (execution time)
	public void onEvent(Event event);

	public List<AnalysisType> getAnalysisTypes();

	public AnalysisType getAnalysisType(String typeID);

	public List<ActionType> getActionTypes();

	public ActionType getActionType(String typeID);

	public List<ServiceType> getTypesToPublish();

}
