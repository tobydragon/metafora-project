package de.dfki.lasad.core.components.instance;

import java.util.List;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.ServiceType;

import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.OnRequestServiceSpec;
import de.dfki.lasad.session.Session;
import de.dfki.lasad.session.SessionActiveRuntime;

/**
 * {@link IComponent} that can be attached to a {@link Session} to provide
 * analysis services ({@link getAnalysisTypes()}) and feedback services ({@link
 * getActionTypes()}).
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent})
 * 
 * @author oliverscheuer
 * 
 */
public interface IAgent extends IComponent {

	public void doWire(IDataService dataService,
			SessionActiveRuntime activeRuntime);

	// notification methods (execution time)
	public void onEvent(Event event);

	public List<ServiceType> getServiceTypes();

	public ServiceType getServiceType(ServiceID serviceID);

	public List<OnRequestServiceSpec> getTypesToPublish();

}
