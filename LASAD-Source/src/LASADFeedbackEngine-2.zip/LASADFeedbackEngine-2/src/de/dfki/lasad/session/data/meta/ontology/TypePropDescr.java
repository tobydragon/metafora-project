package de.dfki.lasad.session.data.meta.ontology;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class TypePropDescr extends StandardPropDescr {

	public TypePropDescr() {
		super("type", null, "type", JessDataType.STRING, ComparisonGroup.TYPE);
	}
	
}
