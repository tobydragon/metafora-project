package de.dfki.lasad.agents.data.analysis.object;

import lasad.shared.dfki.meta.agents.analysis.AnalysisType;
import de.dfki.lasad.agents.data.analysis.BinaryResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ObjectBinaryResult extends ObjectResult implements BinaryResult {

	protected boolean value = true;

	public ObjectBinaryResult(AnalysisType analysisType) {
		super(analysisType);
	}

	public ObjectBinaryResult(AnalysisType analysisType,
			AnalyzableEntity analyzedEntity) {
		super(analysisType, analyzedEntity);
	}

	public ObjectBinaryResult(AnalysisType analysisType,
			AnalyzableEntity analyzedEntity, boolean value) {
		this(analysisType, analyzedEntity);
		this.value = value;
	}

	public boolean getValue() {
		return value;
	}

	public void setValue(boolean value) {
		this.value = value;
	}

	@Override
	public String getValueAsString() {
		return String.valueOf(value);
	}

	@Override
	public String toString() {
		return "ObjectBinaryResult [value=" + value + ", analyzedEntity="
				+ analyzedEntity + ", contributors=" + contributors
				+ ", lastModificationTime=" + lastModificationTime + ", id="
				+ id + ", analysisType=" + analysisType + ", detectionTs="
				+ detectionTs + ", properties=" + properties + "]";
	}

	@Override
	public String toSimpleString() {
		return getClass().getSimpleName() + ": [id=" + id + ", type="
				+ analysisType.getServiceID() + ", entity=" + analyzedEntity
				+ "]";
	}

}
