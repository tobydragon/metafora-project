package de.dfki.lasad.authoring.model.pattern;

/**
 * Comparison of a set variable to some string variable.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class Set2VarStringComparison extends VariableComparison{
	private Set2StringOperator operator;
	private PropertyVariable rightExpr;

	public Set2StringOperator getOperator() {
		return operator;
	}

	public void setOperator(Set2StringOperator operator) {
		this.operator = operator;
	}

	public PropertyVariable getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(PropertyVariable rightExpr) {
		this.rightExpr = rightExpr;
	}

	protected VariableComparison getInverseBasic() {
		String2VarSetComparison inverted = new String2VarSetComparison();
		inverted.setOperator(getOperator().invert());
		return inverted;
	}
}
