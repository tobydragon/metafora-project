package de.dfki.lasad.sessionmodel.counter.constraints;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class NumConstr extends Constr {

	public static final String OPERATOR_GREATER = "GREATER";
	public static final String OPERATOR_LESS = "LESS";

	long referenceValue;

	public NumConstr(String operator, long referenceValue) {
		this.referenceValue = referenceValue;
		super.operator = operator;
	}

	public long getReferenceValue() {
		return referenceValue;
	}

	public void setReferenceValue(long referenceValue) {
		this.referenceValue = referenceValue;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ (int) (referenceValue ^ (referenceValue >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		NumConstr other = (NumConstr) obj;
		if (referenceValue != other.referenceValue)
			return false;
		return true;
	}
	
	

}
