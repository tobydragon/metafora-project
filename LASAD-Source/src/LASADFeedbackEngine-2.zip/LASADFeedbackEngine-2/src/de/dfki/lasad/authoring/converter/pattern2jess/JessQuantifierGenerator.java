package de.dfki.lasad.authoring.converter.pattern2jess;

/**
 * Generates Jess patterns by combining given Fact patterns within quantified
 * expressions (exists, forall, exists-forall, forall-exists)
 * 
 * @author oliverscheuer
 * 
 */
public class JessQuantifierGenerator {

	public static final String INDENT_EXISTS = "    ";
	public static final String INDENT_EXISTS_AND = "        ";
	public static final String INDENT_FORALL = "    ";

	public String generateExistsConstr(String factExpr) {

		StringBuffer buf = new StringBuffer();
		buf.append("(exists");
		buf.append("\n");
		buf.append(Indent.apply(factExpr, INDENT_EXISTS));
		buf.append(")");
		return buf.toString();
	}

	public String generateForallConstr(String propFactMatchExpr,
			String propFactConstrExpr) {
		StringBuffer buf = new StringBuffer();
		buf.append("(forall");
		buf.append("\n");
		buf.append(Indent.apply(propFactMatchExpr, INDENT_FORALL));
		buf.append("\n");
		buf.append(Indent.apply(propFactConstrExpr, INDENT_FORALL));
		buf.append(")");
		return buf.toString();
	}

	public String generateExistsForallConstr(String existsExpr,
			String forallMatchExpr, String forallConstrExpr) {
		StringBuffer buf = new StringBuffer();
		buf.append("(exists(and");
		buf.append("\n");
		buf.append(Indent.apply(existsExpr, INDENT_EXISTS_AND));
		buf.append("\n");
		buf.append(INDENT_EXISTS_AND + "(forall");
		buf.append("\n");
		buf.append(Indent.apply(forallMatchExpr, INDENT_EXISTS_AND
				+ INDENT_FORALL));
		buf.append("\n");
		buf.append(Indent.apply(forallConstrExpr, INDENT_EXISTS_AND
				+ INDENT_FORALL));
		buf.append(")))");
		return buf.toString();
	}

	public String generateExistsExistsConstr(String existsFactExpr1,
			String existsFactExpr2) {
		StringBuffer buf = new StringBuffer();
		buf.append("(exists(and");
		buf.append("\n");
		buf.append(Indent.apply(existsFactExpr1, INDENT_EXISTS_AND));
		buf.append("\n");
		buf.append(INDENT_EXISTS_AND + "(exists");
		buf.append("\n");
		buf.append(Indent.apply(existsFactExpr2, INDENT_EXISTS_AND
				+ INDENT_EXISTS));
		buf.append(")))");
		return buf.toString();
	}

	public String generateForallForallConstr(String propFactMatchExpr1,
			String propFactMatchExpr2, String propFactConstrExpr2) {
		StringBuffer buf = new StringBuffer();
		buf.append("(forall");
		buf.append("\n");
		buf.append(Indent.apply(propFactMatchExpr1, INDENT_FORALL));
		buf.append("\n");
		buf.append(INDENT_FORALL + "(forall");
		buf.append("\n");
		buf.append(Indent.apply(propFactMatchExpr2, INDENT_FORALL
				+ INDENT_FORALL));
		buf.append("\n");
		buf.append(Indent.apply(propFactConstrExpr2, INDENT_FORALL
				+ INDENT_FORALL));
		buf.append(")))");
		return buf.toString();
	}

	public String generateForallExistsConstr(
			String propFactMatchExprVarBinding, String existsFactExpr) {
		StringBuffer buf = new StringBuffer();
		buf.append("(forall");
		buf.append("\n");
		buf.append(Indent.apply(propFactMatchExprVarBinding, INDENT_FORALL));
		buf.append("\n");
		buf.append(INDENT_FORALL + "(exists");
		buf.append(Indent.apply(existsFactExpr, INDENT_FORALL + INDENT_FORALL));
		buf.append(")))");
		return buf.toString();
	}

	public static void main(String[] args) {
		StringBuffer f1 = new StringBuffer();
		f1.append("(node" + "\n");
		f1.append("    (id ?n13)" + "\n");
		f1.append("    (neigbors ?n11 ?n9))");

		StringBuffer f2 = new StringBuffer();
		f2.append("(node" + "\n");
		f2.append("    (id ?n2)" + "\n");
		f2.append("    (neigbors ?n1 ?n3 ?n4))");

		StringBuffer f3 = new StringBuffer();
		f3.append("(node" + "\n");
		f3.append("    (id ?n999)" + "\n");
		f3.append("    (neigbors ?n1))");

		JessQuantifierGenerator qGen = new JessQuantifierGenerator();
		System.out.println(qGen.generateExistsConstr(f1.toString()) + "\n");
		System.out.println(qGen.generateForallConstr(f1.toString(),
				f2.toString())
				+ "\n");
		System.out.println(qGen.generateExistsForallConstr(f1.toString(),
				f2.toString(), f3.toString())
				+ "\n");
		System.out.println(qGen.generateExistsExistsConstr(f1.toString(),
				f2.toString())
				+ "\n");
		System.out.println(qGen.generateForallExistsConstr(f1.toString(),
				f2.toString())
				+ "\n");
		System.out.println(qGen.generateForallForallConstr(f1.toString(),
				f2.toString(), f3.toString())
				+ "\n");
	}

}
