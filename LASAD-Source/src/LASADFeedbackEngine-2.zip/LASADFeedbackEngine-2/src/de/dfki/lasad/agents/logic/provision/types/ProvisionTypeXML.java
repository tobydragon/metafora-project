package de.dfki.lasad.agents.logic.provision.types;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.common.ActionListDef;
import lasad.shared.dfki.meta.agents.provision.ProvisionTimeDef;
import lasad.shared.dfki.meta.agents.provision.RecipientDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import de.dfki.lasad.agents.instances.xml.ServiceTypeXML;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ProvisionTypeXML extends ServiceTypeXML {

	public static final String ELEMENT_NAME = "provision";

	private static Log logger = LogFactory.getLog(ProvisionTypeXML.class);

	protected static ServiceID getServiceID(String agentID, Element provElem) {
		String typeID = provElem.getAttributeValue("id");
		return new ServiceID(agentID, typeID, ServiceClass.PROVISION);
	}

	protected static ActionListDef getProvidedActions(String agentID,
			Element provElem) {
		Element provActionsElem = provElem
				.getChild(ProvidedActionsDefXML.ELEMENT_NAME);
		return ProvidedActionsDefXML.fromXML(agentID, provActionsElem);
	}

	protected static ProvisionTimeDef getProvisionTimeDef(Element provElem) {
		Element provTimeElem = provElem
				.getChild(ProvisionTimeDefXML.ELEMENT_NAME);
		return ProvisionTimeDefXML.fromXML(provTimeElem);
	}

	protected static RecipientDef getRecipientDef(Element provElem) {
		Element recipientElem = provElem.getChild(RecipientDefXML.ELEMENT_NAME);
		return RecipientDefXML.fromXML(recipientElem);
	}

	protected static Element createProvisionElement() {
		return new Element(ELEMENT_NAME);
	}

	protected static void addProvidedActionsElem(Element provElem,
			ActionListDef provActionsDef) {
		Element provActionsElem = ProvidedActionsDefXML.toXML(provActionsDef);
		provElem.addContent(provActionsElem);
	}

	protected static void addProvisionTimeDefElem(Element provElem,
			ProvisionTimeDef provTimeDef) {
		Element provTimeElem = ProvisionTimeDefXML.toXML(provTimeDef);
		provElem.addContent(provTimeElem);
	}

	protected static void addRecipientDefElem(Element provElem,
			RecipientDef recipientDef) {
		Element recipientElem = RecipientDefXML.toXML(recipientDef);
		provElem.addContent(recipientElem);
	}

}
