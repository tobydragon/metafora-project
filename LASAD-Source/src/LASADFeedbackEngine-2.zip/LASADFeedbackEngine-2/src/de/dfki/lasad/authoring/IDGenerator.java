package de.dfki.lasad.authoring;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ConfigurationDatabase;
import de.dfki.lasad.core.ConfigurationManager;
import de.dfki.lasad.core.components.description.AgentDescription;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;

/**
 * Generates fresh agent service ids.
 * 
 * @author oliverscheuer
 * 
 */
public class IDGenerator {

	private static Log logger = LogFactory.getLog(IDGenerator.class);

	private static final String AGENT_PREFIX = "agent-";
	private static final String ANALYSIS_PREFIX = "analysis-";
	private static final String ACTION_PREFIX = "action-";
	private static final String PROVISION_PREFIX = "provision-";

	private ConfigurationManager configManager = null;

	private int agentSeqNum = 1;

	private int analysisSeqNum = 1;
	private int actionSeqNum = 1;
	private int provisionSeqNum = 1;

	public IDGenerator(ConfigurationManager configManager) {
		this.configManager = configManager;
	}

	public String getFreshAgentID() {
		String id = AGENT_PREFIX + agentSeqNum++;

		boolean agentIDInUse = (configManager.getResourcesManager()
				.getAgentDescription(id) != null);
		boolean agentFolderInUse = ConfigurationDatabase
				.isAgentConfHomeDirAlreadyInUse(id);

		if (agentIDInUse || agentFolderInUse) {
			id = getFreshAgentID();
		}
		return id;
	}

	public ServiceID getFreshServiceID(String agentID, ServiceClass serviceClass) {
		String typeID = null;
		if (ServiceClass.ANALYSIS.equals(serviceClass)) {
			typeID = ANALYSIS_PREFIX + analysisSeqNum++;
		} else if (ServiceClass.ACTION.equals(serviceClass)) {
			typeID = ACTION_PREFIX + actionSeqNum++;
		} else if (ServiceClass.PROVISION.equals(serviceClass)) {
			typeID = PROVISION_PREFIX + provisionSeqNum++;
		} else {
			logger.error("Unhandled ServiceClass: " + serviceClass);
			return null;
		}
		ServiceID serviceID = new ServiceID(agentID, typeID, serviceClass);

		boolean serviceIDInUse = false;
		AgentDescription ad = configManager.getResourcesManager()
				.getAgentDescription(agentID);
		if (ad != null) {
			serviceIDInUse = (ad.getServiceType(serviceID) != null);

		}

		// only relevant for analysis services
		boolean patternFileInUse = false;
		if (ServiceClass.ANALYSIS.equals(serviceClass)) {
			patternFileInUse = ConfigurationDatabase
					.isAgentConfigPatternFileAlreadyInUse(serviceID);
		}

		if (serviceIDInUse || patternFileInUse) {
			serviceID = getFreshServiceID(agentID, serviceClass);
		}
		return serviceID;
	}
}
