package de.dfki.lasad.core;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import de.dfki.lasad.core.components.collections.AgentRuntimeConfig;
import de.dfki.lasad.core.components.collections.AgentRuntimeConfigXML;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.core.components.instance.ISessionModel;
import de.dfki.lasad.events.agents.configchange.AFStateChangedEventListener;
import de.dfki.lasad.events.agents.configchange.Agent2OntologyMappingAddedEvent;
import de.dfki.lasad.events.agents.configchange.Agent2OntologyMappingDeletedEvent;
import de.dfki.lasad.events.agents.configchange.Agent2SessionMappingAddedEvent;
import de.dfki.lasad.events.agents.configchange.Agent2SessionMappingDeletedEvent;
import de.dfki.lasad.events.agents.configchange.AgentMappingsDeleted;
import de.dfki.lasad.session.Session;
import de.dfki.lasad.util.XMLUtil;

/**
 * Provides access to the currently configured runtime (i.e., which
 * {@link IDataService} and {@link ISessionModel} to use, which {@link IAgent}s
 * to use).
 * 
 * <br/><br/>
 * <b>NOTE:</b> The configured runtime does not necessarily correspond to the currently
 * used runtime. The configured runtime will only be instantiated when a
 * {@link Session} is (re-)started ({@link Session#tryStartServices()).
 * 
 * @author oliverscheuer
 * 
 */
public class RuntimeConfigManager {

	static Log logger = LogFactory.getLog(RuntimeConfigManager.class);

	private List<AFStateChangedEventListener> afStateChangedListeners = new Vector<AFStateChangedEventListener>();

	private String dataServiceID;
	private String sessionModelID;

	private AgentRuntimeConfig agentRuntime;

	public void loadRuntimeConf() {
		loadDSConf();
		loadModelConf();
		loadAgentRuntimeConf();

		logRuntimeConf();
	}

	public void addAgent2SessionMapping(String agentID, String sessionID) {
		boolean configChanged = false;
		boolean mappingExistant = this.agentRuntime
				.containsAgentToSessionAssignment(agentID, sessionID);
		if (!mappingExistant) {
			this.agentRuntime.addAgent2Session(agentID, sessionID);
			writeAgentRuntime();
			configChanged = true;
		}
		notifyListenersAgent2SessionMappingAdded(agentID, sessionID,
				configChanged);
	}

	public void removeAgent2SessionMapping(String agentID, String sessionID) {
		boolean configChanged = false;
		boolean mappingExistant = this.agentRuntime
				.containsAgentToSessionAssignment(agentID, sessionID);
		if (mappingExistant) {
			this.agentRuntime.removeAgent2SessionAssignment(agentID, sessionID);
			writeAgentRuntime();
			configChanged = true;
		}
		notifyListenersAgent2SessionMappingDeleted(agentID, sessionID,
				configChanged);
	}

	public void addAgent2OntologyMapping(String agentID, String ontologyID) {
		boolean configChanged = false;
		boolean mappingExistant = this.agentRuntime
				.containsAgentToOntologyAssignment(agentID, ontologyID);
		if (!mappingExistant) {
			this.agentRuntime.addAgent2Ontology(agentID, ontologyID);
			writeAgentRuntime();
			configChanged = true;
		}
		notifyListenersAgents2OntologiesMappingAdded(agentID, ontologyID,
				configChanged);
	}

	public void removeAgent2OntologyMapping(String agentID, String ontologyID) {
		boolean configChanged = false;
		boolean mappingExistant = this.agentRuntime
				.containsAgentToOntologyAssignment(agentID, ontologyID);
		if (mappingExistant) {
			this.agentRuntime.removeAgent2OntologyAssignment(agentID,
					ontologyID);
			writeAgentRuntime();
			configChanged = true;
		}
		notifyListenersAgents2OntologiesMappingDeleted(agentID, ontologyID,
				configChanged);
	}

	public void deleteAgentRuntimeEntries(String agentID) {
		List<String> changedSessions = this.agentRuntime
				.removeAgentFromSessions(agentID);
		List<String> changedOntologies = this.agentRuntime
				.removeAgentFromOntologies(agentID);
		boolean configChanged = false;
		if (changedSessions.size() > 0 || changedOntologies.size() > 0) {
			writeAgentRuntime();
			configChanged = true;
		}

		notifyListenersAgentMappingsDeleted(agentID, changedSessions,
				changedOntologies, configChanged);
	}

	public String getRuntimeDS() {
		return dataServiceID;
	}

	public String getRuntimeModel() {
		return sessionModelID;
	}

	public AgentRuntimeConfig getAgentRuntime() {
		return agentRuntime;
	}

	public void setAgentRuntime(AgentRuntimeConfig agentRuntime) {
		this.agentRuntime = agentRuntime;
	}

	private void writeAgentRuntime() {
		File runtimeAgentsFile = ConfigurationDatabase.getAgentsRuntimeFile();
		AgentRuntimeConfigXML.updateXMLFile(runtimeAgentsFile,
				this.agentRuntime);
	}

	private void loadDSConf() {
		File basicRuntimeFile = ConfigurationDatabase.getRuntimeBasicFile();
		this.dataServiceID = parseDSRuntime(basicRuntimeFile);
	}

	private void loadModelConf() {
		File basicRuntimeFile = ConfigurationDatabase.getRuntimeBasicFile();
		this.sessionModelID = parseModelRuntime(basicRuntimeFile);
	}

	private void loadAgentRuntimeConf() {
		File runtimeAgentsFile = ConfigurationDatabase.getAgentsRuntimeFile();
		this.agentRuntime = parseAgentRuntimeConf(runtimeAgentsFile);
	}

	private String parseDSRuntime(File f) {
		try {
			Element rootElem = XMLUtil.file2xmlElem(f);

			Iterator<Element> iter = selectDSElements(rootElem).iterator();
			while (iter.hasNext()) {
				Element elem = iter.next();
				String dsID = elem.getAttributeValue("id");
				return dsID;
			}
		} catch (Exception e) {
			logger.error("Error in 'parseDSRuntime(...)'", e);
		}
		logger.error("Error in 'parseDSRuntime(...)': no data service id defined.");
		return null;

	}

	private String parseModelRuntime(File f) {
		try {
			Element rootElem = XMLUtil.file2xmlElem(f);

			Iterator<Element> iter = selectModelElements(rootElem).iterator();
			while (iter.hasNext()) {
				Element elem = iter.next();
				String sModelID = elem.getAttributeValue("id");
				return sModelID;
			}
		} catch (Exception e) {
			logger.error("Error in 'parseModelRuntime(...)'", e);
		}
		logger.error("Error in 'parseModelRuntime(...)': no session model id defined.");
		return null;
	}

	private AgentRuntimeConfig parseAgentRuntimeConf(File f) {
		try {
			Element rootElem = XMLUtil.file2xmlElem(f);
			return AgentRuntimeConfigXML.fromXML(rootElem);

		} catch (Exception e) {
			logger.error("Error in 'loadAgentRuntimeConf()'", e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	private List<Element> selectDSElements(Element elem) {
		return elem.getChildren("dataservice");
	}

	@SuppressWarnings("unchecked")
	private List<Element> selectModelElements(Element elem) {
		return elem.getChildren("sessionmodel");
	}

	private void logRuntimeConf() {
		logger.info("#### Runtime DataSevice ID ####");
		logger.info(dataServiceID);

		logger.info("#### Runtime SessionModel ID ####");
		logger.info(sessionModelID);

		logger.info("#### Runtime Session Agent IDs ####");

		for (String sessionID : agentRuntime.getSessionIDs()) {
			List<String> agentIDs = agentRuntime.getAgentsForSession(sessionID);

			StringBuffer agentStringBuf = new StringBuffer();
			agentStringBuf.append("{");
			for (Iterator<String> agentIDIter = agentIDs.iterator(); agentIDIter
					.hasNext();) {
				agentStringBuf.append(agentIDIter.next());
				if (agentIDIter.hasNext()) {
					agentStringBuf.append(", ");
				}
			}
			agentStringBuf.append("}");

			logger.info("session = " + sessionID + " " + agentStringBuf);
		}

		logger.info("#### Runtime Ontology Agent IDs ####");

		for (String ontologyID : agentRuntime.getOntologyIDs()) {
			List<String> agentIDs = agentRuntime
					.getAgentsForOntology(ontologyID);

			StringBuffer agentStringBuf = new StringBuffer();
			agentStringBuf.append("{");
			for (Iterator<String> agentIDIter = agentIDs.iterator(); agentIDIter
					.hasNext();) {
				agentStringBuf.append(agentIDIter.next());
				if (agentIDIter.hasNext()) {
					agentStringBuf.append(", ");
				}
			}
			agentStringBuf.append("}");

			logger.info("ontology = " + ontologyID + " " + agentStringBuf);
		}
	}

	public void addListener(AFStateChangedEventListener l) {
		afStateChangedListeners.add(l);
	}

	private void notifyListenersAgents2OntologiesMappingAdded(String agentID,
			String ontologyID, boolean configChanged) {
		Agent2OntologyMappingAddedEvent a2oChangedEv = new Agent2OntologyMappingAddedEvent(
				getClass().toString());
		a2oChangedEv.setAgentID(agentID);
		a2oChangedEv.setOntologyID(ontologyID);
		a2oChangedEv.setChanged(configChanged);
		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(a2oChangedEv);
		}
	}

	private void notifyListenersAgents2OntologiesMappingDeleted(String agentID,
			String ontologyID, boolean configChanged) {
		Agent2OntologyMappingDeletedEvent a2oChangedEv = new Agent2OntologyMappingDeletedEvent(
				getClass().toString());
		a2oChangedEv.setAgentID(agentID);
		a2oChangedEv.setOntologyID(ontologyID);
		a2oChangedEv.setChanged(configChanged);
		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(a2oChangedEv);
		}
	}

	private void notifyListenersAgent2SessionMappingAdded(String agentID,
			String sessionID, boolean configChanged) {
		Agent2SessionMappingAddedEvent a2oChangedEv = new Agent2SessionMappingAddedEvent(
				getClass().toString());
		a2oChangedEv.setAgentID(agentID);
		a2oChangedEv.setSessionID(sessionID);
		a2oChangedEv.setChanged(configChanged);
		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(a2oChangedEv);
		}
	}

	private void notifyListenersAgent2SessionMappingDeleted(String agentID,
			String sessionID, boolean configChanged) {
		Agent2SessionMappingDeletedEvent a2oChangedEv = new Agent2SessionMappingDeletedEvent(
				getClass().toString());
		a2oChangedEv.setAgentID(agentID);
		a2oChangedEv.setSessionID(sessionID);
		a2oChangedEv.setChanged(configChanged);
		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(a2oChangedEv);
		}
	}

	private void notifyListenersAgentMappingsDeleted(String agentID,
			List<String> sessionIDs, List<String> ontologyIDs,
			boolean configChanged) {
		AgentMappingsDeleted a2oChangedEv = new AgentMappingsDeleted(getClass()
				.toString());
		a2oChangedEv.setAgentID(agentID);
		a2oChangedEv.setSessionMappings(sessionIDs);
		a2oChangedEv.setOntologyMappings(ontologyIDs);
		a2oChangedEv.setChanged(configChanged);
		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(a2oChangedEv);
		}
	}
}
