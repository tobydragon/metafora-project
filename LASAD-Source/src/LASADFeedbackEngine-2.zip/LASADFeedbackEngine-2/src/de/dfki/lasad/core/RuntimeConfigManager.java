package de.dfki.lasad.core;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.filter.ElementFilter;
import org.jdom.input.SAXBuilder;

import de.dfki.lasad.core.components.collections.AgentRuntimeConfig;
import de.dfki.lasad.core.components.collections.AgentRuntimeConfigXML;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.core.components.instance.ISessionModel;
import de.dfki.lasad.events.agents.state.Agents2OntologiesMappingChangedEvent;
import de.dfki.lasad.events.agents.state.Agents2SessionsMappingChangedEvent;
import de.dfki.lasad.events.agents.state.AFStateChangedEventListener;
import de.dfki.lasad.session.Session;

/**
 * Provides access to the currently configured runtime (i.e., which
 * {@link IDataService} and {@link ISessionModel} to use, which {@link IAgent}s
 * to use).
 * 
 * <br/><br/>
 * <b>NOTE:</b> The configured runtime does not necessarily correspond to the currently
 * used runtime. The configured runtime will only be instantiated when a
 * {@link Session} is (re-)started ({@link Session#tryStartServices()).
 * 
 * @author oliverscheuer
 * 
 */
public class RuntimeConfigManager {

	static Log logger = LogFactory.getLog(RuntimeConfigManager.class);

	private List<AFStateChangedEventListener> afStateChangedListeners = new Vector<AFStateChangedEventListener>();

	private String dataServiceID;
	private String sessionModelID;

	private AgentRuntimeConfig agentRuntime;

	public void loadRuntimeConf() {
		loadDSConf();
		loadModelConf();
		loadAgentRuntimeConf();

		logRuntimeConf();
	}

	public void addAgent2SessionMapping(String agentID, String sessionID) {
		boolean configChanged = this.agentRuntime
				.containsAgentToSessionAssignment(agentID, sessionID);
		if (configChanged) {
			this.agentRuntime.addAgent2Session(agentID, sessionID);
			writeAgentRuntime();
		}
		notifyListenersAgents2SessionsChanged(configChanged);
	}

	public void removeAgent2SessionMapping(String agentID, String sessionID) {
		boolean configChanged = this.agentRuntime
				.containsAgentToSessionAssignment(agentID, sessionID);
		if (configChanged) {
			this.agentRuntime.removeAgent2SessionAssignment(agentID, sessionID);
			writeAgentRuntime();
		}
		notifyListenersAgents2SessionsChanged(configChanged);
	}

	public void addAgent2OntologyMapping(String agentID, String ontologyID) {
		boolean configChanged = this.agentRuntime
				.containsAgentToOntologyAssignment(agentID, ontologyID);
		if (configChanged) {
			this.agentRuntime.addAgent2Ontology(agentID, ontologyID);
			writeAgentRuntime();
		}
		notifyListenersAgents2SessionsChanged(configChanged);
	}

	public void removeAgent2OntologyMapping(String agentID, String ontologyID) {
		boolean configChanged = this.agentRuntime
				.containsAgentToOntologyAssignment(agentID, ontologyID);
		if (configChanged) {
			this.agentRuntime.removeAgent2OntologyAssignment(agentID,
					ontologyID);
			writeAgentRuntime();
		}
		notifyListenersAgents2SessionsChanged(configChanged);
	}

	public void deleteAgentRuntimeEntries(String agentID) {
		List<String> changedSessions = this.agentRuntime
				.removeAgentFromSessions(agentID);
		List<String> changedOntologies = this.agentRuntime
				.removeAgentFromOntologies(agentID);
		if (changedSessions.size() > 0 || changedOntologies.size() > 0) {
			writeAgentRuntime();
		}
		boolean a2sChanged = (changedSessions.size() > 0);
		notifyListenersAgents2SessionsChanged(a2sChanged);
		boolean a2oChanged = (changedOntologies.size() > 0);
		notifyListenersAgents2OntologiesChanged(a2oChanged);

	}

	public String getRuntimeDS() {
		return dataServiceID;
	}

	public String getRuntimeModel() {
		return sessionModelID;
	}

	public AgentRuntimeConfig getAgentRuntime() {
		return agentRuntime;
	}

	public void setAgentRuntime(AgentRuntimeConfig agentRuntime) {
		this.agentRuntime = agentRuntime;
	}

	private void writeAgentRuntime() {
		File runtimeAgentsFile = ConfigurationDatabase.getAgentsRuntimeFile();
		AgentRuntimeConfigXML.updateXMLFile(runtimeAgentsFile,
				this.agentRuntime);
	}

	private void loadDSConf() {
		File basicRuntimeFile = ConfigurationDatabase.getRuntimeBasicFile();
		this.dataServiceID = parseDSRuntime(basicRuntimeFile);
	}

	private void loadModelConf() {
		File basicRuntimeFile = ConfigurationDatabase.getRuntimeBasicFile();
		this.sessionModelID = parseModelRuntime(basicRuntimeFile);
	}

	private void loadAgentRuntimeConf() {
		File runtimeAgentsFile = ConfigurationDatabase.getAgentsRuntimeFile();
		this.agentRuntime = parseAgentRuntimeConf(runtimeAgentsFile);
	}

	private String parseDSRuntime(File f) {
		try {
			SAXBuilder builder = new SAXBuilder();
			Document doc = builder.build(f);

			Iterator<Element> iter = selectDSElements(doc);
			while (iter.hasNext()) {
				Element elem = iter.next();
				String dsID = elem.getAttributeValue("id");
				return dsID;
			}
		} catch (Exception e) {
			logger.error("Error in 'parseDSRuntime(...)'", e);
		}
		logger.error("Error in 'parseDSRuntime(...)': no data service id defined.");
		return null;

	}

	private String parseModelRuntime(File f) {
		try {
			SAXBuilder builder = new SAXBuilder();
			Document doc = builder.build(f);

			Iterator<Element> iter = selectModelElements(doc);
			while (iter.hasNext()) {
				Element elem = iter.next();
				String sModelID = elem.getAttributeValue("id");
				return sModelID;
			}
		} catch (Exception e) {
			logger.error("Error in 'parseModelRuntime(...)'", e);
		}
		logger.error("Error in 'parseModelRuntime(...)': no session model id defined.");
		return null;
	}

	private AgentRuntimeConfig parseAgentRuntimeConf(File f) {
		try {
			SAXBuilder builder = new SAXBuilder();
			Document doc = builder.build(f);
			Element rootElem = doc.getRootElement();

			return AgentRuntimeConfigXML.fromXML(rootElem);

		} catch (Exception e) {
			logger.error("Error in 'loadAgentRuntimeConf()'", e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	private Iterator<Element> selectDSElements(Document doc) {
		return doc.getDescendants(new ElementFilter("dataservice"));
	}

	@SuppressWarnings("unchecked")
	private Iterator<Element> selectModelElements(Document doc) {
		return doc.getDescendants(new ElementFilter("sessionmodel"));
	}

	private void logRuntimeConf() {
		logger.info("#### Runtime DataSevice ID ####");
		logger.info(dataServiceID);

		logger.info("#### Runtime SessionModel ID ####");
		logger.info(sessionModelID);

		logger.info("#### Runtime Session Agent IDs ####");

		for (String sessionID : agentRuntime.getSessionIDs()) {
			List<String> agentIDs = agentRuntime.getAgentsForSession(sessionID);

			StringBuffer agentStringBuf = new StringBuffer();
			agentStringBuf.append("{");
			for (Iterator<String> agentIDIter = agentIDs.iterator(); agentIDIter
					.hasNext();) {
				agentStringBuf.append(agentIDIter.next());
				if (agentIDIter.hasNext()) {
					agentStringBuf.append(", ");
				}
			}
			agentStringBuf.append("}");

			logger.info("session = " + sessionID + " " + agentStringBuf);
		}

		logger.info("#### Runtime Ontology Agent IDs ####");

		for (String ontologyID : agentRuntime.getOntologyIDs()) {
			List<String> agentIDs = agentRuntime
					.getAgentsForOntology(ontologyID);

			StringBuffer agentStringBuf = new StringBuffer();
			agentStringBuf.append("{");
			for (Iterator<String> agentIDIter = agentIDs.iterator(); agentIDIter
					.hasNext();) {
				agentStringBuf.append(agentIDIter.next());
				if (agentIDIter.hasNext()) {
					agentStringBuf.append(", ");
				}
			}
			agentStringBuf.append("}");

			logger.info("ontology = " + ontologyID + " " + agentStringBuf);
		}
	}

	public void addListener(AFStateChangedEventListener l) {
		afStateChangedListeners.add(l);
	}

	private void notifyListenersAgents2OntologiesChanged(boolean configChanged) {
		Agents2OntologiesMappingChangedEvent a2oChangedEv = new Agents2OntologiesMappingChangedEvent(
				getClass().toString());
		a2oChangedEv.setChanged(configChanged);
		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(a2oChangedEv);
		}
	}

	private void notifyListenersAgents2SessionsChanged(boolean configChanged) {
		Agents2SessionsMappingChangedEvent a2sChangedEv = new Agents2SessionsMappingChangedEvent(
				getClass().toString());
		a2sChangedEv.setChanged(configChanged);
		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(a2sChangedEv);
		}
	}
}
