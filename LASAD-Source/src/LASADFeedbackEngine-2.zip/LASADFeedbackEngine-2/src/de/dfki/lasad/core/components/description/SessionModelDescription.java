package de.dfki.lasad.core.components.description;

import de.dfki.lasad.core.components.configuration.ISessionModelConfiguration;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class SessionModelDescription extends AbstractComponentDescription {

	public SessionModelDescription(BasicDescription basicDesc) {
		super(basicDesc);
	}
	
	public ISessionModelConfiguration getConfiguration(){
		return (ISessionModelConfiguration)configuration;
	}
}
