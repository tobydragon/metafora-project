package de.dfki.lasad.sessionmodel;

import java.util.concurrent.PriorityBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.core.components.instance.AbstractComponent;
import de.dfki.lasad.core.components.instance.ISessionModel;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.session.SessionActiveRuntime;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.util.threads.Signal;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class AbstractSessionModel extends AbstractComponent implements
		ISessionModel {

	private Log logger = LogFactory.getLog(AbstractSessionModel.class);

	protected SessionModelDescription description = null;
	protected SessionModelConfiguration configuration;
	protected SessionActiveRuntime activeRuntime = null;
	protected SessionID sessionID = null;

	private PriorityBlockingQueue<Event> eventQueue;
	private boolean processEvents = false;
	private Thread eventThread;
	private Signal signal = new Signal();

	@Override
	public void configure(AbstractComponentDescription description) {
		this.description = (SessionModelDescription) description;
		this.configuration = (SessionModelConfiguration) this.description
				.getConfiguration();
	}

	@Override
	public void doWire(SessionActiveRuntime sessionRuntime) {
		this.activeRuntime = sessionRuntime;
		this.sessionID = this.activeRuntime.getSessionID();
	}

	@Override
	public AbstractComponentDescription getDescription() {
		return description;
	}
	
	@Override
	public String getComponentID() {
		return description.getComponentID();
	}
	
	@Override
	public synchronized void startService() {
		startEventThread();
	}

	protected void startEventThread() {
		eventQueue = new PriorityBlockingQueue<Event>();
		processEvents = true;
		eventThread = new Thread(new Consumer());
		eventThread.start();
		logger.info(getComponentID() + " (" + this.sessionID
				+ "): Waiting for event thread to start ...");
		signal.waitForSignal(true);
		logger.info(getComponentID() + " (" + this.sessionID
				+ "): Waiting for event thread to start: DONE");
	}

	class Consumer implements Runnable {

		public void run() {
			try {
				signal.signalGo();
				do {
					Event event = eventQueue.take();
					processEvent(event);
				} while (processEvents);
				signal.signalStop();
			} catch (Exception e) {
				logger.error("startEventThread " + e.getClass(), e);
			}

		}
	}

	@Override
	public void onEvent(Event event) {
		eventQueue.add(event);
	}

	protected abstract void processEvent(Event e);

	@Override
	public synchronized void stopService() {
		processEvents = false;
		logger.info(getComponentID() + " (" + sessionID
				+ "): Waiting for event thread to stop ...");
		signal.waitForSignal(false);
		logger.info(getComponentID() + " (" + sessionID
				+ "): Waiting for event thread to stop: DONE");
	}

}
