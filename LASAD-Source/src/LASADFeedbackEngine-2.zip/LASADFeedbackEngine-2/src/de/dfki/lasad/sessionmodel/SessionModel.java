package de.dfki.lasad.sessionmodel;

import java.io.Reader;
import java.io.StringReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Vector;
import java.util.concurrent.PriorityBlockingQueue;

import jess.Context;
import jess.Fact;
import jess.HasLHS;
import jess.Jesp;
import jess.JessEvent;
import jess.JessException;
import jess.LongValue;
import jess.QueryResult;
import jess.RU;
import jess.Rete;
import jess.Value;
import jess.ValueVector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.AnalyzableEntity;
import de.dfki.lasad.agents.data.analysis.BinaryResult;
import de.dfki.lasad.agents.data.analysis.NominalResult;
import de.dfki.lasad.agents.data.analysis.NumericalResult;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.RuleAnalysisType;
import de.dfki.lasad.core.DisplayedObjectIDTracker;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.core.components.instance.AbstractComponent;
import de.dfki.lasad.core.components.instance.IComponent;
import de.dfki.lasad.core.components.instance.ISessionModel;
import de.dfki.lasad.core.components.instance.ServiceStatus;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.AnalysisRequestEvent;
import de.dfki.lasad.events.agents.AnalysisResultEvent;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.events.eue.user.join.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.DeleteObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.SessionActiveRuntime;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.EUEObjectID;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;
import de.dfki.lasad.session.data.objects.ObjectProperty;
import de.dfki.lasad.sessionmodel.JessIDMapper;
import de.dfki.lasad.sessionmodel.SessionModelConfiguration;
import de.dfki.lasad.sessionmodel.counter.jess.CountingService;
import de.dfki.lasad.sessionmodel.graphmodel.GraphElement;
import de.dfki.lasad.sessionmodel.graphmodel.GraphModel;
import de.dfki.lasad.util.threads.Signal;

/**
 * Implementation of the {@link ISessionModel} interface based on the Jess rule
 * engine.
 * 
 * <br/>
 * <br/>
 * (see also {@link ISessionModel}, {@link IComponent})
 * 
 * @author oliverscheuer
 * 
 */
public class SessionModel extends AbstractComponent implements ISessionModel {

	// private Session session;
	protected SessionActiveRuntime sessionRuntime = null;
	private GraphModel graphModel;

	private Log logger = LogFactory.getLog(SessionModel.class);

	protected static final boolean LOG_ALL_FACT_TO_CONSOLE_ON_UPDATE = true;
	protected static final boolean SHUTDOWN_AFTER_ERROR = false;

	public static final String CHILDREN_PREFIX = "elem_";
	public static final String COUNTER_NODE_PREFIX = "n_";

	public static final String COUNTER_NODE_ALL = COUNTER_NODE_PREFIX + "all";
	public static final String COUNTER_LINK_PREFIX = "l_";

	public static final String COUNTER_LINK_ALL = COUNTER_LINK_PREFIX + "all";
	public static final String COUNTER_USER_PREFIX = "u_";
	public static final String COUNTER_USER_ALL = COUNTER_USER_PREFIX + "all";

	private List<RuleAnalysisType> ruleTypes = new Vector<RuleAnalysisType>();

	// to impose an ordering on IDs (to ensure a unique mapping from sets to
	// lists)
	private Comparator<EUEObjectID> idComparator = new Comparator<EUEObjectID>() {
		@Override
		public int compare(EUEObjectID o1, EUEObjectID o2) {
			return o1.getIdAsString().compareTo(o2.getIdAsString());
		}
	};

	protected Rete jessEngine;

	private PriorityBlockingQueue<Event> eventQueue;
	private boolean processEvents = false;
	private Thread eventThread;
	private Signal signal = new Signal();

	private Map<EUEObjectID, Fact> objectID2fact = new HashMap<EUEObjectID, Fact>();

	private Map<EUEObjectID, Set<EUEObjectID>> nodeID2inLinkIDs = new HashMap<EUEObjectID, Set<EUEObjectID>>();
	private Map<EUEObjectID, Set<EUEObjectID>> nodeID2outLinkIDs = new HashMap<EUEObjectID, Set<EUEObjectID>>();
	private Map<EUEObjectID, Set<EUEObjectID>> linkID2sourceIDs = new HashMap<EUEObjectID, Set<EUEObjectID>>();
	private Map<EUEObjectID, Set<EUEObjectID>> linkID2targetIDs = new HashMap<EUEObjectID, Set<EUEObjectID>>();

	private Map<EUEObjectID, SortedSet<String>> objectID2ModifierIDs = new HashMap<EUEObjectID, SortedSet<String>>();

	private Map<StringPair, Integer> counterTargetUserPair2Count = new HashMap<SessionModel.StringPair, Integer>();
	private Map<StringPair, Fact> counterTargetUserPair2Fact = new HashMap<SessionModel.StringPair, Fact>();

	private SessionModelDescription description;
	protected SessionModelConfiguration configuration;

	private CountingService countingService;

	public SessionModel() {
		jessEngine = new Rete();
		graphModel = new GraphModel();
	}

	@Override
	public void configure(AbstractComponentDescription description) {
		this.description = (SessionModelDescription) description;
		configuration = (SessionModelConfiguration) this.description
				.getConfiguration();
	}

	@Override
	public void doWire(SessionActiveRuntime sessionRuntime) {
		this.sessionRuntime = sessionRuntime;
		graphModel.setSessionRuntime(sessionRuntime);
		setServiceStatus(ServiceStatus.READY_TO_START);
	}

	@Override
	public AbstractComponentDescription getDescription() {
		return description;
	}

	@Override
	public String getComponentID() {
		return description.getComponentID();
	}

	@Override
	public void registerAnalysisPattern(RuleAnalysisType ruleType) {
		logger.info("Registering analysis pattern: " + ruleType.getDefinition());
		ruleTypes.add(ruleType);
	}

	@Override
	public synchronized void startService() {
		try {
			setServiceStatus(ServiceStatus.STARTING);
			logger.info("Start service for session: "
					+ sessionRuntime.getSessionID() + "...");
			addCountingService();
			addBasicDefinitions();
			addOntologyBasedDefinitions();
			addAnnotationDefinitionsAndAnnotations();
			addJessRules();
			addResultQueryDefinition();

			jessEngine.reset();

			initializeTallies();
			startEventThread();
			try {
				jessEngine.run();
				if (LOG_ALL_FACT_TO_CONSOLE_ON_UPDATE) {
					for (Iterator<Fact> factIter = getWorkingMemoryFacts(); factIter
							.hasNext();) {
						logger.debug(factIter.next());
					}
				}
			} catch (Exception e) {
				logger.error("startService(...), " + e.getClass() + ": "
						+ e.getMessage());
				if (SHUTDOWN_AFTER_ERROR) {
					System.exit(1);
				}
			}

			setServiceStatus(ServiceStatus.RUNNING);
			logger.info("... service started (" + sessionRuntime.getSessionID()
					+ ")");
		} catch (JessException e) {
			logger.error("startService() " + e.getClass(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	@Override
	public synchronized void stopService() {
		try {
			setServiceStatus(ServiceStatus.STOPPING);
			logger.info("Stop service for session: "
					+ sessionRuntime.getSessionID() + "...");
			jessEngine.halt();
			processEvents = false;
			logger.info(getComponentID() + " (" + sessionRuntime.getSessionID()
					+ "): Waiting for event thread to stop ...");
			signal.waitForSignal(false);
			logger.info(getComponentID() + " (" + sessionRuntime.getSessionID()
					+ "): Waiting for event thread to stop: DONE");
			setServiceStatus(ServiceStatus.STALE);
			logger.info("... service stopped (" + sessionRuntime.getSessionID()
					+ ")");
		} catch (Exception e) {
			logger.error("stopService() " + e.getClass(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	@Override
	public void onEvent(Event event) {
		eventQueue.add(event);
	}

	protected void executeJessBatch(String batch) throws JessException {
		Reader r = new StringReader(batch);
		Jesp j = new Jesp(r, jessEngine);
		j.parse(false);
	}

	protected void addCountingService() {
		try {
			countingService = new CountingService();
			jessEngine.defclass("CountingService",
					CountingService.class.getCanonicalName(), null);
			jessEngine.definstance("CountingService", countingService, true);
			jessEngine.addJessListener(countingService);
			jessEngine.setEventMask(JessEvent.FACT);
		} catch (JessException e) {
			logger.error("addCountingService() " + e.getClass(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	protected void addBasicDefinitions() {
		String datastructuresBasicBatch = configuration
				.getDatastructuresBasicBatch();
		String datastructuresExtraBatch = configuration
				.getDatastructuresExtraBatch();
		String importCounterFunctionsBatch = configuration
				.getImportCounterFunctionsBatch();
		String functionsBatch = configuration.getFunctionsBatch();
		String analysisImplicitLinksBatch = configuration
				.getAnalysisImplicitLinksBatch();
		String analysisTranscriptBatch = configuration
				.getAnalysisTranscriptBatch();
		try {
			executeJessBatch(datastructuresBasicBatch);
			executeJessBatch(datastructuresExtraBatch);
			executeJessBatch(importCounterFunctionsBatch);
			executeJessBatch(functionsBatch);
			executeJessBatch(analysisImplicitLinksBatch);
			executeJessBatch(analysisTranscriptBatch);
			logger.info("Jess data structures and functions added to session '"
					+ sessionRuntime.getSessionID() + "'.");
		} catch (Exception e) {
			logger.error("addBasicDefinitions " + e.getClass(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	protected void addOntologyBasedDefinitions() {
		String ontologyBasedDefinitionsBatch = configuration
				.getOntologyBasedDefinitions(sessionRuntime.getOntology());
		if (ontologyBasedDefinitionsBatch == null) {
			logger.info("No Ontology-based definitions defined for session '"
					+ sessionRuntime.getSessionID() + "'.");
		} else {
			try {
				executeJessBatch(ontologyBasedDefinitionsBatch);
				logger.info("Ontology-based definitions added to session '"
						+ sessionRuntime.getSessionID() + "'.");
			} catch (Exception e) {
				logger.error("addOntologyBasedDefinitions" + e.getClass(), e);
				if (SHUTDOWN_AFTER_ERROR) {
					System.exit(1);
				}
			}
		}
	}

	protected void addAnnotationDefinitionsAndAnnotations() {
		List<String> annotationsJessBatches = configuration
				.getAnnotationDefinitionsAndAnnotations(sessionRuntime
						.getTools());
		try {
			for (String annotationsJessBatch : annotationsJessBatches) {
				executeJessBatch(annotationsJessBatch);
				logger.info("Annotations added to session '"
						+ sessionRuntime.getSessionID() + "'.");
			}
		} catch (Exception e) {
			logger.error(
					"addAnnotationDefinitionsAndAnnotations(...), "
							+ e.getClass(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Add rules (analysis patterns) that can be applied to session.
	 * 
	 * @param sessionID
	 * @param jessEngine
	 */
	protected void addJessRules() {
		for (AgentDescription aDescr : sessionRuntime.getAgentDescriptions()
				.values()) {
			for (RuleAnalysisType rType : aDescr.getAnalysisRuleTypes()) {
				if (!ruleTypes.contains(rType)) {
					ruleTypes.add(rType);
				}
			}
		}
		for (RuleAnalysisType ruleType : ruleTypes) {
			String ruleDefinition = ruleType.getDefinition();
			try {
				executeJessBatch(ruleDefinition);
				logger.info("Rule definition added to session '"
						+ sessionRuntime.getSessionID() + "'.");
			} catch (Exception e) {
				logger.error("addApplicableRules(...), " + e.getClass(), e);
				if (SHUTDOWN_AFTER_ERROR) {
					System.exit(1);
				}
			}

		}
	}

	protected void addResultQueryDefinition() {
		String resultQueryDefinition = configuration.getResultQueryDefinition();
		try {
			executeJessBatch(resultQueryDefinition);
			logger.info("Result query added to session '"
					+ sessionRuntime.getSessionID() + "'.");
		} catch (Exception e) {
			logger.error("addResultQueryDefinition(...), " + e.getClass(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	protected void initializeTallies() {
		logger.info("Start initializing tallies for session '"
				+ sessionRuntime.getSessionID() + "' ...");
		Map<StringPair, Integer> tallies = counterTargetUserPair2Count;

		// create initial state
		StringPair allNodesTallyID = new StringPair(COUNTER_NODE_ALL,
				COUNTER_USER_ALL);
		tallies.put(allNodesTallyID, 0);

		StringPair allLinksTallyID = new StringPair(COUNTER_LINK_ALL,
				COUNTER_USER_ALL);
		tallies.put(allLinksTallyID, 0);

		for (String nodeType : sessionRuntime.getOntology().getNodeTypes()) {
			String tallyType = COUNTER_NODE_PREFIX + nodeType;
			StringPair nodeTypeSpecificTally = new StringPair(tallyType,
					COUNTER_USER_ALL);
			tallies.put(nodeTypeSpecificTally, 0);
		}

		for (String linkType : sessionRuntime.getOntology().getLinkTypes()) {
			String tallyType = COUNTER_LINK_PREFIX + linkType;
			StringPair linkTypeSpecificTally = new StringPair(tallyType,
					COUNTER_USER_ALL);
			tallies.put(linkTypeSpecificTally, 0);
		}

		for (StringPair tallyID : tallies.keySet()) {
			initializeTalliesinJess(tallyID.getFirst(), tallyID.getSecond());
		}
	}

	private void initializeTalliesinJess(String tallyType, String userID) {
		try {
			Fact tallyFact = new Fact("tally", jessEngine);
			tallyFact.setSlotValue("type", new Value(tallyType, RU.STRING));
			tallyFact.setSlotValue("user_id", new Value(userID, RU.STRING));
			tallyFact.setSlotValue("value", new Value(0, RU.INTEGER));
			Fact fact = jessEngine.assertFact(tallyFact);
			counterTargetUserPair2Fact.put(new StringPair(tallyType, userID),
					fact);
		} catch (Exception e) {
			logger.error("initializeTalliesinJess(...), " + e.getClass() + ": "
					+ e.getMessage(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	protected synchronized void executeUserActivityEvent(UserEvent userEvent) {
		boolean doRun = false;
		logger.debug("Execute event in session '"
				+ sessionRuntime.getSessionID() + "': " + userEvent.toString());

		if (userEvent instanceof ObjectActionEvent) {

			ObjectActionEvent oaEvent = (ObjectActionEvent) userEvent;
			String userID = oaEvent.getUserID().getIdAsString();
			long ts = oaEvent.getTs();

			if (userEvent instanceof CreateObjectEvent) {

				doRun = true;
				CreateObjectEvent createEvent = (CreateObjectEvent) userEvent;

				List<EUEObject> objects = createEvent.getEueObjectList();
				for (EUEObject object : objects) {
					if (object instanceof Node && object.isTopLevelObject()) {
						// top-level node
						Node node = (Node) object;
						insertNode(node, createEvent);
						graphModel.insertNode(node, createEvent);
					} else if (object instanceof Node) {
						// child node
						Node node = (Node) object;
						insertChildNode(node, createEvent);
						graphModel.insertSubElement(node, createEvent);
					} else if (object instanceof Link) {
						// link node
						Link link = (Link) object;
						insertLink(link, createEvent);
						graphModel.insertLink(link, createEvent);
					}
				}
			} else if (userEvent instanceof DeleteObjectEvent) {
				doRun = true;
				DeleteObjectEvent deleteEvent = (DeleteObjectEvent) userEvent;
				List<EUEObject> objects = deleteEvent.getEueObjectList();
				for (EUEObject object : objects) {
					if (object instanceof Node && object.isTopLevelObject()) {
						// top-level node
						Node node = (Node) object;
						deleteNode(node, deleteEvent);
						graphModel.deleteNode(node, deleteEvent);
					} else if (object instanceof Node) {
						Node node = (Node) object;
						deleteChildNode(node, deleteEvent);
						graphModel.deleteSubElement(node, deleteEvent);
					} else if (object instanceof Link) {
						Link link = (Link) object;
						deleteLink(link, deleteEvent);
						graphModel.deleteLink(link, deleteEvent);
					}
				}
			} else if (userEvent instanceof ModifyObjectEvent) {
				doRun = true;
				ModifyObjectEvent modifyEvent = (ModifyObjectEvent) userEvent;
				List<EUEObject> objects = modifyEvent.getEueObjectList();
				for (EUEObject object : objects) {
					if (object instanceof Node && object.isTopLevelObject()) {
						// top-level node
						Node node = (Node) object;
						modifyNode(node, modifyEvent);
						graphModel.modifyNode(node, modifyEvent);
					} else if (object instanceof Node) {
						// child node
						Node node = (Node) object;
						modifyChildNode(node, modifyEvent);
						graphModel.modifySubElement(node, modifyEvent);
					} else if (object instanceof Link) {
						Link link = (Link) object;
						modifyLink(link, modifyEvent);
						graphModel.modifyLink(link, modifyEvent);
					}
				}
			} else if (userEvent instanceof UserJoinSessionEvent) {
				/**
				 * TODO - Add / retract / modify Jess facts
				 */
			}
		}
		if (doRun) {
			try {
				jessEngine.run();

				if (LOG_ALL_FACT_TO_CONSOLE_ON_UPDATE) {
					for (Iterator<Fact> factIter = getWorkingMemoryFacts(); factIter
							.hasNext();) {
						logger.debug(factIter.next());
					}
				}
			} catch (Exception e) {
				logger.error("executeEUESessionEvent(...), " + e.getClass()
						+ ": " + e.getMessage());
				if (SHUTDOWN_AFTER_ERROR) {
					System.exit(1);
				}
			}
		}

	}

	private void executeAnalysisRequestEvent(AnalysisRequestEvent aRequestEvent) {
		Map<AnalysisType, List<AnalysisResult>> results = getAnalysisResults(aRequestEvent
				.getAnalysisTypes());
		AnalysisResultEvent resultEvent = new AnalysisResultEvent(
				sessionRuntime.getSessionID(), getComponentID(), results);
		resultEvent.setTransactionID(aRequestEvent.getTransactionID());
		aRequestEvent.getCallback().onEvent(resultEvent);
	}

	/**
	 * Inserts a (top-level) {@link Node}. This includes:
	 * <ul>
	 * <li>insert {@link Node} in Jess</li>
	 * <li>keep track of {@link Node} in internal indices</li>
	 * <li>increment counters</li>
	 * </ul>
	 * 
	 * @param node
	 * @param createEvent
	 * @param jessEngine
	 */
	private void insertNode(Node node, CreateObjectEvent createEvent) {
		try {
			logger.debug("Inserting (top-level) node in session '"
					+ sessionRuntime.getSessionID() + "': " + node);

			String id = node.getID().getIdAsString();
			String displayID = DisplayedObjectIDTracker.getDisplayID(
					sessionRuntime.getSessionID(), node.getID());

			String type = node.getType();
			String creatorID = createEvent.getUserID().getIdAsString();
			long creationTs = createEvent.getTs();

			Fact nodeFact = new Fact("node", jessEngine);

			nodeFact.setSlotValue("type", new Value(type, RU.STRING));
			nodeFact.setSlotValue("id", new Value(id, RU.STRING));
			nodeFact.setSlotValue("display_id", new Value(displayID, RU.STRING));
			nodeFact.setSlotValue("creator", new Value(creatorID, RU.STRING));
			nodeFact.setSlotValue("first-interaction-ts", new LongValue(
					creationTs));
			nodeFact.setSlotValue("last-interaction-ts", new LongValue(
					creationTs));

			// list of all users who have touched this box
			ValueVector modifiers = updateModifiers(node.getID(), creatorID);
			nodeFact.setSlotValue("modifiers", new Value(modifiers, RU.LIST));

			for (String propName : node.getProps().keySet()) {
				if (configuration.isNodePropSupported(propName)) {
					ObjectProperty prop = node.getProps().get(propName);
					nodeFact.setSlotValue(propName,
							new Value(prop.getValueAsString(), RU.STRING));
				}
			}

			countingService.addNodeAction("CREATE", creatorID, creationTs, id,
					type);

			// Update Jess working memory
			Fact fact = jessEngine.assertFact(nodeFact);
			logger.debug("New Jess fact: " + fact);

			objectID2fact.put(node.getID(), fact);

			// Create new index entries for node neighbors
			nodeID2inLinkIDs.put(node.getID(), new TreeSet<EUEObjectID>(
					idComparator));
			nodeID2outLinkIDs.put(node.getID(), new TreeSet<EUEObjectID>(
					idComparator));

			// updateCreateList(node, createEvent);

			// update tallies
			updateTally(COUNTER_NODE_ALL, COUNTER_USER_ALL, 1);
			String typeSpecificTally = COUNTER_NODE_PREFIX + type;
			updateTally(typeSpecificTally, COUNTER_USER_ALL, 1);

		} catch (Exception e) {
			logger.error(
					"insertNode(...), " + e.getClass() + ": " + e.getMessage(),
					e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Inserts a (child) {@link Node}. This includes:
	 * <ul>
	 * <li>insert {@link Node} in Jess</li>
	 * <li>keep track of {@link Node} in internal indices</li>
	 * </ul>
	 * 
	 * @param node
	 * @param createEvent
	 * @param jessEngine
	 */
	private void insertChildNode(Node node, CreateObjectEvent createEvent) {
		try {
			logger.debug("Inserting (child) node in session '"
					+ sessionRuntime.getSessionID() + "': " + node);

			String jessID = node.getID().getIdAsString();

			String type = node.getType();
			String creatorID = createEvent.getUserID().getIdAsString();
			long creationTs = createEvent.getTs();
			String parentID = node.getParentID().getIdAsString();

			String dataType = CHILDREN_PREFIX + node.getDataType();
			Fact nodeFact = new Fact(dataType, jessEngine);

			nodeFact.setSlotValue("type", new Value(type, RU.STRING));
			nodeFact.setSlotValue("id", new Value(jessID, RU.STRING));
			nodeFact.setSlotValue("parent_id", new Value(parentID, RU.STRING));
			nodeFact.setSlotValue("creator", new Value(creatorID, RU.STRING));
			nodeFact.setSlotValue("first-interaction-ts", new LongValue(
					creationTs));
			nodeFact.setSlotValue("last-interaction-ts", new LongValue(
					creationTs));

			ValueVector modifiers = updateModifiers(node.getID(), creatorID);
			nodeFact.setSlotValue("modifiers", new Value(modifiers, RU.LIST));

			for (String propName : node.getProps().keySet()) {
				if (configuration.isSubElementPropSupported(node.getDataType(),
						propName)) {
					ObjectProperty prop = node.getProps().get(propName);
					nodeFact.setSlotValue(propName,
							new Value(prop.getValueAsString(), RU.STRING));
				}
			}

			// Update Jess working memory
			Fact fact = jessEngine.assertFact(nodeFact);
			logger.debug("New Jess fact: " + fact);
			objectID2fact.put(node.getID(), fact);

			propagateToParent(node, createEvent);

		} catch (Exception e) {
			logger.error(
					"insertChildNode(...), " + e.getClass() + ": "
							+ e.getMessage(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Inserts a {@link Link}. This includes:
	 * <ul>
	 * <li>insert {@link Link} in Jess</li>
	 * <li>keep track of {@link Link} in internal indices</li>
	 * <li>update {@link Node} neighborhood for {@link Link} sources and targets
	 * </li>
	 * <li>increment counters</li>
	 * </ul>
	 * 
	 * @param link
	 * @param createEvent
	 * @param jessEngine
	 */
	private void insertLink(Link link, CreateObjectEvent createEvent) {
		try {
			logger.debug("Inserting link in session '"
					+ sessionRuntime.getSessionID() + "': " + link);

			String id = link.getID().getIdAsString();
			String displayID = DisplayedObjectIDTracker.getDisplayID(
					sessionRuntime.getSessionID(), link.getID());

			String type = link.getType();
			String creatorID = createEvent.getUserID().getIdAsString();
			long creationTs = createEvent.getTs();

			String dataType = link.getDataType();

			Fact linkFact = new Fact("link", jessEngine);

			linkFact.setSlotValue("type", new Value(type, RU.STRING));
			linkFact.setSlotValue("id", new Value(id, RU.STRING));
			linkFact.setSlotValue("display_id", new Value(displayID, RU.STRING));

			linkFact.setSlotValue("creator", new Value(creatorID, RU.STRING));
			linkFact.setSlotValue("first-interaction-ts", new LongValue(
					creationTs));
			linkFact.setSlotValue("last-interaction-ts", new LongValue(
					creationTs));

			ValueVector modifiers = updateModifiers(link.getID(), creatorID);
			linkFact.setSlotValue("modifiers", new Value(modifiers, RU.LIST));

			// Add Source and Targets

			List<EUEObjectID> sourceIDs = link.getSources();
			List<EUEObjectID> targetIDs = link.getTargets();
			ValueVector valVecSources = new ValueVector();
			ValueVector valVecTargets = new ValueVector();

			for (EUEObjectID source : sourceIDs) {
				String val = source.getIdAsString();
				valVecSources.add(new Value(val, RU.STRING));
			}

			for (EUEObjectID target : targetIDs) {
				String val = target.getIdAsString();
				valVecTargets.add(new Value(val, RU.STRING));
			}

			linkFact.setSlotValue("source_ids", new Value(valVecSources,
					RU.LIST));
			linkFact.setSlotValue("target_ids", new Value(valVecTargets,
					RU.LIST));

			String firstSourceID = sourceIDs.get(0).getIdAsString();
			String firstTargetID = targetIDs.get(0).getIdAsString();

			countingService.addLinkAction("CREATE", creatorID, creationTs, id,
					type, firstSourceID, firstTargetID);

			// Update Jess working memory
			Fact newFact = jessEngine.assertFact(linkFact);
			logger.debug("New Jess fact: " + newFact);

			// Update internal index (facts)
			objectID2fact.put(link.getID(), newFact);

			// Update internal index (initialize source and target set for new
			// link)
			Set<EUEObjectID> linkSourcesSet = new HashSet<EUEObjectID>(
					sourceIDs);
			Set<EUEObjectID> linkTargetsSet = new HashSet<EUEObjectID>(
					targetIDs);
			linkID2sourceIDs.put(link.getID(), linkSourcesSet);
			linkID2targetIDs.put(link.getID(), linkTargetsSet);

			// Update internal index (node in- and out-links)
			for (EUEObjectID sourceID : sourceIDs) {
				Set<EUEObjectID> sourceOutLinkSet = nodeID2outLinkIDs
						.get(sourceID);
				sourceOutLinkSet.add(link.getID());
			}
			for (EUEObjectID targetID : targetIDs) {
				Set<EUEObjectID> sourceInLinkSet = nodeID2inLinkIDs
						.get(targetID);
				sourceInLinkSet.add(link.getID());
			}

			// update source and target element neighborhood if necessary (in
			// Jess)
			updateNeighbors(linkSourcesSet, linkTargetsSet);

			// updateCreateList(link, createEvent);

			// update tallies
			updateTally(COUNTER_LINK_ALL, COUNTER_USER_ALL, 1);
			String typeSpecificTally = COUNTER_LINK_PREFIX + type;
			updateTally(typeSpecificTally, COUNTER_USER_ALL, 1);

		} catch (Exception e) {
			logger.error(
					"insertLink(...), " + e.getClass() + ": " + e.getMessage(),
					e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Modifies a (top-level) {@link Node}. This includes:
	 * <ul>
	 * <li>update {@link Node} in Jess (type, properties, modification TSs)</li>
	 * <li>update internal indices</li>
	 * <li>update {@link Node} neighborhood for {@link Link} sources and targets
	 * </li>
	 * <li>update counters when type has changed</li>
	 * </ul>
	 * 
	 * @param node
	 * @param modifyEvent
	 * @param jessEngine
	 */
	private void modifyNode(Node node, ModifyObjectEvent modifyEvent) {
		try {
			String nodeID = node.getID().getIdAsString();
			Fact oldFact = objectID2fact.get(node.getID());

			List<String> changedPropNames = new Vector<String>();
			List<Value> changedPropValues = new Vector<Value>();

			String oldType = oldFact.getSlotValue("type").stringValue(
					jessEngine.getGlobalContext());
			String newType = node.getType();
			if (!newType.equals(oldType)) {
				changedPropNames.add("type");
				changedPropValues.add(new Value(newType, RU.STRING));
			}

			for (String propName : node.getProps().keySet()) {
				if (configuration.isNodePropSupported(propName)) {
					changedPropNames.add(propName);
					String value = node.getProps().get(propName)
							.getValueAsString();
					changedPropValues.add(new Value(value, RU.STRING));
				}
			}

			if (changedPropNames.isEmpty()) {
				// neither type nor other relevant properties changed
				logger.debug("Neither type nor other relevant properties changed ("
						+ sessionRuntime.getSessionID()
						+ "', "
						+ node
						+ ") -> Ignore.");
				return;
			}
			logger.debug("Modifying node in session '"
					+ sessionRuntime.getSessionID() + "': " + node);
			String modificatorID = modifyEvent.getUserID().getIdAsString();
			long modificationTs = modifyEvent.getTs();

			if (isModifierNew(node.getID(), modificatorID)) {
				ValueVector modifiers = updateModifiers(node.getID(),
						modificatorID);
				changedPropNames.add("modifiers");
				changedPropValues.add(new Value(modifiers, RU.LIST));
			}

			changedPropNames.add("last-interaction-ts");
			changedPropValues.add(new LongValue(modificationTs));

			countingService.addNodeAction("MODIFY", modificatorID,
					modificationTs, nodeID, null);

			// Update Jess working memory
			Fact newFact = jessEngine.modify(oldFact, changedPropNames
					.toArray(new String[changedPropNames.size()]),
					changedPropValues.toArray(new Value[changedPropValues
							.size()]));
			logger.debug("Modified Jess fact: " + newFact);

			// Update internal index (facts)
			objectID2fact.put(node.getID(), newFact);

			// update counters if type has changed
			if (!newType.equals(oldType)) {
				String typeSpecificTallyNew = COUNTER_NODE_PREFIX + newType;
				updateTally(typeSpecificTallyNew, COUNTER_USER_ALL, 1);
				String typeSpecificTallyOld = COUNTER_NODE_PREFIX + oldType;
				updateTally(typeSpecificTallyOld, COUNTER_USER_ALL, -1);
			}

		} catch (Exception e) {
			logger.error(
					"modifyNode(...), " + e.getClass() + ": " + e.getMessage(),
					e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Modifies a (child) {@link Node}. This includes:
	 * <ul>
	 * <li>update {@link Node} in Jess (properties, modification TSs)</li>
	 * <li>update internal indices</li>
	 * </ul>
	 * 
	 * @param node
	 * @param modifyEvent
	 * @param jessEngine
	 */
	private void modifyChildNode(Node node, ModifyObjectEvent modifyEvent) {
		try {

			logger.debug("Modifying child node in session '"
					+ sessionRuntime.getSessionID() + "': " + node);

			String jessID = node.getID().getIdAsString();
			Fact oldFact = objectID2fact.get(node.getID());

			List<String> changedPropNames = new Vector<String>();
			List<Value> changedPropValues = new Vector<Value>();

			String dataType = node.getDataType();
			for (String propName : node.getProps().keySet()) {
				if (configuration.isSubElementPropSupported(dataType, propName)) {
					changedPropNames.add(propName);
					String value = node.getProps().get(propName)
							.getValueAsString();
					changedPropValues.add(new Value(value, RU.STRING));
				}
			}

			String modificatorID = modifyEvent.getUserID().getIdAsString();
			long modificationTs = modifyEvent.getTs();

			if (isModifierNew(node.getID(), modificatorID)) {
				ValueVector modifiers = updateModifiers(node.getID(),
						modificatorID);
				changedPropNames.add("modifiers");
				changedPropValues.add(new Value(modifiers, RU.LIST));
			}

			changedPropNames.add("last-interaction-ts");
			changedPropValues.add(new LongValue(modificationTs));

			// Update Jess working memory
			Fact newFact = jessEngine.modify(oldFact, changedPropNames
					.toArray(new String[changedPropNames.size()]),
					changedPropValues.toArray(new Value[changedPropValues
							.size()]));
			logger.debug("Modified Jess fact: " + newFact);

			// Update internal index (facts)
			objectID2fact.put(node.getID(), newFact);

			propagateToParent(node, modifyEvent);

		} catch (Exception e) {
			logger.error("[modifyChildNode] on event :\n"
					+ modifyEvent.toXml().toString(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Modifies a {@link Link}. This includes:
	 * <ul>
	 * <li>update {@link Link} in Jess (type, properties, modification TSs)</li>
	 * <li>update internal indices</li>
	 * <li>update {@link Node} neighborhood for {@link Link} sources and
	 * targets, if necessary</li>
	 * <li>update counters when type has changed</li>
	 * </ul>
	 * 
	 * @param link
	 * @param modifyEvent
	 * @param jessEngine
	 */
	private void modifyLink(Link link, ModifyObjectEvent modifyEvent) {
		try {

			logger.debug("Modifying link in session '"
					+ sessionRuntime.getSessionID() + "': " + link);

			String linkID = link.getID().getIdAsString();
			Fact oldFact = objectID2fact.get(link.getID());

			List<String> changedPropNames = new Vector<String>();
			List<Value> changedPropValues = new Vector<Value>();

			// check whether type has changed
			String oldType = oldFact.getSlotValue("type").stringValue(
					jessEngine.getGlobalContext());
			String newType = link.getType();
			if (!newType.equals(oldType)) {
				changedPropNames.add("type");
				changedPropValues.add(new Value(newType, RU.STRING));
			}

			Set<EUEObjectID> oldSourceIDs = linkID2sourceIDs.get(link.getID());
			List<EUEObjectID> newSourceIDs = link.getSources();
			Set<EUEObjectID> oldTargetIDs = linkID2targetIDs.get(link.getID());
			List<EUEObjectID> newTargetIDs = link.getTargets();

			// Check whether sources have changed
			boolean sourcesChanged = false;

			// we collect changed sources' targets to update their neighborhood
			Set<EUEObjectID> changedSourceTargets = new HashSet<EUEObjectID>();

			// check for added sources
			for (EUEObjectID newSourceID : newSourceIDs) {
				if (!oldSourceIDs.contains(newSourceID)) {
					// add new outlink to source
					nodeID2outLinkIDs.get(newSourceID).add(link.getID());
					// changedSources.add(newSourceID);
					changedSourceTargets.addAll(newTargetIDs);
					sourcesChanged = true;
				}
			}
			// check for removed sources
			for (EUEObjectID oldSourceID : oldSourceIDs) {
				if (!newSourceIDs.contains(oldSourceID)) {
					// remove outdated outlink from source
					nodeID2outLinkIDs.get(oldSourceID).remove(link.getID());
					// changedSources.add(oldSourceID);
					changedSourceTargets.addAll(oldTargetIDs);
					sourcesChanged = true;
				}
			}

			// Adding source_ids to changed properties
			if (sourcesChanged) {
				changedPropNames.add("source_ids");
				ValueVector newSourcesVector = new ValueVector();
				for (EUEObjectID sourceId : newSourceIDs) {
					Value v = new Value(sourceId.getIdAsString(), RU.STRING);
					newSourcesVector.add(v);
				}
				changedPropValues.add(new Value(newSourcesVector, RU.LIST));

				// update internal index (link -> sourceIDs)
				Set<EUEObjectID> newSourceIDSet = new TreeSet<EUEObjectID>(
						idComparator);
				newSourceIDSet.addAll(newSourceIDs);
				linkID2sourceIDs.put(link.getID(), newSourceIDSet);
			}

			// Check whether targets have changed
			boolean targetsChanged = false;

			// we collect changed targets' sources to update their neighborhood
			Set<EUEObjectID> changedTargetSources = new HashSet<EUEObjectID>();

			// check for added targets
			for (EUEObjectID newTargetID : newTargetIDs) {
				if (!oldTargetIDs.contains(newTargetID)) {
					// add new inlink to targets
					nodeID2inLinkIDs.get(newTargetID).add(link.getID());
					// changedTargets.add(newTargetID);
					changedTargetSources.addAll(newSourceIDs);
					targetsChanged = true;
				}
			}
			// check for removed targets
			for (EUEObjectID oldTargetID : oldTargetIDs) {
				if (!newTargetIDs.contains(oldTargetID)) {
					// remove outdated inlink from target
					nodeID2inLinkIDs.get(oldTargetID).remove(link.getID());
					// changedTargets.add(oldTargetID);
					changedTargetSources.addAll(oldSourceIDs);
					targetsChanged = true;
				}
			}

			if (targetsChanged) {
				// Adding target_ids to changed properties
				changedPropNames.add("target_ids");
				ValueVector newTargetsVector = new ValueVector();
				for (EUEObjectID targetId : newTargetIDs) {
					Value v = new Value(targetId.getIdAsString(), RU.STRING);
					newTargetsVector.add(v);
				}
				changedPropValues.add(new Value(newTargetsVector, RU.LIST));

				// update internal index (link -> targetIDs)
				Set<EUEObjectID> newTargetIDSet = new TreeSet<EUEObjectID>(
						idComparator);
				newTargetIDSet.addAll(newTargetIDs);
				linkID2targetIDs.put(link.getID(), newTargetIDSet);
			}

			for (String propName : link.getProps().keySet()) {
				if (configuration.isNodePropSupported(propName)) {
					changedPropNames.add(propName);
					String value = link.getProps().get(propName)
							.getValueAsString();
					changedPropValues.add(new Value(value, RU.STRING));
				}
			}

			String modificatorID = modifyEvent.getUserID().getIdAsString();
			long modificationTs = modifyEvent.getTs();

			if (isModifierNew(link.getID(), modificatorID)) {
				ValueVector modifiers = updateModifiers(link.getID(),
						modificatorID);
				changedPropNames.add("modifiers");
				changedPropValues.add(new Value(modifiers, RU.LIST));
			}

			changedPropNames.add("last-interaction-ts");
			changedPropValues.add(new LongValue(modificationTs));

			String newSourceID = null;
			EUEObjectID firstNewSourceID = newSourceIDs.get(0);
			if (firstNewSourceID != null) {
				newSourceID = firstNewSourceID.getIdAsString();
			}
			String newTargetID = null;
			EUEObjectID firstNewTargetID = newTargetIDs.get(0);
			if (firstNewTargetID != null) {
				newTargetID = firstNewTargetID.getIdAsString();
			}

			countingService.addLinkAction("MODIFY", modificatorID,
					modificationTs, linkID, null, newSourceID, newTargetID);

			// Update Jess working memory
			Fact newFact = jessEngine.modify(oldFact, changedPropNames
					.toArray(new String[changedPropNames.size()]),
					changedPropValues.toArray(new Value[changedPropValues
							.size()]));
			logger.debug("Modified Jess fact: " + newFact);

			// Update internal index (facts)
			objectID2fact.put(link.getID(), newFact);

			// update source and target element neighborhood if necessary
			updateNeighbors(changedTargetSources, changedSourceTargets);

			// update counters if type has changed
			if (!newType.equals(oldType)) {
				String typeSpecificTallyNew = COUNTER_LINK_PREFIX + newType;
				updateTally(typeSpecificTallyNew, COUNTER_USER_ALL, 1);
				String typeSpecificTallyOld = COUNTER_LINK_PREFIX + oldType;
				updateTally(typeSpecificTallyOld, COUNTER_USER_ALL, -1);
			}
		} catch (Exception e) {
			logger.error(
					"modifyLink(...), " + e.getClass() + ": " + e.getMessage(),
					e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Deletes a (top-level) {@link Node}. This includes:
	 * <ul>
	 * <li>mark {@link Node} as deleted in Jess</li>
	 * <li>update internal indices</li>
	 * <li>update {@link Link} sources and targets for {@link Link} that connect
	 * to this {@link Node}</li>
	 * <li>update {@link Node} neighborhood for neighboring {@link Node}s (i.e.,
	 * delete this {@link Node} from neighbors)</li>
	 * <li>update counters</li>
	 * </ul>
	 * 
	 * @param node
	 * @param deleteEvent
	 * @param jessEngine
	 */
	private void deleteNode(Node node, DeleteObjectEvent deleteEvent) {
		try {

			logger.debug("Deleting (top-level) node in session '"
					+ sessionRuntime.getSessionID() + "': " + node);

			EUEObjectID nodeID = node.getID();

			// mark node in Jess as deleted
			Fact oldFact = objectID2fact.remove(nodeID);

			List<String> changedPropNames = new Vector<String>();
			List<Value> changedPropValues = new Vector<Value>();

			changedPropNames.add("deleted");
			changedPropValues.add(new Value(true));

			long ts = deleteEvent.getTs();
			changedPropNames.add("last-interaction-ts");
			changedPropValues.add(new LongValue(ts));

			String deletor = deleteEvent.getUserID().getIdAsString();
			changedPropNames.add("deletor");
			changedPropValues.add(new Value(deletor, RU.STRING));

			if (isModifierNew(node.getID(), deletor)) {
				ValueVector modifiers = updateModifiers(nodeID, deletor);
				changedPropNames.add("modifiers");
				changedPropValues.add(new Value(modifiers, RU.LIST));
			}

			countingService.addNodeAction("DELETE", deletor, ts,
					nodeID.getIdAsString(), null);

			// Update Jess working memory
			Fact newFact = jessEngine.modify(oldFact, changedPropNames
					.toArray(new String[changedPropNames.size()]),
					changedPropValues.toArray(new Value[changedPropValues
							.size()]));
			logger.debug("Jess fact marked as deleted: " + newFact);

			// remove node as link source (internal index + Jess); collect all
			// affected link targets (since their neighborhood changed)
			Set<EUEObjectID> relevantOutLinks = nodeID2outLinkIDs
					.remove(nodeID);
			Set<EUEObjectID> affectedOutLinkTargets = new HashSet<EUEObjectID>();
			for (EUEObjectID outLinkID : relevantOutLinks) {
				// remove node as link source (internal index)
				Set<EUEObjectID> outLinkSources = linkID2sourceIDs
						.get(outLinkID);
				outLinkSources.remove(nodeID);

				// remove node as link source (Jess)
				changedPropNames = new Vector<String>();
				changedPropNames.add("source_ids");
				changedPropValues = new Vector<Value>();
				ValueVector newSourcesVector = new ValueVector();
				for (EUEObjectID sourceId : outLinkSources) {
					Value v = new Value(sourceId.getIdAsString(), RU.STRING);
					newSourcesVector.add(v);
				}
				changedPropValues.add(new Value(newSourcesVector, RU.LIST));
				Fact linkFact = objectID2fact.get(outLinkID);
				newFact = jessEngine.modify(linkFact, changedPropNames
						.toArray(new String[changedPropNames.size()]),
						changedPropValues.toArray(new Value[changedPropValues
								.size()]));

				// Update internal index (facts)
				objectID2fact.put(outLinkID, newFact);

				logger.debug("Modified Link fact (deleted node -> changed sources): "
						+ newFact);

				// add affected link targets (to update their neighborhood)
				Set<EUEObjectID> outLinkTargets = linkID2targetIDs
						.get(outLinkID);
				affectedOutLinkTargets.addAll(outLinkTargets);
			}

			// remove node as link target (internal index + Jess); collect all
			// affected link sources (since their neighborhood changed)
			Set<EUEObjectID> relevantInLinks = nodeID2inLinkIDs.remove(nodeID);
			Set<EUEObjectID> affectedInLinkSources = new HashSet<EUEObjectID>();
			for (EUEObjectID inLinkID : relevantInLinks) {
				// remove node as link target (internal index)
				Set<EUEObjectID> inLinkTargets = linkID2targetIDs.get(inLinkID);
				inLinkTargets.remove(nodeID);

				// remove node as link target (Jess)
				changedPropNames = new Vector<String>();
				changedPropNames.add("target_ids");
				changedPropValues = new Vector<Value>();
				ValueVector newTargetVector = new ValueVector();
				for (EUEObjectID targetId : inLinkTargets) {
					Value v = new Value(targetId.getIdAsString(), RU.STRING);
					newTargetVector.add(v);
				}
				changedPropValues.add(new Value(newTargetVector, RU.LIST));
				Fact linkFact = objectID2fact.get(inLinkID);
				newFact = jessEngine.modify(linkFact, changedPropNames
						.toArray(new String[changedPropNames.size()]),
						changedPropValues.toArray(new Value[changedPropValues
								.size()]));

				// Update internal index (facts)
				objectID2fact.put(inLinkID, newFact);

				logger.debug("Modified Link fact (deleted node -> changed targets): "
						+ newFact);

				// add affected link sources (to update their neighborhood)
				Set<EUEObjectID> inLinkSources = linkID2sourceIDs.get(inLinkID);
				affectedInLinkSources.addAll(inLinkSources);
			}

			// update neighborhoods (i.e., remove node as neighbor, in-neighbor,
			// out-neighbor)
			updateNeighbors(affectedInLinkSources, affectedOutLinkTargets);

			// updateDeleteList(node, deleteEvent);

			// update tallies
			updateTally(COUNTER_NODE_ALL, COUNTER_USER_ALL, -1);
			String typeSpecificTally = COUNTER_NODE_PREFIX + node.getType();
			updateTally(typeSpecificTally, COUNTER_USER_ALL, -1);

		} catch (Exception e) {
			logger.error(
					"deleteNode(...), " + e.getClass() + ": " + e.getMessage(),
					e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Deletes a (child) {@link Node}. This includes:
	 * <ul>
	 * <li>retract {@link Node} from Jess</li>
	 * <li>update internal indices</li>
	 * </ul>
	 * 
	 * @param node
	 * @param deleteEvent
	 * @param jessEngine
	 */
	private void deleteChildNode(Node node, DeleteObjectEvent deleteEvent) {
		try {

			logger.debug("Deleting (child) node in session '"
					+ sessionRuntime.getSessionID() + "': " + node);

			EUEObjectID nodeID = node.getID();

			// mark node in Jess as deleted
			Fact oldFact = objectID2fact.remove(nodeID);

			List<String> changedPropNames = new Vector<String>();
			List<Value> changedPropValues = new Vector<Value>();

			changedPropNames.add("deleted");
			changedPropValues.add(new Value(true));

			long ts = deleteEvent.getTs();
			changedPropNames.add("last-interaction-ts");
			changedPropValues.add(new LongValue(ts));

			String deletor = deleteEvent.getUserID().getIdAsString();
			changedPropNames.add("deletor");
			changedPropValues.add(new Value(deletor, RU.STRING));

			if (isModifierNew(node.getID(), deletor)) {
				ValueVector modifiers = updateModifiers(node.getID(), deletor);
				changedPropNames.add("modifiers");
				changedPropValues.add(new Value(modifiers, RU.LIST));
			}

			// Update Jess working memory
			Fact newFact = jessEngine.modify(oldFact, changedPropNames
					.toArray(new String[changedPropNames.size()]),
					changedPropValues.toArray(new Value[changedPropValues
							.size()]));
			logger.debug("Jess fact marked as deleted: " + newFact);

			propagateToParent(node, deleteEvent);

		} catch (Exception e) {
			logger.error(
					"deleteChildNode(...), " + e.getClass() + ": "
							+ e.getMessage(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Deletes a {@link Link}. This includes:
	 * <ul>
	 * <li>retract {@link Link} from Jess</li>
	 * <li>update internal indices</li>
	 * <li>update {@link Node} neighborhood for connected {@link Node}s)</li>
	 * <li>update counters</li>
	 * </ul>
	 * 
	 * @param link
	 * @param deleteEvent
	 * @param jessEngine
	 */
	private void deleteLink(Link link, DeleteObjectEvent deleteEvent) {
		try {

			logger.debug("Deleting link in session '"
					+ sessionRuntime.getSessionID() + "': " + link);

			EUEObjectID linkID = link.getID();

			// remove link from internal index and mark as deleted in Jess
			Fact oldFact = objectID2fact.remove(linkID);

			List<String> changedPropNames = new Vector<String>();
			List<Value> changedPropValues = new Vector<Value>();

			changedPropNames.add("deleted");
			changedPropValues.add(new Value(true));

			long ts = deleteEvent.getTs();
			changedPropNames.add("last-interaction-ts");
			changedPropValues.add(new LongValue(ts));

			String deletor = deleteEvent.getUserID().getIdAsString();
			changedPropNames.add("deletor");
			changedPropValues.add(new Value(deletor, RU.STRING));

			if (isModifierNew(link.getID(), deletor)) {
				ValueVector modifiers = updateModifiers(link.getID(), deletor);
				changedPropNames.add("modifiers");
				changedPropValues.add(new Value(modifiers, RU.LIST));
			}

			countingService.addLinkAction("DELETE", deletor, ts,
					linkID.getIdAsString(), null, null, null);

			// Update Jess working memory
			Fact newFact = jessEngine.modify(oldFact, changedPropNames
					.toArray(new String[changedPropNames.size()]),
					changedPropValues.toArray(new Value[changedPropValues
							.size()]));
			logger.debug("Jess fact marked as deleted: " + newFact);

			// remove link sources (internal indices)
			Set<EUEObjectID> linkSources = linkID2sourceIDs.remove(linkID);
			for (EUEObjectID sourceID : linkSources) {
				Set<EUEObjectID> sourceOutLinks = nodeID2outLinkIDs
						.get(sourceID);
				if (sourceOutLinks != null) {
					sourceOutLinks.remove(linkID);
				}
			}

			// remove link targets (internal indices)
			Set<EUEObjectID> linkTargets = linkID2targetIDs.remove(linkID);
			for (EUEObjectID targetID : linkTargets) {
				Set<EUEObjectID> targetInLinks = nodeID2inLinkIDs.get(targetID);
				if (targetInLinks != null) {
					targetInLinks.remove(linkID);
				}
			}

			// update neighborhoods (i.e., remove node as neighbor, in-neighbor,
			// out-neighbor)
			updateNeighbors(linkSources, linkTargets);

			// updateDeleteList(link, deleteEvent);

			// update tallies
			updateTally(COUNTER_LINK_ALL, COUNTER_USER_ALL, -1);
			String typeSpecificTally = COUNTER_LINK_PREFIX + link.getType();
			updateTally(typeSpecificTally, COUNTER_USER_ALL, -1);

		} catch (Exception e) {
			logger.error(
					"deleteLink(...), " + e.getClass() + ": " + e.getMessage(),
					e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Assuming the the internal indices have already been updated (
	 * {@link #sessions2nodeID2inLinkIDs}, {@link #sessions2nodeID2outLinkIDs},
	 * {@link #sessions2linkID2sourceIDs}, {@link #sessions2linkID2targetIDs}),
	 * this method updates the node neighborhoods in Jess.
	 * 
	 * @param sessionID
	 * @param changedSources
	 *            objects that take the role of a source in a relation whose
	 *            targets changed (i.e., target has been added or removed). The
	 *            out-neighbors will be updated.
	 * @param changedTargets
	 *            objects that take the role of a target in a relation whose
	 *            sources changed (i.e., source has been added or removed). The
	 *            in-neighbors will be updated.
	 * @param jessEngine
	 */
	private void updateNeighbors(Set<EUEObjectID> changedSources,
			Set<EUEObjectID> changedTargets) {
		try {
			if (changedSources.isEmpty() && changedTargets.isEmpty()) {
				// nothing to do
				return;
			}
			Set<EUEObjectID> changedObjects = new HashSet<EUEObjectID>();
			changedObjects.addAll(changedSources);
			changedObjects.addAll(changedTargets);

			for (EUEObjectID objectID : changedObjects) {
				List<String> changedPropNames = new Vector<String>();
				List<Value> changedPropValues = new Vector<Value>();

				// Collect new in-neighbors
				Set<EUEObjectID> newInNeighbors = new TreeSet<EUEObjectID>(
						idComparator);
				Set<EUEObjectID> inLinks = nodeID2inLinkIDs.get(objectID);
				for (EUEObjectID inLinkID : inLinks) {
					Set<EUEObjectID> newInNeighborsOneLink = linkID2sourceIDs
							.get(inLinkID);
					newInNeighbors.addAll(newInNeighborsOneLink);
				}

				// Collect new out-neighbors
				Set<EUEObjectID> newOutNeighbors = new TreeSet<EUEObjectID>(
						idComparator);
				Set<EUEObjectID> outLinks = nodeID2outLinkIDs.get(objectID);
				for (EUEObjectID outLinkID : outLinks) {
					Set<EUEObjectID> newOutNeighborsOneLink = linkID2targetIDs
							.get(outLinkID);
					newOutNeighbors.addAll(newOutNeighborsOneLink);
				}

				// check whether inNeighbors have changed (i.e.,
				// object is target of a changed relation)
				if (changedTargets.contains(objectID)) {
					changedPropNames.add("in_neighbors");
					// Construct new value vector
					ValueVector newInNeighborVector = new ValueVector();
					for (EUEObjectID inNeighborID : newInNeighbors) {
						Value v = new Value(inNeighborID.getIdAsString(),
								RU.STRING);
						newInNeighborVector.add(v);
					}
					changedPropValues.add(new Value(newInNeighborVector,
							RU.LIST));
				}

				// check whether outNeighbors have changed (i.e.,
				// object is source of a changed relation)
				if (changedSources.contains(objectID)) {
					changedPropNames.add("out_neighbors");
					// Construct new value vector
					ValueVector newOutNeighborVector = new ValueVector();
					for (EUEObjectID outNeighborID : newOutNeighbors) {
						Value v = new Value(outNeighborID.getIdAsString(),
								RU.STRING);
						newOutNeighborVector.add(v);
					}
					changedPropValues.add(new Value(newOutNeighborVector,
							RU.LIST));
				}

				// update neighbors (we know already that something changed wrt
				// neighborhood)
				changedPropNames.add("neighbors");

				Set<EUEObjectID> newNeighbors = new TreeSet<EUEObjectID>(
						idComparator);
				newNeighbors.addAll(newInNeighbors);
				newNeighbors.addAll(newOutNeighbors);

				// Construct new value vector
				ValueVector newNeighborVector = new ValueVector();
				for (EUEObjectID neighborID : newNeighbors) {
					Value v = new Value(neighborID.getIdAsString(), RU.STRING);
					newNeighborVector.add(v);
				}
				changedPropValues.add(new Value(newNeighborVector, RU.LIST));

				// Update Jess working memory
				Fact oldFact = objectID2fact.get(objectID);

				Fact newFact = jessEngine.modify(oldFact, changedPropNames
						.toArray(new String[changedPropNames.size()]),
						changedPropValues.toArray(new Value[changedPropValues
								.size()]));

				// Update internal index (facts)
				objectID2fact.put(objectID, newFact);

			}
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Updates internal indices as well as the Jess working memory.
	 * 
	 * @param sessionID
	 * @param tallyType
	 * @param userID
	 * @param change
	 */
	private void updateTally(String tallyType, String userID, int change) {
		try {
			// update internal index
			StringPair tallyID = new StringPair(tallyType, userID);
			int oldCount = counterTargetUserPair2Count.get(tallyID);
			int newCount = oldCount + change;
			counterTargetUserPair2Count.put(tallyID, newCount);

			// update Jess working memory
			Fact oldFact = counterTargetUserPair2Fact.get(tallyID);
			Fact newFact = jessEngine.modify(oldFact, "value", new Value(
					newCount, RU.INTEGER));

			// Update internal index (facts)
			counterTargetUserPair2Fact.put(tallyID, newFact);

		} catch (Exception e) {
			logger.error(
					"updateTally, " + e.getClass() + ": " + e.getMessage(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	/**
	 * Modifies a (child) {@link Node}. This includes:
	 * <ul>
	 * <li>update {@link Node} in Jess (properties, modification TSs)</li>
	 * <li>update internal indices</li>
	 * </ul>
	 * 
	 * @param node
	 * @param modifyEvent
	 * @param jessEngine
	 */
	private void propagateToParent(Node childNode, ObjectActionEvent objectEvent) {
		try {

			long ts = objectEvent.getTs();
			String userID = objectEvent.getUserID().getIdAsString();
			EUEObjectID parentID = childNode.getParentID();
			Fact oldParentFact = objectID2fact.get(parentID);

			List<String> changedPropNames = new Vector<String>();
			List<Value> changedPropValues = new Vector<Value>();
			long currentParentLastInteractionTs = oldParentFact.getSlotValue(
					"last-interaction-ts").longValue(
					jessEngine.getGlobalContext());

			boolean lastInteractionTsChanged = ts > currentParentLastInteractionTs;
			if (lastInteractionTsChanged) {
				changedPropNames.add("last-interaction-ts");
				changedPropValues.add(new LongValue(ts));
			}

			boolean modifiersChanged = isModifierNew(parentID, userID);
			if (modifiersChanged) {
				changedPropNames.add("modifiers");
				ValueVector newModifiers = updateModifiers(parentID, userID);
				changedPropValues.add(new Value(newModifiers, RU.LIST));
			}

			if (lastInteractionTsChanged || modifiersChanged) {

				countingService.addNodeAction("MODIFY", userID, ts,
						parentID.getIdAsString(), null);

				Fact newFact = jessEngine.modify(oldParentFact,
						changedPropNames.toArray(new String[changedPropNames
								.size()]), changedPropValues
								.toArray(new Value[changedPropValues.size()]));

				logger.debug("Propagating child changes to parent in session '"
						+ sessionRuntime.getSessionID() + "': "
						+ childNode.getID() + " --> " + parentID);

				// Update internal index (facts)
				objectID2fact.put(parentID, newFact);
			} else {
				logger.debug("No child changes to propagate to parent '"
						+ sessionRuntime.getSessionID() + "': "
						+ childNode.getID() + " --> " + parentID);
			}
		} catch (Exception e) {
			logger.error(
					"propagateToParent(...), " + e.getClass() + ": "
							+ e.getMessage(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	private boolean isModifierNew(EUEObjectID oID, String userID) {

		Set<String> modifiers = objectID2ModifierIDs.get(oID);
		if (modifiers != null) {
			return !modifiers.contains(userID);
		}

		return false;
	}

	private ValueVector updateModifiers(EUEObjectID oID, String userID)
			throws JessException {

		Set<String> modifiers = objectID2ModifierIDs.get(oID);
		if (modifiers == null) {
			objectID2ModifierIDs.put(oID, new TreeSet<String>());
			modifiers = objectID2ModifierIDs.get(oID);
		}
		modifiers.add(userID);
		ValueVector modifiersUpdated = new ValueVector();
		for (String modifier : modifiers) {
			Value v = new Value(modifier, RU.STRING);
			modifiersUpdated.add(v);
		}
		return modifiersUpdated;
	}

	public Iterator<Fact> getWorkingMemoryFacts() {
		return jessEngine.listFacts();
	}

	public Iterator<HasLHS> getWorkingMemoryRules() {
		return jessEngine.listDefrules();
	}

	private Map<AnalysisType, List<AnalysisResult>> getAnalysisResults(
			Set<AnalysisType> analysisTypes) {
		Map<AnalysisType, List<AnalysisResult>> type2Results = new HashMap<AnalysisType, List<AnalysisResult>>();

		for (AnalysisType type : analysisTypes) {
			List<AnalysisResult> results = getResults(type);
			type2Results.put(type, results);
		}
		return type2Results;
	}

	private List<AnalysisResult> getResults(AnalysisType analysisType) {
		List<AnalysisResult> results = new Vector<AnalysisResult>();
		try {

			Context jessGlobalContext = jessEngine.getGlobalContext();
			String agentID = analysisType.getAgentID();
			String typeID = analysisType.getTypeID();
			ValueVector inputArgs = new ValueVector();
			inputArgs.add(new Value(agentID, RU.STRING));
			inputArgs.add(new Value(typeID, RU.STRING));

			QueryResult resultsJess = jessEngine.runQueryStar("get-result",
					inputArgs);

			while (resultsJess.next()) {

				// setting the entity
				AnalyzableEntity entity = new AnalyzableEntity();
				Value entityComponents = resultsJess.get("entity_ids");

				ValueVector entityComponentsAsJessVector = entityComponents
						.listValue(jessGlobalContext);
				for (int i = 0; i < entityComponentsAsJessVector.size(); ++i) {
					Value componentIDJess = entityComponentsAsJessVector.get(i);
					// check for 'nil' values (will be filtered out; nil is of
					// type "RU.SYMBOL")
					if (componentIDJess.type() == RU.STRING) {
						String componentIDAsString = componentIDJess
								.stringValue(jessGlobalContext);
						entity.addEntityComponent(JessIDMapper
								.jess2EUEID(componentIDAsString));
					}
				}

				// setting the actual result
				AnalysisResult aResult = null;
				if (BinaryResult.class.equals(analysisType.getResultType())) {
					boolean value = resultsJess.getBoolean("value");
					aResult = new BinaryResult(analysisType, entity, value);
					results.add(aResult);
				} else if (NumericalResult.class.equals(analysisType
						.getResultType())) {
					double value = resultsJess.getDouble("value");
					aResult = new NumericalResult(analysisType, entity, value);
					results.add(aResult);
				} else if (NominalResult.class.equals(analysisType
						.getResultType())) {
					String value = resultsJess.getString("value");
					aResult = new NominalResult(analysisType, entity, value);
					results.add(aResult);
				} else {
					logger.warn("Unknown (or unset) result type for "
							+ analysisType.toString());
				}

				// setting result property / value pairs
				if (aResult != null) {

					// prop names
					List<String> propNameList = new Vector<String>();
					Value propNamesJess = resultsJess.get("prop_names");

					ValueVector propNamesAsJessVector = propNamesJess
							.listValue(jessGlobalContext);
					for (int i = 0; i < propNamesAsJessVector.size(); ++i) {
						Value propNameJess = propNamesAsJessVector.get(i);
						// check for 'nil' values (will be filtered out; nil is
						// of type "RU.SYMBOL")
						if (propNameJess.type() == RU.STRING) {
							String propNameAsString = propNameJess
									.stringValue(jessGlobalContext);
							propNameList.add(propNameAsString);
						}
					}

					// prop values
					List<String> propValuesList = new Vector<String>();
					Value propValuesJess = resultsJess.get("prop_values");

					ValueVector propValuesAsJessVector = propValuesJess
							.listValue(jessGlobalContext);
					for (int i = 0; i < propValuesAsJessVector.size(); ++i) {
						Value propValueJess = propValuesAsJessVector.get(i);
						// check for 'nil' values (will be filtered out; nil is
						// of type "RU.SYMBOL")
						if (propValueJess.type() != RU.SYMBOL) {
							String propValueAsString = propValueJess
									.stringValue(jessGlobalContext);
							propValuesList.add(propValueAsString);
						}
					}

					if (propNameList.size() == propValuesList.size()) {
						Iterator<String> valueIter = propValuesList.iterator();
						for (String propName : propNameList) {
							String propValue = valueIter.next();
							aResult.addProperty(propName, propValue);
						}

					} else {
						logger.error("Number of result properties differs from number of result values.");
						if (SHUTDOWN_AFTER_ERROR) {
							System.exit(1);
						}
					}

				}
			}

		} catch (Exception e) {
			logger.error(
					"getResults(...), " + e.getClass() + ": " + e.getMessage(),
					e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
		return results;
	}

	protected void startEventThread() {
		eventQueue = new PriorityBlockingQueue<Event>();
		processEvents = true;
		eventThread = new Thread(new Consumer());
		eventThread.start();
		logger.info(getComponentID() + " (" + sessionRuntime.getSessionID()
				+ "): Waiting for event thread to start ...");
		signal.waitForSignal(true);
		logger.info(getComponentID() + " (" + sessionRuntime.getSessionID()
				+ "): Waiting for event thread to start: DONE");
	}

	class Consumer implements Runnable {

		public void run() {
			try {
				signal.signalGo();
				do {
					Event event = eventQueue.take();
					processEvent(event);
				} while (processEvents);
				signal.signalStop();
			} catch (Exception e) {
				logger.error("startEventThread " + e.getClass(), e);
				if (SHUTDOWN_AFTER_ERROR) {
					System.exit(1);
				}
			}

		}
	}

	/**
	 * NOT synchronized on purpose to avoid deadlock with stopService() method
	 * (stopService() waits until Consumer.run() terminates, Consumer.run()
	 * might wait for stopService() to terminate if method processEvent were
	 * synchronized).
	 */
	protected void processEvent(Event event) {
		if (event instanceof UserEvent) {
			executeUserActivityEvent((UserEvent) event);
		} else if (event instanceof AnalysisRequestEvent) {
			executeAnalysisRequestEvent((AnalysisRequestEvent) event);
		}
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		buffer.append(this.getClass().getSimpleName());
		buffer.append("]");
		return buffer.toString();
	}

	private class StringPair {

		private String[] data;

		public StringPair(String first, String second) {
			data = new String[] { first, second };
		}

		public String getFirst() {
			return data[0];
		}

		public String getSecond() {
			return data[1];
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + Arrays.hashCode(data);
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			StringPair other = (StringPair) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (!Arrays.equals(data, other.data))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "[" + data[0] + ", " + data[1] + "]";
		}

		private ISessionModel getOuterType() {
			return SessionModel.this;
		}

	}

	@Override
	public synchronized GraphElement getElement(String eueObjectId) {

		return graphModel.getNode(eueObjectId);
	}

}
