package de.dfki.lasad.authoring.converter.pattern2jess;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import de.dfki.lasad.authoring.model.pattern.Comparison;
import de.dfki.lasad.authoring.model.pattern.Pattern;

/**
 * Generates Jess 'deffacts' expressions to insert constant values, which are
 * needed for some {@link Comparison}s, into the Jess working memory.
 * 
 * @author oliverscheuer
 * 
 */
public class JessConstValDeffactGenerator {

	public static final String INDENT = "  ";

	JessIDGenerator idGen = new JessIDGenerator();

	public String generateConstValDeffacts(Pattern p) {
		StringBuffer buf = new StringBuffer();
		String patternID = p.getID();
		Map<Integer, List<String>> constantNumID2Values = p
				.getConstantNumID2Values();
		if (constantNumID2Values.isEmpty()) {
			return "";
		}
		buf.append("(deffacts " + "const-vals-pattern-" + patternID + " ");
		buf.append("\"Constant values used in pattern " + patternID + "\"");
		buf.append("\n");
		for (Iterator<Integer> iter = constantNumID2Values.keySet().iterator(); iter
				.hasNext();) {
			int constID = iter.next();
			String factID = idGen.generateConstantFactID(patternID, constID);
			List<String> values = constantNumID2Values.get(constID);

			buf.append(Indent.apply("(constant-set ", INDENT));
			buf.append("(id \"" + factID + "\") ");
			buf.append("(values " + generateValueList(values) + ") ");
			buf.append(")");
			if (iter.hasNext()) {
				buf.append("\n");
			}
		}
		buf.append(")");
		return buf.toString();
	}

	public String generateValueList(List<String> values) {
		StringBuffer buf = new StringBuffer();
		for (Iterator<String> vIter = values.iterator(); vIter.hasNext();) {
			String val = vIter.next();
			buf.append("\"" + val + "\"");
			if (vIter.hasNext()) {
				buf.append(" ");
			}
		}
		return buf.toString();
	}
}
