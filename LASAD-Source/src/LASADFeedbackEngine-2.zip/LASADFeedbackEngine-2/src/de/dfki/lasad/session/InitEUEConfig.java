package de.dfki.lasad.session;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Represents the initial state of the EUE (i.e., when the Feedback-Engine is
 * started). Provides information whether the initial state has been fully
 * received by the Feedback-Engine
 * 
 * @author oliverscheuer
 * 
 */
public class InitEUEConfig {

	private boolean sessionOverviewReceived = false;
	private boolean ontologyOverviewReceived = false;

	private Set<String> sessionsToInitialize = new HashSet<String>();
	private Set<String> ontologiesToInitialize = new HashSet<String>();

	/**
	 * @param sessionsToInitialize
	 *            set of sessions to be initialized
	 */
	public void setSessionsToInitialize(Collection<String> sessionsToInitialize) {
		sessionOverviewReceived = true;
		this.sessionsToInitialize = new HashSet<String>(sessionsToInitialize);
	}

	/**
	 * @param ontologiesToInitialize
	 *            set of ontologies to be initialized
	 */
	public void setOntologiesToInitialize(
			Collection<String> ontologiesToInitialize) {
		ontologyOverviewReceived = true;
		this.ontologiesToInitialize = new HashSet<String>(
				ontologiesToInitialize);
	}

	/**
	 * mark session as initialized
	 */
	public void setSessionInitialized(String sessionID) {
		sessionsToInitialize.remove(sessionID);
	}

	/**
	 * mark ontology as initialized
	 */
	public void setOntologyInitialized(String ontologyID) {
		ontologiesToInitialize.remove(ontologyID);
	}

	/**
	 * 
	 * @param sessionID
	 * @return whether session has NOT been fully initialized yet
	 */
	public boolean waitingForSessionCompletion(String sessionID) {
		return sessionsToInitialize.contains(sessionID);
	}

	/**
	 * 
	 * @param ontologyID
	 * @return whether ontology has NOT been fully initialized yet
	 */
	public boolean waitingForOntologyCompletion(String ontologyID) {
		return ontologiesToInitialize.contains(ontologyID);
	}

	/**
	 * 
	 * @return whether every ontology has been fully initialized
	 */
	public boolean areOntologiesComplete() {
		boolean ontologiesComplete = ontologyOverviewReceived
				&& ontologiesToInitialize.isEmpty();
		return ontologiesComplete;
	}

	/**
	 * 
	 * @return whether every session has been fully initialized
	 */
	public boolean areSessionsComplete() {
		boolean sessionsComplete = sessionOverviewReceived
				&& sessionsToInitialize.isEmpty();
		return sessionsComplete;
	}

	/**
	 * 
	 * @return whether every the complete state has been fully initialized
	 */
	public boolean initializationComplete() {
		return areOntologiesComplete() && areSessionsComplete();
	}

}
