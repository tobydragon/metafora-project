package de.dfki.lasad.agents.instances.xmpp;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;

import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.eue.user.join.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.user.join.UserLeaveSessionEvent;

public class UserToSessionMapping {
	Logger logger = Logger.getLogger(this.getClass());
	
	public Map <String, Vector<String>> userToSessionMapping;
	
	public UserToSessionMapping(){
		userToSessionMapping = new HashMap<String, Vector<String>>();
	}
	
	public void updateMapping(Event event){
		if (event instanceof UserJoinSessionEvent){
			UserJoinSessionEvent joinEvent = (UserJoinSessionEvent) event;
			String userId = joinEvent.getUserID().getIdAsString();
			String sessionId = joinEvent.getSessionID().getIdAsString();
			Vector<String> sessionsForUser = userToSessionMapping.get(userId);
			if (sessionsForUser == null){
				sessionsForUser = new Vector<String>();
				userToSessionMapping.put(userId, sessionsForUser);
				logger.debug("[updateMapping] user added: " + userId);
			}
			sessionsForUser.add(0, sessionId);
			logger.debug("[updateMapping] session added for user: " + userId + " - session: " + sessionId);
		}
		else if (event instanceof UserLeaveSessionEvent) {
			UserLeaveSessionEvent leaveEvent = (UserLeaveSessionEvent) event;
			String userId = leaveEvent.getUserID().getIdAsString();
			String sessionId = leaveEvent.getSessionID().getIdAsString();
			Vector<String> sessionsForUser = userToSessionMapping.get(userId);
			if (sessionsForUser != null){
				if (sessionsForUser.remove(sessionId)){
					logger.debug("[updateMapping] session removed for user: " + userId + " - session: " + sessionId);
				}
				else {
					logger.error("[updateMapping] trying to remove session not joined: " + userId + " - session: " + sessionId);
				}
			}
			else {
				logger.error("[updateMapping] user leaving but never joined for user: " + userId + " - session: " + sessionId);
			}
		}
	}
	
	public String getLatestMapJoinForUserId(String userId){
		Vector<String> sessions = userToSessionMapping.get(userId);
		if (sessions != null && sessions.size() > 0){
			return sessions.firstElement();
		}
		else {
			return null;
		}
	}
	
}
