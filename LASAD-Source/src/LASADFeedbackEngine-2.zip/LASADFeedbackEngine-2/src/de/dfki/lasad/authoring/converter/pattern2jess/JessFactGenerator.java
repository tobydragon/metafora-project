package de.dfki.lasad.authoring.converter.pattern2jess;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.authoring.model.pattern.Comparison;
import de.dfki.lasad.authoring.model.pattern.ElementConstr;
import de.dfki.lasad.authoring.model.pattern.ElementVariable;
import de.dfki.lasad.authoring.model.pattern.LinkConstr;
import de.dfki.lasad.authoring.model.pattern.NodeConstr;
import de.dfki.lasad.authoring.model.pattern.Num2ConstNumComparison;
import de.dfki.lasad.authoring.model.pattern.Num2VarNumComparison;
import de.dfki.lasad.authoring.model.pattern.PropertyVariable;
import de.dfki.lasad.authoring.model.pattern.Set2ConstSetComparison;
import de.dfki.lasad.authoring.model.pattern.Set2ConstStringComparison;
import de.dfki.lasad.authoring.model.pattern.String2ConstSetComparison;
import de.dfki.lasad.authoring.model.pattern.String2ConstStringComparison;
import de.dfki.lasad.authoring.model.pattern.VariableComparison;
import de.dfki.lasad.session.data.meta.Ontology;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * Generates Jess Fact patterns to be used on the LHS of Jess rules.
 * 
 * @author oliverscheuer
 * 
 */
public class JessFactGenerator {

	private static final Log logger = LogFactory
			.getLog(JessFactGenerator.class);

	private JessIDGenerator idGen = new JessIDGenerator();
	private JessComparisonGenerator compGen = new JessComparisonGenerator();

	public static final String INDENT_NODE = " ";
	public static final String INDENT_LINK = " ";
	public static final String INDENT_CONSTSET = "         ";
	public static final String INDENT_PROPFACT = "   ";
	public static final String INDENT_PROPCONSTR = "   ";

	/**
	 * Generates Jess 'node' Fact pattern according to the given specification
	 * 
	 * @param nodeConstr
	 *            constraints for a node variable n
	 * @param predecessors
	 *            predecessor node vars (add constraints: n.id != p.id)
	 * @param compSelector
	 *            {@link Comparison} selector (of {@link ComparisonType})
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @return
	 */
	public String generateNodeFact(NodeConstr nodeConstr,
			List<? extends ElementConstr> predecessors,
			ComparisonType compSelector, Bin bin) {

		StringBuffer buf = new StringBuffer();

		String elemVarID = idGen.generateElemIDVar(nodeConstr.getElemVar());
		String predecessorIDConstrs = generateElemIDConstrs(predecessors);
		String idSlot = "(id " + elemVarID + predecessorIDConstrs + ")";
		String propSlots = generateElemFactPropSlots(nodeConstr, compSelector,
				bin);
		String neighborSlots = generateElemFactNeighborSlots(nodeConstr);
		String deletedSlot = "(deleted FALSE)";

		buf.append("(node");
		buf.append("\n");
		buf.append(Indent.apply(idSlot, INDENT_NODE));
		buf.append("\n");
		buf.append(Indent.apply(propSlots, INDENT_NODE));
		buf.append("\n");
		buf.append(Indent.apply(neighborSlots, INDENT_NODE));
		buf.append("\n");
		buf.append(Indent.apply(deletedSlot, INDENT_NODE));
		buf.append(")");
		return buf.toString();
	}

	/**
	 * Generates Jess 'link' Fact pattern according to the given specification
	 * 
	 * @param nodeConstr
	 *            constraints for a link variable l
	 * @param predecessors
	 *            predecessor link vars (add constraints: l.id != p.id)
	 * @param compSelector
	 *            {@link Comparison} selector (of {@link ComparisonType})
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @return
	 */
	public String generateLinkFact(LinkConstr linkConstr,
			List<? extends ElementConstr> predecessors,
			ComparisonType compSelector, Bin bin) {

		StringBuffer buf = new StringBuffer();

		String elemVarID = idGen.generateElemIDVar(linkConstr.getElemVar());
		String predecessorIDConstrs = generateElemIDConstrs(predecessors);
		String idSlot = "(id " + elemVarID + predecessorIDConstrs + ")";
		String propSlots = generateElemFactPropSlots(linkConstr, compSelector,
				bin);
		String deletedSlot = "(deleted FALSE)";

		buf.append("(link");
		buf.append("\n");
		buf.append(Indent.apply(idSlot, INDENT_LINK));
		buf.append("\n");
		buf.append(Indent.apply(propSlots, INDENT_LINK));
		buf.append("\n");
		buf.append(Indent.apply(deletedSlot, INDENT_LINK));
		buf.append(")");
		return buf.toString();
	}

	/**
	 * Generates a Jess 'node' Fact patterns that establishes a binding to an
	 * element of a list property (the list property is given by the LHS of the
	 * given {@link Comparison})
	 * 
	 * @param comparison
	 * @return
	 */
	public String generateNodeFactBindListElem(Comparison comparison) {
		StringBuffer buf = new StringBuffer();

		PropertyVariable propVar = comparison.getLeftExpr();
		ElementVariable elemVar = propVar.getElementVar();
		String elemVarID = idGen.generateElemIDVar(elemVar);
		String idSlot = "(id " + elemVarID + ")";
		String propSlotName = generateSlotName(propVar);
		String propVarID = idGen.generatePropVarID(propVar, comparison.getId(),
				true, true);
		String propSlot = "(" + propSlotName + " " + "$? " + propVarID + " $?"
				+ ")";
		String deletedSlot = "(deleted FALSE)";

		buf.append("(node");
		buf.append("\n");
		buf.append(Indent.apply(idSlot, INDENT_NODE));
		buf.append("\n");
		buf.append(Indent.apply(propSlot, INDENT_NODE));
		buf.append("\n");
		buf.append(Indent.apply(deletedSlot, INDENT_NODE));
		buf.append(")");
		return buf.toString();
	}

	/**
	 * Generates a Jess 'link' Fact patterns that establishes a binding to an
	 * element of a list property of(the list property is given by the LHS of
	 * the given {@link Comparison})
	 * 
	 * @param comparison
	 * @return
	 */
	public String generateLinkFactBindListElem(Comparison comparison) {
		StringBuffer buf = new StringBuffer();

		PropertyVariable propVar = comparison.getLeftExpr();
		ElementVariable elemVar = propVar.getElementVar();
		String elemVarID = idGen.generateElemIDVar(elemVar);
		String idSlot = "(id " + elemVarID + ")";
		String propSlotName = generateSlotName(propVar);
		String propVarID = idGen.generatePropVarID(propVar, comparison.getId(),
				true, true);
		String propSlot = "(" + propSlotName + " " + "$? " + propVarID + " $?"
				+ ")";
		String deletedSlot = "(deleted FALSE)";

		buf.append("(link");
		buf.append("\n");
		buf.append(Indent.apply(idSlot, INDENT_LINK));
		buf.append("\n");
		buf.append(Indent.apply(propSlot, INDENT_LINK));
		buf.append("\n");
		buf.append(Indent.apply(deletedSlot, INDENT_LINK));
		buf.append(")");
		return buf.toString();
	}

	/**
	 * Generates Jess 'property' Fact pattern according to the given
	 * specification
	 * 
	 * @param elemVar
	 *            the element variable this property belongs to
	 * @param prop
	 *            a property description (from the {@link Ontology})
	 * @param propVars2Comparisons
	 *            {@link Comparison}s per property component
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param tempVarAppendix
	 *            will be appended to generated var names to guarantee
	 *            uniqueness
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 * @return
	 */
	public String generatePropFact(ElementVariable elemVar, PropDescr prop,
			Map<PropertyVariable, List<Comparison>> propVars2Comparisons,
			Bin bin, int tempVarAppendix, boolean useElemTempVar,
			boolean useTempVarLeft, boolean useTempVarRight) {

		//NonStandardPropDescr nonStdProp = (NonStandardPropDescr) prop;

		StringBuffer buf = new StringBuffer();

		String templateName = prop.getJessTemplate();
		String factPatternStart = "(" + templateName;
		String type = prop.getPropID();
		String typeSlot = "(type \"" + type + "\")";
		String parentID = idGen.generateElemIDVar(elemVar);
		String parentSlot = "(parent_id " + parentID + ")";
		String factIDSlot = "";
		if (useElemTempVar) {
			factIDSlot = generateFactTempIDSlot(elemVar, tempVarAppendix);
		}
		String propSlots = generatePropFactPropSlots(propVars2Comparisons, bin,
				tempVarAppendix, useTempVarLeft, useTempVarRight);
		String deletedSlot = "(deleted FALSE)";

		buf.append(factPatternStart);
		buf.append("\n");
		buf.append(Indent.apply(typeSlot, INDENT_PROPFACT));
		buf.append("\n");
		buf.append(Indent.apply(parentSlot, INDENT_PROPFACT));
		buf.append("\n");
		if (useElemTempVar) {
			buf.append(Indent.apply(factIDSlot, INDENT_PROPFACT));
			buf.append("\n");
		}
		buf.append(Indent.apply(propSlots, INDENT_PROPFACT));
		buf.append("\n");
		buf.append(Indent.apply(deletedSlot, INDENT_PROPFACT));
		buf.append(")");
		return buf.toString();
	}

	/**
	 * Generates Jess 'property' Fact pattern according to the given
	 * specification (considers only one {@link Comparison})
	 * 
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param tempVarAppendix
	 *            will be appended to generated var names to guarantee
	 *            uniqueness
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 * @return
	 */
	public String generatePropFact(Comparison comparison, Bin bin,
			int tempVarAppendix, boolean useTempElemVar,
			boolean useTempVarLeft, boolean useTempVarRight) {
		Map<PropertyVariable, List<Comparison>> propVars2Comparisons = new HashMap<PropertyVariable, List<Comparison>>();
		PropertyVariable propVar = comparison.getLeftExpr();
		ElementVariable elemVar = propVar.getElementVar();
		List<Comparison> comparisons = new Vector<Comparison>();
		comparisons.add(comparison);
		propVars2Comparisons.put(propVar, comparisons);
		PropDescr prop = propVar.getProp();
		return generatePropFact(elemVar, prop, propVars2Comparisons, bin,
				tempVarAppendix, useTempElemVar, useTempVarLeft,
				useTempVarRight);
	}

	/**
	 * Generates Jess 'constant-set' Fact pattern according to given
	 * specification
	 * 
	 * @param patternID
	 *            pattern in which const value is used
	 * @param constNumID
	 *            id of the specific const value
	 * @return
	 */
	public String generateConstFact(String patternID, int constNumID) {
		StringBuffer buf = new StringBuffer();

		String constantFactID = idGen.generateConstantFactID(patternID,
				constNumID);
		String idSlot = "(id " + constantFactID + ")";

		String constantValueVar = idGen
				.generateConstantFactValueTempVar(constNumID);
		String valuesSlot = "(values $?" + constantValueVar + " $?)";

		buf.append("(constant-set");
		buf.append("\n");
		buf.append(Indent.apply(idSlot, INDENT_CONSTSET));
		buf.append("\n");
		buf.append(Indent.apply(valuesSlot, INDENT_CONSTSET));
		buf.append(")");
		return buf.toString();

	}

	/**
	 * Generates Jess 'in_neighbors', 'out_neighbors' and 'neighbors' slots,
	 * including given neighbor constraints, to be used within a Jess 'node'
	 * Fact pattern.
	 * 
	 * @param nodeConstr
	 * @return
	 */
	private String generateElemFactNeighborSlots(NodeConstr nodeConstr) {
		StringBuffer buf = new StringBuffer();
		ElementVariable elemVar = nodeConstr.getElemVar();

		String inNeighborsVar = idGen.generateNodeInNeigborsVar(elemVar);
		List<ElementVariable> inNeighborVars = nodeConstr.getNeighborConstrs()
				.getInNeighbors();
		String inNeighborSlot = generateNeigborsSlot("in_neighbors",
				inNeighborsVar, inNeighborVars);

		String outNeighborsVar = idGen.generateNodeOutNeigborsVar(elemVar);
		List<ElementVariable> outNeighborVars = nodeConstr.getNeighborConstrs()
				.getOutNeighbors();
		String outNeighborSlot = generateNeigborsSlot("out_neighbors",
				outNeighborsVar, outNeighborVars);

		String neighborsVar = idGen.generateNodeNeigborsVar(elemVar);
		List<ElementVariable> neighborVars = nodeConstr.getNeighborConstrs()
				.getNeighbors();
		String neighborSlot = generateNeigborsSlot("neighbors", neighborsVar,
				neighborVars);

		buf.append(inNeighborSlot);
		buf.append("\n");
		buf.append(outNeighborSlot);
		buf.append("\n");
		buf.append(neighborSlot);
		return buf.toString();
	}

	/**
	 * Generate one specific 'neighbors' slot, to be used within a Jess 'node'
	 * Fact pattern.
	 * 
	 * @param slotName
	 *            use 'in_neighbors', 'out_neighbors' or 'neighbors'
	 * @param varID
	 * @param neighborVars
	 *            constraints
	 * @return
	 */
	private String generateNeigborsSlot(String slotName, String varID,
			List<ElementVariable> neighborVars) {
		StringBuffer buf = new StringBuffer();
		buf.append("(" + slotName + " " + varID);
		for (ElementVariable neighborVar : neighborVars) {
			buf.append("&:(not(member " + idGen.generateElemIDVar(neighborVar)
					+ " " + varID + "))");
		}
		buf.append(")");
		return buf.toString();
	}

	/**
	 * Generates element id constraints (i.e., an element id is unequal to all
	 * predecessor ids), to be used within an 'id' slot
	 * 
	 * @param predecessors
	 * @return
	 */
	private String generateElemIDConstrs(
			List<? extends ElementConstr> predecessors) {
		StringBuffer buf = new StringBuffer();
		for (ElementConstr pred : predecessors) {
			buf.append("&~" + idGen.generateElemIDVar(pred.getElemVar()));
		}
		return buf.toString();
	}

	/**
	 * Generates Jess 'property' slots, according to the given specification, to
	 * be used within a Jess 'node' or 'link' Fact pattern.
	 * 
	 * @param elemConstr
	 * @param compSelector
	 *            {@link Comparison} selector (of {@link ComparisonType})
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @return
	 */
	private String generateElemFactPropSlots(ElementConstr elemConstr,
			ComparisonType compSelector, Bin bin) {
		StringBuffer buf = new StringBuffer();
		ElementVariable elemVar = elemConstr.getElemVar();
		List<PropDescr> props = elemVar.getProps();
		for (Iterator<PropDescr> iter = props.iterator(); iter.hasNext();) {
			PropDescr prop = iter.next();
			if (prop.isInJessElementFact()) {
				PropertyVariable propVar = elemVar.getPropVar(prop,
						PropDescr.DEFAULT_COMPONENT_ID);
				List<Comparison> propComparisons = elemConstr.getComparisons(
						bin, propVar);
				String slotExp = generatePropSlot(propVar, propComparisons,
						compSelector, bin, -1, false, false);
				buf.append(slotExp);
				if (iter.hasNext()) {
					buf.append("\n");
				}
			}
		}
		return buf.toString();
	}

	/**
	 * Generates Jess 'property' slots, according to the given specification, to
	 * be used within a Jess 'property' Fact pattern.
	 * 
	 * @param propVars2Comparisons
	 *            {@link Comparison}s
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 * @return
	 */
	private String generatePropFactPropSlots(
			Map<PropertyVariable, List<Comparison>> propVars2Comparisons,
			Bin bin, int tempVarAppendix, boolean useTempVarLeft,
			boolean useTempVarRight) {
		StringBuffer buf = new StringBuffer();
		for (PropertyVariable propVar : propVars2Comparisons.keySet()) {
			List<Comparison> comparisons = propVars2Comparisons.get(propVar);
			String slotExp = generatePropSlot(propVar, comparisons,
					ComparisonType.ALL, bin, tempVarAppendix, useTempVarLeft,
					useTempVarRight);
			buf.append(slotExp);
		}
		return buf.toString();
	}

	/**
	 * Generates Jess 'property' slot, according to the given specification
	 * 
	 * @param propVar
	 *            target property (component)
	 * @param propComparisons
	 *            {@link Comparisons}
	 * @param compSelector
	 *            {@link Comparison} selector (of {@link ComparisonType})
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 * @return
	 */
	private String generatePropSlot(PropertyVariable propVar,
			List<Comparison> propComparisons, ComparisonType compSelector,
			Bin bin, int tempVarAppendix, boolean useTempVarLeft,
			boolean useTempVarRight) {
		StringBuffer buf = new StringBuffer();

		String slotName = generateSlotName(propVar);
		String propVarID = idGen.generatePropVarID(propVar, tempVarAppendix,
				useTempVarLeft, false);
		String propSlotStart = "(" + slotName + " " + propVarID;
		String propSlotConstrs = generateSlotConstrs(propVar, propComparisons,
				compSelector, bin, tempVarAppendix, useTempVarLeft,
				useTempVarRight);

		buf.append(propSlotStart);
		if (!"".equals(propSlotConstrs)) {
			buf.append("\n");
			buf.append(Indent.apply(propSlotConstrs, INDENT_PROPCONSTR));
		}
		buf.append(")");
		return buf.toString();
	}

	/**
	 * Generates Jess Fact temp ID slot (i.e., ID var specific to comparison)
	 * 
	 * @param comparisonID
	 * @return
	 */
	private String generateFactTempIDSlot(ElementVariable elemVar,
			int comparisonID) {
		return "(id " + idGen.generateElemIDTempVar(elemVar, comparisonID)
				+ ")";
	}

	/**
	 * Generates slot constraint string for given {@link PropertyVariable}
	 * according to given specification.
	 * 
	 * @param propVar
	 *            target property (component)
	 * @param comparisons
	 *            {@link Comparisons}
	 * @param compSelector
	 *            {@link Comparison} selector (of {@link ComparisonType})
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 * @return
	 */
	private String generateSlotConstrs(PropertyVariable propVar,
			List<Comparison> comparisons, ComparisonType compSelector, Bin bin,
			int tempVarAppendix, boolean useTempVarLeft, boolean useTempVarRight) {
		StringBuffer buf = new StringBuffer();
		String varID = idGen.generatePropVarID(propVar, tempVarAppendix,
				useTempVarLeft, false);
		buf.append(generateNotNilSlotConstr(varID));
		for (Comparison comp : comparisons) {
			String slotConstr = generateSlotConstr(comp, compSelector, bin,
					tempVarAppendix, useTempVarLeft, useTempVarRight);
			if (!"".equals(slotConstr)) {
				buf.append("\n");
				buf.append(slotConstr);
			}
		}
		return buf.toString();
	}

	/**
	 * Generate 'not nil' constraint
	 * 
	 * @param varID
	 * @return
	 */
	private String generateNotNilSlotConstr(String varID) {
		return "&:(neq " + varID + "nil)";
	}

	/**
	 * Generates one slot constraint based on given {@link Comparison},
	 * according to given specification.
	 * 
	 * @param comparison
	 *            {@link Comparison}
	 * @param compSelector
	 *            {@link Comparison} selector (of {@link ComparisonType})
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 * @return
	 */
	private String generateSlotConstr(Comparison comparison,
			ComparisonType compSelector, Bin bin, int tempVarAppendix,
			boolean useTempVarLeft, boolean useTempVarRight) {
		if (compSelector == ComparisonType.ALL
				|| compSelector == comparison.getType()) {
			String leftExp = idGen.generatePropVarID(comparison.getLeftExpr(),
					tempVarAppendix, useTempVarLeft, false);
			String rightExp = generateRightExp(comparison, tempVarAppendix,
					useTempVarRight);
			return generateComparison(comparison, leftExp, rightExp, bin);
		}
		// irrelevant comparison: ignore
		return "";
	}

	/**
	 * Generate slot name for property based on {@link Ontology}
	 * 
	 * @param propVar
	 * @return
	 */
	private String generateSlotName(PropertyVariable propVar) {
		PropDescr prop = propVar.getProp();
		String slotName = prop.getJessSlot(propVar.getCompID());
		return slotName;
	}

	/**
	 * Generates 'right' operator for given {@link Comparison}.
	 * 
	 * @param comparison
	 * @param tempVarAppendix
	 * @param useTempVarRight
	 * @return
	 */
	private String generateRightExp(Comparison comparison, int tempVarAppendix,
			boolean useTempVarRight) {
		if (comparison instanceof Set2ConstSetComparison) {
			Set2ConstSetComparison c = (Set2ConstSetComparison) comparison;
			if (c.useJessConstantSetFact()) {
				return idGen.generateConstantFactValueTempVar(tempVarAppendix);
			} else {
				StringBuffer buf = new StringBuffer();
				buf.append("(create$");
				for (String val : c.getRightExpr()) {
					buf.append(" \"" + val + "\"");
				}
				buf.append(")");
				return buf.toString();
			}
		} else if (comparison instanceof Num2ConstNumComparison) {
			Num2ConstNumComparison c = (Num2ConstNumComparison) comparison;
			return "" + c.getRightExpr();
		} else if (comparison instanceof String2ConstStringComparison) {
			String2ConstStringComparison c = (String2ConstStringComparison) comparison;
			return " \"" + c.getRightExpr() + "\"";
		} else if (comparison instanceof Set2ConstStringComparison) {
			Set2ConstStringComparison c = (Set2ConstStringComparison) comparison;
			return " \"" + c.getRightExpr() + "\"";
		} else if (comparison instanceof String2ConstSetComparison) {
			String2ConstSetComparison c = (String2ConstSetComparison) comparison;
			StringBuffer buf = new StringBuffer();
			buf.append("(create$");
			for (String val : c.getRightExpr()) {
				buf.append(" \"" + val + "\"");
			}
			buf.append(")");
			return buf.toString();
		} else if (comparison instanceof VariableComparison) {
			VariableComparison varComp = (VariableComparison) comparison;
			String varID = idGen.generatePropVarID(varComp.getRightExpr(),
					tempVarAppendix, useTempVarRight, false);

			if (varComp instanceof Num2VarNumComparison) {
				Num2VarNumComparison numVarComparison = (Num2VarNumComparison) varComp;
				return "(+ " + varID + " " + numVarComparison.getOffset() + ")";
			} else {
				return varID;
			}
		}
		logger.error("Not handled Comparison type: " + comparison.toString());
		return null;
	}

	/**
	 * Generates Jess string for given {@link Comparison}.
	 * 
	 * @param comparison
	 * @param leftExp
	 * @param rightExp
	 * @param bin
	 * @return
	 */
	private String generateComparison(Comparison comparison, String leftExp,
			String rightExp, Bin bin) {

		if (bin.getNum() <= 2) {
			return compGen.getValue2ValueComparison(comparison, leftExp,
					rightExp);
		} else if (bin.getNum() <= 6) {
			return compGen.getComponent2ValueComparison(comparison, leftExp,
					rightExp);
		} else {
			return compGen.getComponent2ComponentComparison(comparison,
					leftExp, rightExp);
		}
	}

}
