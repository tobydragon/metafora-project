package de.dfki.lasad.sessionmodel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class SessionModelConfigurationTest extends SessionModelConfiguration {

	private Log logger = LogFactory.getLog(SessionModelConfigurationTest.class);
	
	public static void main(String[] args) {

		SessionModelConfigurationTest smcTest = new SessionModelConfigurationTest();
		smcTest.printOntologyBatches();
		smcTest.printAnnoBatches();
	}

	public void printOntologyBatches(){
		readOntologyDefs();
		
		for(String ontologyID: ontologyID2JessDefinitionBatch.keySet()){
			String batch = ontologyID2JessDefinitionBatch.get(ontologyID);
			logger.info("ONTOLOGY-ID: " + ontologyID);
			logger.info("\n" + batch);
		}
	}
	
	public void printAnnoBatches(){
		readAnnotations();
		
		for(String resourceID: resourceID2JessAnnotationBatch.keySet()){
			String batch = resourceID2JessAnnotationBatch.get(resourceID);
			logger.info("RESOURCE-ID: " + resourceID);
			logger.info("\n" + batch);
		}
	}
}
