package de.dfki.lasad.agents.instances.action;

import lasad.shared.dfki.meta.agents.ServiceID;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class UserServiceID {

	private UserID userID;
	private ServiceID serviceID;

	public UserServiceID(UserID userID, ServiceID serviceID) {
		this.userID = userID;
		this.serviceID = serviceID;
	}

	public UserID getUserID() {
		return userID;
	}

	public ServiceID getServiceID() {
		return serviceID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((serviceID == null) ? 0 : serviceID.hashCode());
		result = prime * result + ((userID == null) ? 0 : userID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserServiceID other = (UserServiceID) obj;
		if (serviceID == null) {
			if (other.serviceID != null)
				return false;
		} else if (!serviceID.equals(other.serviceID))
			return false;
		if (userID == null) {
			if (other.userID != null)
				return false;
		} else if (!userID.equals(other.userID))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UserServiceID [userID=" + userID + ", serviceID=" + serviceID
				+ "]";
	}

}
