package de.dfki.lasad.events.eue.admin.session;


/**
 * Provides information about session.
 * 
 * @author Oliver Scheuer
 * 
 */
public class SessionOverviewEvent extends EUESessionInfoEvent {

	protected String templateID;
	protected String ontologyID;

	public SessionOverviewEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getTemplateID() {
		return templateID;
	}

	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}

	public String getOntologyID() {
		return ontologyID;
	}

	public void setOntologyID(String ontologyID) {
		this.ontologyID = ontologyID;
	}

	@Override
	public String toString() {
		return "sessionID=" + sessionID + ", templateID=" + templateID
				+ ", ontologyID=" + ontologyID;
	}

}
