package de.dfki.lasad.agents.logic.provision.actionfilter;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public interface MsgFilter {

	public boolean keep(ActionTypeResult aTypeResult);
}
