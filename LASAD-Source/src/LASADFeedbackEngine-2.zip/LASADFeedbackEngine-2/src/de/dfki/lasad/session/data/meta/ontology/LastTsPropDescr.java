package de.dfki.lasad.session.data.meta.ontology;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class LastTsPropDescr extends StandardPropDescr {

	public LastTsPropDescr() {
		super("last-ts", null, "last_mod_ts", JessDataType.NUMBER, ComparisonGroup.TS);
	}

}
