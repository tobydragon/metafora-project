package de.dfki.lasad.events.eue.admin.agent.in;

import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class DeleteAgentEvent extends EUEAgentAdminEvent {

	private String agentID;

	public DeleteAgentEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	@Override
	public String toString() {
		return "DeleteAgentEvent [agentID=" + agentID + "]";
	}

}
