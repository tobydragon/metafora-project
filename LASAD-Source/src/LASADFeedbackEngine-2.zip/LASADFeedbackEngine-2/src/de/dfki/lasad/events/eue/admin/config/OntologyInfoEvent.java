package de.dfki.lasad.events.eue.admin.config;

import de.dfki.lasad.session.data.meta.Ontology;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class OntologyInfoEvent extends EUEConfigInfoEvent {

	String ontologyXML;
	Ontology ontology;

	public OntologyInfoEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getOntologyXML() {
		return ontologyXML;
	}

	public void setOntologyXML(String ontologyXML) {
		this.ontologyXML = ontologyXML;
	}

	public Ontology getOntology() {
		return ontology;
	}

	public void setOntology(Ontology ontology) {
		this.ontology = ontology;
	}

	@Override
	public String toString() {
		return super.toString() + ", ontology="
				+ (ontology == null ? "null" : ontology.toString());
	}
}
