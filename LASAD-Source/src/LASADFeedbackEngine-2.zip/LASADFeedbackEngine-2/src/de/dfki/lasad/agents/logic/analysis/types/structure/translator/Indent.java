package de.dfki.lasad.agents.logic.analysis.types.structure.translator;

/**
 * Converts String in indented String to pretty-print generated Jess rules
 * 
 * @author oliverscheuer
 * 
 */
public class Indent {

	/**
	 * Converts String in indented String, i.e., each line will be indented
	 * according to the given 'indent' parameter.
	 * 
	 */
	public static String apply(String s, String indent) {
		int counter = 0;
		String linebreakRemoved = s;
		while (linebreakRemoved.endsWith("\n")) {
			linebreakRemoved = linebreakRemoved.substring(0,
					linebreakRemoved.length() - 1);
			++counter;
		}
		StringBuffer result = new StringBuffer();
		result.append(indent);
		result.append(linebreakRemoved.replace("\n", "\n" + indent));
		for (int i = 0; i < counter; ++i) {
			result.append("\n");
		}

		return result.toString();
	}
}
