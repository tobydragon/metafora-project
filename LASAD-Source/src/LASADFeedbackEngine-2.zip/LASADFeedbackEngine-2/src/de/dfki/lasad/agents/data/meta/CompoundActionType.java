package de.dfki.lasad.agents.data.meta;

import java.util.List;
import java.util.Vector;

/**
 * Comprises a set of subordinate {@link ActionType}s and a specification of how
 * to sort and filter a set of results that is based on these subordinate
 * {@link ActionType}s.
 * 
 * @author Oliver Scheuer
 * 
 */
public class CompoundActionType extends ActionType {

	public static final int ALL_RESULTS = -1;

	private boolean allTypes = false;

	// filter and sort criteria
	public static final String ONE_PER_TYPE = "ONE_PER_TYPE";

	private List<ActionType> subActionTypes = new Vector<ActionType>();

	private int maxNumResults = ALL_RESULTS; // -1 ... unlimited
	private List<String> filterAndSortCriteria = new Vector<String>();

	public CompoundActionType(String actionAgentID, String actionTypeID) {
		super(actionAgentID, actionTypeID);
	}

	/**
	 * For debugging purposes. Instead of using the full-fledged infrastructure
	 * to access dependent {@link ActionType}s (which might not be initialized
	 * in a testing scenario), {@link ActionType}s are provided here directly.
	 * 
	 * @param actionAgentID
	 * @param actionTypeID
	 * @param subActionTypes
	 */
	public CompoundActionType(String actionAgentID, String actionTypeID,
			List<ActionType> subActionTypes) {
		this(actionAgentID, actionTypeID);
		this.subActionTypes = subActionTypes;
	}

	public void addFilterCriterion(String criterion) {
		filterAndSortCriteria.add(criterion);
	}

	/**
	 * Returns all dependent {@link ActionType}s.
	 * 
	 * @return
	 */
	public List<ActionType> getSubActionTypes() {
		return subActionTypes;
	}

	public void addActionType(ActionType subType) {
		subActionTypes.add(subType);
	}

	public boolean isAllTypes() {
		return allTypes;
	}

	public void setAllTypes(boolean allTypes) {
		this.allTypes = allTypes;
	}

	public List<String> getCriteria() {
		return filterAndSortCriteria;
	}

	public int getMaxNumResults() {
		return maxNumResults;
	}

	public void setMaxNumResults(int maxNumResults) {
		this.maxNumResults = maxNumResults;
	}

}
