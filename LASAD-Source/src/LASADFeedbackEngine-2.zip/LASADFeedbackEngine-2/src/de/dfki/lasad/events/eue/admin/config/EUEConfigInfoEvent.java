package de.dfki.lasad.events.eue.admin.config;

import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.eue.admin.EUEAdminEvent;

/**
 * Event providing information regarding the configuration of the EUE that is
 * NOT tied to a specific EUE session.
 * 
 * @author oliverscheuer
 * 
 */
public class EUEConfigInfoEvent extends EventImpl implements EUEAdminEvent {

	public EUEConfigInfoEvent(String srcCompId) {
		super(srcCompId);
	}
}
