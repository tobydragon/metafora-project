package de.dfki.lasad.authoring.model.pattern;

import java.util.List;

/**
 * Specifies that some {@link NodeVariable} must have an out-link to some other
 * {@link NodeVariable} ({@link #outNeighbors}), an in-link from some other
 * {@link NodeVariable} ({@link #inNeighbors}), or be connected in any way with
 * some other {@link NodeVariable} ({@link #neighbors}).
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class NeighborConstrs {

	private List<ElementVariable> inNeighbors;
	private List<ElementVariable> outNeighbors;
	private List<ElementVariable> neighbors;

	public List<ElementVariable> getInNeighbors() {
		return inNeighbors;
	}

	public void setInNeighbors(List<ElementVariable> inNeighbors) {
		this.inNeighbors = inNeighbors;
	}

	public List<ElementVariable> getOutNeighbors() {
		return outNeighbors;
	}

	public void setOutNeighbors(List<ElementVariable> outNeighbors) {
		this.outNeighbors = outNeighbors;
	}

	public List<ElementVariable> getNeighbors() {
		return neighbors;
	}

	public void setNeighbors(List<ElementVariable> neighbors) {
		this.neighbors = neighbors;
	}

}
