package de.dfki.lasad.agents.instances.action.xml.test;

import java.io.File;

import junit.framework.TestCase;
import lasad.shared.dfki.meta.agents.ActionAgentConfigData;

import org.jdom.Document;
import org.jdom.output.Format;
import org.jdom.output.Format.TextMode;
import org.jdom.output.XMLOutputter;

import de.dfki.lasad.agents.instances.action.xml.ActionAgentConfigDataXML;
import de.dfki.lasad.core.ConfigurationDatabase;
import de.dfki.lasad.core.FeedbackConfigManager;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class FeedbackConfigDataXMLTest extends TestCase {

	private static final String IN_CONF_AGENT = "largo-default";
	private static final String OUT_CONF_AGENT = "largo-DEBUG";

	/**
	 * Constructs a {@link ActionAgentConfigData} instance by parsing XML file
	 * (IN_CONF), converts the constructed {@link ActionAgentConfigData} instance
	 * into an XML document, prints XML document to console.
	 */
	public void testXML2Console() {
		try {

			File inFile = ConfigurationDatabase
					.getAgentConfigMasterFile(IN_CONF_AGENT);

			ActionAgentConfigData conf = ActionAgentConfigDataXML.fromXMLFile(
					IN_CONF_AGENT, inFile);
			// System.out.println(conf.toString());

			Document doc = ActionAgentConfigDataXML.toXMLDoc(conf);
			Format format = Format.getPrettyFormat();
			format.setTextMode(TextMode.PRESERVE);
			XMLOutputter o = new XMLOutputter(format);
			System.out.println(o.outputString(doc));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Constructs a {@link ActionAgentConfigData} instance by parsing XML file
	 * (IN_CONF), converts the constructed {@link ActionAgentConfigData} instance
	 * into an XML document, writes XML document to file system (OUT_CONF)
	 */
	public void testXML2File() {
		try {
			File inFile = ConfigurationDatabase
					.getAgentConfigMasterFile(IN_CONF_AGENT);

			ActionAgentConfigData conf = ActionAgentConfigDataXML.fromXMLFile(
					IN_CONF_AGENT, inFile);
			// System.out.println(conf.toString());
			conf.replaceAgentID(OUT_CONF_AGENT);

			FeedbackConfigManager.writeAgentConfig(conf);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
