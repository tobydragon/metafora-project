package de.dfki.lasad.agents.logic.action.patternfilter;

/**
 * 
 * @author oliverscheuer
 *
 */
public interface ObjectFilter_LastModTime {

}
