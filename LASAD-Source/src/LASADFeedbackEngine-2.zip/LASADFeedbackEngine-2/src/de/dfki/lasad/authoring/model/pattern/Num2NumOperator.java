package de.dfki.lasad.authoring.model.pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public enum Num2NumOperator implements Operator{
	EQUAL("NUM_EQUAL"), 
	NOT_EQUAL("NUM_NOT_EQUAL"), 
	LESS("LESS"), 
	LESS_OR_EQUAL("LESS_OR_EQUAL"), 
	GREATER("GREATER"), 
	GREATER_OR_EQUAL("GREATER_OR_EQUAL");

	private static final Log logger = LogFactory.getLog(Num2NumOperator.class);
	
	private final String operator;

	Num2NumOperator(String operator) {
		this.operator = operator;
	}
	
	public Num2NumOperator invert() {
		if (equals(EQUAL)) {
			return EQUAL;
		} else if (equals(NOT_EQUAL)) {
			return NOT_EQUAL;
		} else if (equals(LESS)) {
			return GREATER;
		} else if (equals(LESS_OR_EQUAL)) {
			return GREATER_OR_EQUAL;
		} else if (equals(GREATER)) {
			return LESS;} 
		else if (equals(GREATER_OR_EQUAL)) {
				return LESS_OR_EQUAL;
		} else {
			logger.error("Error in method invert()");
			return null;
		}
	}
}
