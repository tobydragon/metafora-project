package de.dfki.lasad.agents.logic.action.patternfilter;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public interface PatternFilterServiceInterface {

	public boolean keep(AnalysisResult result);
}
