package de.dfki.lasad.core;

import java.io.File;

import lasad.shared.dfki.meta.agents.ServiceID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.util.FileUtil;

/**
 * Provides access to configuration files and directories.
 * 
 * @author oliverscheuer
 * 
 */
public class ConfigurationDatabase {

	static Log logger = LogFactory.getLog(ConfigurationDatabase.class);

	protected static String afConfHomeDefaultLocalPath = "conf/default";
	protected static File configHome;

	protected static String resourcesDirLocalFilename = "resources";
	protected static File resourcesDir;
	protected static String resourcesBasicLocalFilename = "basic.resources.xml";
	protected static File resourcesBasicFile;
	protected static String resourcesAgentsLocalFilename = "agents.resources.xml";
	protected static File resourcesAgentsFile;

	protected static String runtimeDirLocalFilename = "runtime";
	protected static File runtimeDir;
	protected static String runtimeBasicLocalFilename = "basic.runtime.xml";
	protected static File runtimeBasicFile;
	protected static String runtimeAgentsLocalFilename = "startup.runtime.xml";
	protected static File runtimeAgentsFile;

	protected static String confDetailsLocalFilename = "details";
	protected static String confDetailsAgentsLocalFilename = "agents";
	protected static String confDetailsAgentsTypesLocalFilename = "types";
	protected static File confDetailsAgentTypesDir;

	/**
	 * setup configuration files and directories
	 */
	static {
		String afConfHomeString = System.getProperty("lasad.af.conf");
		if (afConfHomeString == null) {
			afConfHomeString = (new File(afConfHomeDefaultLocalPath))
					.getAbsolutePath();
			logger.warn("System property 'lasad.af.home' not set. Using default directory: "
					+ afConfHomeDefaultLocalPath);

		}
		logger.info("LASAD A&F configuration home: " + afConfHomeString);

		configHome = new File(afConfHomeString);
		if (!configHome.exists()) {
			logger.error("Specified configuration home folder does not exist: "
					+ configHome.getAbsolutePath());
		}

		resourcesDir = new File(configHome, resourcesDirLocalFilename);
		if (!resourcesDir.exists()) {
			logger.error("Folder 'resources' does not exist in "
					+ configHome.getAbsolutePath());
		}

		resourcesBasicFile = new File(resourcesDir, resourcesBasicLocalFilename);
		if (!resourcesBasicFile.exists()) {
			logger.error("File 'basic.resources.xml' does not exist in "
					+ resourcesDir.getAbsolutePath());
		}

		resourcesAgentsFile = new File(resourcesDir,
				resourcesAgentsLocalFilename);
		if (!resourcesAgentsFile.exists()) {
			logger.error("File 'agent.xml' does not exist in "
					+ resourcesDir.getAbsolutePath());
		}

		runtimeDir = new File(configHome, runtimeDirLocalFilename);
		if (!runtimeDir.exists()) {
			logger.error("Folder 'runtime' does not exist in "
					+ configHome.getAbsolutePath());
		}

		runtimeBasicFile = new File(runtimeDir, runtimeBasicLocalFilename);
		if (!runtimeBasicFile.exists()) {
			logger.error("File 'basic.runtime.xml' does not exist in "
					+ runtimeDir.getAbsolutePath());
		}

		runtimeAgentsFile = new File(runtimeDir, runtimeAgentsLocalFilename);
		if (!runtimeAgentsFile.exists()) {
			logger.error("File 'startup.runtime.xml' does not exist in "
					+ runtimeDir.getAbsolutePath());
		}

		File confDetailsDir = new File(configHome, confDetailsLocalFilename);
		File confDetailsAgentsDir = new File(confDetailsDir,
				confDetailsAgentsLocalFilename);
		confDetailsAgentTypesDir = new File(confDetailsAgentsDir,
				confDetailsAgentsTypesLocalFilename);

	}

	public static File getConfigHome() {
		return configHome;
	}

	public static File getResourcesDir() {
		return resourcesDir;
	}

	public static File getResourcesBasicFile() {
		return resourcesBasicFile;
	}

	public static File getResourcesAgentsFile() {
		return resourcesAgentsFile;
	}

	public static File getRuntimeDir() {
		return runtimeDir;
	}

	public static File getRuntimeBasicFile() {
		return runtimeBasicFile;
	}

	public static File getAgentsRuntimeFile() {
		return runtimeAgentsFile;
	}

	public static File getAgentConfHomeDir(String agentID) {
		File agentHomeDir = new File(confDetailsAgentTypesDir, agentID);
		return agentHomeDir;
	}

	public static boolean isAgentConfHomeDirAlreadyInUse(String agentID) {
		File agentHomeDir = new File(confDetailsAgentTypesDir, agentID);
		return agentHomeDir.exists();
	}

	public static File getAgentConfigMasterFile(String agentID) {
		File aHome = getAgentConfHomeDir(agentID);
		File jessConf = new File(aHome, agentID + ".xml");
		return jessConf;
	}

	public static File getAgentConfigPatternDir(String agentID) {
		File aHome = getAgentConfHomeDir(agentID);
		File jessPatternDir = new File(aHome, "patterns");
		return jessPatternDir;
	}

	public static File getAgentConfigPatternFile(ServiceID serviceID) {
		File patternDir = getAgentConfigPatternDir(serviceID.getAgentID());
		File patternFile = new File(patternDir, serviceID.getTypeID() + ".xml");
		return patternFile;
	}

	public static boolean isAgentConfigPatternFileAlreadyInUse(
			ServiceID serviceID) {
		File patternDir = getAgentConfigPatternDir(serviceID.getAgentID());
		File patternFile = new File(patternDir, serviceID.getTypeID() + ".xml");
		return patternFile.exists();
	}

	public static File getAgentConfigJessRuleFile(ServiceID serviceID) {
		String agentID = serviceID.getAgentID();
		String patternID = serviceID.getTypeID();
		File patternDir = getAgentConfigPatternDir(agentID);
		File jessPatternFile = new File(patternDir, patternID + ".clp.txt");
		return jessPatternFile;
	}

	public static boolean isAgentConfigJessRuleFileAlreadyInUse(
			ServiceID serviceID) {
		String agentID = serviceID.getAgentID();
		String patternID = serviceID.getTypeID();
		File patternDir = getAgentConfigPatternDir(agentID);
		File jessPatternFile = new File(patternDir, patternID + ".clp.txt");
		return jessPatternFile.exists();
	}

	public static String getAgentConfigMasterRelFilepath(String agentID) {
		File masterConfigFile = getAgentConfigMasterFile(agentID);
		String relAgentMasterConfFilePath = FileUtil.getRelativePath(
				configHome, masterConfigFile);
		return relAgentMasterConfFilePath;
	}

}
