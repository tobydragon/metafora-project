package de.dfki.lasad.core;

import java.io.File;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Provides access to configuration files and directories.
 * 
 * @author oliverscheuer
 * 
 */
public class ConfigurationDatabase {

	static Log logger = LogFactory.getLog(ConfigurationDatabase.class);

	private static String afConfHomeDefaultLocalPath = "conf/default";
	private static File configHome;

	private static File resourcesDir;
	private static File resourcesBasicFile;
	private static File resourcesAgentsFile;

	private static File runtimeDir;
	private static File runtimeBasicFile;
	private static File runtimeAgentsFile;

	private static File confDetailsAgentTypesDir;

	/**
	 * setup configuration files and directories
	 */
	static {
		String afConfHomeString = System.getProperty("lasad.af.conf");
		if (afConfHomeString == null) {
			afConfHomeString = (new File(afConfHomeDefaultLocalPath))
					.getAbsolutePath();
			logger.warn("System property 'lasad.af.home' not set. Using default directory: "
					+ afConfHomeDefaultLocalPath);

		}
		logger.info("LASAD A&F configuration home: " + afConfHomeString);

		configHome = new File(afConfHomeString);
		if (!configHome.exists()) {
			logger.error("Specified configuration home folder does not exist: "
					+ configHome.getAbsolutePath());
		}

		resourcesDir = new File(configHome, "resources");
		if (!resourcesDir.exists()) {
			logger.error("Folder 'resources' does not exist in "
					+ configHome.getAbsolutePath());
		}

		resourcesBasicFile = new File(resourcesDir, "basic.resources.xml");
		if (!resourcesBasicFile.exists()) {
			logger.error("File 'basic.resources.xml' does not exist in "
					+ resourcesDir.getAbsolutePath());
		}

		resourcesAgentsFile = new File(resourcesDir, "agents.resources.xml");
		if (!resourcesAgentsFile.exists()) {
			logger.error("File 'agent.xml' does not exist in "
					+ resourcesDir.getAbsolutePath());
		}

		runtimeDir = new File(configHome, "runtime");
		if (!runtimeDir.exists()) {
			logger.error("Folder 'runtime' does not exist in "
					+ configHome.getAbsolutePath());
		}

		runtimeBasicFile = new File(runtimeDir, "basic.runtime.xml");
		if (!runtimeBasicFile.exists()) {
			logger.error("File 'basic.runtime.xml' does not exist in "
					+ runtimeDir.getAbsolutePath());
		}

		runtimeAgentsFile = new File(runtimeDir, "startup.runtime.xml");
		if (!runtimeAgentsFile.exists()) {
			logger.error("File 'startup.runtime.xml' does not exist in "
					+ runtimeDir.getAbsolutePath());
		}

		File confDetailsDir = new File(configHome, "details");
		File confDetailsAgentsDir = new File(confDetailsDir, "agents");
		confDetailsAgentTypesDir = new File(confDetailsAgentsDir, "types");

	}

	public static File getConfigHome() {
		return configHome;
	}

	public static File getResourcesDir() {
		return resourcesDir;
	}

	public static File getResourcesBasicFile() {
		return resourcesBasicFile;
	}

	public static File getResourcesAgentsFile() {
		return resourcesAgentsFile;
	}

	public static File getRuntimeDir() {
		return runtimeDir;
	}

	public static File getRuntimeBasicFile() {
		return runtimeBasicFile;
	}

	public static File getAgentsRuntimeFile() {
		return runtimeAgentsFile;
	}

	public static File getAgentConfHomeDir(String agentID) {
		File agentHomeDir = new File(confDetailsAgentTypesDir, agentID);
		return agentHomeDir;
	}

	public static File getAgentConfigBEMasterFile(String agentID) {
		File aHome = getAgentConfHomeDir(agentID);
		File jessConf = new File(aHome, agentID + ".jess.xml");
		return jessConf;
	}

	public static File getAgentConfigBEPatternDir(String agentID) {
		File aHome = getAgentConfHomeDir(agentID);
		File jessPatternDir = new File(aHome, "patterns");
		return jessPatternDir;
	}

	public static File getAgentConfigBEPatternFile(String agentID,
			String patternID) {
		File jessPatternDir = getAgentConfigBEPatternDir(agentID);
		File jessPatternFile = new File(jessPatternDir, patternID + ".xml");
		return jessPatternFile;
	}

	public static File getAgentConfigFEFile(String agentID) {
		File aHome = getAgentConfHomeDir(agentID);
		File xmlConf = new File(aHome, agentID + ".xml");
		return xmlConf;
	}

	public static String getRelativePath(File pointOfReference, File file) {
		String pointOfReferencePath = pointOfReference.getAbsolutePath();
		String filePath = file.getAbsolutePath();
		int beginIndex = pointOfReferencePath.length() + 1;
		String relativePath = filePath.substring(beginIndex);
		return relativePath;
	}

	public static String getAgentConfigBERelativeFilepath(String agentID) {
		File masterConfigFile = getAgentConfigBEMasterFile(agentID);
		String relAgentMasterConfFilePath = ConfigurationDatabase
				.getRelativePath(configHome, masterConfigFile);
		return relAgentMasterConfFilePath;
	}

	public static String getAgentConfigFERelativeFilepath(String agentID) {
		File agentFEConfigFile = getAgentConfigFEFile(agentID);
		String relAgentFEConfFilePath = ConfigurationDatabase.getRelativePath(
				configHome, agentFEConfigFile);
		return relAgentFEConfFilePath;
	}

}
