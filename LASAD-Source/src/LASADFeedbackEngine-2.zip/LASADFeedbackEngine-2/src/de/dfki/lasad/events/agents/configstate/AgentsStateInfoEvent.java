package de.dfki.lasad.events.agents.configstate;

import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionListFE;
import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AgentsStateInfoEvent extends EUEAgentAdminEvent {

	private boolean changed;
	private AgentDescriptionListFE agentDescriptionList;

	public AgentsStateInfoEvent(String srcCompId) {
		super(srcCompId);
	}

	public AgentDescriptionListFE getAgentDescriptionList() {
		return agentDescriptionList;
	}

	public void setAgentDescriptionList(
			AgentDescriptionListFE agentDescriptionList) {
		this.agentDescriptionList = agentDescriptionList;
	}

	public boolean isChanged() {
		return changed;
	}

	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	@Override
	public String toString() {
		return "AgentsInfoEvent [changed=" + changed
				+ ", agentDescriptionList=" + agentDescriptionList + "]";
	}

}
