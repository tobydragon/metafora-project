package de.dfki.lasad.agents.logic.provision.actionsort.xml;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.provision.priority.MsgSortCriterion;
import lasad.shared.dfki.meta.agents.provision.priority.MsgSortCriterion_MsgPriority;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgSortCriterionListXML {

	private static Log logger = LogFactory
			.getLog(MsgSortCriterionListXML.class);

	public static final String ELEMENT_NAME = "sort-criteria";

	public static final String CRITERION_MSG_PRIORITY = "message-priority";

	public static List<MsgSortCriterion> fromXML(Element sortCriteriaElem) {
		List<MsgSortCriterion> criteriaDefs = new Vector<MsgSortCriterion>();
		for (Element criterionElem : (List<Element>) sortCriteriaElem
				.getChildren("sort-criterion")) {

			String type = criterionElem.getAttributeValue("type");
			if (CRITERION_MSG_PRIORITY.equalsIgnoreCase(type)) {
				MsgSortCriterion sortCriterion = new MsgSortCriterion_MsgPriority();
				criteriaDefs.add(sortCriterion);
			} else {
				logger.error("(fromXML) Unhandled sort criterion type: " + type);
				return null;
			}
		}
		return criteriaDefs;
	}

	public static Element toXML(List<MsgSortCriterion> sortCriteria) {
		Element criteriaElem = new Element(ELEMENT_NAME);
		for (MsgSortCriterion criterion : sortCriteria) {
			Element criterionElem = new Element("sort-criterion");
			criteriaElem.addContent(criterionElem);
			if (criterion instanceof MsgSortCriterion_MsgPriority) {
				criterionElem.setAttribute("type", CRITERION_MSG_PRIORITY);
			} else {
				logger.error("(toXML) Unhandled sort criterion type: "
						+ criterion);
				return null;
			}
		}
		return criteriaElem;
	}
}
