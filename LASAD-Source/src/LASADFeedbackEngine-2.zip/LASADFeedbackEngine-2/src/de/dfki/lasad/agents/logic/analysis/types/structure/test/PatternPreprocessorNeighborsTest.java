package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import java.io.File;
import java.util.List;

import de.dfki.lasad.agents.logic.analysis.types.structure.translator.PatternPreprocessor;
import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableSuppl;
import lasad.shared.dfki.meta.agents.analysis.structure.model.LinkVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.NodeVariable;

/**
 * 
 * Print out links and node-neighbors (computed during pre-processing) to check
 * whether derived node-neighbors are correct.
 * 
 * @author oliverscheuer
 * 
 */
public class PatternPreprocessorNeighborsTest {

	static PatternPreprocessor preprocessor = new PatternPreprocessor(
			TestData.largoOntology);

	static {
		preprocessor.testModePrintIntermediateResults = false;
		preprocessor.testModeOmitSequentialization = false;
	}

	public static void main(String[] args) {
		printAllCases();
	}

	static void printPreparedCase() {
		StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
				.parsePattern(TestData.TESTFILE_REORDER_SEQUENCE);
		printLinksAndDerivedNeighbors(pattern);
	}

	static void printAllCases() {
		for (File testCase : TestData.testFiles) {
			System.out.println("\n----- " + testCase.getName() + " -----\n");

			StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
					.parsePattern(testCase);
			printLinksAndDerivedNeighbors(pattern);

		}
	}

	static void printLinksAndDerivedNeighbors(StructureAnalysisType pattern) {
		System.out.println("Links");
		List<LinkVariable> linkVars = pattern.getPattern().getLinkVars();
		for (LinkVariable linkVar : linkVars) {
			System.out.println(linkVar.toPrettyString(""));
		}
		preprocessor.preprocess(pattern.getPattern());
		System.out.println("NeighborConstraints - Nodes");
		List<NodeVariable> nodeVars = pattern.getPattern().getNodeVars();
		for (NodeVariable nodeVar : nodeVars) {
			ElementVariableSuppl supplData = nodeVar.getSupplData();
			System.out.println(nodeVar.getVarID() + ": "
					+ supplData.getNeighborConstrs().toString());
		}
	}

}
