package de.dfki.lasad.sessionmodel.jessfunctions;

/**
 * 
 * @author oliverscheuer
 *
 */
public class BasicOperators {

	// basic operators
	
	public static final String LESS = "<";
	public static final String LESS_OR_EQUAL = "<=";
	
	public static final String GREATER = ">";
	public static final String GREATER_OR_EQUAL = ">=";
	
	public static final String EQUAL = "=";
	public static final String UNEQUAL = "!=";
	
	public static final String EQUAL_RE = "=RE";
	public static final String UNEQUAL_RE = "!=RE";
	
	public static final String SUBSET = "SUBSET";
	public static final String SUPERSET = "SUPERSET";
	
}
