package de.dfki.lasad.dataservice.lasad;

import java.util.ArrayList;
import java.util.List;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.categories.Categories;
import lasad.gwt.client.communication.objects.commands.Commands;
import lasad.gwt.client.communication.objects.parameters.ParameterTypes;

public class LasadActionFactory {
	
	// //Added by TD straight from ActionFactory, 18.04.2011

	public static Action createMap(String useMapName, String useTemplate,
			String useRestriction) {
		Action a = new Action(Commands.CreateMap, Categories.Authoring);
		a.addParameter(ParameterTypes.MapName, useMapName);
		a.addParameter(ParameterTypes.Template, useTemplate);
		a.addParameter(ParameterTypes.RestrictedTo, useRestriction);
		return a;
	}

	// ROLE: Standard, Developer, Guest
	public static Action createUser(String useNickname, String usePassword,
			String useRole, boolean isPasswordEncrypted) {
		Action a = new Action(Commands.CreateUser, Categories.Authoring);
		a.addParameter(ParameterTypes.UserName, useNickname);
		a.addParameter(ParameterTypes.Password, usePassword);
		a.addParameter(ParameterTypes.Role, useRole);
		a.addParameter(ParameterTypes.passwordEncrypted, Boolean.toString(isPasswordEncrypted));
		return a;
	}
	
	// ROLE: Standard, Developer, Guest
	public static Action createUser(String useNickname, String usePassword,
			String useRole) {
		Action a = new Action(Commands.CreateUser, Categories.Authoring);
		a.addParameter(ParameterTypes.UserName, useNickname);
		a.addParameter(ParameterTypes.Password, usePassword);
		a.addParameter(ParameterTypes.Role, useRole);
		return a;
	}

	public static Action createUpdateTextElement(String elementId, String mapId,
			String text) {
		Action a = new Action(Commands.UpdateElement, Categories.Map);
		a.addParameter(ParameterTypes.MapId, mapId);
		a.addParameter(ParameterTypes.Id, elementId);
		a.addParameter(ParameterTypes.Text, text);
		return a;
	}

	public static Action createUpdateUrlElement(String elementId, String mapId,
			String newUrl) {
		Action a = new Action(Commands.UpdateElement, Categories.Map);
		a.addParameter(ParameterTypes.MapId, mapId);
		a.addParameter(ParameterTypes.Id, elementId);
		a.addParameter(ParameterTypes.Link, newUrl);
		return a;
	}

	public List<Action> createUpdateMyMicroworld3Object(String mapId, String viewElementId, String viewUrl,
			String textElementId, String text, String referenceUrlElementId, String referenceUrl){
		List<Action> actions = new ArrayList<Action>();
		actions.add(createUpdateUrlElement(viewElementId, mapId, viewUrl));
		actions.add(createUpdateTextElement(textElementId, mapId, text));
		actions.add(createUpdateUrlElement(referenceUrlElementId, mapId, referenceUrl));
		return actions;
	}
	
	public List<Action> createUpdateHelpRequestObject(String mapId, String viewElementId, String viewUrl,
			String textElementId, String text, String referenceUrlElementId, String referenceUrl){
		List<Action> actions = new ArrayList<Action>();
		actions.add(createUpdateUrlElement(viewElementId, mapId, viewUrl));
		actions.add(createUpdateTextElement(textElementId, mapId, text));
		actions.add(createUpdateUrlElement(referenceUrlElementId, mapId, referenceUrl));
		return actions;
	}

}
