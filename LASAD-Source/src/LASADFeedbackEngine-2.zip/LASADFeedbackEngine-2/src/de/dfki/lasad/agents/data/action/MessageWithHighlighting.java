package de.dfki.lasad.agents.data.action;

import de.dfki.lasad.agents.data.analysis.object.AnalyzableEntity;

/**
 * Specifies a set of objects in the end-user environment ( {@link AnalyzableEntity})
 * to be highlighted and an accompanying textual message.
 * 
 * @author Oliver Scheuer
 * 
 */
public class MessageWithHighlighting extends Message {

	private AnalyzableEntity analyzableEntity;

	/**
	 * Highlighting with short text
	 * 
	 * @param textShort
	 * @param analyzableEntity
	 */
	public MessageWithHighlighting(String textShort, AnalyzableEntity analyzableEntity) {
		super(textShort);
		this.analyzableEntity = analyzableEntity;
	}

	/**
	 * Highlighting with short and long text
	 * 
	 * @param textShort
	 * @param textLong
	 * @param analyzableEntity
	 */
	public MessageWithHighlighting(String textShort, String textLong,
			AnalyzableEntity analyzableEntity) {
		super(textShort, textLong);
		this.analyzableEntity = analyzableEntity;
	}

	public AnalyzableEntity getAnalyzableEntity() {
		return analyzableEntity;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((analyzableEntity == null) ? 0 : analyzableEntity.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		MessageWithHighlighting other = (MessageWithHighlighting) obj;
		if (analyzableEntity == null) {
			if (other.analyzableEntity != null)
				return false;
		} else if (!analyzableEntity.equals(other.analyzableEntity))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return super.toString() + ", " + analyzableEntity + "]";
	}
}
