package de.dfki.lasad.agents.logic.provision.phases;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class Phase {

	public static final double NOT_SET = -1;

	String phaseID;
	double probability;

	public Phase(String phaseID, double probability) {
		this.phaseID = phaseID;
		this.probability = probability;
	}

	public String getPhaseID() {
		return phaseID;
	}

	public double getProbability() {
		return probability;
	}

	@Override
	public String toString() {
		return "[" + phaseID + ": " + probability + "]";
	}

}
