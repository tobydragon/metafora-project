package de.dfki.lasad.agents.logic.analysis.types.structure.translator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableSuppl;
import lasad.shared.dfki.meta.agents.analysis.structure.model.LinkVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.NeighborConstrs;
import lasad.shared.dfki.meta.agents.analysis.structure.model.NodeVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PatternPreprocessorNeighbors {

	/**
	 * Processes {@link LinkVariable}s in order to derive neighborhood
	 * relationships between {@link NodeVariable}s
	 */
	public void addNeighborConstrs(StructuralPattern pattern) {
		addNeighborConstrs(pattern.getNodeVars(), pattern.getLinkVars());
		addNeighborConstrs(pattern.getLinkVars(), pattern.getLinkVars());

		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			addNeighborConstrs(notPattern.getNodeVars(),
					notPattern.getLinkVars());
			addNeighborConstrs(notPattern.getLinkVars(),
					notPattern.getLinkVars());
		}
	}

	/**
	 * Initialize neighbor constraints of NodeVariables based on their ordering
	 * and the provided LinkVariables. If both endpoints of a link are
	 * "pattern-external" no neighbors will be added. If both endpoints of a
	 * link are "pattern-internal" a neighbor will be added to the element
	 * variable later in the sequence. If one endpoint is "pattern-internal" and
	 * the other endpoint "pattern-external", a neighbor constraint will be
	 * added to the "pattern-internal" endpoint.
	 * 
	 * 
	 * "Pattern-external" endpoints are assumed to be already processed and thus
	 * "referable"
	 * 
	 * @param elemVars
	 * @param linkVars
	 * @param predecessors
	 */
	public void addNeighborConstrs(List<? extends ElementVariable> elemVars,
			List<LinkVariable> linkVars) {
		// Store position of a node in a given sequence
		Map<String, Integer> elemID2seqNum = new HashMap<String, Integer>();
		for (int i = 0; i < elemVars.size(); i++) {
			ElementVariable elemVar = elemVars.get(i);
			elemID2seqNum.put(elemVar.getVarID(), i);
		}

		// Add link constraint to the node later in the sequence
		// i.e with higher index value
		for (LinkVariable linkVar : linkVars) {
			ElementVariable source = linkVar.getSource();
			ElementVariable target = linkVar.getTarget();

			if (source != null && target != null) {
				// both source and target specified, neighborhood constraints
				// can be added
				Integer sourceSeqNum = elemID2seqNum.get(source.getVarID());
				Integer targetSeqNum = elemID2seqNum.get(target.getVarID());

				if (sourceSeqNum != null || targetSeqNum != null) {
					// at least one "pattern-internal" end-point

					ElementVariable elemToAddNeighbors;
					if (sourceSeqNum != null && targetSeqNum != null) {
						// source and target are "pattern-internal"
						if (sourceSeqNum > targetSeqNum) {
							elemToAddNeighbors = elemVars.get(sourceSeqNum);
						} else {
							elemToAddNeighbors = elemVars.get(targetSeqNum);
						}
					} else if (sourceSeqNum != null) {
						// source is "pattern-internal", target is
						// "pattern-external"
						elemToAddNeighbors = elemVars.get(sourceSeqNum);
					} else {
						// source is "pattern-external", target is
						// "pattern-internal"
						elemToAddNeighbors = elemVars.get(targetSeqNum);
					}

					ElementVariableSuppl supplData = elemToAddNeighbors
							.getSupplData();
					NeighborConstrs neighborConstrs = supplData
							.getNeighborConstrs();

					if (linkVar.getDirectionMatters()) {
						neighborConstrs.getDirectedLinkConstraintsToAdd().add(
								linkVar);
					} else {
						neighborConstrs.getUndirectedLinkConstraintsToAdd()
								.add(linkVar);
					}

				}
			}
		}
	}
}
