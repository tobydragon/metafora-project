package de.dfki.lasad.dataservice.lasad;

import java.util.HashMap;

/**
 * Translates between the feedback types displayed in the GUI and 'technical'
 * IDs used for internal processing.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AnalysisAndFeedbackTypeAdapter {

	private static HashMap<SessionAgentTypeTriple, SessionAgentNameTriple> types2names = new HashMap<SessionAgentTypeTriple, SessionAgentNameTriple>();
	private static HashMap<SessionAgentNameTriple, SessionAgentTypeTriple> names2types = new HashMap<SessionAgentNameTriple, SessionAgentTypeTriple>();

	public static void addMapping(String sessionID, String agentID,
			String serviceID, String serviceName) {
		SessionAgentTypeTriple serviceTypeO = new SessionAgentTypeTriple(
				sessionID, agentID, serviceID);
		SessionAgentNameTriple serviceNameO = new SessionAgentNameTriple(
				sessionID, agentID, serviceName);
		types2names.put(serviceTypeO, serviceNameO);
		names2types.put(serviceNameO, serviceTypeO);
	}

	public static String getServiceTypeID(String sessionID, String agentID,
			String serviceName) {
		SessionAgentNameTriple serviceNameO = new SessionAgentNameTriple(
				sessionID, agentID, serviceName);
		SessionAgentTypeTriple serviceTypeO = names2types.get(serviceNameO);
		if (serviceTypeO != null) {
			return serviceTypeO.typeID;
		}
		return null;
	}

	public static String getServiceName(String sessionID, String agentID,
			String serviceID) {
		SessionAgentTypeTriple serviceTypeO = new SessionAgentTypeTriple(
				sessionID, agentID, serviceID);
		SessionAgentNameTriple servieNameO = types2names.get(serviceTypeO);
		if (servieNameO != null) {
			return servieNameO.serviceName;
		}
		return null;
	}

	private static class SessionAgentTypeTriple {
		String sessionID;
		String agentID;
		String typeID;

		public SessionAgentTypeTriple(String sessionID, String agentID,
				String typeID) {
			this.sessionID = sessionID;
			this.agentID = agentID;
			this.typeID = typeID;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result
					+ ((agentID == null) ? 0 : agentID.hashCode());
			result = prime * result
					+ ((sessionID == null) ? 0 : sessionID.hashCode());
			result = prime * result
					+ ((typeID == null) ? 0 : typeID.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			SessionAgentTypeTriple other = (SessionAgentTypeTriple) obj;
			if (agentID == null) {
				if (other.agentID != null)
					return false;
			} else if (!agentID.equals(other.agentID))
				return false;
			if (sessionID == null) {
				if (other.sessionID != null)
					return false;
			} else if (!sessionID.equals(other.sessionID))
				return false;
			if (typeID == null) {
				if (other.typeID != null)
					return false;
			} else if (!typeID.equals(other.typeID))
				return false;
			return true;
		}

	}

	private static class SessionAgentNameTriple {
		String sessionID;
		String agentID;
		String serviceName;

		public SessionAgentNameTriple(String sessionID, String agentID,
				String serviceName) {
			this.sessionID = sessionID;
			this.agentID = agentID;
			this.serviceName = serviceName;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result
					+ ((agentID == null) ? 0 : agentID.hashCode());
			result = prime * result
					+ ((serviceName == null) ? 0 : serviceName.hashCode());
			result = prime * result
					+ ((sessionID == null) ? 0 : sessionID.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			SessionAgentNameTriple other = (SessionAgentNameTriple) obj;
			if (agentID == null) {
				if (other.agentID != null)
					return false;
			} else if (!agentID.equals(other.agentID))
				return false;
			if (serviceName == null) {
				if (other.serviceName != null)
					return false;
			} else if (!serviceName.equals(other.serviceName))
				return false;
			if (sessionID == null) {
				if (other.sessionID != null)
					return false;
			} else if (!sessionID.equals(other.sessionID))
				return false;
			return true;
		}

	}
}
