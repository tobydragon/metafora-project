package de.dfki.lasad.authoring.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.jdom.Element;

import de.dfki.lasad.util.XMLUtil;

/**
 * a list of agent-to-ontology assignments (to be used in the graphical
 * frontend).
 * 
 * @author oliverscheuer
 * 
 */
public class Agents2OntologiesFE {

	private Map<String, List<String>> ontologyID2agentIDs = new HashMap<String, List<String>>();

	public void addMapping(String aID, String oID) {
		List<String> agents = ontologyID2agentIDs.get(oID);
		if (agents == null) {
			agents = new Vector<String>();
			ontologyID2agentIDs.put(oID, agents);
		}
		agents.add(aID);
	}

	public Element toXMLElem() {

		Set<String> ontogyList = ontologyID2agentIDs.keySet();

		Element descrsElem = new Element(ElementStrings.AGENTS_TO_ONTOLOGIES);

		for (String ontology : ontogyList) {
			Element ont = new Element(ElementStrings.ONTOLOGY);
			ont.setAttribute(ElementStrings.NAME, ontology);

			List<String> agentList = ontologyID2agentIDs.get(ontology);
			for (String agent : agentList) {
				Element ag = new Element(ElementStrings.AGENT);
				ag.setText(agent);
				ont.addContent(ag);
			}
			descrsElem.addContent(ont);
		}

		return descrsElem;
	}

	public static Agents2OntologiesFE fromXMLElem(Element xml) {
		Agents2OntologiesFE agent2OntosFE = new Agents2OntologiesFE();

		List<Element> ontologyElemList = (List<Element>) xml
				.getChildren(ElementStrings.ONTOLOGY);
		for (Element ontology : ontologyElemList) {
			String ontoName = ontology.getAttribute(ElementStrings.NAME)
					.getValue();
			List<Element> agentElemList = (List<Element>) ontology
					.getChildren(ElementStrings.AGENT);

			for (Element agent : agentElemList) {
				String agentName = agent.getText();
				agent2OntosFE.addAgents2Ontology(ontoName, agentName);
			}

		}

		return agent2OntosFE;
	}

	/*
	 * Adds the agent to ontology
	 */
	public void addAgents2Ontology(String ontology, String agent) {
		List<String> agentListTmp = ontologyID2agentIDs.get(ontology);
		if (agentListTmp == null) {
			agentListTmp = new Vector<String>();
			ontologyID2agentIDs.put(ontology, agentListTmp);
		}
		agentListTmp.add(agent);
	}

	public String toXMLString() {
		Element e = toXMLElem();
		return XMLUtil.xmlElem2docString(e);
	}

	public static Agents2OntologiesFE fromXMLString(String xml) {
		Element e = XMLUtil.string2xmlElem(xml);
		return fromXMLElem(e);
	}

	@Override
	public String toString() {
		return "Agents2OntologiesFE [ontologyID2agentIDs="
				+ ontologyID2agentIDs + "]";
	}

}
