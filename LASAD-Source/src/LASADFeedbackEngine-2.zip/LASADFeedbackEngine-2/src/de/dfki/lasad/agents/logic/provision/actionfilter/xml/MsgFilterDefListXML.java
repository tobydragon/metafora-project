package de.dfki.lasad.agents.logic.provision.actionfilter.xml;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.provision.priority.MsgFilterDef;
import lasad.shared.dfki.meta.agents.provision.priority.MsgFilterDef_DiscardAllButOneInstancePerType;
import lasad.shared.dfki.meta.agents.provision.priority.MsgFilterDef_DiscardInstancesAlreadyPointedTo;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgFilterDefListXML {

	private static Log logger = LogFactory.getLog(MsgFilterDefListXML.class);

	public static final String ELEMENT_NAME = "message-filters";

	public static final String FILTER_ONE_INST_PER_TYPE = "discard-all-but-one-instance-per-type";
	public static final String FILTER_ONLY_NEW_INSTANCES = "discard-instance-already-pointed-to";

	public static List<MsgFilterDef> fromXML(Element filtersElem) {
		List<MsgFilterDef> filterDefs = new Vector<MsgFilterDef>();
		for (Element filterElem : (List<Element>) filtersElem
				.getChildren("message-filter")) {

			String type = filterElem.getAttributeValue("type");
			if (FILTER_ONE_INST_PER_TYPE.equalsIgnoreCase(type)) {
				MsgFilterDef filterDef = new MsgFilterDef_DiscardAllButOneInstancePerType();
				filterDefs.add(filterDef);
			} else if (FILTER_ONLY_NEW_INSTANCES.equalsIgnoreCase(type)) {
				MsgFilterDef filterDef = new MsgFilterDef_DiscardInstancesAlreadyPointedTo();
				filterDefs.add(filterDef);
			} else {
				logger.error("(fromXML) Unhandled filter type: " + type);
				return null;
			}
		}
		return filterDefs;
	}

	public static Element toXML(List<MsgFilterDef> filterDefs) {
		Element filtersElem = new Element(ELEMENT_NAME);
		for (MsgFilterDef filterDef : filterDefs) {
			Element filterElem = new Element("message-filter");
			filtersElem.addContent(filterElem);
			if (filterDef instanceof MsgFilterDef_DiscardAllButOneInstancePerType) {
				filterElem.setAttribute("type", FILTER_ONE_INST_PER_TYPE);

			} else if (filterDef instanceof MsgFilterDef_DiscardInstancesAlreadyPointedTo) {
				filterElem.setAttribute("type", FILTER_ONLY_NEW_INSTANCES);
			} else {
				logger.error("(toXML) Unhandled filter type: " + filterDef);
				return null;
			}

		}
		return filtersElem;
	}
}
