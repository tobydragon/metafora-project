package de.dfki.lasad.events.agents;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.EventCallback;

/**
 * Request {@link AnalysisResult}s for a given set of {@link AnalysisType}s.
 * Feedback-Engine internal communication.
 * 
 * @author oliverscheuer
 * 
 */
public class AnalysisRequestEvent extends EventImpl {

	private Set<AnalysisType> analysisTypes = new HashSet<AnalysisType>();

	private UUID transactionID = UUID.randomUUID();

	private EventCallback callback = null;

	public AnalysisRequestEvent(String srcCompId) {
		super(srcCompId);
	}

	public Set<AnalysisType> getAnalysisTypes() {
		return analysisTypes;
	}

	public void setAnalysisTypes(Set<AnalysisType> analysisTypes) {
		this.analysisTypes = analysisTypes;
	}

	public void addAnalysisType(AnalysisType analysisType) {
		analysisTypes.add(analysisType);
	}

	public UUID getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(UUID transactionID) {
		this.transactionID = transactionID;
	}

	public EventCallback getCallback() {
		return callback;
	}

	public void setCallback(EventCallback callback) {
		this.callback = callback;
	}

}
