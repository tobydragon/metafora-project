package de.dfki.lasad.authoring.model.pattern;

/**
 * Comparison of a string variable to some constant string value.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class String2ConstStringComparison extends Comparison {
	private String2StringOperator operator;
	private String rightExpr;

	public String2StringOperator getOperator() {
		return operator;
	}

	public void setOperator(String2StringOperator operator) {
		this.operator = operator;
	}

	public String getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(String rightExpr) {
		this.rightExpr = rightExpr;
	}

}
