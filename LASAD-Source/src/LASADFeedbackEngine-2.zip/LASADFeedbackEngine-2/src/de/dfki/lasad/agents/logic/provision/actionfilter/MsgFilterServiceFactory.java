package de.dfki.lasad.agents.logic.provision.actionfilter;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.provision.priority.MsgFilterDef;
import lasad.shared.dfki.meta.agents.provision.priority.MsgFilterDef_DiscardAllButOneInstancePerType;
import lasad.shared.dfki.meta.agents.provision.priority.MsgFilterDef_DiscardInstancesAlreadyPointedTo;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.provision.actionhistory.MsgProvisionHistory;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgFilterServiceFactory {

	private static Log logger = LogFactory
			.getLog(MsgFilterServiceFactory.class);

	public static MsgFilterServiceInterface createMsgFilterService(UserID referenceUser,
			MsgProvisionHistory msgHistoryRef, List<MsgFilterDef> msgFilterDefs) {

		List<MsgFilter> msgFilters = new Vector<MsgFilter>();
		List<MsgListFilter> msgListFilters = new Vector<MsgListFilter>();

		for (MsgFilterDef msgFilterDef : msgFilterDefs) {

			if (msgFilterDef instanceof MsgFilterDef_DiscardAllButOneInstancePerType) {
				MsgListFilter_DiscardAllButOneInstancePerType filter = new MsgListFilter_DiscardAllButOneInstancePerType();
				msgListFilters.add(filter);
			} else if (msgFilterDef instanceof MsgFilterDef_DiscardInstancesAlreadyPointedTo) {
				MsgFilter_DiscardInstancesAlreadyPointedTo filter = new MsgFilter_DiscardInstancesAlreadyPointedTo(
						referenceUser, msgHistoryRef);
				msgFilters.add(filter);
			} else {
				logger.error("Unhandled message filter type: " + msgFilterDef);
				return null;
			}
		}

		MsgFilterService msgFilterService = new MsgFilterService(referenceUser,
				msgFilters, msgListFilters);
		return msgFilterService;

	}

}
