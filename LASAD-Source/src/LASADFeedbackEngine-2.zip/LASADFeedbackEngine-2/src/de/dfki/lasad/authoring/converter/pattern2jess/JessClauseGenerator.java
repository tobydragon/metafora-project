package de.dfki.lasad.authoring.converter.pattern2jess;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import de.dfki.lasad.authoring.model.pattern.Comparison;
import de.dfki.lasad.authoring.model.pattern.ElementConstr;
import de.dfki.lasad.authoring.model.pattern.ElementVariable;
import de.dfki.lasad.authoring.model.pattern.LinkConstr;
import de.dfki.lasad.authoring.model.pattern.NodeConstr;
import de.dfki.lasad.authoring.model.pattern.Pattern;
import de.dfki.lasad.authoring.model.pattern.PropertyVariable;
import de.dfki.lasad.authoring.model.pattern.VariableComparison;
import de.dfki.lasad.session.data.meta.ontology.NonStandardPropDescr;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * Generates Jess clauses to match nodes, links or node / link properties. The
 * generation of these clauses is based on a pre-classification of
 * {@link Comparison}s in 20 different {@link Bin}s each of which leading to a
 * different Jess expression. Details, see external documentation.
 * 
 * @author oliverscheuer
 * 
 */
public class JessClauseGenerator {

	JessFactGenerator fGen = new JessFactGenerator();
	JessQuantifierGenerator qGen = new JessQuantifierGenerator();

	static final int NO_VAR_APPENDIX = -1;
	static final boolean TEMP_ELEM_VAR = true;
	static final boolean TEMP_VAR_LEFT = true;
	static final boolean TEMP_VAR_RIGHT = true;

	static final Map<PropertyVariable, List<Comparison>> NO_PROP_SLOTS = new HashMap<PropertyVariable, List<Comparison>>();

	// BIN 1 - Part A
	public String generateNodeExtConstrsClause(NodeConstr nodeConstr,
			List<? extends ElementConstr> predecessors) {
		String result = fGen.generateNodeFact(nodeConstr, predecessors,
				ComparisonType.EXTERNAL, Bin.BIN_1);
		return result + "\n";
	}

	public String generateLinkExtConstrsClause(LinkConstr linkConstr,
			List<? extends ElementConstr> predecessors) {
		String result = fGen.generateLinkFact(linkConstr, predecessors,
				ComparisonType.EXTERNAL, Bin.BIN_1);
		return result + "\n";
	}

	// Prop Bindings needed in Comparisons of later ElemConstrs
	public String generatePropVarBindingClauses(ElementConstr elemConstr) {
		ElementVariable elemVar = elemConstr.getElemVar();
		List<PropDescr> props = elemConstr.getPropsUsedAsRefVal();
		StringBuffer buf = new StringBuffer();
		for (PropDescr prop : props) {
			if (prop instanceof NonStandardPropDescr
					&& ((NonStandardPropDescr) prop).getMaxCardinality() <= 1) {
				List<String> componentIDs = elemConstr
						.getPropComponentsUsedAsRefVal(prop);
				Map<PropertyVariable, List<Comparison>> propVars2Comparisons = new HashMap<PropertyVariable, List<Comparison>>();
				for (String compID : componentIDs) {
					PropertyVariable propVar = elemVar.getPropVar(prop, compID);
					List<Comparison> noComparisons = new Vector<Comparison>();
					propVars2Comparisons.put(propVar, noComparisons);
				}
				String propFact = fGen.generatePropFact(elemVar, prop,
						propVars2Comparisons, Bin.ALL_BINS, NO_VAR_APPENDIX,
						false, false, false);
				buf.append(propFact);
				buf.append("\n");
			}
		}
		return buf.toString();
	}

	// BIN 1 - Part B
	public String generateNodeIntConstrsClause(NodeConstr nodeConstr) {
		List<NodeConstr> NO_PREDECESSORS = new Vector<NodeConstr>();
		String result = fGen.generateNodeFact(nodeConstr, NO_PREDECESSORS,
				ComparisonType.INTERNAL, Bin.BIN_1);
		return result + "\n";
	}

	public String generateLinkIntConstrsClause(LinkConstr linkConstr) {
		List<LinkConstr> NO_PREDECESSORS = new Vector<LinkConstr>();
		String result = fGen.generateLinkFact(linkConstr, NO_PREDECESSORS,
				ComparisonType.INTERNAL, Bin.BIN_1);
		return result + "\n";
	}

	// BIN 2
	public String generatePropClauses(ElementConstr elemConstr, PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		ElementVariable elemVar = elemConstr.getElemVar();
		List<String> compIDs = prop.getComponentIDs();
		Map<PropertyVariable, List<Comparison>> propVar2Comparisons = new HashMap<PropertyVariable, List<Comparison>>();
		for (String compID : compIDs) {
			PropertyVariable propVar = elemVar.getPropVar(prop, compID);
			List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_2,
					propVar);
			if (!comparisons.isEmpty()) {
				propVar2Comparisons.put(propVar, comparisons);
			}
		}
		if (!propVar2Comparisons.isEmpty()) {
			String propFact = fGen.generatePropFact(elemVar, prop,
					propVar2Comparisons, Bin.BIN_2, NO_VAR_APPENDIX, false,
					false, false);
			buf.append(propFact);
		}
		return getString(buf, Bin.BIN_2);

	}

	// BIN 3
	public String generatePropExistsClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_3,
				prop);
		for (Comparison comparison : comparisons) {
			String propFactExpr = fGen.generatePropFact(comparison, Bin.BIN_3,
					comparison.getId(), false, TEMP_VAR_LEFT, false);

			String propExistsClause = qGen.generateExistsConstr(propFactExpr);
			buf.append(propExistsClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_3);
	}

	// BIN 4
	public String generatePropForallClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		ElementVariable elemVar = elemConstr.getElemVar();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_4,
				prop);
		for (Comparison comparison : comparisons) {
			String propFactMatchExpr = fGen.generatePropFact(elemVar, prop,
					NO_PROP_SLOTS, Bin.BIN_4, comparison.getId(),
					TEMP_ELEM_VAR, false, false);
			String propFactConstrExpr = fGen.generatePropFact(comparison,
					Bin.BIN_4, comparison.getId(), false, TEMP_VAR_LEFT, false);

			String propForallClause = qGen.generateForallConstr(
					propFactMatchExpr, propFactConstrExpr);
			buf.append(propForallClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_4);
	}

	// BIN 5
	public String generateRefPropExistsClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_5,
				prop);
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);
			String propFactExpr = fGen.generatePropFact(inv.comparison,
					Bin.BIN_5, comparison.getId(), false, TEMP_VAR_LEFT, false);

			String propExistsClause = qGen.generateExistsConstr(propFactExpr);
			buf.append(propExistsClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_5);
	}

	// BIN 6
	public String generateRefPropForallClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_6,
				prop);
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);
			String propFactMatchExpr = fGen.generatePropFact(inv.elemVar,
					inv.prop, NO_PROP_SLOTS, Bin.BIN_6, comparison.getId(),
					TEMP_ELEM_VAR, false, false);
			String propFactConstrExpr = fGen.generatePropFact(inv.comparison,
					Bin.BIN_6, comparison.getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, false);

			String propForallClause = qGen.generateForallConstr(
					propFactMatchExpr, propFactConstrExpr);
			buf.append(propForallClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_6);
	}

	// BIN 7
	public String generatePropExistsForallClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_7,
				prop);
		for (Comparison comparison : comparisons) {

			Map<PropertyVariable, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(comparison
					.getLeftExpr());
			String existsFactExpr = fGen.generatePropFact(
					elemConstr.getElemVar(), prop, propVarWithoutComparisons,
					Bin.BIN_7, comparison.getId(), false, TEMP_VAR_LEFT, false);

			InverseCompRecord inv = new InverseCompRecord(comparison);
			String forallFactMatchExpr = fGen.generatePropFact(inv.elemVar,
					inv.prop, NO_PROP_SLOTS, Bin.BIN_7, comparison.getId(),
					TEMP_ELEM_VAR, false, false);
			String forallFactConstrExpr = fGen.generatePropFact(inv.comparison,
					Bin.BIN_7, comparison.getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);

			String propExistsForallClause = qGen.generateExistsForallConstr(
					existsFactExpr, forallFactMatchExpr, forallFactConstrExpr);
			buf.append(propExistsForallClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_7);
	}

	// BIN 8
	public String generatePropExistsExistsClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_8,
				prop);
		for (Comparison comparison : comparisons) {
			Map<PropertyVariable, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(comparison
					.getLeftExpr());
			String existsFactExpr1 = fGen.generatePropFact(
					elemConstr.getElemVar(), prop, propVarWithoutComparisons,
					Bin.BIN_8, comparison.getId(), false, TEMP_VAR_LEFT, false);

			InverseCompRecord inv = new InverseCompRecord(comparison);
			String existsFactExpr2 = fGen.generatePropFact(inv.comparison,
					Bin.BIN_8, comparison.getId(), false, TEMP_VAR_LEFT,
					TEMP_VAR_RIGHT);

			String propExistsExistsClause = qGen.generateExistsExistsConstr(
					existsFactExpr1, existsFactExpr2);
			buf.append(propExistsExistsClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_8);
	}

	// BIN 9
	public String generatePropForallForallClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_9,
				prop);
		for (Comparison comparison : comparisons) {
			Map<PropertyVariable, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(comparison
					.getLeftExpr());
			String propFactMatchExprVarBinding1 = fGen.generatePropFact(
					elemConstr.getElemVar(), prop, propVarWithoutComparisons,
					Bin.BIN_9, comparison.getId(), false, TEMP_VAR_LEFT, false);

			InverseCompRecord inv = new InverseCompRecord(comparison);
			String propFactMatchExpr2 = fGen.generatePropFact(inv.elemVar,
					inv.prop, NO_PROP_SLOTS, Bin.BIN_9, comparison.getId(),
					TEMP_ELEM_VAR, false, false);
			String propFactConstrExpr2 = fGen.generatePropFact(inv.comparison,
					Bin.BIN_9, comparison.getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);

			String propForallForallClause = qGen.generateForallForallConstr(
					propFactMatchExprVarBinding1, propFactMatchExpr2,
					propFactConstrExpr2);
			buf.append(propForallForallClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_9);
	}

	// BIN 10
	public String generatePropForallExistsClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_10,
				prop);
		for (Comparison comparison : comparisons) {
			Map<PropertyVariable, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(comparison
					.getLeftExpr());
			String propFactMatchExprVarBinding = fGen
					.generatePropFact(elemConstr.getElemVar(), prop,
							propVarWithoutComparisons, Bin.BIN_10,
							comparison.getId(), false, TEMP_VAR_LEFT, false);

			InverseCompRecord inv = new InverseCompRecord(comparison);
			String existsFactExpr = fGen.generatePropFact(inv.comparison,
					Bin.BIN_10, comparison.getId(), false, TEMP_VAR_LEFT,
					TEMP_VAR_RIGHT);

			String propForallExistsClause = qGen.generateForallExistsConstr(
					propFactMatchExprVarBinding, existsFactExpr);
			buf.append(propForallExistsClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_10);
	}

	// BIN 11
	public String generateRefPropExistsForallClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_11,
				prop);
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);
			Map<PropertyVariable, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(inv.comparison
					.getLeftExpr());
			String existsFactExpr = fGen.generatePropFact(inv.elemVar,
					inv.prop, propVarWithoutComparisons, Bin.BIN_11,
					comparison.getId(), false, TEMP_VAR_LEFT, false);

			String forallFactMatchExpr = fGen.generatePropFact(
					elemConstr.getElemVar(), prop, NO_PROP_SLOTS, Bin.BIN_11,
					comparison.getId(), TEMP_ELEM_VAR, false, false);
			String forallFactConstrExpr = fGen.generatePropFact(comparison,
					Bin.BIN_11, comparison.getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);

			String propExistsForallClause = qGen.generateExistsForallConstr(
					existsFactExpr, forallFactMatchExpr, forallFactConstrExpr);
			buf.append(propExistsForallClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_11);
	}

	// BIN 12
	public String generateRefPropForallExistsClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_12,
				prop);
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);
			Map<PropertyVariable, List<Comparison>> propVarWithoutComparisons = getMapPropVarWithoutComparisons(inv.comparison
					.getLeftExpr());
			String propFactMatchExprVarBinding = fGen
					.generatePropFact(inv.elemVar, inv.prop,
							propVarWithoutComparisons, Bin.BIN_12,
							comparison.getId(), false, TEMP_VAR_LEFT, false);

			String existsFactExpr = fGen.generatePropFact(comparison,
					Bin.BIN_12, comparison.getId(), false, TEMP_VAR_LEFT,
					TEMP_VAR_RIGHT);

			String propForallExistsClause = qGen.generateForallExistsConstr(
					propFactMatchExprVarBinding, existsFactExpr);
			buf.append(propForallExistsClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_12);
	}

	// BIN 13
	public String generateElemExistsForallClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_13,
				prop);
		for (Comparison comparison : comparisons) {
			String existsFactExpr;
			if (elemConstr instanceof NodeConstr) {
				existsFactExpr = fGen.generateNodeFactBindListElem(comparison);
			} else {
				// LinkConstr
				existsFactExpr = fGen.generateLinkFactBindListElem(comparison);
			}
			InverseCompRecord inv = new InverseCompRecord(comparison);
			String forallFactMatchExpr = fGen.generatePropFact(inv.elemVar,
					inv.prop, NO_PROP_SLOTS, Bin.BIN_13, comparison.getId(),
					TEMP_ELEM_VAR, false, false);
			String forallFactConstrExpr = fGen.generatePropFact(inv.comparison,
					Bin.BIN_13, comparison.getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);

			String propExistsForall = qGen.generateExistsForallConstr(
					existsFactExpr, forallFactMatchExpr, forallFactConstrExpr);
			buf.append(propExistsForall);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_13);
	}

	// BIN 14
	public String generateElemExistsExistsClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_14,
				prop);
		for (Comparison comparison : comparisons) {
			String existsFactExpr1;
			if (elemConstr instanceof NodeConstr) {
				existsFactExpr1 = fGen.generateNodeFactBindListElem(comparison);
			} else {
				// LinkConstr
				existsFactExpr1 = fGen.generateLinkFactBindListElem(comparison);
			}

			InverseCompRecord inv = new InverseCompRecord(comparison);
			String existsFactExpr2 = fGen.generatePropFact(inv.comparison,
					Bin.BIN_14, comparison.getId(), false, TEMP_VAR_LEFT,
					TEMP_VAR_RIGHT);

			String propExistsExistsClause = qGen.generateExistsExistsConstr(
					existsFactExpr1, existsFactExpr2);
			buf.append(propExistsExistsClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_14);
	}

	// BIN 15
	public String generateElemForallForallClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_15,
				prop);
		for (Comparison comparison : comparisons) {
			String propFactMatchExprVarBinding1;
			if (elemConstr instanceof NodeConstr) {
				propFactMatchExprVarBinding1 = fGen
						.generateNodeFactBindListElem(comparison);
			} else {
				// LinkConstr
				propFactMatchExprVarBinding1 = fGen
						.generateLinkFactBindListElem(comparison);
			}

			InverseCompRecord inv = new InverseCompRecord(comparison);
			String propFactMatchExpr2 = fGen.generatePropFact(inv.elemVar,
					inv.prop, NO_PROP_SLOTS, Bin.BIN_15, comparison.getId(),
					TEMP_ELEM_VAR, false, false);
			String propFactConstrExpr2 = fGen.generatePropFact(inv.comparison,
					Bin.BIN_15, comparison.getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);

			String propForallForallClause = qGen.generateForallForallConstr(
					propFactMatchExprVarBinding1, propFactMatchExpr2,
					propFactConstrExpr2);
			buf.append(propForallForallClause);
			buf.append("\n");

		}
		return getString(buf, Bin.BIN_15);
	}

	// BIN 16
	public String generateElemForallExistsClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_16,
				prop);
		for (Comparison comparison : comparisons) {
			String propFactMatchExprVarBinding;
			if (elemConstr instanceof NodeConstr) {
				propFactMatchExprVarBinding = fGen
						.generateNodeFactBindListElem(comparison);
			} else {
				// LinkConstr
				propFactMatchExprVarBinding = fGen
						.generateLinkFactBindListElem(comparison);
			}

			InverseCompRecord inv = new InverseCompRecord(comparison);
			String existsFactExpr = fGen.generatePropFact(inv.comparison,
					Bin.BIN_16, comparison.getId(), false, TEMP_VAR_LEFT,
					TEMP_VAR_RIGHT);

			String propForallExistsClause = qGen.generateForallExistsConstr(
					propFactMatchExprVarBinding, existsFactExpr);
			buf.append(propForallExistsClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_16);
	}

	// BIN 17
	public String generateRefElemExistsForallClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_17,
				prop);
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);
			String existsFactExpr;

			if (elemConstr instanceof NodeConstr) {
				existsFactExpr = fGen
						.generateNodeFactBindListElem(inv.comparison);
			} else {
				// LinkConstr
				existsFactExpr = fGen
						.generateLinkFactBindListElem(inv.comparison);
			}

			String forallFactMatchExpr = fGen.generatePropFact(
					elemConstr.getElemVar(), prop, NO_PROP_SLOTS, Bin.BIN_17,
					comparison.getId(), TEMP_ELEM_VAR, false, false);
			String forallFactConstrExpr = fGen.generatePropFact(comparison,
					Bin.BIN_17, comparison.getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);

			String propExistsForallClause = qGen.generateExistsForallConstr(
					existsFactExpr, forallFactMatchExpr, forallFactConstrExpr);
			buf.append(propExistsForallClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_17);
	}

	// BIN 18
	public String generateRefElemForallExistsClauses(ElementConstr elemConstr,
			PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_18,
				prop);
		for (Comparison comparison : comparisons) {
			InverseCompRecord inv = new InverseCompRecord(comparison);
			String propFactMatchExprVarBinding;
			if (elemConstr instanceof NodeConstr) {
				propFactMatchExprVarBinding = fGen
						.generateNodeFactBindListElem(inv.comparison);
			} else {
				// LinkConstr
				propFactMatchExprVarBinding = fGen
						.generateLinkFactBindListElem(inv.comparison);
			}

			String existsFactExpr = fGen.generatePropFact(comparison,
					Bin.BIN_18, comparison.getId(), false, TEMP_VAR_LEFT,
					TEMP_VAR_RIGHT);

			String propForallExistsClause = qGen.generateForallExistsConstr(
					propFactMatchExprVarBinding, existsFactExpr);
			buf.append(propForallExistsClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_18);
	}

	// BIN 19
	public String generateRefConstForallExistsClauses(Pattern pattern,
			ElementConstr elemConstr, PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_19,
				prop);
		for (Comparison comparison : comparisons) {
			String nodeFactMatchExprVarBinding = fGen.generateConstFact(
					pattern.getID(), comparison.getId());

			String existsFactExpr = fGen.generatePropFact(comparison,
					Bin.BIN_19, comparison.getId(), false, TEMP_VAR_LEFT,
					TEMP_VAR_RIGHT);

			String propForallExistsClause = qGen.generateForallExistsConstr(
					nodeFactMatchExprVarBinding, existsFactExpr);
			buf.append(propForallExistsClause);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_19);
	}

	// BIN 20
	public String generateRefConstExistsForallClauses(Pattern pattern,
			ElementConstr elemConstr, PropDescr prop) {
		StringBuffer buf = new StringBuffer();
		List<Comparison> comparisons = elemConstr.getComparisons(Bin.BIN_20,
				prop);
		for (Comparison comparison : comparisons) {
			String existsFactExpr = fGen.generateConstFact(pattern.getID(),
					comparison.getId());

			String forallFactMatchExpr = fGen.generatePropFact(
					elemConstr.getElemVar(), prop, NO_PROP_SLOTS, Bin.BIN_20,
					comparison.getId(), TEMP_ELEM_VAR, false, false);
			String forallFactConstrExpr = fGen.generatePropFact(comparison,
					Bin.BIN_20, comparison.getId(), TEMP_ELEM_VAR,
					TEMP_VAR_LEFT, TEMP_VAR_RIGHT);

			String propExistsForall = qGen.generateExistsForallConstr(
					existsFactExpr, forallFactMatchExpr, forallFactConstrExpr);
			buf.append(propExistsForall);
			buf.append("\n");
		}
		return getString(buf, Bin.BIN_20);
	}

	private Map<PropertyVariable, List<Comparison>> getMapPropVarWithoutComparisons(
			PropertyVariable propVar) {
		Map<PropertyVariable, List<Comparison>> propVarWithoutComparisons = new HashMap<PropertyVariable, List<Comparison>>();
		List<Comparison> noComparisons = new Vector<Comparison>();
		propVarWithoutComparisons.put(propVar, noComparisons);
		return propVarWithoutComparisons;
	}

	private class InverseCompRecord {

		VariableComparison comparison;
		ElementVariable elemVar;
		PropertyVariable propVar;
		PropDescr prop;

		public InverseCompRecord(Comparison comparison) {
			VariableComparison varComp = (VariableComparison) comparison;
			comparison = varComp.getInverse();
			propVar = comparison.getLeftExpr();
			prop = propVar.getProp();
			elemVar = propVar.getElementVar();
		}
	}

	private String getString(StringBuffer buf, Bin binID) {
		if (buf.length() > 0) {
			String preface = ";; BIN-" + binID + "\n";
			return preface + buf.toString();
		}
		return buf.toString();
	}
}
