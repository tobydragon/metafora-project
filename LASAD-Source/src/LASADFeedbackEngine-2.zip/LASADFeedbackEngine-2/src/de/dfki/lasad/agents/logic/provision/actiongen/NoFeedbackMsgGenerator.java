package de.dfki.lasad.agents.logic.provision.actiongen;

import de.dfki.lasad.agents.data.action.AgentAction;
import de.dfki.lasad.agents.data.action.Message;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class NoFeedbackMsgGenerator {

	private String parentCmpID = null;
	private SessionID sID = null;

	public NoFeedbackMsgGenerator(String parentCmpID, SessionID sID) {
		this.parentCmpID = parentCmpID;
		this.sID = sID;
	}

	public ActionSpecEvent generateMsgEvent(UserID recipientID) {
		ActionSpecEvent actionSpecEvent = new ActionSpecEvent(sID, parentCmpID);
		AgentAction componentSpec = new AgentAction();
		componentSpec.setActionRecipient(recipientID);
		String messageString = "No feedback available";
		Message message = new Message(messageString);
		componentSpec.addActionComponent(message);
		actionSpecEvent.addActionSpec(componentSpec);
		// agent.sendActionsOut(incompleteSpecEvent);
		return actionSpecEvent;
	}
}
