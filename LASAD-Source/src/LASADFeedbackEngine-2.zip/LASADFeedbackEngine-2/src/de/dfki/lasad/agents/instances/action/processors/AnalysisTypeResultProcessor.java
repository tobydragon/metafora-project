package de.dfki.lasad.agents.instances.action.processors;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AnalysisTypeResultProcessor {

	private static Log logger = LogFactory
			.getLog(AnalysisTypeResultProcessor.class);

	private AnalysisType analysisType = null;

	private List<ActionTypeResultProcessor> listeners = new Vector<ActionTypeResultProcessor>();

	private Map<Integer, AnalysisResult> analysisResults = new HashMap<Integer, AnalysisResult>();

	private String debugID = null;
	private String debugPrefix = null;

	public AnalysisTypeResultProcessor(AnalysisType analysisType) {
		this.analysisType = analysisType;

		debugID = "(" + analysisType.getServiceID().getTypeID() + ")";
		debugPrefix = debugID + " - ";
	}

	public String getDebugID() {
		return debugID;
	}

	public void addResultListenerAndUpdate(ActionTypeResultProcessor listener) {
		listeners.add(listener);
		replayResults(listener);
	}

	public void onResultChanged(AnalysisResult resultData, boolean doRemove) {
		logger.debug(debugPrefix + (doRemove ? "REMOVED - " : "ADDED - ")
				+ resultData.toSimpleString());
		updateInternalRecord(resultData, doRemove);
		for (ActionTypeResultProcessor listener : listeners) {
			listener.onResultChanged(resultData, doRemove);
		}
		logModeledResults();
	}

	private void updateInternalRecord(AnalysisResult resultData,
			boolean doRemove) {
		int id = resultData.getId();

		if (doRemove) {
			analysisResults.remove(id);
		} else {
			analysisResults.put(id, resultData);
		}
	}

	private void replayResults(ActionTypeResultProcessor newActionProcessor) {
		for (AnalysisResult result : analysisResults.values()) {
			newActionProcessor.onResultChanged(result, false);
		}
	}

	private void logModeledResults() {
		logger.debug(debugPrefix + "Modeled results:");
		for (Integer resultID : analysisResults.keySet()) {
			AnalysisResult result = analysisResults.get(resultID);
			logger.debug("... " + debugPrefix + result.toSimpleString());
		}
	}
}
