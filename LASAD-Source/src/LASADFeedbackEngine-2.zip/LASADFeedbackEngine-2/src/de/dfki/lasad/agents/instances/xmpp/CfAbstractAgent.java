package de.dfki.lasad.agents.instances.xmpp;

import java.util.Date;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.AbstractAgent;
import de.dfki.lasad.agents.data.action.XmppActionComponent;
import de.dfki.lasad.agents.data.action.XmppActionSpec;
import de.dfki.lasad.agents.instances.xmpp.xmppaction.CfActionDuringExecution;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.uds.cfcommunication.CfMultiSessionCommunicationManager;
import de.uds.cfcommunication.CommunicationChannelType;
import de.uds.cfcommunication.CommunicationMethodType;
import de.uds.commonformat.CfAction;

public abstract class CfAbstractAgent extends AbstractAgent implements CfAgentInterface{
	
	Log logger = LogFactory.getLog(CfAbstractAgent.class);

	CfMultiSessionCommunicationManager communicationManager;
	Vector<CfActionDuringExecution> actionsWaitingForResponse;
	
	//Standard call to create xmppAgent
	public CfAbstractAgent(){
		this(true);
		logger.info("XmppActionAgent created at" + new Date());
	}
	
	//special constructor to allow for disabled xmpp agent for testing
	CfAbstractAgent(boolean connectToSource){		
		communicationManager = CfMultiSessionCommunicationManager.getInstance( CommunicationChannelType.command);
		actionsWaitingForResponse = new Vector<CfActionDuringExecution>();
	}
	
	@Override
	public void startService(){
		logger.debug("[startService] - " + this);
		super.startService();
		communicationManager.register(this);
	}
	
	@Override
	public void stopService(){
		communicationManager.unregister(this);
		super.stopService();
	}
	
	public void processCfAction(String user, CfAction action){
		CfActionDuringExecution xmppAction = CfActionDuringExecution.buildActionfromCf(action);
		if (xmppAction != null){
			sendActionsToEUE(xmppAction);
		}
		else {
			logger.error("[sendActionToEUE] unable to create xmppAction");
			//TODO: report failed creation to xmpp
		}
	}
	
	//synchronized to avoid issues with actionsWaitingForResponse list
	protected synchronized void sendActionsToEUE(CfActionDuringExecution xmppAction){
		XmppActionComponent xmppActionComponent = new XmppActionComponent(xmppAction);
		
		actionsWaitingForResponse.add(xmppAction);		
		ActionSpecEvent actionSpecEvent = new ActionSpecEvent(null, null);
		XmppActionSpec xmppActionSpec = new XmppActionSpec();
		xmppActionSpec.addActionComponent(xmppActionComponent);
		actionSpecEvent.addActionSpec(xmppActionSpec);
		logger.info("[sendActionsToEUE] sending action");
		logger.debug("[sendActionsToEUE] action - " + xmppAction);
		sendActionsToEUE(actionSpecEvent);
	}
	
	public void sendCfActionsOut(CfActionDuringExecution cfAction){
		CfAction action = cfAction.getCfResponseAction();
		communicationManager.sendMessage(action);	
	}
	
	//------------------------  LASAD Event handling  -----------------------//
	
	//synchronized to avoid issues with actionsWaitingForResponse list
	@Override
	public abstract void processEvent(Event event);
		
	
}