package de.dfki.lasad.core.components.configuration;

/**
 * (see {@link IComponentConfiguration})
 *  
 * @author oliverscheuer
 *
 */
public interface IDataServiceConfiguration extends IComponentConfiguration{

}
