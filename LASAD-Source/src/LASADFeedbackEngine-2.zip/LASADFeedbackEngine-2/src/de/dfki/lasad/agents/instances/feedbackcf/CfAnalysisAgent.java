package de.dfki.lasad.agents.instances.feedbackcf;

import java.util.List;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.instances.action.ActionAgent;
import de.dfki.lasad.agents.instances.xmpp.CfAgentInterface;
import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.dataservice.lasad.AnalysisAndFeedbackTypeAdapter;
import de.dfki.lasad.dataservice.lasad.rmi.LASADDataService;
import de.dfki.lasad.dataservice.lasad.translators.EUEEventIDGenerator;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestEvent;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestSpec;
import de.dfki.lasad.session.SessionConfig;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.uds.cfcommunication.CfMultiSessionCommunicationManager;
import de.uds.cfcommunication.CommunicationChannelType;
import de.uds.cfcommunication.CommunicationMethodType;
import de.uds.cfcommunication.MetaforaCfFactory;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfUser;
import de.uds.commonformatparser.CfActionParser;
import de.uds.translator.CfActionTranslatorConfig;
import de.uds.translator.CfObjectTranslatorConfig;
import de.uds.translator.EueToCfActionTranslator;

public class CfAnalysisAgent extends ActionAgent implements CfAgentInterface {

	Log logger = LogFactory.getLog(this.getClass());

	CfMultiSessionCommunicationManager analysisOutputManager;
	CfMultiSessionCommunicationManager commandInputManager;
	EueToCfActionTranslator translator;

	public CfAnalysisAgent() {
		analysisOutputManager = CfMultiSessionCommunicationManager.getInstance(CommunicationMethodType.xmpp,CommunicationChannelType.analysis);
		commandInputManager = CfMultiSessionCommunicationManager.getInstance(CommunicationMethodType.xmpp,CommunicationChannelType.command);
		
	}
	
	@Override
	protected void startServiceImpl() {
		logger.debug("[startService] - " + this);
		super.startServiceImpl();
		commandInputManager.register(this);
	}

	@Override
	public void init(AbstractComponentDescription description,SessionConfig sessionConfig) throws ComponentInitException {
		super.init(description, sessionConfig);
		
		//ontology is not available until SessionConfig is parsed
		CfActionTranslatorConfig cfActionTranslatorConfig = new CfActionTranslatorConfig("conf/metafora/details/agents/types/eventsummary/CfActionTranslatorConfig.xml");
		CfObjectTranslatorConfig cfObjectTranslatorConfig = new CfObjectTranslatorConfig("conf/metafora/details/agents/types/eventsummary/CfObjectTranslatorConfig.xml");
		translator = new EueToCfActionTranslator(cfActionTranslatorConfig, cfObjectTranslatorConfig, sessionConfig.getOntology());	
	}
	
	@Override
	public void sendActionsOut(ActionSpecEvent actionSpecEvent) {

		List<CfAction> indicators = translator
				.translateActionSpecEventToIndicators(actionSpecEvent, model);
		for (CfAction indicator : indicators) {
			logger.debug("[sendActionsOut] to send out in CF - \n"
					+ CfActionParser.toXml(indicator).toString());
			analysisOutputManager.sendMessage(indicator);
		}
	}

	@Override
	protected void processEvent(Event event) {
		super.processEvent(event);
	}

	@Override
	public void processCfAction(String user, CfAction action) {
		logger.debug("[processCfAction] creating analysis request");
		if(MetaforaStrings.ACTION_TYPE_REQUEST_ANALYSIS_STRING.equalsIgnoreCase(action.getCfActionType().getType())){
			String userName = "NoNameGiven";
			CfUser originatorUser = action.getUserWithRole(MetaforaStrings.USER_ROLE_ORIGINATOR_STRING);
			if (originatorUser != null){
				userName = originatorUser.getid();
			}
			ServiceID sID = new ServiceID("metafora-jess", "all-analysis",ServiceClass.PROVISION);
	
			FeedbackRequestSpec feedbackRequestSpec = new FeedbackRequestSpec(sID);
	
			FeedbackRequestEvent feedbackRequestEvent = new FeedbackRequestEvent( feedbackRequestSpec, this.getSessionID(),
					LASADDataService.class.toString(),
					EUEEventIDGenerator.getNextID(), new UserID(userName));
			
			issueTimerTask(feedbackRequestEvent);
		}
	}

}
