package de.dfki.lasad.core;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import lasad.shared.dfki.meta.agents.ActionAgentConfigData;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;
import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.ontology.Ontology;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import de.dfki.lasad.agents.instances.action.ActionAgent;
import de.dfki.lasad.agents.instances.action.xml.ActionAgentConfigDataXML;
import de.dfki.lasad.agents.logic.analysis.types.structure.StructureAnalysisTypeXML;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.PatternTranslator;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.session.SessionManager;
import de.dfki.lasad.util.FileUtil;
import de.dfki.lasad.util.XMLUtil;

/**
 * Administration of {@link ActionAgent} configurations
 * 
 * <br/>
 * <br/>
 * <b>NOTE:</b> {@link AgentDescription}s are managed by the
 * {@link ResourcesConfigManager}.
 * 
 * @author oliverscheuer
 * 
 */
public class FeedbackConfigManager {

	static Log logger = LogFactory.getLog(FeedbackConfigManager.class);

	private static Map<ServiceID, String> type2jessRule = new HashMap<ServiceID, String>();

	public static void writeAgentConfig(ActionAgentConfigData config) {
		createAgentFolderStructureIfNotExists(config.getAgentID());
		File masterConfigFile = ConfigurationDatabase
				.getAgentConfigMasterFile(config.getAgentID());
		Map<ServiceID, File> patternConfigFiles = new HashMap<ServiceID, File>();
		for (AnalysisType aType : config.getAnalysisTypes()) {
			ServiceID sID = aType.getServiceID();
			File patternConfigFile = ConfigurationDatabase
					.getAgentConfigPatternFile(sID);
			patternConfigFiles.put(sID, patternConfigFile);
		}
		ActionAgentConfigDataXML.writeXMLFileExternalPatterns(masterConfigFile,
				patternConfigFiles, config);
	}

	public static void deleteAgentConfigFiles(String agentID) {
		File agentConfHomeDir = ConfigurationDatabase
				.getAgentConfHomeDir(agentID);
		if (agentConfHomeDir.exists()) {
			recursiveDelete(agentConfHomeDir);
		}
	}

	public static boolean isJessRuleGenerated(StructureAnalysisType type) {
		File jessFile = ConfigurationDatabase.getAgentConfigJessRuleFile(type
				.getServiceID());
		return jessFile.exists();
	}

	public static String generateJessRule(StructureAnalysisType type) {
		Ontology ontology = getOntology(type.getOntologyID());
		String jessRule = generateJessRule(type, ontology);
		writeJessRuleToFile(type, jessRule);
		return jessRule;
	}

	// Tries to retrieve jess rule from internal data structure. If not
	// successful, tries to load jess rule from file system. If not successful
	// generate jess file from definition.
	public static String getJessRule(StructureAnalysisType type) {
		String jessRule = type2jessRule.get(type.getServiceID());
		if (jessRule != null) {
			logger.info("Jess rule retrieved from internal data structure: "
					+ type.getServiceID());
			return jessRule;
		}
		// try to load rule from file
		File jessFile = ConfigurationDatabase.getAgentConfigJessRuleFile(type
				.getServiceID());
		if (jessFile.exists()) {
			// load jess rule
			jessRule = FileUtil.readFromFile(jessFile);
			logger.info("Jess rule retrieved from file: " + type.getServiceID());
			type2jessRule.put(type.getServiceID(), jessRule);
			return jessRule;
		} else {
			// generate jess rule
			jessRule = generateJessRule(type);
			logger.info("Jess rule generated from description: "
					+ type.getServiceID());
			type2jessRule.put(type.getServiceID(), jessRule);
			return jessRule;
		}
	}

	private static Ontology getOntology(String ontologyID) {
		Ontology ontology;
		if (ontologyID == null) {
			ontology = null;
		} else {
			ontology = SessionManager.getOntology(ontologyID);
			if (ontology == null) {
				logger.error("could not retrieve ontology from SessionManager: "
						+ ontologyID);
			}
		}
		return ontology;
	}

	private static String generateJessRule(StructureAnalysisType type,
			Ontology ontology) {
		PatternTranslator translator = new PatternTranslator(ontology);
		String jessRule = translator.generateJessRule(type.getServiceID(),
				type.getPattern());
		return jessRule;
	}

	private static void writeJessRuleToFile(StructureAnalysisType type,
			String jessRule) {
		ServiceID serviceID = type.getServiceID();

		createAgentFolderStructureIfNotExists(serviceID.getAgentID());
		File jessFile = ConfigurationDatabase
				.getAgentConfigJessRuleFile(serviceID);
		FileUtil.writeToFile(jessFile, jessRule);
	}

	private static void createAgentFolderStructureIfNotExists(String agentID) {
		File agentConfHomeDir = ConfigurationDatabase
				.getAgentConfHomeDir(agentID);
		if (!agentConfHomeDir.exists()) {
			agentConfHomeDir.mkdir();
		}
		File agentPatternsDir = ConfigurationDatabase
				.getAgentConfigPatternDir(agentID);
		if (!agentPatternsDir.exists()) {
			agentPatternsDir.mkdir();
		}
	}

	private static void recursiveDelete(File f) {
		if (f.isDirectory()) {
			for (File c : f.listFiles()) {
				recursiveDelete(c);
			}
		}
		f.delete();
	}
}
