package de.dfki.lasad.agents.logic.analysis.types.structure;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.CDATA;
import org.jdom.Element;

import de.dfki.lasad.agents.instances.xml.AnalysisTypeXML;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class StructureAnalysisTypeXML extends AnalysisTypeXML {

	private static Log logger = LogFactory
			.getLog(StructureAnalysisTypeXML.class);

	public static final String TYPE = "structure-pattern";

	/**
	 * 
	 * @param agentID
	 * @param ontologyID
	 *            ID of ontology this pattern depends on or <code>null</code> if
	 *            no such dependency exists
	 * @param elem
	 * @return
	 */
	public static StructureAnalysisType fromXML(String agentID,
			String ontologyID, Element elem) {
		ServiceID serviceID = getServiceID(agentID, elem);
		String name = getName(elem);
		String description = getDescription(elem);

		String jessPath = getJessPath(elem);

		Element structureDefElem = elem
				.getChild(StructuralPatternXML.ELEMENT_NAME);
		StructuralPattern pattern;
		if (structureDefElem != null) {
			pattern = StructuralPatternXML.fromXML(serviceID.getTypeID(),
					structureDefElem);
		} else {
			pattern = new StructuralPattern(serviceID.getTypeID());
		}

		StructureAnalysisType structureType = new StructureAnalysisType(
				serviceID, pattern);
		structureType.setName(name);
		structureType.setDescription(description);
		structureType.setOntologyID(ontologyID);

		return structureType;
	}

	private static String getJessPath(Element elem) {
		Element compilePathElem = elem.getChild("compile-path");
		if (compilePathElem == null) {
			return null;
		}
		return compilePathElem.getText();
	}

	public static Element toXML(StructureAnalysisType aType) {

		Element elem = createPatternElement();
		addServiceIDAtt(elem, aType);
		addServiceTypeAtt(elem, TYPE);
		addResultTypeAtt(elem, aType);
		addNameElemIfNotNull(elem, aType);
		addDescriptionElemIfNotNull(elem, aType);

		StructuralPattern patternDefinition = aType.getPattern();
		if (patternDefinition != null) {
			Element patternDefElem = StructuralPatternXML
					.toXML(patternDefinition);
			elem.addContent(patternDefElem);
		}

		return elem;
	}

}
