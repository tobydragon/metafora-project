package de.dfki.lasad.agents.logic.provision.actionhistory;

import java.util.List;

/**
 * 
 * @author oliverscheuer
 * 
 */
public interface MsgProvisionHistoryChangedListener {

	public void onHistoryChanged(List<MsgProvisionRecord> sentMsgs);
}
