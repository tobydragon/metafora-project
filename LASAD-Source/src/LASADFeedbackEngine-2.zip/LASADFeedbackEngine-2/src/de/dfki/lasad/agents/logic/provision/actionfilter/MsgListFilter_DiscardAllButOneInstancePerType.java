package de.dfki.lasad.agents.logic.provision.actionfilter;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import lasad.shared.dfki.meta.agents.action.ActionType;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgListFilter_DiscardAllButOneInstancePerType implements
		MsgListFilter {

	@Override
	public void filter(List<ActionTypeResult> unfilteredList) {

		Set<ActionType> coveredActionTypes = new HashSet<ActionType>();
		for (Iterator<ActionTypeResult> iter = unfilteredList.iterator(); iter
				.hasNext();) {
			ActionType aType = iter.next().getActionType();
			if (coveredActionTypes.contains(aType)) {
				iter.remove();
			} else {
				coveredActionTypes.add(aType);
			}
		}
	}
}
