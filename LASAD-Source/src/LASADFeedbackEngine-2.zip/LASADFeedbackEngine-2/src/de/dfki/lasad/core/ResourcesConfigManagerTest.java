package de.dfki.lasad.core;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import junit.framework.TestCase;
import lasad.shared.dfki.meta.ontology.Ontology;
import lasad.shared.dfki.meta.ontology.ToolContext;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.core.components.instance.ISessionModel;
import de.dfki.lasad.session.SessionConfig;
import de.dfki.lasad.session.data.SessionID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ResourcesConfigManagerTest extends TestCase {

	private static ResourcesConfigManager rsManager = getAndInitResourceConfigManager();

	/**
	 * Loads descriptions and prints them to the console
	 */
	public void testLoadComponentDescr() {
		System.out.println("#### testLoadComponentDescr() ... DONE ####");
	}

	/**
	 * Initializes one component instance for each description
	 */
	public void testInitializeComponents() {
		System.out.println("#### testInitializeComponents() ####");
		try {
			for (String dsDescrID : rsManager.getDataServiceDescriptionIDs()) {
				DataServiceDescription dsDescr = rsManager
						.getDataServiceDescription(dsDescrID);
				IDataService dataService = (IDataService) dsDescr
						.createInstance(null);
			}

			SessionConfig sConfig = createFakeSessionConfig();

			for (String smDescrID : rsManager.getSessionModelDescriptionIDs()) {
				SessionModelDescription smDescr = rsManager
						.getSessionModelDescription(smDescrID);
				ISessionModel sessionModel = (ISessionModel) smDescr
						.createInstance(sConfig);
			}

			for (String agentDescrID : rsManager.getAgentDescriptionIDs()) {
				AgentDescription agentDescr = rsManager
						.getAgentDescription(agentDescrID);
				IAgent agent = (IAgent) agentDescr.createInstance(sConfig);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private SessionConfig createFakeSessionConfig() {
		SessionModelDescription smDescr = null;
		Iterator<String> smIter = rsManager.getSessionModelDescriptionIDs()
				.iterator();
		if (smIter.hasNext()) {
			String smID = smIter.next();
			smDescr = rsManager.getSessionModelDescription(smID);
		}
		List<AgentDescription> agentDescrs = new Vector<AgentDescription>();
		for (String aDescrID : rsManager.getAgentDescriptionIDs()) {
			AgentDescription aDescr = rsManager.getAgentDescription(aDescrID);
			agentDescrs.add(aDescr);
		}
		SessionID sID = new SessionID("FAKE");
		Ontology onto = new Ontology("FAKE");
		ToolContext tc = new ToolContext();
		SessionConfig sConfig = new SessionConfig(sID, onto, tc);
		sConfig.addAgentDescriptions(agentDescrs);
		sConfig.setModelDescription(smDescr);
		return sConfig;

	}

	/**
	 * CHECK also file system whether config file is correct (i.e., descr added)
	 */
	public void testAddOrUpdateAgentDescription() {
		try {
			// collect descriptions
			List<AgentDescription> adescrs = new Vector<AgentDescription>();
			for (String agentDescrID : rsManager.getAgentDescriptionIDs()) {
				AgentDescription agentDescr = rsManager
						.getAgentDescription(agentDescrID);
				adescrs.add(agentDescr);
			}

			// change descriptions dir
			ConfigurationDatabaseAccessor.setResourceDir("resources-test-temp");
			ConfigurationDatabase.getResourcesDir().mkdir();

			// delete internal record of descriptions
			for (String agentDescrID : rsManager.getAgentDescriptionIDs()) {
				rsManager.deleteAgentDescription(agentDescrID);
			}
			System.out
					.println("AgentDescrs in working memory BEFORE adding DESCRIPTION: "
							+ rsManager.getAgentDescriptionIDs());
			// add descriptions to new descriptions dir
			for (AgentDescription agentDescr : adescrs) {
				rsManager.addOrUpdateAgentDescription(agentDescr);
			}
			System.out
					.println("AgentDescrs in working memory AFTER adding DESCRIPTION: "
							+ rsManager.getAgentDescriptionIDs());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Depends on: testAddAgentDescription()
	 * 
	 * CHECK also file system whether config file is correct (i.e., descr
	 * removed)
	 */
	public void testDeleteAgentDescription() {
		// creating a new temporal config file
		testAddOrUpdateAgentDescription();
		System.out
				.println("AgentDescrs in working memory BEFORE deleting DESCRIPTION: "
						+ rsManager.getAgentDescriptionIDs());
		for (String agentDescrID : rsManager.getAgentDescriptionIDs()) {

			rsManager.deleteAgentDescription(agentDescrID);
		}
		System.out
				.println("AgentDescrs in working memory AFTER deleting DESCRIPTION: "
						+ rsManager.getAgentDescriptionIDs());

	}

	private static ResourcesConfigManager getAndInitResourceConfigManager() {
		ResourcesConfigManager rsManager = new ResourcesConfigManager();
		rsManager.loadDescriptions();
		return rsManager;
	}
}
