package de.dfki.lasad.core;

import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.core.components.instance.ISessionModel;
import junit.framework.TestCase;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ResourcesConfigManagerTest extends TestCase {

	public void testLoadComponentDescr() {
		System.out.println("#### testLoadComponentDescr() ####");
		ResourcesConfigManager rsManager = new ResourcesConfigManager();
		rsManager.loadDescriptionsFromFile();
	}

	public void testInitializeComponents() {
		System.out.println("#### testInitializeComponents() ####");
		try {
			ResourcesConfigManager rsManager = new ResourcesConfigManager();
			rsManager.loadDescriptionsFromFile();

			for (String dsDescrID : rsManager.getDataServiceDescriptionIDs()) {
				DataServiceDescription dsDescr = rsManager
						.getDataServiceDescription(dsDescrID);
				IDataService dataService = (IDataService) dsDescr
						.createInstance();
			}

			for (String smDescrID : rsManager.getSessionModelDescriptionIDs()) {
				SessionModelDescription smDescr = rsManager
						.getSessionModelDescription(smDescrID);
				ISessionModel sessionModel = (ISessionModel) smDescr
						.createInstance();
			}

			for (String agentDescrID : rsManager.getAgentDescriptionIDs()) {
				AgentDescription agentDescr = rsManager
						.getAgentDescription(agentDescrID);
				IAgent agent = (IAgent) agentDescr.createInstance();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
