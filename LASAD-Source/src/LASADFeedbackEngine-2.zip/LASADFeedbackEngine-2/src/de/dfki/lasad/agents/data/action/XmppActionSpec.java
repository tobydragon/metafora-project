package de.dfki.lasad.agents.data.action;



public class XmppActionSpec extends AgentAction {
	
}
