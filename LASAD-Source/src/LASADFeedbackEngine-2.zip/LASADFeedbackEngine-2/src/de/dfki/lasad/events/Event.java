package de.dfki.lasad.events;

/**
 * 
 * @author oliverscheuer
 *
 */
public interface Event {

	public abstract long getTs();

	public abstract void setTs(long ts);

	public abstract int getEventPriority();

	public abstract void setEventPriority(int priority);

	public abstract void setSourceComponentID(String sourceComponentID);

	public abstract String getSourceComponentID();

	public abstract String getClassName();

	public abstract int compareTo(Event otherEvent);

}