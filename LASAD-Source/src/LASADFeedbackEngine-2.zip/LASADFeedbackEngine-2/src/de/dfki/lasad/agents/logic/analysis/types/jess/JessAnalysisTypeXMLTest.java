package de.dfki.lasad.agents.logic.analysis.types.jess;

import java.io.File;

import lasad.shared.dfki.meta.agents.analysis.jess.JessAnalysisType;

import org.jdom.Element;

import de.dfki.lasad.util.ClasspathResourceUtil;
import de.dfki.lasad.util.XMLUtil;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class JessAnalysisTypeXMLTest {

	public static void main(String[] args) {
		reGenerateAndPrintXML("testcase-1.xml");
	}

	public static void reGenerateAndPrintXML(String localFilename) {
		System.out.println(localFilename);
		System.out.println("-----------------");
		String filePathCase = ClasspathResourceUtil
				.getAbsoluteFilepathFromResourceOnClasspath(
						JessAnalysisTypeXMLTest.class, localFilename);

		JessAnalysisType type = parseFile(filePathCase);
		// System.out.println(type);
		String xmlString = toXMLString(type);
		System.out.println(xmlString);
	}

	public static JessAnalysisType parseFile(String absPathXML) {
		try {

			File file = new File(absPathXML);
			Element elem = XMLUtil.file2xmlElem(file);
			return JessAnalysisTypeXML.fromXML("ANALYSIS-AGENT", elem);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String toXMLString(JessAnalysisType jessType) {
		try {

			Element elem = JessAnalysisTypeXML.toXML(jessType);
			return XMLUtil.xmlElem2docString(elem);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
