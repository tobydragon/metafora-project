package de.dfki.lasad.events.eue.user.object;

import java.util.List;

import de.dfki.lasad.events.eue.EUEEventID;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;

/**
 * How to interpret modifications: <br/>
 * - {@link EUEObject} ID does never change <br/>
 * - A generic property is included in {@link EUEObject#getProps()} if and only
 * if it has changed - A type-specific property that has not changed will be
 * <code>null</code> (e.g., {@link EUEObject#getType()},
 * {@link Node#getParentID()} {@link Link#getSources()} and
 * {@link Link#getTargets()}). <br/>
 * 
 * @author Oliver Scheuer
 * 
 */
public class ModifyObjectEvent extends ObjectActionEvent {

	public ModifyObjectEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID, List<EUEObject> eueObject) {
		super(sessionID, srcCompId, eueEventID, userID, eueObject);

	}

	public ModifyObjectEvent(SessionID sessionID, EUEEventID eueEventId,
			String srcComponentId) {
		super(sessionID, srcComponentId, eueEventId);
	}

	public ModifyObjectEvent cloneWithoutObjects() {
		ModifyObjectEvent clone = new ModifyObjectEvent(getSessionID(),
				getEueEventID(), getSourceComponentID());
		clone.setUserID(getUserID());
		return clone;
	}
}
