package de.dfki.lasad.agents.data.action;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.UserIDAll;

/**
 * A set of {@link ActionComponent}s associated with the user(s) to whom the
 * action should be provided.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AgentAction {

	private UserID actionRecipient = new UserIDAll();
	private Set<ActionComponent> actionComponents = new HashSet<ActionComponent>();

	public UserID getActionRecipient() {
		return actionRecipient;
	}

	public void setActionRecipient(UserID actionRecipient) {
		this.actionRecipient = actionRecipient;
	}

	public void addActionComponent(ActionComponent actionComponent) {
		actionComponents.add(actionComponent);
	}

	public void setActionComponents(Set<ActionComponent> actionComponents) {
		this.actionComponents = actionComponents;
	}

	public Set<ActionComponent> getActionComponents() {
		return actionComponents;
	}

	@Override
	public String toString() {
		StringBuffer actionComponentsBuf = new StringBuffer();
		for (Iterator<ActionComponent> iter = actionComponents.iterator(); iter
				.hasNext();) {
			actionComponentsBuf.append(iter.next().toString());
			if (iter.hasNext()) {
				actionComponentsBuf.append(", ");
			}
		}

		return getClass().getSimpleName() + ": [for user: " + actionRecipient
				+ ", " + actionComponentsBuf + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((actionComponents == null) ? 0 : actionComponents.hashCode());
		result = prime * result
				+ ((actionRecipient == null) ? 0 : actionRecipient.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgentAction other = (AgentAction) obj;
		if (actionComponents == null) {
			if (other.actionComponents != null)
				return false;
		} else if (!actionComponents.equals(other.actionComponents))
			return false;
		if (actionRecipient == null) {
			if (other.actionRecipient != null)
				return false;
		} else if (!actionRecipient.equals(other.actionRecipient))
			return false;
		return true;
	}

}
