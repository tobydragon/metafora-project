package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import org.apache.log4j.Logger;

import de.dfki.lasad.events.eue.admin.session.ManagementResponseEvent;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;
import de.uds.commonformat.CfProperty;
import de.uds.commonformat.CfUser;

public abstract class CfManagementAction extends CfActionDuringExecution{
	Logger logger = Logger.getLogger(this.getClass());
	
	public CfManagementAction(CfAction cfAction) {
		super(cfAction);
	}

	//TODO:rewrite using params instead of message
	public abstract boolean eventIsResponseToMe(ManagementResponseEvent mEvent);
	
	public void moveToResponsePhase(ManagementResponseEvent mEvent){
		setState(CfActionState.waitingToReportToXmpp);
		cfAction.setTime(System.currentTimeMillis());
		if (mEvent.isSuccess()){
			cfAction.getCfActionType().setSucceed(Boolean.toString(mEvent.isSuccess()));
		}
		else {
			//means we should send succeed=true, because the map already exists
			if (MetaforaStrings.PROPERTY_VALUE_REASON_ALREADY_EXISITS_STRING.equalsIgnoreCase(mEvent.getReason())){
				CfObject mapObject = cfAction.getCfObjects().get(0);
				if (mEvent.getSessionID() != null){
					String mapId = mEvent.getSessionID().getIdAsString();
					mapObject.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING, mapId));
					mapObject.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_REASON_STRING, MetaforaStrings.PROPERTY_VALUE_REASON_ALREADY_EXISITS_STRING));
					cfAction.getCfActionType().setSucceed(Boolean.toString(true));
				}
				else{
					logger.error("[moveToResponsePhase] map supposedly aleardy exists, but no ID given");
				}
			}
			else {
				cfAction.getCfActionType().setSucceed(Boolean.toString(mEvent.isSuccess()) );
			}
		}
		
		
		
		//Switch originator and receiver
		CfUser originator = cfAction.getUserWithRole(MetaforaStrings.USER_ROLE_ORIGINATOR_STRING);
		CfUser receiver = cfAction.getUserWithRole(MetaforaStrings.USER_ROLE_RECEIVER_STRING);
		String originatorToReplyToId = originator.getid();
		String receiverToReplyFromId = receiver.getid();
		originator.setid(receiverToReplyFromId);
		receiver.setid(originatorToReplyToId);
	}

}
