package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import de.dfki.lasad.events.eue.admin.session.ManagementResponseEvent;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;

public abstract class CfManagementAction extends CfActionDuringExecution{
	
	public CfManagementAction(CfAction cfAction) {
		super(cfAction);
	}

	public abstract boolean eventIsResponseToMe(ManagementResponseEvent mEvent);
	
	public void moveToResponsePhase(ManagementResponseEvent mEvent){
		setState(CfActionState.waitingToReportToXmpp);
		cfAction.setTime(System.currentTimeMillis());
		cfAction.getCfActionType().setSucceed(Boolean.toString(mEvent.isSuccess()) );
		cfAction.getUserWithRole(MetaforaStrings.USER_ROLE_ORIGINATOR_STRING).setid(MetaforaStrings.LASAD_AGENT_USER_ID_STRING);
	}

}
