package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import java.util.List;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ComparisonType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.types.structure.translator.Indent;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PropSlotGen {

	private static final Log logger = LogFactory.getLog(PropSlotGen.class);

	private JessIDAndSlotNameGenerator idGen;

	private boolean addNotNilChecks = true;

	// in
	private ElementVariableProp propVar;
	private List<Comparison> propComparisons;
	private Bin bin;
	private int tempVarAppendix;
	private boolean useTempVarLeft;
	private boolean useTempVarRight;

	// derived
	private PropConstrsGen propConstrsGen;

	/**
	 * Generates Jess 'property' slot, according to the given specification
	 * 
	 * @param propVar
	 *            target property (component)
	 * @param propComparisons
	 *            {@link Comparisons}
	 * @param compSelector
	 *            {@link Comparison} selector (of {@link ComparisonType})
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 */
	public PropSlotGen(JessIDAndSlotNameGenerator idGen,
			ElementVariableProp propVar, List<Comparison> propComparisons,
			Bin bin, int tempVarAppendix, boolean useTempVarLeft,
			boolean useTempVarRight) {
		this.idGen = idGen;
		this.propVar = propVar;
		this.propComparisons = propComparisons;
		this.bin = bin;
		this.tempVarAppendix = tempVarAppendix;
		this.useTempVarLeft = useTempVarLeft;
		this.useTempVarRight = useTempVarRight;

		propConstrsGen = new PropConstrsGen(idGen, propVar, propComparisons,
				bin, tempVarAppendix, useTempVarLeft, useTempVarRight,
				addNotNilChecks);
	}

	public int getNumConstrs() {
		return propConstrsGen.getNumConstrs();
	}

	public String getString() {
		StringBuffer buf = new StringBuffer();

		String slotName = idGen.generateSlotName(propVar);
		String propVarID = idGen.generatePropVarID(propVar, tempVarAppendix,
				useTempVarLeft, false);
		String propSlotStart = "(" + slotName + " " + propVarID;
		String propSlotConstrs = propConstrsGen.getString();

		buf.append(propSlotStart);
		if (!"".equals(propSlotConstrs)) {
			buf.append("\n");
			buf.append(Indent.apply(propSlotConstrs,
					Indentations.INDENT_PROPCONSTR));
		}
		buf.append(")");
		return buf.toString();
	}
}
