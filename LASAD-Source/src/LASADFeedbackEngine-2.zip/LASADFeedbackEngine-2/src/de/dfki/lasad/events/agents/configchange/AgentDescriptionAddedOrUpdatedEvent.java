package de.dfki.lasad.events.agents.configchange;

import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;

/**
 * Notification that the Feedback-Engine configuration has changed.
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescriptionAddedOrUpdatedEvent extends AFStateChangedEvent {

	private AgentDescriptionFE aDescr;

	public AgentDescriptionAddedOrUpdatedEvent(String srcCompId) {
		super(srcCompId);
	}

	public AgentDescriptionFE getAgentDescr() {
		return aDescr;
	}

	public void setAgentDescr(AgentDescriptionFE aDescr) {
		this.aDescr = aDescr;
	}

	@Override
	public String toString() {
		return "AgentDescriptionAddedOrUpdatedEvent [aDescr=" + aDescr + "]";
	}

}
