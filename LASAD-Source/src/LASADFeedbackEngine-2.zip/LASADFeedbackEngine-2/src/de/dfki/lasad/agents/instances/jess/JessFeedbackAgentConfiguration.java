package de.dfki.lasad.agents.instances.jess;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.SessionChecker;
import de.dfki.lasad.agents.SimpleSessionChecker;
import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.CompoundActionType;
import de.dfki.lasad.agents.data.meta.RuleAnalysisType;
import de.dfki.lasad.agents.data.meta.AnalysisActionType;
import de.dfki.lasad.authoring.model.AgentConfigFE;
import de.dfki.lasad.core.components.configuration.IAgentConfiguration;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessFeedbackAgentConfiguration implements IAgentConfiguration {

	static Log logger = LogFactory.getLog(JessFeedbackAgentConfiguration.class);

	private String agentID = "NOT SET";

	private boolean provideRawResults = false;

	private List<String> phaseIDs = new Vector<String>();
	private List<AnalysisType> analysisTypeList = new Vector<AnalysisType>();
	private Map<String, AnalysisType> analysisTypeMap = new HashMap<String, AnalysisType>();

	private List<AnalysisActionType> simpleActionTypes = new Vector<AnalysisActionType>();
	private List<CompoundActionType> compoundActionTypes = new Vector<CompoundActionType>();

	private boolean publishAllActionTypes = false;
	private boolean publishAllAnalysisTypes = false;

	/**
	 * FE ... frontend
	 */
	private AgentConfigFE configFE = null;

	SessionChecker supportedOntologies;

	@Override
	public void load(File confFile) {
		readConfig(confFile);
	}

	@Override
	public boolean doPublishAllActionTypes() {
		return publishAllActionTypes;
	}

	@Override
	public boolean doPublishAllAnalysisTypes() {
		return publishAllAnalysisTypes;
	}

	@Override
	public boolean hasConfigFE() {
		return (getConfigFE() != null);
	}

	@Override
	public AgentConfigFE getConfigFE() {
		return configFE;
	}

	@Override
	public void setConfigFE(AgentConfigFE configFE) {
		this.configFE = configFE;
	}

	public void setPublishAllActionTypes(boolean value) {
		publishAllActionTypes = value;
	}

	@Override
	public void replaceAgentID(String agentID) {
		this.agentID = agentID;
		for (ActionType aType : getActionTypes()) {
			aType.setAgentID(agentID);
		}
		for (AnalysisActionType simpleType : simpleActionTypes) {
			RuleAnalysisType ruleType = (RuleAnalysisType) simpleType
					.getAnalysisType();
			ruleType.setAgentID(agentID);
			String ruleAgentIDInserted = ruleType.getDefinition().replace(
					"[##AGENT-ID##]", agentID);
			ruleType.setDefinition(ruleAgentIDInserted);
		}
	}

	@Override
	public List<ActionType> getActionTypes() {
		List<ActionType> actionTypes = new Vector<ActionType>();
		for (ActionType aType : simpleActionTypes) {
			actionTypes.add(aType);
		}

		for (ActionType aType : compoundActionTypes) {
			actionTypes.add(aType);
		}
		return actionTypes;
	}

	@Override
	public List<AnalysisType> getAnalysisTypes() {
		return analysisTypeList;
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	@Override
	public SessionChecker getSessionChecker() {
		return supportedOntologies;
	}

	public RuleAnalysisType getRuleAnalysisType(String patternID) {
		return (RuleAnalysisType) analysisTypeMap.get(patternID);
	}

	public List<AnalysisActionType> getSimpleActionTypes() {
		return simpleActionTypes;
	}

	public List<CompoundActionType> getCompoundActionTypes() {
		return compoundActionTypes;
	}

	public List<String> getPhaseIDs() {
		return phaseIDs;
	}

	public void addPhaseID(String phaseID) {
		phaseIDs.add(phaseID);
	}

	public void setPhaseIDs(List<String> phaseIDs) {
		this.phaseIDs = phaseIDs;
	}

	public void addRuleAnalysisType(RuleAnalysisType ruleType) {
		analysisTypeList.add(ruleType);
		analysisTypeMap.put(ruleType.getTypeID(), ruleType);
	}

	public void addSimpleActionType(AnalysisActionType simpleActionType) {
		simpleActionTypes.add(simpleActionType);
	}

	public void addCompoundActionType(CompoundActionType compoundActionType) {
		this.compoundActionTypes.add(compoundActionType);
	}

	public void setSupportedOntologies(List<String> supportedOntologyIDs) {
		supportedOntologies = new SimpleSessionChecker(supportedOntologyIDs);
	}

	public void setSupportedAllOntologies() {
		supportedOntologies = new SimpleSessionChecker();
	}

	private final void readConfig(File confFile) {
		logger.info("Trying to read configuration from file '"
				+ confFile.getAbsolutePath() + "' ...");
		JessFeedbackAgentConfigParser parser = new JessFeedbackAgentConfigParser();
		parser.fillInConfigFromFile(confFile, this);
		logger.info("... Done.");
	}

	public boolean doPublishRawResults() {
		return provideRawResults;
	}

	public void setProvideRawResults(boolean provideRawResults) {
		this.provideRawResults = provideRawResults;
	}

	@Override
	public String toString() {

		StringBuffer analysisTypesBuf = new StringBuffer();
		analysisTypesBuf.append("{");
		for (Iterator<AnalysisType> aTypeIter = analysisTypeList.iterator(); aTypeIter
				.hasNext();) {
			analysisTypesBuf.append(aTypeIter.next().getTypeID());
			if (aTypeIter.hasNext()) {
				analysisTypesBuf.append(", ");
			}
		}
		analysisTypesBuf.append("}");

		StringBuffer simpleActionTypesBuf = new StringBuffer();
		simpleActionTypesBuf.append("{");
		for (Iterator<AnalysisActionType> simpleTypeIter = simpleActionTypes
				.iterator(); simpleTypeIter.hasNext();) {
			simpleActionTypesBuf.append(simpleTypeIter.next().getTypeID());
			if (simpleTypeIter.hasNext()) {
				simpleActionTypesBuf.append(", ");
			}
		}
		simpleActionTypesBuf.append("}");

		StringBuffer compoundActionTypesBuf = new StringBuffer();
		compoundActionTypesBuf.append("{");
		for (Iterator<CompoundActionType> aTypeIter = compoundActionTypes
				.iterator(); aTypeIter.hasNext();) {
			compoundActionTypesBuf.append(aTypeIter.next().getTypeID());
			if (aTypeIter.hasNext()) {
				compoundActionTypesBuf.append(", ");
			}
		}
		compoundActionTypesBuf.append("}");

		return getClass().getSimpleName() + " agentID=" + agentID
				+ ", analysisTypes=" + analysisTypesBuf.toString()
				+ ", simpleActionTypes=" + simpleActionTypesBuf.toString()
				+ ", compoundActionTypes=" + compoundActionTypesBuf.toString();
	}

}
