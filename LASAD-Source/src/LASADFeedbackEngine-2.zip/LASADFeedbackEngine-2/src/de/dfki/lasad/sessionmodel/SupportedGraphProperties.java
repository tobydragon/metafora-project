package de.dfki.lasad.sessionmodel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class SupportedGraphProperties {

	private static List<String> supportedNodeProperties = new Vector<String>();
	static {
		// supportedNodeProperties.add("POS-X");
		// supportedNodeProperties.add("POS-Y");
	}

	private static List<String> supportedLinkProperties = new Vector<String>();
	static {
	}

	private static List<String> supportedSubElementDataTypes = new Vector<String>();
	static {
		supportedSubElementDataTypes.add("transcript-link");
		supportedSubElementDataTypes.add("rating");
		supportedSubElementDataTypes.add("awareness");
		supportedSubElementDataTypes.add("text");
	}

	private static Map<String, List<String>> subElementDataType2Properties = new HashMap<String, List<String>>();
	static {
		List<String> transcriptLinkProps = new Vector<String>();
		subElementDataType2Properties.put("transcript-link",
				transcriptLinkProps);
		transcriptLinkProps.add("STARTROW");
		transcriptLinkProps.add("STARTPOINT");
		transcriptLinkProps.add("ENDROW");
		transcriptLinkProps.add("ENDPOINT");

		List<String> ratingProps = new Vector<String>();
		subElementDataType2Properties.put("rating", ratingProps);
		ratingProps.add("SCORE");

		List<String> awarenessProps = new Vector<String>();
		subElementDataType2Properties.put("awareness", awarenessProps);
		awarenessProps.add("TEXT");

		List<String> textProps = new Vector<String>();
		subElementDataType2Properties.put("text", textProps);
		textProps.add("TEXT");
	}

	public static boolean isSubElementSupported(String propName) {
		return supportedSubElementDataTypes.contains(propName);
	}

	public static boolean isNodePropSupported(String propName) {
		return supportedNodeProperties.contains(propName);
	}

	public static boolean isLinkPropSupported(String propName) {
		return supportedLinkProperties.contains(propName);
	}

	public static boolean isSubElementPropSupported(String subElementDataType,
			String propName) {
		return subElementDataType2Properties.containsKey(subElementDataType)
				&& subElementDataType2Properties.get(subElementDataType)
						.contains(propName);
	}

}
