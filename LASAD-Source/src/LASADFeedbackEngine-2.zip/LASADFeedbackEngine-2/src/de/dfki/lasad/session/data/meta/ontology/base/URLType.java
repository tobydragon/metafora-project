package de.dfki.lasad.session.data.meta.ontology.base;

import de.dfki.lasad.session.data.meta.ontology.ComparisonGroup;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * 
 * @author oliverscheuer
 *
 */
public class URLType extends BaseType {

	private static URLType instance = new URLType();
	
	private URLType(){
		super();
		lasadElementType = "url";
		jessTemplateName = "elem_url";
		addComponentSpecification(PropDescr.DEFAULT_COMPONENT_ID,"LINK", JessDataType.STRING, ComparisonGroup.NONE);
	}
	
	public static URLType getInstance(){
		return instance;
	}
}
