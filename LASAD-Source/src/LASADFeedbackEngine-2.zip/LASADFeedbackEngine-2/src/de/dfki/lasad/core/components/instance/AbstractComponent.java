package de.dfki.lasad.core.components.instance;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.ServiceStatus;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.events.agents.configchange.AFStateChangedEventListener;
import de.dfki.lasad.events.agents.configchange.ComponentRuntimeStatusChangedEvent;
import de.dfki.lasad.events.agents.configchange.SessionRuntimeStatusChangedEvent;
import de.dfki.lasad.session.data.SessionID;

/**
 * (see {@link IComponent})
 * 
 * @author oliverscheuer
 * 
 */
public abstract class AbstractComponent implements IComponent {

	private static Log logger = LogFactory.getLog(AbstractComponent.class);

	private List<AFStateChangedEventListener> afStateChangedListeners = new Vector<AFStateChangedEventListener>();

	protected ServiceStatus serviceStatus = ServiceStatus.UNDER_CONSTRUCTION;;

	@Override
	public synchronized void startService(SessionID sID) {
		String sessionContextString = (sID == null) ? "(no session)" : sID
				.toString();
		setServiceStatus(ServiceStatus.STARTING);
		logger.info(getComponentID() + ": Start service for session: "
				+ sessionContextString + "...");
		startServiceImpl();
		setServiceStatus(ServiceStatus.RUNNING);
		logger.info("... service started (" + getComponentID() + ", "
				+ sessionContextString + ")");
	}

	@Override
	public synchronized void stopService(SessionID sID) {
		String sessionContextString = (sID == null) ? "(no session)" : sID
				.toString();
		setServiceStatus(ServiceStatus.STOPPING);
		logger.info(getComponentID() + ": Stop service for session: "
				+ sessionContextString + "...");
		stopServiceImpl();
		setServiceStatus(ServiceStatus.STALE);
		logger.info("... service stopped (" + getComponentID()
				+ sessionContextString + ")");

	}

	protected abstract void startServiceImpl();

	protected abstract void stopServiceImpl();

	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(ServiceStatus newStatus) {
		ServiceStatus oldStatus = this.serviceStatus;
		this.serviceStatus = newStatus;
		logger.info("Status changed: " + serviceStatus + " ("
				+ getComponentID() + ", " + getClass() + ")");
		notifyListenersStatusChanged(oldStatus, newStatus);
	}

	public void addListener(AFStateChangedEventListener l) {
		afStateChangedListeners.add(l);
	}

	private void notifyListenersStatusChanged(ServiceStatus oldS,
			ServiceStatus newS) {
		ComponentRuntimeStatusChangedEvent runtimeChangedEv = new ComponentRuntimeStatusChangedEvent(
				getComponentID());
		runtimeChangedEv.setChangedComponentID(getComponentID());
		runtimeChangedEv.setOldStatus(oldS);
		runtimeChangedEv.setNewStatus(newS);

		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(runtimeChangedEv);
		}
	}

	@Override
	public String toString() {
		return "" + getComponentID();
	}
}
