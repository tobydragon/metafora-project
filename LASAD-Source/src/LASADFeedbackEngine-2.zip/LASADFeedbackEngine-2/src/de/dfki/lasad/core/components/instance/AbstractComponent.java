package de.dfki.lasad.core.components.instance;

import java.util.List;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.events.agents.state.AFStateChangedEventListener;
import de.dfki.lasad.events.agents.state.RuntimeChangedEvent;

/**
 * (see {@link IComponent})
 * 
 * @author oliverscheuer
 * 
 */
public abstract class AbstractComponent implements IComponent {

	private static Log logger = LogFactory.getLog(AbstractComponent.class);

	private List<AFStateChangedEventListener> afStateChangedListeners = new Vector<AFStateChangedEventListener>();

	protected ServiceStatus serviceStatus = ServiceStatus.UNDER_CONSTRUCTION;;

	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(ServiceStatus newStatus) {
		ServiceStatus oldStatus = this.serviceStatus;
		this.serviceStatus = newStatus;
		logger.info("Status changed: " + serviceStatus + " ("
				+ getComponentID() + ", " + getClass() + ")");
		notifyListenersStatusChanged(oldStatus, newStatus);
	}

	public void addListener(AFStateChangedEventListener l) {
		afStateChangedListeners.add(l);
	}

	private void notifyListenersStatusChanged(ServiceStatus oldS,
			ServiceStatus newS) {
		RuntimeChangedEvent runtimeChangedEv = new RuntimeChangedEvent(
				getComponentID());
		runtimeChangedEv.setOldStatus(oldS);
		runtimeChangedEv.setNewStatus(newS);

		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(runtimeChangedEv);
		}
	}
}
