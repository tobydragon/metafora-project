package de.dfki.lasad.session.data.objects;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Vector;

import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class ActionHistory {

	SortedSet<Action> actionHistory = new TreeSet<Action>(
			new Comparator<Action>() {
				@Override
				public int compare(Action o1, Action o2) {
					Long o1Ts = o1.ts;
					Long o2Ts = o2.ts;
					return o1Ts.compareTo(o2Ts);
				}
			});

	public void addAction(long ts, ActionType actionType,
			UserID manipulatorUserID) {
		Action action = new Action(ts, actionType, manipulatorUserID);
		actionHistory.add(action);
	}

	public List<Action> getActionHistory() {
		return new Vector<Action>(actionHistory);
	}

	@Override
	public String toString() {
		return Arrays.toString(actionHistory.toArray());
	}

	public class Action {

		public final long ts;
		public final ActionType actionType;
		public final UserID manipulatorUserID;

		public Action(long ts, ActionType actionType, UserID manipulatorUserID) {
			this.ts = ts;
			this.actionType = actionType;
			this.manipulatorUserID = manipulatorUserID;
		}

		@Override
		public String toString() {
			return "[" + actionType + ", " + manipulatorUserID + ", " + ts
					+ "]";
		}

	}

	public enum ActionType {
		CREATE, MODIFY, DELETE
	}

}
