package de.dfki.lasad.core.components.description;

import org.jdom.Element;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class BasicDescriptionXML {

	public static BasicDescription fromXML(Element elem) {
		BasicDescription basicDescr = new BasicDescription();

		basicDescr.id = elem.getAttributeValue("id");
		basicDescr.classs = elem.getAttributeValue("class");
		basicDescr.confclass = elem.getAttributeValue("confclass");
		basicDescr.conffile = elem.getAttributeValue("conffile");

		return basicDescr;
	}

	public static Element toXML(String elemName, BasicDescription descr) {

		Element elem = new Element(elemName);
		elem.setAttribute("id", descr.id);
		elem.setAttribute("class", descr.classs);
		if (descr.confclass != null) {
			elem.setAttribute("confclass", descr.confclass);
		}
		if (descr.conffile != null) {
			elem.setAttribute("conffile", descr.conffile);
		}
		return elem;
	}
	
	public static Element toXML(String elemName, AbstractComponentDescription descr) {
		return toXML(elemName, descr.getBasicDescr());
	}
	

}
