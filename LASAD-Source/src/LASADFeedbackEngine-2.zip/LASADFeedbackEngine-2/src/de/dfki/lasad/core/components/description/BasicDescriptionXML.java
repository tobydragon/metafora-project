package de.dfki.lasad.core.components.description;

import lasad.shared.dfki.meta.util.ComponentIDUtil;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.CDATA;
import org.jdom.Element;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class BasicDescriptionXML {

	private static Log logger = LogFactory.getLog(BasicDescriptionXML.class);

	public static BasicDescription fromXML(Element elem) {
		BasicDescription basicDescr = new BasicDescription();
		String id = elem.getAttributeValue("id");

		if (ComponentIDUtil.checkID(id)) {
			basicDescr.id = id;
		} else {
			logger.error(ComponentIDUtil.getErrorMessageInvalidID(id));
			return null;
		}

		Element classElem = elem.getChild("class");
		if (classElem != null) {
			basicDescr.classs = classElem.getText();
		}

		Element confClassElem = elem.getChild("conf-class");
		if (confClassElem != null) {
			basicDescr.confclass = confClassElem.getText();
		}

		Element confFileElem = elem.getChild("conf-file");
		if (confFileElem != null) {
			basicDescr.conffile = confFileElem.getText();
		}

		return basicDescr;
	}

	public static Element toXML(String elemName, BasicDescription descr) {

		Element elem = new Element(elemName);
		elem.setAttribute("id", descr.id);

		if (descr.classs != null) {
			Element classElem = new Element("class");
			CDATA classValue = new CDATA(descr.classs);
			elem.addContent(classElem);
			classElem.addContent(classValue);
		} else {
			logger.error("Description 'class' == null: " + descr.id);
			return null;
		}

		if (descr.confclass != null) {
			Element confClassElem = new Element("conf-class");
			CDATA confClassValue = new CDATA(descr.confclass);
			elem.addContent(confClassElem);
			confClassElem.addContent(confClassValue);
		}

		if (descr.conffile != null) {
			Element confFileElem = new Element("conf-file");
			CDATA confFileValue = new CDATA(descr.conffile);
			elem.addContent(confFileElem);
			confFileElem.addContent(confFileValue);
		}
		return elem;
	}

	public static Element toXML(String elemName,
			AbstractComponentDescription descr) {
		return toXML(elemName, descr.getBasicDescr());
	}

}
