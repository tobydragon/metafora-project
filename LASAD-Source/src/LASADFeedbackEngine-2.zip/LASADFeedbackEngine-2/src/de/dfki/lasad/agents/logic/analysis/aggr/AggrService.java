package de.dfki.lasad.agents.logic.analysis.aggr;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import lasad.shared.communication.objects.Action;
import lasad.shared.dfki.meta.agents.analysis.AnalysisResultDatatype;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterCriterionDef;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterDef;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeGeneral;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeSpecific_Pattern;
import lasad.shared.dfki.meta.agents.analysis.counter.UserSelectionSetting;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.AnalysisResultIDGenerator;
import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.agents.data.analysis.session.SessionBinaryResult;
import de.dfki.lasad.agents.data.analysis.user.UserBinaryResult;
import de.dfki.lasad.agents.logic.analysis.aggr.tasks.AggTask_CounterRecheckInstance;
import de.dfki.lasad.agents.logic.analysis.aggr.tasks.AggTask_HandleUserJoin;
import de.dfki.lasad.agents.logic.analysis.aggr.tasks.AggTask_StartService;
import de.dfki.lasad.agents.logic.analysis.aggr.tasks.AggTask_UpdateCountersOnModelUpdate;
import de.dfki.lasad.events.agents.AnalysisResultsChangedEvent;
import de.dfki.lasad.events.agents.AnalysisResultsChangedEventListener;
import de.dfki.lasad.events.agents.SessionModelChangedEvent;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.UserIDAll;
import de.dfki.lasad.sessionmodel.SessionModel;
import de.dfki.lasad.sessionmodel.SessionModelChangeRecord;

/**
 * Central class in the aggregation subsystem. Manages a set of {@link Counter}
 * s, which count current elements in the workspace (i.e., nodes and links) as
 * well as patterns (i.e., system-generated interpretations of workspace content
 * and user actions). {@link Counter}s are created based on configured
 * {@link CounterAnalysisType}s, which specify counter definitions (i.e., what
 * is counted, see {@link CounterDef}) as well as counter criteria (i.e.,
 * thresholds when a count is meaningful, see {@link CounterCriterionDef}).
 * 
 * <br/>
 * Receives notifications about state changes in the {@link SessionModel} in
 * form of {@link Action}s (when nodes, links or their sub-elements changed, see
 * {@link #onObjectAction}) and {@link AnalysisResult}s (with a flag to indicate
 * creation or deletion, see {@link #onAnalysisResult}). Updates its internal
 * record of {@link CountableInstance}s based on the received notifications.
 * Triggers {@link Counter}s to update counts based on the updated or deleted
 * {@link CountableInstance}s ({@link #updateAllCounters}). If a counter state
 * changed the respective {@link Counter} will provide a notification (
 * {@link #counterChanged}). Each {@link CounterCriterionDef} that is based on a
 * changed {@link Counter} will be rechecked and the {@link SessionModel}
 * informed when a {@link CounterCriterionDef} get fulfilled or is not fulfilled
 * anymore, which triggers the insertion or deletion of {@link AnalysisResult}s,
 * respectively.
 * 
 * <br/>
 * All work done in the counter subsystem is organized in {@link TimerTask}s,
 * which will be executed sequentially or according to a defined schedule in one
 * thread ({@link #timer}). The counter subsystems starts when the method
 * {@link initCountingService} is invoked (a {@link AggTask_StartService} is
 * scheduled then). When receiving notifications about changes in the workspace
 * (i.e., links, nodes, sub-elements are created, modified or deleted) or
 * changed {@link AnalysisResult}s update tasks will be scheduled (
 * {@link AggTask_UpdateCountersOnModelUpdate} or
 * {@link UpdateAnalysisResultsTask}). {@link Counter}s might schedule
 * {@link AggTask_CounterRecheckInstance}s if {@link CountableInstance}s getting
 * "old enough" or "too old" to be counted (see also descriptions in
 * {@link Counter}). Finally, notifications are received when the
 * {@link SessionModel} starts or stops running an analysis (
 * {@link AggTask_ListenerStatusChanged}). When an analysis is currently running
 * ( {@link #listenerReady}), the checking of {@link CounterCriterionDef}s will
 * be delayed until the {@link SessionModel}'s analysis run has concluded.
 * 
 * 
 * <br/>
 * <br/>
 * (see also {@link CounterAnalysisType}, {@link Counter}, {@link Action},
 * {@link AnalysisResult}, {@link CountableInstance})
 * 
 * @author oliverscheuer
 * 
 */
public class AggrService implements AggrServiceInterface {

	private Log logger = LogFactory.getLog(AggrService.class);

	private AnalysisResultsChangedEventListener resultsChangedListener = null;

	protected Map<Counter, Set<UserCounterAnalysisType>> counters2counterTypes = new HashMap<Counter, Set<UserCounterAnalysisType>>();
	protected Map<UserCounterAnalysisType, AnalysisResult> fulfilledCounterConditions = new HashMap<UserCounterAnalysisType, AnalysisResult>();

	// elements will be added / removed / updated on Jess Node / Link events
	private Map<String, CountableInstance> id2object = new HashMap<String, CountableInstance>();

	private Map<String, CountableInstance> id2pattern = new HashMap<String, CountableInstance>();

	private List<CounterAnalysisType> forEachUserCounterTypes = new Vector<CounterAnalysisType>();
	private List<UserID> users = new Vector<UserID>();

	private Timer timer = new Timer(true);

	Set<Counter> countersToCheckConditions = new HashSet<Counter>();

	AggrService(AnalysisResultsChangedEventListener resultsChangedListener,
			List<CounterAnalysisType> aggegrationTypes) {
		this.resultsChangedListener = resultsChangedListener;
		for (CounterAnalysisType aggrType : aggegrationTypes) {
			initAggregationType(aggrType);
		}
	}

	@Override
	public void startAggregationService() {
		// logger.info("Start counting service");
		AggTask_StartService task = new AggTask_StartService(this);
		timer.schedule(task, 0);
	}

	@Override
	public void onSessionModelChanged(SessionModelChangedEvent event) {
		logger.debug("Received session modelchanged event: " + event);
		SessionModelChangeRecord changeRecord = event.getChangeRecord();

		AggTask_UpdateCountersOnModelUpdate task = new AggTask_UpdateCountersOnModelUpdate(
				this, changeRecord);
		timer.schedule(task, 0);
	}

	@Override
	public void onUserJoin(UserID userID) {
		AggTask_HandleUserJoin task = new AggTask_HandleUserJoin(this, userID);
		timer.schedule(task, 0);
	}

	protected void initAggregationType(CounterAnalysisType aggrType) {
		logger.info("Initializing aggregation type ...");
		if (aggrType.getCounterDefinition().getUserSelectionSetting() == UserSelectionSetting.FOREACH) {
			getForEachUserCounterTypes().add(aggrType);
			for (UserID userID : getUsers()) {
				CounterAnalysisType forUser = decomposeForUser(aggrType, userID);
				registerCounterAnalysisTypeDecomposed(forUser);
			}

		} else {
			registerCounterAnalysisTypeDecomposed(aggrType);
		}
		logger.info("Initializing aggregation type ... DONE");
	}

	/**
	 * Preprocesses {@link SessionModelChangeRecord}
	 * 
	 * @param changeRecord
	 * @return
	 */
	public Map<CountableInstance, Boolean> getInstances2IsDeleted(
			SessionModelChangeRecord changeRecord) {
		Map<CountableInstance, Boolean> instances2isDeleted = new HashMap<CountableInstance, Boolean>();

		for (CountableInstance newOrUpdatedInstance : changeRecord
				.getAddOrModifiedInstances()) {
			instances2isDeleted.put(newOrUpdatedInstance, Boolean.FALSE);
		}

		for (String removedInstanceID : changeRecord.getRemovedInstancesIDs()) {
			CountableInstance removedInstance = id2object
					.get(removedInstanceID);
			instances2isDeleted.put(removedInstance, Boolean.TRUE);
		}

		for (AnalysisResult newResult : changeRecord
				.getAddedOrModifiedResults()) {
			CountableInstance newInstance = translateAnalysisResult(newResult,
					false);
			instances2isDeleted.put(newInstance, Boolean.FALSE);
		}

		for (Integer removedResultID : changeRecord.getRemovedResultsIDs()) {
			CountableInstance removedInstance = id2pattern.get(String
					.valueOf(removedResultID));
			instances2isDeleted.put(removedInstance, Boolean.TRUE);
		}
		return instances2isDeleted;
	}

	public List<CounterAnalysisType> getDecomposedAnalysisTypesForNewUser(
			UserID uID) {
		List<CounterAnalysisType> oneUserCounterTypes = new Vector<CounterAnalysisType>();
		for (CounterAnalysisType forEachUserCounterType : getForEachUserCounterTypes()) {
			CounterAnalysisType oneUserCounterType = decomposeForUser(
					forEachUserCounterType, uID);
			oneUserCounterTypes.add(oneUserCounterType);
		}
		return oneUserCounterTypes;
	}

	public CounterAnalysisType decomposeForUser(
			CounterAnalysisType counterAType, UserID userID) {
		CounterDef originalCDef = counterAType.getCounterDefinition();
		CounterDef newCDef = new CounterDef(UserSelectionSetting.ONE,
				userID.getIdAsString(), originalCDef.getUserRoleSetting(),
				originalCDef.getInstanceTypeGeneral(),
				originalCDef.getInstanceTypesSpecific(),
				originalCDef.getMinAgeInSecs(), originalCDef.getMaxAgeInSecs());

		CounterAnalysisType decomposedType = new CounterAnalysisType(
				counterAType.getServiceID(), newCDef,
				counterAType.getCounterCriteria());
		return decomposedType;
	}

	/**
	 * Registers and initializes new {@link Counter} (if counter does not
	 * already exist), and associates {@link Counter} with given
	 * {@link CounterAnalysisType}.
	 * 
	 * @param counterAType
	 *            'decomposed' {@link CounterAnalysisType}, i.e., counter is
	 *            defined for one specific user (
	 *            {@link UserSelectionSetting#ONE}) or does not care about users
	 *            at all ({@link UserSelectionSetting#NONE}), yet, is NOT
	 *            defined for each user ( {@link UserSelectionSetting#FOREACH}).
	 *            If {@link UserSelectionSetting#FOREACH} is specified, the
	 *            counter must be decomposed into counters for each user first
	 *            before this method can be invoked.
	 */
	public void registerCounterAnalysisTypeDecomposed(
			CounterAnalysisType counterAType) {
		String counterName = counterAType.getServiceID() + " ["
				+ counterAType.getCounterDefinition().getUserID() + "]";
		logger.info("Adding counter '" + counterName + "'");
		Counter c = new Counter(counterName,
				counterAType.getCounterDefinition(), this);
		Set<UserCounterAnalysisType> counterTypes = counters2counterTypes
				.get(c);
		if (counterTypes == null) {
			counterTypes = new HashSet<UserCounterAnalysisType>();
			counters2counterTypes.put(c, counterTypes);
		}
		UserID userID;
		if (UserSelectionSetting.ONE == counterAType.getCounterDefinition()
				.getUserSelectionSetting()) {
			userID = new UserID(counterAType.getCounterDefinition().getUserID());
		} else {
			userID = new UserIDAll();
		}
		UserCounterAnalysisType userCounterAnalysis = new UserCounterAnalysisType(
				counterAType, userID);
		counterTypes.add(userCounterAnalysis);
		initCounter(c);
	}

	public void scheduleCounterRecheckInstanceTask(
			AggTask_CounterRecheckInstance task, long delay) {
		timer.schedule(task, delay);
	}

	public void processInstance(CountableInstance instance, boolean deleted) {
		logger.debug("Process instance: " + instance + " / deleted = "
				+ deleted);
		if (deleted) {
			deleteInstance(instance);
			updateAllCounters(instance, true);
		} else {
			addOrUpdateInstance(instance);
			updateAllCounters(instance, false);
		}
	}

	void addOrUpdateInstance(CountableInstance instance) {
		if (instance.typeGeneral == InstanceTypeGeneral.PATTERN) {
			id2pattern.put(instance.instanceID, instance);
		} else {
			id2object.put(instance.instanceID, instance);
		}
	}

	void deleteInstance(CountableInstance instance) {
		if (instance.typeGeneral == InstanceTypeGeneral.PATTERN) {
			id2pattern.remove(instance.instanceID);
		} else {
			id2object.remove(instance.instanceID);
		}
	}

	CountableInstance translateAnalysisResult(AnalysisResult aResult,
			boolean deleted) {
		String instanceID = String.valueOf(aResult.getId());
		CountableInstance instance = new CountableInstance();
		instance.typeGeneral = InstanceTypeGeneral.PATTERN;
		AnalysisType aType = aResult.getAnalysisType();
		instance.typeSpecific = new InstanceTypeSpecific_Pattern(aType
				.getServiceID().getAgentID(), aType.getServiceID().getTypeID());
		instance.instanceID = instanceID;
		instance.creatorID = null;
		if (aResult instanceof ObjectResult) {
			ObjectResult objectResult = (ObjectResult) aResult;
			instance.contributorIDs = objectResult.getContributors();
			instance.lastModTs = objectResult.getLastModificationTime();
		}
		return instance;
	}

	/**
	 * If a {@link Counter} changed conditions defined on that counter must be
	 * re-checked
	 * 
	 * @param changedCounter
	 */
	public void counterChanged(Counter changedCounter) {
		countersToCheckConditions.add(changedCounter);
	}

	public void checkConditionsAndNotify() {
		logger.debug("Checking counter conditions ...");
		AnalysisResultsChangedEvent event = checkConditionsAndPackageResults();
		if (event != null) {
			logger.debug("... condition status changed - TRUE: "
					+ event.toSimpleString());
			notifyListener(event);
		} else {
			logger.debug("... condition status changed - FALSE");
		}
	}

	/**
	 * For all {@link Counter}s that are marked to check its conditions
	 * (re-)check conditions
	 * 
	 * @return {@link AnalysisResultsChangedEvent} or <code>null</code> if no
	 *         results are available
	 */
	public AnalysisResultsChangedEvent checkConditionsAndPackageResults() {
		Set<UserCounterAnalysisType> typesToAdd = new HashSet<UserCounterAnalysisType>();
		Set<UserCounterAnalysisType> typesToRemove = new HashSet<UserCounterAnalysisType>();
		for (Counter changedCounter : this.countersToCheckConditions) {
			Set<UserCounterAnalysisType> counterTypes = counters2counterTypes
					.get(changedCounter);
			int newCount = changedCounter.count;
			for (UserCounterAnalysisType counterType : counterTypes) {
				List<CounterCriterionDef> criteria = counterType.analysisType
						.getCounterCriteria();
				boolean conditionFulfilledNow = true;
				for (CounterCriterionDef criterion : criteria) {
					if (!criterion.isFulfilled(newCount)) {
						conditionFulfilledNow = false;
						break;
					}
				}
				boolean conditionFulfilledBefore = fulfilledCounterConditions
						.containsKey(counterType);

				if (conditionFulfilledNow && !conditionFulfilledBefore) {
					// addResultToSessionModel(counterType);
					typesToAdd.add(counterType);

				} else if (!conditionFulfilledNow && conditionFulfilledBefore) {
					typesToRemove.add(counterType);
				}
			}
		}
		this.countersToCheckConditions.clear();
		if (typesToAdd.isEmpty() && typesToRemove.isEmpty()) {
			// nothing to update
			return null;
		}
		AnalysisResultsChangedEvent updateEvent = packageResults(typesToAdd,
				typesToRemove);
		return updateEvent;
	}

	void updateAllCounters(CountableInstance instance, boolean isDeleted) {
		for (Counter c : counters2counterTypes.keySet()) {
			c.updateCounter(instance, isDeleted);
		}
	}

	void initCounter(Counter c) {
		for (CountableInstance i : this.id2object.values()) {
			c.updateCounter(i, false);
		}
		for (CountableInstance i : this.id2pattern.values()) {
			c.updateCounter(i, false);
		}
		String userID = c.counterDefinition.getUserID();
		if (userID == null) {
			userID = "GROUP";
		}
		logger.info("Counter initialized (" + userID + "): " + c.count);
		// in any case counter conditions must be checked
		this.countersToCheckConditions.add(c);
	}

	private void notifyListener(AnalysisResultsChangedEvent updateEvent) {
		logger.debug("Notify Listener: " + updateEvent.toSimpleString());
		resultsChangedListener.onAnalysisResultsChangedEvent(updateEvent);
	}

	private AnalysisResultsChangedEvent packageResults(
			Set<UserCounterAnalysisType> typesToAdd,
			Set<UserCounterAnalysisType> typesToRemove) {
		AnalysisResultsChangedEvent updateEvent = new AnalysisResultsChangedEvent(
				this.getClass().getSimpleName());
		for (UserCounterAnalysisType toAdd : typesToAdd) {
			AnalysisResult result = null;
			if (AnalysisResultDatatype.user_binary_result == toAdd.analysisType
					.getResultDatatype()) {
				result = new UserBinaryResult(toAdd.analysisType);
				UserBinaryResult userBinResult = (UserBinaryResult) result;
				UserID userID = toAdd.userID;
				userBinResult.setUserID(userID);
				userBinResult.setValue(true);
			} else if (AnalysisResultDatatype.session_binary_result == toAdd.analysisType
					.getResultDatatype()) {
				result = new SessionBinaryResult(toAdd.analysisType);
				SessionBinaryResult sessionBinResult = (SessionBinaryResult) result;
				sessionBinResult.setValue(true);
			} else {
				logger.error("Result type not handled: "
						+ toAdd.analysisType.getResultDatatype());
				return null;
			}
			result.setId(AnalysisResultIDGenerator.getFreshID());
			result.setDetectionTs(System.currentTimeMillis());
			updateEvent.addResultToAdd(result);
			this.fulfilledCounterConditions.put(toAdd, result);
		}
		for (UserCounterAnalysisType toRemove : typesToRemove) {
			AnalysisResult result = this.fulfilledCounterConditions
					.remove(toRemove);
			updateEvent.addResultIDToRemove(result.getId());
		}
		return updateEvent;
	}

	public void purgeTimer() {
		this.timer.purge();
	}

	private void printCountableInstances() {
		logger.debug("Workspace objects");
		for (String id : this.id2object.keySet()) {
			CountableInstance i = id2object.get(id);
			logger.debug(i.toString());
		}
		logger.info("Patterns");
		for (String id : this.id2pattern.keySet()) {
			CountableInstance i = id2pattern.get(id);
			logger.debug(i.toString());
		}
	}

	public void setForEachUserCounterTypes(
			List<CounterAnalysisType> forEachUserCounterTypes) {
		this.forEachUserCounterTypes = forEachUserCounterTypes;
	}

	public List<CounterAnalysisType> getForEachUserCounterTypes() {
		return forEachUserCounterTypes;
	}

	public void setUsers(List<UserID> users) {
		this.users = users;
	}

	public List<UserID> getUsers() {
		return users;
	}

}
