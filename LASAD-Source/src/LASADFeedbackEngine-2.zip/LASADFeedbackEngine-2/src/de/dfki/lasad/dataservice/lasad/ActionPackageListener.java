package de.dfki.lasad.dataservice.lasad;

import lasad.shared.communication.objects.ActionPackage;


public interface ActionPackageListener {

	public static final String DIRECTION_IN = "IN";
	
	public void onActionPackage(ActionPackage actionPackage, Direction direction);
	
	public enum Direction {
	    IN, OUT 
	}
}
