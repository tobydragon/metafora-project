package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.PatternPreprocessor;

/**
 * Print out comparisons after pre-processing to check whether comparison type
 * and id are correct.
 * 
 * @author oliverscheuer
 * 
 */
public class PatternPreprocessorComparisonSupplTest {

	static PatternPreprocessor preprocessor = new PatternPreprocessor(
			TestData.largoOntology);

	static {
		preprocessor.testModePrintIntermediateResults = false;
		preprocessor.testModeOmitSequentialization = false;
	}

	public static void main(String[] args) {
		StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
				.parsePattern(TestData.TESTFILE_INTERNAL_EXTERNAL_COMPARISONS);
		printComparisonIDAndType(pattern.getPattern());
	}

	public static void printComparisonIDAndType(StructuralPattern pattern) {

		preprocessor.preprocess(pattern);
		ComparisonPrinterHelper.printAllComparisons(pattern);
	}

}
