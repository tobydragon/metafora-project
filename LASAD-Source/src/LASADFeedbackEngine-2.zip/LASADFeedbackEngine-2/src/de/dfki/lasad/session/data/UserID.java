package de.dfki.lasad.session.data;


public class UserID extends EUEID {

	public UserID(String id) {
		super(id);
	}

}
