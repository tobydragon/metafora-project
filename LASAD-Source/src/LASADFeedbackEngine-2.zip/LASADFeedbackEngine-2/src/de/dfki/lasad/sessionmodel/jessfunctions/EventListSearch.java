package de.dfki.lasad.sessionmodel.jessfunctions;

import java.util.ArrayList;

import jess.Context;
import jess.JessException;
import jess.RU;
import jess.Userfunction;
import jess.Value;
import jess.ValueVector;

/**
 * Filters an object list according to specific criteria including ts, user,
 * general type (node, link) and specific type (based on ontology). The
 * attribute values of all objects are provided in separate lists. The ordering
 * of objects and attributes has to be identical (e.g., the 5th user is
 * associated with the 5th object). Two modes of filtering are supported:
 * inclusive and exclusive filtering.
 * 
 * Example use: 
 * (elist-search $?objects ?minTs ?maxTs $?tss 
 *               ?userFilterMode $?users $?userFilterList 
 *               ?generalTypeFilterMode $?generalTypes $?generalTypeFilterList 
 *               ?specificTypeFilterMode $?specificTypes $?specificTypeFilterList))
 * 
 * @author oliverscheuer
 */
public class EventListSearch implements Userfunction {

	public static final String MODE_INCLUDE = "include";
	public static final String MODE_EXCLUDE = "exclude";

	/** Create a new EventListSearch user function object */
	public EventListSearch() {
		super();
	}

	/**
	 * Get the name of the elist-search user function
	 * 
	 * @see jess.Userfunction#getName()
	 */
	public String getName() {
		return "elist-search";
	}

	/**
	 * Call the elist-search Value user function
	 * 
	 * @see jess.Userfunction#call(jess.ValueVector, jess.Context)
	 */
	public Value call(ValueVector vv, final Context context)
			throws JessException {
		if (vv.size() != 14) {
			throw new JessException(getName(), " invalid number of arguments",
					vv.size() - 1);
		}

		Value objectListAsValue = vv.get(1).resolveValue(context);
		ValueVector objects = objectListAsValue.listValue(context);

		Value minTsAsValue = vv.get(2).resolveValue(context);
		long minTs = minTsAsValue.longValue(context);

		Value maxTsAsValue = vv.get(3).resolveValue(context);
		long maxTs = maxTsAsValue.longValue(context);

		Value tsListAsValue = vv.get(4).resolveValue(context);
		ValueVector tss = tsListAsValue.listValue(context);

		Value userFilterModeAsValue = vv.get(5).resolveValue(context);
		String userFilterMode = userFilterModeAsValue.stringValue(context);

		Value userListAsValue = vv.get(6).resolveValue(context);
		ValueVector users = userListAsValue.listValue(context);

		Value userFilterListAsValue = vv.get(7).resolveValue(context);
		ValueVector userFilterList = userFilterListAsValue.listValue(context);

		Value generalTypeFilterModeAsValue = vv.get(8).resolveValue(context);
		String generalTypeFilterMode = generalTypeFilterModeAsValue
				.stringValue(context);

		Value generalTypeListAsValue = vv.get(9).resolveValue(context);
		ValueVector generalTypes = generalTypeListAsValue.listValue(context);

		Value generalTypeFilterListAsValue = vv.get(10).resolveValue(context);
		ValueVector generalTypeFilterList = generalTypeFilterListAsValue
				.listValue(context);

		Value specificTypeFilterModeAsValue = vv.get(11).resolveValue(context);
		String specificTypeFilterMode = specificTypeFilterModeAsValue
				.stringValue(context);

		Value specificTypeListAsValue = vv.get(12).resolveValue(context);
		ValueVector specificTypes = specificTypeListAsValue.listValue(context);

		Value specificTypeFilterListAsValue = vv.get(13).resolveValue(context);
		ValueVector specificTypeFilterList = specificTypeFilterListAsValue
				.listValue(context);

		ArrayList<ValueVector> valueListsIncl = new ArrayList<ValueVector>();
		ArrayList<ValueVector> valueListsExcl = new ArrayList<ValueVector>();
		ArrayList<ValueVector> filterListsIncl = new ArrayList<ValueVector>();
		ArrayList<ValueVector> filterListsExcl = new ArrayList<ValueVector>();

		if (MODE_INCLUDE.equalsIgnoreCase(userFilterMode)) {
			valueListsIncl.add(users);
			filterListsIncl.add(userFilterList);
		} else if (MODE_EXCLUDE.equalsIgnoreCase(userFilterMode)) {
			valueListsExcl.add(users);
			filterListsExcl.add(userFilterList);
		}

		if (MODE_INCLUDE.equalsIgnoreCase(generalTypeFilterMode)) {
			valueListsIncl.add(generalTypes);
			filterListsIncl.add(generalTypeFilterList);
		} else if (MODE_EXCLUDE.equalsIgnoreCase(generalTypeFilterMode)) {
			valueListsExcl.add(generalTypes);
			filterListsExcl.add(generalTypeFilterList);
		}

		if (MODE_INCLUDE.equalsIgnoreCase(specificTypeFilterMode)) {
			valueListsIncl.add(specificTypes);
			filterListsIncl.add(specificTypeFilterList);
		} else if (MODE_EXCLUDE.equalsIgnoreCase(specificTypeFilterMode)) {
			valueListsExcl.add(specificTypes);
			filterListsExcl.add(specificTypeFilterList);
		}

		ValueVector filterResult = filter(objects, tss, minTs, maxTs,
				valueListsIncl, filterListsIncl, valueListsExcl,
				filterListsExcl, context);

		return new Value(filterResult, RU.LIST);
	}

	private ValueVector filter(ValueVector objects, ValueVector tss,
			long minTs, long maxTs, ArrayList<ValueVector> valueListsIncl,
			ArrayList<ValueVector> filterListsIncl,
			ArrayList<ValueVector> valueListsExcl,
			ArrayList<ValueVector> filterListsExcl, final Context context)
			throws JessException {

		ValueVector matchedObjects = new ValueVector();

		// no ts filter
		if (minTs == -1 && maxTs == -1) {
			for (int i = 0; i < objects.size(); ++i) {
				boolean inclObject = true;
				for (int j = 0; j < valueListsIncl.size(); ++j) {
					if (!filterListsIncl.get(j).contains(
							valueListsIncl.get(j).get(i))) {
						inclObject = false;
						break;
					}
				}
				// test whether object satisfies include lists -> test exclude
				// lists
				if (inclObject) {
					for (int j = 0; j < valueListsExcl.size(); ++j) {
						if (filterListsExcl.get(j).contains(
								valueListsExcl.get(j).get(i))) {
							inclObject = false;
							break;
						}
					}
				}
				// test whether object satisfies include lists and exclude lists
				if (inclObject) {
					matchedObjects.add(objects.get(i));
				}
			}
			return matchedObjects;
		}

		else if (minTs > -1 && maxTs == -1) {
			for (int i = 0; i < objects.size(); ++i) {
				boolean inclObject = true;

				if (tss.get(i).longValue(context) < minTs) {
					inclObject = false;
				}

				// test whether object satisfies minTs condition -> test include
				// and exclude lists
				if (inclObject) {
					for (int j = 0; j < valueListsIncl.size(); ++j) {
						if (!filterListsIncl.get(j).contains(
								valueListsIncl.get(j).get(i))) {
							inclObject = false;
							break;
						}
					}
					// test whether object satisfies include lists -> test
					// exclude lists
					if (inclObject) {
						for (int j = 0; j < valueListsExcl.size(); ++j) {
							if (filterListsExcl.get(j).contains(
									valueListsExcl.get(j).get(i))) {
								inclObject = false;
								break;
							}
						}
					}
				}
				// test whether object satisfies include lists, exclude lists
				// and ts conditions
				if (inclObject) {
					matchedObjects.add(objects.get(i));
				}
			}
			return matchedObjects;

		} else if (minTs == -1 && maxTs > -1) {
			for (int i = 0; i < objects.size(); ++i) {
				boolean inclObject = true;

				if (tss.get(i).longValue(context) > maxTs) {
					inclObject = false;
				}

				// test whether object satisfies maxTs condition -> test include
				// and exclude lists
				if (inclObject) {
					for (int j = 0; j < valueListsIncl.size(); ++j) {
						if (!filterListsIncl.get(j).contains(
								valueListsIncl.get(j).get(i))) {
							inclObject = false;
							break;
						}
					}
					// test whether object satisfies include lists -> test
					// exclude lists
					if (inclObject) {
						for (int j = 0; j < valueListsExcl.size(); ++j) {
							if (filterListsExcl.get(j).contains(
									valueListsExcl.get(j).get(i))) {
								inclObject = false;
								break;
							}
						}
					}
				}
				// test whether object satisfies include lists, exclude lists
				// and ts conditions
				if (inclObject) {
					matchedObjects.add(objects.get(i));
				}
			}

			return matchedObjects;

		} else { // min and max ts defined
			for (int i = 0; i < objects.size(); ++i) {
				boolean inclObject = true;

				long ts = tss.get(i).longValue(context);
				if (ts < minTs || ts > maxTs) {
					inclObject = false;
				}

				// test whether object satisfies maxTs condition -> test include
				// and exclude lists
				if (inclObject) {
					for (int j = 0; j < valueListsIncl.size(); ++j) {
						if (!filterListsIncl.get(j).contains(
								valueListsIncl.get(j).get(i))) {
							inclObject = false;
							break;
						}
					}
					// test whether object satisfies include lists -> test
					// exclude lists
					if (inclObject) {
						for (int j = 0; j < valueListsExcl.size(); ++j) {
							if (filterListsExcl.get(j).contains(
									valueListsExcl.get(j).get(i))) {
								inclObject = false;
								break;
							}
						}
					}
				}
				// test whether object satisfies include lists, exclude lists
				// and ts conditions
				if (inclObject) {
					matchedObjects.add(objects.get(i));
				}
			}

			return matchedObjects;
		}
	}

}
