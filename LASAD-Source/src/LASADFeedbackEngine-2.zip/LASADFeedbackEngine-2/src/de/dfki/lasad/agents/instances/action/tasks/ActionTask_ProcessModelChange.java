package de.dfki.lasad.agents.instances.action.tasks;

import de.dfki.lasad.agents.instances.action.ActionAgent;
import de.dfki.lasad.sessionmodel.SessionModelChangeRecord;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ActionTask_ProcessModelChange extends ActionTask {

	private ActionAgent agent = null;
	private SessionModelChangeRecord changeRecord = null;

	public ActionTask_ProcessModelChange(ActionAgent agent,
			SessionModelChangeRecord changeRecord) {
		this.agent = agent;
		this.changeRecord = changeRecord;
	}

	@Override
	public void run() {
		agent.processModelChanged(changeRecord);
	}
}
