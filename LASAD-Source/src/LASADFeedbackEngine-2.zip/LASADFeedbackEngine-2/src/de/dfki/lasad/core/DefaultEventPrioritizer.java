package de.dfki.lasad.core;

import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.events.agents.AnalysisResultsProvisionEvent;
import de.dfki.lasad.events.eue.admin.EUEAdminEvent;
import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;
import de.dfki.lasad.events.eue.admin.config.EUEConfigInfoEvent;
import de.dfki.lasad.events.eue.admin.config.OntologyListEvent;
import de.dfki.lasad.events.eue.admin.config.SessionListEvent;
import de.dfki.lasad.events.eue.admin.session.EUESessionInfoEvent;
import de.dfki.lasad.events.eue.user.UserEvent;

/**
 * Assigns priority values to {@link EventImpl}s that are used to determine the
 * order of processing.
 * 
 * @author Zeshan
 */
public class DefaultEventPrioritizer {
	public static final int PRIORITY_HIGHEST = 6;
	public static final int PRIORITY_VERY_HIGH = 5;
	public static final int PRIORITY_HIGH = 4;
	public static final int PRIORITY_MEDIUM = 3;
	public static final int PRIORITY_LOW = 2;

	public static void assignPriority(Event event) {
		if (event instanceof SessionListEvent) {
			event.setEventPriority(PRIORITY_HIGHEST);
		} else if (event instanceof OntologyListEvent) {
			event.setEventPriority(PRIORITY_HIGHEST);
		} else if (event instanceof EUEConfigInfoEvent) {
			event.setEventPriority(PRIORITY_VERY_HIGH);
		} else if (event instanceof EUESessionInfoEvent) {
			event.setEventPriority(PRIORITY_VERY_HIGH);
		} else if (event instanceof UserEvent) {
			event.setEventPriority(PRIORITY_HIGH);
		} else if (event instanceof ActionSpecEvent) {
			event.setEventPriority(PRIORITY_MEDIUM);
		} else if (event instanceof AnalysisResultsProvisionEvent) {
			event.setEventPriority(PRIORITY_LOW);
		} else if (event instanceof EUEAgentAdminEvent) {
			event.setEventPriority(PRIORITY_LOW);
		}
	}

}