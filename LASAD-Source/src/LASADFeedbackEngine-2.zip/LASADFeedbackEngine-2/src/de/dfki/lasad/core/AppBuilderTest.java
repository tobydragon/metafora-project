package de.dfki.lasad.core;

import junit.framework.TestCase;

/**
 * 
 * @author oliverscheuer
 *
 */
public class AppBuilderTest extends TestCase {

	public void testBuildApp(){
		AppBuilder appBuilder = new AppBuilder();
		appBuilder.doWire();
	}
	
}
