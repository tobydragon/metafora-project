package de.dfki.lasad.agents.logic.analysis.types.structure.translator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableManager;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.agents.analysis.structure.model.LinkVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.NodeVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import lasad.shared.dfki.meta.agents.analysis.structure.model.VariableComparison;
import lasad.shared.dfki.meta.ontology.Ontology;

/**
 * Re-orders elements (nodes and links) within a pattern to obtain an "optimal"
 * sequence. For details, see method
 * {@link #sequentializeVariables(StructuralPattern)}
 * 
 * @author oliverscheuer
 * 
 */
public class PatternPreprocessorSequentializer {

	private static final Log logger = LogFactory
			.getLog(PatternPreprocessorSequentializer.class);

	public static boolean testModePrintIntermediateResults = false;

	public static final int PREDECESSOR_SEQ_NUM = -1;

	private static final int a = 1, b = 1, c = 1;

	private static final int IN_NEIGBOR_INDEX = 0;
	private static final int OUT_NEIGBOR_INDEX = 1;
	private static final int NEIGBOR_INDEX = 2;

	private Ontology ontology = null;

	public PatternPreprocessorSequentializer(Ontology ontology,
			boolean testModePrintIntermediateResults) {
		this(ontology);
		this.testModePrintIntermediateResults = testModePrintIntermediateResults;
	}

	public PatternPreprocessorSequentializer(Ontology ontology) {
		this.ontology = ontology;
	}

	/**
	 * Re-orders elements (nodes and links) within a pattern to obtain an
	 * "optimal" sequence. "Optimal" means putting more constrained elements
	 * early in the the sequence and less constrained ones at the end. The
	 * rationale is to minimize the number of possible matches as early as
	 * possible when processing the elements of the pattern. The method moreover
	 * ensures, and considers in its calculations, that elements only can
	 * reference elements that have already been defined, i.e., elements that
	 * occur earlier in the sequence. Therefore, constraints may be re-arranged
	 * to meet this condition in a way that maintains the semantics of the
	 * pattern. More specifically, if a constraint of an "early" element
	 * references a "later" element, this constraint must be detached from the
	 * "early" element, "inverted," and attached to the "later."
	 */
	public void sequentializeVariables(StructuralPattern pattern,
			List<? extends ElementVariable> predecessorElems) {
		moveConstraintsFromNodesToLinks(pattern);
		reorderNodes(pattern, predecessorElems);

		List<ElementVariable> predecessorElemsNew = new Vector<ElementVariable>();
		predecessorElemsNew.addAll(predecessorElems);
		predecessorElemsNew.addAll(pattern.getNodeVars());
		reorderLinks(pattern, predecessorElemsNew);
	}

	/**
	 * 
	 * @param pattern
	 *            {@link StructuralPattern} whose {@link NodeVariable} sequence
	 *            will be reordered
	 * @param predecessorElems
	 *            {@link ElementVariable}s already used, i.e., ones that are
	 *            allowed to be referenced by the given {@link NodeVariable}s
	 */
	private void reorderNodes(StructuralPattern pattern,
			List<? extends ElementVariable> predecessorElems) {
		List<ElementVariable> originalSequence = new ArrayList<ElementVariable>(
				pattern.getNodeVars());

		List<List<ElementVariable>> permutations = buildPossiblePermutations(originalSequence);

		int optimalPermutationIndex = computeIndexOptimalPermutation(
				permutations, pattern.getLinkVars(), predecessorElems);

		List<ElementVariable> optimalPermutation = permutations
				.get(optimalPermutationIndex);
		adjustConstraints(optimalPermutation, predecessorElems);
		setNodeVars(pattern, optimalPermutation);
	}

	/**
	 * 
	 * @param pattern
	 *            {@link StructuralPattern} whose {@link LinkVariable} sequence
	 *            will be reordered
	 * @param predecessorElems
	 *            {@link ElementVariable}s already used, i.e., ones that are
	 *            allowed to be referenced by the given {@link LinkVariable}s
	 */

	private void reorderLinks(StructuralPattern pattern,
			List<? extends ElementVariable> predecessorElems) {
		List<ElementVariable> originalSequence = new ArrayList<ElementVariable>(
				pattern.getLinkVars());
		List<List<ElementVariable>> permutations = buildPossiblePermutations(originalSequence);

		// IGNORE links between links
		List<LinkVariable> links = new Vector<LinkVariable>();
		int optimalPermutationIndex = computeIndexOptimalPermutation(
				permutations, links, predecessorElems);

		List<ElementVariable> optimalPermutation = permutations
				.get(optimalPermutationIndex);
		adjustConstraints(optimalPermutation, predecessorElems);
		setLinkVars(pattern, optimalPermutation);
	}

	private void setNodeVars(StructuralPattern pattern,
			List<ElementVariable> elemVars) {
		List<NodeVariable> nodeVars = new ArrayList<NodeVariable>();
		for (ElementVariable elemVar : elemVars) {
			nodeVars.add((NodeVariable) elemVar);
		}
		pattern.setNodeVars(nodeVars);
	}

	private void setLinkVars(StructuralPattern pattern,
			List<ElementVariable> elemVars) {
		List<LinkVariable> linkVars = new ArrayList<LinkVariable>();
		for (ElementVariable elemVar : elemVars) {
			linkVars.add((LinkVariable) elemVar);
		}
		pattern.setLinkVars(linkVars);
	}

	/**
	 * For each {@link NodeVariable}, remove all constraints that reference a
	 * {@link LinkVariable} "on the same level" (i.e., the link variable is not
	 * part of some super-ordinate pattern), invert these constraints, and add
	 * them to the corresponding {@link LinkVariable}.
	 * 
	 * 
	 * This operation is useful when {@link NodeVariable}s will be processed
	 * before {@link LinkVariable}s. (Remember, {@link ElementVariable}s are
	 * only allowed to reference {@link ElementVariable}s processed before).
	 */
	private void moveConstraintsFromNodesToLinks(StructuralPattern pattern) {
		Map<ElementVariable, List<Comparison>> linkVar2ComparisonsToAdd = new HashMap<ElementVariable, List<Comparison>>();
		for (NodeVariable nodeVar : pattern.getNodeVars()) {
			for (Comparison c : nodeVar.getComparisons()) {
				if (c instanceof VariableComparison) {
					VariableComparison varComp = (VariableComparison) c;
					ElementVariableProp rightExpr = varComp.getRightExpr();
					ElementVariable rightElemVar = rightExpr.getElementVar();
					if (rightElemVar instanceof LinkVariable) {
						// check whether link is "on the same level" (and not
						// part of some super-ordinate pattern)
						if (pattern.getLinkVars().contains(rightElemVar)) {
							VariableComparison inverseComparison = varComp
									.getInverse();
							List<Comparison> comparisonsToAdd = linkVar2ComparisonsToAdd
									.get(rightElemVar);
							if (comparisonsToAdd == null) {
								comparisonsToAdd = new ArrayList<Comparison>();
								linkVar2ComparisonsToAdd.put(rightElemVar,
										comparisonsToAdd);
							}
							comparisonsToAdd.add(inverseComparison);
							nodeVar.removeComparisonIfExists(c);
						}
					}
				}
			}
		}
		for (LinkVariable linkVar : pattern.getLinkVars()) {
			if (linkVar2ComparisonsToAdd.containsKey(linkVar)) {
				List<Comparison> comparisonsToMove = linkVar2ComparisonsToAdd
						.get(linkVar);
				for (Comparison comparison : comparisonsToMove) {
					linkVar.addComparisonIfNotExists(comparison);
				}
			}
		}
	}

	/**
	 * Determines an "efficiency_score" for each provided element sequence and
	 * returns the index of the optimal permutation.
	 * 
	 * @param permutations
	 *            element sequences
	 * @param linkVars
	 *            links between sequence elements (define "neighbor"
	 *            relationships between elements, i.e., further constraints that
	 *            are considered in the computation of optimality)
	 * @param predecessorElems
	 *            {@link ElementVariable}s already used, i.e., ones that are
	 *            allowed to be referenced by the given sequences
	 */
	private int computeIndexOptimalPermutation(
			List<List<ElementVariable>> permutations,
			List<LinkVariable> linkVars,
			List<? extends ElementVariable> predecessorElems) {
		double optimalEfficiencyScore = 0;
		int optimalSequence = 0;

		for (int i = 0; i < permutations.size(); i++) {
			List<ElementVariable> sequence = permutations.get(i);
			adjustConstraints(sequence, predecessorElems);
			// determine number of addition neighbor constraints if applicable
			Map<ElementVariable, Integer[]> elem2countVector = getNeighborCounts(
					sequence, linkVars);

			double efficiencyScore = computeEfficiencyScore(sequence,
					elem2countVector);

			if (efficiencyScore > optimalEfficiencyScore) {
				optimalEfficiencyScore = efficiencyScore;
				optimalSequence = i;
			}
		}

		return optimalSequence;
	}

	/**
	 * For each {@link ElementVariable}, remove all constraints that reference a
	 * later {@link ElementVariable}, invert these constraints, and add them to
	 * the later {@link ElementVariable}.
	 * 
	 * 
	 * @param sequence
	 *            {@link ElementVariable} to be adjusted
	 * @param predecessorElems
	 *            {@link ElementVariable}s already used, i.e., ones that are
	 *            allowed to be referenced by the given sequences
	 */
	private void adjustConstraints(List<? extends ElementVariable> sequence,
			List<? extends ElementVariable> predecessorElems) {
		Set<ElementVariable> visited = new HashSet<ElementVariable>();
		visited.addAll(predecessorElems);

		Map<ElementVariable, List<Comparison>> elemVar2compsToAdd = new HashMap<ElementVariable, List<Comparison>>();

		// Gather comparisons with nodes later in the sequence
		for (ElementVariable elemVar : sequence) {
			visited.add(elemVar);

			for (Comparison comp : elemVar.getComparisons()) {
				if (comp instanceof VariableComparison) {
					VariableComparison varComp = (VariableComparison) comp;
					ElementVariable rightExprElem = varComp.getRightExpr()
							.getElementVar();
					boolean notYetVisited = !visited.contains(rightExprElem);
					if (notYetVisited) {

						Comparison inverseComparison = varComp.getInverse();
						List<Comparison> compsToAdd = elemVar2compsToAdd
								.get(rightExprElem);
						if (compsToAdd == null) {
							compsToAdd = new Vector<Comparison>();
							elemVar2compsToAdd.put(rightExprElem, compsToAdd);
						}
						compsToAdd.add(inverseComparison);
						elemVar.removeComparisonIfExists(comp);
					}
				}
			}
		}

		// Add gathered comparisons to that later nodes
		for (ElementVariable elemVar : sequence) {
			if (elemVar2compsToAdd.containsKey(elemVar)) {
				List<Comparison> compsToAdd = elemVar2compsToAdd.get(elemVar);
				for (Comparison compToAdd : compsToAdd) {
					elemVar.addComparisonIfNotExists(compToAdd);
				}
			}
		}
	}

	/**
	 * Returns efficiency score for given sequence
	 * 
	 * @param sequence
	 *            {@link ElementVariable} sequence for which the score is
	 *            computed. The constraints used within the sequence are already
	 *            "adjusted." (Remember, {@link ElementVariable}s are only
	 *            allowed to reference {@link ElementVariable}s earlier in the
	 *            sequence).
	 * @param elem2countVector
	 *            for each {@link ElementVariable} the number of "in-neighbors,"
	 *            "out-neighbors," and "neighbors"
	 */
	private double computeEfficiencyScore(List<ElementVariable> sequence,
			Map<ElementVariable, Integer[]> elem2countVector) {
		double efficiency = 0;

		printDebugMessageIfEnabled(elemSequence2String(sequence));
		for (int j = 0; j < sequence.size(); j++) {
			int neighborfactor = 0, constpropfactor = 0, varpropfactor = 0;
			ElementVariable elemVar = sequence.get(j);
			Integer[] countVector = elem2countVector.get(elemVar);

			if (countVector != null) {
				neighborfactor = countVector[IN_NEIGBOR_INDEX]
						+ countVector[OUT_NEIGBOR_INDEX]
						+ countVector[NEIGBOR_INDEX];
			}

			// variable and constant comparisons
			for (Comparison comp : elemVar.getComparisons()) {
				if (comp instanceof VariableComparison) {
					varpropfactor++;
				} else {
					constpropfactor++;
				}
			}
			int constrfactor = a * neighborfactor + b * constpropfactor + c
					* varpropfactor;
			printDebugMessageIfEnabled("[" + elemVar.getVarID() + "] "
					+ "overall-constr-factor=" + constrfactor
					+ ", neighborfactor=" + neighborfactor
					+ ", constpropfactor=" + constpropfactor
					+ ", varpropfactor=" + varpropfactor);

			efficiency += Math.pow(0.5, j) * constrfactor;
		}

		printDebugMessageIfEnabled("efficiency=" + efficiency);
		return efficiency;
	}

	private static void printDebugMessageIfEnabled(String message) {
		if (testModePrintIntermediateResults) {
			logger.debug(message);
		}
	}

	private List<List<ElementVariable>> buildPossiblePermutations(
			List<ElementVariable> elemVars) {
		List<List<ElementVariable>> permutationList = new ArrayList<List<ElementVariable>>();
		boolean used[] = new boolean[elemVars.size()];
		List<ElementVariable> empty = new ArrayList<ElementVariable>();
		permuteElements(0, empty, used, elemVars, permutationList);

		return permutationList;
	}

	private void permuteElements(int level,
			List<ElementVariable> permutationInProgress, boolean[] used,
			List<ElementVariable> originalSequence,
			List<List<ElementVariable>> permutations) {
		int length = originalSequence.size();
		boolean permutationComplete = (level == length);
		if (permutationComplete) {
			// permutation complete
			List<ElementVariable> completePermutation = new ArrayList<ElementVariable>();
			completePermutation.addAll(permutationInProgress);
			permutations.add(completePermutation);
		} else {
			for (int i = 0; i < length; i++) {
				if (!used[i]) {
					used[i] = true;
					permutationInProgress.add(originalSequence.get(i));
					permuteElements(level + 1, permutationInProgress, used,
							originalSequence, permutations);
					used[i] = false;
					permutationInProgress
							.remove(permutationInProgress.size() - 1);
				}
			}
		}
	}

	private Map<ElementVariable, Integer[]> getNeighborCounts(
			List<? extends ElementVariable> elemVars,
			List<LinkVariable> linkVars) {

		Map<ElementVariable, Integer[]> var2countVector = new HashMap<ElementVariable, Integer[]>();
		for (ElementVariable nodeVar : elemVars) {
			Integer[] countVector = new Integer[3];
			countVector[IN_NEIGBOR_INDEX] = 0;
			countVector[OUT_NEIGBOR_INDEX] = 0;
			countVector[NEIGBOR_INDEX] = 0;
			var2countVector.put(nodeVar, countVector);
		}

		// Store position of a node in a given sequence
		Map<String, Integer> elemID2seqNum = new HashMap<String, Integer>();
		for (int i = 0; i < elemVars.size(); i++) {
			ElementVariable nodeVar = elemVars.get(i);
			elemID2seqNum.put(nodeVar.getVarID(), i);
		}

		// Count neighbor constraint for node later in the sequence
		// i.e. the one with a higher sequence number
		for (LinkVariable linkVar : linkVars) {
			String sourceId = linkVar.getSource().getVarID();
			String targetId = linkVar.getTarget().getVarID();

			Integer sourceSeqNum = elemID2seqNum.get(sourceId);
			Integer targetSeqNum = elemID2seqNum.get(targetId);

			if (sourceSeqNum == null) {
				// assumption: link source is predecessor
				sourceSeqNum = PREDECESSOR_SEQ_NUM;
			}

			if (targetSeqNum == null) {
				// assumption: link target is predecessor
				targetSeqNum = PREDECESSOR_SEQ_NUM;
			}

			ElementVariable elemToAddNeighbors;
			boolean addNeighborsToSource;
			if (sourceSeqNum > targetSeqNum) {
				elemToAddNeighbors = elemVars.get(sourceSeqNum);
				addNeighborsToSource = true;
			} else {
				elemToAddNeighbors = elemVars.get(targetSeqNum);
				addNeighborsToSource = false;
			}

			Integer[] countVector = var2countVector.get(elemToAddNeighbors);
			if (linkVar.getDirectionMatters()) {
				if (addNeighborsToSource) {
					// add out-link to link source
					++countVector[OUT_NEIGBOR_INDEX];
				} else {
					// add in-link to link target
					++countVector[IN_NEIGBOR_INDEX];
				}
			} else {
				++countVector[NEIGBOR_INDEX];
			}
		}
		return var2countVector;
	}

	public static void main(String[] args) {
		PatternPreprocessorSequentializer pps = new PatternPreprocessorSequentializer(
				null);
		pps.testPermutationGeneration();
	}

	void testPermutationGeneration() {

		List<ElementVariable> original = new Vector<ElementVariable>();
		ElementVariableManager elemVarManager = new ElementVariableManager();

		int seqLength = 8;
		for (int i = 1; i <= seqLength; ++i) {
			int prefixLength = ("" + seqLength).length() - ("" + i).length();

			StringBuffer prefixBuf = new StringBuffer();
			for (int j = 0; j < prefixLength; ++j) {
				prefixBuf.append("0");
			}
			NodeVariable nodeVar;
			nodeVar = elemVarManager.createNodeVar(prefixBuf.toString() + i);
			original.add(nodeVar);
		}

		List<List<ElementVariable>> permutations = buildPossiblePermutations(original);
		printPermutations(permutations);

		// to check whether test code is ok
		// List<ElementVariable> duplicate = new Vector<ElementVariable>();
		// dublicate.addAll(original);
		// permutations.add(duplicate);

		int expNumResults = factorial(seqLength);
		int actualNumResults = permutations.size();
		boolean correctNumPermutations = (expNumResults == actualNumResults);

		boolean permutationsSizesOK = true;
		boolean permutationsContainAllNodes = true;
		for (List<ElementVariable> permutation : permutations) {
			if (permutation.size() != seqLength) {
				permutationsSizesOK = false;
			}
			for (ElementVariable elemVar : original) {
				if (!permutation.contains(elemVar)) {
					permutationsContainAllNodes = false;
				}
			}
		}
		Set<List<ElementVariable>> permutationSet = new HashSet<List<ElementVariable>>(
				permutations);
		boolean noDuplicatePermutation = permutationSet.size() == permutations
				.size();

		System.out.println("correctNumPermutations: " + correctNumPermutations);
		System.out.println("permutationsSizesOK: " + permutationsSizesOK);
		System.out.println("permutationsContainAllNodes: "
				+ permutationsContainAllNodes);
		System.out.println("noDuplicatePermutation: " + noDuplicatePermutation);

	}

	void printPermutations(List<List<ElementVariable>> permutations) {
		Iterator<List<ElementVariable>> permutationIter = permutations
				.iterator();
		int i = 1;
		for (; permutationIter.hasNext(); ++i) {
			List<ElementVariable> permutation = permutationIter.next();
			int prefixLength = ("" + permutations.size()).length()
					- ("" + i).length();

			StringBuffer prefixBuf = new StringBuffer();
			for (int j = 0; j < prefixLength; ++j) {
				prefixBuf.append("0");
			}

			System.out.print("" + prefixBuf.toString() + i + "]] ");

			for (ElementVariable elemVar : permutation) {
				System.out.print(elemVar.getVarID() + ", ");
			}
			System.out.println("");
		}
	}

	String elemSequence2String(List<ElementVariable> elems) {
		StringBuffer buf = new StringBuffer();
		buf.append("[");
		Iterator<ElementVariable> iter = elems.iterator();
		for (; iter.hasNext();) {
			ElementVariable elem = iter.next();
			buf.append(elem.getVarID());
			buf.append("/");
			buf.append(elem instanceof NodeVariable ? "n" : "l");
			if (iter.hasNext()) {
				buf.append(", ");
			}
		}
		buf.append("]");
		return buf.toString();
	}

	static int factorial(int n) {
		int fact = 1; // this will be the result
		for (int i = 1; i <= n; i++) {
			fact *= i;
		}
		return fact;
	}
}
