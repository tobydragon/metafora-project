package de.dfki.lasad.events.eue.admin;

import de.dfki.lasad.events.eue.EUEEvent;

/**
 * Event regarding the administration of the EUE.
 * 
 * @author oliverscheuer
 *
 */
public interface EUEAdminEvent extends EUEEvent{

}
