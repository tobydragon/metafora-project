package de.dfki.lasad.authoring.model.pattern;

import de.dfki.lasad.authoring.converter.pattern2jess.ComparisonType;

/**
 * Represents a comparison of a variable and some RHS expression.
 * {@link Comparison}s are used to constrain the set of possible property values
 * of some {@link ElementVariable}.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public abstract class Comparison {

	// standard fields
	private PropertyVariable leftExpr;

	// supplemental fields
	private ComparisonType type;
	private int id;

	public PropertyVariable getLeftExpr() {
		return leftExpr;
	}

	public void setLeftExpr(PropertyVariable leftExpr) {
		this.leftExpr = leftExpr;
	}

	public ComparisonType getType() {
		return type;
	}

	public void setType(ComparisonType type) {
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public abstract Operator getOperator();

}
