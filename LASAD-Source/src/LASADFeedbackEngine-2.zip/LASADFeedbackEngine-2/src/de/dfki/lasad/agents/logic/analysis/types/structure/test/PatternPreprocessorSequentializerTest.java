package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import java.io.File;
import java.util.List;

import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.PatternPreprocessor;

/**
 * 
 * Determines whether element sequences after preprocessing are correct (i.e.,
 * only references to 'predecessors' exist) and semantically equivalent to the
 * original sequence (i.e., same instances will be matched).
 * 
 * @author oliverscheuer
 * 
 */
public class PatternPreprocessorSequentializerTest {

	static PatternPreprocessor preprocessor = new PatternPreprocessor(
			TestData.largoOntology);

	static {
		preprocessor.testModePrintIntermediateResults = false;
		preprocessor.testModeOmitSequentialization = false;
	}

	public static void main(String[] args) {
		boolean success = testAllCases();
		// boolean success = testCase("test_comparison_type_and_id.xml");
		if (success) {
			System.out.println("TEST SUCCESSFULLY CONCLUDED !");
		} else {
			System.out.println("TEST FAILED !");
		}
	}

	static boolean testCase(String fileName) {
		StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
				.parsePattern(fileName);
		return checkVariableSequenceAndPrintResults(pattern.getPattern(), false);
	}

	static boolean testPreparedCase() {
		StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
				.parsePattern(TestData.TESTFILE_REORDER_SEQUENCE);
		return checkVariableSequenceAndPrintResults(pattern.getPattern(), false);
	}

	static boolean testAllCases() {
		for (File testCase : TestData.testFiles) {
			System.out.println("\n----- " + testCase.getName() + " -----\n");

			StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
					.parsePattern(testCase);
			boolean success = checkVariableSequenceAndPrintResults(
					pattern.getPattern(), false);
			if (!success) {
				return false;
			}
		}
		return true;
	}

	static void printPatternBeforeAndAfterReordering(
			StructureAnalysisType pattern) {
		System.out.println("BEFORE RE-ORDERING");
		System.out.println(pattern.getPattern().toPrettyString(""));
		preprocessor.preprocess(pattern.getPattern());
		System.out.println("AFTER RE-ORDERING");
		System.out.println(pattern.getPattern().toPrettyString(""));
	}

	static boolean checkVariableSequenceAndPrintResults(
			StructuralPattern pattern, boolean isSubPattern) {
		String patternID = pattern.getID();
		if (pattern.getSubID() != null) {
			patternID = patternID + "/" + pattern.getSubID();
		}

		List<? extends ElementVariable> originalNodeSeq = pattern.getNodeVars();
		List<ComparisonSimplified> originalNodeSeqSimplified = ComparisonSimplifier
				.generateComparisonsSimplified(patternID, originalNodeSeq);

		List<? extends ElementVariable> originalLinkSeq = pattern.getLinkVars();
		List<ComparisonSimplified> originalLinkSeqSimplified = ComparisonSimplifier
				.generateComparisonsSimplified(patternID, originalLinkSeq);

		System.out.println("BEFORE RE-ORDERING");
		System.out.println(pattern.toPrettyString(""));

		if (!isSubPattern) {
			// sub-patterns have already been processed in iteration of "main"
			// pattern
			preprocessor.preprocess(pattern);
		}
		System.out.println("AFTER RE-ORDERING");
		System.out.println(pattern.toPrettyString(""));

		List<? extends ElementVariable> reorderedNodeSeq = pattern
				.getNodeVars();
		List<ComparisonSimplified> reorderedNodeSeqSimplified = ComparisonSimplifier
				.generateComparisonsSimplified(patternID, reorderedNodeSeq);

		List<? extends ElementVariable> reorderedLinkSeq = pattern
				.getLinkVars();
		List<ComparisonSimplified> reorderedLinkSeqSimplified = ComparisonSimplifier
				.generateComparisonsSimplified(patternID, reorderedLinkSeq);

		boolean originalNodeSeqCorrect = sequenceCorrect(originalNodeSeqSimplified);
		boolean reorderedNodeSeqCorrect = sequenceCorrect(reorderedNodeSeqSimplified);
		boolean nodeSequencesEquivalent = sequencesEquivalent(
				originalNodeSeqSimplified, reorderedNodeSeqSimplified);

		boolean originalLinkSeqCorrect = sequenceCorrect(originalLinkSeqSimplified);
		boolean reorderedLinkSeqCorrect = sequenceCorrect(reorderedLinkSeqSimplified);
		boolean linkSequencesEquivalent = sequencesEquivalent(
				originalLinkSeqSimplified, reorderedLinkSeqSimplified);

		System.out.println("originalNodeSeqCorrect: " + originalNodeSeqCorrect);
		System.out.println("reorderedNodeSeqCorrect: "
				+ reorderedNodeSeqCorrect);
		System.out.println("nodeSequencesEquivalent: "
				+ nodeSequencesEquivalent);
		System.out.println("originalLinkSeqCorrect: " + originalLinkSeqCorrect);
		System.out.println("reorderedLinkSeqCorrect: "
				+ reorderedLinkSeqCorrect);
		System.out.println("linkSequencesEquivalent: "
				+ linkSequencesEquivalent);

		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			boolean notPatternCorrect = checkVariableSequenceAndPrintResults(
					notPattern, true);
			if (!notPatternCorrect) {
				return false;
			}
		}

		return reorderedNodeSeqCorrect && nodeSequencesEquivalent
				&& reorderedLinkSeqCorrect && linkSequencesEquivalent;
	}

	/**
	 * Correct == no references to elements that come later in the sequence
	 * 
	 * @return
	 */
	static boolean sequenceCorrect(
			List<ComparisonSimplified> comparisonsSimplified) {
		for (ComparisonSimplified comparisonSimpl : comparisonsSimplified) {
			if (comparisonSimpl instanceof ComparisonToVarSimplified) {
				ComparisonToVarSimplified varCompSimplified = (ComparisonToVarSimplified) comparisonSimpl;
				if (!varCompSimplified.rightOrder()) {
					return false;
				}
			}
		}
		return true;

	}

	/**
	 * sequence equivalence:
	 * 
	 * (1) for each comparison in seq1 there is an equivalent comparison in seq2
	 * (either an identical or the inverse comparison)
	 * 
	 * (2) length(seq1) == length(seq2)
	 * 
	 * @param seq1
	 * @param seq2
	 * @return
	 */
	static boolean sequencesEquivalent(List<ComparisonSimplified> seq1,
			List<ComparisonSimplified> seq2) {
		if (seq1.size() != seq2.size()) {
			System.out
					.println("[sequencesEquivalent] FALSE - Different sequence lengths");
			return false;
		}
		for (ComparisonSimplified comparison1 : seq1) {
			boolean equivalentComparisonFound = false;
			for (ComparisonSimplified comparison2 : seq2) {
				if (comparison1.isEquivalent(comparison2)) {
					equivalentComparisonFound = true;
					break;
				}
			}
			if (!equivalentComparisonFound) {
				System.out
						.println("[sequencesEquivalent] FALSE - No match found for seq1 element: "
								+ comparison1.toString());
				return false;
			}
		}
		return true;
	}

}
