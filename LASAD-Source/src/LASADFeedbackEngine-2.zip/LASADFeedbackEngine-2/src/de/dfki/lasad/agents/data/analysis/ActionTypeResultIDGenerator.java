package de.dfki.lasad.agents.data.analysis;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ActionTypeResultIDGenerator {

	private static int counter = 0;

	public static synchronized int getFreshID() {
		return counter++;
	}
}
