package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.ontology.Ontology;
import lasad.shared.dfki.meta.ontology.descr.PropDescr;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.types.structure.translator.Indent;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PropFactGen {

	private static final Log logger = LogFactory.getLog(PropFactGen.class);

	private JessIDAndSlotNameGenerator idGen;
	private Ontology ontology;
	// in
	private ElementVariable elemVar;
	private PropDescr prop;
	private Map<ElementVariableProp, List<Comparison>> propVars2Comparisons;
	private Bin bin;
	private int tempVarAppendix;
	private boolean useElemTempVar;
	private boolean useTempVarLeft;
	private boolean useTempVarRight;

	// generated
	private PropFactPropSlotsGen slotsGen;

	/**
	 * Generates Jess 'property' Fact pattern according to the given
	 * specification
	 * 
	 * @param elemVar
	 *            the element variable this property belongs to
	 * @param prop
	 *            a property description (from the {@link Ontology})
	 * @param propVars2Comparisons
	 *            {@link Comparison}s per property component
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param tempVarAppendix
	 *            will be appended to generated var names to guarantee
	 *            uniqueness
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 */
	public PropFactGen(JessIDAndSlotNameGenerator idGen, Ontology ontology,
			ElementVariable elemVar, PropDescr prop,
			Map<ElementVariableProp, List<Comparison>> propVars2Comparisons,
			Bin bin, int tempVarAppendix, boolean useElemTempVar,
			boolean useTempVarLeft, boolean useTempVarRight) {
		this.idGen = idGen;
		this.ontology = ontology;

		this.elemVar = elemVar;
		this.prop = prop;
		this.propVars2Comparisons = propVars2Comparisons;
		this.bin = bin;
		this.tempVarAppendix = tempVarAppendix;
		this.useElemTempVar = useElemTempVar;
		this.useTempVarLeft = useTempVarLeft;
		this.useTempVarRight = useTempVarRight;

		this.slotsGen = new PropFactPropSlotsGen(idGen, propVars2Comparisons,
				bin, tempVarAppendix, useTempVarLeft, useTempVarRight);
	}

	/**
	 * Generates Jess 'property' Fact pattern according to the given
	 * specification (considers only one {@link Comparison})
	 * 
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param tempVarAppendix
	 *            will be appended to generated var names to guarantee
	 *            uniqueness
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 */
	public PropFactGen(JessIDAndSlotNameGenerator idGen, Ontology ontology,
			Comparison comparison, Bin bin, int tempVarAppendix,
			boolean useTempElemVar, boolean useTempVarLeft,
			boolean useTempVarRight) {
		this(idGen, ontology, comparison.getLeftExpr().getElementVar(),
				comparison.getLeftExpr().getPropDescr(ontology),
				createProp2ComparisonsMapping(comparison), bin,
				tempVarAppendix, useTempElemVar, useTempVarLeft,
				useTempVarRight);
	}

	private static Map<ElementVariableProp, List<Comparison>> createProp2ComparisonsMapping(
			Comparison comparison) {
		Map<ElementVariableProp, List<Comparison>> propVars2Comparisons = new HashMap<ElementVariableProp, List<Comparison>>();
		ElementVariableProp propVar = comparison.getLeftExpr();
		List<Comparison> comparisons = new Vector<Comparison>();
		comparisons.add(comparison);
		propVars2Comparisons.put(propVar, comparisons);
		return propVars2Comparisons;
	}

	public String getString() {

		StringBuffer buf = new StringBuffer();

		String templateName = prop.getJessTemplate();
		String factPatternStart = "(" + templateName;
		String type = prop.getPropID();
		String typeSlot = "(type \"" + type + "\")";
		String parentID = idGen.generateElemIDVar(elemVar);
		String parentSlot = "(parent_id " + parentID + ")";
		String factIDSlot = "";
		if (useElemTempVar) {
			factIDSlot = generateFactTempIDSlot(elemVar, tempVarAppendix);
		}
		String propSlots = slotsGen.getString();
		String deletedSlot = "(deleted FALSE)";

		buf.append(factPatternStart);
		buf.append("\n");
		buf.append(Indent.apply(typeSlot, Indentations.INDENT_PROPFACT));
		buf.append("\n");
		buf.append(Indent.apply(parentSlot, Indentations.INDENT_PROPFACT));
		buf.append("\n");
		if (useElemTempVar) {
			buf.append(Indent.apply(factIDSlot, Indentations.INDENT_PROPFACT));
			buf.append("\n");
		}
		if (propSlots.length() > 0) {
			buf.append(Indent.apply(propSlots, Indentations.INDENT_PROPFACT));
			buf.append("\n");
		}
		buf.append(Indent.apply(deletedSlot, Indentations.INDENT_PROPFACT));
		buf.append(")");
		return buf.toString();
	}

	/**
	 * Generates Jess Fact temp ID slot (i.e., ID var specific to comparison)
	 * 
	 * @param comparisonID
	 * @return
	 */
	private String generateFactTempIDSlot(ElementVariable elemVar,
			int comparisonID) {
		return "(id " + idGen.generateElemIDTempVar(elemVar, comparisonID)
				+ ")";
	}
}
