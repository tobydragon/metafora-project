package de.dfki.lasad.core.components.collections;

import java.io.File;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.description.DataServiceDescriptionXML;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.core.components.description.SessionModelDescriptionXML;
import de.dfki.lasad.util.XMLUtil;

/**
 * XML (de-)serialization for {@link BasicResourceDescriptions} objects.
 * 
 * @author oliverscheuer
 * 
 */
public class BasicResourceDescriptionsXML {

	static Log logger = LogFactory.getLog(BasicResourceDescriptionsXML.class);

	public static BasicResourceDescriptions fromXML(Element resourceElem) {

		BasicResourceDescriptions resourceDescrs = new BasicResourceDescriptions();
		for (Element elem : (List<Element>) resourceElem
				.getChildren("dataservice")) {
			DataServiceDescription dsDescr = DataServiceDescriptionXML
					.fromXML(elem);
			resourceDescrs.addDescription(dsDescr);
		}
		for (Element elem : (List<Element>) resourceElem
				.getChildren("sessionmodel")) {
			SessionModelDescription smDescr = SessionModelDescriptionXML
					.fromXML(elem);
			resourceDescrs.addDescription(smDescr);
		}
		return resourceDescrs;
	}

	public static Element toXML(BasicResourceDescriptions resourceDescrs) {

		Element resourcesElem = new Element("resources");

		for (DataServiceDescription dsDescr : resourceDescrs
				.getDataServiceDescriptions()) {
			Element childElem = DataServiceDescriptionXML.toXML(dsDescr);
			resourcesElem.addContent(childElem);
		}
		for (SessionModelDescription smDescr : resourceDescrs
				.getSessionModelDescriptions()) {
			Element childElem = SessionModelDescriptionXML.toXML(smDescr);
			resourcesElem.addContent(childElem);
		}
		return resourcesElem;
	}

	/**
	 * Creates (or overwrites) given file with given
	 * {@link BasicResourceDescriptions}
	 * 
	 * @param file
	 * @param aRuntime
	 */
	public static void updateXMLFile(File file,
			BasicResourceDescriptions resourceDescrs) {
		try {
			if (file.exists()) {
				file.delete();
			}
			Element elem = toXML(resourceDescrs);
			XMLUtil.xmlElem2File(file, elem);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
}
