package de.dfki.lasad.core.components.collections;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.description.DataServiceDescriptionXML;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.core.components.description.SessionModelDescriptionXML;

/**
 * XML (de-)serialization for {@link BasicResourceDescriptions} objects.
 * 
 * @author oliverscheuer
 * 
 */
public class BasicResourceDescriptionsXML {

	static Log logger = LogFactory.getLog(BasicResourceDescriptionsXML.class);

	public static BasicResourceDescriptions fromXML(Element resourceElem) {

		BasicResourceDescriptions resourceDescrs = new BasicResourceDescriptions();
		for (Element elem : (List<Element>) resourceElem
				.getChildren("dataservice")) {
			DataServiceDescription dsDescr = DataServiceDescriptionXML
					.fromXML(elem);
			resourceDescrs.addDescription(dsDescr);
		}
		for (Element elem : (List<Element>) resourceElem
				.getChildren("sessionmodel")) {
			SessionModelDescription smDescr = SessionModelDescriptionXML
					.fromXML(elem);
			resourceDescrs.addDescription(smDescr);
		}
		return resourceDescrs;
	}

	public static Element toXML(BasicResourceDescriptions resourceDescrs) {

		Element resourcesElem = new Element("resources");

		for (DataServiceDescription dsDescr : resourceDescrs
				.getDataServiceDescriptions()) {
			Element childElem = DataServiceDescriptionXML.toXML(dsDescr);
			resourcesElem.addContent(childElem);
		}
		for (SessionModelDescription smDescr : resourceDescrs
				.getSessionModelDescriptions()) {
			Element childElem = SessionModelDescriptionXML.toXML(smDescr);
			resourcesElem.addContent(childElem);
		}
		return resourcesElem;
	}

	public static void updateXMLFile(File file,
			BasicResourceDescriptions resourceDescrs) {
		try {
			if (file.exists()) {
				file.delete();
			}
			Element elem = toXML(resourceDescrs);
			XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
			Document doc = new Document();
			doc.setRootElement(elem);
			outputter.output(doc, new FileWriter(file));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
}
