package de.dfki.lasad.dataservice.lasad.translators;


import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.ActionPackage;
import lasad.shared.communication.objects.categories.Categories;
import lasad.shared.communication.objects.commands.Commands;
import lasad.shared.communication.objects.parameters.ParameterTypes;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.events.agents.configchange.AFStateChangedEvent;
import de.dfki.lasad.events.agents.configchange.Agent2OntologyMappingAddedEvent;
import de.dfki.lasad.events.agents.configchange.Agent2OntologyMappingDeletedEvent;
import de.dfki.lasad.events.agents.configchange.Agent2SessionMappingAddedEvent;
import de.dfki.lasad.events.agents.configchange.Agent2SessionMappingDeletedEvent;
import de.dfki.lasad.events.agents.configchange.AgentDescriptionAddedOrUpdatedEvent;
import de.dfki.lasad.events.agents.configchange.AgentDescriptionDeletedEvent;
import de.dfki.lasad.events.agents.configchange.AgentMappingsDeleted;
import de.dfki.lasad.events.agents.configchange.ComponentRuntimeStatusChangedEvent;
import de.dfki.lasad.events.agents.configchange.SessionRuntimeStatusChangedEvent;
import de.dfki.lasad.events.agents.configstate.AgentsStateInfoEvent;
import de.dfki.lasad.events.agents.configstate.AgentsToOntologiesStateInfoEvent;
import de.dfki.lasad.events.agents.configstate.AgentsToSessionsStateInfoEvent;
import de.dfki.lasad.events.agents.configstate.CompileAgentInfoEvent;
import de.dfki.lasad.events.agents.configstate.SessionStatusInfoEvent;
import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;
import de.dfki.lasad.events.eue.admin.agent.out.FreshAgentIDEvent;
import de.dfki.lasad.events.eue.admin.agent.out.FreshServiceIDEvent;

/**
 * 
 * @author oliverscheuer, anahuacv
 * 
 */
public class EventTranslatorAgentAuthoringOut {


	private static Log logger = LogFactory
			.getLog(EventTranslatorAgentAuthoringOut.class);
	
	public static ActionPackage translate(EUEAgentAdminEvent event) {
		if (event instanceof AgentsStateInfoEvent) {
			return translateAgentsStateInfoEvent((AgentsStateInfoEvent) event);
		} else if (event instanceof AgentsToOntologiesStateInfoEvent) {
			return translateAgentsToOntologiesStateInfoEvent((AgentsToOntologiesStateInfoEvent) event);
		} else if (event instanceof AgentsToSessionsStateInfoEvent) {
			return translateAgentsToSessionsStateInfoEvent((AgentsToSessionsStateInfoEvent) event);
		} else if (event instanceof SessionStatusInfoEvent) {
			return translateSessionStatusInfoEvent((SessionStatusInfoEvent) event);
		} else if (event instanceof CompileAgentInfoEvent) {
			return translateCompileAgentInfoEvent((CompileAgentInfoEvent) event);
		} else if (event instanceof FreshAgentIDEvent) {
			return translateFreshAgentIDEvent((FreshAgentIDEvent) event);
		} else if (event instanceof FreshServiceIDEvent) {
			return translateFreshServiceIDEvent((FreshServiceIDEvent) event);
		} else {
			logger.error("Unknown EUEAgentAdminEvent, cannot translate: "
					+ event.toString());
			return null;
		}
	}
	
	public static ActionPackage translate(AFStateChangedEvent event) {
		if (event instanceof Agent2OntologyMappingAddedEvent) {
			return translateAgent2OntologyMappingAddedEvent((Agent2OntologyMappingAddedEvent) event);
		} else if (event instanceof Agent2OntologyMappingDeletedEvent) {
			return translateAgent2OntologyMappingDeletedEvent((Agent2OntologyMappingDeletedEvent) event);
		} else if (event instanceof Agent2SessionMappingAddedEvent) {
			return translateAgent2SessionMappingAddedEvent((Agent2SessionMappingAddedEvent) event);
		} else if (event instanceof Agent2SessionMappingDeletedEvent) {
			return translateAgent2SessionMappingDeletedEvent((Agent2SessionMappingDeletedEvent) event);
		} else if (event instanceof AgentDescriptionAddedOrUpdatedEvent) {
			return translateAgentDescriptionAddedOrUpdatedEvent((AgentDescriptionAddedOrUpdatedEvent) event);
		} else if (event instanceof AgentDescriptionDeletedEvent) {
			return translateAgentDescriptionDeletedEvent((AgentDescriptionDeletedEvent) event);
		} else if (event instanceof AgentMappingsDeleted) {
			return translateAgentMappingsDeleted((AgentMappingsDeleted) event);
		} else if (event instanceof ComponentRuntimeStatusChangedEvent) {
			return translateComponentRuntimeStatusChangedEvent((ComponentRuntimeStatusChangedEvent) event);
		} else if (event instanceof SessionRuntimeStatusChangedEvent) {
			return translateSessionRuntimeStatusChangedEvent((SessionRuntimeStatusChangedEvent) event);
		} else {
			logger.error("Unknown AFStateChangedEvent, cannot translate: "
					+ event.toString());
			return null;
		}
	}

	/*
	 * EUEAgentAdminEvent
	 */
	private static ActionPackage translateAgentsStateInfoEvent(
			AgentsStateInfoEvent agentsInfoEvent) {
		
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.ListAgentsInfo, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, agentsInfoEvent.isChanged()+"");
		action.setObjectFE(agentsInfoEvent.getAgentDescriptionList());
		ap.addAction(action);
		return ap;
	}

	private static ActionPackage translateAgentsToOntologiesStateInfoEvent(
			AgentsToOntologiesStateInfoEvent a2oEvent) {
		
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.ListAgentsToOntologies, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, a2oEvent.isChanged()+"");
		action.setObjectFE(a2oEvent.getAgents2ontologies());
		ap.addAction(action);
		return ap;
	}

	private static ActionPackage translateAgentsToSessionsStateInfoEvent(
			AgentsToSessionsStateInfoEvent a2sEvent) {
		
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.ListAgentsToSessions, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, a2sEvent.isChanged()+"");
		action.setObjectFE(a2sEvent.getAgents2sessions());
		ap.addAction(action);
		return ap;
	}

	private static ActionPackage translateSessionStatusInfoEvent(
			SessionStatusInfoEvent sessionStatusEvent) {
		
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.ListSessionStatus, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, String.valueOf(sessionStatusEvent.isChanged()));
		action.setObjectFE(sessionStatusEvent.getSessionStatusMap());
		ap.addAction(action);
		return ap;
	}
	
	private static ActionPackage translateCompileAgentInfoEvent(CompileAgentInfoEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.CompileAgent, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Successful, String.valueOf(event.isSuccessful()));
		action.addParameter(ParameterTypes.AgentId, event.getAgentId());
		ap.addAction(action);
		return ap;
	}
	
	private static ActionPackage translateFreshAgentIDEvent(FreshAgentIDEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.GetFreshAgentId, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Successful, String.valueOf(true));
		action.addParameter(ParameterTypes.RequestId, event.getRequestID());
		action.addParameter(ParameterTypes.AgentId, event.getAgentID());
		ap.addAction(action);
		return ap;
	}
	
	private static ActionPackage translateFreshServiceIDEvent(FreshServiceIDEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.GetFreshPatternId, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Successful, String.valueOf(true));
		action.addParameter(ParameterTypes.RequestId, event.getRequestID());
		action.addParameter(ParameterTypes.AgentId, event.getServiceID().getAgentID());
		action.addParameter(ParameterTypes.PatternId, event.getServiceID().getTypeID());
		if(event.getServiceID().getServiceClass() != null){
			action.addParameter(ParameterTypes.ServiceClass, event.getServiceID().getServiceClass().toString());
		}
		ap.addAction(action);
		return ap;
	}
	
	/*
	 * AFStateChangedEvent
	 */
	public static ActionPackage translateAgent2OntologyMappingAddedEvent (Agent2OntologyMappingAddedEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.AddAgentToOntology, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, event.isChanged()+"");
		action.addParameter(ParameterTypes.AgentId, event.getAgentID());
		action.addParameter(ParameterTypes.Ontology, event.getOntologyID());
		ap.addAction(action);
		return ap;
	}
	public static ActionPackage translateAgent2OntologyMappingDeletedEvent (Agent2OntologyMappingDeletedEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.RemoveAgentFromOntology, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, event.isChanged()+"");
		action.addParameter(ParameterTypes.AgentId, event.getAgentID());
		action.addParameter(ParameterTypes.Ontology, event.getOntologyID());
		ap.addAction(action);
		return ap;
	}
	public static ActionPackage translateAgent2SessionMappingAddedEvent (Agent2SessionMappingAddedEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.AddAgentToSession, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, event.isChanged()+"");
		action.addParameter(ParameterTypes.AgentId, event.getAgentID());
		action.addParameter(ParameterTypes.SessionId, event.getSessionID());
		ap.addAction(action);
		return ap;
	}
	public static ActionPackage translateAgent2SessionMappingDeletedEvent (Agent2SessionMappingDeletedEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.RemoveAgentFromSession, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, event.isChanged()+"");
		action.addParameter(ParameterTypes.AgentId, event.getAgentID());
		action.addParameter(ParameterTypes.SessionId, event.getSessionID());
		ap.addAction(action);
		return ap;
	}
	public static ActionPackage translateAgentDescriptionAddedOrUpdatedEvent (AgentDescriptionAddedOrUpdatedEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.AddOrUpdateAgent, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, event.isChanged()+"");
		action.setObjectFE(event.getAgentDescr());
		ap.addAction(action);
		return ap;
	}
	public static ActionPackage translateAgentDescriptionDeletedEvent (AgentDescriptionDeletedEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.DeleteAgent, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, event.isChanged()+"");
		action.addParameter(ParameterTypes.AgentId, event.getAgentID());
		ap.addAction(action);
		return ap;
	}
	/*
	 * triggered as a second update when and agent is deleted from a session or ontology
	 */
	public static ActionPackage translateAgentMappingsDeleted (AgentMappingsDeleted event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.AgentMappingsDeleted, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, event.isChanged()+"");
		action.addParameter(ParameterTypes.AgentId, event.getAgentID());
		for (String ont:event.getOntologyMappings()){
			action.addParameter(ParameterTypes.Ontology, ont);
		}
		for (String ses:event.getSessionMappings()){
			action.addParameter(ParameterTypes.SessionId, ses);
		}
		ap.addAction(action);
		return ap;
	}
	/*
	 * triggered triggered when an agent status is changed
	 */
	public static ActionPackage translateComponentRuntimeStatusChangedEvent (ComponentRuntimeStatusChangedEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.ComponentRuntimeStatusChanged, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, event.isChanged()+"");
		action.addParameter(ParameterTypes.ChangedComponentID, event.getChangedComponentID());
		action.addParameter(ParameterTypes.OldStatus, event.getOldStatus().toString());
		action.addParameter(ParameterTypes.NewStatus, event.getNewStatus().toString());
		ap.addAction(action);
		return ap;
	}
	/*
	 * triggered when a session is status is changed
	 */
	public static ActionPackage translateSessionRuntimeStatusChangedEvent (SessionRuntimeStatusChangedEvent event){
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.SessionRuntimeStatusChanged, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, event.isChanged()+"");
		action.addParameter(ParameterTypes.SessionId, event.getSessionID().getIdAsString());
		action.addParameter(ParameterTypes.OldStatus, event.getOldStatus().toString());
		action.addParameter(ParameterTypes.NewStatus, event.getNewStatus().toString());
		ap.addAction(action);
		return ap;
	}
}
