package de.dfki.lasad.dataservice.lasad.translators;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.categories.Categories;
import lasad.gwt.client.communication.objects.commands.Commands;
import lasad.gwt.client.communication.objects.parameters.ParameterTypes;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;
import de.dfki.lasad.events.eue.admin.agent.out.AgentsInfoEvent;
import de.dfki.lasad.events.eue.admin.agent.out.AgentsToOntologiesInfoEvent;
import de.dfki.lasad.events.eue.admin.agent.out.AgentsToSessionsInfoEvent;
import de.dfki.lasad.events.eue.admin.agent.out.SessionStatusInfoEvent;

/**
 * 
 * @author oliverscheuer, Anahuac Valero
 * 
 */
public class EventTranslatorAgentAuthoringOut {

	private static Log logger = LogFactory
			.getLog(EventTranslatorAgentAuthoringOut.class);

	public static ActionPackage translate(EUEAgentAdminEvent event) {

		if (event instanceof AgentsInfoEvent) {
			return translateAgentsInfoEvent((AgentsInfoEvent) event);
		} else if (event instanceof AgentsToOntologiesInfoEvent) {
			return translateAgentsToOntologiesInfoEvent((AgentsToOntologiesInfoEvent) event);
		} else if (event instanceof AgentsToSessionsInfoEvent) {
			return translateAgentsToSessionsInfoEvent((AgentsToSessionsInfoEvent) event);
		} else if (event instanceof SessionStatusInfoEvent) {
			return translateSessionStatusInfoEvent((SessionStatusInfoEvent) event);
		} else {
			logger.error("Unhandled Event type, cannot translate: "
					+ event.toString());
			return null;
		}
	}

	private static ActionPackage translateAgentsInfoEvent(
			AgentsInfoEvent agentsInfoEvent) {
		
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.ListAgentsInfo, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, agentsInfoEvent.isChanged()+"");
		action.addParameter(ParameterTypes.Details, agentsInfoEvent.getAgentDescriptionList().toXMLString());
		ap.addAction(action);
		return ap;
	}

	private static ActionPackage translateAgentsToOntologiesInfoEvent(
			AgentsToOntologiesInfoEvent a2oEvent) {
		
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.ListAgentsToOntologies, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, a2oEvent.isChanged()+"");
		action.addParameter(ParameterTypes.Details, a2oEvent.getAgents2ontologies().toXMLString());
		ap.addAction(action);
		return ap;
	}

	private static ActionPackage translateAgentsToSessionsInfoEvent(
			AgentsToSessionsInfoEvent a2sEvent) {
		
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.ListAgentsToSessions, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, a2sEvent.isChanged()+"");
		action.addParameter(ParameterTypes.Details, a2sEvent.getAgents2sessions().toXMLString());
		ap.addAction(action);
		return ap;
	}

	private static ActionPackage translateSessionStatusInfoEvent(
			SessionStatusInfoEvent sessionStatusEvent) {
		
		ActionPackage ap = new ActionPackage();
		Action action = new Action(Commands.ListSessionStatus, Categories.FeedbackAuthoring);
		action.addParameter(ParameterTypes.Changed, sessionStatusEvent.isChanged()+"");
		action.addParameter(ParameterTypes.Details, sessionStatusEvent.getSessionStatusMap().toXMLString());
		ap.addAction(action);
		return ap;
	}
}
