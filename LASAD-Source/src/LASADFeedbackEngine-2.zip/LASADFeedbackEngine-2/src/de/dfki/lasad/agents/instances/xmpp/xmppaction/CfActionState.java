package de.dfki.lasad.agents.instances.xmpp.xmppaction;

public enum CfActionState {
	
	create, waitingToModifyEUE, waitingToReportToXmpp;

}
