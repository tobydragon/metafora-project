package de.dfki.lasad.agents.instances.action.processors;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.provision.ProvisionType;
import lasad.shared.dfki.meta.agents.provision.priority.MsgFilterDef;
import lasad.shared.dfki.meta.agents.provision.priority.MsgSortCriterion;
import lasad.shared.dfki.meta.agents.provision.priority.PriorityProvisionType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.agents.instances.action.UserServiceID;
import de.dfki.lasad.agents.logic.provision.actionfilter.MsgFilterServiceFactory;
import de.dfki.lasad.agents.logic.provision.actionfilter.MsgFilterServiceInterface;
import de.dfki.lasad.agents.logic.provision.actionhistory.MsgProvisionHistory;
import de.dfki.lasad.agents.logic.provision.actionhistory.MsgProvisionHistoryChangedListener;
import de.dfki.lasad.agents.logic.provision.actionhistory.MsgProvisionRecord;
import de.dfki.lasad.agents.logic.provision.actionsort.MsgSortServiceFactory;
import de.dfki.lasad.agents.logic.provision.actionsort.MsgSortServiceInterface;
import de.dfki.lasad.agents.logic.provision.phases.PhaseModelerInterface;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ProvisionTypeResultProcessor implements
		MsgProvisionHistoryChangedListener {

	private static Log logger = LogFactory
			.getLog(ProvisionTypeResultProcessor.class);

	private UserServiceID userProvisionID = null;
	private ProvisionType provisionType = null;
	private MsgProvisionHistory msgHistoryRef = null;
	private PhaseModelerInterface phaseModelerRef = null;

	private MsgFilterServiceInterface filterService = null;
	private MsgSortServiceInterface sortService = null;

	private int maxNumResults = 1;

	private Map<Integer, ActionTypeResult> prefilteredResults = new HashMap<Integer, ActionTypeResult>();

	private String debugID = null;
	private String debugPrefix = null;

	public ProvisionTypeResultProcessor(UserServiceID userProvisionID,
			ProvisionType provisionType, MsgProvisionHistory msgHistoryRef,
			PhaseModelerInterface phaseModelerRef) {
		this.userProvisionID = userProvisionID;
		this.provisionType = provisionType;

		debugID = "(" + provisionType.getServiceID().getTypeID() + " | "
				+ userProvisionID.getUserID().getIdAsString() + ")";
		debugPrefix = debugID + " - ";

		this.msgHistoryRef = msgHistoryRef;
		this.msgHistoryRef.addListener(this);
		this.phaseModelerRef = phaseModelerRef;

		initMsgFilterService();
		initMsgSortService();

	}

	public String getDebugID() {
		return debugID;
	}

	private void initMsgFilterService() {
		List<MsgFilterDef> msgFilterDefs;
		if (provisionType instanceof PriorityProvisionType) {
			PriorityProvisionType ppType = (PriorityProvisionType) provisionType;
			msgFilterDefs = ppType.getFilterDefs();
			this.maxNumResults = ppType.getMaxNumResults();
		} else {
			logger.info(debugPrefix
					+ "No msg filters supported in provision type: "
					+ provisionType);
			msgFilterDefs = new Vector<MsgFilterDef>();
		}
		this.filterService = MsgFilterServiceFactory.createMsgFilterService(
				userProvisionID.getUserID(), msgHistoryRef, msgFilterDefs);
	}

	private void initMsgSortService() {
		List<MsgSortCriterion> msgFilterCriteria;
		if (provisionType instanceof PriorityProvisionType) {
			PriorityProvisionType ppType = (PriorityProvisionType) provisionType;
			msgFilterCriteria = ppType.getSortCriteriaInOrder();
		} else {
			logger.info(debugPrefix
					+ "No msg sort criteria supported in provision type: "
					+ provisionType);
			msgFilterCriteria = new Vector<MsgSortCriterion>();
		}
		this.sortService = MsgSortServiceFactory
				.createMsgSortService(msgFilterCriteria,
						userProvisionID.getUserID(), phaseModelerRef);
	}

	public void onResultChanged(ActionTypeResult resultData, boolean doRemove) {
		if (doRemove) {
			boolean removed = tryRemoveResult(resultData);
			if (removed) {
				logger.debug(debugPrefix + "REMOVED - "
						+ resultData.getResult().toSimpleString());
				logModeledResults();
			}
		} else {
			boolean filtersSatisfied = filterService.keep(resultData);
			boolean modeled = prefilteredResults
					.containsKey(resultData.getId());

			if (filtersSatisfied && !modeled) {
				addResult(resultData);
				logger.debug(debugPrefix + "ADDED - "
						+ resultData.getResult().toSimpleString());
				logModeledResults();
			} else if (!filtersSatisfied && modeled) {
				tryRemoveResult(resultData);
				logger.debug(debugPrefix + "REMOVED - "
						+ resultData.getResult().toSimpleString());
				logModeledResults();
			} else {
				logger.debug(debugPrefix + "IGNORED - "
						+ resultData.getResult().toSimpleString());
				logModeledResults();
			}
		}
	}

	public void onHistoryChanged(List<MsgProvisionRecord> sentMsgs) {
		for (Iterator<Integer> iter = prefilteredResults.keySet().iterator(); iter
				.hasNext();) {
			Integer id = iter.next();
			ActionTypeResult resultData = prefilteredResults.get(id);
			if (filterService.keep(resultData) == false) {
				logger.debug(debugPrefix + "REMOVED - "
						+ resultData.getResult().toSimpleString());
				iter.remove();
			}
		}
		logModeledResults();
	}

	public List<ActionTypeResult> getResultsInOrder() {
		List<ActionTypeResult> results = new Vector<ActionTypeResult>(
				prefilteredResults.values());
		sortService.sort(results);
		filterService.filter(results);
		if (maxNumResults == PriorityProvisionType.ALL_RESULTS) {
			return results;
		}
		int numResults = Math.min(maxNumResults, results.size());
		return results.subList(0, numResults);
	}

	private void addResult(ActionTypeResult resultData) {
		int resultID = resultData.getId();
		prefilteredResults.put(resultID, resultData);
	}

	private boolean tryRemoveResult(ActionTypeResult resultData) {
		int resultID = resultData.getId();
		boolean removed = (prefilteredResults.remove(resultID) != null);
		return removed;
	}

	private void logModeledResults() {
		logger.debug(debugPrefix + "Modeled results:");
		for (Integer resultID : prefilteredResults.keySet()) {
			ActionTypeResult result = prefilteredResults.get(resultID);
			logger.debug("... " + debugPrefix
					+ result.getResult().toSimpleString());
		}
	}
}
