package de.dfki.lasad.events.eue.user.feedback;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;

/**
 * Indicates which feedback {@link #feedbackType} from which
 * {@link IActionAgent} (@link #feedbackProvider) should be provided. The flag
 * {@link #mirrorResults} indicates that feedback should be provided by an
 * {@link IAnalysisAgent} rather than an {@link IActionAgent} to access
 * {@link AnalysisResult}s directly.
 * 
 * @author Oliver Scheuer
 * 
 */
public class FeedbackTypeID {

	String feedbackProvider;
	String feedbackType;

	boolean mirrorResults = false;

	public FeedbackTypeID(String feedbackProvider, String feedbackType) {
		this.feedbackProvider = feedbackProvider;
		this.feedbackType = feedbackType;
	}

	public FeedbackTypeID(String feedbackProvider, String feedbackType,
			boolean mirrorResults) {
		this.feedbackProvider = feedbackProvider;
		this.feedbackType = feedbackType;
		this.mirrorResults = mirrorResults;
	}

	public String getFeedbackProvider() {
		return feedbackProvider;
	}

	public String getFeedbackType() {
		return feedbackType;
	}

	public boolean mirrorResults() {
		return mirrorResults;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((feedbackProvider == null) ? 0 : feedbackProvider.hashCode());
		result = prime * result
				+ ((feedbackType == null) ? 0 : feedbackType.hashCode());
		result = prime * result + (mirrorResults ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof FeedbackTypeID))
			return false;
		FeedbackTypeID other = (FeedbackTypeID) obj;
		if (feedbackProvider == null) {
			if (other.feedbackProvider != null)
				return false;
		} else if (!feedbackProvider.equals(other.feedbackProvider))
			return false;
		if (feedbackType == null) {
			if (other.feedbackType != null)
				return false;
		} else if (!feedbackType.equals(other.feedbackType))
			return false;
		if (mirrorResults != other.mirrorResults)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "FeedbackTypeID [feedbackProvider=" + feedbackProvider
				+ ", feedbackType=" + feedbackType + ", mirrorResults="
				+ mirrorResults + "]";
	}

}
