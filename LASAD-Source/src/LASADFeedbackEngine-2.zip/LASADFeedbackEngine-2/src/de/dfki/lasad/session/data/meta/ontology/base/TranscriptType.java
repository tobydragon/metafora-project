package de.dfki.lasad.session.data.meta.ontology.base;

import de.dfki.lasad.session.data.meta.ontology.ComparisonGroup;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class TranscriptType extends BaseType {

	private static TranscriptType instance = new TranscriptType();

	private TranscriptType() {

		super();
		lasadElementType = "transcript-link";
		jessTemplateName = "elem_transcript-link";
		addComponentSpecification("startrow","STARTROW", JessDataType.NUMBER,
				ComparisonGroup.NONE);
		addComponentSpecification("startpoint","STARTPOINT", JessDataType.NUMBER,
				ComparisonGroup.NONE);
		addComponentSpecification("endrow","ENDROW", JessDataType.NUMBER,
				ComparisonGroup.NONE);
		addComponentSpecification("endpoint","ENDPOINT", JessDataType.NUMBER,
				ComparisonGroup.NONE);
	}

	public static TranscriptType getInstance() {
		return instance;
	}
}
