package de.dfki.lasad.agents;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.action.AgentAction;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.NoAnalysisResults;
import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.ServiceType;
import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.DefaultEventPrioritizer;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.instance.AbstractComponent;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.IComponent;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.core.components.instance.ISessionModel;
import de.dfki.lasad.core.components.instance.ServiceStatus;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.EventCallback;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.events.agents.AnalysisResultEvent;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestEvent;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestSpec;
import de.dfki.lasad.events.eue.user.feedback.FeedbackTypeID;
import de.dfki.lasad.session.SessionActiveRuntime;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.util.threads.Signal;

/**
 * Provides basic functionality shared by {@link IAgent} implementations,
 * including a {@link PriorityBlockingQueue<Event>} to keep received
 * {@link EventImpl}s and a {@link Thread} that dequeues and processes {@link EventImpl}
 * s.
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent}, {@link IAgent})
 * 
 * 
 * @author oliverscheuer
 * 
 */
public abstract class AbstractAgent extends AbstractComponent implements
		IAgent, EventCallback {

	private Log logger = LogFactory.getLog(AbstractAgent.class);

	protected AgentDescription description = null;
	protected SessionActiveRuntime activeRuntime = null;
	protected SessionID sessionID = null;

	protected ISessionModel model;

	protected IDataService dataService;
	// protected ConfigurationManager confManager;

	private PriorityBlockingQueue<Event> eventQueue = null;
	private boolean processEvents = false;
	private Thread workingThread;
	private Signal signal = new Signal();

	public AbstractAgent() {
	}

	@Override
	public void configure(AbstractComponentDescription description)
			throws ComponentInitException {
		this.description = (AgentDescription) description;
	}

	@Override
	public AbstractComponentDescription getDescription() {
		// TODO Auto-generated method stub
		return description;
	}

	@Override
	public void doWire(IDataService dataService,
			SessionActiveRuntime activeRuntime) {
		this.dataService = dataService;
		// this.confManager = agentManager;

		// management agents don't have sessions...
		if (activeRuntime != null) {
			this.activeRuntime = activeRuntime;
			this.model = activeRuntime.getModel();
			this.sessionID = activeRuntime.getSessionID();
			setServiceStatus(ServiceStatus.READY_TO_START);
		}
	}

	public AgentDescription getAgentDescription() {
		return description;
	}

	@Override
	public String getComponentID() {
		return description.getComponentID();
	}

	@Override
	public AnalysisType getAnalysisType(String typeID) {
		return description.getAnalysisType(typeID);
	}

	@Override
	public List<AnalysisType> getAnalysisTypes() {
		return description.getAnalysisTypes();
	}

	@Override
	public List<ActionType> getActionTypes() {
		return description.getActionTypes();
	}

	@Override
	public ActionType getActionType(String typeID) {
		return description.getActionType(typeID);
	}

	@Override
	public List<ServiceType> getTypesToPublish() {
		return description.getTypesToPublish();
	}

	public synchronized void startService() {
		try {
			eventQueue = new PriorityBlockingQueue<Event>();
			processEvents = true;
			workingThread = new Thread(new Consumer());
			workingThread.start();
			logger.info(getComponentID() + " (" + getSessionID()
					+ "): Waiting for event thread to start ...");
			signal.waitForSignal(true);
			logger.info(getComponentID() + " (" + getSessionID()
					+ "): Waiting for event thread to start: DONE");
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	public synchronized void stopService() {
		try {
			processEvents = false;
			logger.info(getComponentID() + " (" + getSessionID()
					+ "): Waiting for event thread to stop ...");
			signal.waitForSignal(false);
			logger.info(getComponentID() + " (" + getSessionID()
					+ "): Waiting for event thread to stop: DONE");
		} catch (Exception e) {
			logger.error("stopService() " + e.getClass(), e);
		}
	}

	@Override
	public void onEvent(Event event) {
		DefaultEventPrioritizer.assignPriority(event);
		eventQueue.put(event);
	}

	/**
	 * should NOT be synchronized to avoid deadlock with stopService() method
	 * (stopService() waits until Consumer.run() terminates, Consumer.run()
	 * might wait for stopService() to terminate if method processEvent were
	 * synchronized).
	 */
	protected abstract void processEvent(Event event);

	protected void sendActionsToEUE(ActionSpecEvent event) {
		dataService.onOutEvent(event);
	}

	/**
	 * Repackages {@link AnalysisResultEvent} into
	 * 
	 * @param analysisResultEvent
	 * @param uID
	 */
	protected void sendRawResultsToEUE(AnalysisResultEvent analysisResultEvent,
			UserID uID) {
		String actionAgentID = description.getComponentID();
		Set<AnalysisType> aTypes = analysisResultEvent.getAnalysisType();
		for (AnalysisType aType : aTypes) {
			logger.info(actionAgentID + ": processAnalysisResultEvent");

			SessionID sessionID = analysisResultEvent.getSessionID();

			AgentAction actionSpec = new AgentAction();

			// Only the original requester will receive mirroring feedback
			actionSpec.setActionRecipient(uID);

			ActionSpecEvent actionSpecEvent = new ActionSpecEvent(sessionID,
					actionAgentID);

			List<AnalysisResult> results = analysisResultEvent
					.getResults(aType);
			if (results.isEmpty()) {
				NoAnalysisResults noResults = new NoAnalysisResults(aType);
				actionSpec.addActionComponent(noResults);
			}

			for (AnalysisResult result : results) {
				actionSpec.addActionComponent(result);
			}
			actionSpecEvent.addActionSpec(actionSpec);
			dataService.onOutEvent(actionSpecEvent);
		}
	}

	protected ServiceType resolveRequestedType(
			FeedbackRequestEvent feedbackRequestEvent) {

		logger.debug("Resolve requested service type: "
				+ feedbackRequestEvent.getFeedbackRequestSpec() + " ...");

		FeedbackRequestSpec feedbackReqSpec = feedbackRequestEvent
				.getFeedbackRequestSpec();
		FeedbackTypeID fType = feedbackReqSpec.getFeedbackTypeID();
		if (fType.mirrorResults()) {
			AnalysisType aType = activeRuntime.getAnalysisType(
					fType.getFeedbackProvider(), fType.getFeedbackType());
			return aType;
		} else {
			ActionType aType = activeRuntime.getActionType(
					fType.getFeedbackProvider(), fType.getFeedbackType());
			return aType;
		}

	}

	class Consumer implements Runnable {

		@Override
		public void run() {
			try {
				signal.signalGo();
				do {
					Event event = eventQueue.take();
					processEvent(event);
				} while (processEvents);
				signal.signalStop();
			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}
		}
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		buffer.append(this.getClass().getSimpleName());
		buffer.append(": ").append(getDataString());
		buffer.append("]");
		return buffer.toString();
	}

	public String getDataString() {
		StringBuffer buffer = new StringBuffer();

		buffer.append("analysisAgentID=").append(description.getComponentID());
		buffer.append(", class=").append(description.getClass());
		buffer.append(", analysisTypes =").append(analysisTypesToString());
		return buffer.toString();
	}

	public String analysisTypesToString() {
		StringBuffer buffer = new StringBuffer();
		AnalysisType types;
		buffer.append("{");
		Iterator<AnalysisType> iter = description.getAnalysisTypes().iterator();
		while (iter.hasNext()) {
			types = iter.next();
			buffer.append(types.toString());
			if (iter.hasNext()) {
				buffer.append(", ");
			}
		}
		buffer.append("}");
		return buffer.toString();
	}

	public SessionID getSessionID() {
		return sessionID;
	}
}
