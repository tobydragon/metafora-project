package de.dfki.lasad.agents;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.PriorityBlockingQueue;

import lasad.shared.dfki.meta.ServiceStatus;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.ServiceType;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.action.AgentAction;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.NoAnalysisResults;
import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.DefaultEventPrioritizer;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.instance.AbstractComponent;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.IComponent;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.core.components.instance.ISessionModel;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.EventCallback;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.events.agents.AnalysisResultsProvisionEvent;
import de.dfki.lasad.events.agents.OnRequestServiceSpec;
import de.dfki.lasad.session.SessionActiveRuntime;
import de.dfki.lasad.session.SessionConfig;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.util.threads.Signal;

/**
 * Provides basic functionality shared by {@link IAgent} implementations,
 * including a {@link PriorityBlockingQueue<Event>} to keep received
 * {@link EventImpl}s and a {@link Thread} that dequeues and processes
 * {@link EventImpl} s.
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent}, {@link IAgent})
 * 
 * 
 * @author oliverscheuer
 * 
 */
public abstract class AbstractAgent extends AbstractComponent implements
		IAgent, EventCallback {

	private Log logger = LogFactory.getLog(AbstractAgent.class);

	protected AgentDescription description = null;
	protected SessionActiveRuntime activeRuntime = null;
	protected SessionID sessionID = null;

	protected ISessionModel model;

	protected IDataService dataService;
	// protected ConfigurationManager confManager;

	protected PriorityBlockingQueue<Event> eventQueue = new PriorityBlockingQueue<Event>();
	private boolean processEvents = false;
	private Thread workingThread;
	private Signal signal = new Signal();

	public AbstractAgent() {
		super();
	}

	@Override
	public void init(AbstractComponentDescription description,
			SessionConfig sessionConfig) throws ComponentInitException {
		this.description = (AgentDescription) description;
	}

	@Override
	public AbstractComponentDescription getDescription() {
		return description;
	}

	@Override
	public void doWire(IDataService dataService,
			SessionActiveRuntime activeRuntime) {
		this.dataService = dataService;
		// this.confManager = agentManager;

		// management agents don't have sessions...
		if (activeRuntime != null) {
			this.activeRuntime = activeRuntime;
			this.model = activeRuntime.getModel();
			this.sessionID = activeRuntime.getSessionID();
		}
		setServiceStatus(ServiceStatus.READY_TO_START);
	}

	public AgentDescription getAgentDescription() {
		return description;
	}

	@Override
	public String getComponentID() {
		return description.getComponentID();
	}

	@Override
	public List<ServiceType> getServiceTypes() {
		return description.getServiceTypes();
	}

	@Override
	public ServiceType getServiceType(ServiceID sID) {
		return description.getServiceType(sID);
	}

	/**
	 * Override this method in subclasses to specify services that can be
	 * requested by the user.
	 * 
	 * @Override
	 */
	public List<OnRequestServiceSpec> getTypesToPublish() {
		return new Vector<OnRequestServiceSpec>();
	}

	/**
	 * starts event thread
	 */
	protected void startServiceImpl() {
		try {
			processEvents = true;
			workingThread = new Thread(new Consumer());
			workingThread.start();
			logger.info(getComponentID() + " (" + getSessionID()
					+ "): Waiting for event thread to start ...");
			signal.waitForSignal(true);
			logger.info(getComponentID() + " (" + getSessionID()
					+ "): Waiting for event thread to start: DONE");
		} catch (Exception e) {
			logger.error("startServiceImpl() " + e.getMessage(), e);
		}
	}

	/**
	 * stops event thread
	 */

	protected void stopServiceImpl() {
		try {
			processEvents = false;
			logger.info(getComponentID() + " (" + getSessionID()
					+ "): Waiting for event thread to stop ...");
			signal.waitForSignal(false);
			logger.info(getComponentID() + " (" + getSessionID()
					+ "): Waiting for event thread to stop: DONE");
		} catch (Exception e) {
			logger.error("stopServiceImpl() " + e.getClass(), e);
		}
	}

	@Override
	public void onEvent(Event event) {
		DefaultEventPrioritizer.assignPriority(event);
		eventQueue.put(event);
	}

	/**
	 * should NOT be synchronized to avoid deadlock with stopService() method
	 * (stopService() waits until Consumer.run() terminates, Consumer.run()
	 * might wait for stopService() to terminate if method processEvent were
	 * synchronized).
	 */
	protected abstract void processEvent(Event event);

	protected void sendActionsToEUE(ActionSpecEvent event) {
		dataService.onOutEvent(event);
	}

	/**
	 * Repackages {@link AnalysisResultsProvisionEvent} into
	 * 
	 * @param analysisResultEvent
	 * @param uID
	 */
	protected void sendRawResultsToEUE(
			AnalysisResultsProvisionEvent analysisResultEvent, UserID uID) {
		String actionAgentID = description.getComponentID();
		Set<ServiceID> aTypeIDs = analysisResultEvent.getAnalysisTypeIDs();
		for (ServiceID aTypeID : aTypeIDs) {
			logger.info(actionAgentID + ": sendRawResultsToEUE");

			SessionID sessionID = analysisResultEvent.getSessionID();

			AgentAction actionSpec = new AgentAction();

			// Only the original requester will receive mirroring feedback
			actionSpec.setActionRecipient(uID);

			ActionSpecEvent actionSpecEvent = new ActionSpecEvent(sessionID,
					actionAgentID);

			List<AnalysisResult> results = analysisResultEvent
					.getResults(aTypeID);
			if (results.isEmpty()) {
				AnalysisType aType = (AnalysisType) getServiceTypeFromSessionConfig(aTypeID);

				NoAnalysisResults noResults = new NoAnalysisResults(aType);
				actionSpec.addActionComponent(noResults);
			}

			for (AnalysisResult result : results) {
				actionSpec.addActionComponent(result);
			}
			actionSpecEvent.addActionSpec(actionSpec);
			dataService.onOutEvent(actionSpecEvent);
		}
	}

	public ServiceType getServiceTypeFromSessionConfig(ServiceID id) {
		ServiceType type = this.activeRuntime.getSessionConfig()
				.getAgentServiceType(id);
		return type;
	}

	class Consumer implements Runnable {

		@Override
		public void run() {
			try {
				signal.signalGo();
				do {
					Event event = eventQueue.take();
					processEvent(event);
				} while (processEvents);
				signal.signalStop();
			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}
		}
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		buffer.append(this.getClass().getSimpleName());
		buffer.append(": ").append(getDataString());
		buffer.append("]");
		return buffer.toString();
	}

	public String getDataString() {
		StringBuffer buffer = new StringBuffer();

		buffer.append("agentID=").append(description.getComponentID());
		buffer.append(", class=").append(description.getClass());
		buffer.append(", serviceTypes =").append(serviceTypesToString());
		return buffer.toString();
	}

	public String serviceTypesToString() {
		StringBuffer buffer = new StringBuffer();
		ServiceType type;
		//buffer.append("{");
		Iterator<ServiceType> iter = description.getServiceTypes().iterator();
		while (iter.hasNext()) {
			buffer.append("\n\t");
			type = iter.next();
			buffer.append(type.getServiceID());
			if (iter.hasNext()) {
				buffer.append(", ");
			}
		}
		//buffer.append("}");
		return buffer.toString();
	}

	public SessionID getSessionID() {
		return sessionID;
	}
}
