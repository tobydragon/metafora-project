package de.dfki.lasad.sessionmodel.jessfunctions;

import jess.Context;
import jess.JessException;
import jess.Userfunction;
import jess.Value;
import jess.ValueVector;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class CompareList2ListLong implements Userfunction {

	/** Create a new CompareList2List userfunction object */
	public CompareList2ListLong() {
		super();
	}

	/**
	 * Get the name of the compare-l2l user function
	 * 
	 * @see jess.Userfunction#getName()
	 */
	public String getName() {
		return "compare-l2l-long";
	}

	/**
	 * 
	 * Call the compare-l2l user function
	 * 
	 * @see jess.Userfunction#call(jess.ValueVector, jess.Context)
	 */
	public Value call(ValueVector vv, final Context context)
			throws JessException {
		if (vv.size() != 6) {
			throw new JessException(
					getName(),
					getName()
							+ " takes exactly five arguments:"
							+ "list selector 1, list 1, operator, list selector 2, list 2",
					vv.size() - 1);
		}

		Value listSelector1AsValue = vv.get(1).resolveValue(context);
		String listselector1 = listSelector1AsValue.stringValue(context);

		Value list1AsValue = vv.get(2).resolveValue(context);
		ValueVector list1 = list1AsValue.listValue(context);

		Value operatorAsValue = vv.get(3).resolveValue(context);
		String operator = operatorAsValue.stringValue(context);

		Value listSelector2AsValue = vv.get(4).resolveValue(context);
		String listselector2 = listSelector2AsValue.stringValue(context);

		Value list2AsValue = vv.get(5).resolveValue(context);
		ValueVector list2 = list2AsValue.listValue(context);

		long refVal;
		boolean result;
		if (BasicOperators.GREATER.equalsIgnoreCase(operator)
				|| BasicOperators.GREATER_OR_EQUAL.equalsIgnoreCase(operator)) {
			if (SetSelectors.ALL.equalsIgnoreCase(listselector2)) {
				refVal = getMax(list2, context);
			} else if (SetSelectors.EXISTS.equalsIgnoreCase(listselector2)) {
				refVal = getMin(list2, context);
			} else {
				throw new JessException(getName(), "Unable to compare lists",
						"Unknown list selector for list 12: " + listselector2);
			}
			result = compare(listselector1, list1, operator, refVal, context);
		} else if (BasicOperators.LESS.equalsIgnoreCase(operator)
				|| BasicOperators.LESS_OR_EQUAL.equalsIgnoreCase(operator)) {
			if (SetSelectors.ALL.equalsIgnoreCase(listselector2)) {
				refVal = getMin(list2, context);
			} else if (SetSelectors.EXISTS.equalsIgnoreCase(listselector2)) {
				refVal = getMax(list2, context);
			} else {
				throw new JessException(getName(), "Unable to compare lists",
						"Unknown list selector for list 12: " + listselector2);
			}
			result = compare(listselector1, list1, operator, refVal, context);
		} else if (BasicOperators.EQUAL.equalsIgnoreCase(operator)
				|| BasicOperators.UNEQUAL.equalsIgnoreCase(operator)) {
			result = compare(listselector1, list1, operator, listselector1,
					list1, context);
		} else {
			throw new JessException(getName(), "Unable to compare lists",
					"Invalid operator: " + operator);
		}

		return new Value(result);
	}

	private long getMax(ValueVector vv, final Context context)
			throws JessException {
		long max = Long.MIN_VALUE;
		for (int i = 0; i < vv.size(); ++i) {
			long v = vv.get(i).longValue(context);
			if (v > max) {
				max = v;
			}
		}
		return max;
	}

	private long getMin(ValueVector vv, final Context context)
			throws JessException {
		long min = Long.MAX_VALUE;
		for (int i = 0; i < vv.size(); ++i) {
			long v = vv.get(i).longValue(context);
			if (v < min) {
				min = v;
			}
		}
		return min;
	}

	private boolean compare(String listselector1, ValueVector list1,
			String operator, long refVal, final Context context)
			throws JessException {

		if (BasicOperators.GREATER.equalsIgnoreCase(operator)) {
			if (SetSelectors.ALL.equalsIgnoreCase(listselector1)) {
				for (int i = 0; i < list1.size(); ++i) {
					long v = list1.get(i).longValue(context);
					if (v <= refVal) {
						return false;
					}
				}
				return true;
			} else if (SetSelectors.EXISTS.equalsIgnoreCase(listselector1)) {
				for (int i = 0; i < list1.size(); ++i) {
					long v = list1.get(i).longValue(context);
					if (v > refVal) {
						return true;
					}
				}
				return false;
			} else {
				throw new JessException(getName(), "Unable to compare lists",
						"Unknown list selector for list 1: " + listselector1);
			}
		}

		else if (BasicOperators.GREATER_OR_EQUAL.equalsIgnoreCase(operator)) {
			if (SetSelectors.ALL.equalsIgnoreCase(listselector1)) {
				for (int i = 0; i < list1.size(); ++i) {
					long v = list1.get(i).longValue(context);
					if (v < refVal) {
						return false;
					}
				}
				return true;
			} else if (SetSelectors.EXISTS.equalsIgnoreCase(listselector1)) {
				for (int i = 0; i < list1.size(); ++i) {
					long v = list1.get(i).longValue(context);
					if (v >= refVal) {
						return true;
					}
				}
				return false;
			} else {
				throw new JessException(getName(), "Unable to compare lists",
						"Unknown list selector for list 1: " + listselector1);
			}
		}

		else if (BasicOperators.LESS.equalsIgnoreCase(operator)) {
			if (SetSelectors.ALL.equalsIgnoreCase(listselector1)) {
				for (int i = 0; i < list1.size(); ++i) {
					long v = list1.get(i).longValue(context);
					if (v >= refVal) {
						return false;
					}
				}
				return true;
			} else if (SetSelectors.EXISTS.equalsIgnoreCase(listselector1)) {
				for (int i = 0; i < list1.size(); ++i) {
					long v = list1.get(i).longValue(context);
					if (v < refVal) {
						return true;
					}
				}
				return false;
			} else {
				throw new JessException(getName(), "Unable to compare lists",
						"Unknown list selector for list 1: " + listselector1);
			}
		}

		else if (BasicOperators.LESS_OR_EQUAL.equalsIgnoreCase(operator)) {
			if (SetSelectors.ALL.equalsIgnoreCase(listselector1)) {
				for (int i = 0; i < list1.size(); ++i) {
					long v = list1.get(i).longValue(context);
					if (v > refVal) {
						return false;
					}
				}
				return true;
			} else if (SetSelectors.EXISTS.equalsIgnoreCase(listselector1)) {
				for (int i = 0; i < list1.size(); ++i) {
					long v = list1.get(i).longValue(context);
					if (v <= refVal) {
						return true;
					}
				}
				return false;
			} else {
				throw new JessException(getName(), "Unable to compare lists",
						"Unknown list selector for list 1: " + listselector1);
			}
		} else {
			throw new JessException(getName(), "Unable to compare lists",
					"Unknown operator: " + operator);
		}

	}

	private boolean compare(String listselector1, ValueVector list1,
			String operator, String listselector2, ValueVector list2,
			final Context context) throws JessException {

		if (BasicOperators.EQUAL.equalsIgnoreCase(operator)) {

			if (SetSelectors.EXISTS.equalsIgnoreCase(listselector1)
					&& SetSelectors.EXISTS.equalsIgnoreCase(listselector2)) {

				for (int i = 0; i < list1.size(); ++i) {
					for (int j = 0; j < list2.size(); ++j) {
						if (list1.get(i).equals(list2.get(j))) {
							return true;
						}
					}
				}
				return false;
			}

			else if (SetSelectors.EXISTS.equalsIgnoreCase(listselector1)
					&& SetSelectors.ALL.equalsIgnoreCase(listselector2)) {
				for (int i = 0; i < list1.size(); ++i) {
					boolean retVal = true;
					for (int j = 0; j < list2.size(); ++j) {
						if (!list1.get(i).equals(list2.get(j))) {
							retVal = false;
							break;
						}
					}
					if (retVal) {
						return true;
					}
				}
				return false;
			}

			else if (SetSelectors.ALL.equalsIgnoreCase(listselector1)
					&& SetSelectors.EXISTS.equalsIgnoreCase(listselector2)) {
				for (int i = 0; i < list1.size(); ++i) {
					boolean retVal = false;
					for (int j = 0; j < list2.size(); ++j) {
						if (list1.get(i).equals(list2.get(j))) {
							retVal = true;
							break;
						}
					}
					if (!retVal) {
						return false;
					}
				}
				return true;
			}

			else if (SetSelectors.ALL.equalsIgnoreCase(listselector1)
					&& SetSelectors.ALL.equalsIgnoreCase(listselector2)) {
				for (int i = 0; i < list1.size(); ++i) {
					for (int j = 0; j < list2.size(); ++j) {
						if (!list1.get(i).equals(list2.get(j))) {
							return false;
						}
					}
				}
				return true;
			}

			else {
				throw new JessException(getName(), "Unable to compare lists",
						"Something wrong with list selector 1 ("
								+ listselector1 + ") or 2 (" + listselector2
								+ ")");
			}
		}

		else if (BasicOperators.UNEQUAL.equalsIgnoreCase(operator)) {

			if (SetSelectors.EXISTS.equalsIgnoreCase(listselector1)
					&& SetSelectors.EXISTS.equalsIgnoreCase(listselector2)) {

				for (int i = 0; i < list1.size(); ++i) {
					for (int j = 0; j < list2.size(); ++j) {
						if (!list1.get(i).equals(list2.get(j))) {
							return true;
						}
					}
				}
				return false;
			}

			else if (SetSelectors.EXISTS.equalsIgnoreCase(listselector1)
					&& SetSelectors.ALL.equalsIgnoreCase(listselector2)) {
				for (int i = 0; i < list1.size(); ++i) {
					boolean retVal = true;
					for (int j = 0; j < list2.size(); ++j) {
						if (list1.get(i).equals(list2.get(j))) {
							retVal = false;
							break;
						}
					}
					if (retVal) {
						return true;
					}
				}
				return false;
			}

			else if (SetSelectors.ALL.equalsIgnoreCase(listselector1)
					&& SetSelectors.EXISTS.equalsIgnoreCase(listselector2)) {
				for (int i = 0; i < list1.size(); ++i) {
					boolean retVal = false;
					for (int j = 0; j < list2.size(); ++j) {
						if (!list1.get(i).equals(list2.get(j))) {
							retVal = true;
							break;
						}
					}
					if (!retVal) {
						return false;
					}
				}
				return true;
			}

			else if (SetSelectors.ALL.equalsIgnoreCase(listselector1)
					&& SetSelectors.ALL.equalsIgnoreCase(listselector2)) {
				for (int i = 0; i < list1.size(); ++i) {
					for (int j = 0; j < list2.size(); ++j) {
						if (list1.get(i).equals(list2.get(j))) {
							return false;
						}
					}
				}
				return true;
			}

			else {
				throw new JessException(getName(), "Unable to compare lists",
						"Something wrong with list selector 1 ("
								+ listselector1 + ") or 2 (" + listselector2
								+ ")");
			}

		} else {
			throw new JessException(getName(), "Unable to compare lists",
					"Unsupported operator: " + operator);
		}

	}
}
