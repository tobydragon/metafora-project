package de.dfki.lasad.core.components.description;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.RuleAnalysisType;
import de.dfki.lasad.agents.data.meta.ServiceType;
import de.dfki.lasad.core.components.configuration.IAgentConfiguration;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescription extends AbstractComponentDescription {

	static Log logger = LogFactory.getLog(AgentDescription.class);

	private String displayName = null;

	private List<AnalysisType> analysisTypeList = new Vector<AnalysisType>();
	private Map<String, AnalysisType> analysisTypesMap = new HashMap<String, AnalysisType>();

	private List<ActionType> actionTypeList = new Vector<ActionType>();
	private Map<String, ActionType> actionTypesMap = new HashMap<String, ActionType>();

	private boolean confReadable = false;
	private boolean confWritable = false;

	private String supportedOntology = null;
	private String configFEFilepath = null;

	public AgentDescription(BasicDescription basicDesc) {
		super(basicDesc);
	}

	public IAgentConfiguration getConfiguration() {
		return (IAgentConfiguration) configuration;
	}

	public List<AnalysisType> getAnalysisTypes() {
		return analysisTypeList;
	}

	public List<RuleAnalysisType> getAnalysisRuleTypes() {
		List<RuleAnalysisType> rTypes = new Vector<RuleAnalysisType>();
		for (AnalysisType aType : analysisTypeList) {
			if (aType instanceof RuleAnalysisType) {
				rTypes.add((RuleAnalysisType) aType);
			}
		}
		return rTypes;
	}

	public List<ActionType> getActionTypes() {
		return actionTypeList;
	}

	public AnalysisType getAnalysisType(String typeID) {
		return analysisTypesMap.get(typeID);
	}

	public ActionType getActionType(String typeID) {
		return actionTypesMap.get(typeID);
	}

	public List<ServiceType> getTypesToPublish() {
		List<ServiceType> typesToPublish = new Vector<ServiceType>();
		IAgentConfiguration agentConf = (IAgentConfiguration) configuration;

		boolean publishAllAnalysisTypes = agentConf != null
				&& agentConf.doPublishAllAnalysisTypes();
		for (ServiceType t : analysisTypeList) {
			if (t.doPublishToEndUser() || publishAllAnalysisTypes) {
				typesToPublish.add(t);
			}
		}

		boolean publishAllActionTypes = agentConf != null
				&& agentConf.doPublishAllActionTypes();
		for (ServiceType t : actionTypeList) {
			if (t.doPublishToEndUser() || publishAllActionTypes) {
				typesToPublish.add(t);
			}
		}
		return typesToPublish;
	}

	// should be called once all information is complete
	public void setup() throws Exception {
		super.setup();
		if (this.configuration != null) {
			IAgentConfiguration agentConf = (IAgentConfiguration) configuration;
			agentConf.replaceAgentID(basicDescr.id);
			analysisTypeList = agentConf.getAnalysisTypes();
			for (AnalysisType aType : analysisTypeList) {
				analysisTypesMap.put(aType.getTypeID(), aType);
			}
			actionTypeList = agentConf.getActionTypes();
			for (ActionType aType : actionTypeList) {
				actionTypesMap.put(aType.getTypeID(), aType);
			}
		}
	}

	public boolean isConfigReadable() {
		return confReadable;
	}

	public void setConfigReadable(boolean confReadable) {
		this.confReadable = confReadable;
	}

	public boolean isConfigWritable() {
		return confWritable;
	}

	public void setConfigWritable(boolean confWritable) {
		this.confWritable = confWritable;
	}

	public String getSupportedOntology() {
		return supportedOntology;
	}

	public void setSupportedOntology(String supportedOntology) {
		this.supportedOntology = supportedOntology;
	}

	public String getConfigFEFilepath() {
		return configFEFilepath;
	}

	public void setConfigFEFilepath(String configFEFilepath) {
		this.configFEFilepath = configFEFilepath;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	@Override
	public String toString() {
		String basicInfos = super.toString();
		StringBuffer analysisTypesBuf = new StringBuffer();
		analysisTypesBuf.append("{");
		for (Iterator<String> typeIter = analysisTypesMap.keySet().iterator(); typeIter
				.hasNext();) {
			analysisTypesBuf.append(typeIter.next());
			if (typeIter.hasNext()) {
				analysisTypesBuf.append(", ");
			}
		}
		analysisTypesBuf.append("}");

		return basicInfos + ", analysisTypes=" + analysisTypesBuf.toString();
	}

}
