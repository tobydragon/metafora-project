package de.dfki.lasad.core.components.description;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.ServiceType;
import lasad.shared.dfki.meta.agents.SupportedOntologiesDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.components.configuration.IAgentConfiguration;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescription extends AbstractComponentDescription {

	static Log logger = LogFactory.getLog(AgentDescription.class);

	private String displayName = null;
	private String description = null;

	private List<ServiceType> serviceTypeList = new Vector<ServiceType>();
	private Map<ServiceID, ServiceType> id2serviceType = new HashMap<ServiceID, ServiceType>();

	private boolean configCompiled = false;
	private boolean confReadable = false;
	private boolean confWritable = false;

	private SupportedOntologiesDef supportedOntology = null;

	public AgentDescription(BasicDescription basicDesc) {
		super(basicDesc);
	}

	public IAgentConfiguration getConfiguration() {
		return (IAgentConfiguration) configuration;
	}

	public List<ServiceType> getServiceTypes() {
		return serviceTypeList;
	}

	public ServiceType getServiceType(ServiceID serviceID) {
		return id2serviceType.get(serviceID);
	}

	/**
	 * Instantiates the lists and mappings of service types from the
	 * configuration. Should be called once all information is complete
	 */
	public void init() throws Exception {
		super.init();
		if (this.configuration != null) {
			IAgentConfiguration agentConf = (IAgentConfiguration) configuration;
			serviceTypeList = agentConf.getServiceTypes();
			for (ServiceType sType : serviceTypeList) {
				ServiceID sID = sType.getServiceID();
				id2serviceType.put(sID, sType);
			}
		}
	}

	public boolean isConfigCompiled() {
		return configCompiled;
	}

	public void setConfigCompiled(boolean configCompiled) {
		this.configCompiled = configCompiled;
	}

	/**
	 * Some analysis types must be pre-processed before use. (How to pre-process
	 * is codified in the specific configuration class.)
	 */
	public void compileNotYetCompiledAnalysisTypes() {
		if (this.configuration != null) {
			getConfiguration().compileNotYetCompiledAnalysisTypes();
		}
	}

	public boolean isConfigReadable() {
		return confReadable;
	}

	public void setConfigReadable(boolean confReadable) {
		this.confReadable = confReadable;
	}

	public boolean isConfigWritable() {
		return confWritable;
	}

	public void setConfigWritable(boolean confWritable) {
		this.confWritable = confWritable;
	}

	public SupportedOntologiesDef getSupportedOntology() {
		return supportedOntology;
	}

	public void setSupportedOntology(SupportedOntologiesDef supportedOntology) {
		this.supportedOntology = supportedOntology;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		String basicInfos = super.toString();
		StringBuffer serviceTypesBuf = new StringBuffer();
		serviceTypesBuf.append("{");
		for (Iterator<ServiceID> typeIter = id2serviceType.keySet().iterator(); typeIter
				.hasNext();) {
			serviceTypesBuf.append(typeIter.next());
			if (typeIter.hasNext()) {
				serviceTypesBuf.append(", ");
			}
		}
		serviceTypesBuf.append("}");

		return basicInfos + ", serviceTypes=" + serviceTypesBuf.toString();
	}

}
