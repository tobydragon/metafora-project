package de.dfki.lasad.authoring;

import java.util.List;

import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;
import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionListFE;
import lasad.shared.dfki.authoring.frontenddata.Agents2OntologiesFE;
import lasad.shared.dfki.authoring.frontenddata.Agents2SessionsFE;
import lasad.shared.dfki.authoring.frontenddata.SessionStatusMapFE;
import lasad.shared.dfki.meta.ServiceStatus;
import lasad.shared.dfki.meta.agents.ActionAgentConfigData;
import lasad.shared.dfki.meta.ontology.Ontology;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.instances.action.ActionAgent;
import de.dfki.lasad.agents.instances.action.ActionAgentConfig;
import de.dfki.lasad.core.ConfigurationDatabase;
import de.dfki.lasad.core.ConfigurationManager;
import de.dfki.lasad.core.FeedbackConfigManager;
import de.dfki.lasad.core.ResourcesConfigManager;
import de.dfki.lasad.core.RuntimeConfigManager;
import de.dfki.lasad.core.components.collections.AgentDescriptions;
import de.dfki.lasad.core.components.collections.AgentRuntimeConfig;
import de.dfki.lasad.core.components.configuration.IAgentConfiguration;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.BasicDescription;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.session.Session;
import de.dfki.lasad.session.SessionActiveRuntime;
import de.dfki.lasad.session.SessionManager;
import de.dfki.lasad.util.ObjectToFETranslator;

/**
 * Provides methods to update configurations and runtime and to get state
 * information. Methods inputs and outputs are compliant with the frontend data
 * model ('...FE' objects).
 * 
 * @author oliverscheuer
 * 
 */
public class BackendPort {

	private static Log logger = LogFactory.getLog(BackendPort.class);

	SessionManager sessionManager;
	ConfigurationManager configManager;

	public BackendPort(SessionManager sessionManager,
			ConfigurationManager configManager) {
		this.sessionManager = sessionManager;
		this.configManager = configManager;
	}

	public void addOrUpdateAgent(AgentDescriptionFE agentDescrFE) {
		addOrUpdateAgentConfigFiles(agentDescrFE);
		AgentDescription aDescr = translate(agentDescrFE);
		ResourcesConfigManager rm = configManager.getResourcesManager();
		rm.addOrUpdateAgentDescription(aDescr);
	}

	public void deleteAgent(String agentID) {
		FeedbackConfigManager.deleteAgentConfigFiles(agentID);

		ResourcesConfigManager resourcesManager = configManager
				.getResourcesManager();
		resourcesManager.deleteAgentDescription(agentID);

		RuntimeConfigManager runtimeManager = configManager.getRuntimeManager();
		runtimeManager.deleteAgentRuntimeEntries(agentID);
	}

	public void compileAgent(String agentID) {
		ResourcesConfigManager resourcesManager = configManager
				.getResourcesManager();
		AgentDescription aDescr = resourcesManager.getAgentDescription(agentID);
		IAgentConfiguration aConf = aDescr.getConfiguration();
		if (aConf != null) {
			aConf.compileNotYetCompiledAnalysisTypes();
			aDescr.setConfigCompiled(true);
			resourcesManager.addOrUpdateAgentDescription(aDescr);
		}
	}

	public void addAgent2SessionMapping(String agentID, String sessionID) {
		RuntimeConfigManager runtimeManager = configManager.getRuntimeManager();
		runtimeManager.addAgent2SessionMapping(agentID, sessionID);
	}

	public void removeAgent2SessionMapping(String agentID, String sessionID) {
		RuntimeConfigManager runtimeManager = configManager.getRuntimeManager();
		runtimeManager.removeAgent2SessionMapping(agentID, sessionID);
	}

	public void addAgent2OntologyMapping(String agentID, String ontologyID) {
		RuntimeConfigManager runtimeManager = configManager.getRuntimeManager();
		runtimeManager.addAgent2OntologyMapping(agentID, ontologyID);
	}

	public void removeAgent2OntologyMapping(String agentID, String ontologyID) {
		RuntimeConfigManager runtimeManager = configManager.getRuntimeManager();
		runtimeManager.removeAgent2OntologyMapping(agentID, ontologyID);
	}

	public void startSessionServices(String sessionID) {
		sessionManager.tryStartSession(sessionID);
	}

	public void stopSessionServices(String sessionID) {
		sessionManager.stopSession(sessionID);
	}

	public AgentDescriptionListFE getAgentDescriptions() {
		ResourcesConfigManager rm = configManager.getResourcesManager();
		AgentDescriptions aDescrs = rm.getAgentDescriptions();
		return translate(aDescrs);
	}

	public Agents2OntologiesFE getAgents2Ontologies() {
		Agents2OntologiesFE a2oFE = new Agents2OntologiesFE();
		List<Ontology> ontologies = sessionManager.getOntologies();
		RuntimeConfigManager rm = configManager.getRuntimeManager();
		AgentRuntimeConfig aRuntime = rm.getAgentRuntime();
		for (Ontology o : ontologies) {
			String oID = o.getOntologyID();
			List<String> aIDs = aRuntime.getAgentsForOntology(oID);
			for (String aID : aIDs) {
				a2oFE.addMapping(aID, oID);
			}
		}
		return a2oFE;
	}

	public Agents2SessionsFE getAgents2Sessions() {
		Agents2SessionsFE a2sFE = new Agents2SessionsFE();
		List<Session> sessions = sessionManager.getSessions();
		RuntimeConfigManager rm = configManager.getRuntimeManager();
		AgentRuntimeConfig aRuntime = rm.getAgentRuntime();
		for (Session s : sessions) {
			String sID = s.getID().getIdAsString();
			List<String> aIDs = aRuntime.getAgentsForSession(sID);
			for (String aID : aIDs) {
				a2sFE.addMapping(aID, sID);
			}
		}
		return a2sFE;
	}

	public SessionStatusMapFE getSessionStatusMap() {
		List<Session> sessions = sessionManager.getSessions();
		return translate(sessions);
	}

//	public AgentDescriptionFE translate(AgentDescription ad) {
//		AgentDescriptionFE adFE = new AgentDescriptionFE();
//		adFE.setAgentID(ad.getComponentID());
//		adFE.setDisplayName(ad.getDisplayName());
//		adFE.setDescription(ad.getDescription());
//		adFE.setSupportedOntology(ad.getSupportedOntology());
//		adFE.setConfigCompleted(ad.isConfigCompleted());
//		adFE.setConfReadable(ad.isConfigReadable());
//		adFE.setConfWritable(ad.isConfigWritable());
//		return adFE;
//	}

	private void addOrUpdateAgentConfigFiles(AgentDescriptionFE agentDescrFE) {
		try {
			// write config data to file
			ActionAgentConfigData configData = agentDescrFE.getConfData();
			FeedbackConfigManager.writeAgentConfig(configData);
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage());

		}
	}

	private SessionStatusMapFE translate(List<Session> sessions) {
		SessionStatusMapFE statusMapFE = new SessionStatusMapFE();

		for (Session s : sessions) {
			String sessionID = s.getID().getIdAsString();
			ServiceStatus sStatus = s.getStatus();
			statusMapFE.addSessionStatus(sessionID, sStatus);
			SessionActiveRuntime sessionActiveRuntime = s.getActiveRuntime();
			if (sessionActiveRuntime != null) {
				for (IAgent a : sessionActiveRuntime.getAgents()) {
					String agentID = a.getComponentID();
					ServiceStatus aStatus = a.getServiceStatus();
					statusMapFE.addAgentStatus(sessionID, agentID, aStatus);
				}
			}
		}
		return statusMapFE;
	}

	private AgentDescriptionListFE translate(AgentDescriptions agentDescrs) {
		AgentDescriptionListFE aDescrs = new AgentDescriptionListFE();
		for (String aID : agentDescrs.getAgentDescriptionIDs()) {
			AgentDescription ad = agentDescrs.getAgentDescription(aID);
			AgentDescriptionFE adFE = ObjectToFETranslator.translate(ad);
			aDescrs.add(adFE);
		}
		return aDescrs;
	}

	private AgentDescription translate(AgentDescriptionFE agentDescrFE) {
		try {
			String agentID = agentDescrFE.getAgentID();

			BasicDescription basicDescr = new BasicDescription();
			basicDescr.id = agentID;
			basicDescr.classs = ActionAgent.class.getName();
			basicDescr.confclass = ActionAgentConfig.class.getName();

			String relAgentConfFilePath = ConfigurationDatabase
					.getAgentConfigMasterRelFilepath(agentID);
			basicDescr.conffile = relAgentConfFilePath;

			AgentDescription agentDescr = new AgentDescription(basicDescr);
			agentDescr
					.setSupportedOntology(agentDescrFE.getSupportedOntology());
			agentDescr.setConfigCompiled(agentDescrFE.isConfigCompleted());
			agentDescr.setConfigReadable(agentDescrFE.isConfReadable());
			agentDescr.setConfigWritable(agentDescrFE.isConfWritable());

			agentDescr.setDisplayName(agentDescrFE.getDisplayName());
			agentDescr.setDescription(agentDescrFE.getDescription());

			// agent description is complete, prepare for use (e.g., load conf
			// that has been written to file previously)
			agentDescr.init();

			return agentDescr;
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage());
			return null;
		}
	}

}
