package de.dfki.lasad.authoring;

import java.io.File;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.instances.jess.JessFeedbackAgent;
import de.dfki.lasad.agents.instances.jess.JessFeedbackAgentConfiguration;
import de.dfki.lasad.authoring.converter.AgentConfigConverterFE2BE;
import de.dfki.lasad.authoring.model.AgentConfigFE;
import de.dfki.lasad.authoring.model.AgentDescriptionFE;
import de.dfki.lasad.authoring.model.AgentDescriptionListFE;
import de.dfki.lasad.authoring.model.Agents2OntologiesFE;
import de.dfki.lasad.authoring.model.Agents2SessionsFE;
import de.dfki.lasad.authoring.model.ServiceStatusFE;
import de.dfki.lasad.authoring.model.SessionStatusMapFE;
import de.dfki.lasad.core.AgentsConfigManager;
import de.dfki.lasad.core.ConfigurationDatabase;
import de.dfki.lasad.core.ConfigurationManager;
import de.dfki.lasad.core.ResourcesConfigManager;
import de.dfki.lasad.core.RuntimeConfigManager;
import de.dfki.lasad.core.components.collections.AgentDescriptions;
import de.dfki.lasad.core.components.collections.AgentRuntimeConfig;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.BasicDescription;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.ServiceStatus;
import de.dfki.lasad.session.Session;
import de.dfki.lasad.session.SessionActiveRuntime;
import de.dfki.lasad.session.SessionManager;
import de.dfki.lasad.session.data.meta.Ontology;

/**
 * Provides methods to update configurations and runtime and to get state
 * information. Methods inputs and outputs are compliant with the frontend data
 * model ('...FE' objects).
 * 
 * @author oliverscheuer
 * 
 */
public class BackendPort {

	private static Log logger = LogFactory.getLog(BackendPort.class);

	SessionManager sessionManager;
	ConfigurationManager configManager;

	public BackendPort(SessionManager sessionManager,
			ConfigurationManager configManager) {
		this.sessionManager = sessionManager;
		this.configManager = configManager;
	}

	public void addOrUpdateAgent(AgentDescriptionFE agentDescrFE) {
		addOrUpdateAgentConfigFiles(agentDescrFE);
		AgentDescription aDescr = translate(agentDescrFE);
		ResourcesConfigManager rm = configManager.getResourcesManager();
		rm.addOrUpdateAgentDescription(aDescr);
	}

	public void deleteAgent(String agentID) {
		AgentsConfigManager.deleteAgentConfigFiles(agentID);

		ResourcesConfigManager resourcesManager = configManager.getResourcesManager();
		resourcesManager.deleteAgentDescription(agentID);

		RuntimeConfigManager runtimeManager = configManager.getRuntimeManager();
		runtimeManager.deleteAgentRuntimeEntries(agentID);
	}

	public void addAgent2SessionMapping(String agentID, String sessionID) {
		RuntimeConfigManager runtimeManager = configManager.getRuntimeManager();
		runtimeManager.addAgent2SessionMapping(agentID, sessionID);
	}

	public void removeAgent2SessionMapping(String agentID, String sessionID) {
		RuntimeConfigManager runtimeManager = configManager.getRuntimeManager();
		runtimeManager.removeAgent2SessionMapping(agentID, sessionID);
	}

	public void addAgent2OntologyMapping(String agentID, String ontologyID) {
		RuntimeConfigManager runtimeManager = configManager.getRuntimeManager();
		runtimeManager.addAgent2OntologyMapping(agentID, ontologyID);
	}

	public void removeAgent2OntologyMapping(String agentID, String ontologyID) {
		RuntimeConfigManager runtimeManager = configManager.getRuntimeManager();
		runtimeManager.removeAgent2OntologyMapping(agentID, ontologyID);
	}

	public void startSessionServices(String sessionID) {
		sessionManager.tryStartSession(sessionID);
	}

	public void stopSessionServices(String sessionID) {
		sessionManager.stopSession(sessionID);
	}

	public AgentDescriptionListFE getAgentDescriptions() {
		ResourcesConfigManager rm = configManager.getResourcesManager();
		AgentDescriptions aDescrs = rm.getAgentDescriptions();
		return translate(aDescrs);
	}

	public Agents2OntologiesFE getAgents2Ontologies() {
		Agents2OntologiesFE a2oFE = new Agents2OntologiesFE();
		List<Ontology> ontologies = sessionManager.getOntologies();
		RuntimeConfigManager rm = configManager.getRuntimeManager();
		AgentRuntimeConfig aRuntime = rm.getAgentRuntime();
		for (Ontology o : ontologies) {
			String oID = o.getOntologyID();
			List<String> aIDs = aRuntime.getAgentsForOntology(oID);
			for (String aID : aIDs) {
				a2oFE.addMapping(aID, oID);
			}
		}
		return a2oFE;
	}

	public Agents2SessionsFE getAgents2Sessions() {
		Agents2SessionsFE a2sFE = new Agents2SessionsFE();
		List<Session> sessions = sessionManager.getSessions();
		RuntimeConfigManager rm = configManager.getRuntimeManager();
		AgentRuntimeConfig aRuntime = rm.getAgentRuntime();
		for (Session s : sessions) {
			String sID = s.getID().getIdAsString();
			List<String> aIDs = aRuntime.getAgentsForSession(sID);
			for (String aID : aIDs) {
				a2sFE.addMapping(aID, sID);
			}
		}
		return a2sFE;
	}

	public SessionStatusMapFE getSessionStatusMap() {
		List<Session> sessions = sessionManager.getSessions();
		return translate(sessions);
	}

	public ServiceStatusFE serviceStatusBE2FE(ServiceStatus serviceStatus) {
		if (serviceStatus == ServiceStatus.UNDER_CONSTRUCTION) {
			return ServiceStatusFE.UNDER_CONSTRUCTION;
		}
		if (serviceStatus == ServiceStatus.READY_TO_START) {
			return ServiceStatusFE.READY_TO_START;
		}
		if (serviceStatus == ServiceStatus.STARTING) {
			return ServiceStatusFE.STARTING;
		}
		if (serviceStatus == ServiceStatus.RUNNING) {
			return ServiceStatusFE.RUNNING;
		}
		if (serviceStatus == ServiceStatus.STOPPING) {
			return ServiceStatusFE.STOPPING;
		}
		if (serviceStatus == ServiceStatus.STALE) {
			return ServiceStatusFE.STALE;
		}
		logger.error("Unknown service status: " + serviceStatus);
		return null;
	}

	private void addOrUpdateAgentConfigFiles(AgentDescriptionFE agentDescrFE) {
		try {
			String agentID = agentDescrFE.getAgentID();

			// create folders
			AgentsConfigManager.createAgentFolderStructure(agentID);

			// write FE config to file
			AgentConfigFE configFE = agentDescrFE.getAgentConf();
			AgentsConfigManager.writeAgentConfigFE(configFE);

			// convert FE into BE config and write BE config to file
			JessFeedbackAgentConfiguration configBE = AgentConfigConverterFE2BE
					.toBEConf(configFE);
			AgentsConfigManager.writeAgentConfigBE(configBE);

		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage());
		}
	}

	private SessionStatusMapFE translate(List<Session> sessions) {
		SessionStatusMapFE statusMapFE = new SessionStatusMapFE();

		for (Session s : sessions) {
			String sessionID = s.getID().getIdAsString();
			ServiceStatusFE sStatus = serviceStatusBE2FE(s.getStatus());
			statusMapFE.addSessionStatus(sessionID, sStatus);
			SessionActiveRuntime sessionActiveRuntime = s.getActiveRuntime();
			if (sessionActiveRuntime != null) {
				for (IAgent a : sessionActiveRuntime.getAgents()) {
					String agentID = a.getComponentID();
					ServiceStatusFE aStatus = serviceStatusBE2FE(a
							.getServiceStatus());
					statusMapFE.addAgentStatus(sessionID, agentID, aStatus);
				}
			}
		}
		return statusMapFE;
	}

	private AgentDescriptionListFE translate(AgentDescriptions agentDescrs) {

		AgentDescriptionListFE aDescrs = new AgentDescriptionListFE();
		for (String aID : agentDescrs.getAgentDescriptionIDs()) {
			AgentDescription ad = agentDescrs.getAgentDescription(aID);
			AgentDescriptionFE adFE = new AgentDescriptionFE();
			adFE.setAgentID(ad.getComponentID());
			adFE.setSupportedOntology(ad.getSupportedOntology());
			adFE.setConfReadable(ad.isConfigReadable());
			adFE.setConfWritable(ad.isConfigWritable());
			String configFEFilepath = ad.getConfigFEFilepath();
			if (configFEFilepath != null) {
				File configHome = ConfigurationDatabase.getConfigHome();
				File xmlConfFile = new File(configHome, configFEFilepath);
				if (!xmlConfFile.exists()) {
					logger.error("File not found: "
							+ xmlConfFile.getAbsolutePath());
				}
				AgentConfigFE xmlConfFE = AgentConfigFE
						.fromXMLFile(xmlConfFile);
				adFE.setAgentConf(xmlConfFE);
			}
			aDescrs.add(adFE);
		}
		return aDescrs;
	}

	private AgentDescription translate(AgentDescriptionFE agentDescrFE) {
		try {
			String agentID = agentDescrFE.getAgentID();

			BasicDescription basicDescr = new BasicDescription();
			basicDescr.id = agentID;
			basicDescr.classs = JessFeedbackAgent.class.getName();
			basicDescr.confclass = JessFeedbackAgentConfiguration.class
					.getName();

			String relAgentBEConfFilePath = ConfigurationDatabase
					.getAgentConfigFERelativeFilepath(agentID);
			basicDescr.conffile = relAgentBEConfFilePath;

			AgentDescription agentDescr = new AgentDescription(basicDescr);
			agentDescr
					.setSupportedOntology(agentDescrFE.getSupportedOntology());
			agentDescr.setConfigReadable(agentDescrFE.isConfReadable());
			agentDescr.setConfigWritable(agentDescrFE.isConfWritable());

			String relAgentFEConfFilePath = ConfigurationDatabase
					.getAgentConfigFERelativeFilepath(agentID);
			agentDescr.setConfigFEFilepath(relAgentFEConfFilePath);

			// agent description is complete, prepare for use
			agentDescr.setup();

			return agentDescr;
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage());
			return null;
		}
	}

}
