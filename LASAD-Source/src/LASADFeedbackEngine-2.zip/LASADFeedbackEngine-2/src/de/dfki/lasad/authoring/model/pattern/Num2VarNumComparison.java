package de.dfki.lasad.authoring.model.pattern;

/**
 * 
 * Comparison of a numeric variable to some other numeric variable.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class Num2VarNumComparison extends VariableComparison {

	private Num2NumOperator operator;
	private PropertyVariable rightExpr;
	private int offset;

	public Num2NumOperator getOperator() {
		return operator;
	}

	public void setOperator(Num2NumOperator operator) {
		this.operator = operator;
	}

	public PropertyVariable getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(PropertyVariable rightExpr) {
		this.rightExpr = rightExpr;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	protected VariableComparison getInverseBasic() {
		Num2VarNumComparison inverted = new Num2VarNumComparison();
		inverted.setOperator(getOperator().invert());
		inverted.setOffset((-1) * getOffset());
		return inverted;
	}

}
