package de.dfki.lasad.agents.instances.action.tasks;

import java.util.TimerTask;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class ActionTask extends TimerTask {

}
