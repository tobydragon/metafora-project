package de.dfki.lasad.events.eue.user.object;

import java.util.List;

import de.dfki.lasad.events.eue.EUEEventID;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.objects.EUEObject;

public class DeleteObjectEvent extends ObjectActionEvent {

	public DeleteObjectEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID,
			List<EUEObject> eueObject) {
		super(sessionID, srcCompId, eueEventID, userID, eueObject);
	}

	public DeleteObjectEvent(SessionID sessionID,
			EUEEventID eueEventId, String srcComponentId) {
		super(sessionID, srcComponentId, eueEventId);
	}
	
	public DeleteObjectEvent cloneWithoutObjects() {
		DeleteObjectEvent clone = new DeleteObjectEvent(getSessionID(),
				getEueEventID(), getSourceComponentID());
		clone.setUserID(getUserID());
		return clone;
	}

}
