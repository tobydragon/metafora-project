package de.dfki.lasad.events.eue.admin.agent.in;

import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AddAgentToOntologyEvent extends EUEAgentAdminEvent {

	private String agentID;
	private String ontologyID;

	public AddAgentToOntologyEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public String getOntologyID() {
		return ontologyID;
	}

	public void setOntologyID(String ontologyID) {
		this.ontologyID = ontologyID;
	}

	@Override
	public String toString() {
		return "AddAgentToOntologyEvent [agentID=" + agentID + ", ontologyID="
				+ ontologyID + "]";
	}

}
