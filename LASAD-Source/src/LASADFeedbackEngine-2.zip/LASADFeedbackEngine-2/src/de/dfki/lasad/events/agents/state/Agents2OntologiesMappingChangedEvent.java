package de.dfki.lasad.events.agents.state;

/**
 * Notification that the Feedback-Engine configuration has changed.
 * 
 * @author oliverscheuer
 * 
 */
public class Agents2OntologiesMappingChangedEvent extends AFStateChangedEvent {

	public Agents2OntologiesMappingChangedEvent(String srcCompId) {
		super(srcCompId);
	}
}
