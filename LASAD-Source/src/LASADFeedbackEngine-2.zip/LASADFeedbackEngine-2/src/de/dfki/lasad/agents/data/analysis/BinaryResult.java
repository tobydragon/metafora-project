package de.dfki.lasad.agents.data.analysis;

/**
 * 
 * @author oliverscheuer
 * 
 */
public interface BinaryResult {

	public boolean getValue();

	public void setValue(boolean value);

}
