package de.dfki.lasad.agents.instances.jess;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PhaseProbability {

	String phaseID;
	double probability;

	public PhaseProbability(String phaseID, double probability) {
		this.phaseID = phaseID;
		this.probability = probability;
	}

	@Override
	public String toString() {
		return "[" + phaseID + ": " + probability + "]";
	}

}
