package de.dfki.lasad.sessionmodel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.session.data.EUEID;
import de.dfki.lasad.session.data.objects.EUEObjectID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessIDMapper {

	private static Log logger = LogFactory.getLog(JessIDMapper.class);

	/**
	 * TODO Currently only objectIDs are supported. Later versions should also
	 * support other kinds of IDs (e.g., userIDs). This might also require
	 * changes in the {@link JessModelController}.
	 * 
	 * @param jessID
	 * @return
	 */
	public static EUEID jess2EUEID(String jessID) {
		return new EUEObjectID(jessID.substring(jessID.indexOf("_") + 1));
	}

}
