package de.dfki.lasad.agents.logic.action.patternfilter;

import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.agents.instances.TaskScheduler;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ObjectFilter_LastModTimeMaxAge extends ObjectFilter implements
		ObjectFilter_LastModTime {

	private long maxAgeInMilliSecs;
	private TaskScheduler taskSchedulerRef;

	public ObjectFilter_LastModTimeMaxAge(int maxAgeInSecs,
			TaskScheduler taskSchedulerRef) {
		this.maxAgeInMilliSecs = 1000L * maxAgeInSecs;
		this.taskSchedulerRef = taskSchedulerRef;
	}

	@Override
	public boolean keep(ObjectResult oResult) {
		long objectAge = System.currentTimeMillis()
				- oResult.getLastModificationTime();
		if (objectAge > maxAgeInMilliSecs) {
			return false;
		} else {
			long timerDelay = (maxAgeInMilliSecs - objectAge) + 1;
			// check again when object leaves relevant interval
			taskSchedulerRef.scheduleAnalysisTask(oResult, timerDelay);
			return true;
		}
	}

}
