package de.dfki.lasad.agents.logic.provision.actionsort;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgSortComparator_AssignedPriority extends MsgSortComparator {

	public MsgSortComparator_AssignedPriority(MsgSortComparator tieBreaker) {
		super(tieBreaker);
	}

	@Override
	protected int compareImpl(ActionTypeResult result1, ActionTypeResult result2) {
		double utilityDiff = result1.getUtility() - result2.getUtility();
		if (utilityDiff == 0) {
			return 0;
		}
		return (utilityDiff > 0) ? 1 : -1;
	}

}
