package de.dfki.lasad.agents.data.analysis.user;

import lasad.shared.dfki.meta.agents.analysis.AnalysisType;
import de.dfki.lasad.agents.data.analysis.BinaryResult;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class UserBinaryResult extends UserResult implements BinaryResult {

	protected boolean value = true;

	public UserBinaryResult(AnalysisType analysisType) {
		super(analysisType);
	}

	public UserBinaryResult(AnalysisType analysisType, UserID userID) {
		super(analysisType, userID);
	}

	public UserBinaryResult(AnalysisType analysisType, UserID userID,
			boolean value) {
		this(analysisType, userID);
		this.value = value;
	}

	public boolean getValue() {
		return value;
	}

	public void setValue(boolean value) {
		this.value = value;
	}

	@Override
	public String getValueAsString() {
		return String.valueOf(value);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (value ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserBinaryResult other = (UserBinaryResult) obj;
		if (value != other.value)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UserBinaryResult [value=" + value + ", userID=" + userID
				+ ", id=" + id + ", analysisType=" + analysisType
				+ ", detectionTs=" + detectionTs + ", properties=" + properties
				+ "]";
	}

	@Override
	public String toSimpleString() {
		return getClass().getSimpleName() + ": [id=" + id + ", type="
				+ analysisType.getServiceID() + ", user=" + userID + "]";
	}

}
