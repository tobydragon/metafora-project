package de.dfki.lasad.dataservice.lasad.translators;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import junit.framework.TestCase;
import lasad.shared.dfki.meta.ontology.Ontology;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class OntologyXMLTest extends TestCase {

	private static Log logger = LogFactory.getLog(OntologyXMLTest.class);
	
	private String argunautOntologyPath = "/Users/oliverscheuer/eclipse-workspace/LASAD-Server/conf/default/ontology/ARGUNAUT.xml";
	private String climateEthicsOntologyPath = "/Users/oliverscheuer/eclipse-workspace/LASAD-Server/conf/default/ontology/climate_ethics_coll_en.xml";
	private String newFeaturesOntologyPath = "/Users/oliverscheuer/eclipse-workspace/LASAD-Server/conf/default/ontology/NewFeaturesOntology.xml";

	public void testParseArgunautOntology() {
		File ontologyFile = new File(argunautOntologyPath);
		String ontologyXML = file2String(ontologyFile);
		Ontology onto = OntologyXML.parseOntology(ontologyXML);
		logger.info(onto);
	}
	
	public void testParseClimateEthicsOntology() {
		File ontologyFile = new File(climateEthicsOntologyPath);
		String ontologyXML = file2String(ontologyFile);
		Ontology onto = OntologyXML.parseOntology(ontologyXML);
		logger.info(onto);
	}
	
	public void testParseNewFeaturesOntology() {
		File ontologyFile = new File(newFeaturesOntologyPath);
		String ontologyXML = file2String(ontologyFile);
		Ontology onto = OntologyXML.parseOntology(ontologyXML);
		logger.info(onto);
	}
	
	public String file2String(File f){
		StringBuffer buf = new StringBuffer();
		try {
			BufferedReader in = new BufferedReader(new FileReader(f));
			String line;
			while (true) {
				line = in.readLine();
				if (line == null) {
					break;
				}
				buf.append(line);
				buf.append("\n");
			}
			return buf.toString();
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}
}
