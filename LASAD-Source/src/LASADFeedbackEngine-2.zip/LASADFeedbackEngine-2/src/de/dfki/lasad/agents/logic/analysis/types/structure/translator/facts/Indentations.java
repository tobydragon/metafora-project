package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

/**
 * Generates Jess Fact patterns to be used on the LHS of Jess rules.
 * 
 * @author oliverscheuer
 * 
 */
public class Indentations {

	public static final String INDENT_NODE = " ";
	public static final String INDENT_LINK = " ";
	public static final String INDENT_CONSTSET = "         ";
	public static final String INDENT_PROPFACT = "   ";
	public static final String INDENT_PROPCONSTR = "   ";

}
