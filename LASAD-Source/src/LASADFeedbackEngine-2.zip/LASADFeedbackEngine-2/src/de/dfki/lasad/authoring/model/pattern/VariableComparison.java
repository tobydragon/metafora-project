package de.dfki.lasad.authoring.model.pattern;

/**
 * Comparison of some variable with another variable (as opposed to comparisons
 * with constant values).
 * 
 * @author oliverscheuer
 * 
 */
public abstract class VariableComparison extends Comparison {

	public abstract PropertyVariable getRightExpr();

	public abstract void setRightExpr(PropertyVariable rightExpr);

	// Returns a semantically equivalent Comparison with switched variables,
	// i.e., (a op b) => (b inv-op a)
	public VariableComparison getInverse() {
		VariableComparison returnVal = getInverseBasic();
		returnVal.setId(getId());
		returnVal.setType(getType());
		returnVal.setLeftExpr(getRightExpr());
		returnVal.setRightExpr(getLeftExpr());
		return returnVal;
	}

	protected abstract VariableComparison getInverseBasic();
}
