package de.dfki.lasad.agents.logic.analysis.aggr.tasks;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.aggr.AggrService;

/**
 * Starts the counting service, i.e., from now on notifications can be send to
 * other components when counter conditions are met / are not met anymore.
 * Triggers the {@link #manager} to check all counter conditions if the an
 * analysis is currently NOT running. (If an analysis IS running counter
 * conditions will be checked anyway when the analysis is finished.) This task
 * is used for the initial check for fulfilled counter conditions.
 * 
 * @author oliverscheuer
 * 
 */
public class AggTask_StartService extends AggTask {

	private static Log logger = LogFactory.getLog(AggTask_StartService.class);

	private AggrService manager;

	public AggTask_StartService(AggrService manager) {
		this.manager = manager;
	}

	@Override
	public void run() {
		logger.debug("Start aggregation service");
		manager.checkConditionsAndNotify();
	}

}
