package de.dfki.lasad.agents.instances.action.processors;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.ServiceType;
import lasad.shared.dfki.meta.agents.action.ActionType;
import lasad.shared.dfki.meta.agents.action.feedback.FeedbackActionType;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;
import lasad.shared.dfki.meta.agents.common.ActionListDef;
import lasad.shared.dfki.meta.agents.provision.ProvisionType;
import lasad.shared.dfki.meta.agents.provision.RecipientDef_Group;
import lasad.shared.dfki.meta.agents.provision.RecipientDef_Individuals;
import lasad.shared.dfki.meta.agents.provision.priority.PriorityProvisionType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.instances.TaskScheduler;
import de.dfki.lasad.agents.instances.action.ActionAgentConfig;
import de.dfki.lasad.agents.instances.action.UserServiceID;
import de.dfki.lasad.agents.logic.provision.actionhistory.MsgProvisionHistory;
import de.dfki.lasad.agents.logic.provision.phases.PhaseModelerInterface;
import de.dfki.lasad.session.SessionConfig;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.UserIDAll;
import de.dfki.lasad.sessionmodel.SessionModelChangeRecord;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ResultProcessorManager {

	private static Log logger = LogFactory.getLog(ResultProcessorManager.class);

	private ActionAgentConfig feedbackConfig = null;
	private SessionConfig sessionConfig = null;
	private MsgProvisionHistory msgHistoryRef = null;
	private PhaseModelerInterface phaseModelerRef = null;
	private TaskScheduler taskSchedulerRef = null;

	private List<ActionType> userSpecificActionTypes = new Vector<ActionType>();
	private List<ProvisionType> userSpecificProvisionTypes = new Vector<ProvisionType>();

	private Map<ServiceID, AnalysisTypeResultProcessor> analysisID2processor = new HashMap<ServiceID, AnalysisTypeResultProcessor>();
	private Map<UserServiceID, ActionTypeResultProcessor> actionID2processor = new HashMap<UserServiceID, ActionTypeResultProcessor>();
	private Map<UserServiceID, ProvisionTypeResultProcessor> provisionID2processor = new HashMap<UserServiceID, ProvisionTypeResultProcessor>();

	private Map<Integer, AnalysisResult> modeledResults = new HashMap<Integer, AnalysisResult>();

	private String debugPrefix = null;

	public void processModelChanged(SessionModelChangeRecord changeRecord) {
		logger.debug("START PROCESSING MODEL UPDATE: " + changeRecord + "...");
		for (AnalysisResult newResult : changeRecord
				.getAddedOrModifiedResults()) {
			processAddedOrModifiedResult(newResult);
		}
		for (Integer removedResultID : changeRecord.getRemovedResultsIDs()) {
			processRemovedResult(removedResultID);
		}
		logModeledResults();
		logger.debug("... CONCLUDE PROCESSING MODEL UPDATE");
	}

	public void reprocessAnalysisResult(AnalysisResult result) {
		processAddedOrModifiedResult(result);
	}

	private void processAddedOrModifiedResult(AnalysisResult newResult) {

		ServiceID sID = newResult.getAnalysisType().getServiceID();
		AnalysisTypeResultProcessor analysisProcessor = analysisID2processor
				.get(sID);
		if (analysisProcessor != null) {
			cancelPendingTasksRelatedToResult(newResult.getId());
			analysisID2processor.get(sID).onResultChanged(newResult, false);
			modeledResults.put(newResult.getId(), newResult);
		} else {
			logger.debug(debugPrefix + "IGNORE NEW-RESULT: " + newResult);
		}
	}

	private void processRemovedResult(Integer removedResultID) {

		AnalysisResult result = modeledResults.remove(removedResultID);
		if (result != null) {
			cancelPendingTasksRelatedToResult(removedResultID);
			ServiceID sID = result.getAnalysisType().getServiceID();
			analysisID2processor.get(sID).onResultChanged(result, true);
		} else {
			logger.debug(debugPrefix + "IGNORE REMOVE-RESULT: "
					+ removedResultID);
		}

	}

	public void processUserJoin(UserID uID) {
		for (ActionType actionType : userSpecificActionTypes) {
			UserServiceID uServiceID = new UserServiceID(uID,
					actionType.getServiceID());
			initActionTypeProcessorIfNeeded(uServiceID);
		}
		for (ProvisionType provisionType : userSpecificProvisionTypes) {
			UserServiceID uServiceID = new UserServiceID(uID,
					provisionType.getServiceID());
			initProvisionTypeProcessorIfNeeded(uServiceID);
		}
	}

	public List<ActionTypeResult> getResultsInOrder(UserServiceID userServiceID) {
		ProvisionTypeResultProcessor pprocessor = provisionID2processor
				.get(userServiceID);
		return pprocessor.getResultsInOrder();
	}

	/**
	 * To handle case: individual user requests group feedback
	 * 
	 */
	public UserServiceID getRecipientUserServiceID(UserServiceID userProvisionID) {
		ProvisionType provisionType = (ProvisionType) sessionConfig
				.getAgentServiceType(userProvisionID.getServiceID());

		UserID relUser = null;
		if (provisionType.getRecipient() instanceof RecipientDef_Group) {
			relUser = new UserIDAll();
		} else if (provisionType.getRecipient() instanceof RecipientDef_Individuals) {
			relUser = userProvisionID.getUserID();
		} else {
			logger.error("(getRecipientUserServiceID) Unhandled recipient def type: "
					+ provisionType.getRecipient());
		}
		return new UserServiceID(relUser, provisionType.getServiceID());
	}

	// cancel all tasks scheduled for that analysis result
	// (the result will be re-processed anyway)
	private void cancelPendingTasksRelatedToResult(Integer resultID) {
		taskSchedulerRef.cancelTasks(resultID);
	}

	public void init(ActionAgentConfig feedbackConfig,
			SessionConfig sessionConfig, MsgProvisionHistory msgHistoryRef,
			PhaseModelerInterface phaseModelerRef,
			TaskScheduler taskSchedulerRef) {
		this.feedbackConfig = feedbackConfig;
		this.debugPrefix = "(" + feedbackConfig.getAgentID() + ") - ";

		this.sessionConfig = sessionConfig;
		this.msgHistoryRef = msgHistoryRef;
		this.phaseModelerRef = phaseModelerRef;
		this.taskSchedulerRef = taskSchedulerRef;

		initAnalysisTypeProcessors();
		initActionTypeProcessors();
		initProvisionTypeProcessors();
	}

	private void initAnalysisTypeProcessors() {
		for (AnalysisType analysisType : feedbackConfig.getAnalysisTypes()) {
			initAnalysisTypeProcessorIfNeeded(analysisType.getServiceID());
		}
	}

	private void initActionTypeProcessors() {
		for (ActionType actionType : feedbackConfig.getActionTypes()) {
			if (isActionTypeUserSpecific(actionType)) {
				// delayed processing (will be processed for each use who joins
				// session)
				userSpecificActionTypes.add(actionType);
			} else {
				initActionTypeProcessorIfNeeded(new UserServiceID(
						new UserIDAll(), actionType.getServiceID()));
			}
		}
	}

	private void initProvisionTypeProcessors() {
		for (ProvisionType provisionType : feedbackConfig.getProvisionTypes()) {
			if (isProvisionTypeUserSpecific(provisionType)) {
				// delayed processing (will be processed for each use who joins
				// session)
				userSpecificProvisionTypes.add(provisionType);
			} else {
				initProvisionTypeProcessorIfNeeded(new UserServiceID(
						new UserIDAll(), provisionType.getServiceID()));
			}
		}
	}

	private AnalysisTypeResultProcessor initAnalysisTypeProcessorIfNeeded(
			ServiceID serviceID) {
		AnalysisTypeResultProcessor analysisProcessor = analysisID2processor
				.get(serviceID);
		if (analysisProcessor == null) {
			// not yet initialized analysis processor -> intialize
			ServiceType serviceType = sessionConfig
					.getAgentServiceType(serviceID);
			AnalysisType analysisType = (AnalysisType) serviceType;
			analysisProcessor = new AnalysisTypeResultProcessor(analysisType);
			analysisID2processor.put(serviceID, analysisProcessor);
			logger.debug("AnalysisProcessor initialized: "
					+ analysisProcessor.getDebugID());
		}
		return analysisProcessor;

	}

	private ActionTypeResultProcessor initActionTypeProcessorIfNeeded(
			UserServiceID userServiceID) {
		ActionTypeResultProcessor actionProcessor = actionID2processor
				.get(userServiceID);
		if (actionProcessor == null) {
			ActionType actionType = (ActionType) sessionConfig
					.getAgentServiceType(userServiceID.getServiceID());
			if (actionType instanceof FeedbackActionType) {
				FeedbackActionType fActionType = (FeedbackActionType) actionType;
				actionProcessor = initFeedbackTypeProcessor(fActionType,
						userServiceID);
			} else {
				logger.error("Unhandled action type: " + actionType);
			}
		}
		return actionProcessor;
	}

	private ActionTypeResultProcessor initFeedbackTypeProcessor(
			FeedbackActionType fActionType, UserServiceID userServiceID) {

		ActionTypeResultProcessor actionProcessor = new ActionTypeResultProcessor(
				userServiceID, fActionType, taskSchedulerRef);
		actionID2processor.put(userServiceID, actionProcessor);

		ServiceID triggerID = fActionType.getTriggerID();
		AnalysisTypeResultProcessor analysisProcessor = initAnalysisTypeProcessorIfNeeded(triggerID);
		analysisProcessor.addResultListenerAndUpdate(actionProcessor);

		logger.debug("FeedbackProcessor initialized: "
				+ actionProcessor.getDebugID() + " -> "
				+ analysisProcessor.getDebugID());

		return actionProcessor;
	}

	private ProvisionTypeResultProcessor initProvisionTypeProcessorIfNeeded(
			UserServiceID userServiceID) {

		ProvisionType provisionType = (ProvisionType) sessionConfig
				.getAgentServiceType(userServiceID.getServiceID());

		ProvisionTypeResultProcessor provisionProcessor = provisionID2processor
				.get(userServiceID);
		if (provisionProcessor == null) {

			if (provisionType instanceof PriorityProvisionType) {
				PriorityProvisionType pProvisionType = (PriorityProvisionType) provisionType;
				provisionProcessor = initPriorityProvisionTypeProcessor(
						pProvisionType, userServiceID);
			} else {
				logger.error("Unhandled action type: " + provisionType);
			}
		}
		return provisionProcessor;
	}

	private ProvisionTypeResultProcessor initPriorityProvisionTypeProcessor(
			PriorityProvisionType pProvisionType, UserServiceID userProvisionID) {

		ProvisionTypeResultProcessor provisionProcessor = new ProvisionTypeResultProcessor(
				userProvisionID, pProvisionType, msgHistoryRef, phaseModelerRef);
		provisionID2processor.put(userProvisionID, provisionProcessor);

		ActionListDef providedActions = pProvisionType.getProvidedActions();
		List<ActionType> actionTypes = getProvidedActionTypes(pProvisionType,
				providedActions);

		StringBuffer actionTypesDebugString = new StringBuffer();
		for (Iterator<ActionType> iter = actionTypes.iterator(); iter.hasNext();) {
			ActionType actionType = iter.next();
			UserServiceID userActionTypeID = getUserActionID(userProvisionID,
					actionType);
			ActionTypeResultProcessor actionProcessor = initActionTypeProcessorIfNeeded(userActionTypeID);
			actionProcessor.addResultListenerAndUpdate(provisionProcessor);
			actionTypesDebugString.append(actionProcessor.getDebugID());
			if (iter.hasNext()) {
				actionTypesDebugString.append(", ");
			}
		}

		logger.debug("PriorityProvisionProcessor initialized: "
				+ provisionProcessor.getDebugID() + " -> "
				+ actionTypesDebugString.toString());

		return provisionProcessor;
	}

	/**
	 * 
	 * @param pProvisionType
	 * @param providedActionsDef
	 * @return the list of {@link ActionType}s that are provided by the given
	 *         {@link ProvisionType}, according to to the given
	 *         {@link ActionListDef}
	 */
	private List<ActionType> getProvidedActionTypes(
			ProvisionType provisionType, ActionListDef providedActionsDef) {

		List<ActionType> actionTypes = new Vector<ActionType>();
		if (providedActionsDef.isAllOwnActionTypes()) {
			String agentID = provisionType.getServiceID().getAgentID();
			List<ServiceType> serviceTypes = sessionConfig
					.getAgentServiceTypes(agentID);
			for (ServiceType sType : serviceTypes) {
				if (sType instanceof ActionType) {
					actionTypes.add((ActionType) sType);
				}
			}
		} else {
			for (ServiceID sID : providedActionsDef.getServiceIDs()) {
				ActionType actionType = (ActionType) sessionConfig
						.getAgentServiceType(sID);
				actionTypes.add(actionType);
			}
		}
		return actionTypes;
	}

	/**
	 * 
	 * @param userProvisionID
	 * @param actionType
	 * @return a {@link UserServiceID} to represent the combination of the given
	 *         {@link ActionType} and a {@link UserID} (which is compliant with
	 *         the {@link UserID} of the parent {@link ProvisionType})
	 */
	private UserServiceID getUserActionID(UserServiceID userProvisionID,
			ActionType actionType) {
		ServiceID actionTypeID = actionType.getServiceID();
		if (isActionTypeUserSpecific(actionType)) {
			UserID uID = userProvisionID.getUserID();
			if (uID instanceof UserIDAll) {
				logger.error("User-specific action types ("
						+ actionType.getServiceID()
						+ ") not supported in user-general provision types ("
						+ userProvisionID.getServiceID() + ")");
			}
			return new UserServiceID(uID, actionTypeID);
		} else {
			return new UserServiceID(new UserIDAll(), actionTypeID);
		}
	}

	private boolean isActionTypeUserSpecific(ActionType actionType) {
		if (actionType.userSpecificLogic()) {
			return true;
		}
		if (actionType instanceof FeedbackActionType) {
			FeedbackActionType fActionType = (FeedbackActionType) actionType;
			AnalysisType analysisType = (AnalysisType) sessionConfig
					.getAgentServiceType(fActionType.getTriggerID());
			return analysisType.userSpecificLogic();
		} else {
			return false;
		}
	}

	private boolean isProvisionTypeUserSpecific(ProvisionType provisionType) {
		return provisionType.userSpecificLogic();
	}

	private void logModeledResults() {
		logger.debug("Modeled results: ");
		for (Integer resultID : modeledResults.keySet()) {
			AnalysisResult result = modeledResults.get(resultID);
			logger.debug("... " + result.toSimpleString());
		}
	}
}
