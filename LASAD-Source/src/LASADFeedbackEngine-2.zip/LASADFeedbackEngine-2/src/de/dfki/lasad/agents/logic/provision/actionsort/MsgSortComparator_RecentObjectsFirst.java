package de.dfki.lasad.agents.logic.provision.actionsort;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.object.ObjectResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgSortComparator_RecentObjectsFirst extends MsgSortComparator {

	public MsgSortComparator_RecentObjectsFirst(MsgSortComparator tieBreaker) {
		super(tieBreaker);
	}

	/**
	 * TODO: TEST THIS METHOD
	 * @Override
	 */
	protected int compareImpl(ActionTypeResult actionResult1,
			ActionTypeResult actionResult2) {
		AnalysisResult analysisResult1 = actionResult1.getResult();
		AnalysisResult analysisResult2 = actionResult2.getResult();
		if (analysisResult1 instanceof ObjectResult
				&& analysisResult2 instanceof ObjectResult) {
			long lastMod1 = ((ObjectResult) analysisResult1)
					.getLastModificationTime();
			long lastMod2 = ((ObjectResult) analysisResult2)
					.getLastModificationTime();

			return Long.signum(lastMod1 - lastMod2);
		} else {
			return 0;
		}

	}
}
