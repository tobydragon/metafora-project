package de.dfki.lasad.agents.instances.eventsummaryagent;

import java.io.File;
import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.ServiceType;
import lasad.shared.dfki.meta.agents.analysis.AnalysisResultDatatype;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.SessionChecker;
import de.dfki.lasad.agents.SimpleSessionChecker;
import de.dfki.lasad.core.components.configuration.IAgentConfiguration;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class EventSummaryAgentConfiguration implements IAgentConfiguration {

	static Log logger = LogFactory.getLog(EventSummaryAgentConfiguration.class);

	private String agentID = "NOT SET";

	SessionChecker supportedOntologies;

	private List<ServiceType> serviceTypeList = new Vector<ServiceType>();

	// private Map<String, AnalysisType> analysisTypeMap;

	public EventSummaryAgentConfiguration() {
	}

	@Override
	public void setComponentID(String componentID) {
		this.agentID = componentID;
	}

	@Override
	public void load(File confFile) {
		readConfig(confFile);
	}

	@Override
	public void init() {
		ServiceID id = new ServiceID(agentID, "Indicator",
				ServiceClass.ANALYSIS);
		AnalysisType indicator = new AnalysisType(
				AnalysisResultDatatype.session_binary_result, id);
		indicator.setName("Important Events");

		serviceTypeList.add(indicator);
	}

	@Override
	public void compileNotYetCompiledAnalysisTypes() {
		// nothing to do
	}

	@Override
	public List<ServiceType> getServiceTypes() {
		return serviceTypeList;
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	@Override
	public SessionChecker getSessionChecker() {
		return supportedOntologies;
	}

	public void setSupportedOntologies(List<String> supportedOntologyIDs) {
		supportedOntologies = new SimpleSessionChecker(supportedOntologyIDs);
	}

	private final void readConfig(File confFile) {
		logger.info("Trying to read configuration from file '"
				+ confFile.getAbsolutePath() + "' ...");

		logger.info("... Done.");
	}

}
