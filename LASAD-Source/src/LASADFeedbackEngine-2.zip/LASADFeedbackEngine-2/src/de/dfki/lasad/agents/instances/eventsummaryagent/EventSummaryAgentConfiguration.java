package de.dfki.lasad.agents.instances.eventsummaryagent;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.SessionChecker;
import de.dfki.lasad.agents.SimpleSessionChecker;
import de.dfki.lasad.agents.data.analysis.StringResult;
import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.authoring.model.AgentConfigFE;
import de.dfki.lasad.core.components.configuration.IAgentConfiguration;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class EventSummaryAgentConfiguration implements IAgentConfiguration {

	static Log logger = LogFactory.getLog(EventSummaryAgentConfiguration.class);

	private String agentID = "NOT SET";

	SessionChecker supportedOntologies;

	private List<AnalysisType> analysisTypeList;

	// private Map<String, AnalysisType> analysisTypeMap;

	private boolean publishAllActionTypes = false;
	private boolean publishAllAnalysisTypes = false;
	
	public EventSummaryAgentConfiguration() {
		analysisTypeList = new Vector<AnalysisType>();

		AnalysisType indicator = new AnalysisType(StringResult.class, agentID,
				"Indicator", true);
		indicator.setDisplayName("Important Events");

		analysisTypeList.add(indicator);
	}

	@Override
	public void load(File confFile) {
		readConfig(confFile);
	}

	@Override
	public List<AnalysisType> getAnalysisTypes() {
		return analysisTypeList;
	}

	@Override
	public List<ActionType> getActionTypes() {
		return new Vector<ActionType>();
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	@Override
	public SessionChecker getSessionChecker() {
		return supportedOntologies;
	}

	public void setSupportedOntologies(List<String> supportedOntologyIDs) {
		supportedOntologies = new SimpleSessionChecker(supportedOntologyIDs);
	}

	private final void readConfig(File confFile) {
		logger.info("Trying to read configuration from file '"
				+ confFile.getAbsolutePath() + "' ...");

		logger.info("... Done.");
	}

	@Override
	public void replaceAgentID(String agentID) {
		for (AnalysisType analysisType : analysisTypeList) {
			analysisType.setAgentID(agentID);
		}

	}

	@Override
	public boolean doPublishAllActionTypes() {
		return publishAllActionTypes;
	}

	@Override
	public boolean doPublishAllAnalysisTypes() {
		return publishAllAnalysisTypes;
	}
	
	@Override
	public AgentConfigFE getConfigFE() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setConfigFE(AgentConfigFE feedbackConfXML) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean hasConfigFE() {
		// TODO Auto-generated method stub
		return false;
	}

}
