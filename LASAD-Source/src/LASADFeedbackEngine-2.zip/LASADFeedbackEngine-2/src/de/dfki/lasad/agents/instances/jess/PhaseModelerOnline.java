package de.dfki.lasad.agents.instances.jess;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.AnalysisActionType;
import de.dfki.lasad.session.data.SessionID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PhaseModelerOnline {

	public static final int ACTION_ASSERT = 1;
	public static final int ACTION_RETRACT = 2;

	Map<String, Set<PhaseContext>> agent2phaseContexts = new HashMap<String, Set<PhaseContext>>();
	Map<PhaseContext, Set<ActionType>> phases2aTypes = new HashMap<PhaseModelerOnline.PhaseContext, Set<ActionType>>();
	Map<PhaseContext, Map<ActionType, Integer>> phases2aTypes2ResultCount = new HashMap<PhaseModelerOnline.PhaseContext, Map<ActionType,Integer>>();

	Map<PhaseContext, Double> phases2aggregateMax = new HashMap<PhaseModelerOnline.PhaseContext, Double>();
	Map<PhaseContext, Double> phases2aggregateActual = new HashMap<PhaseModelerOnline.PhaseContext, Double>();
	Map<PhaseContext, Double> phases2aggregateNormalizedByMax = new HashMap<PhaseModelerOnline.PhaseContext, Double>();

	public void initPhaseModel(String agentID, List<String> phaseIDs,
			Set<ActionType> actionTypes) {

		Map<String, Set<PhaseContext>> agent2phaseContexts = new HashMap<String, Set<PhaseContext>>();
		Set<PhaseContext> phases = new HashSet<PhaseModelerOnline.PhaseContext>();
		agent2phaseContexts.put(agentID, phases);
		for (String phaseID : phaseIDs) {
			PhaseContext phaseContext = new PhaseContext(agentID, phaseID);
			phases.add(phaseContext);
			phases2aggregateMax.put(phaseContext, 0.0);
			phases2aggregateActual.put(phaseContext, 0.0);
			phases2aggregateNormalizedByMax.put(phaseContext, 0.0);
			phases2aTypes.put(phaseContext, new HashSet<ActionType>());
			phases2aTypes2ResultCount.put(phaseContext,
					new HashMap<ActionType, Integer>());
		}

		// computing for each phase the max possible value
		for (ActionType aType : actionTypes) {
			if (aType instanceof AnalysisActionType) {
				AnalysisActionType simpleActionType = (AnalysisActionType) aType;
				for (PhaseContext phase : phases) {
					double representativeness = simpleActionType
							.getRepresentativeness(phase.getPhaseID());
					if (representativeness != 0) {
						phases2aTypes.get(phase).add(aType);
						phases2aTypes2ResultCount.get(phase).put(aType, 0);
					}
					double aggreageOld = phases2aggregateMax.get(phase);
					double aggreageNew = aggreageOld + representativeness;
					phases2aggregateMax.put(phase, aggreageNew);
				}
			}
		}
	}

	public void update(String agentID, ActionTypeResult result, int action) {

		Set<PhaseContext> phases = agent2phaseContexts.get(agentID);

		if (result.getActionType() instanceof AnalysisActionType) {
			AnalysisActionType aType = (AnalysisActionType) result
					.getActionType();
			for (PhaseContext phase : phases) {
				if (phases2aTypes.get(phase).contains(aType)) {
					// relevant type
					int prevCount = phases2aTypes2ResultCount.get(phase).get(
							aType);
					if (action == ACTION_ASSERT) {
						if (prevCount == 0) {
							updateScore(phase,
									(aType.getRepresentativeness(phase
											.getPhaseID())));
						}
						phases2aTypes2ResultCount.get(phase).put(aType,
								prevCount + 1);
					} else if (action == ACTION_RETRACT) {
						if (prevCount == 1) {
							updateScore(phase,
									(-1 * aType.getRepresentativeness(phase
											.getPhaseID())));
						}
						phases2aTypes2ResultCount.get(phase).put(aType,
								prevCount - 1);
					}

				}
			}

		}

	}

	public Map<String, Double> getPhaseProbs(SessionID sessionID, String agentID) {
		Map<String, Double> phase2ScoreNormalized = new HashMap<String, Double>();
		Set<PhaseContext> phases = agent2phaseContexts.get(agentID);
		double phaseScoresSum = 0;
		for (PhaseContext phase : phases) {
			phaseScoresSum += phases2aggregateNormalizedByMax.get(phase);
		}
		for (PhaseContext phase : phases) {
			phase2ScoreNormalized
					.put(phase.getPhaseID(),
							phases2aggregateNormalizedByMax.get(phase)
									/ phaseScoresSum);
		}

		return phase2ScoreNormalized;
	}

	private void updateScore(PhaseContext phase, double change) {
		double newScoreActual = phases2aggregateActual.get(phase) + change;
		phases2aggregateActual.put(phase, newScoreActual);

		double scoreMax = phases2aggregateMax.get(phase);
		phases2aggregateNormalizedByMax.put(phase, newScoreActual / scoreMax);
	}

	private class PhaseContext {

		String agentID;
		String phaseID;

		public PhaseContext(String agentID, String phaseID) {
			this.agentID = agentID;
			this.phaseID = phaseID;
		}

		public String getAgentID() {
			return agentID;
		}

		public String getPhaseID() {
			return phaseID;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result
					+ ((agentID == null) ? 0 : agentID.hashCode());
			result = prime * result
					+ ((phaseID == null) ? 0 : phaseID.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			PhaseContext other = (PhaseContext) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (agentID == null) {
				if (other.agentID != null)
					return false;
			} else if (!agentID.equals(other.agentID))
				return false;
			if (phaseID == null) {
				if (other.phaseID != null)
					return false;
			} else if (!phaseID.equals(other.phaseID))
				return false;
			return true;
		}

		private PhaseModelerOnline getOuterType() {
			return PhaseModelerOnline.this;
		}

	}
}
