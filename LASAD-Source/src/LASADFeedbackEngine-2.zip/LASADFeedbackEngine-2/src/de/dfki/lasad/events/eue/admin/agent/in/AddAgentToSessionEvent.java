package de.dfki.lasad.events.eue.admin.agent.in;

import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AddAgentToSessionEvent extends EUEAgentAdminEvent {

	private String agentID;
	private String sessionID;

	public AddAgentToSessionEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	@Override
	public String toString() {
		return "AddAgentToSessionEvent [agentID=" + agentID + ", sessionID="
				+ sessionID + "]";
	}

}
