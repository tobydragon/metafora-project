package de.dfki.lasad.authoring.model.pattern;

/**
 * Comparison of a string variable to some other string variable.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class String2VarStringComparison extends VariableComparison {
	private String2StringOperator operator;
	private PropertyVariable rightExpr;

	public String2StringOperator getOperator() {
		return operator;
	}

	public void setOperator(String2StringOperator operator) {
		this.operator = operator;
	}

	public PropertyVariable getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(PropertyVariable rightExpr) {
		this.rightExpr = rightExpr;
	}

	protected VariableComparison getInverseBasic() {
		String2VarStringComparison inverted = new String2VarStringComparison();
		inverted.setOperator(getOperator().invert());
		return inverted;
	}
}
