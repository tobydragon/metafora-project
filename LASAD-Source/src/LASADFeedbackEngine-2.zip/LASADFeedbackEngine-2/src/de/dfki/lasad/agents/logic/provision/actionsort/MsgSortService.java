package de.dfki.lasad.agents.logic.provision.actionsort;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.agents.logic.provision.phases.PhaseModelerInterface;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgSortService implements MsgSortServiceInterface {

	private static Log logger = LogFactory.getLog(MsgSortService.class);

	private PhaseModelerInterface phaseModelerRef = null;
	private MsgSortComparator comparator = null;

	MsgSortService(MsgSortComparator comparator,
			PhaseModelerInterface phaseModelerRef) {
		this.phaseModelerRef = phaseModelerRef;
		this.comparator = comparator;
	}

	/**
	 * CAUTION: the provided list will be modified (elements with zero utility
	 * will be filtered out; list will be sorted)
	 * 
	 * @Override
	 */
	public void sort(List<ActionTypeResult> results) {
		if (phaseModelerRef != null) {
			for (Iterator<ActionTypeResult> iter = results.iterator(); iter
					.hasNext();) {
				ActionTypeResult result = iter.next();
				phaseModelerRef.assignPriority(result);
				if (result.getUtility() == 0) {
					iter.remove();
				}
			}
		}
		Collections.sort(results, comparator);
	}
}
