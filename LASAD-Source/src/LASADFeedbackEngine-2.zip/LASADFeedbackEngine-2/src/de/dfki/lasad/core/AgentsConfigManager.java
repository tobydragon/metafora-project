package de.dfki.lasad.core;

import java.io.File;

import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.RuleAnalysisType;
import de.dfki.lasad.agents.instances.jess.JessFeedbackAgentConfiguration;
import de.dfki.lasad.agents.instances.jess.JessFeedbackAgentConfigurationXML;
import de.dfki.lasad.authoring.model.AgentConfigFE;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.instance.IAgent;

/**
 * Provides methods to update the specific {@link IAgent} configurations in the
 * file system.
 * 
 * <br/>
 * <br/>
 * <b>NOTE:</b> {@link AgentDescription}s are managed by the
 * {@link ResourcesConfigManager}.
 * 
 * @author oliverscheuer
 * 
 */
public class AgentsConfigManager {

	public static boolean doesAgentConfigFolderExist(String agentID) {
		File agentConfHomeDir = ConfigurationDatabase
				.getAgentConfHomeDir(agentID);
		return agentConfHomeDir.exists();
	}

	public static void createAgentFolderStructure(String agentID) {
		File agentConfHomeDir = ConfigurationDatabase
				.getAgentConfHomeDir(agentID);
		if (!agentConfHomeDir.exists()) {
			agentConfHomeDir.mkdir();
		}
		File agentPatternsDir = ConfigurationDatabase
				.getAgentConfigBEPatternDir(agentID);
		if (!agentPatternsDir.exists()) {
			agentPatternsDir.mkdir();
		}
	}

	public static void writeAgentConfigBE(
			JessFeedbackAgentConfiguration configBE) {
		File masterConfigFile = ConfigurationDatabase
				.getAgentConfigBEMasterFile(configBE.getAgentID());
		JessFeedbackAgentConfigurationXML.writeMasterXMLFile(masterConfigFile,
				configBE);

		for (AnalysisType aType : configBE.getAnalysisTypes()) {
			RuleAnalysisType rType = (RuleAnalysisType) aType;
			File patternConfigFile = ConfigurationDatabase
					.getAgentConfigBEPatternFile(rType.getAgentID(),
							rType.getTypeID());
			JessFeedbackAgentConfigurationXML.writePatternXMLFile(
					patternConfigFile, rType);
		}
	}

	public static void writeAgentConfigFE(AgentConfigFE configFE) {
		File agentFEConfigFile = ConfigurationDatabase
				.getAgentConfigFEFile(configFE.getAgentID());
		configFE.writeXMLFile(agentFEConfigFile);
	}

	public static void deleteAgentConfigFiles(String agentID) {
		File agentConfHomeDir = ConfigurationDatabase
				.getAgentConfHomeDir(agentID);
		if (agentConfHomeDir.exists()) {
			recursiveDelete(agentConfHomeDir);
		}
	}

	private static void recursiveDelete(File f) {
		if (f.isDirectory()) {
			for (File c : f.listFiles()) {
				recursiveDelete(c);
			}
		}
		f.delete();
	}
}
