package de.dfki.lasad.core;

import java.io.File;

import junit.framework.TestCase;
import lasad.shared.dfki.meta.agents.ActionAgentConfigData;
import de.dfki.lasad.agents.instances.action.xml.ActionAgentConfigDataXML;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class FeedbackConfigManagerTest extends TestCase {

	private String TEST_AGENT_ID ="largo-test";
	
	public void testWriteAgentConfig() {
		String agentID = "largo-default";
		File agentConfFile = ConfigurationDatabase
				.getAgentConfigMasterFile(agentID);
		ActionAgentConfigData configData = ActionAgentConfigDataXML.fromXMLFile(agentID,
				agentConfFile);
		configData.replaceAgentID(TEST_AGENT_ID);
		FeedbackConfigManager.writeAgentConfig(configData);
	}

	public void testDeleteAgentConfigFiles() {
		FeedbackConfigManager.deleteAgentConfigFiles(TEST_AGENT_ID);
	}
}
