package de.dfki.lasad.events.eue.admin.config;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.eue.admin.EUEAdminEvent;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class OntologyListEvent extends EUEConfigInfoEvent {

	private List<String> ontologyIDs = new Vector<String>();

	public OntologyListEvent(String srcCompId) {
		super(srcCompId);
	}

	public List<String> getOntologyIDs() {
		return ontologyIDs;
	}

	public void setOntologyIDs(List<String> ontologyIDs) {
		this.ontologyIDs = ontologyIDs;
	}

	@Override
	public String toString() {
		return super.toString() + ", ontologyIDs=" + ontologyIDs;
	}

}
