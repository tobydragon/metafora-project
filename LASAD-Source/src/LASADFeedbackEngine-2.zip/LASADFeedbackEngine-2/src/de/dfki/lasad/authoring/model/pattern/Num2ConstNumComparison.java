package de.dfki.lasad.authoring.model.pattern;

/**
 * Comparison of a numeric variable to some constant numeric value.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class Num2ConstNumComparison extends Comparison{

	private Num2NumOperator operator;
	private int rightExpr;

	public Num2NumOperator getOperator() {
		return operator;
	}

	public void setOperator(Num2NumOperator operator) {
		this.operator = operator;
	}

	public int getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(int rightExpr) {
		this.rightExpr = rightExpr;
	}

}
