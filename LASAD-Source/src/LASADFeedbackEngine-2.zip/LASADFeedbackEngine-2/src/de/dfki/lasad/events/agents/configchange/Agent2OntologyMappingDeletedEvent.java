package de.dfki.lasad.events.agents.configchange;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class Agent2OntologyMappingDeletedEvent extends AFStateChangedEvent {

	private String agentID;
	private String ontologyID;

	public Agent2OntologyMappingDeletedEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public String getOntologyID() {
		return ontologyID;
	}

	public void setOntologyID(String ontologyID) {
		this.ontologyID = ontologyID;
	}

	@Override
	public String toString() {
		return "Agent2OntologyMappingDeletedEvent [agentID=" + agentID
				+ ", ontologyID=" + ontologyID + "]";
	}

}
