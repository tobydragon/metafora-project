package de.dfki.lasad.agents.logic.provision.types;

import lasad.shared.dfki.meta.agents.provision.ProvisionTimeDef;
import lasad.shared.dfki.meta.agents.provision.ProvisionTimeDef_OnRequest;
import lasad.shared.dfki.meta.agents.provision.ProvisionTimeDef_Periodically;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.CDATA;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class ProvisionTimeDefXML {

	public static final String ELEMENT_NAME = "provision-time";

	private static Log logger = LogFactory.getLog(ProvisionTimeDefXML.class);

	public static ProvisionTimeDef fromXML(Element provTimeElem) {
		String type = provTimeElem.getAttributeValue("type");
		if ("on-request".equalsIgnoreCase(type)) {
			Element displayNameElem = provTimeElem.getChild("display-name");
			if (displayNameElem != null) {
				String displayName = displayNameElem.getText();
				ProvisionTimeDef_OnRequest def = new ProvisionTimeDef_OnRequest(
						displayName);
				return def;
			} else {
				logger.error("Required elem 'display-name' not defined for type 'on-request'");
				return null;
			}
		} else if ("periodically".equalsIgnoreCase(type)) {
			Element checkIntervalElem = provTimeElem.getChild("check-interval");
			if (checkIntervalElem != null) {
				String checkIntervalString = checkIntervalElem
						.getAttributeValue("value");
				Long checkInterval = Long.parseLong(checkIntervalString);
				ProvisionTimeDef_Periodically def = new ProvisionTimeDef_Periodically(
						checkInterval);
				return def;
			} else {
				logger.error("Required elem 'check-interval' not defined for type 'periodically'");
				return null;
			}
		} else {
			logger.error("provision time type not handled: " + type);
			return null;
		}
	}

	public static Element toXML(ProvisionTimeDef provTimeDef) {

		Element provTimeDefElem = new Element(ELEMENT_NAME);

		if (provTimeDef instanceof ProvisionTimeDef_OnRequest) {
			ProvisionTimeDef_OnRequest onRequestDef = (ProvisionTimeDef_OnRequest) provTimeDef;
			provTimeDefElem.setAttribute("type", "on-request");
			Element displayNameElem = new Element("display-name");
			provTimeDefElem.addContent(displayNameElem);
			CDATA displayNameCData = new CDATA(onRequestDef.getDisplayName());
			displayNameElem.addContent(displayNameCData);
			return provTimeDefElem;
		} else if (provTimeDef instanceof ProvisionTimeDef_Periodically) {
			ProvisionTimeDef_Periodically periodicallyDef = (ProvisionTimeDef_Periodically) provTimeDef;
			provTimeDefElem.setAttribute("type", "periodically");
			Element checkIntervalElem = new Element("check-interval");
			provTimeDefElem.addContent(checkIntervalElem);
			checkIntervalElem.setAttribute("value",
					String.valueOf(periodicallyDef.getCheckInterval()));
			return provTimeDefElem;
		} else {
			logger.error("provision time type not handled: " + provTimeDef);
			return null;
		}
	}

}
