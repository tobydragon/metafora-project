package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Num2ConstNumComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Num2VarNumComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2ConstSetComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2ConstSetComparisonSuppl;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2ConstStringComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2ConstSetComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2ConstStringComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.VariableComparison;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ConstrRHSGen {

	private static final Log logger = LogFactory.getLog(ConstrRHSGen.class);

	private JessIDAndSlotNameGenerator idGen;

	private Comparison comparison;
	private int tempVarAppendix;
	private boolean useTempVarRight;

	public ConstrRHSGen(JessIDAndSlotNameGenerator idGen, Comparison comparison,
			int tempVarAppendix, boolean useTempVarRight) {
		this.idGen = idGen;
		this.comparison = comparison;
		this.tempVarAppendix = tempVarAppendix;
		this.useTempVarRight = useTempVarRight;
	}

	public String getString() {
		if (comparison instanceof Set2ConstSetComparison) {
			Set2ConstSetComparison c = (Set2ConstSetComparison) comparison;
			Set2ConstSetComparisonSuppl supplData = (Set2ConstSetComparisonSuppl) c
					.getSupplData();
			if (supplData.isUseJessConstantSetFact()) {
				return idGen.generateConstantFactValueTempVar(tempVarAppendix);
			} else {
				StringBuffer buf = new StringBuffer();
				buf.append("(create$");
				for (String val : c.getRightExpr()) {
					buf.append(" \"" + val + "\"");
				}
				buf.append(")");
				return buf.toString();
			}
		} else if (comparison instanceof Num2ConstNumComparison) {
			Num2ConstNumComparison c = (Num2ConstNumComparison) comparison;
			return "" + c.getRightExpr();
		} else if (comparison instanceof String2ConstStringComparison) {
			String2ConstStringComparison c = (String2ConstStringComparison) comparison;
			return " \"" + c.getRightExpr() + "\"";
		} else if (comparison instanceof Set2ConstStringComparison) {
			Set2ConstStringComparison c = (Set2ConstStringComparison) comparison;
			return " \"" + c.getRightExpr() + "\"";
		} else if (comparison instanceof String2ConstSetComparison) {
			String2ConstSetComparison c = (String2ConstSetComparison) comparison;
			StringBuffer buf = new StringBuffer();
			buf.append("(create$");
			for (String val : c.getRightExpr()) {
				buf.append(" \"" + val + "\"");
			}
			buf.append(")");
			return buf.toString();
		} else if (comparison instanceof VariableComparison) {
			VariableComparison varComp = (VariableComparison) comparison;
			String varID = idGen.generatePropVarID(varComp.getRightExpr(),
					tempVarAppendix, useTempVarRight, false);

			if (varComp instanceof Num2VarNumComparison) {
				Num2VarNumComparison numVarComparison = (Num2VarNumComparison) varComp;
				return "(+ " + varID + " " + numVarComparison.getOffset() + ")";
			} else {
				return varID;
			}
		}
		logger.error("Not handled Comparison type: " + comparison.toString());
		return null;
	}
}
