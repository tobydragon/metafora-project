package de.dfki.lasad.agents.instances.jess;

import java.util.Comparator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class Comparators {

	private static final Comparator<ActionTypeResult> actionTypeResultsComparator = new Comparator<ActionTypeResult>() {
		@Override
		public int compare(ActionTypeResult o1, ActionTypeResult o2) {
			double utilityDiff = o2.utility - o1.utility;
			if (utilityDiff == 0) {
				return 0;
			}
			return (utilityDiff > 0) ? 1 : -1;
		}
	};

	private static final Comparator<PhaseProbability> phaseProbabilityComparator = new Comparator<PhaseProbability>() {
		@Override
		public int compare(PhaseProbability o1, PhaseProbability o2) {
			double utilityDiff = o2.probability - o1.probability;
			if (utilityDiff == 0) {
				return 0;
			}
			return (utilityDiff > 0) ? 1 : -1;
		}
	};

	public static Comparator<ActionTypeResult> getActionTypeResultComparator() {
		return actionTypeResultsComparator;
	}

	public static Comparator<PhaseProbability> getPhaseProbComparator() {
		return phaseProbabilityComparator;
	}
}
