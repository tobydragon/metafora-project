package de.dfki.lasad.agents.instances.action.xml;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ActionAgentConfigData;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.SupportedOntologiesDef;
import lasad.shared.dfki.meta.agents.action.ActionType;
import lasad.shared.dfki.meta.agents.action.feedback.FeedbackActionType;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.jess.JessAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.phases.PhaseModelerDef;
import lasad.shared.dfki.meta.agents.analysis.phases.PhaseModelerDef_Empirical;
import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.agents.provision.ProvisionType;
import lasad.shared.dfki.meta.agents.provision.priority.PriorityProvisionType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.DocType;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.EntityRef;

import de.dfki.lasad.agents.SupportedOntologiesDefXML;
import de.dfki.lasad.agents.instances.xml.ActionTypeXML;
import de.dfki.lasad.agents.instances.xml.AnalysisTypeXML;
import de.dfki.lasad.agents.logic.action.types.feedback.FeedbackActionTypeXML;
import de.dfki.lasad.agents.logic.analysis.types.counter.CounterAnalysisTypeXML;
import de.dfki.lasad.agents.logic.analysis.types.jess.JessAnalysisTypeXML;
import de.dfki.lasad.agents.logic.analysis.types.structure.StructureAnalysisTypeXML;
import de.dfki.lasad.agents.logic.provision.phases.xml.PhaseModelerDefXML;
import de.dfki.lasad.agents.logic.provision.phases.xml.PhaseModelerDef_EmpiricalXML;
import de.dfki.lasad.agents.logic.provision.types.ProvisionTypeXML;
import de.dfki.lasad.agents.logic.provision.types.priority.PriorityProvisionTypeXML;
import de.dfki.lasad.util.FileUtil;
import de.dfki.lasad.util.XMLUtil;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ActionAgentConfigDataXML {

	private static Log logger = LogFactory.getLog(ActionAgentConfigDataXML.class);

	public static final String ELEMENT_NAME = "agent";

	/**
	 * Creates {@link ActionAgentConfigData} instance from given XML element
	 */
	public static ActionAgentConfigData fromXMLElem(String agentID, Element xml) {

		ActionAgentConfigData configData = new ActionAgentConfigData(agentID);

		Element ontologyDefElem = xml
				.getChild(SupportedOntologiesDefXML.ELEMENT_NAME);
		SupportedOntologiesDef supportedOntologiesDef = SupportedOntologiesDefXML
				.fromXML(ontologyDefElem);
		configData.setSupportedOntologiesDef(supportedOntologiesDef);

		Element phaseModelerDefElem = xml
				.getChild(PhaseModelerDefXML.ELEMENT_NAME);
		String phaseModelerTypeString = phaseModelerDefElem
				.getAttributeValue("type");
		if (PhaseModelerDef_EmpiricalXML.TYPE
				.equalsIgnoreCase(phaseModelerTypeString)) {
			PhaseModelerDef_Empirical phaseModelerDef = PhaseModelerDef_EmpiricalXML
					.fromXML(agentID, phaseModelerDefElem);
			configData.setPhaseModelerDef(phaseModelerDef);
		} else {
			logger.error("Unhandled phase modeler type: "
					+ phaseModelerTypeString);
		}

		List<AnalysisType> patternTypes = new Vector<AnalysisType>();
		for (Element patternElem : (List<Element>) xml
				.getChildren(AnalysisTypeXML.ELEMENT_NAME)) {
			String patternTypeString = patternElem.getAttributeValue("type");
			if (JessAnalysisTypeXML.TYPE.equalsIgnoreCase(patternTypeString)) {
				JessAnalysisType patternType = JessAnalysisTypeXML.fromXML(
						agentID, patternElem);
				patternTypes.add(patternType);
			} else if (CounterAnalysisTypeXML.TYPE
					.equalsIgnoreCase(patternTypeString)) {
				CounterAnalysisType patternType = CounterAnalysisTypeXML
						.fromXML(agentID, patternElem);
				patternTypes.add(patternType);
			} else if (StructureAnalysisTypeXML.TYPE
					.equalsIgnoreCase(patternTypeString)) {
				String ontologyID;
				if (supportedOntologiesDef.isAllOntologies()) {
					ontologyID = null;
				} else {
					List<String> supportedOntologies = supportedOntologiesDef
							.getSupportedOntologies();
					if (supportedOntologies.size() == 1) {
						ontologyID = supportedOntologies.get(0);
					} else if (supportedOntologies.size() == 0) {
						logger.error("Empty list supported ontologies for agent: "
								+ agentID);
						ontologyID = null;
					} else {
						logger.error("More than 1 supported ontologies for agent: "
								+ agentID
								+ ", yet only 1 supported for "
								+ StructureAnalysisType.class);
						ontologyID = supportedOntologies.get(0);
					}

				}

				StructureAnalysisType patternType = StructureAnalysisTypeXML
						.fromXML(agentID, ontologyID, patternElem);
				patternTypes.add(patternType);
			} else {
				logger.error("Unhandled pattern type: " + patternTypeString);
			}
		}
		configData.addAnalysisTypes(patternTypes);

		List<ActionType> actionTypes = new Vector<ActionType>();
		for (Element actionElem : (List<Element>) xml
				.getChildren(ActionTypeXML.ELEMENT_NAME)) {
			String actionTypeString = actionElem.getAttributeValue("type");
			if (FeedbackActionTypeXML.TYPE.equalsIgnoreCase(actionTypeString)) {
				FeedbackActionType actionType = FeedbackActionTypeXML.fromXML(
						agentID, actionElem);
				actionTypes.add(actionType);
			} else {
				logger.error("Unhandled action type: " + actionTypeString);
			}
		}
		configData.addActionTypes(actionTypes);

		List<ProvisionType> provisionTypes = new Vector<ProvisionType>();
		for (Element provisionElem : (List<Element>) xml
				.getChildren(ProvisionTypeXML.ELEMENT_NAME)) {
			String provisionTypeString = provisionElem
					.getAttributeValue("type");
			if (PriorityProvisionTypeXML.TYPE
					.equalsIgnoreCase(provisionTypeString)) {
				PriorityProvisionType provisionType = PriorityProvisionTypeXML
						.fromXML(agentID, provisionElem);
				provisionTypes.add(provisionType);
			} else {
				logger.error("Unhandled provision type: " + provisionTypeString);
			}
		}
		configData.addProvisionTypes(provisionTypes);

		return configData;
	}

	/**
	 * Creates XML {@link Element} instance from given
	 * {@link ActionAgentConfigData} instance.
	 * 
	 * @param analysisTypeExternalReferencesOnly
	 *            if true the created element will contain external entity
	 *            references rather than the actual {@link AnalysisType}
	 *            specifications
	 */
	public static Element toXMLElem(ActionAgentConfigData configData,
			boolean analysisTypeExternalReferencesOnly) {
		Element agentElem = new Element(ELEMENT_NAME);

		SupportedOntologiesDef supportedOntologiesDef = configData
				.getSupportedOntologiesDef();
		Element ontologiesElem = SupportedOntologiesDefXML
				.toXML(supportedOntologiesDef);
		agentElem.addContent(ontologiesElem);

		PhaseModelerDef phaseModelerDef = configData.getPhaseModelerDef();
		if (phaseModelerDef instanceof PhaseModelerDef_Empirical) {
			PhaseModelerDef_Empirical phaseModelerEmpDef = (PhaseModelerDef_Empirical) phaseModelerDef;
			Element phaseModelerElem = PhaseModelerDef_EmpiricalXML
					.toXML(phaseModelerEmpDef);
			agentElem.addContent(phaseModelerElem);
		} else {
			logger.error("Unhandled phase modeler def type: " + phaseModelerDef);
		}

		Collection<AnalysisType> patternTypes = configData.getAnalysisTypes();
		for (Iterator<AnalysisType> iter = patternTypes.iterator(); iter
				.hasNext();) {
			AnalysisType patternType = iter.next();
			addAnalysisType(agentElem, patternType,
					analysisTypeExternalReferencesOnly, iter.hasNext());
		}

		Collection<ActionType> actionTypes = configData.getActionTypes();
		for (ActionType actionType : actionTypes) {
			if (actionType instanceof FeedbackActionType) {
				FeedbackActionType feedbackActionType = (FeedbackActionType) actionType;
				Element actionElem = FeedbackActionTypeXML
						.toXML(feedbackActionType);
				agentElem.addContent(actionElem);
			} else {
				logger.error("Unhandled action type: " + actionType);
			}
		}

		Collection<ProvisionType> provisionTypes = configData
				.getProvisionTypes();
		for (ProvisionType provisionType : provisionTypes) {
			if (provisionType instanceof PriorityProvisionType) {
				PriorityProvisionType prioProvisionType = (PriorityProvisionType) provisionType;
				Element provisionElem = PriorityProvisionTypeXML
						.toXML(prioProvisionType);
				agentElem.addContent(provisionElem);
			} else {
				logger.error("Unhandled provision type: " + provisionType);
			}
		}
		return agentElem;
	}

	public static Document toXMLDoc(ActionAgentConfigData configData) {
		Element root = toXMLElem(configData, false);
		Document doc = new Document();
		doc.setRootElement(root);
		return doc;
	}

	/**
	 * Writes all data into one config file
	 * 
	 * @param targetFile
	 * @param configData
	 */
	public static void writeXMLFile(File targetFile,
			ActionAgentConfigData configData) {
		Element e = toXMLElem(configData, false);
		XMLUtil.xmlElem2File(targetFile, e);
	}

	/**
	 * Creates a master config file and a separate set of analysis config files.
	 * The master config files references analysis config files through external
	 * entities
	 * 
	 * @param targetMasterFile
	 * @param id2patternFiles
	 * @param configData
	 */
	public static void writeXMLFileExternalPatterns(File targetMasterFile,
			Map<ServiceID, File> id2patternFiles, ActionAgentConfigData configData) {
		Document doc = new Document();

		DocType doctype = createDocType(targetMasterFile, id2patternFiles,
				configData);
		doc.setDocType(doctype);

		Element masterXMLElem = toXMLElem(configData, true);
		doc.setRootElement(masterXMLElem);

		writeXMLPatternFiles(id2patternFiles, configData);

		XMLUtil.xmlDoc2File(targetMasterFile, doc);
	}

	public static ActionAgentConfigData fromXMLString(String agentID, String xml) {
		Element e = XMLUtil.string2xmlElem(xml);
		return fromXMLElem(agentID, e);
	}

	public static ActionAgentConfigData fromXMLFile(String agentID, File file) {
		Element e = XMLUtil.file2xmlElem(file);
		return fromXMLElem(agentID, e);
	}

	private static void addAnalysisType(Element agentElem,
			AnalysisType patternType,
			boolean analysisTypeExternalReferencesOnly, boolean moreTypesToCome) {
		if (analysisTypeExternalReferencesOnly) {
			EntityRef entityRef = getEntityRef(patternType);
			agentElem.addContent(entityRef);
			if (moreTypesToCome) {
				agentElem.addContent("\n");
			}
		} else {
			Element patternElem = getPatternElement(patternType);
			if (patternElem != null) {
				agentElem.addContent(patternElem);
			}
		}
	}

	private static EntityRef getEntityRef(AnalysisType patternType) {
		EntityRef ref = new EntityRef(patternType.getServiceID().getTypeID());
		return ref;
	}

	private static Element getPatternElement(AnalysisType patternType) {
		if (patternType instanceof JessAnalysisType) {
			JessAnalysisType jessType = (JessAnalysisType) patternType;
			Element patternElem = JessAnalysisTypeXML.toXML(jessType);
			return patternElem;
		} else if (patternType instanceof StructureAnalysisType) {
			StructureAnalysisType structureType = (StructureAnalysisType) patternType;
			Element patternElem = StructureAnalysisTypeXML.toXML(structureType);
			return patternElem;
		} else if (patternType instanceof CounterAnalysisType) {
			CounterAnalysisType counterType = (CounterAnalysisType) patternType;
			Element patternElem = CounterAnalysisTypeXML.toXML(counterType);
			return patternElem;
		} else {
			logger.warn("Unhandled pattern type: " + patternType);
			return null;
		}
	}

	private static void writeXMLPatternFiles(
			Map<ServiceID, File> id2patternFiles, ActionAgentConfigData configData) {
		for (AnalysisType aType : configData.getAnalysisTypes()) {
			ServiceID sID = aType.getServiceID();
			File f = id2patternFiles.get(sID);
			if (f == null) {
				logger.error("No file specified to write analysis type: " + sID);
			}
			Element patternElem = getPatternElement(aType);
			XMLUtil.xmlElem2File(f, patternElem);
		}
	}

	private static DocType createDocType(File targetMasterFile,
			Map<ServiceID, File> id2patternFiles, ActionAgentConfigData configData) {
		DocType docType = new DocType("rule_entities");

		StringBuffer entityDefinitions = new StringBuffer();
		for (AnalysisType aType : configData.getAnalysisTypes()) {
			ServiceID sID = aType.getServiceID();
			File f = id2patternFiles.get(sID);
			if (f == null) {
				logger.error("No file specified to write analysis type: " + sID);
			}
			File masterFileDir = targetMasterFile.getParentFile();
			if (FileUtil.contains(masterFileDir, f)) {
				String relativeFilepath = FileUtil.getRelativePath(
						masterFileDir, f);
				EntityRef entity = getEntityRef(aType);
				String entityString = XMLUtil.getXMLEntityString(entity,
						relativeFilepath);
				entityDefinitions.append("    " + entityString + "\n");
			} else {
				logger.error("");
			}
		}
		docType.setInternalSubset(entityDefinitions.toString());
		return docType;
	}

}
