package de.dfki.lasad.sessionmodel.counter;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import de.dfki.lasad.sessionmodel.counter.constraints.NumConstr;
import de.dfki.lasad.sessionmodel.counter.constraints.SetConstr;
import de.dfki.lasad.sessionmodel.counter.jess.CountingService.ActionAttributes;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class Index {

	private Log logger = LogFactory.getLog(Index.class);

	public static final String ROLE_SOURCE = "SOURCE";
	public static final String ROLE_TARGET = "TARGET";
	public static final String ROLE_ENDPOINT = "ENDPOINT";

	private Set<GraphObject> nodes = new HashSet<GraphObject>();
	private Set<GraphObject> links = new HashSet<GraphObject>();

	private Map<String, GraphObject> objectID2object = new HashMap<String, GraphObject>();

	private Map<String, Set<GraphObject>> node2outLinks = new HashMap<String, Set<GraphObject>>();
	private Map<String, Set<GraphObject>> node2inLinks = new HashMap<String, Set<GraphObject>>();
	private Map<String, Set<GraphObject>> node2links = new HashMap<String, Set<GraphObject>>();

	private Map<String, GraphObject> link2source = new HashMap<String, GraphObject>();
	private Map<String, GraphObject> link2target = new HashMap<String, GraphObject>();

	private Map<Integer, Set<GraphObject>> resultCache = new HashMap<Integer, Set<GraphObject>>();
	
	public void addLinkAction(ActionAttributes atts, String sourceID,
			String targetID) {
		addLinkAction(atts.type, atts.actor, atts.ts, atts.objectID,
				atts.objectType, sourceID, targetID);
	}

	public void addLinkAction(String actionType, String actor, long ts,
			String objectID, String objectType, String sourceID, String targetID) {

		resultCache.clear();
		
		if ("CREATE".equals(actionType)) {
			logger.debug("ADD link to index: " + objectID);
			GraphObject link = createObjectFromAction(actor, ts, objectID,
					objectType);

			links.add(link);
			objectID2object.put(objectID, link);

			Set<GraphObject> sourceOutLinks = node2outLinks.get(sourceID);
			if (sourceOutLinks == null) {
				sourceOutLinks = new HashSet<GraphObject>();
				node2outLinks.put(sourceID, sourceOutLinks);
			}
			sourceOutLinks.add(link);

			Set<GraphObject> sourceLinks = node2links.get(sourceID);
			if (sourceLinks == null) {
				sourceLinks = new HashSet<GraphObject>();
				node2links.put(sourceID, sourceLinks);
			}
			sourceLinks.add(link);

			Set<GraphObject> targetInLinks = node2inLinks.get(targetID);
			if (targetInLinks == null) {
				targetInLinks = new HashSet<GraphObject>();
				node2inLinks.put(targetID, targetInLinks);
			}
			targetInLinks.add(link);

			Set<GraphObject> targetLinks = node2links.get(targetID);
			if (targetLinks == null) {
				targetLinks = new HashSet<GraphObject>();
				node2links.put(targetID, targetLinks);
			}
			targetLinks.add(link);

			GraphObject sourceO = objectID2object.get(sourceID);
			link2source.put(objectID, sourceO);
			GraphObject targetO = objectID2object.get(targetID);
			link2target.put(objectID, targetO);
		} else if ("MODIFY".equals(actionType)) {
			logger.debug("MODIFY link in index: " + objectID);
			modifyObjectFromAction(actor, ts, objectID, objectType);
			GraphObject link = objectID2object.get(objectID);
			if(sourceID != null){
				GraphObject oldSource = link2source.remove(objectID);
				GraphObject newSource = objectID2object.get(sourceID);
				
				// update link endpoint
				link2source.put(objectID, newSource);
				
				// update links of old source
				Set<GraphObject> oldSourceOutLinks = node2outLinks.get(oldSource.getObjectID());
				oldSourceOutLinks.remove(link);
				Set<GraphObject> oldSourceLinks = node2links.get(oldSource.getObjectID());
				oldSourceLinks.remove(link);
				
				// update links of new source
				Set<GraphObject> newSourceOutLinks = node2outLinks.get(newSource.getObjectID());
				if(newSourceOutLinks == null){
					newSourceOutLinks = new HashSet<GraphObject>();
					node2outLinks.put(newSource.getObjectID(), newSourceOutLinks);
				}
				newSourceOutLinks.add(link);
				Set<GraphObject> newSourceLinks = node2links.get(newSource.getObjectID());
				if(newSourceLinks == null){
					newSourceLinks = new HashSet<GraphObject>();
					node2links.put(newSource.getObjectID(), newSourceLinks);
				}
				newSourceLinks.add(link);
				
				
			}
			if(targetID != null){
				GraphObject oldTarget = link2target.remove(objectID);
				GraphObject newTarget = objectID2object.get(targetID);
				
				// update link endpoint
				link2target.put(objectID, newTarget);
				
				// update links of old target
				Set<GraphObject> oldTargetInLinks = node2inLinks.get(oldTarget.getObjectID());
				oldTargetInLinks.remove(link);
				Set<GraphObject> oldTargetLinks = node2links.get(oldTarget.getObjectID());
				oldTargetLinks.remove(link);
				
				// update links of new target
				Set<GraphObject> newTargetInLinks = node2inLinks.get(newTarget.getObjectID());
				if(newTargetInLinks == null){
					newTargetInLinks = new HashSet<GraphObject>();
					node2inLinks.put(newTarget.getObjectID(), newTargetInLinks);
				}
				newTargetInLinks.add(link);
				Set<GraphObject> newTargetLinks = node2links.get(newTarget.getObjectID());
				if(newTargetLinks == null){
					newTargetLinks = new HashSet<GraphObject>();
					node2links.put(newTarget.getObjectID(), newTargetLinks);
				}
				newTargetLinks.add(link);
			}
			
		} else if ("DELETE".equals(actionType)) {
			removeLinkFromIndices(objectID);
		}
	}

	private void removeLinkFromIndices(String objectID) {
		logger.debug("DELETE link from index: " + objectID);
		links.remove(objectID2object.get(objectID));
		GraphObject link = objectID2object.remove(objectID);

		GraphObject sourceFromIndex = link2source.remove(link.getObjectID());

		if (sourceFromIndex != null) {
			String sourceIDFromIndex = sourceFromIndex.objectID;
			Set<GraphObject> sourceOutlinks = node2outLinks
					.get(sourceIDFromIndex);
			if (sourceOutlinks != null) {
				sourceOutlinks.remove(link);
			}

			Set<GraphObject> sourceLinks = node2links.get(sourceIDFromIndex);
			if (sourceLinks != null) {
				sourceLinks.remove(link);
			}
		}

		GraphObject targetFromIndex = link2target.remove(link.getObjectID());
		if (targetFromIndex != null) {
			String targetIDFromIndex = targetFromIndex.objectID;
			Set<GraphObject> targetInlinks = node2inLinks
					.get(targetIDFromIndex);
			if (targetInlinks != null) {
				targetInlinks.remove(link);
			}

			Set<GraphObject> targetLinks = node2links.get(targetIDFromIndex);
			if (targetLinks != null) {
				targetLinks.remove(link);
			}
		}
	}

	public void addNodeAction(ActionAttributes atts) {
		addNodeAction(atts.type, atts.actor, atts.ts, atts.objectID,
				atts.objectType);
	}

	public void addNodeAction(String actionType, String actor, long ts,
			String objectID, String objectType) {

		resultCache.clear();
		
		if ("CREATE".equals(actionType)) {
			logger.debug("ADD node to index: " + objectID);
			GraphObject node = createObjectFromAction(actor, ts, objectID,
					objectType);
			nodes.add(node);
			objectID2object.put(objectID, node);

		} else if ("MODIFY".equals(actionType)) {
			logger.debug("MODIFY node in index: " + objectID);
			modifyObjectFromAction(actor, ts, objectID, objectType);
		} else if ("DELETE".equals(actionType)) {
			removeNodeFromIndices(objectID);
		}
	}

	private void removeNodeFromIndices(String objectID) {
		logger.debug("DELETE node from index: " + objectID);
		nodes.remove(objectID2object.get(objectID));

		objectID2object.remove(objectID);
		Set<GraphObject> outLinks = node2outLinks.remove(objectID);
		if (outLinks != null) {
			for (GraphObject l : outLinks) {
				link2source.remove(l.getObjectID());
			}
		}

		Set<GraphObject> inLinks = node2inLinks.remove(objectID);
		if (inLinks != null) {
			for (GraphObject l : inLinks) {
				link2target.remove(l.getObjectID());
			}
		}

		node2links.remove(objectID);
	}

	public GraphObject createObjectFromAction(String actor, long ts,
			String objectID, String objectType) {

		GraphObject o = new GraphObject();
		o.setObjectID(objectID);
		o.setCreator(actor);
		o.getModifiers().add(actor);
		o.setFirstTs(ts);
		o.setLastTs(ts);
		o.setType(objectType);

		return o;
	}

	public GraphObject modifyObjectFromAction(String actor, long ts,
			String objectID, String objectType) {

		GraphObject o = objectID2object.get(objectID);
		o.getModifiers().add(actor);
		if (o.getLastTs() < ts) {
			o.setLastTs(ts);
		}
		if (objectType != null) {
			o.setType(objectType);
		}
		return o;
	}

	public Set<GraphObject> applyBoundConstraints(int requestHash, String refNodeID,
			String refNodeRole, SetConstr[] linkTypeRestrs,
			SetConstr[] linkCreatorConstrs, SetConstr[] linkModifiersConstrs,
			NumConstr[] linkFirstTSConstrs, NumConstr[] linkLastTSConstrs,
			SetConstr[] nodeTypeConstrs, SetConstr[] nodeCreatorConstrs,
			SetConstr[] nodeModifiersConstrs, NumConstr[] nodeFirstTSConstrs,
			NumConstr[] nodeLastTSConstrs) {

		if(resultCache.containsKey(requestHash)){
			Set<GraphObject> result = resultCache.get(requestHash);
			logger.debug("Return cached result: " + result + " (request hash = " + requestHash + ")");
			return result;
		}
		
		Set<GraphObject> links = getLinks(refNodeID, refNodeRole);
		logger.debug("RELEVANT LINKS (" + refNodeID + " = " + refNodeRole + "): " + links);

		Set<GraphObject> filteredLinks = filterObjects(links, linkTypeRestrs,
				linkCreatorConstrs, linkModifiersConstrs, linkFirstTSConstrs,
				linkLastTSConstrs, null);

		logger.debug("RELEVANT LINKS FILTERED (" + refNodeID + " = " + refNodeRole + "): " + filteredLinks);
		
		String nodeRole;

		if (ROLE_SOURCE.equals(refNodeRole)) {
			nodeRole = ROLE_TARGET;
		} else if (ROLE_TARGET.equals(refNodeRole)) {
			nodeRole = ROLE_SOURCE;
		} else {
			nodeRole = ROLE_ENDPOINT;
		}
		Set<GraphObject> nodes = getNodes(filteredLinks, nodeRole);

		Set<GraphObject> filteredNodes = filterObjects(nodes, nodeTypeConstrs,
				nodeCreatorConstrs, nodeModifiersConstrs, nodeFirstTSConstrs,
				nodeLastTSConstrs, refNodeID);
		logger.debug("RELEVANT NODES FILTERED (" + refNodeID + " = " + refNodeRole + "): " + filteredNodes);
		
		resultCache.put(requestHash, filteredNodes);
		return filteredNodes;
	}

	public Set<GraphObject> applyGlobalNodeConstraints(int requestHash,
			SetConstr[] nodeTypeConstrs, SetConstr[] nodeCreatorConstrs,
			SetConstr[] nodeModifiersConstrs, NumConstr[] nodeFirstTSConstrs,
			NumConstr[] nodeLastTSConstrs) {

		if(resultCache.containsKey(requestHash)){
			Set<GraphObject> result = resultCache.get(requestHash);
			logger.debug("Return cached result: " + result + " (request hash = " + requestHash + ")");
			return result;
		}
		
		Set<GraphObject> filteredNodes = filterObjects(getAllNodes(),
				nodeTypeConstrs, nodeCreatorConstrs, nodeModifiersConstrs,
				nodeFirstTSConstrs, nodeLastTSConstrs, null);
		logger.debug("Matches: " + filteredNodes);
		
		resultCache.put(requestHash, filteredNodes);
		return filteredNodes;
	}

	public Set<GraphObject> applyGlobalLinkConstraints(int requestHash,
			SetConstr[] linkTypeConstrs, SetConstr[] linkCreatorConstrs,
			SetConstr[] linkModifiersConstrs, NumConstr[] linkFirstTSConstrs,
			NumConstr[] linkLastTSConstrs) {

		if(resultCache.containsKey(requestHash)){
			Set<GraphObject> result = resultCache.get(requestHash);
			logger.debug("Return cached result: " + result + " (request hash = " + requestHash + ")");
			return result;
		}
		
		Set<GraphObject> filteredLinks = filterObjects(getAllLinks(),
				linkTypeConstrs, linkCreatorConstrs, linkModifiersConstrs,
				linkFirstTSConstrs, linkLastTSConstrs, null);
		
		resultCache.put(requestHash, filteredLinks);
		return filteredLinks;
	}

	private Set<GraphObject> getLinks(String nodeID, String nodeRole) {
		Set<GraphObject> result = null;
		if (ROLE_SOURCE.equals(nodeRole)) {
			result = node2outLinks.get(nodeID);
		} else if (ROLE_TARGET.equals(nodeRole)) {
			result = node2inLinks.get(nodeID);
		} else if (ROLE_ENDPOINT.equals(nodeRole)) {
			result = node2links.get(nodeID);
		} else {
			logger.error("Undefined node role: " + nodeRole);
			return null;
		}
		if (result == null) {
			result = new HashSet<GraphObject>();
		}
		return result;
	}

	private Set<GraphObject> getNodes(Set<GraphObject> links, String nodeRole) {
		Set<GraphObject> result = new HashSet<GraphObject>();
		for (GraphObject link : links) {
			if (ROLE_SOURCE.equals(nodeRole)) {
				result.add(link2source.get(link.getObjectID()));
			} else if (ROLE_TARGET.equals(nodeRole)) {
				result.add(link2target.get(link.getObjectID()));
			} else if (ROLE_ENDPOINT.equals(nodeRole)) {
				result.add(link2source.get(link.getObjectID()));
				result.add(link2target.get(link.getObjectID()));
			} else {
				logger.error("Undefined node role: " + nodeRole);
				return null;
			}
		}
		return result;

	}

	private Set<GraphObject> filterObjects(Set<GraphObject> objects,
			SetConstr[] typeConstrs, SetConstr[] creatorConstrs,
			SetConstr[] modifiersConstrs, NumConstr[] firstTSConstrs,
			NumConstr[] lastTSConstrs, String excludeID) {

		Set<GraphObject> results = new HashSet<GraphObject>();
		for (GraphObject o : objects) {
			if (testTypeConstr(o, typeConstrs)
					&& testCreatorConstr(o, creatorConstrs)
					&& testModifiersConstr(o, modifiersConstrs)
					&& testFirstTsConstr(o, firstTSConstrs)
					&& testLastTsConstr(o, lastTSConstrs)
					&& !(o.getObjectID().equals(excludeID))) {
				results.add(o);
			}
		}
		return results;
	}

	private boolean testTypeConstr(GraphObject o, SetConstr[] constrs) {
		return testSetConstrs(o.getType(), constrs);
	}

	private boolean testCreatorConstr(GraphObject o, SetConstr[] constrs) {
		return testSetConstrs(o.getCreator(), constrs);
	}

	private boolean testModifiersConstr(GraphObject o, SetConstr[] constrs) {
		return testSetConstrs(o.getModifiers(), constrs);
	}

	private boolean testFirstTsConstr(GraphObject o, NumConstr[] constrs) {
		return testNumConstr(o.getFirstTs(), constrs);
	}

	private boolean testLastTsConstr(GraphObject o, NumConstr[] constrs) {
		return testNumConstr(o.getLastTs(), constrs);
	}

	private boolean testNumConstr(long val, NumConstr[] constrs) {
		for (int i = 0; i < constrs.length; ++i) {

			if (NumConstr.OPERATOR_GREATER.equals(constrs[i].getOperator())) {
				if (!testGreater(val, constrs[i].getReferenceValue())) {
					return false;
				}
			} else if (NumConstr.OPERATOR_LESS.equals(constrs[i].getOperator())) {
				if (!testLess(val, constrs[i].getReferenceValue())) {
					return false;
				}
			}
		}
		return true;
	}

	private boolean testSetConstrs(String val, SetConstr[] constrs) {

		for (int i = 0; i < constrs.length; ++i) {

			if (SetConstr.OPERATOR_IN.equals(constrs[i].getOperator())) {
				if (!testIn(val, constrs[i].getRefSet())) {
					return false;
				}

			} else if (SetConstr.OPERATOR_NOT_IN.equals(constrs[i]
					.getOperator())) {
				if (testIn(val, constrs[i].getRefSet())) {
					return false;
				}
			} else {
				logger.error("Operator not supported: "
						+ constrs[i].getOperator() + ". Ignore restriction.");
			}
		}
		return true;

	}

	private boolean testSetConstrs(Set<String> vals, SetConstr[] constrs) {

		for (int i = 0; i < constrs.length; ++i) {

			if (SetConstr.OPERATOR_EQUALS.equals(constrs[i].getOperator())) {
				if (!testSetEquality(vals, constrs[i].getRefSet())) {
					return false;
				}
			} else if (SetConstr.OPERATOR_NOT_EQUALS.equals(constrs[i]
					.getOperator())) {
				if (testSetEquality(vals, constrs[i].getRefSet())) {
					return false;
				}
			} else if (SetConstr.OPERATOR_SUBSET.equals(constrs[i]
					.getOperator())) {
				if (!testSubset(vals, constrs[i].getRefSet())) {
					return false;
				}

			} else if (SetConstr.OPERATOR_NOT_SUBSET.equals(constrs[i]
					.getOperator())) {
				if (testSubset(vals, constrs[i].getRefSet())) {
					return false;
				}
			} else if (SetConstr.OPERATOR_SUPERSET.equals(constrs[i]
					.getOperator())) {
				if (!testSuperset(vals, constrs[i].getRefSet())) {
					return false;
				}
			} else if (SetConstr.OPERATOR_NOT_SUPERSET.equals(constrs[i]
					.getOperator())) {
				if (testSuperset(vals, constrs[i].getRefSet())) {
					return false;
				}
			} else if (SetConstr.OPERATOR_DISJOINT.equals(constrs[i]
					.getOperator())) {
				if (!testDisjoint(vals, constrs[i].getRefSet())) {
					return false;
				}
			} else if (SetConstr.OPERATOR_NOT_DISJOINT.equals(constrs[i]
					.getOperator())) {
				if (testDisjoint(vals, constrs[i].getRefSet())) {
					return false;
				}
			} else {
				logger.error("Operator not supported: "
						+ constrs[i].getOperator() + ". Ignore restriction.");
			}
		}
		return true;

	}

	private boolean testGreater(long v1, long v2) {
		return v1 > v2;
	}

	private boolean testLess(long v1, long v2) {
		return v1 < v2;
	}

	private boolean testIn(String val, Set<String> s) {
		return s.contains(val);
	}

	private boolean testSetEquality(Set<String> s1, Set<String> s2) {
		return s1.equals(s2);
	}

	private boolean testSubset(Set<String> subS, Set<String> superS) {
		return superS.containsAll(subS);
	}

	private boolean testSuperset(Set<String> superS, Set<String> subS) {
		return superS.containsAll(subS);
	}

	private boolean testDisjoint(Set<String> s1, Set<String> s2) {
		for (String s1Val : s1) {
			if (s2.contains(s1Val)) {
				return false;
			}
		}
		return true;
	}

	private Set<GraphObject> getAllNodes() {
		return nodes;
	}

	private Set<GraphObject> getAllLinks() {
		return links;
	}

	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("\nNODES\n");
		for (Iterator<GraphObject> iter = nodes.iterator(); iter.hasNext();) {
			buf.append("\t" + iter.next().toDetailedString() + "\n");
		}
		buf.append("LINKS\n");
		for (Iterator<GraphObject> iter = links.iterator(); iter.hasNext();) {
			buf.append("\t" + iter.next().toDetailedString() + "\n");
		}
		buf.append("ID -> GRAPHOBJECT\n");
		for (Iterator<String> iter = objectID2object.keySet().iterator(); iter
				.hasNext();) {
			String key = iter.next();
			GraphObject o = objectID2object.get(key);
			buf.append("\t" + key + " -> " + o.toDetailedString() + "\n");
		}
		buf.append("NODE -> IN-LINKS\n");
		for (Iterator<String> iter = node2inLinks.keySet().iterator(); iter
				.hasNext();) {
			String nodeID = iter.next();
			Set<GraphObject> links = node2inLinks.get(nodeID);
			buf.append("\t" + nodeID + " -> " + links + "\n");
		}
		buf.append("NODE -> OUT-LINKS\n");
		for (Iterator<String> iter = node2outLinks.keySet().iterator(); iter
				.hasNext();) {
			String nodeID = iter.next();
			Set<GraphObject> links = node2outLinks.get(nodeID);
			buf.append("\t" + nodeID + " -> " + links + "\n");
		}
		buf.append("NODE -> LINKS\n");
		for (Iterator<String> iter = node2links.keySet().iterator(); iter
				.hasNext();) {
			String nodeID = iter.next();
			Set<GraphObject> links = node2links.get(nodeID);
			buf.append("\t" + nodeID + " -> " + links + "\n");
		}
		buf.append("LINK -> SOURCE\n");
		for (Iterator<String> iter = link2source.keySet().iterator(); iter
				.hasNext();) {
			String linkID = iter.next();
			GraphObject n = link2source.get(linkID);
			buf.append("\t" + linkID + " -> " + n + "\n");
		}
		buf.append("LINK -> TARGET\n");
		for (Iterator<String> iter = link2target.keySet().iterator(); iter
				.hasNext();) {
			String linkID = iter.next();
			GraphObject n = link2target.get(linkID);
			buf.append("\t" + linkID + " -> " + n + "\n");
		}
		return buf.toString();
	}

}
