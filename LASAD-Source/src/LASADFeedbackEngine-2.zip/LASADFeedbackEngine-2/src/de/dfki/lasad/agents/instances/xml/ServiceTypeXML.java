package de.dfki.lasad.agents.instances.xml;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.ServiceType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.CDATA;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class ServiceTypeXML {

	private static Log logger = LogFactory.getLog(ServiceTypeXML.class);

	protected static ServiceID getServiceID(String agentID,
			ServiceClass serviceClass, Element serviceElem) {
		String typeID = serviceElem.getAttributeValue("id");
		return new ServiceID(agentID, typeID, serviceClass);
	}

	protected static String getName(Element serviceElem) {
		Element displayNameElem = serviceElem.getChild("name");
		if (displayNameElem == null) {
			return null;
		}
		String displayName = displayNameElem.getText();
		return displayName;
	}

	protected static String getDescription(Element serviceElem) {
		Element descriptionElem = serviceElem.getChild("description");
		if (descriptionElem == null) {
			return null;
		}
		String description = descriptionElem.getText();
		return description;
	}

	protected static void addServiceIDAtt(Element serviceElem,
			ServiceType serviceType) {
		serviceElem.setAttribute("id", serviceType.getServiceID().getTypeID());
	}

	protected static void addServiceTypeAtt(Element serviceElem,
			String serviceType) {
		serviceElem.setAttribute("type", serviceType);
	}

	protected static void addNameElemIfNotNull(Element serviceElem,
			ServiceType serviceType) {
		if (serviceType.getName() != null) {
			Element nameElem = new Element("name");
			serviceElem.addContent(nameElem);
			CDATA cdata = new CDATA(serviceType.getName());
			nameElem.addContent(cdata);
		}
	}

	protected static void addDescriptionElemIfNotNull(Element serviceElem,
			ServiceType serviceType) {
		if (serviceType.getDescription() != null) {
			Element descrElem = new Element("description");
			serviceElem.addContent(descrElem);
			CDATA cdata = new CDATA(serviceType.getDescription());
			descrElem.addContent(cdata);
		}
	}
}
