package de.dfki.lasad.events.agents.configchange;

import java.util.List;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AgentMappingsDeleted extends AFStateChangedEvent {

	private String agentID;
	private List<String> ontologyMappings;
	private List<String> sessionMappings;

	public AgentMappingsDeleted(String srcCompId) {
		super(srcCompId);
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public List<String> getOntologyMappings() {
		return ontologyMappings;
	}

	public void setOntologyMappings(List<String> ontologyMappings) {
		this.ontologyMappings = ontologyMappings;
	}

	public List<String> getSessionMappings() {
		return sessionMappings;
	}

	public void setSessionMappings(List<String> sessionMappings) {
		this.sessionMappings = sessionMappings;
	}

	@Override
	public String toString() {
		return "AgentMappingsDeleted [agentID=" + agentID
				+ ", ontologyMappings=" + ontologyMappings
				+ ", sessionMappings=" + sessionMappings + "]";
	}

}
