package de.dfki.lasad.core.components.collections;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;

/**
 * a set of {@link DataServiceDescription}s and {@link SessionModelDescription}s
 * 
 * @author oliverscheuer
 * 
 */
public class BasicResourceDescriptions {

	private Map<String, DataServiceDescription> dataServiceDescriptions = new HashMap<String, DataServiceDescription>();
	private Map<String, SessionModelDescription> sessionModelDescriptions = new HashMap<String, SessionModelDescription>();

	public Set<String> getDataServiceDescriptionIDs() {
		return dataServiceDescriptions.keySet();
	}

	public Collection<DataServiceDescription> getDataServiceDescriptions() {
		return dataServiceDescriptions.values();
	}

	public DataServiceDescription getDataServiceDescription(String id) {
		return dataServiceDescriptions.get(id);
	}

	public Set<String> getSessionModelDescriptionIDs() {
		return sessionModelDescriptions.keySet();
	}

	public Collection<SessionModelDescription> getSessionModelDescriptions() {
		return sessionModelDescriptions.values();
	}

	public SessionModelDescription getSessionModelDescription(String id) {
		return sessionModelDescriptions.get(id);
	}

	public void addDescription(AbstractComponentDescription descr) {
		if (descr instanceof DataServiceDescription) {
			DataServiceDescription dsDesr = (DataServiceDescription) descr;
			dataServiceDescriptions.put(descr.getComponentID(), dsDesr);
		} else if (descr instanceof SessionModelDescription) {
			SessionModelDescription smDescr = (SessionModelDescription) descr;
			sessionModelDescriptions.put(descr.getComponentID(), smDescr);
		}
	}

	@Override
	public String toString() {
		return "BasicResourceDescriptions [dataServiceDescriptions="
				+ dataServiceDescriptions + ", sessionModelDescriptions="
				+ sessionModelDescriptions + "]";
	}

}
