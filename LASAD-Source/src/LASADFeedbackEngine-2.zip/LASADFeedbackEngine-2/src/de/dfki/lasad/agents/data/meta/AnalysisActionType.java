package de.dfki.lasad.agents.data.meta;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * An {@link AnalysisType} that triggers the generation of system actions
 * associated with a specification of how to generate these actions(long and
 * short feedback text, highlighting).
 * 
 * @author Oliver Scheuer
 * 
 */
public class AnalysisActionType extends ActionType {

	private Log logger = LogFactory.getLog(AnalysisActionType.class);

	public static final int DEFAULT_REPRESENTATIVENESS = 1;
	public static final int DEFAULT_PRIORITY = 1;

	private AnalysisType analysisType;

	private boolean oneResultOnly = true;

	private String shortFeedback = getDisplayName();
	private String longFeedback = getDisplayName();
	private boolean highlighting = true;

	// control flags that specify how feedback is presented
	private List<String> propList = new Vector<String>();
	private Map<String, String> propName2propValue = new HashMap<String, String>();

	// the actual value will be instantiated dynamically at run time
	private List<String> dynamicPropList = new Vector<String>();

	private List<String> phases = new Vector<String>();
	private int defaultPriority = DEFAULT_PRIORITY;
	private Map<String, Integer> phase2Priority = new HashMap<String, Integer>();
	private Integer defaultRepresentativeness = DEFAULT_REPRESENTATIVENESS;
	private Map<String, Integer> phase2Representativeness = new HashMap<String, Integer>();

	public AnalysisActionType(String agentID, String actionTypeID,
			AnalysisType analysisType) {
		super(agentID, actionTypeID);
		this.analysisType = analysisType;
	}

	public AnalysisType getAnalysisType() {
		return analysisType;
	}

	public void setAnalysisType(AnalysisType analysisType) {
		this.analysisType = analysisType;
	}

	public String getFeedbackShort() {
		return shortFeedback;
	}

	public String getFeedbackLong() {
		return longFeedback;
	}

	public void setFeedbackShort(String shortFeedback) {
		this.shortFeedback = shortFeedback;
	}

	public void setFeedbackLong(String longFeedback) {
		this.longFeedback = longFeedback;
	}

	public Boolean doHighlighting() {
		return highlighting;
	}

	public void setHighlighting(boolean highlighting) {
		this.highlighting = highlighting;
	}

	public void addParam(String paramName, String paramValue) {
		propList.add(paramName);
		propName2propValue.put(paramName, paramValue);
	}

	public Map<String, String> getParams() {
		return propName2propValue;
	}

	public List<String> getParamNames() {
		return propList;
	}

	/**
	 * @param paramName
	 * @return parameter value for given phaseID and param name, or
	 *         <code>null</code> if param name is not defined.
	 */
	public String getParamValue(String paramName) {
		return propName2propValue.get(paramName);
	}

	public void addDynamicParam(String paramName) {
		dynamicPropList.add(paramName);
	}

	public List<String> getDynamicParamNames() {
		return dynamicPropList;
	}

	public List<String> getPhases() {
		return phases;
	}

	public void addPriority(String phaseID, int priority) {
		if (!phases.contains(phaseID)) {
			phases.add(phaseID);
		}
		phase2Priority.put(phaseID, priority);
	}

	public void setDefaultPriority(int priority) {
		this.defaultPriority = priority;
	}

	public int getPriority(String phaseID) {
		Integer priority = phase2Priority.get(phaseID);
		if (priority != null) {
			return priority;
		}
		return defaultPriority;
	}

	public int getDefaultPriority() {
		return defaultPriority;
	}

	public void addRepresentativeness(String phaseID, int representativeness) {
		if (!phases.contains(phaseID)) {
			phases.add(phaseID);
		}
		phase2Representativeness.put(phaseID, representativeness);
	}

	public void setDefaultRepresentativeness(int representativeness) {
		this.defaultRepresentativeness = representativeness;
	}

	public int getRepresentativeness(String phaseID) {
		Integer representativeness = phase2Representativeness.get(phaseID);
		if (representativeness != null) {
			return representativeness;
		}
		return defaultRepresentativeness;
	}

	public int getDefaultRepresentativeness() {
		return defaultRepresentativeness;
	}

	public boolean isOneResultOnly() {
		return oneResultOnly;
	}

	public void setOneResultOnly(boolean oneResultOnly) {
		this.oneResultOnly = oneResultOnly;
	}

}
