package de.dfki.lasad.agents;

import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.session.Session;

/**
 * Checks whether a given {@link Session} can be supported by some service
 * (e.g., by some {@link IAgent}).
 * 
 * @author Oliver Scheuer
 * 
 */
public interface SessionChecker {

	/**
	 * Checks whether a provided {@link Session} is supported.
	 * 
	 * @param session
	 * @return
	 */
	public boolean isSessionSupported(Session session);

}
