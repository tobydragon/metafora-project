package de.dfki.lasad.agents.instances.jess;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.AbstractAgent;
import de.dfki.lasad.agents.data.action.AgentAction;
import de.dfki.lasad.agents.data.action.Message;
import de.dfki.lasad.agents.data.action.MessageWithHighlighting;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.AnalyzableEntity;
import de.dfki.lasad.agents.data.analysis.NoAnalysisResults;
import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.CompoundActionType;
import de.dfki.lasad.agents.data.meta.AnalysisActionType;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.IComponent;
import de.dfki.lasad.core.components.instance.ServiceStatus;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.events.agents.AnalysisRequestEvent;
import de.dfki.lasad.events.agents.AnalysisResultEvent;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestEvent;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestSpec;
import de.dfki.lasad.session.data.UserID;

/**
 * {@link IAgent} implementation that supports the provision of feedback to
 * users based on patterns detected in a {@link Session}. For details, see
 * external documentation.
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent}, {@link IAgent}, {@link AbstractAgent})
 * 
 * @author oliverscheuer
 * 
 */
public class JessFeedbackAgent extends AbstractAgent {

	private Log logger = LogFactory.getLog(JessFeedbackAgent.class);

	private Map<UUID, FeedbackRequestEvent> openFeedbackRequests = new HashMap<UUID, FeedbackRequestEvent>();

	public static final int ALL_RESULTS = -1;

	private Comparator<ActionTypeResult> actionTypeResultsComparator = Comparators
			.getActionTypeResultComparator();

	private Comparator<PhaseProbability> phaseProbabilityComparator = Comparators
			.getPhaseProbComparator();

	@Override
	public synchronized void startService() {
		setServiceStatus(ServiceStatus.STARTING);
		logger.info("Start service for session: " + sessionID + "...");
		// writeRulesToSessionModel();
		super.startService();
		setServiceStatus(ServiceStatus.RUNNING);
		logger.info("... service started (" + sessionID + ")");
	}

	@Override
	public synchronized void stopService() {
		setServiceStatus(ServiceStatus.STOPPING);
		logger.info("Stop service for session: " + sessionID + "...");
		super.stopService();
		setServiceStatus(ServiceStatus.STALE);
		logger.info("... service stopped (" + sessionID + ")");
	}

	/**
	 * private void writeRulesToSessionModel() { jessAgentConf =
	 * (JessFeedbackAgentConfiguration) description .getConfiguration(); for
	 * (AnalysisActionType actionType : jessAgentConf .getSimpleActionTypes()) {
	 * model.registerAnalysisPattern((RuleAnalysisType) actionType
	 * .getAnalysisType()); } }
	 */

	@Override
	protected void processEvent(Event event) {
		if (event instanceof FeedbackRequestEvent) {
			FeedbackRequestEvent feedbackRequestEvent = (FeedbackRequestEvent) event;
			processFeedbackRequestEvent(feedbackRequestEvent);
		} else if (event instanceof AnalysisResultEvent) {
			AnalysisResultEvent resultEvent = (AnalysisResultEvent) event;
			processAnalysisResultEvent(resultEvent);
		}
	}

	protected void processFeedbackRequestEvent(
			FeedbackRequestEvent feedbackRequestEvent) {
		logger.debug("Start processing event: " + feedbackRequestEvent + " ...");
		FeedbackRequestSpec spec = feedbackRequestEvent
				.getFeedbackRequestSpec();

		AnalysisRequestEvent aRequest = new AnalysisRequestEvent(
				getComponentID());
		aRequest.setCallback(this);

		if (spec.getFeedbackTypeID().mirrorResults()) {
			AnalysisType analysisType = (AnalysisType) resolveRequestedType(feedbackRequestEvent);
			aRequest.addAnalysisType(analysisType);
		} else {
			ActionType actionType = (ActionType) resolveRequestedType(feedbackRequestEvent);

			if (actionType instanceof AnalysisActionType) {
				AnalysisActionType simpleActionType = (AnalysisActionType) actionType;
				aRequest.addAnalysisType(simpleActionType.getAnalysisType());
			} else if (actionType instanceof CompoundActionType) {
				CompoundActionType compoundActionType = (CompoundActionType) actionType;
				for (ActionType subactionType : compoundActionType
						.getSubActionTypes()) {
					if (subactionType instanceof AnalysisActionType) {
						AnalysisActionType simpleActionType = (AnalysisActionType) subactionType;
						aRequest.addAnalysisType(simpleActionType
								.getAnalysisType());
					}

					else {
						logger.warn("ActionType in CompundActionType not instanceof SimpleActionType. Ignore.");
					}
				}
			}
		}
		openFeedbackRequests.put(aRequest.getTransactionID(),
				feedbackRequestEvent);
		model.onEvent(aRequest);
	}

	protected void processAnalysisResultEvent(AnalysisResultEvent resultEvent) {

		FeedbackRequestEvent requestEvent = openFeedbackRequests
				.remove(resultEvent.getTransactionID());
		FeedbackRequestSpec spec = requestEvent.getFeedbackRequestSpec();

		if (spec.getFeedbackTypeID().mirrorResults()) {
			handleAnalysisResultRequest(requestEvent, resultEvent);
		} else {
			ActionType actionType = (ActionType) resolveRequestedType(requestEvent);

			if (actionType instanceof AnalysisActionType) {
				AnalysisActionType simpleActionType = (AnalysisActionType) actionType;
				handleAnalysisActionRequest(requestEvent, resultEvent,
						simpleActionType);
			} else if (actionType instanceof CompoundActionType) {
				CompoundActionType compoundActionType = (CompoundActionType) actionType;
				handleCompoundActionRequest(requestEvent, resultEvent,
						compoundActionType);
			}
		}
	}

	/**
	 * 
	 * Method called when the user requested the results of an
	 * {@link AnalysisType}.
	 */
	private void handleAnalysisResultRequest(FeedbackRequestEvent requestEvent,
			AnalysisResultEvent resultEvent) {
		AnalysisType analysisType = (AnalysisType) resolveRequestedType(requestEvent);
		UserID originalRequestorID = requestEvent.getUserID();
		List<AnalysisResult> results = resultEvent.getResults(analysisType);
		if (results == null) {
			results = new Vector<AnalysisResult>();
		}
		sendRawResults(analysisType, results, originalRequestorID);
	}

	/**
	 * 
	 * Method called when the user requested the results of an
	 * {@link AnalysisActionType}.
	 */
	private void handleAnalysisActionRequest(FeedbackRequestEvent requestEvent,
			AnalysisResultEvent resultEvent, AnalysisActionType simpleActionType) {

		AnalysisType analysisType = simpleActionType.getAnalysisType();
		List<AnalysisResult> resultsForType = resultEvent
				.getResults(analysisType);
		List<ActionTypeResult> actionResultList = new Vector<ActionTypeResult>();
		if (resultsForType != null) {
			for (AnalysisResult resultForType : resultsForType) {
				ActionTypeResult actionResult = new ActionTypeResult(
						simpleActionType, resultForType);
				actionResultList.add(actionResult);
			}
		}
		generateAndSendResponse(requestEvent, simpleActionType,
				actionResultList, null);
	}

	/**
	 * 
	 * Method called when the user requested the results of an
	 * {@link CompoundActionType}.
	 */
	private void handleCompoundActionRequest(FeedbackRequestEvent requestEvent,
			AnalysisResultEvent resultEvent,
			CompoundActionType compoundActionType) {
		Map<ActionType, List<ActionTypeResult>> types2Results = new HashMap<ActionType, List<ActionTypeResult>>();
		for (ActionType subType : compoundActionType.getSubActionTypes()) {
			if (subType instanceof AnalysisActionType) {
				AnalysisActionType simpleType = (AnalysisActionType) subType;
				AnalysisType analysisType = simpleType.getAnalysisType();
				List<AnalysisResult> resultsForType = resultEvent
						.getResults(analysisType);
				if (resultsForType != null) {
					List<ActionTypeResult> actionResultList = new Vector<ActionTypeResult>();
					types2Results.put(simpleType, actionResultList);
					for (AnalysisResult resultForType : resultsForType) {
						ActionTypeResult actionResult = new ActionTypeResult(
								simpleType, resultForType);
						actionResultList.add(actionResult);
					}
				}
			}
		}

		// determine phase probabilities
		JessFeedbackAgentConfiguration jessAgentConf = (JessFeedbackAgentConfiguration) description
				.getConfiguration();
		List<String> phaseIDs = jessAgentConf.getPhaseIDs();
		Map<String, Double> phaseProbabilities = PhaseModeler
				.getPhaseProbabilities(phaseIDs, types2Results);

		// sort and filter results
		int maxNumResults = determineNumResults(requestEvent,
				compoundActionType);

		List<ActionTypeResult> typeResultsListAll = new Vector<ActionTypeResult>();
		for (List<ActionTypeResult> typeResultsListOne : types2Results.values()) {
			typeResultsListAll.addAll(typeResultsListOne);
		}
		List<String> criteria = compoundActionType.getCriteria();
		List<ActionTypeResult> orderedResultList = sortAndFilter(
				phaseProbabilities, criteria, typeResultsListAll, maxNumResults);

		generateAndSendResponse(requestEvent, compoundActionType,
				orderedResultList, phaseProbabilities);

	}

	private void generateAndSendResponse(FeedbackRequestEvent requestEvent,
			ActionType requestedActionType, List<ActionTypeResult> resultList,
			Map<String, Double> phaseProbabilities) {
		FeedbackRequestSpec spec = requestEvent.getFeedbackRequestSpec();

		UserID originalRequestorID = requestEvent.getUserID();
		JessFeedbackAgentConfiguration jessAgentConf = (JessFeedbackAgentConfiguration) description
				.getConfiguration();
		if (jessAgentConf.doPublishRawResults() || spec.isRequestRawResults()) {
			if (resultList == null || resultList.isEmpty()) {
				sendNoFeedbackAvailableMessage(requestedActionType,
						originalRequestorID);
			}
			for (ActionTypeResult typeResult : resultList) {
				AnalysisType aType = typeResult.getActionType()
						.getAnalysisType();
				List<AnalysisResult> aResults = new Vector<AnalysisResult>();
				aResults.add(typeResult.getResult());
				sendRawResults(aType, aResults, originalRequestorID);
			}

		} else {
			generateAndSendFeedback(requestedActionType, resultList,
					phaseProbabilities, originalRequestorID);
		}
	}

	private int determineNumResults(FeedbackRequestEvent requestEvent,
			CompoundActionType compoundActionType) {
		FeedbackRequestSpec spec = requestEvent.getFeedbackRequestSpec();
		int maxNumResults = spec.getNumResults();
		if (maxNumResults == FeedbackRequestSpec.NOT_SPECIFIED) {
			maxNumResults = compoundActionType.getMaxNumResults();
			if (maxNumResults == CompoundActionType.ALL_RESULTS) {
				maxNumResults = JessFeedbackAgent.ALL_RESULTS;
			}
		} else if (maxNumResults == FeedbackRequestSpec.ALL_RESULTS) {
			maxNumResults = JessFeedbackAgent.ALL_RESULTS;
		}
		return maxNumResults;
	}

	/**
	 * Generates and sends an {@link AgentAction} that is based on the
	 * application of pedagogical strategies, as specified in the provided
	 * {@link ActionType}.
	 * 
	 */
	private void generateAndSendFeedback(ActionType aType,
			List<ActionTypeResult> orderedResultList,
			Map<String, Double> phaseProbabilities, UserID originalRequestorID) {

		ActionSpecEvent incompleteSpecEvent = new ActionSpecEvent(sessionID,
				getAgentDescription().getComponentID());

		// sort phase IDs according probability
		List<PhaseProbability> phaseIDsOrdered = null;
		if (phaseProbabilities != null) {
			phaseIDsOrdered = new Vector<PhaseProbability>();
			for (String phaseID : phaseProbabilities.keySet()) {
				double probability = phaseProbabilities.get(phaseID);
				PhaseProbability pair = new PhaseProbability(phaseID,
						probability);
				phaseIDsOrdered.add(pair);
			}
			Collections.sort(phaseIDsOrdered, phaseProbabilityComparator);
		}

		if (orderedResultList == null || orderedResultList.size() == 0) {
			sendNoFeedbackAvailableMessage(aType, originalRequestorID);
			return;
		}

		for (ActionTypeResult actionResult : orderedResultList) {

			AnalysisActionType simpleType = actionResult.getActionType();
			AnalysisResult analysisResult = actionResult.getResult();
			AgentAction componentSpec = new AgentAction();
			componentSpec.setActionRecipient(originalRequestorID);

			// get text and highlighting

			Map<String, String> additionalParams = simpleType.getParams();

			String feedbackShort = simpleType.getFeedbackShort();
			if (feedbackShort.contains("##")) {
				feedbackShort = fillInProperties(feedbackShort,
						analysisResult.getProperties());
			}

			String feedbackLong = simpleType.getFeedbackLong();
			if (feedbackLong.contains("##")) {
				feedbackLong = fillInProperties(feedbackLong,
						analysisResult.getProperties());
			}

			Boolean doHighlighting = simpleType.doHighlighting();

			List<String> dynamicParams = simpleType.getDynamicParamNames();
			for (String paramName : dynamicParams) {
				String paramValue = analysisResult.getProperties().get(
						paramName);
				if (paramValue != null) {
					additionalParams.put(paramName, paramValue);
				} else {
					logger.warn("No value available for (dynamic) param '"
							+ paramName + "' from result: "
							+ actionResult.toString());
				}
			}

			List<String> staticParams = simpleType.getParamNames();
			for (String paramName : staticParams) {
				String paramValue = simpleType.getParamValue(paramName);
				if (paramValue != null) {
					additionalParams.put(paramName, paramValue);
				} else {
					logger.warn("No value available for (static) param '"
							+ paramName + "'");
				}

			}

			AnalyzableEntity entity = analysisResult.getAnalyzableEntity();
			if (doHighlighting && !(entity.getEntityComponents().isEmpty())) {
				MessageWithHighlighting highlighting;
				if (feedbackLong != null) {
					highlighting = new MessageWithHighlighting(feedbackShort,
							feedbackLong, entity);
				} else {
					highlighting = new MessageWithHighlighting(feedbackShort,
							entity);
				}
				highlighting.setParameters(additionalParams);
				componentSpec.addActionComponent(highlighting);
			} else {
				// create text message without highlighting
				Message message;
				if (feedbackLong != null) {
					message = new Message(feedbackShort, feedbackLong);
				} else {
					message = new Message(feedbackShort);
				}
				message.setParameters(additionalParams);
				componentSpec.addActionComponent(message);
			}
			incompleteSpecEvent.addActionSpec(componentSpec);

		}
		sendActionsOut(incompleteSpecEvent);
		logger.debug("Generated feedback: " + incompleteSpecEvent.toString());
	}

	private void sendNoFeedbackAvailableMessage(ActionType requestedActionType,
			UserID originalRequestorID) {
		ActionSpecEvent incompleteSpecEvent = new ActionSpecEvent(sessionID,
				getAgentDescription().getComponentID());
		AgentAction componentSpec = new AgentAction();
		componentSpec.setActionRecipient(originalRequestorID);
		String messageString = "No feedback available";
		Message message = new Message(messageString);
		componentSpec.addActionComponent(message);
		incompleteSpecEvent.addActionSpec(componentSpec);
		sendActionsOut(incompleteSpecEvent);
	}

	protected void sendActionsOut(ActionSpecEvent actionSpecEvent) {
		sendActionsToEUE(actionSpecEvent);
	}

	/**
	 * 
	 * Sends an {@link AgentAction} that contains the 'raw'
	 * {@link AnalysisResult}s without further application of pedagogical
	 * strategies.
	 */
	private void sendRawResults(AnalysisType aType,
			List<AnalysisResult> orderedResultList, UserID originalRequestorID) {

		ActionSpecEvent incompleteSpecEvent = new ActionSpecEvent(sessionID,
				getAgentDescription().getComponentID());

		AgentAction aSpec = new AgentAction();

		if (orderedResultList.size() == 0) {
			/**
			 * sendNoFeedbackAvailableMessage(incompleteSpecEvent,
			 * originalRequestorID); return;
			 */
			// add indicator for no result
			NoAnalysisResults noResults = new NoAnalysisResults(aType);
			orderedResultList.add(noResults);
		}
		for (AnalysisResult result : orderedResultList) {
			aSpec.addActionComponent(result);
		}
		aSpec.setActionRecipient(originalRequestorID);
		incompleteSpecEvent.addActionSpec(aSpec);
		sendActionsToEUE(incompleteSpecEvent);
		logger.debug("Generated raw results: " + incompleteSpecEvent.toString());
	}

	/**
	 * Sorts and filters the provided {@link AnalysisResult}s according to their
	 * expected utility using a phase probability model, a set of filter
	 * criteria and a cut-off threshold.
	 * 
	 */
	private List<ActionTypeResult> sortAndFilter(
			Map<String, Double> phaseProbabilities,
			List<String> filterCriteria,
			List<ActionTypeResult> unsortedResults, int maxNumResults) {
		Set<String> phaseIDs = phaseProbabilities.keySet();

		List<ActionTypeResult> sortedResults = new Vector<ActionTypeResult>();

		for (ActionTypeResult result : unsortedResults) {

			AnalysisActionType foundSimpleActionType = (AnalysisActionType) result
					.getActionType();
			double weightedPriority = 0;
			for (String phaseID : phaseIDs) {
				double phaseProb = phaseProbabilities.get(phaseID);
				double priority = foundSimpleActionType.getPriority(phaseID);
				weightedPriority += (phaseProb * priority);
			}
			// messages with an expected utility of 0 are filtered out
			if (weightedPriority != 0) {
				result.setUtility(weightedPriority);
				sortedResults.add(result);
			}

		}

		Collections.sort(sortedResults, actionTypeResultsComparator);

		int count = 0;
		logger.debug("Utility for best-" + maxNumResults + " action types:");

		boolean one_per_type = filterCriteria
				.contains(CompoundActionType.ONE_PER_TYPE);
		List<ActionTypeResult> resultShortList = new Vector<ActionTypeResult>();
		Set<String> alreadyIncludedTypes = new HashSet<String>();
		for (ActionTypeResult result : sortedResults) {

			if (count == maxNumResults) {
				break;
			}

			AnalysisActionType actionType = result.getActionType();
			String actionTypeID = actionType.getTypeID();

			if (one_per_type && alreadyIncludedTypes.contains(actionTypeID)) {
				// ignore
			} else {
				resultShortList.add(result);
				alreadyIncludedTypes.add(actionTypeID);
				++count;
				logger.debug("Expected utility for '" + actionTypeID + "': "
						+ result.getUtility());
			}

		}

		logger.debug("Filtered and sorted results:");
		int i = 1;
		for (ActionTypeResult result : resultShortList) {
			logger.debug("(" + i + "): " + result.getActionType().getTypeID()
					+ ", result=" + result.getResult());
			++i;
		}

		return resultShortList;
	}

	private String fillInProperties(String text,
			Map<String, String> propName2Value) {
		for (String propName : propName2Value.keySet()) {
			String propValue = propName2Value.get(propName);
			text = text.replace("[##" + propName + "##]", propValue);
		}
		return text;
	}

}
