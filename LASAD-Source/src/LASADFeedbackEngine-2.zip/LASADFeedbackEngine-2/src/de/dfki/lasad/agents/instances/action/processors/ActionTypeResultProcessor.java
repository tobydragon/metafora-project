package de.dfki.lasad.agents.instances.action.processors;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.action.ActionType;
import lasad.shared.dfki.meta.agents.action.feedback.FeedbackActionType;
import lasad.shared.dfki.meta.agents.action.feedback.PatternFilterDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.instances.TaskScheduler;
import de.dfki.lasad.agents.instances.action.UserServiceID;
import de.dfki.lasad.agents.logic.action.patternfilter.PatternFilterServiceFactory;
import de.dfki.lasad.agents.logic.action.patternfilter.PatternFilterServiceInterface;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ActionTypeResultProcessor {

	private static Log logger = LogFactory
			.getLog(ActionTypeResultProcessor.class);

	private UserServiceID userServiceID = null;
	private ActionType actionType = null;
	private TaskScheduler taskSchedulerRef = null;

	private PatternFilterServiceInterface patternFilterService = null;

	private List<ProvisionTypeResultProcessor> listeners = new Vector<ProvisionTypeResultProcessor>();

	private Map<Integer, ActionTypeResult> analysisResultID2actionTypeResult = new HashMap<Integer, ActionTypeResult>();

	private String debugID = null;
	private String debugPrefix = null;

	public ActionTypeResultProcessor(UserServiceID userServiceID,
			ActionType actionType, TaskScheduler taskSchedulerRef) {
		this.userServiceID = userServiceID;
		this.actionType = actionType;

		debugID = "(" + actionType.getServiceID().getTypeID() + " | "
				+ userServiceID.getUserID().getIdAsString() + ")";
		debugPrefix = debugID + " - ";

		this.taskSchedulerRef = taskSchedulerRef;

		initFilterService();
	}

	public String getDebugID() {
		return debugID;
	}
	
	private void initFilterService() {
		List<PatternFilterDef> filterDefinitions;
		if (actionType instanceof FeedbackActionType) {
			FeedbackActionType fActionType = (FeedbackActionType) actionType;
			filterDefinitions = fActionType.getFilterDefs();
		} else {
			logger.info(debugPrefix
					+ "No pattern filters supported in action type: "
					+ actionType);
			filterDefinitions = new Vector<PatternFilterDef>();
		}
		this.patternFilterService = PatternFilterServiceFactory
				.createPatternFilterService(userServiceID.getUserID(),
						filterDefinitions, taskSchedulerRef);
	}

	public void addResultListenerAndUpdate(ProvisionTypeResultProcessor listener) {
		listeners.add(listener);
		replayResults(listener);
	}

	public void onResultChanged(AnalysisResult resultData, boolean doRemove) {
		if (doRemove) {
			ActionTypeResult invalidatedResult = tryRemoveResult(resultData);
			if (invalidatedResult != null) {
				logger.debug(debugPrefix + "REMOVED - "
						+ resultData.toSimpleString());
				logModeledResults();
				propagateResult(invalidatedResult, true);
			}
		} else {
			boolean filtersSatisfied = patternFilterService.keep(resultData);
			boolean modeled = analysisResultID2actionTypeResult
					.containsKey(resultData.getId());

			if (filtersSatisfied && !modeled) {
				ActionTypeResult addedResult = addResult(resultData);
				logger.debug(debugPrefix + "ADDED - "
						+ resultData.toSimpleString());
				logModeledResults();
				propagateResult(addedResult, false);
			} else if (!filtersSatisfied && modeled) {
				ActionTypeResult invalidatedResult = tryRemoveResult(resultData);
				logger.debug(debugPrefix + "REMOVED - "
						+ resultData.toSimpleString());
				logModeledResults();
				propagateResult(invalidatedResult, true);
			} else {
				logger.debug(debugPrefix + "IGNORED - "
						+ resultData.toSimpleString());
				logModeledResults();
			}
		}
	}

	private ActionTypeResult addResult(AnalysisResult resultData) {
		int analysisResultID = resultData.getId();
		ActionTypeResult actionResult = new ActionTypeResult(actionType,
				resultData);
		analysisResultID2actionTypeResult.put(analysisResultID, actionResult);
		return actionResult;
	}

	/**
	 * 
	 * @param resultData
	 * @return invalidated {@link ActionTypeResult} or <code>null</code> if no
	 *         such result is not modeled
	 */
	private ActionTypeResult tryRemoveResult(AnalysisResult resultData) {
		int analysisResultID = resultData.getId();
		ActionTypeResult invalidatedActionResult = analysisResultID2actionTypeResult
				.remove(analysisResultID);
		return invalidatedActionResult;
	}

	private void propagateResult(ActionTypeResult result, boolean deleted) {
		for (ProvisionTypeResultProcessor provResultsDB : listeners) {
			provResultsDB.onResultChanged(result, deleted);
		}
	}

	private void replayResults(
			ProvisionTypeResultProcessor newProvisionProcessor) {
		for (ActionTypeResult result : analysisResultID2actionTypeResult
				.values()) {
			newProvisionProcessor.onResultChanged(result, false);
		}
	}

	private void logModeledResults() {
		logger.debug(debugPrefix + "Modeled results:");
		for (Integer resultID : analysisResultID2actionTypeResult.keySet()) {
			ActionTypeResult result = analysisResultID2actionTypeResult
					.get(resultID);
			logger.debug("... " + debugPrefix
					+ result.getResult().toSimpleString());
		}
	}
}
