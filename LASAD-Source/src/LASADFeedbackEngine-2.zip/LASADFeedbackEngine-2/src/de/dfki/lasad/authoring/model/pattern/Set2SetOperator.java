package de.dfki.lasad.authoring.model.pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public enum Set2SetOperator implements Operator{
	EQUAL("SET_EQUAL"), 
	NOT_EQUAL("SET_NOT_EQUAL"), 
	SUBSET("SUBSET"), 
	NOT_SUBSET("NOT_SUBSET"), 
	SUPERSET("SUPERSET"), 
	NOT_SUPERSET("NOT_SUPERSET"), 
	INTERSECT("INTERSECT"), 
	NOT_INTERSECT("NOT_INTERSECT");

	private static final Log logger = LogFactory.getLog(Set2SetOperator.class);
	
	private final String operator;

	Set2SetOperator(String operator) {
		this.operator = operator;
	}

	public Set2SetOperator invert() {
		if (equals(EQUAL)) {
			return EQUAL;
		} else if (equals(NOT_EQUAL)) {
			return NOT_EQUAL;
		} else if (equals(SUBSET)) {
			return SUPERSET;
		} else if (equals(NOT_SUBSET)) {
			return NOT_SUPERSET;
		} else if (equals(SUPERSET)) {
			return SUBSET;
		} else if (equals(NOT_SUPERSET)) {
			return NOT_SUBSET;
		} else if (equals(INTERSECT)) {
			return INTERSECT;
		} else if (equals(NOT_INTERSECT)) {
			return NOT_INTERSECT;
		} else {
			logger.error("Error in method invert()");
			return null;
		}
	}
	
	public static void main(String[] args) {
		Set2SetOperator op = SUBSET;
		System.out.println(op.invert());
	}
}
