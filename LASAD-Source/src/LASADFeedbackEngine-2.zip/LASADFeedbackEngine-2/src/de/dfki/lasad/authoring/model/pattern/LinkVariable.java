package de.dfki.lasad.authoring.model.pattern;

/**
 * (see {@link ElementVariable})
 * 
 * @author Almer Bolatov
 * 
 */
public class LinkVariable extends ElementVariable {

}
