package de.dfki.lasad.authoring.converter;


import de.dfki.lasad.agents.instances.jess.JessFeedbackAgentConfiguration;
import de.dfki.lasad.authoring.model.AgentConfigFE;

/**
 * 
 * @author oliverscheuer
 *
 */
public class AgentConfigConverterFE2BE {

	public static JessFeedbackAgentConfiguration toBEConf(AgentConfigFE xmlConf){
		// TODO
		return null;
	}
	
}
