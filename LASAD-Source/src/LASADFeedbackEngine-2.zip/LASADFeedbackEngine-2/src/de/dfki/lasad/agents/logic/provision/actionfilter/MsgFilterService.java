package de.dfki.lasad.agents.logic.provision.actionfilter;

import java.util.List;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgFilterService implements MsgFilterServiceInterface {

	private UserID referenceUser = null;
	private List<MsgFilter> msgFilters = null;
	private List<MsgListFilter> msgListFilters = null;

	MsgFilterService(UserID referenceUser, List<MsgFilter> msgFilters,
			List<MsgListFilter> msgListFilters) {
		this.referenceUser = referenceUser;
		this.msgFilters = msgFilters;
		this.msgListFilters = msgListFilters;
	}

	public void filter(List<ActionTypeResult> list) {
		for (MsgListFilter filter : msgListFilters) {
			filter.filter(list);
		}
	}

	public boolean keep(ActionTypeResult aTypeResult) {
		for (MsgFilter checker : msgFilters) {
			if (checker.keep(aTypeResult) == false) {
				return false;
			}
		}
		return true;
	}
}
