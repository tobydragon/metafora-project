package de.dfki.lasad.session.data.meta.ontology.base;

import de.dfki.lasad.session.data.meta.ontology.ComparisonGroup;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * 
 * @author oliverscheuer
 *
 */
public class DropDownType extends BaseType {

	private static DropDownType instance = new DropDownType();
	
	private DropDownType(){
		super();
		lasadElementType = "dropdown";
		jessTemplateName = "elem_dropdown";
		addComponentSpecification(PropDescr.DEFAULT_COMPONENT_ID, "SELECTION", JessDataType.STRING, ComparisonGroup.TEXT);
	}
	
	public static DropDownType getInstance(){
		return instance;
	}
}