package de.dfki.lasad.agents.logic.action.patternfilter;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.agents.data.analysis.user.UserResult;
import de.dfki.lasad.agents.instances.TaskScheduler;
import de.dfki.lasad.session.data.UserID;

/**
 * TODO different subclasses to handle different result types (user result,
 * object result)
 * 
 * @author oliverscheuer
 * 
 */
public class PatternFilterService implements PatternFilterServiceInterface {

	private UserID referenceUser;
	private UserFilter userFilter;
	private List<ObjectFilter> objectFilters = new Vector<ObjectFilter>();

	PatternFilterService(UserID referenceUser, List<ObjectFilter> objectFilters) {
		this.referenceUser = referenceUser;
		this.userFilter = new UserFilter_IsUser(referenceUser);
		this.objectFilters = objectFilters;
	}

	public boolean keep(AnalysisResult result) {
		if (result instanceof ObjectResult) {
			ObjectResult objectResult = (ObjectResult) result;
			for (ObjectFilter checker : objectFilters) {
				if (checker.keep(objectResult) == false) {
					return false;
				}
			}
			return true;
		} else if (result instanceof UserResult) {
			return userFilter.keep((UserResult) result);
		} else {
			return true;
		}
	}

}
