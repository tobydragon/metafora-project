package de.dfki.lasad.agents.logic.provision.actionsort;

import java.util.Comparator;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;

/**
 * 
 * @author oliverscheuer
 *
 */
public abstract class MsgSortComparator implements
		Comparator<ActionTypeResult> {

	private MsgSortComparator tieBreaker = null;

	public MsgSortComparator(MsgSortComparator tieBreaker) {
		this.tieBreaker = tieBreaker;
	}

	@Override
	public int compare(ActionTypeResult result1, ActionTypeResult result2) {
		int compResult = compareImpl(result1, result2);
		if (compResult == 0 && tieBreaker != null) {
			return tieBreaker.compare(result1, result2);
		}
		return compResult;
	}

	protected abstract int compareImpl(ActionTypeResult result1,
			ActionTypeResult result2);

}
