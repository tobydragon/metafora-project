package de.dfki.lasad.authoring.model;

import java.io.File;
import java.util.List;
import java.util.Vector;

import org.jdom.Element;

import de.dfki.lasad.authoring.model.pattern.Pattern;
import de.dfki.lasad.util.XMLUtil;

/**
 * an agent configuration (to be used in the graphical frontend).
 * 
 * @author oliverscheuer
 * 
 */
public class AgentConfigFE {

	private String agentID;
	private List<Pattern> patterns = new Vector<Pattern>();

	// ...
	// TODO

	public Element toXMLElem() {
		Element e = new Element(ElementStrings.AGENT);
		// TODO produced XML should follow format of:
		// /LASADAFEngine/conf/default/details/agents/types/largo-default/largo-default.jess.xml
		return e;

	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public List<Pattern> getPatterns() {
		return patterns;
	}

	public void setPatterns(List<Pattern> patterns) {
		this.patterns = patterns;
	}

	public static AgentConfigFE fromXMLElem(Element xml) {
		// TODO someXML.equals(toXML(fromXML(someXML)))
		return null;
	}

	public String toXMLString() {
		Element e = toXMLElem();
		return XMLUtil.xmlElem2docString(e);
	}

	public void writeXMLFile(File targetFile) {
		Element e = toXMLElem();
		XMLUtil.xmlElem2File(targetFile, e);
	}
	
	public static AgentConfigFE fromXMLString(String xml) {
		Element e = XMLUtil.string2xmlElem(xml);
		return fromXMLElem(e);
	}

	public static AgentConfigFE fromXMLFile(File file) {
		Element e = XMLUtil.file2xmlElem(file);
		return fromXMLElem(e);
	}

	@Override
	public String toString() {
		return "AgentConfigFE [agentID=" + agentID + ", patterns=" + patterns
				+ "]";
	}
	
	
}
