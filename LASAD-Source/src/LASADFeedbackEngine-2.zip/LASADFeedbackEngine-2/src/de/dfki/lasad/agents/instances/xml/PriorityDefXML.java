package de.dfki.lasad.agents.instances.xml;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lasad.shared.dfki.meta.agents.action.PriorityDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;



/**
 * 
 * @author oliverscheuer
 * 
 */
public class PriorityDefXML {

	private static Log logger = LogFactory.getLog(PriorityDefXML.class);

	public static final String ELEMENT_NAME = "priority";

	public static PriorityDef fromXML(Element priorityElem) {

		PriorityDef priorityDef = new PriorityDef();

		Element defaultElem = priorityElem.getChild("default");
		Integer defaultPriority = getPriorityIfDefined(defaultElem);
		if (defaultPriority == null) {
			logger.error("No default priority defined");
		}
		priorityDef.setDefaultPriority(defaultPriority);
		priorityDef.setDefaultRepresentativeness(defaultPriority);
		for (Element phaseElem : (List<Element>) priorityElem
				.getChildren("phase")) {

			String phaseID = phaseElem.getAttributeValue("idref");
			Integer priority = getPriorityIfDefined(phaseElem);
			if (priority != null) {
				priorityDef.addPhasePriority(phaseID, priority);
				priorityDef.addPhaseRepresentativeness(phaseID, priority);
			}
		}

		return priorityDef;
	}

	protected static Integer getPriorityIfDefined(Element phaseOrDefaultElem) {
		String valueString = phaseOrDefaultElem.getAttributeValue("priority");
		if (valueString == null) {
			return null;
		}
		return Integer.valueOf(valueString);
	}

	protected static Integer getRepresentativenessIfDefined(
			Element phaseOrDefaultElem) {
		String valueString = phaseOrDefaultElem
				.getAttributeValue("representativeness");
		if (valueString == null) {
			return null;
		}
		return Integer.valueOf(valueString);
	}

	public static Element toXML(PriorityDef priorityDef) {

		Element priorityElem = new Element(ELEMENT_NAME);

		Integer defaultPriority = priorityDef.getDefaultPriority();
		Integer defaultRepresentativeness = priorityDef
				.getDefaultRepresentativeness();
		Element defaultElem = getDefaultElem(defaultPriority,
				defaultRepresentativeness);
		priorityElem.addContent(defaultElem);

		Set<String> relevantPhases = new HashSet<String>();
		Map<String, Integer> phaseID2priority = priorityDef.getPhase2Priority();
		Map<String, Integer> phaseID2representativenss = priorityDef
				.getPhase2Representativeness();

		relevantPhases.addAll(phaseID2priority.keySet());
		relevantPhases.addAll(phaseID2representativenss.keySet());

		for (String phaseID : relevantPhases) {
			Integer phasePriority = phaseID2priority.get(phaseID);
			Integer phaseRepresentativenss = phaseID2representativenss
					.get(phaseID);
			Element phaseElem = getPhaseElem(phaseID, phasePriority,
					phaseRepresentativenss);
			priorityElem.addContent(phaseElem);
		}

		return priorityElem;
	}

	protected static Element getDefaultElem(Integer defaultPriority,
			Integer defaultRepresentativeness) {
		Element defaultElem = new Element("default");

		if (defaultPriority != null) {
			defaultElem.setAttribute("priority",
					String.valueOf(defaultPriority));
		}
		return defaultElem;
	}

	protected static Element getPhaseElem(String phaseID, Integer priority,
			Integer representativeness) {
		Element phaseElem = new Element("phase");
		phaseElem.setAttribute("idref", phaseID);
		if (priority != null) {
			phaseElem.setAttribute("priority", String.valueOf(priority));
		}
		return phaseElem;
	}
}
