package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import java.io.File;
import java.io.FilenameFilter;
import java.util.List;
import java.util.Vector;

import org.jdom.Element;

import lasad.shared.dfki.meta.ontology.Ontology;

import de.dfki.lasad.dataservice.lasad.translators.OntologyXML;
import de.dfki.lasad.util.ClasspathResourceUtil;
import de.dfki.lasad.util.XMLUtil;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class TestData {

	static final String testFolderPath = ClasspathResourceUtil
			.getAbsoluteFilepathFromResourceOnClasspath(
					StructureAnalysisTypeXMLTest.class, "data");
	static final File testFolder = new File(testFolderPath);
	static final File ontologyFolder = new File(testFolder, "ontology");

	static final List<File> testFiles = new Vector<File>();

	static final File largoOntologyLocalFile = new File(ontologyFolder,
			"LARGO.xml");
	static final Element largoOntologyElem = XMLUtil
			.file2xmlElem(largoOntologyLocalFile);
	static final String largoOntologyXML = XMLUtil
			.xmlElem2docString(largoOntologyElem);
	static Ontology largoOntology = OntologyXML.parseOntology(largoOntologyXML);

	static {
		File[] testFileArray = testFolder.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				return name.endsWith(".xml");
			}
		});

		for (int i = 0; i < testFileArray.length; ++i) {
			testFiles.add(testFileArray[i]);
		}
	}

	// specific test cases
	static final String TESTFILE_R20 = "R20_test_without_condition.xml";
	static final String TESTFILE_REORDER_SEQUENCE = "test_node_sequence.xml";
	static final String TESTFILE_INTERNAL_EXTERNAL_COMPARISONS = "test_comparison_type_and_id.xml";
	static final String TESTFILE_BINS = "test_bins.xml";
	static final String TESTFILE_JESS_CONST_SET_FACTS = "test_set2constset_comparison.xml";
	static final String TESTFILE_PROPS_USED_AS_REF_VALUES = "test_properties_used_as_reference_values.xml";

	static File getTestFileFromTestFolder(String localFileName) {
		return new File(testFolder, localFileName);
	}

	static Element loadXMLFromTestFolder(File testFile) {
		return XMLUtil.file2xmlElem(testFile);
	}

}
