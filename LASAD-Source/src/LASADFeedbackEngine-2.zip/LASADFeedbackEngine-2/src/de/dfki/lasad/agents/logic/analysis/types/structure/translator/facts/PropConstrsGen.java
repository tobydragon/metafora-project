package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ComparisonType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PropConstrsGen {

	private static final Log logger = LogFactory.getLog(PropConstrsGen.class);

	private JessIDAndSlotNameGenerator idGen;

	// in
	private ElementVariableProp propVar;
	private List<Comparison> comparisons;
	private Bin bin;
	private int tempVarAppendix;
	private boolean useTempVarLeft;
	private boolean useTempVarRight;
	private boolean addNotNilCheck;

	// generated
	private List<ConstrGen> constrGens = new Vector<ConstrGen>();

	/**
	 * Generates slot constraint string for given {@link ElementVariableProp}
	 * according to given specification.
	 * 
	 * @param propVar
	 *            target property (component)
	 * @param comparisons
	 *            {@link Comparisons}
	 * @param compSelector
	 *            {@link Comparison} selector (of {@link ComparisonType})
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 */
	public PropConstrsGen(JessIDAndSlotNameGenerator idGen,
			ElementVariableProp propVar, List<Comparison> comparisons, Bin bin,
			int tempVarAppendix, boolean useTempVarLeft,
			boolean useTempVarRight, boolean addNotNilCheck) {
		this.idGen = idGen;
		this.propVar = propVar;
		this.comparisons = comparisons;
		this.bin = bin;
		this.tempVarAppendix = tempVarAppendix;
		this.useTempVarLeft = useTempVarLeft;
		this.useTempVarRight = useTempVarRight;
		this.addNotNilCheck = addNotNilCheck;

		for (Comparison comp : comparisons) {
			ConstrGen constrGen = new ConstrGen(idGen, comp, bin,
					tempVarAppendix, useTempVarLeft, useTempVarRight);
			constrGens.add(constrGen);

		}
	}

	public int getNumConstrs() {
		return constrGens.size();
	}

	public String getString() {
		StringBuffer buf = new StringBuffer();

		int numConstrs = constrGens.size();
		if (addNotNilCheck) {
			String varID = idGen.generatePropVarID(propVar, tempVarAppendix,
					useTempVarLeft, false);
			buf.append(generateNotNilSlotConstr(varID));
			if (numConstrs > 0) {
				buf.append("\n");
			}
		}
		int constrsAdded = 0;
		for (ConstrGen constrPrinter : constrGens) {
			buf.append(constrPrinter.getString());
			++constrsAdded;
			if (constrsAdded < numConstrs) {
				buf.append("\n");
			}
		}
		return buf.toString();
	}

	/**
	 * Generate 'not nil' constraint
	 * 
	 * @param varID
	 * @return
	 */
	private String generateNotNilSlotConstr(String varID) {
		return "&:(neq " + varID + " nil)";
	}
}
