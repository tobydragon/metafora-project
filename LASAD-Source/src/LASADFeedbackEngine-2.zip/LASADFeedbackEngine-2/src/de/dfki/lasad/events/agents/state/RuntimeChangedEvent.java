package de.dfki.lasad.events.agents.state;

import de.dfki.lasad.core.components.instance.ServiceStatus;

/**
 * Some Feedback-Engine component has changed its runtime status (see also
 * {@link ServiceStatus}).
 * 
 * @author oliverscheuer
 * 
 */
public class RuntimeChangedEvent extends AFStateChangedEvent {

	private ServiceStatus oldStatus = null;
	private ServiceStatus newStatus = null;

	public RuntimeChangedEvent(String srcCompId) {
		super(srcCompId);
	}

	public ServiceStatus getOldStatus() {
		return oldStatus;
	}

	public void setOldStatus(ServiceStatus oldStatus) {
		this.oldStatus = oldStatus;
	}

	public ServiceStatus getNewStatus() {
		return newStatus;
	}

	public void setNewStatus(ServiceStatus newStatus) {
		this.newStatus = newStatus;
	}

	@Override
	public String toString() {
		return "RuntimeChangedEvent [oldStatus=" + oldStatus + ", newStatus="
				+ newStatus + "]";
	}

}
