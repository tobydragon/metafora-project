package de.dfki.lasad.agents.instances.jess;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.CDATA;
import org.jdom.DocType;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.EntityRef;

import de.dfki.lasad.agents.SimpleSessionChecker;
import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.CompoundActionType;
import de.dfki.lasad.agents.data.meta.RuleAnalysisType;
import de.dfki.lasad.agents.data.meta.RuleAnalysisTypeXML;
import de.dfki.lasad.core.ConfigurationDatabase;
import de.dfki.lasad.util.XMLUtil;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class JessFeedbackAgentConfigurationXML {

	static Log logger = LogFactory
			.getLog(JessFeedbackAgentConfigurationXML.class);

	public static void fromXMLElem(JessFeedbackAgentConfiguration conf,
			Element agentElem) {

		try {
			String agentID = agentElem.getAttributeValue("id");
			conf.setAgentID(agentID);

			String exposeAllString = agentElem.getAttributeValue("expose_all");
			if (exposeAllString != null && Boolean.valueOf(exposeAllString)) {
				boolean exposeAll = Boolean.valueOf(exposeAllString);
				conf.setPublishAllActionTypes(exposeAll);
			}

			String provideRawResultsString = agentElem
					.getAttributeValue("raw_results");
			if (provideRawResultsString != null
					&& Boolean.valueOf(provideRawResultsString)) {
				conf.setProvideRawResults(Boolean
						.valueOf(provideRawResultsString));
			}

			Element supportedOntologiesElem = agentElem
					.getChild("supported_ontologies");
			String supportAllOntologiesString = supportedOntologiesElem
					.getAttributeValue("support_all");
			if (supportAllOntologiesString != null
					&& Boolean.valueOf(supportAllOntologiesString)) {
				conf.setSupportedAllOntologies();
			} else {
				@SuppressWarnings("unchecked")
				List<Element> ontologyIDElements = supportedOntologiesElem
						.getChildren("ontology");
				List<String> supportedOntologyIDs = parseOntologyIDElements(ontologyIDElements);
				conf.setSupportedOntologies(supportedOntologyIDs);
			}

			Element phaseDefElem = agentElem.getChild("phase_def");
			@SuppressWarnings("unchecked")
			List<Element> phaseIDElements = phaseDefElem.getChildren("phase");
			List<String> phaseIDs = parsePhaseIDElements(phaseIDElements);
			conf.setPhaseIDs(phaseIDs);

			@SuppressWarnings("unchecked")
			Element patternsElement = agentElem.getChild("patterns");
			@SuppressWarnings("unchecked")
			List<Element> patternElements = patternsElement
					.getChildren(RuleAnalysisTypeXML.ELEMENT_NAME);
			List<RuleAnalysisType> patterns = parsePatternElements(
					patternElements, agentID);
			addPatternsToConf(patterns, conf);

			@SuppressWarnings("unchecked")
			List<Element> ruleActionElements = agentElem
					.getChildren("rule-action");
			List<AnalysisActionType> simpleActionTypes = parseSimpleActionElements(
					ruleActionElements, agentID, conf);
			addSimpleActionsToConf(simpleActionTypes, conf);

			@SuppressWarnings("unchecked")
			List<Element> filterActionElements = agentElem
					.getChildren("filter-action");
			List<CompoundActionType> compoundActionTypes = parseFilterActionElements(
					filterActionElements, agentID, simpleActionTypes);
			addFilterActionElementsToConf(compoundActionTypes, conf);

		} catch (Exception e) {
			logger.error("Error while parsing conf file: " + e.getClass()
					+ ": " + e.getMessage(), e);
		}
	}

	private static void addPatternsToConf(List<RuleAnalysisType> patterns,
			JessFeedbackAgentConfiguration conf) {
		for (RuleAnalysisType p : patterns) {
			conf.addRuleAnalysisType(p);
		}
	}

	private static void addSimpleActionsToConf(
			List<AnalysisActionType> simpleActionTypes,
			JessFeedbackAgentConfiguration conf) {
		for (AnalysisActionType ruleActionType : simpleActionTypes) {
			conf.addSimpleActionType(ruleActionType);
		}
	}

	private static List<String> parsePhaseIDElements(
			List<Element> phaseIDElements) {
		List<String> phaseIDs = new Vector<String>();
		for (Element phaseIDElem : phaseIDElements) {
			String phaseID = phaseIDElem.getAttributeValue("id");
			phaseIDs.add(phaseID);
		}
		return phaseIDs;
	}

	private static List<String> parseOntologyIDElements(
			List<Element> ontologyIDElements) {
		List<String> ontologyIDs = new Vector<String>();
		for (Element ontologyIDElem : ontologyIDElements) {
			String ontologyID = ontologyIDElem.getAttributeValue("idref");
			ontologyIDs.add(ontologyID);
		}
		return ontologyIDs;
	}

	private static List<RuleAnalysisType> parsePatternElements(
			List<Element> patternElements, String agentID) {

		List<RuleAnalysisType> result = new Vector<RuleAnalysisType>();
		for (Element patternElem : patternElements) {
			RuleAnalysisType patternDef = RuleAnalysisTypeXML.fromXML(agentID,
					patternElem);
			result.add(patternDef);
		}
		return result;
	}

	private static List<AnalysisActionType> parseSimpleActionElements(
			List<Element> ruleActionElements, String agentID,
			JessFeedbackAgentConfiguration conf) {

		List<AnalysisActionType> simpleActionTypes = new Vector<AnalysisActionType>();
		for (Element ruleActionElem : ruleActionElements) {
			String actionTypeID = ruleActionElem.getAttributeValue("id");

			Element patternElem = ruleActionElem.getChild("pattern");
			String analysisTypeID = patternElem.getAttributeValue("idref");
			RuleAnalysisType ruleType = conf
					.getRuleAnalysisType(analysisTypeID);

			AnalysisActionType simpleType = new AnalysisActionType(agentID,
					actionTypeID, ruleType);

			Element displayNameElement = ruleActionElem
					.getChild("display-name");
			if (displayNameElement != null) {
				String displayName = displayNameElement.getText();
				simpleType.setDisplayName(displayName);
			}

			Element feedbackShortElem = ruleActionElem
					.getChild("feedback-short");
			String feedbackShort = feedbackShortElem.getTextNormalize();
			simpleType.setFeedbackShort(feedbackShort);

			Element feedbackLongElem = ruleActionElem.getChild("feedback-long");
			String feedbackLong = feedbackLongElem.getTextNormalize();
			simpleType.setFeedbackLong(feedbackLong);

			Element highlightingElem = ruleActionElem.getChild("highlighting");
			String highlightingString = highlightingElem.getTextNormalize();
			boolean highlighting = Boolean.parseBoolean(highlightingString);
			simpleType.setHighlighting(highlighting);

			Element additionalParamsElem = ruleActionElem
					.getChild("addition-params");
			if (additionalParamsElem != null) {
				@SuppressWarnings("unchecked")
				List<Element> paramElems = additionalParamsElem
						.getChildren("param");
				parseAdditionalParameters(simpleType, paramElems);
			}

			Element phasesElem = ruleActionElem.getChild("phases");
			@SuppressWarnings("unchecked")
			List<Element> phaseElements = phasesElem.getChildren("phase");
			for (Element phaseElem : phaseElements) {
				String phaseID = phaseElem.getAttributeValue("idref");
				Element priorityElem = phaseElem.getChild("priority");
				int priority = Integer.parseInt(priorityElem
						.getAttributeValue("value"));
				simpleType.addPriority(phaseID, priority);

				Element representativenessElem = phaseElem
						.getChild("representativeness");
				int representativeness = Integer
						.parseInt(representativenessElem
								.getAttributeValue("value"));
				simpleType.addRepresentativeness(phaseID, representativeness);
			}
			Element defaultSettingsElem = phasesElem.getChild("default");
			if (defaultSettingsElem != null) {
				Element priorityElem = defaultSettingsElem.getChild("priority");
				int priority = Integer.parseInt(priorityElem
						.getAttributeValue("value"));
				simpleType.setDefaultPriority(priority);

				Element representativenessElem = defaultSettingsElem
						.getChild("representativeness");
				int representativeness = Integer
						.parseInt(representativenessElem
								.getAttributeValue("value"));
				simpleType.setDefaultRepresentativeness(representativeness);
			}

			Element exposeElem = ruleActionElem.getChild("expose");
			boolean doExpose = Boolean.parseBoolean(exposeElem.getTextTrim());
			simpleType.setDoPublishToEndUser(doExpose);

			simpleActionTypes.add(simpleType);
		}
		return simpleActionTypes;
	}

	private static void parseAdditionalParameters(
			AnalysisActionType actionType, List<Element> paramElems) {
		for (Element paramElem : paramElems) {
			String paramName = paramElem.getAttributeValue("name");
			String paramValue = paramElem.getAttributeValue("value");
			Boolean paramIsDynamic = Boolean.parseBoolean(paramElem
					.getAttributeValue("dynamic"));
			if (paramIsDynamic) {
				actionType.addDynamicParam(paramName);
			} else {
				// assume: param is static
				actionType.addParam(paramName, paramValue);
			}
		}
	}

	private static void addFilterActionElementsToConf(
			List<CompoundActionType> filterActionTypes,
			JessFeedbackAgentConfiguration conf) {
		for (CompoundActionType compoundActionType : filterActionTypes) {
			conf.addCompoundActionType(compoundActionType);
		}
	}

	private static List<CompoundActionType> parseFilterActionElements(
			List<Element> filterActionElements, String agentID,
			List<AnalysisActionType> simpleActionTypes) {
		List<CompoundActionType> compoundActionTypes = new Vector<CompoundActionType>();
		for (Element filterActionElem : filterActionElements) {
			String typeID = filterActionElem.getAttributeValue("id");
			CompoundActionType actionType = new CompoundActionType(agentID,
					typeID);

			Element displayNameElement = filterActionElem
					.getChild("display-name");
			if (displayNameElement != null) {
				String displayName = displayNameElement.getTextNormalize();
				actionType.setDisplayName(displayName);
			}

			Element numberElem = filterActionElem.getChild("number");
			String numberString = numberElem.getTextTrim();
			if ("all".equals(numberString)) {
				actionType.setMaxNumResults(CompoundActionType.ALL_RESULTS);
			} else {
				try {
					int number = Integer.parseInt(numberString);
					actionType.setMaxNumResults(number);
				} catch (NumberFormatException e) {
					logger.warn("Parameter 'number' not formatted correctly "
							+ "in config file. Will use default value: "
							+ actionType.getMaxNumResults());
				}
			}

			Element dependentActionsElem = filterActionElem
					.getChild("subactions");

			String allSubTypesString = dependentActionsElem
					.getAttributeValue("all");
			if (allSubTypesString != null && Boolean.valueOf(allSubTypesString)) {
				boolean allSubTypes = Boolean.valueOf(allSubTypesString);
				actionType.setAllTypes(allSubTypes);

				for (ActionType subType : simpleActionTypes) {
					actionType.addActionType(subType);
				}
			} else {
				@SuppressWarnings("unchecked")
				List<Element> agentElements = dependentActionsElem
						.getChildren("action");
				for (Element agentElem : agentElements) {
					String dependentTypeID = agentElem
							.getAttributeValue("type");
					for (ActionType subType : simpleActionTypes) {
						if (subType.getTypeID().equals(dependentTypeID)) {
							actionType.addActionType(subType);
						}
					}
				}
			}

			Element filterCriteriaElem = filterActionElem
					.getChild("filter-criteria");
			@SuppressWarnings("unchecked")
			List<Element> criterionElements = filterCriteriaElem
					.getChildren("criterion");
			for (Element criterionElement : criterionElements) {
				String criterionType = criterionElement
						.getAttributeValue("type");
				actionType.addFilterCriterion(criterionType);
			}

			Element exposeElem = filterActionElem.getChild("expose");
			boolean doExpose = Boolean.parseBoolean(exposeElem.getTextTrim());
			actionType.setDoPublishToEndUser(doExpose);

			compoundActionTypes.add(actionType);
		}
		return compoundActionTypes;
	}

	public static void fromXMLFile(JessFeedbackAgentConfiguration conf,
			File file) {
		Element e = XMLUtil.file2xmlElem(file);
		fromXMLElem(conf, e);
	}

	public static Document toMasterXMLDoc(JessFeedbackAgentConfiguration conf) {
		Document doc = new Document();

		DocType docType = new DocType("rule_entities");
		doc.setDocType(docType);

		List<EntityRef> entityRefs = new Vector<EntityRef>();
		StringBuffer entityDefinitions = new StringBuffer();
		String agentID = conf.getAgentID();
		File agentHome = ConfigurationDatabase.getAgentConfHomeDir(agentID);
		for (AnalysisType aType : conf.getAnalysisTypes()) {
			RuleAnalysisType ruleAnalysisType = (RuleAnalysisType) aType;
			String patternID = ruleAnalysisType.getTypeID();
			File patternFile = ConfigurationDatabase
					.getAgentConfigBEPatternFile(agentID, patternID);
			String relativeFilepath = ConfigurationDatabase.getRelativePath(
					agentHome, patternFile);
			String entityString = XMLUtil.getXMLEntityString(patternID,
					relativeFilepath);
			entityDefinitions.append("    " + entityString + "\n");
			EntityRef entityRef = new EntityRef(patternID);
			entityRefs.add(entityRef);
		}
		docType.setInternalSubset(entityDefinitions.toString());

		Element agentElem = new Element("agent");
		doc.setRootElement(agentElem);
		agentElem.setAttribute("id", conf.getAgentID());
		String exposeAll = String.valueOf(conf.doPublishAllActionTypes());
		agentElem.setAttribute("expose_all", exposeAll);
		String rawResults = String.valueOf(conf.doPublishRawResults());
		agentElem.setAttribute("raw_results", rawResults);

		Element supportedOntologiesElem = new Element("supported_ontologies");
		agentElem.addContent("\n");
		agentElem.addContent(supportedOntologiesElem);
		

		if (conf.getSessionChecker() instanceof SimpleSessionChecker) {
			SimpleSessionChecker simpleChecker = (SimpleSessionChecker) conf
					.getSessionChecker();
			if (simpleChecker.allOntologiesSupported()) {
				supportedOntologiesElem.setAttribute("support_all", String.valueOf(true));
			} else {
				supportedOntologiesElem.setAttribute("support_all", String.valueOf(false));
				List<String> ontologyIDs = simpleChecker
						.getSupportedOntologies();
				for (String oID : ontologyIDs) {
					Element ontologyElem = new Element("ontology");
					supportedOntologiesElem.addContent(ontologyElem);
					ontologyElem.setAttribute("idref", oID);
				}
			}
		}

		Element phaseDefElem = new Element("phase_def");
		agentElem.addContent("\n");
		agentElem.addContent(phaseDefElem);
		List<String> phaseIDs = conf.getPhaseIDs();
		for (String pID : phaseIDs) {
			Element phaseElem = new Element("phase");
			phaseDefElem.addContent(phaseElem);
			phaseElem.setAttribute("id", pID);
		}

		Element patternsElem = new Element("patterns");
		agentElem.addContent("\n");
		agentElem.addContent(patternsElem);
		
		for (Iterator<EntityRef> iter = entityRefs.iterator(); iter.hasNext();) {
			EntityRef entityRef = iter.next();
			patternsElem.addContent("\n    ");
			patternsElem.addContent(entityRef);
			if(!iter.hasNext()){
				patternsElem.addContent("\n");
			}
		}

		for (AnalysisActionType aType : conf.getSimpleActionTypes()) {
			Element ruleActionElem = toXMLRuleActionElem(aType);
			agentElem.addContent("\n");
			agentElem.addContent(ruleActionElem);
		}

		for (CompoundActionType cType : conf.getCompoundActionTypes()) {
			Element filterActionElem = toXMLFilterActionElem(cType);
			agentElem.addContent("\n");
			agentElem.addContent(filterActionElem);
		}

		return doc;
	}

	private static Element toXMLRuleActionElem(AnalysisActionType aType) {
		Element ruleActionElem = new Element("rule-action");
		ruleActionElem.setAttribute("id", aType.getTypeID());

		Element displayNameElem = new Element("display-name");
		ruleActionElem.addContent(displayNameElem);
		displayNameElem.setAttribute("lang", "en");
		CDATA displayNameCData = new CDATA(aType.getDisplayName());
		//displayNameElem.addContent("\n      ");
		displayNameElem.addContent(displayNameCData);

		Element patternElem = new Element("pattern");
		ruleActionElem.addContent(patternElem);
		patternElem.setAttribute("idref", aType.getAnalysisType().getTypeID());

		Element feedbackShortElem = new Element("feedback-short");
		ruleActionElem.addContent(feedbackShortElem);
		feedbackShortElem.setAttribute("lang", "en");
		CDATA feedbackShortCData = new CDATA(aType.getFeedbackShort());
		//feedbackShortElem.addContent("\n      ");
		feedbackShortElem.addContent(feedbackShortCData);
		

		Element feedbackLongElem = new Element("feedback-long");
		ruleActionElem.addContent(feedbackLongElem);
		CDATA feedbackLongCData = new CDATA(aType.getFeedbackLong());
		//feedbackLongElem.addContent("\n      ");
		feedbackLongElem.addContent(feedbackLongCData);

		Element highlightingElem = new Element("highlighting");
		ruleActionElem.addContent(highlightingElem);
		String highlightingValue = String.valueOf(aType.doHighlighting());
		highlightingElem.setText(highlightingValue);

		Element additionalParamsElem = new Element("addition-params");
		ruleActionElem.addContent(additionalParamsElem);
		for (String paramName : aType.getParamNames()) {
			String paramValue = aType.getParamValue(paramName);
			Element paramElem = new Element("param");
			additionalParamsElem.addContent(paramElem);
			paramElem.setAttribute("name", paramName);
			paramElem.setAttribute("value", paramValue);
		}
		for (String paramName : aType.getDynamicParamNames()) {
			Element paramElem = new Element("param");
			additionalParamsElem.addContent(paramElem);
			paramElem.setAttribute("name", paramName);
			paramElem.setAttribute("dynamic", String.valueOf(true));
		}

		Element phasesElem = new Element("phases");
		ruleActionElem.addContent(phasesElem);

		Element defaultPhaseElem = getPhaseElem(null,
				aType.getDefaultPriority(),
				aType.getDefaultRepresentativeness(), true);
		phasesElem.addContent(defaultPhaseElem);

		for (String phaseID : aType.getPhases()) {
			Element phaseElem = getPhaseElem(phaseID,
					aType.getPriority(phaseID),
					aType.getRepresentativeness(phaseID), false);
			phasesElem.addContent(phaseElem);
		}

		Element exposeElem = new Element("expose");
		ruleActionElem.addContent(exposeElem);
		exposeElem.setText(String.valueOf(aType.doPublishToEndUser()));

		return ruleActionElem;
	}

	private static Element getPhaseElem(String phaseID, int priority,
			int representativeness, boolean isDefault) {
		Element phaseElem;
		if (isDefault) {
			phaseElem = new Element("default");
		} else {
			phaseElem = new Element("phase");
			phaseElem.setAttribute("idref", phaseID);
		}
		Element priorityElem = new Element("priority");
		phaseElem.addContent(priorityElem);
		priorityElem.setAttribute("value", String.valueOf(priority));
		Element representativenessElem = new Element("representativeness");
		phaseElem.addContent(representativenessElem);
		representativenessElem.setAttribute("value",
				String.valueOf(representativeness));
		return phaseElem;
	}

	private static Element toXMLFilterActionElem(CompoundActionType cType) {
		Element filterActionElem = new Element("filter-action");
		filterActionElem.setAttribute("id", cType.getTypeID());

		Element displayNameElem = new Element("display-name");
		filterActionElem.addContent(displayNameElem);
		displayNameElem.setAttribute("lang", "en");
		CDATA displayNameCData = new CDATA(cType.getDisplayName());
		//displayNameElem.addContent("\n      ");
		displayNameElem.addContent(displayNameCData);
		
		Element subActionsElem = new Element("subactions");
		filterActionElem.addContent(subActionsElem);
		
		if(cType.isAllTypes()){
			subActionsElem.setAttribute("all", String.valueOf(true));
		} else{
			for(ActionType subType: cType.getSubActionTypes()){
				Element actionElem = new Element("action");
				subActionsElem.addContent(actionElem);
				actionElem.setAttribute("type",subType.getTypeID());
			}	
		}
		
		Element numberElem = new Element("number");
		filterActionElem.addContent(numberElem);
		if(cType.getMaxNumResults() == CompoundActionType.ALL_RESULTS){
			numberElem.setText("all");
		} else{
			numberElem.setText(String.valueOf(cType.getMaxNumResults()));
		}
		
		Element criteriaElem = new Element("filter-criteria");
		filterActionElem.addContent(criteriaElem);
		for(String criterion: cType.getCriteria()){
			Element criterionElem = new Element("criterion");
			criteriaElem.addContent(criterionElem);
			criterionElem.setAttribute("type", criterion);
		}
		
		Element exposeElem = new Element("expose");
		filterActionElem.addContent(exposeElem);
		exposeElem.setText(String.valueOf(cType.doPublishToEndUser()));
		
		return filterActionElem;
	}

	public static Element toPatternXMLElem(RuleAnalysisType ruleType) {
		return RuleAnalysisTypeXML.toXML(ruleType);
	}

	public static void writeMasterXMLFile(File file,
			JessFeedbackAgentConfiguration conf) {
		try {
			if (file.exists()) {
				file.delete();
			}
			file.createNewFile();
			Document doc = toMasterXMLDoc(conf);
			XMLUtil.xmlDoc2File(file, doc);

		} catch (Exception e) {
			logger.error(
					"Error while writing : " + e.getClass() + ": "
							+ e.getMessage(), e);
		}
	}

	public static void writePatternXMLFile(File file, RuleAnalysisType ruleType) {
		try {
			if (file.exists()) {
				file.delete();
			}
			file.createNewFile();
			Element elem = toPatternXMLElem(ruleType);
			XMLUtil.xmlElem2File(file, elem);
		} catch (Exception e) {
			logger.error(
					"Error while writing : " + e.getClass() + ": "
							+ e.getMessage(), e);
		}
	}

	public static void main(String[] args) {
		File homeDir = ConfigurationDatabase.getAgentConfHomeDir("blah");
		File patternFile = ConfigurationDatabase.getAgentConfigBEPatternFile(
				"blah", "blub: 3311");
		System.out.println(ConfigurationDatabase.getRelativePath(homeDir,
				patternFile));
	}
}
