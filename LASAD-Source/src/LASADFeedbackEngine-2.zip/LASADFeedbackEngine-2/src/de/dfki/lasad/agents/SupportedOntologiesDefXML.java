package de.dfki.lasad.agents;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.SupportedOntologiesDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class SupportedOntologiesDefXML {

	private static Log logger = LogFactory
			.getLog(SupportedOntologiesDefXML.class);

	public static final String ELEMENT_NAME = "ontologies";

	public static SupportedOntologiesDef fromXML(Element ontologiesElem) {
		String supportAllString = ontologiesElem
				.getAttributeValue("support_all");
		boolean supportAll = Boolean.parseBoolean(supportAllString);
		if (supportAll) {
			return new SupportedOntologiesDef(true);
		}
		List<String> ontologyIDs = new Vector<String>();
		for (Element ontoElem : (List<Element>) ontologiesElem
				.getChildren("ontology")) {
			String ontoID = ontoElem.getAttributeValue("idref");
			ontologyIDs.add(ontoID);

		}
		return new SupportedOntologiesDef(ontologyIDs);
	}

	public static Element toXML(SupportedOntologiesDef ontoDef) {

		Element ontologiesElem = new Element(ELEMENT_NAME);
		if (ontoDef.isAllOntologies()) {
			ontologiesElem.setAttribute("support_all", String.valueOf(true));
		} else {
			for (String ontoID : ontoDef.getSupportedOntologies()) {
				Element ontoElem = new Element("ontology");
				ontoElem.setAttribute("idref", ontoID);
				ontologiesElem.addContent(ontoElem);
			}
		}
		return ontologiesElem;
	}
}
