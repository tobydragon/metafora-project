package de.dfki.lasad.authoring.converter.pattern2jess;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import de.dfki.lasad.authoring.model.pattern.Comparison;
import de.dfki.lasad.authoring.model.pattern.ElementVariable;
import de.dfki.lasad.authoring.model.pattern.LinkConstr;
import de.dfki.lasad.authoring.model.pattern.LinkVariable;
import de.dfki.lasad.authoring.model.pattern.NeighborConstrs;
import de.dfki.lasad.authoring.model.pattern.NodeConstr;
import de.dfki.lasad.authoring.model.pattern.Num2ConstNumComparison;
import de.dfki.lasad.authoring.model.pattern.Num2VarNumComparison;
import de.dfki.lasad.authoring.model.pattern.Pattern;
import de.dfki.lasad.authoring.model.pattern.PropConstr;
import de.dfki.lasad.authoring.model.pattern.PropertyVariable;
import de.dfki.lasad.authoring.model.pattern.Set2ConstSetComparison;
import de.dfki.lasad.authoring.model.pattern.Set2ConstStringComparison;
import de.dfki.lasad.authoring.model.pattern.Set2SetOperator;
import de.dfki.lasad.authoring.model.pattern.Set2StringOperator;
import de.dfki.lasad.authoring.model.pattern.Set2VarSetComparison;
import de.dfki.lasad.authoring.model.pattern.Set2VarStringComparison;
import de.dfki.lasad.authoring.model.pattern.String2ConstSetComparison;
import de.dfki.lasad.authoring.model.pattern.String2ConstStringComparison;
import de.dfki.lasad.authoring.model.pattern.String2SetOperator;
import de.dfki.lasad.authoring.model.pattern.String2StringOperator;
import de.dfki.lasad.authoring.model.pattern.String2VarSetComparison;
import de.dfki.lasad.authoring.model.pattern.String2VarStringComparison;
import de.dfki.lasad.authoring.model.pattern.VariableComparison;
import de.dfki.lasad.session.data.meta.Ontology;
import de.dfki.lasad.session.data.meta.ontology.ElementDescr;
import de.dfki.lasad.session.data.meta.ontology.LinkDescr;
import de.dfki.lasad.session.data.meta.ontology.NodeDescr;
import de.dfki.lasad.session.data.meta.ontology.NonStandardPropDescr;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;
import de.dfki.lasad.session.data.meta.ontology.StandardPropDescr;

/**
 * 
 * @author oliverscheuer, Almer Bolatov
 * 
 */
public class PatternPreprocessor {
	private static int a, b, c;

	public void preprocess(Pattern pattern, Ontology ontology) {
		reorderNodes(pattern);
		reorderLinks(pattern);
		fillInSupplementalFields(pattern, ontology);
	}

	/**
	 * Reorder Pattern.nodeConstrs in an “optimal” order
	 */
	private void reorderNodes(Pattern pattern) {
		/*
		 * (1.1) Move comparisons with link properties to the link variable 
		 * and “invert” these comparisons.
		 */
		Map<ElementVariable, Map<PropConstr, List<Comparison>>> linkMap = 
			new HashMap<ElementVariable, Map<PropConstr,List<Comparison>>>();
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			for (PropConstr pc : nc.getPropConstrs()) {
				for (Comparison c : pc.getComparisons()) {
					if (c instanceof VariableComparison) {
						VariableComparison varComp = (VariableComparison) c;
						PropertyVariable rightExpr = varComp.getRightExpr();
						ElementVariable elementVar = rightExpr.getElementVar();
						if (elementVar instanceof LinkVariable) {
							VariableComparison inverseComparison = varComp.getInverse();
							Map<PropConstr, List<Comparison>> tempMap = linkMap.containsKey(elementVar) ? 
									linkMap.get(elementVar) : new HashMap<PropConstr, List<Comparison>>();
							List<Comparison> linkComparisons = (tempMap.containsKey(pc)) ?
									tempMap.get(pc) : new ArrayList<Comparison>();
							linkComparisons.add(inverseComparison);
							
							pc.removeComparison(c);
						}
					}
				}
			}
		}
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			ElementVariable elemVar = lc.getElemVar();
			if (linkMap.containsKey(elemVar)) {
				Map<PropConstr, List<Comparison>> map = linkMap.get(elemVar);
				for (PropConstr pc : lc.getPropConstrs()) {
					if (map.containsKey(pc)) {
						List<Comparison> comparisonsFromNodeConstr = map.get(pc);
						
						List<Comparison> linkComps = pc.getComparisons();
						linkComps.addAll(comparisonsFromNodeConstr);
						pc.setComparisons(linkComps);
					}
				}
			}
		}

		/*
		 * Mapping that helps to identify neighborConstrs
		 */
		Map<ElementVariable, List<LinkConstr>> neighborMap = new HashMap<ElementVariable, List<LinkConstr>>();
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			ElementVariable source = lc.getSource();
			ElementVariable target = lc.getTarget();
			
			List<LinkConstr> sourceLinkConstrs = (neighborMap.containsKey(source)) ?
					neighborMap.get(source) : new ArrayList<LinkConstr>();
			sourceLinkConstrs.add(lc);
			neighborMap.put(source, sourceLinkConstrs);
			
			List<LinkConstr> targetLinkConstrs = (neighborMap.containsKey(target)) ?
					neighborMap.get(target) : new ArrayList<LinkConstr>();
			targetLinkConstrs.add(lc);
			neighborMap.put(target, targetLinkConstrs);
		}
		
		/*
		 * Iterate over all possible NODE variable sequences
		 */
		List<List<NodeConstr>> permutations = getPossibleNodePermutations(pattern.getNodeConstrs());
		int optimal_efficiency_index = 0;
		int right_sequence = 0;
		// iterate over possible sequences
		for (int i = 0; i < permutations.size(); i++) {
			List<NodeConstr> sequence = permutations.get(i);
			
			Set<ElementVariable> visited = new HashSet<ElementVariable>();
			Map<ElementVariable, Map<PropConstr, List<Comparison>>> postBox = 
				new HashMap<ElementVariable, Map<PropConstr,List<Comparison>>>();
			
			int efficiency_index = 0;
			
			// iterate over NodeConstrs
			for (int j = 0; j < sequence.size(); j++) {
				NodeConstr nc = sequence.get(j);
				ElementVariable leftElemVar = nc.getElemVar();
				visited.add(leftElemVar);
				
				int neighborfactor = 0;		// number of neighbor constraints
				int constpropfactor = 0;	// number of comparisons with a constant value
				int varpropfactor = 0;		// number of comparisons with a variable value

				// (1.3) NodeConstr.neighborConstrs will be initialized 
				// based on the LinkConstrs of this Pattern.
				if (neighborMap.containsKey(leftElemVar)) {
					List<LinkConstr> linkConstrList = neighborMap.get(leftElemVar);
					for (LinkConstr lc : linkConstrList) {
						
						ElementVariable sourceElemVar = lc.getSource();
						ElementVariable targetElemVar = lc.getTarget();

						// identify which one is a neighbor to current node
						// one of them is current, and the other is a neighbor
						boolean outNeighbor = true;
						ElementVariable neighborElemVar = targetElemVar;
						if (targetElemVar.equals(leftElemVar)) {
							outNeighbor = false;
							neighborElemVar = sourceElemVar;
						}
						
						
						if (visited.contains(sourceElemVar) && visited.contains(targetElemVar)) {
							NeighborConstrs neighborConstrs = nc.getNeighborConstrs();
							neighborfactor++;
							if (lc.isUndefinedDirection()) {
								List<ElementVariable> neighbors = neighborConstrs.getNeighbors();
								neighbors.add(neighborElemVar);
								neighborConstrs.setNeighbors(neighbors);
							} else {
								if (outNeighbor) {
									List<ElementVariable> outNeighbors = neighborConstrs.getOutNeighbors();
									outNeighbors.add(neighborElemVar);
									neighborConstrs.setOutNeighbors(outNeighbors);
								} else {
									List<ElementVariable> inNeighbors = neighborConstrs.getInNeighbors();
									inNeighbors.add(neighborElemVar);
									neighborConstrs.setInNeighbors(inNeighbors);
								}
							}
							nc.setNeighborConstrs(neighborConstrs);
						}
					}
				}
				
				for (PropConstr pc : nc.getPropConstrs()) {

					// add comparisons from previous nodes if they exist
					if (postBox.containsKey(leftElemVar)) {
						Map<PropConstr, List<Comparison>> map = postBox.get(leftElemVar);
						if (map.containsKey(pc)) {
							List<Comparison> list = map.get(pc);
							
							List<Comparison> initialComps = pc.getComparisons();
							initialComps.addAll(list);
							pc.setComparisons(initialComps);
						}
					}
					
					// (1.2) Comparisons with nodes later in the sequence 
					// will be inverted and moved to that later node.
					for (Comparison c : pc.getComparisons()) {
						if (c instanceof VariableComparison) {
							VariableComparison varComp = (VariableComparison) c;
							PropertyVariable rightExpr = varComp.getRightExpr();
							ElementVariable rightElemVar = rightExpr.getElementVar();
							if (!visited.contains(rightElemVar)) {
								Map<PropConstr, List<Comparison>> map = (postBox.containsKey(rightElemVar)) ? 
										postBox.get(rightElemVar) : new HashMap<PropConstr, List<Comparison>>();
								List<Comparison> list = (map.containsKey(pc)) ?
										map.get(pc) : new ArrayList<Comparison>();
								list.add(varComp.getInverse());
								map.put(pc, list);
							}
							
							// increase the number of comparison 
							varpropfactor++;
						} else {
							constpropfactor++;
						}
					}
				}
				int constrfactor = a*neighborfactor + b*constpropfactor + c*varpropfactor;
				efficiency_index += Math.pow(0.5, j) * constrfactor;
			}
			
			if (efficiency_index > optimal_efficiency_index) {
				optimal_efficiency_index = efficiency_index;
				right_sequence = i;
			}
			
		}
		
		/*
		 * (3) Based on the computations create a new Pattern instance.
		 */
		List<NodeConstr> rightOrder = permutations.get(right_sequence);
		pattern.setNodeConstrs(rightOrder);
	}

	/**
	 * Reorder Pattern.linkConstrs in an “optimal” order
	 */
	private void reorderLinks(Pattern pattern) {
		/*
		 * Iterate over all possible LINK variable sequences
		 */
		List<List<LinkConstr>> permutations = getPossibleLinkPermutations(pattern.getLinkConstrs());
		int optimal_efficiency_index = 0;
		int right_sequence = 0;
		// iterate over possible sequences
		for (int i = 0; i < permutations.size(); i++) {
			List<LinkConstr> sequence = permutations.get(i);
			
			Set<ElementVariable> visited = new HashSet<ElementVariable>();
			Map<ElementVariable, Map<PropConstr, List<Comparison>>> postBox = 
				new HashMap<ElementVariable, Map<PropConstr,List<Comparison>>>();
			
			int efficiency_index = 0;
			
			// iterate over NodeConstrs
			for (int j = 0; j < sequence.size(); j++) {
				LinkConstr lc = sequence.get(j);
				ElementVariable leftElemVar = lc.getElemVar();
				visited.add(leftElemVar);
				
				int neighborfactor = 0;		// number of neighbor constraints
				int constpropfactor = 0;	// number of comparisons with a constant value
				int varpropfactor = 0;		// number of comparisons with a variable value

				for (PropConstr pc : lc.getPropConstrs()) {

					// add comparisons from previous links if they exist
					if (postBox.containsKey(leftElemVar)) {
						Map<PropConstr, List<Comparison>> map = postBox.get(leftElemVar);
						if (map.containsKey(pc)) {
							List<Comparison> list = map.get(pc);
							
							List<Comparison> initialComps = pc.getComparisons();
							initialComps.addAll(list);
							pc.setComparisons(initialComps);
						}
					}
					
					// (1.2) Comparisons with links later in the sequence 
					// will be inverted and moved to that later link.
					for (Comparison c : pc.getComparisons()) {
						if (c instanceof VariableComparison) {
							VariableComparison varComp = (VariableComparison) c;
							PropertyVariable rightExpr = varComp.getRightExpr();
							ElementVariable rightElemVar = rightExpr.getElementVar();
							if (!visited.contains(rightElemVar)) {
								Map<PropConstr, List<Comparison>> map = (postBox.containsKey(rightElemVar)) ? 
										postBox.get(rightElemVar) : new HashMap<PropConstr, List<Comparison>>();
								List<Comparison> list = (map.containsKey(pc)) ?
										map.get(pc) : new ArrayList<Comparison>();
								list.add(varComp.getInverse());
								map.put(pc, list);
							}
							
							// increase the number of comparison 
							varpropfactor++;
						} else {
							constpropfactor++;
						}
					}
				}
				int constrfactor = a*neighborfactor + b*constpropfactor + c*varpropfactor;
				efficiency_index += Math.pow(0.5, j) * constrfactor;
			}
			
			if (efficiency_index > optimal_efficiency_index) {
				optimal_efficiency_index = efficiency_index;
				right_sequence = i;
			}
			
		}
		
		/*
		 * (3) Based on the computations create a new Pattern instance.
		 */
		List<LinkConstr> rightOrder = permutations.get(right_sequence);
		pattern.setLinkConstrs(rightOrder);
	}

	private void fillInSupplementalFields(Pattern pattern, Ontology ontology) {
		pattern.setOntology(ontology);

		/**
		 * ElementVariable.possibleTypes
		 */
		Set<String> nodeTypes = ontology.getNodeTypes();
		Map<String, NodeDescr> nodeDescriptions = ontology.getNodeDescriptions();
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			Set<String> temp = nodeTypes;

			ElementVariable elemVar = nc.getElemVar();
			List<Comparison> comparisons = nc.getTypeComparisons();
			for (Comparison c : comparisons) {
				if (c instanceof String2ConstStringComparison) {
					String2ConstStringComparison comparison = (String2ConstStringComparison) c;
					String rightExpr = comparison.getRightExpr();
					String2StringOperator operator = comparison.getOperator();
					if (operator.equals(String2StringOperator.EQUAL)) {
						temp.add(rightExpr);
					} else if (operator.equals(String2StringOperator.NOT_EQUAL)) {
						temp.remove(rightExpr);
					}
					
				} else if (c instanceof String2ConstSetComparison) {
					String2ConstSetComparison comparison = (String2ConstSetComparison) c;
					List<String> rightExpr = comparison.getRightExpr();
					String2SetOperator operator = comparison.getOperator();
					if (operator.equals(String2SetOperator.IN)) {
						for (String s : rightExpr) {
							temp.add(s);
						}
					} else if (operator.equals(String2SetOperator.NOT_IN)) {
						for (String s : rightExpr) {
							temp.remove(s);
						}
					}
				}					

			}
			
			List<ElementDescr> possibleTypes = new ArrayList<ElementDescr>();
			for (String nodeType : temp) {
				if (nodeDescriptions.containsKey(nodeType)) {
					NodeDescr nodeDescr = nodeDescriptions.get(nodeType);
					possibleTypes.add(nodeDescr);
				}
			}
			elemVar.setPossibleTypes(possibleTypes);
		}
		
		Set<String> linkTypes = ontology.getLinkTypes();
		HashMap<String,LinkDescr> linkDescriptions = ontology.getLinkDescriptions();
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			Set<String> temp = linkTypes;

			ElementVariable elemVar = lc.getElemVar();
			List<Comparison> comparisons = lc.getTypeComparisons();
			for (Comparison c : comparisons) {
				if (c instanceof String2ConstStringComparison) {
					String2ConstStringComparison comparison = (String2ConstStringComparison) c;
					String rightExpr = comparison.getRightExpr();
					String2StringOperator operator = comparison.getOperator();
					if (operator.equals(String2StringOperator.EQUAL)) {
						temp.add(rightExpr);
					} else if (operator.equals(String2StringOperator.NOT_EQUAL)) {
						temp.remove(rightExpr);
					}
					
				} else if (c instanceof String2ConstSetComparison) {
					String2ConstSetComparison comparison = (String2ConstSetComparison) c;
					List<String> rightExpr = comparison.getRightExpr();
					String2SetOperator operator = comparison.getOperator();
					if (operator.equals(String2SetOperator.IN)) {
						for (String s : rightExpr) {
							temp.add(s);
						}
					} else if (operator.equals(String2SetOperator.NOT_IN)) {
						for (String s : rightExpr) {
							temp.remove(s);
						}
					}
				}					

			}
			
			List<ElementDescr> possibleTypes = new ArrayList<ElementDescr>();
			for (String linkType : temp) {
				if (linkDescriptions.containsKey(linkType)) {
					LinkDescr linkDescr = linkDescriptions.get(linkType);
					possibleTypes.add(linkDescr);
				}
			}
			elemVar.setPossibleTypes(possibleTypes);
		}
		
		/**
		 * TODO ElementVariable.standardProps
		 */
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			ElementVariable elemVar = nc.getElemVar();
			elemVar.setStandardProps(ontology.getStandardProps());
		}
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			ElementVariable elemVar = lc.getElemVar();
			elemVar.setStandardProps(ontology.getStandardProps());
		}
		
		/**
		 * ElementVariable.nonStandardProps
		 */
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			ElementVariable elemVar = nc.getElemVar();
			List<ElementDescr> possibleTypes = elemVar.getPossibleTypes();
			Set<NonStandardPropDescr> tempSet = new HashSet<NonStandardPropDescr>();
			List<NonStandardPropDescr> tempList = new ArrayList<NonStandardPropDescr>();
			for (ElementDescr ed : possibleTypes) {
				List<NonStandardPropDescr> nonStandardProps = ed.getNonStandardProps();
				for (NonStandardPropDescr descr : nonStandardProps) {
					if (tempSet.contains(descr)) {
						tempList.add(descr);
					}
					tempSet.add(descr);
				}
			}
			elemVar.setNonStandardProps(tempList);
		}
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			ElementVariable elemVar = lc.getElemVar();
			List<ElementDescr> possibleTypes = elemVar.getPossibleTypes();
			Set<NonStandardPropDescr> tempSet = new HashSet<NonStandardPropDescr>();
			List<NonStandardPropDescr> tempList = new ArrayList<NonStandardPropDescr>();
			for (ElementDescr ed : possibleTypes) {
				List<NonStandardPropDescr> nonStandardProps = ed.getNonStandardProps();
				for (NonStandardPropDescr descr : nonStandardProps) {
					if (tempSet.contains(descr)) {
						tempList.add(descr);
					}
					tempSet.add(descr);
				}
			}
			elemVar.setNonStandardProps(tempList);
		}
		
		/**
		 * PropertyVariable.prop
		 * - Retrieve from the Ontology, based on propID and elementVar.
		 */
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			for (PropConstr pc : nc.getPropConstrs()) {
				PropertyVariable propVar = pc.getPropVar();
				String propId = propVar.getPropId();
				PropDescr prop = propVar.getElementVar().getProperty(propId);
				
				propVar.setProp(prop);
			}
		}
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			for (PropConstr pc : lc.getPropConstrs()) {
				PropertyVariable propVar = pc.getPropVar();
				String propId = propVar.getPropId();
				PropDescr prop = propVar.getElementVar().getProperty(propId);
				
				propVar.setProp(prop);
			}
		}
		
		/**
		 * Comparison.id
		 */
		int comparison_id = 0;
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			for (PropConstr pc : nc.getPropConstrs()) {
				for (Comparison c : pc.getComparisons()) {
					c.setId(comparison_id++);
				}
			}
		}
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			for (PropConstr pc : lc.getPropConstrs()) {
				for (Comparison c : pc.getComparisons()) {
					c.setId(comparison_id++);
				}
			}
		}

		/**
		 * Comparison.type
		 */
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			for (PropConstr pc : nc.getPropConstrs()) {
				PropertyVariable propVar = pc.getPropVar();
				for (Comparison c : pc.getComparisons()) {
					if (c instanceof VariableComparison) {
						VariableComparison vc = (VariableComparison) c;
						PropertyVariable rightPropVar = vc.getRightExpr();
	
						if (propVar.equals(rightPropVar))
							c.setType(ComparisonType.INTERNAL);
						else
							c.setType(ComparisonType.EXTERNAL);
					} else {
						c.setType(ComparisonType.INTERNAL);
					}
				}
			}
		}
		for (NodeConstr lc : pattern.getNodeConstrs()) {
			for (PropConstr pc : lc.getPropConstrs()) {
				PropertyVariable propVar = pc.getPropVar();
				for (Comparison c : pc.getComparisons()) {
					if (c instanceof VariableComparison) {
						VariableComparison vc = (VariableComparison) c;
						PropertyVariable rightPropVar = vc.getRightExpr();
	
						if (propVar.equals(rightPropVar))
							c.setType(ComparisonType.INTERNAL);
						else
							c.setType(ComparisonType.EXTERNAL);
					} else {
						c.setType(ComparisonType.INTERNAL);
					}
				}
			}
		}
		
		/**
		 * ElementConstr.bin2propVars2Comparisons
		 */
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			Map<Bin, Map<PropertyVariable, List<Comparison>>> binMap = new HashMap<Bin, Map<PropertyVariable, List<Comparison>>>();
			for (PropConstr pc : nc.getPropConstrs()) {
				PropertyVariable propVar = pc.getPropVar();
				PropDescr leftPropDescr = propVar.getProp();
				
				for (Comparison c : pc.getComparisons()) {
					if (leftPropDescr.isInJessElementFact()) {
						// leftExprPropDescr is Std
						
						if (c instanceof VariableComparison) {
							// Variable comparisons
							
							VariableComparison varComp = (VariableComparison) c;
							PropertyVariable rightExpr = varComp.getRightExpr();
							PropDescr rightPropDescr = rightExpr.getProp();
							if (rightPropDescr.isInJessElementFact()) {
								// Std - Std
								
								if (c instanceof Num2VarNumComparison || c instanceof String2VarStringComparison) {
									// scalar - scalar (2:1)
									addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
								} else if (c instanceof String2VarSetComparison) {
									// scalar - set (5:1)
									String2VarSetComparison comparison = (String2VarSetComparison) c;
									String2SetOperator operator = comparison.getOperator();
									if ( operator.equals(String2SetOperator.IN) || operator.equals(String2SetOperator.NOT_IN)) {
										addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
									}
									
								} else if (c instanceof Set2VarStringComparison) {
									// set - scalar (2:3)
									Set2VarStringComparison comparison = (Set2VarStringComparison) c;
									Set2StringOperator operator = comparison.getOperator();
									if (operator.equals(Set2StringOperator.CONTAINS) || operator.equals(Set2StringOperator.NOT_CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
									}
									
								} else if (c instanceof Set2VarSetComparison) {
									// set - set (5:3)
									Set2VarSetComparison comparison = (Set2VarSetComparison) c;
									Set2SetOperator operator = comparison.getOperator();
									// Set2SetOperator.EQUAL & Set2SetOperator.NOT_EQUAL are not included
									// they are not in documentation
									if (operator.equals(Set2SetOperator.INTERSECT) ||
											operator.equals(Set2SetOperator.NOT_INTERSECT) ||
											operator.equals(Set2SetOperator.SUBSET) ||
											operator.equals(Set2SetOperator.NOT_SUBSET) ||
											operator.equals(Set2SetOperator.SUPERSET) ||
											operator.equals(Set2SetOperator.NOT_SUPERSET) )
									{
										addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
									}
									
								}
							} else {
								// Std - NonStd
								
								if (c instanceof Num2VarNumComparison || c instanceof String2VarStringComparison) {
									// scalar - scalar (3:1)
									addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
								} else if (c instanceof String2VarSetComparison) {
									// scalar - set (6:1)
									String2VarSetComparison comparison = (String2VarSetComparison) c;
									String2SetOperator operator = comparison.getOperator();
									
									Bin bin = null;
									if (operator.equals(String2SetOperator.IN)) 			{ bin = Bin.BIN_5; }
									else if (operator.equals(String2SetOperator.NOT_IN)) 	{ bin = Bin.BIN_6; }
									
									addComparisonToBin(c, bin, binMap, propVar);
								} else if (c instanceof Set2VarStringComparison) {
									// set - scalar (3:3)
									Set2VarStringComparison comparison = (Set2VarStringComparison) c;
									Set2StringOperator operator = comparison.getOperator();
									if (operator.equals(Set2StringOperator.CONTAINS) || operator.equals(Set2StringOperator.NOT_CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
									}
								} else if (c instanceof Set2VarSetComparison) {
									// set - set (6:3)
									Set2VarSetComparison comparison = (Set2VarSetComparison) c;
									Set2SetOperator operator = comparison.getOperator();
									Bin bin = null;
									if (operator.equals(Set2SetOperator.INTERSECT))				{ bin = Bin.BIN_14; }
									else if (operator.equals(Set2SetOperator.NOT_INTERSECT))	{ bin = Bin.BIN_15; }
									else if (operator.equals(Set2SetOperator.SUBSET))			{ bin = Bin.BIN_16; }
									else if (operator.equals(Set2SetOperator.NOT_SUBSET))		{ bin = Bin.BIN_13; }
									else if (operator.equals(Set2SetOperator.SUPERSET))			{ bin = Bin.BIN_6; }
									else if (operator.equals(Set2SetOperator.NOT_SUPERSET))		{ bin = Bin.BIN_5; }
									
									addComparisonToBin(c, bin, binMap, propVar);
								}
							}
						} else {
							// Constant comparisons
							// Std - const
							
							if (c instanceof Num2ConstNumComparison || c instanceof String2ConstStringComparison) {
								// scalar - scalar (1:1)
								addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
							} else if (c instanceof String2ConstSetComparison) {
								// scalar - set (4:1)
								String2ConstSetComparison comparison = (String2ConstSetComparison) c;
								String2SetOperator operator = comparison.getOperator();
								if (operator.equals(String2SetOperator.IN) || operator.equals(String2SetOperator.NOT_IN)) {
									addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
								}
							} else if (c instanceof Set2ConstStringComparison) {
								// set - scalar (1:3)
								Set2ConstStringComparison comparison = (Set2ConstStringComparison) c;
								Set2StringOperator operator = comparison.getOperator();
								if (operator.equals(Set2StringOperator.CONTAINS) || operator.equals(Set2StringOperator.NOT_CONTAINS)) {
									addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
								}
							} else if (c instanceof Set2ConstSetComparison) {
								// set - set (4:3)
								Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
								Set2SetOperator operator = comparison.getOperator();
								if (operator.equals(Set2SetOperator.INTERSECT) ||
										operator.equals(Set2SetOperator.NOT_INTERSECT) ||
										operator.equals(Set2SetOperator.SUBSET) ||
										operator.equals(Set2SetOperator.NOT_SUBSET) ||
										operator.equals(Set2SetOperator.SUPERSET) ||
										operator.equals(Set2SetOperator.NOT_SUPERSET)) {
									addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
								}
							}
						}
//					} else if (leftPropDescr instanceof NonStandardPropDescr) {
					} else {
						// leftExprPropDescr is NonStd
						if (c instanceof VariableComparison) {
							// Variable comparisons
							
							VariableComparison varComp = (VariableComparison) c;
							PropertyVariable rightExpr = varComp.getRightExpr();
							PropDescr rightPropDescr = rightExpr.getProp();
							if (rightPropDescr.isInJessElementFact()) {
								// NonStd - Std
								
								if (c instanceof Num2VarNumComparison || c instanceof String2VarStringComparison) {
									// scalar - scalar (2:2)
									addComparisonToBin(c, Bin.BIN_2, binMap, propVar);
									
								} else if (c instanceof String2VarSetComparison) {
									// scalar - set (5:2)
									String2VarSetComparison comparison = (String2VarSetComparison) c;
									String2SetOperator operator = comparison.getOperator();
									if (operator.equals(String2SetOperator.IN) || operator.equals(String2SetOperator.NOT_IN)) {
										addComparisonToBin(c, Bin.BIN_2, binMap, propVar);
									}
									
								} else if (c instanceof Set2VarStringComparison) {
									// set - scalar (2:4)
									Set2VarStringComparison comparison = (Set2VarStringComparison) c;
									Set2StringOperator operator = comparison.getOperator();
									if (operator.equals(Set2StringOperator.CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_3, binMap, propVar);
									} else if (operator.equals(Set2StringOperator.NOT_CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_4, binMap, propVar);
									}
									
								} else if (c instanceof Set2VarSetComparison) {
									// set - set (5:4)
									Set2VarSetComparison comparison = (Set2VarSetComparison) c;
									Set2SetOperator operator = comparison.getOperator();
									if (operator.equals(Set2SetOperator.INTERSECT) || operator.equals(Set2SetOperator.NOT_SUBSET)) {
										addComparisonToBin(c, Bin.BIN_3, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.NOT_INTERSECT) || operator.equals(Set2SetOperator.SUBSET)) {
										addComparisonToBin(c, Bin.BIN_4, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.NOT_SUPERSET)) {
										addComparisonToBin(c, Bin.BIN_17, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.SUPERSET)) {
										addComparisonToBin(c, Bin.BIN_18, binMap, propVar);
									}
								}
							} else {
								// NonStd - NonStd
								
								if (c instanceof Num2VarNumComparison || c instanceof String2VarStringComparison) {
									// scalar - scalar (3:2)
									addComparisonToBin(c, Bin.BIN_2, binMap, propVar);
								} else if (c instanceof String2VarSetComparison) {
									// scalar - set (6:2)
									String2VarSetComparison comparison = (String2VarSetComparison) c;
									String2SetOperator operator = comparison.getOperator();
									if (operator.equals(String2SetOperator.IN)) {
										addComparisonToBin(c, Bin.BIN_5, binMap, propVar);
									} else if (operator.equals(String2SetOperator.NOT_IN)) {
										addComparisonToBin(c, Bin.BIN_6, binMap, propVar);
									}
								} else if (c instanceof Set2VarStringComparison) {
									// set - scalar (3:4)
									Set2VarStringComparison comparison = (Set2VarStringComparison) c;
									Set2StringOperator operator = comparison.getOperator();
									if (operator.equals(Set2StringOperator.CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_3, binMap, propVar);
									} else if (operator.equals(Set2StringOperator.NOT_CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_4, binMap, propVar);
									}
								} else if (c instanceof Set2VarSetComparison) {
									// set - set (6:4)
									Set2VarSetComparison comparison = (Set2VarSetComparison) c;
									Set2SetOperator operator = comparison.getOperator();
									if (operator.equals(Set2SetOperator.INTERSECT)) {
										addComparisonToBin(c, Bin.BIN_8, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.NOT_INTERSECT)) {
										addComparisonToBin(c, Bin.BIN_9, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.SUBSET)) {
										addComparisonToBin(c, Bin.BIN_10, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.NOT_SUBSET)) {
										addComparisonToBin(c, Bin.BIN_7, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.SUPERSET)) {
										addComparisonToBin(c, Bin.BIN_12, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.NOT_SUPERSET)) {
										addComparisonToBin(c, Bin.BIN_11, binMap, propVar);
									}
								}
							}
						} else {
							// Constant comparisons
							// NonStd - const
							
							if (c instanceof Num2ConstNumComparison || c instanceof String2ConstStringComparison) {
								// scalar - scalar (1:2)
								addComparisonToBin(c, Bin.BIN_2, binMap, propVar);
							} else if (c instanceof String2ConstSetComparison) {
								// scalar - set (4:2)
								String2ConstSetComparison comparison = (String2ConstSetComparison) c;
								String2SetOperator operator = comparison.getOperator();
								if (operator.equals(String2SetOperator.IN) || operator.equals(String2SetOperator.NOT_IN)) {
									addComparisonToBin(c, Bin.BIN_2, binMap, propVar);
								}
							} else if (c instanceof Set2ConstStringComparison) {
								// set - scalar (1:4)
								Set2ConstStringComparison comparison = (Set2ConstStringComparison) c;
								Set2StringOperator operator = comparison.getOperator();
								if (operator.equals(Set2StringOperator.CONTAINS)) {
									addComparisonToBin(c, Bin.BIN_3, binMap, propVar);
								} else if (operator.equals(Set2StringOperator.NOT_CONTAINS)) {
									addComparisonToBin(c, Bin.BIN_4, binMap, propVar);
								}
							} else if (c instanceof Set2ConstSetComparison) {
								// set - set (4:4)
								Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
								Set2SetOperator operator = comparison.getOperator();
								if (operator.equals(Set2SetOperator.INTERSECT) || operator.equals(Set2SetOperator.NOT_SUBSET)) {
									addComparisonToBin(c, Bin.BIN_3, binMap, propVar);
								} else if (operator.equals(Set2SetOperator.NOT_INTERSECT) || operator.equals(Set2SetOperator.SUBSET)) {
									addComparisonToBin(c, Bin.BIN_4, binMap, propVar);
								} else if (operator.equals(Set2SetOperator.NOT_SUPERSET)) {
									addComparisonToBin(c, Bin.BIN_20, binMap, propVar);
								} else if (operator.equals(Set2SetOperator.SUPERSET)) {
									addComparisonToBin(c, Bin.BIN_19, binMap, propVar);
								}
							}
						}						
					}
				}
			}
			nc.setBin2propVars2Comparisons(binMap);
		} // have set bin2propVars2Comparisons to each NodeConstr
		
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			Map<Bin, Map<PropertyVariable, List<Comparison>>> binMap = new HashMap<Bin, Map<PropertyVariable, List<Comparison>>>();
			for (PropConstr pc : lc.getPropConstrs()) {
				PropertyVariable propVar = pc.getPropVar();
				PropDescr leftPropDescr = propVar.getProp();
				
				for (Comparison c : pc.getComparisons()) {
					if (leftPropDescr.isInJessElementFact()) {
						// leftExprPropDescr is Std
						
						if (c instanceof VariableComparison) {
							// Variable comparisons
							
							VariableComparison varComp = (VariableComparison) c;
							PropertyVariable rightExpr = varComp.getRightExpr();
							PropDescr rightPropDescr = rightExpr.getProp();
							if (rightPropDescr.isInJessElementFact()) {
								// Std - Std
								
								if (c instanceof Num2VarNumComparison || c instanceof String2VarStringComparison) {
									// scalar - scalar (2:1)
									addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
								} else if (c instanceof String2VarSetComparison) {
									// scalar - set (5:1)
									String2VarSetComparison comparison = (String2VarSetComparison) c;
									String2SetOperator operator = comparison.getOperator();
									if ( operator.equals(String2SetOperator.IN) || operator.equals(String2SetOperator.NOT_IN)) {
										addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
									}
									
								} else if (c instanceof Set2VarStringComparison) {
									// set - scalar (2:3)
									Set2VarStringComparison comparison = (Set2VarStringComparison) c;
									Set2StringOperator operator = comparison.getOperator();
									if (operator.equals(Set2StringOperator.CONTAINS) || operator.equals(Set2StringOperator.NOT_CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
									}
									
								} else if (c instanceof Set2VarSetComparison) {
									// set - set (5:3)
									Set2VarSetComparison comparison = (Set2VarSetComparison) c;
									Set2SetOperator operator = comparison.getOperator();
									// Set2SetOperator.EQUAL & Set2SetOperator.NOT_EQUAL are not included
									// they are not in documentation
									if (operator.equals(Set2SetOperator.INTERSECT) ||
											operator.equals(Set2SetOperator.NOT_INTERSECT) ||
											operator.equals(Set2SetOperator.SUBSET) ||
											operator.equals(Set2SetOperator.NOT_SUBSET) ||
											operator.equals(Set2SetOperator.SUPERSET) ||
											operator.equals(Set2SetOperator.NOT_SUPERSET) )
									{
										addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
									}
									
								}
							} else {
								// Std - NonStd
								
								if (c instanceof Num2VarNumComparison || c instanceof String2VarStringComparison) {
									// scalar - scalar (3:1)
									addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
								} else if (c instanceof String2VarSetComparison) {
									// scalar - set (6:1)
									String2VarSetComparison comparison = (String2VarSetComparison) c;
									String2SetOperator operator = comparison.getOperator();
									
									Bin bin = null;
									if (operator.equals(String2SetOperator.IN)) 			{ bin = Bin.BIN_5; }
									else if (operator.equals(String2SetOperator.NOT_IN)) 	{ bin = Bin.BIN_6; }
									
									addComparisonToBin(c, bin, binMap, propVar);
								} else if (c instanceof Set2VarStringComparison) {
									// set - scalar (3:3)
									Set2VarStringComparison comparison = (Set2VarStringComparison) c;
									Set2StringOperator operator = comparison.getOperator();
									if (operator.equals(Set2StringOperator.CONTAINS) || operator.equals(Set2StringOperator.NOT_CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
									}
								} else if (c instanceof Set2VarSetComparison) {
									// set - set (6:3)
									Set2VarSetComparison comparison = (Set2VarSetComparison) c;
									Set2SetOperator operator = comparison.getOperator();
									Bin bin = null;
									if (operator.equals(Set2SetOperator.INTERSECT))				{ bin = Bin.BIN_14; }
									else if (operator.equals(Set2SetOperator.NOT_INTERSECT))	{ bin = Bin.BIN_15; }
									else if (operator.equals(Set2SetOperator.SUBSET))			{ bin = Bin.BIN_16; }
									else if (operator.equals(Set2SetOperator.NOT_SUBSET))		{ bin = Bin.BIN_13; }
									else if (operator.equals(Set2SetOperator.SUPERSET))			{ bin = Bin.BIN_6; }
									else if (operator.equals(Set2SetOperator.NOT_SUPERSET))		{ bin = Bin.BIN_5; }
									
									addComparisonToBin(c, bin, binMap, propVar);
								}
							}
						} else {
							// Constant comparisons
							// Std - const
							
							if (c instanceof Num2ConstNumComparison || c instanceof String2ConstStringComparison) {
								// scalar - scalar (1:1)
								addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
							} else if (c instanceof String2ConstSetComparison) {
								// scalar - set (4:1)
								String2ConstSetComparison comparison = (String2ConstSetComparison) c;
								String2SetOperator operator = comparison.getOperator();
								if (operator.equals(String2SetOperator.IN) || operator.equals(String2SetOperator.NOT_IN)) {
									addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
								}
							} else if (c instanceof Set2ConstStringComparison) {
								// set - scalar (1:3)
								Set2ConstStringComparison comparison = (Set2ConstStringComparison) c;
								Set2StringOperator operator = comparison.getOperator();
								if (operator.equals(Set2StringOperator.CONTAINS) || operator.equals(Set2StringOperator.NOT_CONTAINS)) {
									addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
								}
							} else if (c instanceof Set2ConstSetComparison) {
								// set - set (4:3)
								Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
								Set2SetOperator operator = comparison.getOperator();
								if (operator.equals(Set2SetOperator.INTERSECT) ||
										operator.equals(Set2SetOperator.NOT_INTERSECT) ||
										operator.equals(Set2SetOperator.SUBSET) ||
										operator.equals(Set2SetOperator.NOT_SUBSET) ||
										operator.equals(Set2SetOperator.SUPERSET) ||
										operator.equals(Set2SetOperator.NOT_SUPERSET)) {
									addComparisonToBin(c, Bin.BIN_1, binMap, propVar);
								}
							}
						}
//					} else if (leftPropDescr instanceof NonStandardPropDescr) {
					} else {
						// leftExprPropDescr is NonStd
						if (c instanceof VariableComparison) {
							// Variable comparisons
							
							VariableComparison varComp = (VariableComparison) c;
							PropertyVariable rightExpr = varComp.getRightExpr();
							PropDescr rightPropDescr = rightExpr.getProp();
							if (rightPropDescr.isInJessElementFact()) {
								// NonStd - Std
								
								if (c instanceof Num2VarNumComparison || c instanceof String2VarStringComparison) {
									// scalar - scalar (2:2)
									addComparisonToBin(c, Bin.BIN_2, binMap, propVar);
									
								} else if (c instanceof String2VarSetComparison) {
									// scalar - set (5:2)
									String2VarSetComparison comparison = (String2VarSetComparison) c;
									String2SetOperator operator = comparison.getOperator();
									if (operator.equals(String2SetOperator.IN) || operator.equals(String2SetOperator.NOT_IN)) {
										addComparisonToBin(c, Bin.BIN_2, binMap, propVar);
									}
									
								} else if (c instanceof Set2VarStringComparison) {
									// set - scalar (2:4)
									Set2VarStringComparison comparison = (Set2VarStringComparison) c;
									Set2StringOperator operator = comparison.getOperator();
									if (operator.equals(Set2StringOperator.CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_3, binMap, propVar);
									} else if (operator.equals(Set2StringOperator.NOT_CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_4, binMap, propVar);
									}
									
								} else if (c instanceof Set2VarSetComparison) {
									// set - set (5:4)
									Set2VarSetComparison comparison = (Set2VarSetComparison) c;
									Set2SetOperator operator = comparison.getOperator();
									if (operator.equals(Set2SetOperator.INTERSECT) || operator.equals(Set2SetOperator.NOT_SUBSET)) {
										addComparisonToBin(c, Bin.BIN_3, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.NOT_INTERSECT) || operator.equals(Set2SetOperator.SUBSET)) {
										addComparisonToBin(c, Bin.BIN_4, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.NOT_SUPERSET)) {
										addComparisonToBin(c, Bin.BIN_17, binMap, propVar);
									} else if (operator.equals(Set2SetOperator.SUPERSET)) {
										addComparisonToBin(c, Bin.BIN_18, binMap, propVar);
									}
								}
							} else {
								// NonStd - NonStd
								
								if (c instanceof Num2VarNumComparison || c instanceof String2VarStringComparison) {
									// scalar - scalar (3:2)
									addComparisonToBin(c, Bin.BIN_2, binMap, propVar);
								} else if (c instanceof String2VarSetComparison) {
									// scalar - set (6:2)
									String2VarSetComparison comparison = (String2VarSetComparison) c;
									String2SetOperator operator = comparison.getOperator();
									if (operator.equals(String2SetOperator.IN)) {
										addComparisonToBin(c, Bin.BIN_5, binMap, propVar);
									} else if (operator.equals(String2SetOperator.NOT_IN)) {
										addComparisonToBin(c, Bin.BIN_6, binMap, propVar);
									}
								} else if (c instanceof Set2VarStringComparison) {
									// set - scalar (3:4)
									Set2VarStringComparison comparison = (Set2VarStringComparison) c;
									Set2StringOperator operator = comparison.getOperator();
									if (operator.equals(Set2StringOperator.CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_3, binMap, propVar);
									} else if (operator.equals(Set2StringOperator.NOT_CONTAINS)) {
										addComparisonToBin(c, Bin.BIN_4, binMap, propVar);
									}
								} else if (c instanceof Set2VarSetComparison) {
									// set - set (6:4)
									Set2VarSetComparison comparison = (Set2VarSetComparison) c;
									Set2SetOperator operator = comparison.getOperator();
									if (operator.equals(Set2SetOperator.INTERSECT))				{ addComparisonToBin(c, Bin.BIN_8, binMap, propVar); }
									else if (operator.equals(Set2SetOperator.NOT_INTERSECT)) 	{ addComparisonToBin(c, Bin.BIN_9, binMap, propVar); }
									else if (operator.equals(Set2SetOperator.SUBSET)) 			{ addComparisonToBin(c, Bin.BIN_10, binMap, propVar); }
									else if (operator.equals(Set2SetOperator.NOT_SUBSET)) 		{ addComparisonToBin(c, Bin.BIN_7, binMap, propVar); }
									else if (operator.equals(Set2SetOperator.SUPERSET)) 		{ addComparisonToBin(c, Bin.BIN_12, binMap, propVar); }
									else if (operator.equals(Set2SetOperator.NOT_SUPERSET)) 	{ addComparisonToBin(c, Bin.BIN_11, binMap, propVar); }
								}
							}
						} else {
							// Constant comparisons
							// NonStd - const
							
							if (c instanceof Num2ConstNumComparison || c instanceof String2ConstStringComparison) {
								// scalar - scalar (1:2)
								addComparisonToBin(c, Bin.BIN_2, binMap, propVar);
							} else if (c instanceof String2ConstSetComparison) {
								// scalar - set (4:2)
								String2ConstSetComparison comparison = (String2ConstSetComparison) c;
								String2SetOperator operator = comparison.getOperator();
								if (operator.equals(String2SetOperator.IN) || operator.equals(String2SetOperator.NOT_IN)) {
									addComparisonToBin(c, Bin.BIN_2, binMap, propVar);
								}
							} else if (c instanceof Set2ConstStringComparison) {
								// set - scalar (1:4)
								Set2ConstStringComparison comparison = (Set2ConstStringComparison) c;
								Set2StringOperator operator = comparison.getOperator();
								if (operator.equals(Set2StringOperator.CONTAINS)) {
									addComparisonToBin(c, Bin.BIN_3, binMap, propVar);
								} else if (operator.equals(Set2StringOperator.NOT_CONTAINS)) {
									addComparisonToBin(c, Bin.BIN_4, binMap, propVar);
								}
							} else if (c instanceof Set2ConstSetComparison) {
								// set - set (4:4)
								Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
								Set2SetOperator operator = comparison.getOperator();
								if (operator.equals(Set2SetOperator.INTERSECT) || operator.equals(Set2SetOperator.NOT_SUBSET)) {
									addComparisonToBin(c, Bin.BIN_3, binMap, propVar);
								} else if (operator.equals(Set2SetOperator.NOT_INTERSECT) || operator.equals(Set2SetOperator.SUBSET)) {
									addComparisonToBin(c, Bin.BIN_4, binMap, propVar);
								} else if (operator.equals(Set2SetOperator.NOT_SUPERSET)) {
									addComparisonToBin(c, Bin.BIN_20, binMap, propVar);
								} else if (operator.equals(Set2SetOperator.SUPERSET)) {
									addComparisonToBin(c, Bin.BIN_19, binMap, propVar);
								}
							}
						}						
					}
				}
			}
			lc.setBin2propVars2Comparisons(binMap);
		} // have set bin2propVars2Comparisons to each LinkConstr
		
		
		/**
		 * NeighborConstrs.neighborsAddConstr
		 * NeighborConstrs.inNeighborsAddConstr
		 * NeighborConstrs.outNeighborsAddConstr
		 */
		Map<ElementVariable, List<ElementVariable>> neighbors = new HashMap<ElementVariable, List<ElementVariable>>();
		Map<ElementVariable, List<ElementVariable>> inNeighbors = new HashMap<ElementVariable, List<ElementVariable>>();
		Map<ElementVariable, List<ElementVariable>> outNeighbors = new HashMap<ElementVariable, List<ElementVariable>>();
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			ElementVariable source = lc.getSource();
			ElementVariable target = lc.getTarget();
			
			List<ElementVariable> list;
			if (lc.isUndefinedDirection()) {
				list = neighbors.get(source);
				if (!list.contains(target)) {
					list.add(target);
					neighbors.put(source, list);
				}
				
				list = neighbors.get(target);
				if (!list.contains(source)) {
					list.add(source);
					neighbors.put(target, list);
				}
			} else {
				list = outNeighbors.get(source);
				if (!list.contains(target)) {
					list.add(target);
					outNeighbors.put(source, list);
				}
				
				list = inNeighbors.get(target);
				if (!list.contains(source)) {
					list.add(source);
					inNeighbors.put(target, list);
				}
			}
				
		}
		List<NodeConstr> nodeConstrs = new ArrayList<NodeConstr>();
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			ElementVariable elemVar = nc.getElemVar();
			NeighborConstrs neighborConstrs = new NeighborConstrs();
			List<ElementVariable> neighborList = neighbors.get(elemVar);
			List<ElementVariable> inNeighborList = inNeighbors.get(elemVar);
			List<ElementVariable> outNeighborList = outNeighbors.get(elemVar);
			
			neighborConstrs.setNeighbors(neighborList);
			neighborConstrs.setInNeighbors(inNeighborList);
			neighborConstrs.setOutNeighbors(outNeighborList);
			
			nc.setNeighborConstrs(neighborConstrs);
			nodeConstrs.add(nc);
		}
		pattern.setNodeConstrs(nodeConstrs);
		
		
		/**
		 * Pattern.constantNumID2Values
		 * 
		 * Set2ConstSetComparison.rightExpr
		 */
		Map<Integer, List<String>> constantNumID2Values = new HashMap<Integer, List<String>>();
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			Map<Bin, Map<PropertyVariable, List<Comparison>>> bins = nc.getBin2propVars2Comparisons();
			Map<PropertyVariable, List<Comparison>> bin19 = bins.get(Bin.BIN_19);
			for (PropertyVariable key : bin19.keySet()) {
				List<Comparison> comparisons = bin19.get(key);
				for (Comparison c : comparisons) {
					Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
					List<String> rightExpr = comparison.getRightExpr();
					constantNumID2Values.put(c.getId(), rightExpr);
				}
			}
			Map<PropertyVariable, List<Comparison>> bin20 = bins.get(Bin.BIN_20);
			for (PropertyVariable key : bin20.keySet()) {
				List<Comparison> comparisons = bin19.get(key);
				for (Comparison c : comparisons) {
					Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
					List<String> rightExpr = comparison.getRightExpr();
					constantNumID2Values.put(c.getId(), rightExpr);
				}
			}
		}
		for (NodeConstr lc : pattern.getNodeConstrs()) {
			Map<Bin, Map<PropertyVariable, List<Comparison>>> bins = lc.getBin2propVars2Comparisons();
			Map<PropertyVariable, List<Comparison>> bin19 = bins.get(Bin.BIN_19);
			for (PropertyVariable key : bin19.keySet()) {
				List<Comparison> comparisons = bin19.get(key);
				for (Comparison c : comparisons) {
					Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
					List<String> rightExpr = comparison.getRightExpr();
					constantNumID2Values.put(c.getId(), rightExpr);
				}
			}
			Map<PropertyVariable, List<Comparison>> bin20 = bins.get(Bin.BIN_20);
			for (PropertyVariable key : bin20.keySet()) {
				List<Comparison> comparisons = bin19.get(key);
				for (Comparison c : comparisons) {
					Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
					List<String> rightExpr = comparison.getRightExpr();
					constantNumID2Values.put(c.getId(), rightExpr);
				}
			}
		}
		pattern.setConstantNumID2Values(constantNumID2Values);

		/**
		 * Set2ConstSetComparison.useJessConstantSetFact
		 */
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			for (PropConstr pc : nc.getPropConstrs()) {
				for (Comparison c : pc.getComparisons()) {
					if (c instanceof Set2ConstSetComparison && constantNumID2Values.containsKey(c.getId()))
					{
						Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
						comparison.setUseJessConstantSetFact(true);
					}
				}
			}
		}
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			for (PropConstr pc : lc.getPropConstrs()) {
				for (Comparison c : pc.getComparisons()) {
					if (c instanceof Set2ConstSetComparison && constantNumID2Values.containsKey(c.getId()))
					{
						Set2ConstSetComparison comparison = (Set2ConstSetComparison) c;
						comparison.setUseJessConstantSetFact(true);
					}
				}
			}
		}
		
		/**
		 * ElementVariable.prop2Comps2Vars
		 */
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			Map<PropDescr, Map<String, PropertyVariable>> prop2Comps2Vars = new HashMap<PropDescr, Map<String, PropertyVariable>>();
			ElementVariable elemVar = nc.getElemVar();
			for (StandardPropDescr standardPropDescr : elemVar.getStandardProps()) {
				Map<String, PropertyVariable> compId2PropVar = new HashMap<String, PropertyVariable>();
				for (String compID : standardPropDescr.getComponentIDs()) {
					PropertyVariable newPropVar = new PropertyVariable();
					compId2PropVar.put(compID, newPropVar);
				}
				prop2Comps2Vars.put(standardPropDescr, compId2PropVar);
			}
			for (NonStandardPropDescr nonStandardPropDescr : elemVar.getNonStandardProps()) {
				Map<String, PropertyVariable> compId2PropVar = new HashMap<String, PropertyVariable>();
				for (String compID : nonStandardPropDescr.getComponentIDs()) {
					PropertyVariable newPropVar = new PropertyVariable();
					compId2PropVar.put(compID, newPropVar);
				}
				prop2Comps2Vars.put(nonStandardPropDescr, compId2PropVar);
			}
			elemVar.setProp2Comps2Vars(prop2Comps2Vars);
		}
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			Map<PropDescr, Map<String, PropertyVariable>> prop2Comps2Vars = new HashMap<PropDescr, Map<String, PropertyVariable>>();
			ElementVariable elemVar = lc.getElemVar();
			for (StandardPropDescr standardPropDescr : elemVar.getStandardProps()) {
				Map<String, PropertyVariable> compId2PropVar = new HashMap<String, PropertyVariable>();
				for (String compID : standardPropDescr.getComponentIDs()) {
					PropertyVariable newPropVar = new PropertyVariable();
					compId2PropVar.put(compID, newPropVar);
				}
				prop2Comps2Vars.put(standardPropDescr, compId2PropVar);
			}
			for (NonStandardPropDescr nonStandardPropDescr : elemVar.getNonStandardProps()) {
				Map<String, PropertyVariable> compId2PropVar = new HashMap<String, PropertyVariable>();
				for (String compID : nonStandardPropDescr.getComponentIDs()) {
					PropertyVariable newPropVar = new PropertyVariable();
					compId2PropVar.put(compID, newPropVar);
				}
				prop2Comps2Vars.put(nonStandardPropDescr, compId2PropVar);
			}
			elemVar.setProp2Comps2Vars(prop2Comps2Vars);
		}

		/**
		 * ElementConstr.prop2CompsUsedAsReferenceValues
		 */
		for (NodeConstr nc : pattern.getNodeConstrs()) {
			Map<PropDescr, List<String>> prop2Comps = new HashMap<PropDescr, List<String>>();
			for (PropConstr pc : nc.getPropConstrs()) {
				for (Comparison c : pc.getComparisons()) {
					PropertyVariable leftExpr = c.getLeftExpr();
					PropDescr leftProp = leftExpr.getProp();
					List<String> leftCompIDs = leftProp.getComponentIDs();
					List<String> leftList = (prop2Comps.containsKey(leftProp)) ? 
							prop2Comps.get(leftProp) : new ArrayList<String>();
					leftList.addAll(leftCompIDs);
					prop2Comps.put(leftProp, leftList);
					
					if (c instanceof VariableComparison) {
						VariableComparison varComp = (VariableComparison) c;
						PropertyVariable rightExpr = varComp.getRightExpr();
						PropDescr rightProp = rightExpr.getProp();
						List<String> rightCompIDs = rightProp.getComponentIDs();
						List<String> rightList = (prop2Comps.containsKey(rightProp)) ? 
								prop2Comps.get(rightProp) : new ArrayList<String>();
						rightList.addAll(rightCompIDs);
						prop2Comps.put(rightProp, rightList);
					}
				}
			}
			nc.setProp2CompsUsedAsReferenceValues(prop2Comps);
		}
		for (LinkConstr lc : pattern.getLinkConstrs()) {
			Map<PropDescr, List<String>> prop2Comps = new HashMap<PropDescr, List<String>>();
			for (PropConstr pc : lc.getPropConstrs()) {
				for (Comparison c : pc.getComparisons()) {
					PropertyVariable leftExpr = c.getLeftExpr();
					PropDescr leftProp = leftExpr.getProp();
					List<String> leftCompIDs = leftProp.getComponentIDs();
					List<String> leftList = (prop2Comps.containsKey(leftProp)) ? 
							prop2Comps.get(leftProp) : new ArrayList<String>();
					leftList.addAll(leftCompIDs);
					prop2Comps.put(leftProp, leftList);
					
					if (c instanceof VariableComparison) {
						VariableComparison varComp = (VariableComparison) c;
						PropertyVariable rightExpr = varComp.getRightExpr();
						PropDescr rightProp = rightExpr.getProp();
						List<String> rightCompIDs = rightProp.getComponentIDs();
						List<String> rightList = (prop2Comps.containsKey(rightProp)) ? 
								prop2Comps.get(rightProp) : new ArrayList<String>();
						rightList.addAll(rightCompIDs);
						prop2Comps.put(rightProp, rightList);
					}
				}
			}
			lc.setProp2CompsUsedAsReferenceValues(prop2Comps);
		}
		

	}


	/**
	 * Add comparison to the specified bin (1..20)
	 * @param c			- comparison
	 * @param bin		- bin to put comparison in
	 * @param binMap
	 * @param propVar
	 */
	private void addComparisonToBin(Comparison c, Bin bin,
			Map<Bin, Map<PropertyVariable, List<Comparison>>> binMap,
			PropertyVariable propVar) {
		Map<PropertyVariable, List<Comparison>> propMap = (binMap.containsKey(bin)) ?
				binMap.get(bin) : new HashMap<PropertyVariable, List<Comparison>>();
		List<Comparison> list = propMap.containsKey(propVar) ? 
				propMap.get(propVar) : new ArrayList<Comparison>();
		list.add(c);
		propMap.put(propVar, list);
		binMap.put(bin, propMap);
	}
	
	private List<List<NodeConstr>> getPossibleNodePermutations(List<NodeConstr> nodeConstrs) {
		List<List<NodeConstr>> permuted = new ArrayList<List<NodeConstr>>();
		boolean used[] = new boolean[nodeConstrs.size()];
		List<NodeConstr> empty = new ArrayList<NodeConstr>();
		permuteNodes(0, empty, used, nodeConstrs, permuted);
		return permuted;
	}

	private void permuteNodes(int level, List<NodeConstr> list, boolean[] used,
			List<NodeConstr> original, List<List<NodeConstr>> result) {
		int length = original.size();
        if (level == length) {
        	List<NodeConstr> temp = new ArrayList<NodeConstr>();
        	temp.addAll(list);
        	result.add(temp);
        } else {
            for (int i = 0; i < length; i++) {
                if (!used[i]) {
                    used[i] = true;
                    list.add(original.get(i));
                    permuteNodes(level + 1, list,
                       used, original, result);
                    used[i] = false;
                    list.remove(list.size()-1);
                }
            }
        }
	}
	
	private List<List<LinkConstr>> getPossibleLinkPermutations(List<LinkConstr> linkConstrs) {
		List<List<LinkConstr>> permuted = new ArrayList<List<LinkConstr>>();
		boolean used[] = new boolean[linkConstrs.size()];
		List<LinkConstr> empty = new ArrayList<LinkConstr>();
		permuteLinks(0, empty, used, linkConstrs, permuted);
		return permuted;
	}

	private void permuteLinks(int level, List<LinkConstr> list, boolean[] used,
			List<LinkConstr> original, List<List<LinkConstr>> result) {
		int length = original.size();
		if (level == length) {
			List<LinkConstr> temp = new ArrayList<LinkConstr>();
			temp.addAll(list);
			result.add(temp);
		} else {
			for (int i = 0; i < length; i++) {
				if (!used[i]) {
					used[i] = true;
					list.add(original.get(i));
					permuteLinks(level + 1, list,
							used, original, result);
					used[i] = false;
					list.remove(list.size()-1);
				}
			}
		}
	}
}
