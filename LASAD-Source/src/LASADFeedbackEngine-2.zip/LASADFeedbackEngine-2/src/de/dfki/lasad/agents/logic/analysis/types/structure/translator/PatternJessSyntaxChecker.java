package de.dfki.lasad.agents.logic.analysis.types.structure.translator;

import java.io.Reader;
import java.io.StringReader;

import jess.Jesp;
import jess.JessException;
import jess.Rete;
import de.dfki.lasad.sessionmodel.SessionModelConfiguration;
import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.ontology.Ontology;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PatternJessSyntaxChecker {

	private static SessionModelConfiguration smConf = new SessionModelConfiguration();

	static {
		smConf.init();
	}

	public static boolean syntaxCorrect(String jessCode) throws Exception {

		String templates = smConf.getDatastructuresBasicBatch();
		Rete r = new Rete();
		parseExpression(r, templates);
		parseExpression(r, jessCode);

		try {
			// r.eval(templates);
			// r.eval(jessCode);
			parseExpression(r, templates);
			parseExpression(r, jessCode);
			return true;
		} catch (Exception e) {
			throw e;
		}

	}

	private static void parseExpression(Rete r, String expr) throws Exception {
		Reader reader = new StringReader(expr);
		Jesp j = new Jesp(reader, r);
		j.parse(false);
	}
}
