package de.dfki.lasad.events.eue;



/**
 * 
 * @author Oliver Scheuer
 *
 */
public interface EUEEventPublisher {

	public void subscribe(EUEEventListener listener);
	
}
