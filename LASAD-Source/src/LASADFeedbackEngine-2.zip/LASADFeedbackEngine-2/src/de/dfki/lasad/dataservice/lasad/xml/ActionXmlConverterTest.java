package de.dfki.lasad.dataservice.lasad.xml;

import de.uds.xml.XmlFragment;
import de.uds.xml.XmlFragmentInterface;
import junit.framework.TestCase;
import lasad.gwt.client.communication.objects.Parameter;

public class ActionXmlConverterTest extends TestCase{

	
	public void testParameterXmlConverter(){
		XmlFragment xmlFrag = (XmlFragment) XmlFragment.getFragmentFromString("<Parameter NAME=\"MapId\" VALUE=\"2\" />");
		Parameter p = ParameterXmlConverter.fromXml(xmlFrag);
		System.out.println(ParameterXmlConverter.toXml(p));
	}
	
	public void testActionPackageXmlConverter(){
		XmlFragment xmlFragment = (XmlFragment)XmlFragment.getFragmentFromFile("resources/xml/lasad/CreateQuestionBox.xml");
		System.out.println(ActionPackageXmlConverter.createFromXml(xmlFragment));
	}
}
