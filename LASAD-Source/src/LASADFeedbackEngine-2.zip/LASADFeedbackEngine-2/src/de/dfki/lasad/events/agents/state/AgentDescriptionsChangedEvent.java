package de.dfki.lasad.events.agents.state;

/**
 * Notification that the Feedback-Engine configuration has changed.
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescriptionsChangedEvent extends AFStateChangedEvent {

	public AgentDescriptionsChangedEvent(String srcCompId) {
		super(srcCompId);
	}
}
