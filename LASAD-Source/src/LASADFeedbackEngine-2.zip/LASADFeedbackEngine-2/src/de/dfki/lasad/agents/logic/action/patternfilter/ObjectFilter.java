package de.dfki.lasad.agents.logic.action.patternfilter;

import de.dfki.lasad.agents.data.analysis.object.ObjectResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class ObjectFilter {

	public abstract boolean keep(ObjectResult result);
}
