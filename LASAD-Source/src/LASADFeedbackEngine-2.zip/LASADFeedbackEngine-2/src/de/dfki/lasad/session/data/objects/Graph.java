package de.dfki.lasad.session.data.objects;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


public class Graph {

	private String graphId;
	private Map<EUEObjectID, Node> nodes = new HashMap<EUEObjectID, Node>();
	private Map<EUEObjectID, Link> links = new HashMap<EUEObjectID, Link>();

	public Graph() {
	}

	public String getGraphId() {
		return graphId;
	}

	public Map<EUEObjectID, Node> getNodemap() {
		return nodes;
	}

	public Map<EUEObjectID, Link> getEdgemap() {
		return links;
	}

	public Map<EUEObjectID, Link> getLinkmap() {
		return links;
	}

	public void setGraphId(String graphId) {
		this.graphId = graphId;
	}

	public Collection<Node> getNodes() {
		return nodes.values();
	}

	public Collection<Link> getLinks() {
		return links.values();
	}

	public void addNode(Node n) {
		nodes.put(n.getID(), n);
	}

	public void addLink(Link l) {
		links.put(l.getID(), l);
	}

	public Node getNode(EUEObjectID id) {
		return nodes.get(id);
	}

	public Link getEdge(EUEObjectID id) {
		return links.get(id);
	}

	public void removeNode(EUEObjectID id) {
		nodes.remove(id);
	}

	public void removeLink(EUEObjectID id) {
		links.remove(id);
	}

	/**
	 
	public void modifyNode(Node newNode) {
		if (nodes.containsKey(newNode.getID())) {
			Node n = nodes.get(newNode.getID());
			String lastmodifier = newNode.getProps().remove("modifier");
			String modificationdate = newNode.getProps().remove(
					"modificationdate");

			n.getProps().put("nodelastmodificator", lastmodifier);
			n.getProps().put("nodelastmodificationdate", modificationdate);

			n.getProps().putAll(newNode.getProps());
		}
	}

	public void modifyLink(Link newLink) {
		if (links.containsKey(newLink.getID())) {
			Link n = links.get(newLink.getID());
			String lastmodifier = newLink.getProps().remove("modifier");
			String modificationdate = newLink.getProps().remove(
					"modificationdate");

			n.getProps().put("nodelastmodificator", lastmodifier);
			n.getProps().put("nodelastmodificationdate", modificationdate);

			n.getProps().putAll(newLink.getProps());

		}

	}
**/

}
