package de.dfki.lasad.agents.logic.action.patternfilter;

import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.agents.instances.TaskScheduler;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ObjectFilter_LastModTimeMinAge extends ObjectFilter implements
		ObjectFilter_LastModTime {

	private long minAgeInMilliSecs;
	private TaskScheduler taskSchedulerRef;

	public ObjectFilter_LastModTimeMinAge(int minAgeInSecs,
			TaskScheduler taskSchedulerRef) {
		this.minAgeInMilliSecs = 1000L * minAgeInSecs;
		this.taskSchedulerRef = taskSchedulerRef;
	}

	@Override
	public boolean keep(ObjectResult oResult) {
		long objectAge = System.currentTimeMillis()
				- oResult.getLastModificationTime();
		if (objectAge < minAgeInMilliSecs) {
			long timerDelay = (minAgeInMilliSecs - objectAge) + 1;
			// check again when object enters relevant interval
			taskSchedulerRef.scheduleAnalysisTask(oResult, timerDelay);
			return false;
		} else {
			return true;
		}
	}

}
