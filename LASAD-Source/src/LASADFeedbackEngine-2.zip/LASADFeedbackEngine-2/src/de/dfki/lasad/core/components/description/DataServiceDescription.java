package de.dfki.lasad.core.components.description;

import de.dfki.lasad.core.components.configuration.IDataServiceConfiguration;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class DataServiceDescription extends AbstractComponentDescription {

	public DataServiceDescription(BasicDescription basicDesc) {
		super(basicDesc);
	}

	public IDataServiceConfiguration getConfiguration() {
		return (IDataServiceConfiguration) configuration;
	}

}
