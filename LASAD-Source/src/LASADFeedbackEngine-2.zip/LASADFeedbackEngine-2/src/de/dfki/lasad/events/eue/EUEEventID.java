package de.dfki.lasad.events.eue;

import de.dfki.lasad.session.data.EUEID;

public class EUEEventID extends EUEID {

	public EUEEventID(String id) {
		super(id);
	}
	
}
