package de.dfki.lasad.events.agents;



public interface ActionSpecEventListener {

	public void onActionSpecEvent(ActionSpecEvent event);
}
