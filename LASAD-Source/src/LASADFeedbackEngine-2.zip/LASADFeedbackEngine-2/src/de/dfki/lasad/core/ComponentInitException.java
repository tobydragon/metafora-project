package de.dfki.lasad.core;

/**
 * Indicates a failure to initialize or configure a system component.
 * 
 * @author Oliver Scheuer
 * 
 */
public class ComponentInitException extends Exception {

	private static final long serialVersionUID = 2353572826413787178L;

	public ComponentInitException(String message, Throwable cause) {
		super(message, cause);
	}

	public ComponentInitException(String message) {
		super(message);
	}
}
