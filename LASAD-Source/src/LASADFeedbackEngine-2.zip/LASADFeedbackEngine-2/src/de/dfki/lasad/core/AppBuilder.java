package de.dfki.lasad.core;

import javax.activation.MailcapCommandMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.session.SessionManager;

/**
 * Wiring logic: Components provided by a {@link IConfiguration} instance are
 * initialized and wired together at system initialization time.
 * 
 * @author Oliver Scheuer
 */
public class AppBuilder {

	private Log logger = LogFactory.getLog(AppBuilder.class);

	// run levels

	public static final String STOPPED = "STOPPED";

	/**
	 * System components are initialized, configured and registered at the
	 * {@link ServiceRegistry}.
	 */
	public static final String INITIALIZING = "INITIALIZING";

	/**
	 * Runtime connection between local system components is established (i.e.,
	 * components are wired together).
	 */
	public static final String WIRING = "WIRING";

	/**
	 * Session information is fetched from the remote counterpart of the
	 * {@link IDataService} and services prepared for each session.
	 */
	public static final String PREPARING_SERVICES = "PREPARING_SERVICES";

	/**
	 * Services are announced to remote counterpart of the {@link IDataService}
	 * and service is provided.
	 */
	public static final String PROVIDING_SERVICES = "PROVIDING_SERVICES";

	public static String current_runlevel = STOPPED;

	private ConfigurationManager confManager;
	private IDataService dataService;
	private SessionManager sessionManager;

	public AppBuilder() {
		current_runlevel = INITIALIZING;
		logger.info("Run level changed to: " + current_runlevel);

		registerXMLDataHandler();
		initConfigurationManager();
		initDataService();
		initSessionManager();

	}

	public void doWireAndStart() {
		try {
			doWire();
			sessionManager.startService();
			prepareAndStartDataService();
		} catch (Exception e) {
			logger.error("Error occurred", e);
		}
	}

	void doWire() {
		current_runlevel = WIRING;
		logger.info("Run level changed to: " + current_runlevel);

		dataService.doWire(sessionManager, confManager);
		sessionManager.doWire(dataService, confManager);
	}

	private void initConfigurationManager() {
		confManager = new ConfigurationManager();
		confManager.loadConf();
	}

	private void initDataService() {
		DataServiceDescription dataServiceDescription = confManager
				.getDSDescription();
		try {
			dataService = (IDataService) dataServiceDescription
					.createInstance(null);
		} catch (ComponentInitException e) {
			logger.error(e.getMessage(), e);
		}
	}

	private void initSessionManager() {
		sessionManager = new SessionManager();
	}

	private void prepareAndStartDataService() {
		current_runlevel = PROVIDING_SERVICES;
		logger.info("Run level changed to: " + current_runlevel);
		dataService.startService(null);
	}

	/**
	 * JRE 1.6 automatically registers an XML data handler for MIME type
	 * "text/xml", when publishing a WS, that throws an exception for all MIME
	 * types that do not exactly match one of the strings "text/xml" or
	 * "application/xml". The DeepLoop WS is based on AXIS2, which automatically
	 * uses "text/xml; charset=UTF-8" as MIME type, which leads to the exception
	 * described above. Therefore, we register the default XML data handler
	 * before the JAX-WS RI has a chance to register the non-functional XML data
	 * handler (the first programmatically registered data handler has
	 * priority).
	 */
	protected void registerXMLDataHandler() {
		MailcapCommandMap mailcapCommandMap = (MailcapCommandMap) MailcapCommandMap
				.getDefaultCommandMap();
		mailcapCommandMap
				.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
	}

	public IDataService getDataService() {
		return dataService;
	}

	public void setDataService(IDataService dataService) {
		this.dataService = dataService;
	}

}
