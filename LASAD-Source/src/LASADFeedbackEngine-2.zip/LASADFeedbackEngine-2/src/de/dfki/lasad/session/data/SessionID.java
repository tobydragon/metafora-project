package de.dfki.lasad.session.data;


public class SessionID extends EUEID {

	public SessionID(String id) {
		super(id);
	}

}
