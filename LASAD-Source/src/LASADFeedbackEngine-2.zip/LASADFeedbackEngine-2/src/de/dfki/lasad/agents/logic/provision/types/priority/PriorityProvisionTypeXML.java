package de.dfki.lasad.agents.logic.provision.types.priority;

import java.util.List;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.common.ActionListDef;
import lasad.shared.dfki.meta.agents.provision.ProvisionTimeDef;
import lasad.shared.dfki.meta.agents.provision.RecipientDef;
import lasad.shared.dfki.meta.agents.provision.priority.MsgFilterDef;
import lasad.shared.dfki.meta.agents.provision.priority.MsgSortCriterion;
import lasad.shared.dfki.meta.agents.provision.priority.PriorityProvisionType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import de.dfki.lasad.agents.logic.provision.actionfilter.xml.MsgFilterDefListXML;
import de.dfki.lasad.agents.logic.provision.actionsort.xml.MsgSortCriterionListXML;
import de.dfki.lasad.agents.logic.provision.types.ProvisionTypeXML;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PriorityProvisionTypeXML extends ProvisionTypeXML {

	private static Log logger = LogFactory
			.getLog(PriorityProvisionTypeXML.class);

	public static final String TYPE = "sort-and-filter";

	public static PriorityProvisionType fromXML(String agentID, Element provElem) {

		ServiceID serviceID = getServiceID(agentID, provElem);
		String name = getName(provElem);
		String description = getDescription(provElem);

		PriorityProvisionType provType = new PriorityProvisionType(serviceID);
		provType.setName(name);
		provType.setDescription(description);

		ActionListDef provActionsDef = getProvidedActions(agentID,
				provElem);
		provType.setProvidedActions(provActionsDef);

		ProvisionTimeDef provTimeDef = getProvisionTimeDef(provElem);
		provType.setProvisionTime(provTimeDef);

		RecipientDef recipientDef = getRecipientDef(provElem);
		provType.setRecipient(recipientDef);

		Element filterCriteriaElem = provElem
				.getChild(MsgFilterDefListXML.ELEMENT_NAME);
		if (filterCriteriaElem != null) {
			List<MsgFilterDef> msgFilterCriteria = MsgFilterDefListXML
					.fromXML(filterCriteriaElem);
			provType.setFilterCriteria(msgFilterCriteria);
		}

		Element sortCriteriaElem = provElem
				.getChild(MsgSortCriterionListXML.ELEMENT_NAME);
		if (sortCriteriaElem != null) {
			List<MsgSortCriterion> msgSortCriteria = MsgSortCriterionListXML
					.fromXML(sortCriteriaElem);
			provType.setSortCriteriaInOrder(msgSortCriteria);
		}

		Element maxNumElem = provElem.getChild("number-of-messages");
		int maxNumResults = getMaxNumResult(maxNumElem);
		provType.setMaxNumResults(maxNumResults);

		return provType;
	}

	protected static int getMaxNumResult(Element numberElem) {
		String allString = numberElem.getAttributeValue("all");
		boolean allResults = Boolean.valueOf(allString);
		if (allResults) {
			return PriorityProvisionType.ALL_RESULTS;
		} else {
			String numString = numberElem.getTextTrim();
			int num = Integer.parseInt(numString);
			return num;
		}
	}

	public static Element toXML(PriorityProvisionType provType) {

		Element provElem = createProvisionElement();
		addServiceIDAtt(provElem, provType);
		addServiceTypeAtt(provElem, TYPE);
		addNameElemIfNotNull(provElem, provType);
		addDescriptionElemIfNotNull(provElem, provType);

		ActionListDef provActionsDef = provType.getProvidedActions();
		addProvidedActionsElem(provElem, provActionsDef);

		ProvisionTimeDef provTimeDef = provType.getProvisionTime();
		addProvisionTimeDefElem(provElem, provTimeDef);

		RecipientDef recipientDef = provType.getRecipient();
		addRecipientDefElem(provElem, recipientDef);

		List<MsgSortCriterion> sortCriteria = provType.getSortCriteriaInOrder();
		addMsgSortCriteriaElem(provElem, sortCriteria);

		List<MsgFilterDef> filterCriteria = provType.getFilterDefs();
		addMsgFilterCriteriaElem(provElem, filterCriteria);

		int maxNumResults = provType.getMaxNumResults();
		addMaxNumResultsElem(provElem, maxNumResults);

		return provElem;
	}

	protected static Element getNumberElem(int maxNumResults) {
		Element numberElem = new Element("number-of-messages");
		if (maxNumResults == PriorityProvisionType.ALL_RESULTS) {
			numberElem.setAttribute("all", String.valueOf(true));
		} else {
			numberElem.setText(String.valueOf(maxNumResults));
		}
		return numberElem;
	}

	protected static void addMsgSortCriteriaElem(Element provElem,
			List<MsgSortCriterion> sortCriteria) {
		Element sortCriteriaElem = MsgSortCriterionListXML.toXML(sortCriteria);
		provElem.addContent(sortCriteriaElem);
	}

	protected static void addMsgFilterCriteriaElem(Element provElem,
			List<MsgFilterDef> filterCriteria) {
		Element filterCriteriaElem = MsgFilterDefListXML.toXML(filterCriteria);
		provElem.addContent(filterCriteriaElem);
	}

	protected static void addMaxNumResultsElem(Element provElem,
			int maxNumResults) {
		Element maxNumResultsElem = getNumberElem(maxNumResults);
		provElem.addContent(maxNumResultsElem);
	}
}
