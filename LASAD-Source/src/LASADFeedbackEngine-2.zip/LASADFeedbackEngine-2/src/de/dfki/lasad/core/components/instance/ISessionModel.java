package de.dfki.lasad.core.components.instance;

import de.dfki.lasad.agents.data.meta.RuleAnalysisType;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.session.SessionActiveRuntime;
import de.dfki.lasad.sessionmodel.graphmodel.GraphElement;

/**
 * Models the current state of a {@link Session} in terms of user-actions and
 * user-created objects within that {@link Session}. Model updates are triggered
 * based upon provided {@link EventImpl}s. Allows to add analysis rules (
 * {@link RuleAnalysisType}) to reason about the {@link Session} (e.g.,
 * identifying pattern in an argument graph).
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent})
 * 
 * @author oliverscheuer
 * 
 */
public interface ISessionModel extends IComponent {

	public void doWire(SessionActiveRuntime sessionRuntime);

	public abstract void registerAnalysisPattern(RuleAnalysisType p);

	public abstract void onEvent(Event event);

	public GraphElement getElement(String eueObjectId);

}