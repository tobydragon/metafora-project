package de.dfki.lasad.agents.logic.analysis.aggr.tasks;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.aggr.AggrService;
import de.dfki.lasad.agents.logic.analysis.aggr.CountableInstance;
import de.dfki.lasad.sessionmodel.SessionModelChangeRecord;

/**
 * Updates the {@link #manager}'s internal record of current workspace objects
 * (nodes, links, sub-elements) based on the given {@link actions}. Check all
 * counter conditions if the an analysis is currently NOT running. (If an
 * analysis IS running counter conditions will be checked anyway when the
 * analysis run is finished.)
 * 
 * @author oliverscheuer
 * 
 */
public class AggTask_UpdateCountersOnModelUpdate extends AggTask {

	private static Log logger = LogFactory
			.getLog(AggTask_UpdateCountersOnModelUpdate.class);

	private AggrService manager;
	private SessionModelChangeRecord changeRecord;

	public AggTask_UpdateCountersOnModelUpdate(AggrService manager,
			SessionModelChangeRecord changeRecord) {
		this.manager = manager;
		this.changeRecord = changeRecord;
	}

	@Override
	public void run() {
		logger.debug("Update counters on model update");
		Map<CountableInstance, Boolean> instances2isDeleted = manager
				.getInstances2IsDeleted(changeRecord);
		for (CountableInstance instance : instances2isDeleted.keySet()) {
			manager.processInstance(instance, instances2isDeleted.get(instance));
		}
		manager.checkConditionsAndNotify();
	}
}
