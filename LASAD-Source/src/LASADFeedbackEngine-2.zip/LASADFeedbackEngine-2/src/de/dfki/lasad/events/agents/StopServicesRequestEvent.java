package de.dfki.lasad.events.agents;

import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.session.data.SessionID;

/**
 * Request to stop feedback services in the EUE for a given session
 * 
 * @author oliverscheuer
 * 
 */
public class StopServicesRequestEvent extends SessionEvent {

	private SessionID sessionID;

	public StopServicesRequestEvent(SessionID sessionID, String srcCompId) {
		super(sessionID, srcCompId);
	}

	public SessionID getSessionID() {
		return sessionID;
	}

	public void setSessionID(SessionID sessionID) {
		this.sessionID = sessionID;
	}

}
