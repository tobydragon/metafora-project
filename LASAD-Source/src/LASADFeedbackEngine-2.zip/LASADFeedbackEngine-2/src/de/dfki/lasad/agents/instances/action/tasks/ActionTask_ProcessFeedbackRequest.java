package de.dfki.lasad.agents.instances.action.tasks;

import de.dfki.lasad.agents.instances.action.ActionAgent;
import de.dfki.lasad.agents.instances.action.UserServiceID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ActionTask_ProcessFeedbackRequest extends ActionTask {

	private ActionAgent agent = null;
	private UserServiceID userServiceID = null;

	public ActionTask_ProcessFeedbackRequest(ActionAgent agent,
			UserServiceID userServiceID) {
		this.agent = agent;
		this.userServiceID = userServiceID;
	}

	@Override
	public void run() {
		agent.processProvision(userServiceID);
	}
}
