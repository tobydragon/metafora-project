package de.dfki.lasad.core;

import junit.framework.TestCase;

/**
 * 
 * @author oliverscheuer
 *
 */
public class RuntimeConfigManagerTest  extends TestCase {

	public void testLoadRuntimeConf() {
		System.out.println("#### testLoadRuntimeConf() ####");
		RuntimeConfigManager rtManager = new RuntimeConfigManager();
		rtManager.loadRuntimeConf();
	}
}
