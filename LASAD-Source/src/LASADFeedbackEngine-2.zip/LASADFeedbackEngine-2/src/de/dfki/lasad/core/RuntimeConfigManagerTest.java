package de.dfki.lasad.core;

import de.dfki.lasad.core.components.collections.AgentRuntimeConfig;
import junit.framework.TestCase;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class RuntimeConfigManagerTest extends TestCase {

	public static RuntimeConfigManager rtManager = new RuntimeConfigManager();
	static {
		rtManager.setAgentRuntime(new AgentRuntimeConfig());
	}

	public void testLoadRuntimeConf() {
		System.out.println("#### testLoadRuntimeConf() ####");
		rtManager.loadRuntimeConf();
	}

	/**
	 * CHECK also file system whether config file is correct (i.e., mappings
	 * added)
	 */
	public void testAddAgent2SessionMapping() {
		System.out.println("#### testAddAgent2SessionMapping() ####");

		// change descriptions dir
		ConfigurationDatabaseAccessor.setRuntimeDir("resources-test-temp");
		ConfigurationDatabase.getRuntimeDir().mkdir();

		System.out
				.println("AgentRuntime in working memory BEFORE adding SESSION MAPPING: "
						+ rtManager.getAgentRuntime());
		rtManager.addAgent2SessionMapping("AGENT-1", "SESSION-1");
		rtManager.addAgent2SessionMapping("AGENT-1", "SESSION-2");
		rtManager.addAgent2SessionMapping("AGENT-1", "SESSION-3");
		rtManager.addAgent2SessionMapping("AGENT-2", "SESSION-1");
		rtManager.addAgent2SessionMapping("AGENT-3", "SESSION-2");
		System.out
				.println("AgentRuntime in working memory AFTER adding SESSION MAPPING: "
						+ rtManager.getAgentRuntime());
	}

	/**
	 * Depends on: testAddAgent2SessionMapping()
	 * 
	 * CHECK also file system whether config file is correct (i.e., mappings
	 * removed)
	 */
	public void testRemoveAgent2SessionMapping() {
		System.out.println("#### testRemoveAgent2SessionMapping() ####");
		testAddAgent2SessionMapping();

		System.out
				.println("AgentRuntime in working memory BEFORE remove SESSION MAPPING: "
						+ rtManager.getAgentRuntime());
		rtManager.removeAgent2SessionMapping("AGENT-1", "SESSION-1");
		rtManager.removeAgent2SessionMapping("AGENT-1", "SESSION-3");
		System.out
				.println("AgentRuntime in working memory AFTER remove SESSION MAPPING: "
						+ rtManager.getAgentRuntime());
	}

	/**
	 * CHECK also file system whether config file is correct (i.e., mappings
	 * added)
	 */
	public void testAddAgent2OntologyMapping() {
		System.out.println("#### testAddAgent2OntologyMapping() ####");

		// change descriptions dir
		ConfigurationDatabaseAccessor.setRuntimeDir("resources-test-temp");
		ConfigurationDatabase.getRuntimeDir().mkdir();

		System.out
				.println("AgentRuntime in working memory BEFORE adding ONTOLOGY MAPPING: "
						+ rtManager.getAgentRuntime());
		rtManager.addAgent2OntologyMapping("AGENT-1", "ONTO-1");
		rtManager.addAgent2OntologyMapping("AGENT-1", "ONTO-2");
		rtManager.addAgent2OntologyMapping("AGENT-1", "ONTO-3");
		rtManager.addAgent2OntologyMapping("AGENT-2", "ONTO-1");
		rtManager.addAgent2OntologyMapping("AGENT-3", "ONTO-2");
		System.out
				.println("AgentRuntime in working memory AFTER adding ONTOLOGY MAPPING: "
						+ rtManager.getAgentRuntime());
	}

	/**
	 * Depends on: testAddAgent2OntologyMapping()
	 * 
	 * CHECK also file system whether config file is correct (i.e., mappings
	 * removed)
	 */
	public void testRemoveAgent2OntologyMapping() {
		System.out.println("#### testRemoveAgent2OntologyMapping() ####");
		testAddAgent2OntologyMapping();

		System.out
				.println("AgentRuntime in working memory BEFORE remove ONTOLOGY MAPPING: "
						+ rtManager.getAgentRuntime());
		rtManager.removeAgent2OntologyMapping("AGENT-1", "ONTO-1");
		rtManager.removeAgent2OntologyMapping("AGENT-1", "ONTO-3");
		System.out
				.println("AgentRuntime in working memory AFTER remove ONTOLOGY MAPPING: "
						+ rtManager.getAgentRuntime());
	}

	/**
	 * Depends on: testAddAgent2SessionMapping(), testAddAgent2OntologyMapping()
	 * 
	 * CHECK also file system whether config file is correct (i.e., agents
	 * removed)
	 */
	public void testDeleteAgentRuntimeEntries() {
		System.out.println("#### testDeleteAgentRuntimeEntries() ####");
		testAddAgent2SessionMapping();
		testAddAgent2OntologyMapping();
		System.out
				.println("AgentRuntime in working memory BEFORE remove AGENT: "
						+ rtManager.getAgentRuntime());
		rtManager.deleteAgentRuntimeEntries("AGENT-1");
		System.out
				.println("AgentRuntime in working memory AFTER remove AGENT: "
						+ rtManager.getAgentRuntime());

	}
}
