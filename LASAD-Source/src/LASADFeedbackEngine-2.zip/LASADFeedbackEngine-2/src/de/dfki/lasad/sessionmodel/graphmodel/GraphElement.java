package de.dfki.lasad.sessionmodel.graphmodel;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.Map.Entry;

import org.apache.log4j.Logger;


import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.DeleteObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.dfki.lasad.session.data.EUEID;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;
import de.dfki.lasad.session.data.objects.ObjectProperty;
import de.uds.commonformat.CfObject;
import de.uds.commonformat.CfProperty;

public class GraphElement {
	Logger logger = Logger.getLogger(this.getClass());
	
	private EUEObject myEueObject;
	private CreateObjectEvent createEvent;
	private Vector<ModifyObjectEvent> modifyObjectEvents;
	private DeleteObjectEvent deleteObjectEvent;
	
	private Map <String, GraphElement> currentSubElements;
	private Map <String, GraphElement> deletedSubElements;
	
	private boolean deleted = false;
	
	String displayID;
	long lastModifiedTs;
	
	public GraphElement (EUEObject element, CreateObjectEvent createEvent, String displayID){
		this.myEueObject = element;
		this.createEvent = createEvent;
		this.displayID =displayID;
		lastModifiedTs = createEvent.getTs();
		
		currentSubElements = new Hashtable<String, GraphElement>();
		deletedSubElements = new Hashtable<String, GraphElement>();
		
		//modifiers can be found within these objects...
		modifyObjectEvents = new Vector<ModifyObjectEvent>();		
	}

	public void modify(ModifyObjectEvent modifyObjectEvent){
		//save modify event, update props
		modifyObjectEvents.add(modifyObjectEvent);
		if (modifyObjectEvent.getEueObjectList().size() != 1){
			logger.error("[modify] failed. EUE object list is expected to contain one object. Contains: " + modifyObjectEvent.getEueObjectList().size());
			return;
		}
		
		EUEObject newObject = modifyObjectEvent.getEueObjectList().get(0);
		
		for (ObjectProperty newProp : newObject.getProps().values()){
			ObjectProperty oldProp = myEueObject.getPropValue(newProp.getName());
			if (oldProp != null){
				myEueObject.removeProperty(oldProp);
				myEueObject.addProperty(newProp);
				logger.info("[modify] replaced prop: " + oldProp + " with : " + newProp);
			}
			else {
				myEueObject.addProperty(newProp);
				logger.info("[modify] No old prop found, new prop added: " + newProp);
			}
		}
		lastModifiedTs = modifyObjectEvent.getTs();
	}
	
	public void delete(DeleteObjectEvent deleteObjectEvent) {
		this.deleted = true;
		this.deleteObjectEvent = deleteObjectEvent;	
	}
	
	public void addSubElement(GraphElement subElement){
		currentSubElements.put(subElement.getId(), subElement);
	}
	
	public void modifySubElement(Node subElementNode, ModifyObjectEvent modifyObjectEvent){
		String key = subElementNode.getID().getIdAsString();
		GraphElement subElement = currentSubElements.get(key);
		subElement.modify(modifyObjectEvent);
		lastModifiedTs = modifyObjectEvent.getTs();
	}

	public void deleteSubElement(Node subElementNode, DeleteObjectEvent deleteSubElementEvent) {
		String key = subElementNode.getID().getIdAsString();
		GraphElement subElement = currentSubElements.get(key);
		subElement.delete(deleteSubElementEvent);
		deletedSubElements.put(key, subElement);
		currentSubElements.remove(key);
		lastModifiedTs = deleteSubElementEvent.getTs();
	}
	
/////////  getters  /////////////////////////
	
	public EUEObject getEueObject(){
		return myEueObject;
	}
	
	public String getId() {
		return myEueObject.getID().getIdAsString();
	}

	public String getDisplayID() {
		return displayID;
	}

	public String getType() {
		return myEueObject.getType();
	}

	public String getCreatorID() {
		return createEvent.getUserID().getIdAsString();
	}

	public long getCreationTs() {
		return createEvent.getTs();
	}

	public long getLastModifiedTs() {
		return lastModifiedTs;
	}
	
	public Collection<GraphElement> getSubElements(){
		return currentSubElements.values();
	}

	public boolean isDeleted() {
		return deleted;
	}
	
	public String toString(){
		String toString =  myEueObject.toXml().toString();
		for (GraphElement subElement : currentSubElements.values()){
			toString += "\n" + subElement.toString();
		}
		return toString;
	}
	
	public  CfObject translateToCfObject(){
		CfObject cfObject = new CfObject(getId(), getType());
		cfObject.addProperty(new CfProperty("TOOL", "LASAD"));
		
		Vector<CfProperty> props = new Vector<CfProperty>();
		buildFlatCfPropertyList(props, "");
		for (CfProperty prop : props){
			cfObject.addProperty(prop);
		}
		return cfObject;	
	}
	
	//recursive mutator
	public void buildFlatCfPropertyList(Vector<CfProperty> props, String prefix){

		//this elements props
		for (ObjectProperty objectProperty : myEueObject.getProps().values() ){
			if (includePropertyOnce(objectProperty.getName())){
				props.add(new CfProperty(objectProperty.getName(), objectProperty.getValueAsString()));
			}
			else if (includePropertyForEachInstance(objectProperty.getName())){
				props.add(new CfProperty(prefix + "-"+ objectProperty.getName(), objectProperty.getValueAsString()));
			}
		}
		
		if (myEueObject instanceof Link){
			Link link = (Link) myEueObject;
			for (EUEID sourceId : link.getSources()){
				props.add(new CfProperty("SOURCE_ID", sourceId.getIdAsString()));
			}
			for (EUEID targetId : link.getTargets()){
				props.add(new CfProperty("TARGET_ID", targetId.getIdAsString()));
			}
		}
		
		//sub-element props
		for (GraphElement subElement: currentSubElements.values()){
			subElement.buildFlatCfPropertyList(props, prefix + subElement.getType());
		}	
	}
	
	//returns true for all properties that should only be included in the flat list once
	public boolean includePropertyOnce(String name){
		List<String> props = Arrays.asList("USERNAME", "MAP-ID", "POS-X", "POS-Y", "groupId", "challengeId");
		for (String prop : props){
			if (name.equalsIgnoreCase(prop)){
				return true;
			}
		}
		return false;
	}
	
	//returns true for all properties that should only be included in the flat list once
	public boolean includePropertyForEachInstance(String name){
		List<String> props = Arrays.asList("TEXT", "MYCHECK", "SELECTION");
		for (String prop : props){
			if (name.equalsIgnoreCase(prop)){
				return true;
			}
		}
		return false;
	}
}
