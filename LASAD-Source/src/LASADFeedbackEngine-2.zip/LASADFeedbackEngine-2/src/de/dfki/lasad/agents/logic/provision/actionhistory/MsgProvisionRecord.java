package de.dfki.lasad.agents.logic.provision.actionhistory;

import lasad.shared.dfki.meta.agents.action.ActionType;
import de.dfki.lasad.agents.data.analysis.object.AnalyzableEntity;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgProvisionRecord {

	private UserID userID = null;
	private ActionType actionType = null;
	private AnalyzableEntity entity = null;
	private Long provisionTS = null;

	public MsgProvisionRecord(UserID userID, ActionType actionType,
			AnalyzableEntity entity, Long provisionTS) {
		this.userID = userID;
		this.actionType = actionType;
		this.entity = entity;
		this.provisionTS = provisionTS;
	}

	public UserID getUserID() {
		return userID;
	}

	public ActionType getActionType() {
		return actionType;
	}

	public AnalyzableEntity getEntity() {
		return entity;
	}

	public Long getProvisionTS() {
		return provisionTS;
	}

	@Override
	public String toString() {
		return "MsgProvisionRecord [userID=" + userID + ", actionType="
				+ actionType.getServiceID() + ", entity=" + entity
				+ ", provisionTS=" + provisionTS + "]";
	}

}
