package de.dfki.lasad.core.components.collections;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.session.Session;
import de.dfki.lasad.session.data.meta.Ontology;

/**
 * Configuration that specifies which {@link IAgent}s to assign to which
 * {@link Ontology}s and {@link Session}s.
 * 
 * @author oliverscheuer
 * 
 */
public class AgentRuntimeConfig {

	static Log logger = LogFactory.getLog(AgentRuntimeConfig.class);

	private List<String> sessionGeneralAgents = new Vector<String>();

	private List<String> sessionIDs = new Vector<String>();
	private Map<String, List<String>> sessionID2agentIDs = new HashMap<String, List<String>>();

	private List<String> ontologyIDs = new Vector<String>();
	private Map<String, List<String>> ontologyID2agentIDs = new HashMap<String, List<String>>();

	public void addAgent2Session(String agentID, String sessionID) {
		List<String> agentIDs = sessionID2agentIDs.get(sessionID);
		if (agentIDs == null) {
			agentIDs = new Vector<String>();
			sessionID2agentIDs.put(sessionID, agentIDs);
			sessionIDs.add(sessionID);
		}
		if (agentIDs.contains(agentID)) {
			return;
		}
		agentIDs.add(agentID);
	}

	public void addSessionGeneralAgent(String agentID) {
		this.sessionGeneralAgents.add(agentID);
	}

	public void addAgent2Ontology(String agentID, String ontologyID) {
		List<String> agentIDs = ontologyID2agentIDs.get(ontologyID);
		if (agentIDs == null) {
			agentIDs = new Vector<String>();
			ontologyID2agentIDs.put(ontologyID, agentIDs);
			ontologyIDs.add(ontologyID);
		}
		if (agentIDs.contains(agentID)) {
			return;
		}
		agentIDs.add(agentID);
	}

	public void removeAgent2SessionAssignment(String agentID, String sessionID) {
		List<String> agentIDs = sessionID2agentIDs.get(sessionID);
		if (agentIDs != null) {
			agentIDs.remove(agentID);
			if (agentIDs.isEmpty()) {
				sessionID2agentIDs.remove(sessionID);
				sessionIDs.remove(sessionID);
			}
		}
	}

	public void removeAgent2OntologyAssignment(String agentID, String ontologyID) {
		List<String> agentIDs = ontologyID2agentIDs.get(ontologyID);
		if (agentIDs != null) {
			agentIDs.remove(agentID);
			if (agentIDs.isEmpty()) {
				ontologyID2agentIDs.remove(ontologyID);
				ontologyIDs.remove(ontologyID);
			}
		}
	}

	public List<String> getSessionIDs() {
		return sessionIDs;
	}

	public List<String> getOntologyIDs() {
		return ontologyIDs;
	}

	public List<String> getSessionGeneralAgents() {
		return this.sessionGeneralAgents;
	}

	public List<String> getAgentsForSession(String sessionID) {
		if (sessionIDs.contains(sessionID)) {
			return sessionID2agentIDs.get(sessionID);
		}
		return new Vector<String>();
	}

	public List<String> getAgentsForOntology(String ontologyID) {
		if (ontologyIDs.contains(ontologyID)) {
			return ontologyID2agentIDs.get(ontologyID);
		}
		return new Vector<String>();
	}

	/**
	 * 
	 * @param agentID
	 * @return changed session entries
	 */
	public List<String> removeAgentFromSessions(String agentID) {
		List<String> sessionsWithAgent = new Vector<String>();
		for (String sessionID : getSessionIDs()) {
			List<String> agentIDs = getAgentsForSession(sessionID);
			if (agentIDs.contains(agentID)) {
				sessionsWithAgent.add(sessionID);
			}
		}
		for (String sessionID : sessionsWithAgent) {
			removeAgent2SessionAssignment(agentID, sessionID);
		}
		return sessionsWithAgent;
	}

	/**
	 * 
	 * @param agentID
	 * @return changed ontology entries
	 */
	public List<String> removeAgentFromOntologies(String agentID) {
		List<String> ontologiesWithAgent = new Vector<String>();
		for (String ontologyID : getOntologyIDs()) {
			List<String> agentIDs = getAgentsForOntology(ontologyID);
			if (agentIDs.contains(agentID)) {
				ontologiesWithAgent.add(ontologyID);
			}
		}
		for (String ontologyID : ontologiesWithAgent) {
			removeAgent2OntologyAssignment(agentID, ontologyID);
		}
		return ontologiesWithAgent;
	}

	public boolean containsAgentToSessionAssignment(String agentID,
			String sessionID) {
		List<String> agentIDs = sessionID2agentIDs.get(sessionID);
		if (agentIDs == null) {
			return false;
		}
		return agentIDs.contains(agentID);
	}

	public boolean containsAgentToOntologyAssignment(String agentID,
			String ontologyID) {
		List<String> agentIDs = ontologyID2agentIDs.get(ontologyID);
		if (agentIDs == null) {
			return false;
		}
		return agentIDs.contains(agentID);
	}

	/**
	 * will probably not be needed
	 */
	public void renameAgent(String agentIDOld, String agentIDNew) {
		List<String> sessionsWithAgent = new Vector<String>();
		for (String sessionID : getSessionIDs()) {
			List<String> agentIDs = getAgentsForSession(sessionID);
			if (agentIDs.contains(agentIDOld)) {
				sessionsWithAgent.add(sessionID);
			}
		}
		for (String sessionID : sessionsWithAgent) {
			removeAgent2SessionAssignment(agentIDOld, sessionID);
			addAgent2Session(agentIDNew, sessionID);
		}

		List<String> ontologiesWithAgent = new Vector<String>();
		for (String ontologyID : getOntologyIDs()) {
			List<String> agentIDs = getAgentsForOntology(ontologyID);
			if (agentIDs.contains(agentIDOld)) {
				ontologiesWithAgent.add(ontologyID);
			}
		}
		for (String ontologyID : ontologiesWithAgent) {
			removeAgent2OntologyAssignment(agentIDOld, ontologyID);
			addAgent2Session(agentIDNew, ontologyID);
		}
	}

	@Override
	public String toString() {
		return "AgentRuntimeConfig [sessionGeneralAgents="
				+ sessionGeneralAgents + ", sessionIDs=" + sessionIDs
				+ ", sessionID2agentIDs=" + sessionID2agentIDs
				+ ", ontologyIDs=" + ontologyIDs + ", ontologyID2agentIDs="
				+ ontologyID2agentIDs + "]";
	}

}
