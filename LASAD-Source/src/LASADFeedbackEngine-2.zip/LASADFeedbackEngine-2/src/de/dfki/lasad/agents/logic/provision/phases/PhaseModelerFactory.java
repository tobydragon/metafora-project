package de.dfki.lasad.agents.logic.provision.phases;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.ServiceType;
import lasad.shared.dfki.meta.agents.action.ActionType;
import lasad.shared.dfki.meta.agents.analysis.phases.PhaseDef;
import lasad.shared.dfki.meta.agents.analysis.phases.PhaseModelerDef;
import lasad.shared.dfki.meta.agents.analysis.phases.PhaseModelerDef_Empirical;
import lasad.shared.dfki.meta.agents.common.ActionListDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.session.SessionConfig;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PhaseModelerFactory {

	private static Log logger = LogFactory.getLog(PhaseModelerFactory.class);

	public static PhaseModelerInterface createPhaseModeler(PhaseModelerDef modelerDef,
			String agentID, SessionConfig sessionConfig) {

		List<PhaseDef> phaseIDs = modelerDef.getPhaseDef().getPhases();

		if (modelerDef instanceof PhaseModelerDef_Empirical) {

			List<ActionType> relevantActionTypes = new Vector<ActionType>();
			PhaseModelerDef_Empirical empModelerDef = (PhaseModelerDef_Empirical) modelerDef;
			ActionListDef actionListDef = empModelerDef.getRelevantActions();
			if (actionListDef.isAllOwnActionTypes()) {
				List<ServiceType> serviceTypes = sessionConfig
						.getAgentServiceTypes(agentID);
				for (ServiceType sType : serviceTypes) {
					if (sType instanceof ActionType) {
						ActionType aType = (ActionType) sType;
						relevantActionTypes.add(aType);
					}
				}
				PhaseModeler_Empirical phaseModeler = new PhaseModeler_Empirical(
						phaseIDs, relevantActionTypes);
				return phaseModeler;
			} else {
				for (ServiceID sID : actionListDef.getServiceIDs()) {
					ServiceType sType = sessionConfig.getAgentServiceType(sID);
					if (sType instanceof ActionType) {
						ActionType aType = (ActionType) sType;
						relevantActionTypes.add(aType);
					}
				}
				return new PhaseModeler_Empirical(phaseIDs, relevantActionTypes);
			}

		} else {
			logger.error("Unhandled phase modeler type: " + modelerDef);
			return null;
		}
	}
}
