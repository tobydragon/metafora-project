package de.dfki.lasad.authoring.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.jdom.Element;

import de.dfki.lasad.util.XMLUtil;

/**
 * a list of agent-to-session assignments (to be used in the graphical
 * frontend).
 * 
 * @author oliverscheuer
 * 
 */
public class Agents2SessionsFE {

	private Map<String, List<String>> sessionID2agentIDs = new HashMap<String, List<String>>();

	public void addMapping(String aID, String sID) {
		List<String> agents = sessionID2agentIDs.get(sID);
		if (agents == null) {
			agents = new Vector<String>();
			sessionID2agentIDs.put(sID, agents);
		}
		agents.add(aID);
	}

	public Element toXMLElem() {
		Set<String> sessionList = sessionID2agentIDs.keySet();

		Element descrsElem = new Element(ElementStrings.AGENTS_TO_SESSIONS);

		for (String session : sessionList) {
			Element ont = new Element(ElementStrings.SESSION);
			ont.setAttribute(ElementStrings.NAME, session);

			List<String> agentList = sessionID2agentIDs.get(session);
			for (String agent : agentList) {
				Element ag = new Element(ElementStrings.AGENT);
				ag.setText(agent);
				ont.addContent(ag);
			}
			descrsElem.addContent(ont);
		}

		return descrsElem;
	}

	public static Agents2SessionsFE fromXMLElem(Element xml) {
		Agents2SessionsFE agent2SessFE = new Agents2SessionsFE();

		List<Element> sessionElemList = (List<Element>) xml
				.getChildren(ElementStrings.SESSION);
		for (Element session : sessionElemList) {
			String sessionName = session.getAttribute(ElementStrings.NAME)
					.getValue();

			List<Element> agentElemList = (List<Element>) session
					.getChildren(ElementStrings.AGENT);

			for (Element agent : agentElemList) {
				String agentName = agent.getText();
				agent2SessFE.addAgents2Session(sessionName, agentName);
			}
		}

		return agent2SessFE;
	}

	/*
	 * Adds the agent to ontology
	 */
	public void addAgents2Session(String session, String agent) {
		List<String> agentListTmp = sessionID2agentIDs.get(session);
		if (agentListTmp == null) {
			agentListTmp = new Vector<String>();
			sessionID2agentIDs.put(session, agentListTmp);
		}
		agentListTmp.add(agent);
	}

	public String toXMLString() {
		Element e = toXMLElem();
		return XMLUtil.xmlElem2docString(e);
	}

	public static Agents2SessionsFE fromXMLString(String xml) {
		Element e = XMLUtil.string2xmlElem(xml);
		return fromXMLElem(e);
	}

	@Override
	public String toString() {
		return "Agents2SessionsFE [sessionID2agentIDs=" + sessionID2agentIDs
				+ "]";
	}

}
