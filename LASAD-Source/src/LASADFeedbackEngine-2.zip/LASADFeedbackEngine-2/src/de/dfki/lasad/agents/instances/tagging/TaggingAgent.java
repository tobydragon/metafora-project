package de.dfki.lasad.agents.instances.tagging;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.AbstractAgent;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.AnalysisResultEvent;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.events.eue.user.join.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.user.join.UserLeaveSessionEvent;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.DeleteObjectEvent;
import de.dfki.lasad.events.eue.user.object.FocusObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;
import de.dfki.lasad.sessionmodel.graphmodel.GraphElement;
import de.uds.cfcommunication.CfMultiSessionCommunicationManager;
import de.uds.cfcommunication.CommunicationChannelType;
import de.uds.cfcommunication.CommunicationMethodType;
import de.uds.commonformat.CfAction;
import de.uds.translator.EueToCfActionTranslator;
import de.uds.util.GeneralUtil;

public class TaggingAgent extends AbstractAgent {
	Log logger = LogFactory.getLog(this.getClass());

	CfMultiSessionCommunicationManager communicationManager;

	public TaggingAgent() {
		communicationManager = CfMultiSessionCommunicationManager.getInstance(CommunicationMethodType.file, CommunicationChannelType.analysis);
	}


	@Override
	protected void processEvent(Event event) {
		if (event instanceof UserEvent) {
			UserEvent userActionEvent = (UserEvent) event;
			if (GeneralUtil.isTimeRecent(event.getTs())){
				if (userActionEvent instanceof ModifyObjectEvent) {
					List<CfAction> indicators = buildTagIndicator((ObjectActionEvent) userActionEvent);
					for (CfAction indicator : indicators){
						communicationManager.sendMessage(indicator);
					}
				}
			}
		}
	}

	private List<CfAction> buildTagIndicator(ObjectActionEvent eueObjectAction){
		List<CfAction> indicators = new ArrayList<CfAction>();
		for (EUEObject object : eueObjectAction.getEueObjectList()){
			if (shouldReportObject(eueObjectAction, object)){
				String eueObjectId = object.getID().getIdAsString();
				GraphElement element = model.getElement(eueObjectId);
				if (element != null){
					String text = getModifiedText(eueObjectAction);
					CfAction indicator = EueToCfActionTranslator.translateModifyEventAndTagsToCfActionIndicator(eueObjectAction, element, text, getTags(text));
					if (indicator != null){
						indicators.add(indicator);
					}
					else {
						logger.error("[buildUserObjectActionIndicator] Null indicator returned for object id: " + eueObjectId);
					}
				}
				else {
					logger.error("[buildUserObjectActionIndicator] No graphModel entry found for object id: " + eueObjectId);
				}
			}
		}
		return indicators;
	}

	private boolean shouldReportObject(ObjectActionEvent action, EUEObject object ){
		
		if (action instanceof ModifyObjectEvent){
			//TODO If text was modified
			return true;
		}
		return false;
	}
	
	
	private static String getModifiedText(ObjectActionEvent eueObjectAction) {
		// TODO Find text to be tagged
		return null;
	}
	
	private static List<String> getTags(String text) {
		// TODO Run tagging and return results
		return null;
	}

	
}
