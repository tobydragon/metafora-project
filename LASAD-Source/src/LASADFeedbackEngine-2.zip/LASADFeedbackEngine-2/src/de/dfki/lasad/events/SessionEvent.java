package de.dfki.lasad.events;

import de.dfki.lasad.session.data.SessionID;

/**
 * {@link EventImpl} associated with some session.
 * 
 * @author Oliver Scheuer
 * 
 */
public class SessionEvent extends EventImpl {

	protected SessionID sessionID;

	public SessionEvent(String srcCompId) {
		super(srcCompId);
	}

	public SessionEvent(SessionID sessionID, String srcCompId) {
		super(srcCompId);
		this.sessionID = sessionID;
	}

	public void setSessionID(SessionID sessionID) {
		this.sessionID = sessionID;
	}

	public SessionID getSessionID() {
		return sessionID;
	}

	@Override
	public String toString() {
		return super.toString() + ", sessionID=" + sessionID;
	}

}
