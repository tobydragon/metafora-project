package de.dfki.lasad.authoring;

import java.util.concurrent.PriorityBlockingQueue;

import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;
import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionListFE;
import lasad.shared.dfki.authoring.frontenddata.Agents2OntologiesFE;
import lasad.shared.dfki.authoring.frontenddata.Agents2SessionsFE;
import lasad.shared.dfki.authoring.frontenddata.SessionStatusMapFE;
import lasad.shared.dfki.meta.ServiceStatus;
import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ConfigurationManager;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.configchange.AFStateChangedEvent;
import de.dfki.lasad.events.agents.configchange.AFStateChangedEventListener;
import de.dfki.lasad.events.agents.configchange.ComponentRuntimeStatusChangedEvent;
import de.dfki.lasad.events.agents.configchange.SessionRuntimeStatusChangedEvent;
import de.dfki.lasad.events.agents.configstate.AgentsStateInfoEvent;
import de.dfki.lasad.events.agents.configstate.AgentsToOntologiesStateInfoEvent;
import de.dfki.lasad.events.agents.configstate.AgentsToSessionsStateInfoEvent;
import de.dfki.lasad.events.agents.configstate.SessionStatusInfoEvent;
import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;
import de.dfki.lasad.events.eue.admin.agent.in.AddAgentToOntologyEvent;
import de.dfki.lasad.events.eue.admin.agent.in.AddAgentToSessionEvent;
import de.dfki.lasad.events.eue.admin.agent.in.AddOrUpdateAgentEvent;
import de.dfki.lasad.events.eue.admin.agent.in.CompileAgentEvent;
import de.dfki.lasad.events.eue.admin.agent.in.DeleteAgentEvent;
import de.dfki.lasad.events.eue.admin.agent.in.GetFreshAgentIDEvent;
import de.dfki.lasad.events.eue.admin.agent.in.GetFreshServiceIDEvent;
import de.dfki.lasad.events.eue.admin.agent.in.RemoveAgentFromOntologyEvent;
import de.dfki.lasad.events.eue.admin.agent.in.RemoveAgentFromSessionEvent;
import de.dfki.lasad.events.eue.admin.agent.in.StartSessionEvent;
import de.dfki.lasad.events.eue.admin.agent.in.StopSessionEvent;
import de.dfki.lasad.events.eue.admin.agent.out.FreshAgentIDEvent;
import de.dfki.lasad.events.eue.admin.agent.out.FreshServiceIDEvent;
import de.dfki.lasad.session.SessionManager;
import de.dfki.lasad.util.threads.Signal;

/**
 * Communication interface with the Feedback-Agent frontend, received requests
 * to update configuration and runtime and sends out state updates. State
 * updates are processed asynchronously in a separate Thread.
 * 
 * @author oliverscheuer, anahuacvalero
 * 
 */
public class EUEAuthorCommunicator implements AFStateChangedEventListener {

	private static Log logger = LogFactory.getLog(EUEAuthorCommunicator.class);

	private boolean sendOutStateUpdates = false;

	private IDataService dataService;
	private BackendPort backendPort;
	private IDGenerator idGenerator;

	private PriorityBlockingQueue<AFStateChangedEvent> eventQueue = new PriorityBlockingQueue<AFStateChangedEvent>();
	private boolean processEvents = false;
	private Thread workingThread;
	private Signal signal = new Signal();

	public EUEAuthorCommunicator(SessionManager sessionManager,
			ConfigurationManager configManager, IDataService dataService) {
		this.dataService = dataService;
		backendPort = new BackendPort(sessionManager, configManager);
		idGenerator = new IDGenerator(configManager);

	}

	public void processAgentAdminEvent(EUEAgentAdminEvent event) {
		if (event instanceof AddOrUpdateAgentEvent) {
			AddOrUpdateAgentEvent updateAgentEvent = (AddOrUpdateAgentEvent) event;
			AgentDescriptionFE agentDescrFE = updateAgentEvent
					.getAgentDescriptionFE();
			backendPort.addOrUpdateAgent(agentDescrFE);
		} else if (event instanceof DeleteAgentEvent) {
			DeleteAgentEvent deleteAgentEvent = (DeleteAgentEvent) event;
			String agentID = deleteAgentEvent.getAgentID();
			backendPort.deleteAgent(agentID);
		} else if (event instanceof AddAgentToSessionEvent) {
			AddAgentToSessionEvent addAgentToSessionEvent = (AddAgentToSessionEvent) event;
			String agentID = addAgentToSessionEvent.getAgentID();
			String sessionID = addAgentToSessionEvent.getSessionID();
			backendPort.addAgent2SessionMapping(agentID, sessionID);
		} else if (event instanceof RemoveAgentFromSessionEvent) {
			RemoveAgentFromSessionEvent removeAgentFromSessionEvent = (RemoveAgentFromSessionEvent) event;
			String agentID = removeAgentFromSessionEvent.getAgentID();
			String sessionID = removeAgentFromSessionEvent.getSessionID();
			backendPort.removeAgent2SessionMapping(agentID, sessionID);
		} else if (event instanceof AddAgentToOntologyEvent) {
			AddAgentToOntologyEvent addAgentToOntologyEvent = (AddAgentToOntologyEvent) event;
			String agentID = addAgentToOntologyEvent.getAgentID();
			String ontologyID = addAgentToOntologyEvent.getOntologyID();
			backendPort.addAgent2OntologyMapping(agentID, ontologyID);
		} else if (event instanceof RemoveAgentFromOntologyEvent) {
			RemoveAgentFromOntologyEvent removeAgentFromOntologyEvent = (RemoveAgentFromOntologyEvent) event;
			String agentID = removeAgentFromOntologyEvent.getAgentID();
			String ontologyID = removeAgentFromOntologyEvent.getOntologyID();
			backendPort.removeAgent2OntologyMapping(agentID, ontologyID);
		} else if (event instanceof CompileAgentEvent) {
			CompileAgentEvent compileAgentEvent = (CompileAgentEvent) event;
			String agentID = compileAgentEvent.getAgentID();
			backendPort.compileAgent(agentID);
		} else if (event instanceof StopSessionEvent) {
			StopSessionEvent stopSessionEvent = (StopSessionEvent) event;
			String sessionID = stopSessionEvent.getSessionID();
			backendPort.stopSessionServices(sessionID);
		} else if (event instanceof StartSessionEvent) {
			StartSessionEvent startSessionEvent = (StartSessionEvent) event;
			String sessionID = startSessionEvent.getSessionID();
			backendPort.startSessionServices(sessionID);
		} else if (event instanceof GetFreshAgentIDEvent) {
			generateAndSendFreshAgentID((GetFreshAgentIDEvent) event);
		} else if (event instanceof GetFreshServiceIDEvent) {
			generateAndSendFreshServiceID((GetFreshServiceIDEvent) event);
		}
	}

	@Override
	public void onConfigChangedEvent(AFStateChangedEvent event) {
		if (processEvents) {
			eventQueue.add(event);
		} else {
			// ignore
			logger.debug("(onConfigChangedEvent) Ignore event: "
					+ event.toString()
					+ ", agent admin updating service not active (yet).");
		}
	}

	private void processAFStateChangedEvent(AFStateChangedEvent event) {
		if (sendOutStateUpdates) {
			logger.debug("(processAFStateChangedEvent) Processing event: "
					+ event.toString());

			if (event instanceof SessionRuntimeStatusChangedEvent) {
				SessionRuntimeStatusChangedEvent runtimeEvent = (SessionRuntimeStatusChangedEvent) event;
				ServiceStatus from = runtimeEvent.getOldStatus();
				ServiceStatus to = runtimeEvent.getNewStatus();
				if (from != to
						&& (to == ServiceStatus.RUNNING || from == ServiceStatus.RUNNING)) {
					dataService.onOutEvent(event);
				} else {
					// ignore
					logger.debug("Ignore event: " + event.toString());
				}
			} else if (event instanceof ComponentRuntimeStatusChangedEvent) {
				// ignore
				logger.debug("Ignore event: " + event.toString());
			} else {
				dataService.onOutEvent(event);
			}
		}
	}

	private void initFE() {
		if (sendOutStateUpdates) {
			logger.debug("(initFE())");
			sendAgentDescrsStateInfoEvent();
			sendAgentsToOntologiesInfoEvent();
			sendAgentsToSessionsInfoEvent();
			sendSessionStatusInfoEvent();
		}
	}

	public synchronized void startUpdatingService() {
		try {
			if (!processEvents) {
				eventQueue.clear();
				processEvents = true;
				workingThread = new Thread(new Consumer());
				workingThread.start();
				logger.info(getClass().getSimpleName()
						+ ": Waiting for event thread to start ...");
				signal.waitForSignal(true);
				logger.info(getClass().getSimpleName()
						+ ": Waiting for event thread to start: DONE");
			} else {
				logger.debug("(startUpdatingService) Updating service is already running.");
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	public synchronized void stopUpdatingService() {
		try {
			processEvents = false;
			logger.info(getClass().getSimpleName()
					+ ": Waiting for event thread to stop ...");
			signal.waitForSignal(false);
			logger.info(getClass().getSimpleName()
					+ ": Waiting for event thread to stop: DONE");
		} catch (Exception e) {
			logger.error("stopService() " + e.getClass(), e);
		}
	}

	private void sendAgentDescrsStateInfoEvent() {
		logger.info("sendAgentDescrsStateInfoEvent()");
		AgentDescriptionListFE agentDescriptionList = backendPort
				.getAgentDescriptions();
		AgentsStateInfoEvent infoEvent = new AgentsStateInfoEvent(getClass()
				.getSimpleName());
		infoEvent.setAgentDescriptionList(agentDescriptionList);
		infoEvent.setChanged(true);
		dataService.onOutEvent(infoEvent);
	}

	private void sendAgentsToOntologiesInfoEvent() {
		logger.info("sendAgents2OntologiesInfoEvent()");
		Agents2OntologiesFE a2o = backendPort.getAgents2Ontologies();
		AgentsToOntologiesStateInfoEvent event = new AgentsToOntologiesStateInfoEvent(
				getClass().getSimpleName());
		event.setAgents2ontologies(a2o);
		event.setChanged(true);
		dataService.onOutEvent(event);
	}

	private void sendAgentsToSessionsInfoEvent() {
		logger.info("sendAgents2SessionsInfoEvent()");
		Agents2SessionsFE a2s = backendPort.getAgents2Sessions();
		AgentsToSessionsStateInfoEvent event = new AgentsToSessionsStateInfoEvent(
				getClass().getSimpleName());
		event.setAgents2sessions(a2s);
		event.setChanged(true);
		dataService.onOutEvent(event);
	}

	private void sendSessionStatusInfoEvent() {
		logger.info("sendSessionStatusInfoEvent()");
		SessionStatusMapFE statusMapFE = backendPort.getSessionStatusMap();
		SessionStatusInfoEvent event = new SessionStatusInfoEvent(getClass()
				.getSimpleName());
		event.setSessionStatusMap(statusMapFE);
		event.setChanged(true);
		dataService.onOutEvent(event);
	}

	private void generateAndSendFreshAgentID(
			GetFreshAgentIDEvent getFreshAgentIDEvent) {
		String freshAgentID = idGenerator.getFreshAgentID();
		FreshAgentIDEvent agentIDEvent = new FreshAgentIDEvent(getClass()
				.getSimpleName());
		agentIDEvent.setAgentID(freshAgentID);
		agentIDEvent.setRequestID(getFreshAgentIDEvent.getRequestID());
		dataService.onOutEvent(agentIDEvent);
	}

	private void generateAndSendFreshServiceID(
			GetFreshServiceIDEvent getFreshServiceIDEvent) {
		String agentID = getFreshServiceIDEvent.getAgentID();
		ServiceClass serviceClass = getFreshServiceIDEvent.getServiceClass();
		ServiceID freshServiceID = idGenerator.getFreshServiceID(agentID,
				serviceClass);
		FreshServiceIDEvent serviceIDEvent = new FreshServiceIDEvent(getClass()
				.getSimpleName());
		serviceIDEvent.setServiceID(freshServiceID);
		serviceIDEvent.setRequestID(getFreshServiceIDEvent.getRequestID());
		dataService.onOutEvent(serviceIDEvent);
	}

	class Consumer implements Runnable {

		@Override
		public void run() {
			try {
				signal.signalGo();

				initFE();

				do {
					Event event = eventQueue.take();
					processAFStateChangedEvent((AFStateChangedEvent) event);
				} while (processEvents);
				signal.signalStop();
			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}
		}
	}
}
