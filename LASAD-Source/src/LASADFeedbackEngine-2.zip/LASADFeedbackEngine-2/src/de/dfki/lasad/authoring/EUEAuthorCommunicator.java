package de.dfki.lasad.authoring;

import java.util.concurrent.PriorityBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.authoring.model.AgentDescriptionFE;
import de.dfki.lasad.authoring.model.AgentDescriptionListFE;
import de.dfki.lasad.authoring.model.Agents2OntologiesFE;
import de.dfki.lasad.authoring.model.Agents2SessionsFE;
import de.dfki.lasad.authoring.model.SessionStatusMapFE;
import de.dfki.lasad.core.ConfigurationManager;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.core.components.instance.ServiceStatus;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.state.AFStateChangedEvent;
import de.dfki.lasad.events.agents.state.AFStateChangedEventListener;
import de.dfki.lasad.events.agents.state.AgentDescriptionsChangedEvent;
import de.dfki.lasad.events.agents.state.Agents2OntologiesMappingChangedEvent;
import de.dfki.lasad.events.agents.state.Agents2SessionsMappingChangedEvent;
import de.dfki.lasad.events.agents.state.RuntimeChangedEvent;
import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;
import de.dfki.lasad.events.eue.admin.agent.in.AddAgentToOntologyEvent;
import de.dfki.lasad.events.eue.admin.agent.in.AddAgentToSessionEvent;
import de.dfki.lasad.events.eue.admin.agent.in.AddOrUpdateAgentEvent;
import de.dfki.lasad.events.eue.admin.agent.in.DeleteAgentEvent;
import de.dfki.lasad.events.eue.admin.agent.in.RemoveAgentFromOntologyEvent;
import de.dfki.lasad.events.eue.admin.agent.in.RemoveAgentFromSessionEvent;
import de.dfki.lasad.events.eue.admin.agent.out.AgentsInfoEvent;
import de.dfki.lasad.events.eue.admin.agent.out.AgentsToOntologiesInfoEvent;
import de.dfki.lasad.events.eue.admin.agent.out.AgentsToSessionsInfoEvent;
import de.dfki.lasad.events.eue.admin.agent.out.SessionStatusInfoEvent;
import de.dfki.lasad.session.SessionManager;
import de.dfki.lasad.util.threads.Signal;

/**
 * Communication interface with the Feedback-Agent frontend, received requests
 * to update configuration and runtime and sends out state updates. State
 * updates are processed asynchronously in a separate Thread.
 * 
 * @author oliverscheuer
 * 
 */
public class EUEAuthorCommunicator implements AFStateChangedEventListener {

	private static Log logger = LogFactory.getLog(EUEAuthorCommunicator.class);

	private boolean sendOutStateUpdates = false;

	private IDataService dataService;
	private BackendPort backendPort;

	private PriorityBlockingQueue<AFStateChangedEvent> eventQueue = new PriorityBlockingQueue<AFStateChangedEvent>();
	private boolean processEvents = false;
	private Thread workingThread;
	private Signal signal = new Signal();

	public EUEAuthorCommunicator(SessionManager sessionManager,
			ConfigurationManager configManager, IDataService dataService) {
		this.dataService = dataService;
		backendPort = new BackendPort(sessionManager, configManager);

	}

	public void processAgentAdminEvent(EUEAgentAdminEvent event) {
		if (event instanceof AddOrUpdateAgentEvent) {
			AddOrUpdateAgentEvent updateAgentEvent = (AddOrUpdateAgentEvent) event;
			AgentDescriptionFE agentDescrFE = updateAgentEvent
					.getAgentDescriptionFE();
			backendPort.addOrUpdateAgent(agentDescrFE);
		} else if (event instanceof DeleteAgentEvent) {
			DeleteAgentEvent deleteAgentEvent = (DeleteAgentEvent) event;
			String agentID = deleteAgentEvent.getAgentID();
			backendPort.deleteAgent(agentID);
		} else if (event instanceof AddAgentToSessionEvent) {
			AddAgentToSessionEvent addAgentToSessionEvent = (AddAgentToSessionEvent) event;
			String agentID = addAgentToSessionEvent.getAgentID();
			String sessionID = addAgentToSessionEvent.getSessionID();
			backendPort.addAgent2SessionMapping(agentID, sessionID);
		} else if (event instanceof RemoveAgentFromSessionEvent) {
			RemoveAgentFromSessionEvent removeAgentFromSessionEvent = (RemoveAgentFromSessionEvent) event;
			String agentID = removeAgentFromSessionEvent.getAgentID();
			String sessionID = removeAgentFromSessionEvent.getSessionID();
			backendPort.removeAgent2SessionMapping(agentID, sessionID);
		} else if (event instanceof AddAgentToOntologyEvent) {
			AddAgentToOntologyEvent addAgentToOntologyEvent = (AddAgentToOntologyEvent) event;
			String agentID = addAgentToOntologyEvent.getAgentID();
			String ontologyID = addAgentToOntologyEvent.getOntologyID();
			backendPort.addAgent2OntologyMapping(agentID, ontologyID);
		} else if (event instanceof RemoveAgentFromOntologyEvent) {
			RemoveAgentFromOntologyEvent removeAgentFromOntologyEvent = (RemoveAgentFromOntologyEvent) event;
			String agentID = removeAgentFromOntologyEvent.getAgentID();
			String ontologyID = removeAgentFromOntologyEvent.getOntologyID();
			backendPort.removeAgent2OntologyMapping(agentID, ontologyID);
		}
	}

	@Override
	public void onConfigChangedEvent(AFStateChangedEvent event) {
		if (processEvents) {
			eventQueue.add(event);
		}
	}

	private void processAFStateChangedEvent(AFStateChangedEvent event) {
		if (sendOutStateUpdates) {
			logger.info("Processing event: " + event.toString());
			boolean stateOrConfigChanged = event.isChanged();
			if (event instanceof AgentDescriptionsChangedEvent) {
				sendAgentsInfoEvent(stateOrConfigChanged);
			} else if (event instanceof Agents2OntologiesMappingChangedEvent) {
				sendAgentsToOntologiesInfoEvent(stateOrConfigChanged);
			} else if (event instanceof Agents2SessionsMappingChangedEvent) {
				sendAgentsToSessionsInfoEvent(stateOrConfigChanged);
			} else if (event instanceof RuntimeChangedEvent) {
				RuntimeChangedEvent runtimeEvent = (RuntimeChangedEvent) event;
				ServiceStatus from = runtimeEvent.getOldStatus();
				ServiceStatus to = runtimeEvent.getNewStatus();
				if (from != to
						&& (to == ServiceStatus.RUNNING || from == ServiceStatus.RUNNING)) {
					sendSessionStatusInfoEvent(stateOrConfigChanged);
				}

			}
		}
	}

	private void initFE() {
		if (sendOutStateUpdates) {
			sendAgentsInfoEvent(true);
			sendAgentsToOntologiesInfoEvent(true);
			sendAgentsToSessionsInfoEvent(true);
			sendSessionStatusInfoEvent(true);
		}
	}

	public synchronized void startUpdatingService() {
		try {
			if (!processEvents) {
				eventQueue.clear();
				processEvents = true;
				workingThread = new Thread(new Consumer());
				workingThread.start();
				logger.info(getClass().getSimpleName()
						+ ": Waiting for event thread to start ...");
				signal.waitForSignal(true);
				logger.info(getClass().getSimpleName()
						+ ": Waiting for event thread to start: DONE");
			} else {
				logger.info("Updating service is already running.");
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	public synchronized void stopUpdatingService() {
		try {
			processEvents = false;
			logger.info(getClass().getSimpleName()
					+ ": Waiting for event thread to stop ...");
			signal.waitForSignal(false);
			logger.info(getClass().getSimpleName()
					+ ": Waiting for event thread to stop: DONE");
		} catch (Exception e) {
			logger.error("stopService() " + e.getClass(), e);
		}
	}

	private void sendAgentsInfoEvent(boolean changedFlag) {
		logger.info("sendAgentsInfoEvent");
		AgentDescriptionListFE agentDescriptionList = backendPort
				.getAgentDescriptions();
		AgentsInfoEvent event = new AgentsInfoEvent(getClass().getSimpleName());
		event.setAgentDescriptionList(agentDescriptionList);
		event.setChanged(changedFlag);
		dataService.onOutEvent(event);
	}

	private void sendAgentsToOntologiesInfoEvent(boolean changedFlag) {
		logger.info("sendAgents2OntologiesInfoEvent");
		Agents2OntologiesFE a2o = backendPort.getAgents2Ontologies();
		AgentsToOntologiesInfoEvent event = new AgentsToOntologiesInfoEvent(
				getClass().getSimpleName());
		event.setAgents2ontologies(a2o);
		event.setChanged(changedFlag);
		dataService.onOutEvent(event);
	}

	private void sendAgentsToSessionsInfoEvent(boolean changedFlag) {
		logger.info("sendAgents2SessionsInfoEvent");
		Agents2SessionsFE a2s = backendPort.getAgents2Sessions();
		AgentsToSessionsInfoEvent event = new AgentsToSessionsInfoEvent(
				getClass().getSimpleName());
		event.setAgents2sessions(a2s);
		event.setChanged(changedFlag);
		dataService.onOutEvent(event);
	}

	private void sendSessionStatusInfoEvent(boolean changedFlag) {
		logger.info("sendSessionStatusInfoEvent");
		SessionStatusMapFE statusMapFE = backendPort.getSessionStatusMap();
		SessionStatusInfoEvent event = new SessionStatusInfoEvent(getClass()
				.getSimpleName());
		event.setSessionStatusMap(statusMapFE);
		event.setChanged(changedFlag);
		dataService.onOutEvent(event);
	}

	class Consumer implements Runnable {

		@Override
		public void run() {
			try {
				signal.signalGo();

				initFE();

				do {
					Event event = eventQueue.take();
					processAFStateChangedEvent((AFStateChangedEvent) event);
				} while (processEvents);
				signal.signalStop();
			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}
		}
	}
}
