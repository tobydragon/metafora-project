package de.dfki.lasad.events.agents.state;


/**
 * 
 * @author oliverscheuer
 *
 */
public interface AFStateChangedEventListener {

	public void onConfigChangedEvent(AFStateChangedEvent event);
}
