package de.dfki.lasad.authoring.model.pattern;

/**
 * (see {@link ElementConstr})
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class NodeConstr extends ElementConstr {

	// supplemental fields
	private NeighborConstrs neighborConstrs;

	public NeighborConstrs getNeighborConstrs() {
		return neighborConstrs;
	}

	public void setNeighborConstrs(NeighborConstrs neighborConstrs) {
		this.neighborConstrs = neighborConstrs;
	}

}
