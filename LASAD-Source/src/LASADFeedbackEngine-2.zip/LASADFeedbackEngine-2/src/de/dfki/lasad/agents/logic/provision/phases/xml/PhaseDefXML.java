package de.dfki.lasad.agents.logic.provision.phases.xml;

import lasad.shared.dfki.meta.agents.analysis.phases.PhaseDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.CDATA;
import org.jdom.Element;

/**
 * 
 * @author anahuacv
 * 
 */
public class PhaseDefXML {
	private static Log logger = LogFactory.getLog(PhaseDefXML.class);

	public static final String PHASE_ELEMENT_NAME = "phase";
	public static final String ID_ELEMENT_NAME = "id";
	public static final String DISPLAY_NAME_ELEMENT_NAME = "display-name";
	public static final String DESCRIPTION_ELEMENT_NAME = "description";

	public static PhaseDef fromXML(Element phaseElem) {
		PhaseDef phaseDef = new PhaseDef();
		String phaseID = phaseElem.getAttributeValue(ID_ELEMENT_NAME);
		phaseDef.setID(phaseID);
		
		Element displayNameElem = phaseElem.getChild(DISPLAY_NAME_ELEMENT_NAME);
		if (displayNameElem != null) {
			String displayName = displayNameElem.getText();
			phaseDef.setName(displayName);
		}

		Element descriptionElem = phaseElem.getChild(DESCRIPTION_ELEMENT_NAME);
		if (descriptionElem != null) {
			String description = descriptionElem.getText();
			phaseDef.setDescription(description);
		}
		return phaseDef;
	}

	public static Element toXML(PhaseDef phaseDef) {
		Element phaseDefElem = new Element(PHASE_ELEMENT_NAME);
		
		phaseDefElem.setAttribute(ID_ELEMENT_NAME, phaseDef.getID());
		
		String displayName = phaseDef.getName();
		if (displayName != null) {
			Element displayNameElem = new Element(DISPLAY_NAME_ELEMENT_NAME);
			CDATA displayNameCData = new CDATA(displayName);
			displayNameElem.addContent(displayNameCData);
			phaseDefElem.addContent(displayNameElem);
		}
		String description = phaseDef.getDescription();
		if (description != null) {
			Element descriptionElem = new Element(DESCRIPTION_ELEMENT_NAME);
			CDATA descriptionCData = new CDATA(description);
			descriptionElem.addContent(descriptionCData);
			phaseDefElem.addContent(descriptionElem);
		}
		
		return phaseDefElem;
	}

}
