package de.dfki.lasad.agents.logic.provision.phases.xml;

import lasad.shared.dfki.meta.agents.common.ActionListDef;

import org.jdom.Element;

import de.dfki.lasad.agents.logic.ActionListDefXML;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class RelevantActionsDefXML extends ActionListDefXML {

	public static final String ELEMENT_NAME = "relevant-actions";

	public static ActionListDef fromXML(String agentID, Element actionsElem) {
		return ActionListDefXML.fromXML(agentID, actionsElem);
	}

	protected static Element toXML(ActionListDef actionListDef) {
		return ActionListDefXML.toXML(ELEMENT_NAME, actionListDef);
	}
}
