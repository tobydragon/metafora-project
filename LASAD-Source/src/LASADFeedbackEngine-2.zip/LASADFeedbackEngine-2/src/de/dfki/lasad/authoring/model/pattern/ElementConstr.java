package de.dfki.lasad.authoring.model.pattern;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import de.dfki.lasad.authoring.converter.pattern2jess.Bin;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;
import de.dfki.lasad.session.data.meta.ontology.TypePropDescr;

/**
 * All {@link PropConstr} defined for some {@link ElementVariable}.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public abstract class ElementConstr {

	// standard fields
	private ElementVariable elemVar;
	private List<PropConstr> propConstrs = new Vector<PropConstr>();

	// supplemental fields
	private Map<PropDescr, List<String>> prop2CompsUsedAsReferenceValues = new HashMap<PropDescr, List<String>>();
	private Map<Bin, Map<PropertyVariable, List<Comparison>>> bin2propVars2Comparisons = new HashMap<Bin, Map<PropertyVariable, List<Comparison>>>();

	public Map<PropDescr, List<String>> getProp2CompsUsedAsReferenceValues() {
		return prop2CompsUsedAsReferenceValues;
	}

	public void setProp2CompsUsedAsReferenceValues(
			Map<PropDescr, List<String>> prop2CompsUsedAsReferenceValues) {
		this.prop2CompsUsedAsReferenceValues = prop2CompsUsedAsReferenceValues;
	}


	public Map<Bin, Map<PropertyVariable, List<Comparison>>> getBin2propVars2Comparisons() {
		return bin2propVars2Comparisons;
	}

	public void setBin2propVars2Comparisons(
			Map<Bin, Map<PropertyVariable, List<Comparison>>> bin2propVars2Comparisons) {
		this.bin2propVars2Comparisons = bin2propVars2Comparisons;
	}

	public ElementVariable getElemVar() {
		return elemVar;
	}

	public void setElemVar(ElementVariable elemVar) {
		this.elemVar = elemVar;
	}

	public List<PropConstr> getPropConstrs() {
		return propConstrs;
	}

	public void setPropConstrs(List<PropConstr> propConstrs) {
		this.propConstrs = propConstrs;
	}

	public List<PropDescr> getPropsUsedAsRefVal() {
		return new Vector<PropDescr>(prop2CompsUsedAsReferenceValues.keySet());
	}

	public List<String> getPropComponentsUsedAsRefVal(PropDescr prop) {
		return prop2CompsUsedAsReferenceValues.get(prop);
	}

	public List<Comparison> getTypeComparisons() {
		List<Comparison> comparisons = new ArrayList<Comparison>();
		for (PropConstr pc : propConstrs) {
			PropertyVariable propVar = pc.getPropVar();
			PropDescr prop = propVar.getProp();
			if (prop instanceof TypePropDescr) {
				comparisons.addAll(pc.getComparisons());
			}
		}
		return comparisons;
	} 
	
	public List<Comparison> getComparisons(Bin bin, PropertyVariable propVar) {
		Map<PropertyVariable, List<Comparison>> propVars2Comparisons = bin2propVars2Comparisons
				.get(bin);
		if (propVars2Comparisons == null) {
			return new Vector<Comparison>();
		}
		List<Comparison> comparisons = propVars2Comparisons.get(propVar);
		if (comparisons == null) {
			return new Vector<Comparison>();
		}
		return comparisons;
	}

	// concatenation of comparison lists of all prop components
	public List<Comparison> getComparisons(Bin bin, PropDescr prop) {
		List<Comparison> allComparisons = new Vector<Comparison>();
		List<String> propComponentIDs = prop.getComponentIDs();
		for (String compID : propComponentIDs) {
			PropertyVariable propVar = elemVar.getPropVar(prop, compID);
			List<Comparison> comparisons = getComparisons(bin, propVar);
			allComparisons.addAll(comparisons);
		}
		return allComparisons;
	}
}
