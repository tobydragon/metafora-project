package de.dfki.lasad.agents.logic.provision.phases.xml;

import lasad.shared.dfki.meta.agents.analysis.phases.PhasesDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class PhaseModelerDefXML {

	private static Log logger = LogFactory.getLog(PhaseModelerDefXML.class);

	public static final String ELEMENT_NAME = "phase-model";

	public static PhasesDef getPhasesDef(Element phaseModelerElem) {
		Element phasesDefElem = phaseModelerElem
				.getChild(PhasesDefXML.ELEMENT_NAME);
		return PhasesDefXML.fromXML(phasesDefElem);
	}

	public static Element createPhaseModelElement(String type) {
		Element phaseModelElem = new Element(ELEMENT_NAME);
		phaseModelElem.setAttribute("type", type);
		return phaseModelElem;
	}

	public static void addPhasesDefElem(Element phaseModelerElem,
			PhasesDef phasesDef) {
		Element phasesDefElem = PhasesDefXML.toXML(phasesDef);
		phaseModelerElem.addContent(phasesDefElem);
	}
}
