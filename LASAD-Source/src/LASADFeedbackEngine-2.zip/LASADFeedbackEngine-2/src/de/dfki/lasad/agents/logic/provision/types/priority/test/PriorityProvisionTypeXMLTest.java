package de.dfki.lasad.agents.logic.provision.types.priority.test;

import java.io.File;

import lasad.shared.dfki.meta.agents.provision.priority.PriorityProvisionType;

import org.jdom.Element;

import de.dfki.lasad.agents.logic.provision.types.priority.PriorityProvisionTypeXML;
import de.dfki.lasad.util.ClasspathResourceUtil;
import de.dfki.lasad.util.XMLUtil;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PriorityProvisionTypeXMLTest {

	public static void main(String[] args) {
		reGenerateAndPrintXML("testcase-1.xml");
		reGenerateAndPrintXML("testcase-2.xml");
	}

	public static void reGenerateAndPrintXML(String localFilename) {
		System.out.println(localFilename);
		System.out.println("-----------------");
		String filePathCase = ClasspathResourceUtil
				.getAbsoluteFilepathFromResourceOnClasspath(
						PriorityProvisionTypeXMLTest.class, localFilename);

		PriorityProvisionType type = parseFile(filePathCase);
		// System.out.println(type);
		String xmlString = toXMLString(type);
		System.out.println(xmlString);
	}

	public static PriorityProvisionType parseFile(String absPathXML) {
		try {

			File file = new File(absPathXML);
			Element elem = XMLUtil.file2xmlElem(file);
			return PriorityProvisionTypeXML.fromXML("FEEDBACK-AGENT", elem);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String toXMLString(PriorityProvisionType priorityType) {
		try {

			Element elem = PriorityProvisionTypeXML.toXML(priorityType);
			return XMLUtil.xmlElem2docString(elem);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
