package de.dfki.lasad.session;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.meta.ServiceType;
import de.dfki.lasad.authoring.EUEAuthorCommunicator;
import de.dfki.lasad.core.ConfigurationManager;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.core.components.instance.ServiceStatus;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.agents.StartServicesRequestEvent;
import de.dfki.lasad.events.agents.StopServicesRequestEvent;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.admin.EUEAdminEvent;
import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;
import de.dfki.lasad.events.eue.admin.config.EUEConfigInfoEvent;
import de.dfki.lasad.events.eue.admin.config.OntologyInfoEvent;
import de.dfki.lasad.events.eue.admin.config.OntologyListEvent;
import de.dfki.lasad.events.eue.admin.config.SessionListEvent;
import de.dfki.lasad.events.eue.admin.session.EUESessionInfoEvent;
import de.dfki.lasad.events.eue.admin.session.SessionOntologyInfoEvent;
import de.dfki.lasad.events.eue.admin.session.SessionToolsInfoEvent;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.meta.Ontology;
import de.dfki.lasad.util.ErrorUtil;

/**
 * Manages {@link Session} support ({@link #tryStartSession(String)} and
 * {@link #stopSession(String)}). Maintains two event queues, one for
 * {@link EUEAdminEvent}s and one for {@link UserEvent}s. Distributes
 * {@link EventImpl}s to the 'right' component (between {@link IDataService},
 * {@link Session}s and {@link EUEAuthorCommunicator}).
 * 
 * @author oliverscheuer
 * 
 */
public class SessionManager {

	private static Log logger = LogFactory.getLog(SessionManager.class);

	private String componentID = SessionManager.class.getName();

	// private boolean hasManager = false;
	private List<IAgent> sessionGeneralAgents = new Vector<IAgent>();
	// private CfManagementActionAgent managementAgent;

	private InitEUEConfig initialEUEConfig = new InitEUEConfig();
	// private Set<String> ontologiesToBeCompleted = null;
	private Map<String, Ontology> id2ontology = new HashMap<String, Ontology>();

	private Map<SessionID, Session> id2session = new HashMap<SessionID, Session>();

	private BlockingQueue<EUEAdminEvent> adminEventQueue = new LinkedBlockingQueue<EUEAdminEvent>();
	private Thread adminEventThread;

	private BlockingQueue<UserEvent> userEventQueue = new LinkedBlockingQueue<UserEvent>();
	private Thread userEventThread;

	private IDataService dataService;
	private ConfigurationManager configManager;

	private EUEAuthorCommunicator authorCommunicator;

	public SessionManager() {
		/**
		 * if (hasManager) { managementAgent = new CfManagementActionAgent(); }
		 */
		startEventThreads();
	}

	public void doWire(IDataService dataService,
			ConfigurationManager configManager) {
		this.dataService = dataService;
		this.configManager = configManager;
		this.authorCommunicator = new EUEAuthorCommunicator(this,
				configManager, dataService);
		this.dataService.addListener(this.authorCommunicator);
		this.configManager.getResourcesManager().addListener(
				this.authorCommunicator);
		this.configManager.getRuntimeManager().addListener(
				this.authorCommunicator);

		this.configManager.loadConf();

		// setUpManagementAgentIfPresent();
		//setUpSessionGeneralAgents();
	}

	/**
	 * private void setUpManagementAgentIfPresent() { try { AgentDescription
	 * managementAgentDescr = this.configManager
	 * .getResourcesManager().getAgentDescription( "xmpp-action-agent"); if
	 * (managementAgentDescr != null) { managementAgent =
	 * (CfManagementActionAgent) managementAgentDescr .createInstance();
	 * managementAgent.doWire(dataService, null);
	 * managementAgent.startService(); } } catch (Exception e) { logger.error(
	 * "[doWire] exception in configuration of managmentAgent, setting managementAgent to null, exception: \n"
	 * + ErrorUtil.getStackTrace(e)); }
	 * 
	 * }
	 */

	public void startService(){
		setUpSessionGeneralAgents();
	}
	
	private void setUpSessionGeneralAgents() {
		try {
			List<AgentDescription> agentDescrs = this.configManager
					.getSessionGeneralAgentDescriptions();
			for (AgentDescription aDescr : agentDescrs) {
				IAgent agent = (IAgent) aDescr.createInstance();
				agent.doWire(dataService, null);
				agent.startService();
				sessionGeneralAgents.add(agent);
			}
		} catch (Exception e) {
			logger.error("[doWire] exception in configuration of managmentAgent, setting managementAgent to null, exception: \n"
					+ ErrorUtil.getStackTrace(e));
		}
	}

	private final void startEventThreads() {
		adminEventThread = new Thread(new AdminEventConsumer(this));
		adminEventThread.start();

		userEventThread = new Thread(new UserEventConsumer(this));
		userEventThread.start();

	}

	public void onEvent(EUEEvent event) {
		for(IAgent agent: this.sessionGeneralAgents){
			agent.onEvent(event);
		}
		if (event instanceof EUEAdminEvent) {
			adminEventQueue.add((EUEAdminEvent) event);
		} else if (event instanceof UserEvent) {
			userEventQueue.add((UserEvent) event);
		}
	}

	public synchronized void tryStartSession(String sID) {
		try {
			logger.info("Try starting session '" + sID + "' ...");
			SessionID sIDObj = new SessionID(sID);
			Session s = id2session.get(sIDObj);
			if (s == null) {
				logger.warn("Cannot start session '" + sID
						+ "', does not exist.");
				return;
			}
			ServiceStatus statusBefore = s.getStatus();
			if (statusBefore == ServiceStatus.READY_TO_START) {
				boolean sessionStarted = s.tryStartServices();
				if (sessionStarted) {
					announceServiceStartToEUE(s);
					logger.info("Starting session '" + sID + "': DONE");
				}
			} else {
				logger.info("Cannot start session '" + sID
						+ "', service status = " + statusBefore);
			}
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}

	public synchronized void stopSession(String sID) {
		logger.info("Stopping session '" + sID + "' ...");
		SessionID sIDObj = new SessionID(sID);
		Session s = id2session.get(sIDObj);
		if (s == null) {
			logger.warn("Cannot stop session '" + sID + "', does not exist.");
			return;
		}
		ServiceStatus statusBefore = s.getStatus();
		if (statusBefore == ServiceStatus.RUNNING) {
			announceServiceStopToEUE(s);
			try {
				s.stopServices();
				logger.info("Stopping session '" + sID + "': DONE");
			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}
		} else {
			logger.warn("Cannot stop session '" + sID + "', service status = "
					+ statusBefore);
		}
	}

	public List<Session> getSessions() {
		List<Session> sessions = new Vector<Session>(id2session.values());
		return sessions;
	}

	public List<Ontology> getOntologies() {
		List<Ontology> ontologies = new Vector<Ontology>(id2ontology.values());
		return ontologies;
	}

	private void announceServiceStartToEUE(Session s) {
		List<ServiceType> servicesToPublish = s.getActiveRuntime()
				.getServicesToPublish();
		StartServicesRequestEvent startServicesEvent = new StartServicesRequestEvent(
				s.getID(), componentID);
		startServicesEvent.setServices(servicesToPublish);
		dataService.onOutEvent(startServicesEvent);
	}

	private void announceServiceStopToEUE(Session s) {
		StopServicesRequestEvent stopServicesEvent = new StopServicesRequestEvent(
				s.getID(), componentID);
		dataService.onOutEvent(stopServicesEvent);
	}

	private synchronized void processUserEvent(UserEvent event) {
		SessionID sID = event.getSessionID();
		if (sID != null) {
			Session s = id2session.get(sID);
			ServiceStatus status = s.getStatus();
			if (status == ServiceStatus.RUNNING) {
				s.onEvent(event);
			} else {
				logger.warn("Session '" + sID.getIdAsString()
						+ "' is not running (status=" + status
						+ "). Cannot process UserEvent '" + event.toString()
						+ "'.");
			}
		}
	}

	private void processAdminEvent(EUEAdminEvent event) {
		
		if (event instanceof EUEConfigInfoEvent) {
			EUEConfigInfoEvent confInfoEv = (EUEConfigInfoEvent) event;
			handleConfigInfoEvent(confInfoEv);
		} else if (event instanceof EUESessionInfoEvent) {
			EUESessionInfoEvent sessionInfoEv = (EUESessionInfoEvent) event;
			handleSessionInfoEvent(sessionInfoEv);
		} else if (event instanceof EUEAgentAdminEvent) {
			EUEAgentAdminEvent agentAdminEv = (EUEAgentAdminEvent) event;
			handleAgentAdminEvent(agentAdminEv);
		}
	}

	private void handleSessionInfoEvent(EUESessionInfoEvent sessionInfoEvent) {
		try {
			SessionID sID = sessionInfoEvent.getSessionID();
			Session s = id2session.get(sID);
			if (s == null) {
				s = new Session(sessionInfoEvent.getSessionID());
				s.addListener(this.authorCommunicator);
				s.doWire(dataService, configManager);
				id2session.put(sID, s);
			}
			if (!s.isComplete()) {
				if (sessionInfoEvent instanceof SessionOntologyInfoEvent) {
					SessionOntologyInfoEvent ontoInfoEvent = (SessionOntologyInfoEvent) sessionInfoEvent;
					s.setOntology(ontoInfoEvent.getOntology());
				}

				else if (sessionInfoEvent instanceof SessionToolsInfoEvent) {
					SessionToolsInfoEvent toolsInfoEvent = (SessionToolsInfoEvent) sessionInfoEvent;
					s.setToolContext(toolsInfoEvent.getToolContext());
				}
				if (s.isComplete()) {
					tryStartSession(sID.getIdAsString());
					initialEUEConfig.setSessionInitialized(sID.getIdAsString());
					tryStartingAgentAdminUpdatingService();
					if (initialEUEConfig.areSessionsComplete()) {
						List<String> sessionStrings = new Vector<String>();
						for (Session session : id2session.values()) {
							sessionStrings.add(session.toSimpleString());
						}
						logger.info("Sessions instantiated: " + sessionStrings);
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}

	private void handleConfigInfoEvent(EUEConfigInfoEvent configInfoEvent) {

		if (configInfoEvent instanceof SessionListEvent) {
			SessionListEvent sessionListEvent = (SessionListEvent) configInfoEvent;
			List<String> sessionsToInitialize = sessionListEvent
					.getSessionIDs();
			initialEUEConfig.setSessionsToInitialize(sessionsToInitialize);
			tryStartingAgentAdminUpdatingService();
		} else if (configInfoEvent instanceof OntologyListEvent) {
			OntologyListEvent ontoIDListEvent = (OntologyListEvent) configInfoEvent;
			Set<String> ontologiesToBeInitialized = new HashSet<String>();
			for (String ontologyID : ontoIDListEvent.getOntologyIDs()) {
				ontologiesToBeInitialized.add(ontologyID);
			}
			initialEUEConfig
					.setOntologiesToInitialize(ontologiesToBeInitialized);
			tryStartingAgentAdminUpdatingService();
		} else if (configInfoEvent instanceof OntologyInfoEvent) {
			OntologyInfoEvent ontoEvent = (OntologyInfoEvent) configInfoEvent;
			Ontology ontology = ontoEvent.getOntology();
			String ontologyID = ontology.getOntologyID();
			if (initialEUEConfig.waitingForOntologyCompletion(ontologyID)) {
				id2ontology.put(ontologyID, ontology);
				initialEUEConfig.setOntologyInitialized(ontologyID);
				tryStartingAgentAdminUpdatingService();
				if (initialEUEConfig.areOntologiesComplete()) {
					logger.info("Ontologies instantiated: "
							+ id2ontology.values().toString());
				}
			} else {
				logger.warn("Ontology is already initialized: " + ontologyID);
			}
		}
	}

	private void tryStartingAgentAdminUpdatingService() {
		if (this.initialEUEConfig.initializationComplete()) {
			authorCommunicator.startUpdatingService();
		}
	}

	private void handleAgentAdminEvent(EUEAgentAdminEvent agentAdminEvent) {
		authorCommunicator.processAgentAdminEvent(agentAdminEvent);
	}

	class UserEventConsumer implements Runnable {

		SessionManager manager;

		public UserEventConsumer(SessionManager manager) {
			this.manager = manager;
		}

		@Override
		public void run() {
			try {
				do {
					UserEvent event = userEventQueue.take();
					processUserEvent(event);
				} while (true);
			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}
		}
	}

	class AdminEventConsumer implements Runnable {

		SessionManager sessionManager;

		public AdminEventConsumer(SessionManager manager) {
			this.sessionManager = manager;
		}

		@Override
		public void run() {
			try {
				do {
					EUEAdminEvent event = adminEventQueue.take();
					processAdminEvent(event);
				} while (true);
			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}
		}

	}

}
