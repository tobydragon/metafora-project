package de.dfki.lasad.agents.instances.deeploop;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.graphdrawing.graphml.xmlns.x1.GraphmlDocument;

import de.dfki.argunaut.deeploop.api.ClassifierDescription;
import de.dfki.argunaut.deeploop.api.datamodel.Classification;
import de.dfki.argunaut.deeploop.api.datamodel.Classifications;
import de.dfki.argunaut.deeploop.api.exceptions.WSException;
import de.dfki.argunaut.deeploop.service.wsclient.ClassifierProxy;
import de.dfki.lasad.agents.AbstractAgent;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.AnalyzableEntity;
import de.dfki.lasad.agents.data.analysis.BinaryResult;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.ServiceType;
import de.dfki.lasad.agents.instances.deeploop.graphml.GraphMLDocumentFactory;
import de.dfki.lasad.agents.instances.deeploop.preprocessing.FlatGraphModeler;
import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.IComponent;
import de.dfki.lasad.core.components.instance.ServiceStatus;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.AnalysisResultEvent;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.data.EUEID;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.objects.EUEObjectID;

/**
 * {@link IAgent} implementation that supports the provision of feedback to
 * users based on machine learned classifiers, accessed through the DeepLoop
 * classification webservice.
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent}, {@link IAgent}, {@link AbstractAgent})
 * 
 * @author oliverscheuer
 * 
 */
public class DeepLoopAnalysisAgent extends AbstractAgent {

	Log logger = LogFactory.getLog(DeepLoopAnalysisAgent.class);

	private DeepLoopAnalysisAgentConfiguration conf;

	private ClassifierProxy classifierService;

	FlatGraphModeler graphModel = null;

	@Override
	public void configure(AbstractComponentDescription description)
			throws ComponentInitException {

		super.configure(description);
		conf = (DeepLoopAnalysisAgentConfiguration) description
				.getConfiguration();
		serviceStatus = ServiceStatus.UNDER_CONSTRUCTION;
	}

	/**
	 * 
	 */
	@Override
	public void startService() {
		try {
			setServiceStatus(ServiceStatus.STARTING);
			logger.info("Start service for session: " + sessionID + "...");
			String serviceAddress = conf.getWsAddress();
			classifierService = new ClassifierProxy(serviceAddress);

			Collection<ClassifierDescription> classifierDescriptions = classifierService
					.getClassifiers(Locale.getDefault(), Locale.getDefault());

			for (ClassifierDescription classifierDescription : classifierDescriptions) {
				logger.debug("Available classifiers"
						+ classifierDescription.getId());
			}
			super.startService();
			setServiceStatus(ServiceStatus.RUNNING);
			logger.info("... service started (" + sessionID + ")");
		} catch (WSException e) {
			logger.error("Error while initiating " + getClass(), e);
		}
	}

	@Override
	public synchronized void stopService() {
		setServiceStatus(ServiceStatus.STOPPING);
		logger.info("Stop service for session: " + sessionID + "...");
		super.stopService();
		setServiceStatus(ServiceStatus.STALE);
		logger.info("... service stopped (" + sessionID + ")");
	}

	@Override
	public void processEvent(Event event) {

		if (event instanceof ObjectActionEvent) {
			ObjectActionEvent objectActionEvent = (ObjectActionEvent) event;
			if (graphModel == null) {
				// new session
				graphModel = new FlatGraphModeler(
						conf.getMappingConfiguration());
			}
			graphModel.executeEvent(objectActionEvent);

		} else if (event instanceof FeedbackRequestEvent) {
			FeedbackRequestEvent feedbackRequestEvent = (FeedbackRequestEvent) event;
			SessionID sessionID = feedbackRequestEvent.getSessionID();
			UserID userID = feedbackRequestEvent.getUserID();
			if (graphModel == null) {
				// TODO throw exception
				logger.warn("Analysis Request without any previous "
						+ "UserObjectActionEvent in session " + sessionID);
				// new session
				graphModel = new FlatGraphModeler(
						conf.getMappingConfiguration());
			}

			graphModel.updateFlatRepresentations();
			GraphmlDocument graphMLDoc = GraphMLDocumentFactory.fillGML(
					sessionID, graphModel);

			ServiceType dType = resolveRequestedType(feedbackRequestEvent);

			if (dType instanceof AnalysisType) {
				AnalysisType aType = (AnalysisType) dType;
				Map<AnalysisType, List<AnalysisResult>> allResults = new HashMap<AnalysisType, List<AnalysisResult>>();

				Vector<AnalysisResult> resultsOfOneClassifier = requestAnalysisResults(
						aType, graphMLDoc);
				allResults.put(aType, resultsOfOneClassifier);

				AnalysisResultEvent resultEvent = new AnalysisResultEvent(
						sessionID, description.getComponentID(), allResults);

				sendRawResultsToEUE(resultEvent, userID);
			}
		}
	}

	private Vector<AnalysisResult> requestAnalysisResults(AnalysisType aType,
			GraphmlDocument graphMLDoc) {

		Vector<AnalysisResult> results = new Vector<AnalysisResult>();
		try {
			Classifications classifications = classifierService
					.applyClassifier(aType.getTypeID(), graphMLDoc);

			for (Classification classification : classifications
					.getClassifications()) {
				BinaryResult result = createAnalysisResult(aType,
						classification);
				results.add(result);
			}
		} catch (Exception e) {
			logger.error("Applying classifier '" + aType.getTypeID()
					+ "' failed.", e);
		}
		return results;
	}

	private BinaryResult createAnalysisResult(AnalysisType analysisType,
			Classification classification) {
		Boolean classificationResult = Classification.POSITIVE
				.equals(classification.getClassification());
		AnalyzableEntity analyzedEntity = createAnalyzableEntity(classification);

		BinaryResult result = new BinaryResult(analysisType, analyzedEntity,
				classificationResult);
		return result;
	}

	private AnalyzableEntity createAnalyzableEntity(
			Classification classification) {
		Collection<String> objectIDs = classification.getInstance()
				.getObjectIds();
		List<EUEID> eueIDList = new Vector<EUEID>();
		for (String id : objectIDs) {
			eueIDList.add(new EUEObjectID(id));
		}
		AnalyzableEntity analyzableEntity = new AnalyzableEntity(eueIDList);
		return analyzableEntity;
	}

}
