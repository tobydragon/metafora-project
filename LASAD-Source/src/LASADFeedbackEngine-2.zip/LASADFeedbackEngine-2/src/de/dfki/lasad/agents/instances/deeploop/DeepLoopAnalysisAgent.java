package de.dfki.lasad.agents.instances.deeploop;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.ServiceStatus;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.graphdrawing.graphml.xmlns.x1.GraphmlDocument;

import de.dfki.argunaut.deeploop.api.ClassifierDescription;
import de.dfki.argunaut.deeploop.api.datamodel.Classification;
import de.dfki.argunaut.deeploop.api.datamodel.Classifications;
import de.dfki.argunaut.deeploop.api.exceptions.WSException;
import de.dfki.argunaut.deeploop.service.wsclient.ClassifierProxy;
import de.dfki.lasad.agents.AbstractAgent;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.AnalysisResultIDGenerator;
import de.dfki.lasad.agents.data.analysis.object.AnalyzableEntity;
import de.dfki.lasad.agents.data.analysis.object.ObjectBinaryResult;
import de.dfki.lasad.agents.instances.deeploop.graphml.GraphMLDocumentFactory;
import de.dfki.lasad.agents.instances.deeploop.preprocessing.FlatGraphModeler;
import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.IComponent;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.AnalysisResultsProvisionEvent;
import de.dfki.lasad.events.agents.OnRequestServiceSpec;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.SessionConfig;
import de.dfki.lasad.session.data.EUEID;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.objects.EUEObjectID;

/**
 * {@link IAgent} implementation that supports the provision of feedback to
 * users based on machine learned classifiers, accessed through the DeepLoop
 * classification webservice.
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent}, {@link IAgent}, {@link AbstractAgent})
 * 
 * @author oliverscheuer
 * 
 */
public class DeepLoopAnalysisAgent extends AbstractAgent {

	Log logger = LogFactory.getLog(DeepLoopAnalysisAgent.class);

	private DeepLoopAnalysisAgentConfiguration conf;

	private ClassifierProxy classifierService;

	FlatGraphModeler graphModel = null;

	@Override
	public void init(AbstractComponentDescription description,
			SessionConfig sessionConfig) throws ComponentInitException {

		super.init(description, sessionConfig);
		conf = (DeepLoopAnalysisAgentConfiguration) description
				.getConfiguration();
		serviceStatus = ServiceStatus.UNDER_CONSTRUCTION;
	}

	/**
	 * 
	 */
	@Override
	public void startServiceImpl() {
		try {
			String serviceAddress = conf.getWsAddress();
			classifierService = new ClassifierProxy(serviceAddress);

			Collection<ClassifierDescription> classifierDescriptions = classifierService
					.getClassifiers(Locale.ENGLISH, Locale.ENGLISH);

			for (ClassifierDescription classifierDescription : classifierDescriptions) {
				logger.debug("Available classifier: "
						+ classifierDescription.getId());
			}
			super.startServiceImpl();
		} catch (WSException e) {
			logger.error("Error while initiating " + getClass(), e);
		}
	}

	@Override
	protected void stopServiceImpl() {
		super.stopServiceImpl();
	}

	@Override
	public List<OnRequestServiceSpec> getTypesToPublish() {
		return conf.getTypesToPublish();
	}

	@Override
	public void processEvent(Event event) {

		if (event instanceof ObjectActionEvent) {
			ObjectActionEvent objectActionEvent = (ObjectActionEvent) event;
			if (graphModel == null) {
				// new session
				graphModel = new FlatGraphModeler(
						conf.getMappingConfiguration());
			}
			graphModel.executeEvent(objectActionEvent);

		} else if (event instanceof FeedbackRequestEvent) {
			FeedbackRequestEvent feedbackRequestEvent = (FeedbackRequestEvent) event;
			SessionID sessionID = feedbackRequestEvent.getSessionID();
			UserID userID = feedbackRequestEvent.getUserID();
			if (graphModel == null) {
				// TODO throw exception
				logger.warn("Analysis Request without any previous "
						+ "UserObjectActionEvent in session " + sessionID);
				// new session
				graphModel = new FlatGraphModeler(
						conf.getMappingConfiguration());
			}

			graphModel.updateFlatRepresentations();
			GraphmlDocument graphMLDoc = GraphMLDocumentFactory.fillGML(
					sessionID, graphModel);

			ServiceID provisionServiceID = feedbackRequestEvent
					.getFeedbackRequestSpec().getRequestedServiceID();

			AnalysisType aType = conf
					.getRequestedAnalysisType(provisionServiceID);

			Map<ServiceID, List<AnalysisResult>> allResults = new HashMap<ServiceID, List<AnalysisResult>>();

			Vector<AnalysisResult> resultsOfOneClassifier = requestAnalysisResults(
					aType, graphMLDoc);
			allResults.put(aType.getServiceID(), resultsOfOneClassifier);

			AnalysisResultsProvisionEvent resultEvent = new AnalysisResultsProvisionEvent(
					sessionID, description.getComponentID(), allResults);

			sendRawResultsToEUE(resultEvent, userID);

		}
	}

	private Vector<AnalysisResult> requestAnalysisResults(AnalysisType aType,
			GraphmlDocument graphMLDoc) {

		Vector<AnalysisResult> results = new Vector<AnalysisResult>();
		try {
			Classifications classifications = classifierService
					.applyClassifier(aType.getServiceID().getTypeID(),
							graphMLDoc);

			for (Classification classification : classifications
					.getClassifications()) {
				ObjectBinaryResult result = createAnalysisResult(aType,
						classification);
				results.add(result);
			}
		} catch (Exception e) {
			logger.error("Applying classifier '"
					+ aType.getServiceID().getTypeID() + "' failed.", e);
		}
		return results;
	}

	private ObjectBinaryResult createAnalysisResult(AnalysisType analysisType,
			Classification classification) {
		Boolean classificationResult = Classification.POSITIVE
				.equals(classification.getClassification());
		AnalyzableEntity analyzedEntity = createAnalyzableEntity(classification);
		ObjectBinaryResult result = new ObjectBinaryResult(analysisType,
				analyzedEntity, classificationResult);
		activeRuntime.getModel().addProcessData(result);
		result.setId(AnalysisResultIDGenerator.getFreshID());
		return result;
	}

	private AnalyzableEntity createAnalyzableEntity(
			Classification classification) {
		Collection<String> objectIDs = classification.getInstance()
				.getObjectIds();
		List<EUEID> eueIDList = new Vector<EUEID>();
		for (String id : objectIDs) {
			eueIDList.add(new EUEObjectID(id));
		}
		AnalyzableEntity analyzableEntity = new AnalyzableEntity(eueIDList);
		return analyzableEntity;
	}

}
