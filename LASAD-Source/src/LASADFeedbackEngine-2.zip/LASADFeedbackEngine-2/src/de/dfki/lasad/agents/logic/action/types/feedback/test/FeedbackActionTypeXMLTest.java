package de.dfki.lasad.agents.logic.action.types.feedback.test;

import java.io.File;

import lasad.shared.dfki.meta.agents.action.feedback.FeedbackActionType;

import org.jdom.Element;

import de.dfki.lasad.agents.logic.action.types.feedback.FeedbackActionTypeXML;
import de.dfki.lasad.util.ClasspathResourceUtil;
import de.dfki.lasad.util.XMLUtil;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class FeedbackActionTypeXMLTest {

	public static void main(String[] args) {
		reGenerateAndPrintXML("testcase-1.xml");
		reGenerateAndPrintXML("testcase-2.xml");
	}

	public static void reGenerateAndPrintXML(String localFilename) {
		System.out.println(localFilename);
		System.out.println("-----------------");
		String filePathCase = ClasspathResourceUtil
				.getAbsoluteFilepathFromResourceOnClasspath(
						FeedbackActionTypeXMLTest.class, localFilename);

		FeedbackActionType type = parseFile(filePathCase);
		// System.out.println(type);
		String xmlString = toXMLString(type);
		System.out.println(xmlString);
	}

	public static FeedbackActionType parseFile(String absPathXML) {
		try {

			File file = new File(absPathXML);
			Element elem = XMLUtil.file2xmlElem(file);
			return FeedbackActionTypeXML.fromXML("FEEDBACK-AGENT", elem);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String toXMLString(FeedbackActionType feedbackType) {
		try {

			Element elem = FeedbackActionTypeXML.toXML(feedbackType);
			return XMLUtil.xmlElem2docString(elem);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
