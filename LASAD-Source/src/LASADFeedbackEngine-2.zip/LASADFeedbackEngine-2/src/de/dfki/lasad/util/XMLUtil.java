package de.dfki.lasad.util;

import java.io.File;
import java.io.FileWriter;
import java.io.StringReader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.DocType;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.jdom.output.Format.TextMode;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class XMLUtil {

	private static Log logger = LogFactory.getLog(XMLUtil.class);

	/**
	 * 
	 * @param elem
	 * @return an XML document represented as String object
	 */
	public static String xmlElem2docString(Element elem) {
		Format format = Format.getPrettyFormat();
		format.setTextMode(TextMode.PRESERVE);
		XMLOutputter o = new XMLOutputter(format);
		Document doc = new Document();
		doc.setRootElement(elem);
		return o.outputString(doc);
	}

	/**
	 * 
	 * @param docAsString
	 *            String object representation of XML document
	 * @return JDOM root element of parsed XML document
	 */
	public static Element string2xmlElem(String docAsString) {
		try {
			SAXBuilder builder = new SAXBuilder();
			StringReader sReader = new StringReader(docAsString);
			Document doc = builder.build(sReader);
			return doc.getRootElement();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	/**
	 * 
	 * @param docAsFile
	 *            File object containing XML document
	 * @return JDOM root element of parsed XML document
	 */
	public static Element file2xmlElem(File docAsFile) {
		try {
			SAXBuilder builder = new SAXBuilder();
			Document doc = builder.build(docAsFile);
			return doc.getRootElement();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	/**
	 * Writes given XML element as root element of a newly created XML document
	 * to a file
	 * 
	 * @param targetfile
	 *            File object to which XML document is written
	 * @param elem
	 *            JDOM element to be written to a file
	 */
	public static void xmlElem2File(File targetfile, Element elem) {
		try {
			Document doc = new Document();
			doc.setRootElement(elem);
			xmlDoc2File(targetfile, doc);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * Writes given XML element as root element of a newly created XML document
	 * to a file
	 * 
	 * @param targetfile
	 *            File object to which XML document is written
	 * @param elem
	 *            JDOM element to be written to a file
	 */
	public static void xmlDoc2File(File targetfile, Document doc) {
		try {
			Format format = Format.getPrettyFormat();
			format.setTextMode(TextMode.PRESERVE);
			XMLOutputter o = new XMLOutputter(format);
			FileWriter fw = new FileWriter(targetfile);
			o.output(doc, fw);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * 
	 * @return XML String to represent entity declaration
	 */
	public static String getXMLEntityString(String entityName, String systemID) {
		return "<!ENTITY " + entityName + " SYSTEM \"" + systemID + "\">";
	}

	public static void main(String[] args) {
		XMLOutputter o = new XMLOutputter(Format.getPrettyFormat());
		Document doc = new Document();
		doc.setRootElement(new Element("root"));
		DocType docType = new DocType("rule_entities");
		doc.setDocType(docType);
		String entityString = getXMLEntityString("R99", "./aaaa/R99.xml");
		docType.setInternalSubset(entityString);

		System.out.println(o.outputString(doc));
	}
}
