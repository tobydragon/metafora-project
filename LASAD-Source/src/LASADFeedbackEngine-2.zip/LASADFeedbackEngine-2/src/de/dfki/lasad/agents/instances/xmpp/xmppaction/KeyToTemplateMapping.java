package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import de.uds.xml.XmlConfigParser;
import de.uds.xml.XmlFragment;
import de.uds.xml.XmlFragmentInterface;

public class KeyToTemplateMapping {
	Logger logger = Logger.getLogger(this.getClass());
	
	Map<String, String> keyToTemplateMap;
	
	String defaultTemplate;
	
	public KeyToTemplateMapping(String filename){
		defaultTemplate = "Discussing-Microworlds-3";
		keyToTemplateMap = new HashMap<String, String>();
		
		XmlFragmentInterface config = XmlFragment.getFragmentFromFile(filename);
		for (XmlFragmentInterface key : config.getChildren("KEY")){
			String id = key.getChildValue("ID").trim();
			String template = key.getChildValue("TEMPLATE").trim();
			if (id.equals("Default")){
				defaultTemplate = template;
			}
			else {
				keyToTemplateMap.put(id, template);
			}
		}
	}
	
	public String getTemplate(String key){
		String template = keyToTemplateMap.get(key);
		if (template == null){
			logger.info("[getTemplate] no template found for key: " + key + ", using default: " + defaultTemplate);
			return defaultTemplate;
		}
		return template;
	}
	
	public String getDefaultTemplate(){
		return defaultTemplate;
	}

}
