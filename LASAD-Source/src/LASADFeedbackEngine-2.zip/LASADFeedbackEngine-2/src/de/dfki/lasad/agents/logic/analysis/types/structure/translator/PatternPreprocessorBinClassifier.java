package de.dfki.lasad.agents.logic.analysis.types.structure.translator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Operator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2SetOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2SomethingComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2StringOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Something2SetComparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2SetOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import lasad.shared.dfki.meta.agents.analysis.structure.model.VariableComparison;
import lasad.shared.dfki.meta.ontology.Ontology;
import lasad.shared.dfki.meta.ontology.descr.PropDescr;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PatternPreprocessorBinClassifier {

	private Ontology ontology = null;

	public PatternPreprocessorBinClassifier(Ontology ontology) {
		this.ontology = ontology;
	}

	public void addBinClassifications(StructuralPattern pattern) {
		addBinClassifications(pattern.getNodeVars());
		addBinClassifications(pattern.getLinkVars());
	}

	/**
	 * Index data structure that classifies Comparisons into 20 bins for later
	 * processing
	 * 
	 * @param elemVars
	 */
	private void addBinClassifications(List<? extends ElementVariable> elemVars) {

		for (ElementVariable elemVar : elemVars) {
			Map<Bin, Map<ElementVariableProp, List<Comparison>>> bin2elemProp2comparisons = new HashMap<Bin, Map<ElementVariableProp, List<Comparison>>>();

			for (Comparison comp : elemVar.getComparisons()) {
				ComparisonClassification classifier = new ComparisonClassification();
				Bin bin = classifier.getBin(comp);
				comp.getSupplData().setBin(bin);
				addComparisonToBin(comp, bin, bin2elemProp2comparisons);
			}
			elemVar.getSupplData().setBin2propVars2Comparisons(
					bin2elemProp2comparisons);
		}
	}

	private void addComparisonToBin(
			Comparison c,
			Bin bin,
			Map<Bin, Map<ElementVariableProp, List<Comparison>>> bin2elemProp2comparisons) {

		ElementVariableProp propVar = c.getLeftExpr();

		Map<ElementVariableProp, List<Comparison>> elemProp2comparisons = bin2elemProp2comparisons
				.get(bin);
		if (elemProp2comparisons == null) {
			elemProp2comparisons = new HashMap<ElementVariableProp, List<Comparison>>();
			bin2elemProp2comparisons.put(bin, elemProp2comparisons);
		}
		List<Comparison> comparisons = elemProp2comparisons.get(propVar);
		if (comparisons == null) {
			comparisons = new ArrayList<Comparison>();
			elemProp2comparisons.put(propVar, comparisons);
		}
		comparisons.add(c);
	}

	private class ComparisonClassification {

		final int REPR_CONST = 1;
		final int REPR_IN_ELEM = 2;
		final int REPR_OUT_ELEM = 3;

		final int TYPE_SCALAR = 1;
		final int TYPE_SET = 2;

		private int leftRepresentation;
		private int rightRepresentation;
		private int leftType;
		private int rightType;
		private Operator operator;

		private void extractRelevantData(Comparison comp) {
			// left representation
			ElementVariableProp leftPropVar = comp.getLeftExpr();
			PropDescr leftPropDescr = leftPropVar.getElementVar().getPropDescr(
					ontology, leftPropVar.getPropId());

			if (leftPropDescr.isInJessElementFact()) {
				leftRepresentation = REPR_IN_ELEM;
			} else {
				leftRepresentation = REPR_OUT_ELEM;
			}

			// right representation
			rightRepresentation = REPR_CONST;
			if (comp instanceof VariableComparison) {
				VariableComparison varComp = (VariableComparison) comp;
				ElementVariableProp rightExpr = varComp.getRightExpr();
				PropDescr rightPropDescr = rightExpr.getElementVar()
						.getPropDescr(ontology, rightExpr.getPropId());
				if (rightPropDescr.isInJessElementFact()) {
					rightRepresentation = REPR_IN_ELEM;
				} else {
					rightRepresentation = REPR_OUT_ELEM;
				}
			}

			if (comp instanceof Set2SomethingComparison) {
				leftType = TYPE_SET;
			} else {
				leftType = TYPE_SCALAR;
			}

			if (comp instanceof Something2SetComparison) {
				rightType = TYPE_SET;
			} else {
				rightType = TYPE_SCALAR;
			}

			operator = comp.getOperator();
		}

		public Bin getBin(Comparison comp) {
			extractRelevantData(comp);

			boolean column_1_or_3 = (leftRepresentation == REPR_IN_ELEM);
			boolean column_1_or_2 = (leftType == TYPE_SCALAR);
			boolean column_2 = (leftRepresentation == REPR_OUT_ELEM && leftType == TYPE_SCALAR);
			boolean column_3 = (leftRepresentation == REPR_IN_ELEM && leftType == TYPE_SET);
			boolean column_4 = (leftRepresentation == REPR_OUT_ELEM && leftType == TYPE_SET);
			boolean row_4 = (rightRepresentation == REPR_CONST && rightType == TYPE_SET);
			boolean row_5 = (rightRepresentation == REPR_IN_ELEM && rightType == TYPE_SET);
			boolean row_6 = (rightRepresentation == REPR_OUT_ELEM && rightType == TYPE_SET);
			boolean not_row_6 = !row_6;

			boolean bin3_operator = (operator
					.equals(Set2StringOperator.CONTAINS)
					|| operator.equals(Set2SetOperator.INTERSECT) || operator
					.equals(Set2SetOperator.NOT_SUBSET));

			boolean bin4_operator = (operator
					.equals(Set2StringOperator.NOT_CONTAINS)
					|| operator.equals(Set2SetOperator.NOT_INTERSECT) || operator
					.equals(Set2SetOperator.SUBSET));

			boolean bin5_operator = (operator.equals(String2SetOperator.IN) || operator
					.equals(Set2SetOperator.NOT_SUPERSET));

			boolean bin6_operator = (operator.equals(String2SetOperator.NOT_IN) || operator
					.equals(Set2SetOperator.SUPERSET));

			boolean bin7_operator = (operator
					.equals(Set2SetOperator.NOT_SUBSET));

			boolean bin8_operator = (operator.equals(Set2SetOperator.INTERSECT));

			boolean bin9_operator = (operator
					.equals(Set2SetOperator.NOT_INTERSECT));

			boolean bin10_operator = (operator.equals(Set2SetOperator.SUBSET));

			boolean bin11_operator = (operator
					.equals(Set2SetOperator.NOT_SUPERSET));

			boolean bin12_operator = (operator.equals(Set2SetOperator.SUPERSET));

			boolean bin13_operator = (operator
					.equals(Set2SetOperator.NOT_SUBSET));

			boolean bin14_operator = (operator
					.equals(Set2SetOperator.INTERSECT));

			boolean bin15_operator = (operator
					.equals(Set2SetOperator.NOT_INTERSECT));

			boolean bin16_operator = (operator.equals(Set2SetOperator.SUBSET));

			boolean bin17_operator = (operator
					.equals(Set2SetOperator.NOT_SUPERSET));

			boolean bin18_operator = (operator.equals(Set2SetOperator.SUPERSET));

			boolean bin19_operator = (operator.equals(Set2SetOperator.SUPERSET));

			boolean bin20_operator = (operator
					.equals(Set2SetOperator.NOT_SUPERSET));

			if (column_1_or_3 && not_row_6)
				return Bin.BIN_1;
			if (column_2 && not_row_6)
				return Bin.BIN_2;
			if (column_4 && not_row_6 && bin3_operator)
				return Bin.BIN_3;
			if (column_4 && not_row_6 && bin4_operator)
				return Bin.BIN_4;
			if (column_1_or_2 && row_6 && bin5_operator)
				return Bin.BIN_5;
			if (column_3 && row_6 && bin5_operator)
				return Bin.BIN_5;
			if (column_1_or_2 && row_6 && bin6_operator)
				return Bin.BIN_6;
			if (column_3 && row_6 && bin6_operator)
				return Bin.BIN_6;
			if (column_4 && row_6) {
				if (bin7_operator)
					return Bin.BIN_7;
				if (bin8_operator)
					return Bin.BIN_8;
				if (bin9_operator)
					return Bin.BIN_9;
				if (bin10_operator)
					return Bin.BIN_10;
				if (bin11_operator)
					return Bin.BIN_11;
				if (bin12_operator)
					return Bin.BIN_12;
			}
			if (column_3 && row_6) {
				if (bin13_operator)
					return Bin.BIN_13;
				if (bin14_operator)
					return Bin.BIN_14;
				if (bin15_operator)
					return Bin.BIN_15;
				if (bin16_operator)
					return Bin.BIN_16;
			}
			if (column_4 && row_5) {
				if (bin17_operator)
					return Bin.BIN_17;
				if (bin18_operator)
					return Bin.BIN_18;
			}
			if (column_4 && row_4) {
				if (bin19_operator)
					return Bin.BIN_19;
				if (bin20_operator)
					return Bin.BIN_20;
			}
			return null;
		}
	}
}
