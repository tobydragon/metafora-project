package de.dfki.lasad.core.components.collections;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import de.dfki.lasad.core.components.description.AgentDescription;

/**
 * a set of {@link AgentDescription}s
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescriptions {

	private Map<String, AgentDescription> agentDescriptions = new HashMap<String, AgentDescription>();

	public Set<String> getAgentDescriptionIDs() {
		return agentDescriptions.keySet();
	}

	public Collection<AgentDescription> getAgentDescriptions() {
		return agentDescriptions.values();
	}

	public AgentDescription getAgentDescription(String id) {
		return agentDescriptions.get(id);
	}

	public void addOrUpdateDescription(AgentDescription descr) {
		agentDescriptions.put(descr.getComponentID(), descr);
	}

	public void removeDescription(String agentID) {
		agentDescriptions.remove(agentID);
	}

	public boolean contains(String agentID) {
		return agentDescriptions.containsKey(agentID);
	}

	@Override
	public String toString() {
		return "AgentDescriptions [agentDescriptions=" + agentDescriptions
				+ "]";
	}

}
