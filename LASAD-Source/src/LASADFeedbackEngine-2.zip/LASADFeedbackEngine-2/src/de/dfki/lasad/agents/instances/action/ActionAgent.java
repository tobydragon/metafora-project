package de.dfki.lasad.agents.instances.action;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.ServiceType;
import lasad.shared.dfki.meta.agents.analysis.phases.PhaseModelerDef;
import lasad.shared.dfki.meta.agents.provision.ProvisionTimeDef;
import lasad.shared.dfki.meta.agents.provision.ProvisionTimeDef_OnRequest;
import lasad.shared.dfki.meta.agents.provision.ProvisionType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.AbstractAgent;
import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.instances.TaskScheduler;
import de.dfki.lasad.agents.instances.action.processors.ResultProcessorManager;
import de.dfki.lasad.agents.instances.action.tasks.ActionTask;
import de.dfki.lasad.agents.instances.action.tasks.ActionTask_ProcessAnalysisResult;
import de.dfki.lasad.agents.instances.action.tasks.ActionTask_ProcessFeedbackRequest;
import de.dfki.lasad.agents.instances.action.tasks.ActionTask_ProcessModelChange;
import de.dfki.lasad.agents.instances.action.tasks.ActionTask_ProcessUserJoinsSession;
import de.dfki.lasad.agents.instances.action.tasks.ActionTask_ProcessUserLeavesSession;
import de.dfki.lasad.agents.logic.provision.actiongen.AnalysisMsgGenerator;
import de.dfki.lasad.agents.logic.provision.actiongen.FeedbackMsgGenerator;
import de.dfki.lasad.agents.logic.provision.actionhistory.MsgProvisionHistory;
import de.dfki.lasad.agents.logic.provision.phases.PhaseModelerFactory;
import de.dfki.lasad.agents.logic.provision.phases.PhaseModelerInterface;
import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.events.agents.OnRequestServiceSpec;
import de.dfki.lasad.events.agents.SessionModelChangedEvent;
import de.dfki.lasad.events.agents.SessionModelChangedListener;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestEvent;
import de.dfki.lasad.events.eue.user.feedback.FeedbackRequestSpec;
import de.dfki.lasad.events.eue.user.join.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.user.join.UserLeaveSessionEvent;
import de.dfki.lasad.session.SessionActiveRuntime;
import de.dfki.lasad.session.SessionConfig;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.UserIDAll;
import de.dfki.lasad.sessionmodel.SessionModelChangeRecord;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ActionAgent extends AbstractAgent implements
		SessionModelChangedListener, TaskScheduler {

	private Log logger = LogFactory.getLog(ActionAgent.class);

	PhaseModelerInterface phaseModeler = null;
	MsgProvisionHistory msgHistory = null;
	ResultProcessorManager resultProcessor = null;
	AnalysisMsgGenerator analysisMsgGen = null;
	FeedbackMsgGenerator actionMsgGen = null;

	private String debugPrefix = null;

	private boolean timerStarted = false;
	private Timer timer = new Timer(true);

	private Map<Integer, List<ActionTask>> targetResult2ActionTasks = new HashMap<Integer, List<ActionTask>>();

	private Set<UserID> currentlyActiveUsers = new HashSet<UserID>();

	public ActionAgent() {
		super();
	}

	@Override
	public void init(AbstractComponentDescription description,
			SessionConfig sessionConfig) throws ComponentInitException {
		super.init(description, sessionConfig);
		msgHistory = new MsgProvisionHistory();

		ActionAgentConfig fConfig = (ActionAgentConfig) description
				.getConfiguration();
		this.debugPrefix = "(" + fConfig.getAgentID() + ") - ";

		initPhaseModeler(fConfig.getPhaseModelerDef(),
				description.getComponentID(), sessionConfig);

		resultProcessor = new ResultProcessorManager();
		resultProcessor.init(fConfig, sessionConfig, msgHistory, phaseModeler,
				this);

		analysisMsgGen = new AnalysisMsgGenerator(description.getComponentID(),
				sessionConfig.getSessionID());
		actionMsgGen = new FeedbackMsgGenerator(description.getComponentID(),
				sessionConfig.getSessionID());

	}

	private void initPhaseModeler(PhaseModelerDef phaseModelerDef,
			String agentID, SessionConfig sessionConfig) {
		phaseModeler = PhaseModelerFactory.createPhaseModeler(phaseModelerDef,
				agentID, sessionConfig);
	}

	@Override
	public void doWire(IDataService dataService,
			SessionActiveRuntime activeRuntime) {
		activeRuntime.getModel().register(this);
		super.doWire(dataService, activeRuntime);
	}

	/**
	 * Initialize timer and replay all events that have been collected until
	 * now.
	 * 
	 * @Override
	 */
	protected void startServiceImpl() {
		// super-method not called since general event thread not needed
		replayEvents();
		timerStarted = true;
		logger.info(debugPrefix + "service started (" + sessionID + ")");
	}

	@Override
	protected void stopServiceImpl() {
		// super-method not called since general event thread not used
		timer.cancel();
		logger.info(debugPrefix + "service stopped (" + sessionID + ")");
	}

	public List<OnRequestServiceSpec> getTypesToPublish() {

		List<OnRequestServiceSpec> servicesToPublish = new Vector<OnRequestServiceSpec>();
		for (ServiceType sType : getServiceTypes()) {
			if (sType instanceof ProvisionType) {
				ProvisionType pType = (ProvisionType) sType;
				ProvisionTimeDef provTime = pType.getProvisionTime();
				if (provTime instanceof ProvisionTimeDef_OnRequest) {
					ProvisionTimeDef_OnRequest provTimeOnRequest = (ProvisionTimeDef_OnRequest) provTime;
					String displayName = provTimeOnRequest.getDisplayName();
					OnRequestServiceSpec onRequestSpec = new OnRequestServiceSpec(
							sType.getServiceID(), displayName);
					servicesToPublish.add(onRequestSpec);
				}
			}
		}
		return servicesToPublish;
	}

	@Override
	public void onSessionModelChanged(SessionModelChangedEvent event) {
		onEvent(event);
	}

	@Override
	public void onEvent(Event event) {
		if (timerStarted) {
			issueTimerTask(event);
		} else {
			super.onEvent(event);
		}
	}

	protected void replayEvents() {
		try {
			while (!eventQueue.isEmpty()) {
				Event event = eventQueue.take();
				issueTimerTask(event);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	public void scheduleAnalysisTask(AnalysisResult result, long delay) {
		logger.debug(debugPrefix + "Schedule task to (re-)check result in "
				+ delay + "ms (" + result.toSimpleString() + ")...");
		Integer targetResultID = result.getId();
		List<ActionTask> tasks = targetResult2ActionTasks.get(targetResultID);
		if (tasks == null) {
			tasks = new Vector<ActionTask>();
			targetResult2ActionTasks.put(targetResultID, tasks);
		}
		ActionTask_ProcessAnalysisResult task = new ActionTask_ProcessAnalysisResult(
				this, result);
		tasks.add(task);
		scheduleTask(task, delay);

	}

	private void scheduleTask(ActionTask task, long delay) {
		timer.schedule(task, delay);
	}

	@Override
	public void cancelTasks(Integer targetResultID) {
		List<ActionTask> tasks = targetResult2ActionTasks.get(targetResultID);
		if (tasks != null) {
			for (ActionTask task : tasks) {
				logger.debug(debugPrefix + "Task cancelled: " + task
						+ "(result-id=" + targetResultID + ")");
				task.cancel();
			}
		}
	}

	public void processModelChanged(SessionModelChangeRecord changeRecord) {
		logger.debug(debugPrefix + "(processModelChanged): " + changeRecord);
		phaseModeler.processModelChanged(changeRecord);
		resultProcessor.processModelChanged(changeRecord);
	}

	public void processRecheckAnalysisResult(AnalysisResult result) {
		logger.debug(debugPrefix + "(processRecheckAnalysisResult): "
				+ result.toSimpleString());
		resultProcessor.reprocessAnalysisResult(result);
	}

	public void processUserJoinsSession(UserID uID) {
		logger.debug(debugPrefix + "(processUserJoinsSession): " + uID);
		currentlyActiveUsers.add(uID);
		resultProcessor.processUserJoin(uID);
	}

	public void processUserLeavesSession(UserID uID) {
		logger.debug(debugPrefix + "(processUserLeavesSession): " + uID);
		currentlyActiveUsers.remove(uID);
	}

	public void processProvision(UserServiceID userServiceID) {
		logger.debug(debugPrefix + "(processProvision): " + userServiceID);
		UserServiceID recipientService = resultProcessor
				.getRecipientUserServiceID(userServiceID);
		List<ActionTypeResult> results = resultProcessor
				.getResultsInOrder(recipientService);

		UserID recipientID = recipientService.getUserID();
		if (recipientID instanceof UserIDAll) {
			for (UserID uID : currentlyActiveUsers) {
				msgHistory.addRecords(uID, results);
			}
		} else {
			msgHistory.addRecords(recipientID, results);
		}
		ActionSpecEvent event = actionMsgGen.generateMsg(results, recipientID);
		sendActionsOut(event);
	}

	protected void issueTimerTask(Event event) {
		if (event instanceof SessionModelChangedEvent) {
			SessionModelChangedEvent smChangedEvent = (SessionModelChangedEvent) event;
			SessionModelChangeRecord changeRecord = smChangedEvent
					.getChangeRecord();
			ActionTask_ProcessModelChange task = new ActionTask_ProcessModelChange(
					this, changeRecord);
			scheduleTask(task, 0);
		} else if (event instanceof FeedbackRequestEvent) {
			FeedbackRequestEvent feedbackRequestEvent = (FeedbackRequestEvent) event;
			UserID requestor = feedbackRequestEvent.getUserID();
			FeedbackRequestSpec spec = feedbackRequestEvent
					.getFeedbackRequestSpec();
			ServiceID requestedServiceID = spec.getRequestedServiceID();

			if (this.getAgentDescription().getComponentID()
					.equals(requestedServiceID.getAgentID())) {

				UserServiceID userServiceID = new UserServiceID(requestor,
						requestedServiceID);
				ActionTask_ProcessFeedbackRequest task = new ActionTask_ProcessFeedbackRequest(
						this, userServiceID);
				scheduleTask(task, 0);
			} else {
				logger.debug(debugPrefix + "IGNORE FEEDBACK-REQUEST: "
						+ requestedServiceID);
			}
		} else if (event instanceof UserJoinSessionEvent) {
			UserJoinSessionEvent joinEvent = (UserJoinSessionEvent) event;
			UserID userID = joinEvent.getUserID();
			ActionTask_ProcessUserJoinsSession task = new ActionTask_ProcessUserJoinsSession(
					this, userID);
			scheduleTask(task, 0);
		} else if (event instanceof UserLeaveSessionEvent) {
			UserLeaveSessionEvent leaveEvent = (UserLeaveSessionEvent) event;
			UserID userID = leaveEvent.getUserID();
			ActionTask_ProcessUserLeavesSession task = new ActionTask_ProcessUserLeavesSession(
					this, userID);
			scheduleTask(task, 0);
		} else {
			logger.debug("(issueTimerTask) Unhandled event type: " + event);
		}
	}

	protected void sendActionsOut(ActionSpecEvent actionSpecEvent) {
		logger.debug(debugPrefix + "Send out message: "
				+ actionSpecEvent.getAgentActions());
		sendActionsToEUE(actionSpecEvent);
	}

	@Override
	protected void processEvent(Event event) {
		// nothing to do (events are handled by timer thread)
	}

}
