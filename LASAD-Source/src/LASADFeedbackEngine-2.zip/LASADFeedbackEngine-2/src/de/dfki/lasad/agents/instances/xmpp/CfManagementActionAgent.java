package de.dfki.lasad.agents.instances.xmpp;

import java.util.Date;
import java.util.Iterator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.instances.xmpp.xmppaction.CfActionDuringExecution;
import de.dfki.lasad.agents.instances.xmpp.xmppaction.CfManagementAction;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.eue.admin.session.ManagementResponseEvent;

public class CfManagementActionAgent extends CfAbstractAgent{
	
	Log logger = LogFactory.getLog(this.getClass());

	public CfManagementActionAgent(){
		this(true);
		logger.info("XmppManagementActionAgent created at" + new Date());
	}
	
	//special constructor to allow for disabled xmpp agent for testing
	CfManagementActionAgent(boolean connectToSource){
		super(connectToSource);
	}
	
	//synchronized to avoid issues with actionsWaitingForResponse list
	@Override
	public synchronized void processEvent(Event event) {
		if (event instanceof ManagementResponseEvent){
			checkForManagementResponses((ManagementResponseEvent)event);
		}
		else {
			logger.error("[processEvent] non-management event submitted - " + event);
		}
	}
	
	private void checkForManagementResponses(ManagementResponseEvent mEvent){
		Iterator<CfActionDuringExecution> actionsToCheck = actionsWaitingForResponse.iterator();
		logger.debug("[checkForManagementResponses] event - " + mEvent.toString() );
	
		boolean actionFound = false;
		while (!actionFound && actionsToCheck.hasNext()){
			CfActionDuringExecution actionToCheck = actionsToCheck.next();
			if (actionToCheck instanceof CfManagementAction){
				CfManagementAction managementActionToCheck = (CfManagementAction) actionToCheck;
				if (managementActionToCheck.eventIsResponseToMe(mEvent)){
					actionFound = true;
					actionsToCheck.remove();
					managementActionToCheck.moveToResponsePhase(mEvent);
					sendCfActionsOut(actionToCheck);
				}
			}
		}		
	}
	
}