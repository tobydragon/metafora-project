package de.dfki.lasad.agents.logic.analysis.types.structure.translator;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.agents.analysis.structure.model.LinkVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.NodeVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import lasad.shared.dfki.meta.ontology.Ontology;
import lasad.shared.dfki.meta.ontology.descr.LastTsPropDescr;
import lasad.shared.dfki.meta.ontology.descr.ModifiersPropDescr;
import lasad.shared.dfki.meta.ontology.descr.PropDescr;
import lasad.shared.dfki.meta.ontology.descr.StandardPropDescr;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PatternTranslator {

	private Ontology ontology = null;

	private PatternPreprocessor preprocessor = null;
	private JessIDAndSlotNameGenerator idgen = null;
	private JessConstValDeffactGenerator constGen = null;
	private JessClauseGenerator clauseGen = null;

	public static final String INDENT_L0 = "";
	public static final String INDENT_L1 = "  ";
	public static final String INDENT_L2 = "     ";

	public PatternTranslator(Ontology ontology) {
		this.ontology = ontology;

		this.preprocessor = new PatternPreprocessor(ontology);
		this.idgen = new JessIDAndSlotNameGenerator(ontology);
		constGen = new JessConstValDeffactGenerator(ontology, idgen);
		clauseGen = new JessClauseGenerator(ontology, idgen);
	}

	public void testModeOmitSequentialization(boolean setting) {
		preprocessor.testModeOmitSequentialization = setting;
	}

	/**
	 * 
	 * @param id
	 *            needed to generate RHS of Jess rule (agent id and analysis
	 *            type)
	 * @param pattern
	 *            needed to generate LHS of Jess rule (Jess pattern expression)
	 * 
	 * @return
	 */
	public String generateJessRule(ServiceID id, StructuralPattern pattern) {
		String agentID = id.getAgentID();
		StringBuffer result = new StringBuffer();
		result.append(";; PATTERN-ID: " + pattern.getID() + "\n");

		preprocessor.preprocess(pattern);

		result.append(Indent.apply(generateImports() + "\n\n", INDENT_L0));
		result.append(Indent.apply(";; ----- CONSTANT FACTS -----" + "\n",
				INDENT_L0));
		String constValClause = generateConstValDeffacts(agentID, pattern);
		if (constValClause.length() == 0) {
			result.append(Indent.apply(";; -- NONE --\n\n", INDENT_L0));
		} else {
			result.append(Indent.apply(constValClause + "\n\n", INDENT_L0));
		}

		result.append(";; ----- RULE DEFINITION ----- " + "\n");
		result.append(Indent.apply("(defrule " + pattern.getID() + "\n",
				INDENT_L0));
		result.append(Indent.apply("(logical" + "\n", INDENT_L1));

		result.append(Indent.apply(
				generateJessPattern(agentID, pattern) + "\n", INDENT_L2));

		String notExpressions = generateJessNotPattern(agentID, pattern);
		if (notExpressions.length() > 0) {
			result.append(Indent.apply(notExpressions + "\n", INDENT_L2));
		}
		// result.append(Indent.apply(")", INDENT_L2));
		result.append(Indent.apply(") =>" + "\n", INDENT_L2));
		result.append(Indent.apply(generateRuleRHS(id, pattern), INDENT_L1));

		return result.toString();
	}

	private String generateRuleRHS(ServiceID id, StructuralPattern pattern) {
		StringBuffer buf = new StringBuffer();

		String idSlot = ("(id (call AnalysisResultIDGenerator getFreshID))");
		String agentSlot = ("(agent_id \"[##AGENT-ID##]\")");
		String typeSlot = ("(type \"" + id.getTypeID() + "\")");

		List<ElementVariable> elemIDs = new Vector<ElementVariable>();
		for (NodeVariable nodeVar : pattern.getNodeVars()) {
			elemIDs.add(nodeVar);
		}
		for (LinkVariable linkVar : pattern.getLinkVars()) {
			elemIDs.add(linkVar);
		}

		String entitySlot = null;
		String lastModTsSlot = null;
		String contributorsSlot = null;
		if (elemIDs.size() > 0) {
			entitySlot = "(entity_ids ";
			Iterator<ElementVariable> iter = elemIDs.iterator();
			while (iter.hasNext()) {
				ElementVariable elemVar = iter.next();
				entitySlot += idgen.generateElemIDVar(elemVar);
				if (iter.hasNext()) {
					entitySlot += " ";
				}
			}
			entitySlot += ")";

			lastModTsSlot = "(last_mod_ts (max ";
			iter = elemIDs.iterator();
			while (iter.hasNext()) {
				ElementVariable elemVar = iter.next();
				ElementVariableProp elemPropVar = elemVar.getPropVar(
						LastTsPropDescr.PROP_ID,
						StandardPropDescr.DEFAULT_COMPONENT_ID);
				String elemPropVarString = idgen.generatePropVarID(elemPropVar,
						0, false, false);
				lastModTsSlot += elemPropVarString;
				if (iter.hasNext()) {
					lastModTsSlot += " ";
				}
			}
			lastModTsSlot += "))";

			contributorsSlot = "(contributors (union$ ";
			iter = elemIDs.iterator();
			while (iter.hasNext()) {
				ElementVariable elemVar = iter.next();
				ElementVariableProp elemPropVar = elemVar.getPropVar(
						ModifiersPropDescr.PROP_ID,
						StandardPropDescr.DEFAULT_COMPONENT_ID);
				String elemPropVarString = idgen.generatePropVarID(elemPropVar,
						0, false, false);
				contributorsSlot += elemPropVarString;
				if (iter.hasNext()) {
					contributorsSlot += " ";
				}
			}
			contributorsSlot += "))";
		}

		buf.append(Indent.apply("(assert (object-binary-result" + "\n",
				INDENT_L0));
		buf.append(Indent.apply(idSlot + "\n", INDENT_L1));
		buf.append(Indent.apply(agentSlot + "\n", INDENT_L1));
		buf.append(Indent.apply(typeSlot, INDENT_L1));

		if (elemIDs.size() > 0) {
			buf.append("\n");
			buf.append(Indent.apply(entitySlot + "\n", INDENT_L1));
			buf.append(Indent.apply(lastModTsSlot + "\n", INDENT_L1));
			buf.append(Indent.apply(contributorsSlot, INDENT_L1));
		}
		buf.append(")))");
		return buf.toString();
	}

	private String generateJessNotPattern(String agentID,
			StructuralPattern pattern) {
		StringBuffer result = new StringBuffer();
		Collection<StructuralPattern> notPatterns = pattern.getNotPatterns();
		Iterator<StructuralPattern> iter = notPatterns.iterator();
		while (iter.hasNext()) {
			StructuralPattern notPattern = iter.next();
			result.append(Indent.apply("\n", INDENT_L0));
			result.append(Indent.apply(";; NOT-PATTERN: " + notPattern.getID()
					+ "/" + notPattern.getSubID() + "\n", INDENT_L0));
			result.append(Indent.apply("(not(and" + "\n", INDENT_L0));
			result.append(Indent.apply(generateJessPattern(agentID, notPattern)
					+ "))", INDENT_L1));

			if (iter.hasNext()) {
				result.append(Indent.apply("\n", INDENT_L1));
			}
		}
		return result.toString();
	}

	private String generateJessPattern(String agentID, StructuralPattern pattern) {
		StringBuffer result = new StringBuffer();
		result.append(";; ----- NODES -----" + "\n");
		// result.append(";;;;;;;;;;; " + "\n");
		result.append(generateNodeConstrs(agentID, pattern));

		result.append(";; ----- LINKS -----" + "\n");
		// result.append(";;;;;;;;;;; " + "\n");
		result.append(generateLinkConstrs(agentID, pattern));
		return result.toString();
	}

	private String generateConstValDeffacts(String agentID,
			StructuralPattern pattern) {
		StringBuffer result = new StringBuffer();
		String patternConsts = constGen.generateConstValDeffacts(agentID,
				pattern);
		result.append(patternConsts);

		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			String notPatternConsts = constGen.generateConstValDeffacts(
					agentID, notPattern);
			if (result.length() > 0 && notPatternConsts.length() > 0) {
				result.append("\n");
				result.append(notPatternConsts);
			} else if (notPatternConsts.length() > 0) {
				result.append(notPatternConsts);
			}
		}
		return result.toString();
	}

	private String generateNodeConstrs(String agentID, StructuralPattern pattern) {
		return generateElemConstrs(agentID, pattern, pattern.getNodeVars());
	}

	private String generateLinkConstrs(String agentID, StructuralPattern pattern) {
		return generateElemConstrs(agentID, pattern, pattern.getLinkVars());
	}

	private String generateElemConstrs(String agentID,
			StructuralPattern pattern, List<? extends ElementVariable> elemVars) {
		StringBuffer result = new StringBuffer();

		boolean isNotPattern = false;
		if (pattern.getSubID() != null) {
			isNotPattern = true;
		}
		boolean bindLastTsAndModifiers = !isNotPattern;

		for (ElementVariable elemVar : elemVars) {
			List<? extends ElementVariable> predecessors;
			if (elemVar instanceof NodeVariable) {
				NodeVariable nodeVar = (NodeVariable) elemVar;
				predecessors = pattern.getNodePredecessors(nodeVar);

				result.append(";; ----- " + elemVar.getVarID()
						+ ": BIN-1-EXTERNAL -----" + "\n");
				String externalConstrsString = clauseGen
						.generateNodeExtConstrsClause(nodeVar, predecessors,
								bindLastTsAndModifiers);
				boolean externalConstrsExists = !""
						.equals(externalConstrsString);
				if (externalConstrsExists) {
					result.append(externalConstrsString + "\n\n");
				} else {
					result.append(";; -- NONE --" + "\n\n");
				}

				result.append(";; ----- " + elemVar.getVarID()
						+ ": PROP-FACTS VARIABLE BINDINGS -----" + "\n");
				String propVarBindingString = clauseGen
						.generatePropVarBindingClauses(nodeVar);
				boolean propVarBindingsExists = !""
						.equals(propVarBindingString);
				if (propVarBindingsExists) {
					result.append(propVarBindingString + "\n\n");
				} else {
					result.append(";; -- NONE --" + "\n\n");
				}

				result.append(";; ----- " + elemVar.getVarID()
						+ ": NEIGHBORHOOD CONSTRAINTS -----" + "\n");
				String neighborhoodConstrsString = clauseGen
						.generateNeighborhoodConstrs(nodeVar);
				boolean neighborhoodConstrsExists = !""
						.equals(neighborhoodConstrsString);
				if (neighborhoodConstrsExists) {
					result.append(neighborhoodConstrsString + "\n\n");
				} else {
					result.append(";; -- NONE --" + "\n\n");
				}

				result.append(";; ----- " + elemVar.getVarID()
						+ ": BIN-1-INTERNAL -----" + "\n");
				String internalConstrsString = clauseGen
						.generateNodeIntConstrsClause(nodeVar);
				boolean internalConstrsExists = !""
						.equals(internalConstrsString);
				if (internalConstrsExists) {
					result.append(internalConstrsString + "\n\n");
				} else {
					result.append(";; -- NONE --" + "\n\n");
				}

			} else {
				// LinkVariable
				LinkVariable linkVar = (LinkVariable) elemVar;
				predecessors = pattern.getLinkPredecessors(linkVar);

				result.append(";; ----- " + elemVar.getVarID()
						+ ": BIN-1-EXTERNAL -----" + "\n");
				String externalConstrsString = clauseGen
						.generateLinkExtConstrsClause(linkVar, predecessors,
								bindLastTsAndModifiers);
				boolean externalConstrsExists = !""
						.equals(externalConstrsString);
				if (externalConstrsExists) {
					result.append(externalConstrsString + "\n\n");
				} else {
					result.append(";; -- NONE --" + "\n\n");
				}

				result.append(";; ----- " + elemVar.getVarID()
						+ ": NEIGHBORHOOD CONSTRAINTS -----" + "\n");
				String neighborhoodConstrsString = clauseGen
						.generateNeighborhoodConstrs(linkVar);
				boolean neighborhoodConstrsExists = !""
						.equals(neighborhoodConstrsString);
				if (neighborhoodConstrsExists) {
					result.append(neighborhoodConstrsString + "\n\n");
				} else {
					result.append(";; -- NONE --" + "\n\n");
				}

				result.append(";; ----- " + elemVar.getVarID()
						+ ": PROP-FACTS VARIABLE BINDINGS -----" + "\n");
				String propVarBindingString = clauseGen
						.generatePropVarBindingClauses(linkVar);
				boolean propVarBindingsExists = !""
						.equals(propVarBindingString);
				if (propVarBindingsExists) {
					result.append(propVarBindingString + "\n\n");
				} else {
					result.append(";; -- NONE --" + "\n\n");
				}

				result.append(";; ----- " + elemVar.getVarID()
						+ ": BIN-1-INTERNAL -----" + "\n");
				String internalConstrsString = clauseGen
						.generateLinkIntConstrsClause(linkVar);
				boolean internalConstrsExists = !""
						.equals(internalConstrsString);
				if (internalConstrsExists) {
					result.append(internalConstrsString + "\n\n");
				} else {
					result.append(";; -- NONE --" + "\n\n");
				}

			}

			for (PropDescr prop : elemVar.getPropDescrs(ontology)) {

				StringBuffer propResult = new StringBuffer();

				String clause = clauseGen.generatePropClauses(elemVar, prop);
				addClause(propResult, clause);

				clause = clauseGen.generatePropExistsClauses(elemVar, prop);
				addClause(propResult, clause);

				clause = clauseGen.generatePropForallClauses(elemVar, prop);
				addClause(propResult, clause);

				clause = clauseGen.generateRefPropExistsClauses(elemVar, prop);
				addClause(propResult, clause);

				clause = clauseGen.generateRefPropForallClauses(elemVar, prop);
				addClause(propResult, clause);

				clause = clauseGen.generatePropExistsForallClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generatePropExistsExistsClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generatePropForallForallClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generatePropForallExistsClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generateRefPropExistsForallClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generateRefPropForallExistsClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generateElemExistsForallClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generateElemExistsExistsClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generateElemForallForallClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generateElemForallExistsClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generateRefElemExistsForallClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generateRefElemForallExistsClauses(elemVar,
						prop);
				addClause(propResult, clause);

				clause = clauseGen.generateRefConstForallExistsClauses(agentID,
						pattern, elemVar, prop);
				addClause(propResult, clause);

				clause = clauseGen.generateRefConstExistsForallClauses(agentID,
						pattern, elemVar, prop);
				addClause(propResult, clause);

				String propClauses = propResult.toString();
				if (!"".equals(propClauses)) {
					result.append(propClauses);
				}

			}
		}
		return result.toString();
	}

	private void addClause(StringBuffer aggregator, String clause) {
		if (!"".equals(clause)) {
			aggregator.append(clause + "\n\n");
		}
	}

	private String generateRuleID(String agentID, StructuralPattern p) {
		return agentID + "// " + p.getID();
	}

	private String generateImports() {
		return "(require datastructures-basic-NEW)";
	}

}
