package de.dfki.lasad.authoring.model;

import org.jdom.Element;

import de.dfki.lasad.util.XMLUtil;

/**
 * an agent description (to be used in the graphical frontend).
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescriptionFE {

	private String agentID;
	private String displayName = null;

	private boolean confReadable = false;
	private boolean confWritable = false;

	private String supportedOntology = null;
	private AgentConfigFE agentConf = null;

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public boolean isConfReadable() {
		return confReadable;
	}

	public void setConfReadable(boolean confReadable) {
		this.confReadable = confReadable;
	}

	public boolean isConfWritable() {
		return confWritable;
	}

	public void setConfWritable(boolean confWritable) {
		this.confWritable = confWritable;
	}

	public String getSupportedOntology() {
		return supportedOntology;
	}

	public void setSupportedOntology(String supportedOntology) {
		this.supportedOntology = supportedOntology;
	}

	public AgentConfigFE getAgentConf() {
		return agentConf;
	}

	public void setAgentConf(AgentConfigFE agentConf) {
		this.agentConf = agentConf;
	}

	public Element toXMLElem() {
		Element descrsElem = new Element(ElementStrings.AGENT_DESCRIPTION);

		Element elem = new Element(ElementStrings.AGENT_ID);
		elem.setText(agentID);
		descrsElem.addContent(elem);

		elem = new Element(ElementStrings.DISPLAY_NAME);
		elem.setText(displayName);
		descrsElem.addContent(elem);

		elem = new Element(ElementStrings.CONF_READABLE);
		elem.setText(confReadable + "");
		descrsElem.addContent(elem);

		elem = new Element(ElementStrings.CONF_WRITEABLE);
		elem.setText(confWritable + "");
		descrsElem.addContent(elem);

		elem = new Element(ElementStrings.SUPPORTED_ONTOLOGY);
		elem.setText(supportedOntology);
		descrsElem.addContent(elem);

		if (agentConf != null) {
			descrsElem.addContent(agentConf.toXMLElem());
		}

		return descrsElem;
	}

	public static AgentDescriptionFE fromXMLElem(Element xml) {
		AgentDescriptionFE agentDescrFE = new AgentDescriptionFE();

		Element elem = (Element) xml.getChild(ElementStrings.AGENT_ID);
		agentDescrFE.setAgentID(elem.getText());
		elem = (Element) xml.getChild(ElementStrings.DISPLAY_NAME);
		agentDescrFE.setDisplayName(elem.getText());
		elem = (Element) xml.getChild(ElementStrings.CONF_READABLE);
		agentDescrFE.setConfReadable(Boolean.parseBoolean(elem.getText()));
		elem = (Element) xml.getChild(ElementStrings.CONF_WRITEABLE);
		agentDescrFE.setConfWritable(Boolean.parseBoolean(elem.getText()));
		elem = (Element) xml.getChild(ElementStrings.SUPPORTED_ONTOLOGY);
		agentDescrFE.setAgentID(elem.getText());
		elem = (Element) xml.getChild(ElementStrings.SUPPORTED_ONTOLOGY);
		agentDescrFE.setAgentID(elem.getText());
		elem = (Element) xml.getChild(ElementStrings.AGENT);
		agentDescrFE.setAgentConf(AgentConfigFE.fromXMLElem(elem));

		return agentDescrFE;
	}

	public String toXMLString() {
		Element e = toXMLElem();
		return XMLUtil.xmlElem2docString(e);
	}

	public static AgentDescriptionFE fromXMLString(String xml) {
		Element e = XMLUtil.string2xmlElem(xml);
		return fromXMLElem(e);
	}

	@Override
	public String toString() {
		return "AgentDescriptionFE [agentID=" + agentID + ", displayName="
				+ displayName + ", confReadable=" + confReadable
				+ ", confWritable=" + confWritable + ", supportedOntology="
				+ supportedOntology + ", agentConf=" + agentConf + "]";
	}

}
