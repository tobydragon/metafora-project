package de.dfki.lasad.agents.logic.analysis.types.structure.translator;

import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariable;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.ontology.Ontology;
import lasad.shared.dfki.meta.ontology.descr.JessDataType;
import lasad.shared.dfki.meta.ontology.descr.PropDescr;

/**
 * Generates IDs, to be used within Jess, in a uniform way.
 * 
 * @author oliverscheuer
 * 
 */
public class JessIDAndSlotNameGenerator {

	public static final int NO_APPENDIX = -1;

	private Ontology ontology = null;

	public JessIDAndSlotNameGenerator(Ontology ontology) {
		this.ontology = ontology;
	}

	public String generateConstantFactID(String agentID, String patternID,
			int constNumID) {
		return "const//" + agentID + "//" + patternID + "//" + constNumID;
	}

	public String generateConstantFactValueTempVar(int constNumID) {
		return "?const//" + constNumID;
	}

	public String generateElemIDVar(ElementVariable elemVar) {
		return "?elem//" + elemVar.getVarID();
	}

	public String generateElemIDTempVar(ElementVariable elemVar, int appendixNum) {
		return "?elem//" + elemVar.getVarID() + "//" + appendixNum;
	}

	public String generateNodeInNeigborsVar(ElementVariable elemVar) {
		return "$?inneighbors//" + elemVar.getVarID();
	}

	public String generateNodeOutNeigborsVar(ElementVariable elemVar) {
		return "$?outneighbors//" + elemVar.getVarID();
	}

	public String generateNodeNeigborsVar(ElementVariable elemVar) {
		return "$?neighbors//" + elemVar.getVarID();
	}

	public String generatePropVarID(ElementVariableProp propVar,
			int appendixNum, boolean useAppendix, boolean listElem) {

		ElementVariable elemVar = propVar.getElementVar();
		PropDescr prop = propVar.getPropDescr(ontology);

		String baseID = "prop//";
		if (prop.hasOnlySingleComponent()) {
			baseID = baseID + elemVar.getVarID() + "//" + propVar.getPropId();
		} else {
			baseID = baseID + elemVar.getVarID() + "//" + propVar.getPropId()
					+ "//" + propVar.getCompID();
		}

		String prefix = "";
		if (listElem) {
			prefix = "?";
		} else {
			JessDataType jessDataType = prop.getSlotDataType(propVar
					.getCompID());
			prefix = (jessDataType.equals(JessDataType.LIST)) ? "$?" : "?";
		}

		String appendix = "";
		if (useAppendix) {
			appendix = "//c" + appendixNum;
		}

		return prefix + baseID + appendix;
	}

	/**
	 * Generate slot name for property based on {@link Ontology}
	 * 
	 * @param propVar
	 * @return
	 */
	public String generateSlotName(ElementVariableProp propVar) {
		PropDescr prop = propVar.getPropDescr(ontology);
		String slotName = prop.getJessSlot(propVar.getCompID());
		return slotName;
	}

}
