package de.dfki.lasad.sessionmodel.jessfunctions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jess.Context;
import jess.Funcall;
import jess.JessException;
import jess.RU;
import jess.Userfunction;
import jess.Value;
import jess.ValueVector;

/**
 * Sort a ValueVector or java.util.List object.
 * <P>
 * Created on Dec 7, 2004
 * </P>
 * 
 * @author George A. Williamson Jr. (Ihfe020)
 * @author �Union Pacific Railroad
 * 
 * 
 */
public class ListSort implements Userfunction {

	/** Create a new Sort user function object */
	public ListSort() {
		super();
	}

	/**
	 * Get the name of the sort user function
	 * 
	 * @see jess.Userfunction#getName()
	 */
	public String getName() {
		return "sort";
	}

	/** Get a value from the Java Object */
	private Value getValue(Object o) {
		try {
			if (o instanceof Value) {
				return (Value) o;
			} else if (o instanceof Integer) {
				return new Value(((Integer) o).intValue(), RU.INTEGER);
			} else if (o instanceof Long) {
				return new Value(((Long) o).intValue(), RU.LONG);
			} else if (o instanceof Float) {
				return new Value(((Float) o).doubleValue(), RU.FLOAT);
			} else if (o instanceof Double) {
				return new Value(((Double) o).doubleValue(), RU.FLOAT);
			} else if (o instanceof Short) {
				return new Value(((Short) o).intValue(), RU.INTEGER);
			} else if (o instanceof String) {
				return new Value(((String) o), RU.STRING);
			}
		} catch (Exception e) {
		}
		return new Value(o);
	}

	/**
	 * Call the sort ValueVector user function
	 * 
	 * @see jess.Userfunction#call(jess.ValueVector, jess.Context)
	 */
	public Value call(ValueVector vv, final Context context)
			throws JessException {
		if (vv.size() != 3) {
			throw new JessException(
					getName(),
					getName()
							+ " takes exactly two arguments, the multifield to "
							+ "sort and the name of the comparison function for the sort",
					vv.size() - 1);
		}

		// Get the list to sort
		List list = null;
		Value v = vv.get(1).resolveValue(context);
		if (v.type() == RU.LIST) {
			ValueVector vector = vv.get(1).listValue(context);
			list = new ArrayList(vector.size());
			for (int i = 0; i < vector.size(); i++) {
				list.add(vector.get(i));
			}
		} else if (v.type() == RU.JAVA_OBJECT
				&& v.javaObjectValue(context) instanceof List) {
			list = (List) v.javaObjectValue(context);
		} else {
			throw new JessException(getName(), "Unable to sort list",
					"The first argument should be a list or multifield value");
		}

		// Get the comparator object
		Comparator comparator = null;
		v = vv.get(2).resolveValue(context);
		if (v.type() == RU.JAVA_OBJECT
				&& v.javaObjectValue(context) instanceof Comparator) {
			comparator = (Comparator) v.javaObjectValue(context);
		} else if (v.type() == RU.STRING || v.type() == RU.SYMBOL) {
			final String sortFunction = v.stringValue(context);
			comparator = new Comparator() {
				public int compare(Object o1, Object o2) {
					try {
						Funcall f = new Funcall(sortFunction,
								context.getEngine());
						f.arg(getValue(o1));
						f.arg(getValue(o2));
						Value retValue = f.execute(context);
						return retValue.intValue(context);
					} catch (JessException e) {
						throw new IllegalArgumentException(e.getMessage());
					}
				}
			};
		} else {
			throw new JessException(
					getName(),
					"Unable to sort list",
					"The second argument should be a comparison function "
							+ "that determines the order of elements in the list");
		}

		try {
			Collections.sort(list, comparator);
		} catch (IllegalArgumentException e) {
			throw new JessException(
					getName(),
					"Unable to sort multifield, error on call to comparison function",
					e);
		}

		ValueVector retValueVector = new ValueVector(list.size());
		for (int i = 0; i < list.size(); i++) {
			Object o = list.get(i);
			if (o instanceof Value) {
				retValueVector.add((Value) list.get(i));
			} else {
				retValueVector.add(new Value(list.get(i)));
			}
		}
		return new Value(retValueVector, RU.LIST);
	}

}
