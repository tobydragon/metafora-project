package de.dfki.lasad.session;

import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ConfigurationManager;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.IComponent;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.core.components.instance.ISessionModel;
import de.dfki.lasad.core.components.instance.ServiceStatus;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.agents.state.AFStateChangedEventListener;
import de.dfki.lasad.events.agents.state.RuntimeChangedEvent;
import de.dfki.lasad.session.data.*;
import de.dfki.lasad.session.data.meta.Ontology;
import de.dfki.lasad.session.data.meta.ToolContext;
import de.dfki.lasad.sessionmodel.SessionModel;

/**
 * Representation of a session in the EUE (including ID, {@link Ontology} and
 * {@link ToolContext}). This class provides methods to start and stop agent
 * support for the session ({@link #tryStartServices()} and
 * {@link #stopServices()}).
 * 
 * @author oliverscheuer
 * 
 */
public class Session {

	private Log logger = LogFactory.getLog(Session.class);

	private List<AFStateChangedEventListener> afStateChangedListeners = new Vector<AFStateChangedEventListener>();

	private SessionID sID;

	private IDataService dataService;
	private ConfigurationManager confManager;

	private Ontology ontology;
	private ToolContext toolContext;

	private SessionActiveRuntime activeRuntime = null;
	private ServiceStatus status = ServiceStatus.UNDER_CONSTRUCTION;

	public Session(SessionID sID) {
		this.sID = sID;
	}

	public void doWire(IDataService dataService,
			ConfigurationManager confManager) {
		this.dataService = dataService;
		this.confManager = confManager;
	}

	/**
	 * {@link IAgent}s and {@link SessionModel} are instantiated and started if
	 * at least one {@link IAgent} is configured for this {@link Session}.
	 * 
	 * @return if session will be started or not
	 * @throws Exception
	 */
	public synchronized boolean tryStartServices() throws Exception {
		logger.info("Try starting services for session: " + getID() + "...");
		List<AgentDescription> agentDescriptions = confManager
				.getSessionSpecificAgentDescriptions(this);
		if (agentDescriptions.size() > 0) {
			setServiceStatus(ServiceStatus.STARTING);
			activeRuntime = new SessionActiveRuntime(sID, ontology, toolContext);
			SessionModelDescription smDescr = confManager
					.getSessionModelDescription();
			activeRuntime.addAgentDescriptions(agentDescriptions);
			activeRuntime.setModelDescription(smDescr);

			ISessionModel model = (ISessionModel) smDescr.createInstance();
			// propagateListeners(model);
			model.doWire(activeRuntime);

			model.startService();
			activeRuntime.setModel(model);

			for (AgentDescription aDescr : agentDescriptions) {
				IAgent agent = (IAgent) aDescr.createInstance();
				// propagateListeners(agent);
				agent.doWire(dataService, activeRuntime);
				agent.startService();
				activeRuntime.addAgent(agent);
			}
			setServiceStatus(ServiceStatus.RUNNING);
			logger.info("... services started (" + getID() + "), status = "
					+ status);
			return true;
		}
		logger.info("... no services for session (" + getID() + "), status = "
				+ status);
		return false;
	}

	/**
	 * {@link IAgent}s and {@link SessionModel} are stopped and removed from
	 * session.
	 * 
	 * @return {@link ServiceStatus} after method completion.
	 * @throws Exception
	 */
	public synchronized void stopServices() throws Exception {
		setServiceStatus(ServiceStatus.STOPPING);
		logger.info("Stop services for session: " + getID() + "...");
		for (IAgent agent : activeRuntime.getAgents()) {
			agent.stopService();
		}
		activeRuntime.getModel().stopService();
		activeRuntime = null;
		setServiceStatus(ServiceStatus.READY_TO_START);
		logger.info("... services stopped (" + getID() + "), status = "
				+ status);
	}

	public synchronized void restartServices() throws Exception {
		stopServices();
		tryStartServices();
	}

	public ServiceStatus getStatus() {
		return status;
	}

	public synchronized void onEvent(EventImpl event) {
		activeRuntime.onEvent(event);
	}

	public boolean isComplete() {
		return (ontology != null && toolContext != null);
	}

	public SessionID getID() {
		return sID;
	}

	public Ontology getOntology() {
		return ontology;
	}

	public SessionActiveRuntime getActiveRuntime() {
		return activeRuntime;
	}

	public void setOntology(Ontology ontology) {
		this.ontology = ontology;
		if (isComplete()) {
			setServiceStatus(ServiceStatus.READY_TO_START);
		}
	}

	public ToolContext getToolContext() {
		return toolContext;
	}

	public void setToolContext(ToolContext toolContext) {
		this.toolContext = toolContext;
		if (isComplete()) {
			setServiceStatus(ServiceStatus.READY_TO_START);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sID == null) ? 0 : sID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Session other = (Session) obj;
		if (sID == null) {
			if (other.sID != null)
				return false;
		} else if (!sID.equals(other.sID))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Session [sID=" + sID + ", ontology=" + ontology
				+ ", toolContext=" + toolContext + ", status=" + status + "]";
	}

	public String toSimpleString() {
		return "Session [sID=" + sID + ", ontology=" + ontology.getOntologyID()
				+ ", status=" + status + "]";
	}

	private void setServiceStatus(ServiceStatus newStatus) {
		ServiceStatus oldStatus = this.status;
		this.status = newStatus;
		logger.info("Status changed: " + status + " (" + getID() + ", "
				+ getClass() + ")");
		notifyListenersStatusChanged(oldStatus, newStatus);
	}

	public void addListener(AFStateChangedEventListener l) {
		afStateChangedListeners.add(l);
	}

	private void notifyListenersStatusChanged(ServiceStatus oldS,
			ServiceStatus newS) {
		RuntimeChangedEvent runtimeChangedEv = new RuntimeChangedEvent(getID()
				.toString());
		runtimeChangedEv.setOldStatus(oldS);
		runtimeChangedEv.setNewStatus(newS);

		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(runtimeChangedEv);
		}
	}

	private void propagateListeners(IComponent iComponent) {
		for (AFStateChangedEventListener l : afStateChangedListeners) {
			iComponent.addListener(l);
		}
	}
}
