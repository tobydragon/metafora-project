package de.dfki.lasad.sessionmodel;

import java.io.Reader;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jess.Context;
import jess.Fact;
import jess.HasLHS;
import jess.Jesp;
import jess.JessException;
import jess.LongValue;
import jess.QueryResult;
import jess.RU;
import jess.Rete;
import jess.Value;
import jess.ValueVector;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.AnalyzableEntity;
import de.dfki.lasad.agents.data.analysis.BinaryResult;
import de.dfki.lasad.agents.data.analysis.NominalResult;
import de.dfki.lasad.agents.data.analysis.NumericalResult;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.RuleAnalysisType;
import de.dfki.lasad.core.DisplayedObjectIDTracker;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.instance.ServiceStatus;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.AnalysisRequestEvent;
import de.dfki.lasad.events.agents.AnalysisResultEvent;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.DeleteObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.SessionActiveRuntime;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;
import de.dfki.lasad.session.data.objects.ObjectProperty;
import de.dfki.lasad.sessionmodel.graphmodel.GraphElement;
import de.dfki.lasad.sessionmodel.graphmodel.GraphModel;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class SessionModelV2 extends AbstractSessionModel {

	private Log logger = LogFactory.getLog(SessionModelV2.class);

	protected static final boolean LOG_ALL_FACT_TO_CONSOLE_ON_UPDATE = true;
	protected static final boolean SHUTDOWN_AFTER_ERROR = false;

	protected Rete jessEngine;
	private GraphModel graphModel;
	private List<RuleAnalysisType> ruleTypes = new Vector<RuleAnalysisType>();

	public SessionModelV2() {
		jessEngine = new Rete();
		graphModel = new GraphModel();
	}

	@Override
	public void doWire(SessionActiveRuntime sessionRuntime) {
		super.doWire(sessionRuntime);
		graphModel.setSessionRuntime(sessionRuntime);
		setServiceStatus(ServiceStatus.READY_TO_START);
	}

	@Override
	public synchronized void startService() {
		try {
			setServiceStatus(ServiceStatus.STARTING);
			logger.info("Start service for session: " + this.sessionID + "...");

			prepareJessEngine();
			jessEngine.reset();

			// start event thread
			super.startService();

			// initial rule application
			jessEngine.run();
			if (LOG_ALL_FACT_TO_CONSOLE_ON_UPDATE) {
				for (Iterator<Fact> factIter = getWorkingMemoryFacts(); factIter
						.hasNext();) {
					logger.debug(factIter.next());
				}
			}
			setServiceStatus(ServiceStatus.RUNNING);
			logger.info("... service started (" + this.sessionID + ")");
		} catch (JessException e) {
			logger.error("startService() " + e.getClass(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	private void prepareJessEngine() {
		try {
			addBasicDefinitions();
			addOntologyBasedDefinitions();
			addAnnotationDefinitionsAndAnnotations();
			//addJessRules();
			addResultQueryDefinition();
		} catch (Exception e) {
			logger.error("prepareJessEngine" + e.getClass(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	protected void addBasicDefinitions() throws Exception {
		String datastructuresBasicBatch = configuration
				.getDatastructuresBasicNewBatch();
		String actionUpdateBatch = configuration.getActionUpdatesBatch();

		String functionsBatch = configuration.getFunctionsBatch();
		String analysisImplicitLinksBatch = configuration
				.getAnalysisImplicitLinksBatch();
		String analysisTranscriptBatch = configuration
				.getAnalysisTranscriptBatch();

		executeJessBatch(datastructuresBasicBatch);
		executeJessBatch(actionUpdateBatch);
		//executeJessBatch(analysisImplicitLinksBatch);
		//executeJessBatch(analysisTranscriptBatch);
		logger.info("Jess data structures and functions added to session '"
				+ this.sessionID + "'.");
	}

	@Override
	public synchronized void stopService() {
		try {
			setServiceStatus(ServiceStatus.STOPPING);
			logger.info("Stop service for session: " + sessionID + "...");
			jessEngine.halt();
			super.stopService();
			setServiceStatus(ServiceStatus.STALE);
			logger.info("... service stopped (" + sessionID + ")");
		} catch (Exception e) {
			logger.error("stopService() " + e.getClass(), e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
	}

	@Override
	public void registerAnalysisPattern(RuleAnalysisType ruleType) {
		logger.info("Registering analysis pattern: " + ruleType.getDefinition());
		ruleTypes.add(ruleType);
	}

	protected void addOntologyBasedDefinitions() throws Exception {
		String ontologyBasedDefinitionsBatch = configuration
				.getOntologyBasedDefinitions(this.activeRuntime.getOntology());
		if (ontologyBasedDefinitionsBatch == null) {
			logger.info("No Ontology-based definitions defined for session '"
					+ this.sessionID + "'.");
		} else {
			executeJessBatch(ontologyBasedDefinitionsBatch);
			logger.info("Ontology-based definitions added to session '"
					+ this.sessionID + "'.");
		}
	}

	protected void addAnnotationDefinitionsAndAnnotations() throws Exception {
		List<String> annotationsJessBatches = configuration
				.getAnnotationDefinitionsAndAnnotations(this.activeRuntime
						.getTools());

		for (String annotationsJessBatch : annotationsJessBatches) {
			executeJessBatch(annotationsJessBatch);
			logger.info("Annotations added to session '" + this.sessionID
					+ "'.");
		}
	}

	/**
	 * Add rules (analysis patterns) that can be applied to session.
	 * 
	 */
	protected void addJessRules() throws Exception {
		for (AgentDescription aDescr : this.activeRuntime
				.getAgentDescriptions().values()) {
			for (RuleAnalysisType rType : aDescr.getAnalysisRuleTypes()) {
				if (!ruleTypes.contains(rType)) {
					ruleTypes.add(rType);
				}
			}
		}
		for (RuleAnalysisType ruleType : ruleTypes) {
			String ruleDefinition = ruleType.getDefinition();
			executeJessBatch(ruleDefinition);
			logger.info("Rule definition added to session '" + this.sessionID
					+ "'.");
		}
	}

	protected void addResultQueryDefinition() throws Exception {
		String resultQueryDefinition = configuration.getResultQueryDefinition();
		executeJessBatch(resultQueryDefinition);
		logger.info("Result query added to session '" + this.sessionID + "'.");
	}

	protected void executeJessBatch(String batch) throws JessException {
		Reader r = new StringReader(batch);
		Jesp j = new Jesp(r, jessEngine);
		j.parse(false);
	}

	protected synchronized void executeUserActivityEvent(UserEvent userEvent) {
		try {
			boolean doRun = false;
			logger.debug("Execute event in session '" + this.sessionID + "': "
					+ userEvent.toString());

			if ((userEvent instanceof CreateObjectEvent)
					|| (userEvent instanceof ModifyObjectEvent)
					|| (userEvent instanceof DeleteObjectEvent)) {
				ObjectActionEvent objectEvent = (ObjectActionEvent) userEvent;
				String eventID = objectEvent.getEueEventID().getIdAsString();
				long ts = objectEvent.getTs();
				String userID = objectEvent.getUserID().getIdAsString();
				String eventType = null;
				if (userEvent instanceof CreateObjectEvent) {
					eventType = "CREATE";
				} else if (userEvent instanceof ModifyObjectEvent) {
					eventType = "MODIFY";
				} else if (userEvent instanceof DeleteObjectEvent) {
					eventType = "DELETE";
				}

				List<EUEObject> objects = objectEvent.getEueObjectList();
				for (EUEObject object : objects) {
					boolean insert = true;
					Fact actionFact = new Fact("action", jessEngine);

					actionFact
							.setSlotValue("id", new Value(eventID, RU.STRING));
					actionFact.setSlotValue("type", new Value(eventType,
							RU.STRING));
					actionFact.setSlotValue("actor", new Value(userID,
							RU.STRING));
					actionFact.setSlotValue("ts", new LongValue(ts));

					String objectID = object.getID().getIdAsString();
					actionFact.setSlotValue("elem_id", new Value(objectID,
							RU.STRING));

					ValueVector propertyNames = new ValueVector();
					ValueVector propertyValues = new ValueVector();

					if (userEvent instanceof CreateObjectEvent) {
						Value propNameVal = new Value("type", RU.STRING);
						propertyNames.add(propNameVal);
						Value propValueVal = new Value(object.getType(),
								RU.STRING);
						propertyValues.add(propValueVal);
					}

					if (object.isTopLevelObject()) {
						String displayID = DisplayedObjectIDTracker
								.getDisplayID(this.sessionID, object.getID());
						actionFact.setSlotValue("display_id", new Value(
								displayID, RU.STRING));

						if (object instanceof Node) {
							Node n = (Node) object;
							actionFact.setSlotValue("elem_datatype", new Value(
									"NODE", RU.STRING));
							addNodeProperties(n, propertyNames, propertyValues);
						} else if (object instanceof Link) {
							Link l = (Link) object;
							actionFact.setSlotValue("elem_datatype", new Value(
									"LINK", RU.STRING));
							addLinkProperties(l, propertyNames, propertyValues);
						}

					} else {
						// subelement
						Node subElem = (Node) object;
						String type = subElem.getDataType();
						if (!configuration.isSubElementSupported(type)) {
							insert = false;
						} else {
							actionFact.setSlotValue("elem_datatype", new Value(
									subElem.getDataType(), RU.STRING));
							actionFact.setSlotValue("parent_id", new Value(
									subElem.getParentID().getIdAsString(),
									RU.STRING));
							addSubElemProperties(subElem, propertyNames,
									propertyValues);
						}
					}

					if ((userEvent instanceof ModifyObjectEvent)
							&& propertyNames.size() == 0) {
						insert = false;
					}

					if (insert) {
						actionFact.setSlotValue("prop_names", new Value(
								propertyNames, RU.LIST));
						actionFact.setSlotValue("prop_values", new Value(
								propertyValues, RU.LIST));
						jessEngine.assertFact(actionFact);
						doRun = true;
					}
				}

				if (doRun) {
					runEngine();
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	private void executeAnalysisRequestEvent(AnalysisRequestEvent aRequestEvent) {
		Map<AnalysisType, List<AnalysisResult>> results = getAnalysisResults(aRequestEvent
				.getAnalysisTypes());
		AnalysisResultEvent resultEvent = new AnalysisResultEvent(
				this.sessionID, getComponentID(), results);
		resultEvent.setTransactionID(aRequestEvent.getTransactionID());
		aRequestEvent.getCallback().onEvent(resultEvent);
	}

	private void runEngine() {
		try {
			jessEngine.run();

			if (LOG_ALL_FACT_TO_CONSOLE_ON_UPDATE) {
				for (Iterator<Fact> factIter = getWorkingMemoryFacts(); factIter
						.hasNext();) {
					logger.debug(factIter.next());
				}
			}
		} catch (Exception e) {
			logger.error("executeEUESessionEvent(...), " + e.getClass() + ": "
					+ e.getMessage());
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}

	}

	private void addNodeProperties(Node n, ValueVector propertyNames,
			ValueVector propertyValues) {
		Map<String, ObjectProperty> propMap = n.getProps();
		for (String propName : propMap.keySet()) {
			if (configuration.isNodePropSupported(propName)) {
				String propValue = propMap.get(propName).getValueAsString();
				addProperty(propName, propertyNames, propValue, propertyValues);
			}
		}
	}

	private void addLinkProperties(Link l, ValueVector propertyNames,
			ValueVector propertyValues) {
		if (!l.getSources().isEmpty()) {
			String sourceID = l.getSources().get(0).getIdAsString();
			addProperty("source_id", propertyNames, sourceID, propertyValues);
		}

		if (!l.getTargets().isEmpty()) {
			String targetID = l.getTargets().get(0).getIdAsString();
			addProperty("target_id", propertyNames, targetID, propertyValues);
		}

		Map<String, ObjectProperty> propMap = l.getProps();
		for (String propName : propMap.keySet()) {
			if (configuration.isLinkPropSupported(propName)) {
				String propValue = propMap.get(propName).getValueAsString();
				addProperty(propName, propertyNames, propValue, propertyValues);
			}
		}
	}

	private void addSubElemProperties(Node n, ValueVector propertyNames,
			ValueVector propertyValues) {
		Map<String, ObjectProperty> propMap = n.getProps();
		for (String propName : propMap.keySet()) {
			if (configuration.isSubElementPropSupported(n.getDataType(),
					propName)) {
				String propValue = propMap.get(propName).getValueAsString();
				addProperty(propName, propertyNames, propValue, propertyValues);
			}
		}

	}

	private void addProperty(String propName, ValueVector propertyNames,
			String propValue, ValueVector propertyValues) {
		try {
			Value propNameVal = new Value(propName, RU.STRING);
			propertyNames.add(propNameVal);
			Value propValueVal = new Value(propValue, RU.STRING);
			propertyValues.add(propValueVal);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	public Iterator<Fact> getWorkingMemoryFacts() {
		return jessEngine.listFacts();
	}

	public Iterator<HasLHS> getWorkingMemoryRules() {
		return jessEngine.listDefrules();
	}

	private Map<AnalysisType, List<AnalysisResult>> getAnalysisResults(
			Set<AnalysisType> analysisTypes) {
		Map<AnalysisType, List<AnalysisResult>> type2Results = new HashMap<AnalysisType, List<AnalysisResult>>();

		for (AnalysisType type : analysisTypes) {
			List<AnalysisResult> results = getResults(type);
			type2Results.put(type, results);
		}
		return type2Results;
	}

	private List<AnalysisResult> getResults(AnalysisType analysisType) {
		List<AnalysisResult> results = new Vector<AnalysisResult>();
		try {

			Context jessGlobalContext = jessEngine.getGlobalContext();
			String agentID = analysisType.getAgentID();
			String typeID = analysisType.getTypeID();
			ValueVector inputArgs = new ValueVector();
			inputArgs.add(new Value(agentID, RU.STRING));
			inputArgs.add(new Value(typeID, RU.STRING));

			QueryResult resultsJess = jessEngine.runQueryStar("get-result",
					inputArgs);

			while (resultsJess.next()) {

				// setting the entity
				AnalyzableEntity entity = new AnalyzableEntity();
				Value entityComponents = resultsJess.get("entity_ids");

				ValueVector entityComponentsAsJessVector = entityComponents
						.listValue(jessGlobalContext);
				for (int i = 0; i < entityComponentsAsJessVector.size(); ++i) {
					Value componentIDJess = entityComponentsAsJessVector.get(i);
					// check for 'nil' values (will be filtered out; nil is of
					// type "RU.SYMBOL")
					if (componentIDJess.type() == RU.STRING) {
						String componentIDAsString = componentIDJess
								.stringValue(jessGlobalContext);
						entity.addEntityComponent(JessIDMapper
								.jess2EUEID(componentIDAsString));
					}
				}

				// setting the actual result
				AnalysisResult aResult = null;
				if (BinaryResult.class.equals(analysisType.getResultType())) {
					boolean value = resultsJess.getBoolean("value");
					aResult = new BinaryResult(analysisType, entity, value);
					results.add(aResult);
				} else if (NumericalResult.class.equals(analysisType
						.getResultType())) {
					double value = resultsJess.getDouble("value");
					aResult = new NumericalResult(analysisType, entity, value);
					results.add(aResult);
				} else if (NominalResult.class.equals(analysisType
						.getResultType())) {
					String value = resultsJess.getString("value");
					aResult = new NominalResult(analysisType, entity, value);
					results.add(aResult);
				} else {
					logger.warn("Unknown (or unset) result type for "
							+ analysisType.toString());
				}

				// setting result property / value pairs
				if (aResult != null) {

					// prop names
					List<String> propNameList = new Vector<String>();
					Value propNamesJess = resultsJess.get("prop_names");

					ValueVector propNamesAsJessVector = propNamesJess
							.listValue(jessGlobalContext);
					for (int i = 0; i < propNamesAsJessVector.size(); ++i) {
						Value propNameJess = propNamesAsJessVector.get(i);
						// check for 'nil' values (will be filtered out; nil is
						// of type "RU.SYMBOL")
						if (propNameJess.type() == RU.STRING) {
							String propNameAsString = propNameJess
									.stringValue(jessGlobalContext);
							propNameList.add(propNameAsString);
						}
					}

					// prop values
					List<String> propValuesList = new Vector<String>();
					Value propValuesJess = resultsJess.get("prop_values");

					ValueVector propValuesAsJessVector = propValuesJess
							.listValue(jessGlobalContext);
					for (int i = 0; i < propValuesAsJessVector.size(); ++i) {
						Value propValueJess = propValuesAsJessVector.get(i);
						// check for 'nil' values (will be filtered out; nil is
						// of type "RU.SYMBOL")
						if (propValueJess.type() != RU.SYMBOL) {
							String propValueAsString = propValueJess
									.stringValue(jessGlobalContext);
							propValuesList.add(propValueAsString);
						}
					}

					if (propNameList.size() == propValuesList.size()) {
						Iterator<String> valueIter = propValuesList.iterator();
						for (String propName : propNameList) {
							String propValue = valueIter.next();
							aResult.addProperty(propName, propValue);
						}

					} else {
						logger.error("Number of result properties differs from number of result values.");
						if (SHUTDOWN_AFTER_ERROR) {
							System.exit(1);
						}
					}

				}
			}

		} catch (Exception e) {
			logger.error(
					"getResults(...), " + e.getClass() + ": " + e.getMessage(),
					e);
			if (SHUTDOWN_AFTER_ERROR) {
				System.exit(1);
			}
		}
		return results;
	}

	/**
	 * NOT synchronized on purpose to avoid deadlock with stopService() method
	 * (stopService() waits until Consumer.run() terminates, Consumer.run()
	 * might wait for stopService() to terminate if method processEvent were
	 * synchronized).
	 */
	protected void processEvent(Event event) {
		if (event instanceof UserEvent) {
			executeUserActivityEvent((UserEvent) event);
		} else if (event instanceof AnalysisRequestEvent) {
			executeAnalysisRequestEvent((AnalysisRequestEvent) event);
		}
	}

	@Override
	public synchronized GraphElement getElement(String eueObjectId) {
		return graphModel.getNode(eueObjectId);
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		buffer.append(this.getClass().getSimpleName());
		buffer.append("]");
		return buffer.toString();
	}

}
