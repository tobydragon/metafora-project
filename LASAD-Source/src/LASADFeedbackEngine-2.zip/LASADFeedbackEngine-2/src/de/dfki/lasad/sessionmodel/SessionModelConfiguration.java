package de.dfki.lasad.sessionmodel;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ConfigurationDatabase;
import de.dfki.lasad.core.components.configuration.ISessionModelConfiguration;
import de.dfki.lasad.session.data.meta.Ontology;
import de.dfki.lasad.session.data.meta.ToolContext;

/**
 * TODO: Currently, this class hard-codes LARGO-specific details. More general
 * LARGO-independent data should be separated cleanly from LARGO-specific data,
 * which should be taken from the ontology.
 * 
 * @author Oliver Scheuer
 * 
 */
public class SessionModelConfiguration implements ISessionModelConfiguration {

	private Log logger = LogFactory.getLog(SessionModelConfiguration.class);

	private static final String ontologyDefinitionsDirName = "details/agents/ontologies";
	private static final String annotationDirName = "details/agents/annotations";

	private static final String datastructuresBasicLocalFilename = "datastructures-basic.clp";
	private static final String datastructuresExtraLocalFilename = "datastructures-extra.clp";
	private static final String importCounterFunctionsLocalFilename = "import-counter-functions.clp";
	private static final String analysisImplicitLinksLocalFilename = "analysis-implicit-links.clp";
	private static final String analysisTranscriptLocalFilename = "analysis-transcript.clp";
	private static final String functionsLocalFilename = "functions.clp";
	private static final String resultQueryDefinitionLocalFilename = "result_query_definition.clp";

	private static final String datastructuresBasicNewLocalFilename = "datastructures-basic-NEW.clp";
	private static final String actionUpdatesLocalFilename = "update-model.clp";

	private String datastructuresBasicBatch;
	private String datastructuresExtraBatch;
	private String importCounterFunctionsBatch;
	private String analysisImplicitLinksBatch;
	private String analysisTranscriptBatch;
	private String functionsBatch;
	private String resultQueryDefinition;
	protected Map<String, String> resourceID2JessAnnotationBatch = new HashMap<String, String>();
	protected Map<String, String> ontologyID2JessDefinitionBatch = new HashMap<String, String>();

	private String datastructuresBasicNewBatch;
	private String actionUpdatesBatch;

	public SessionModelConfiguration() {
		loadDefinitionsFromFile();
	}

	@Override
	public void load(File configFile) {
		// nothing to do
	}

	public String getDatastructuresBasicBatch() {
		return datastructuresBasicBatch;
	}

	public String getDatastructuresExtraBatch() {
		return datastructuresExtraBatch;
	}

	public String getImportCounterFunctionsBatch() {
		return importCounterFunctionsBatch;
	}

	public String getAnalysisImplicitLinksBatch() {
		return analysisImplicitLinksBatch;
	}

	public String getAnalysisTranscriptBatch() {
		return analysisTranscriptBatch;
	}

	public String getFunctionsBatch() {
		return functionsBatch;
	}

	public String getResultQueryDefinition() {
		return resultQueryDefinition;
	}

	public String getDatastructuresBasicNewBatch() {
		return datastructuresBasicNewBatch;
	}

	public String getActionUpdatesBatch() {
		return actionUpdatesBatch;
	}

	public boolean isSubElementSupported(String propName) {
		return SupportedGraphProperties.isSubElementSupported(propName);
	}

	public boolean isNodePropSupported(String propName) {
		return SupportedGraphProperties.isNodePropSupported(propName);
	}

	public boolean isLinkPropSupported(String propName) {
		return SupportedGraphProperties.isLinkPropSupported(propName);
	}

	public boolean isSubElementPropSupported(String subElementDataType,
			String propName) {
		return SupportedGraphProperties.isSubElementPropSupported(
				subElementDataType, propName);
	}

	public String getOntologyBasedDefinitions(Ontology ontology) {
		String batch = ontologyID2JessDefinitionBatch.get(ontology
				.getOntologyID());
		return batch;
	}

	/**
	 * For each available resource annotations might be available
	 * 
	 */
	public List<String> getAnnotationDefinitionsAndAnnotations(ToolContext tc) {
		List<String> annotationJessBatches = new Vector<String>();
		for (String transciptID : tc.getTranscriptIDs()) {
			String annotationJessBatch = resourceID2JessAnnotationBatch
					.get(transciptID);
			if (annotationJessBatch != null) {
				annotationJessBatches.add(annotationJessBatch);
			}
		}
		return annotationJessBatches;
	}

	private final void loadDefinitionsFromFile() {

		datastructuresBasicBatch = readCPResourceIntoString(datastructuresBasicLocalFilename);
		logger.debug(datastructuresBasicBatch);

		datastructuresExtraBatch = readCPResourceIntoString(datastructuresExtraLocalFilename);
		logger.debug(datastructuresExtraBatch);

		importCounterFunctionsBatch = readCPResourceIntoString(importCounterFunctionsLocalFilename);
		logger.debug(importCounterFunctionsBatch);

		analysisImplicitLinksBatch = readCPResourceIntoString(analysisImplicitLinksLocalFilename);
		logger.debug(analysisImplicitLinksBatch);

		analysisTranscriptBatch = readCPResourceIntoString(analysisTranscriptLocalFilename);
		logger.debug(analysisTranscriptBatch);

		functionsBatch = readCPResourceIntoString(functionsLocalFilename);
		logger.debug(functionsBatch);

		resultQueryDefinition = readCPResourceIntoString(resultQueryDefinitionLocalFilename);
		logger.debug(resultQueryDefinition);

		datastructuresBasicNewBatch = readCPResourceIntoString(datastructuresBasicNewLocalFilename);
		logger.debug(datastructuresBasicNewBatch);

		actionUpdatesBatch = readCPResourceIntoString(actionUpdatesLocalFilename);
		logger.debug(actionUpdatesBatch);

		readOntologyDefs();
		readAnnotations();
	}

	protected void readOntologyDefs() {
		File confDir = ConfigurationDatabase.getConfigHome();
		File ontoDir = new File(confDir, ontologyDefinitionsDirName);
		if (ontoDir.exists()) {
			File[] ontoFiles = ontoDir.listFiles(new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					return name.endsWith(".clp");
				}
			});

			for (int i = 0; i < ontoFiles.length; ++i) {
				File ontoFile = ontoFiles[i];
				String ontologyDefinitionBatch = readFileIntoString(ontoFile);
				String ontologyID = ontoFile.getName().substring(0,
						ontoFile.getName().indexOf(".clp"));
				ontologyID2JessDefinitionBatch.put(ontologyID,
						ontologyDefinitionBatch);
			}
		} else {
			logger.info("Ontology folder '" + ontoDir.getAbsolutePath()
					+ "' does not exist. Ignore.");
		}
	}

	protected void readAnnotations() {
		File confDir = ConfigurationDatabase.getConfigHome();
		File annoDir = new File(confDir, annotationDirName);
		if (annoDir.exists()) {
			File[] annoFiles = annoDir.listFiles(new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					return name.endsWith(".clp");
				}
			});
			for (int i = 0; i < annoFiles.length; ++i) {
				File annoFile = annoFiles[i];
				String annoBatch = readFileIntoString(annoFile);
				String resourceID = annoFile.getName().substring(0,
						annoFile.getName().indexOf(".clp"));
				resourceID2JessAnnotationBatch.put(resourceID, annoBatch);
			}
		} else {
			logger.info("Annotation folder '" + annoDir.getAbsolutePath()
					+ "' does not exist. Ignore.");
		}
	}

	private String readFileIntoString(File file) {
		StringBuffer buf = new StringBuffer();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String line;
			while (true) {
				line = in.readLine();
				if (line == null) {
					break;
				}
				buf.append(line);
				buf.append("\n");
			}
			return buf.toString();
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}

	private String readCPResourceIntoString(String resourcename) {
		StringBuffer buf = new StringBuffer();
		try {
			InputStream inStream = this.getClass().getResourceAsStream(
					"resources" + "/" + resourcename);
			InputStreamReader inStreamReader = new InputStreamReader(inStream);
			BufferedReader bufReader = new BufferedReader(inStreamReader);
			String line;
			while (true) {
				line = bufReader.readLine();
				if (line == null) {
					break;
				}
				buf.append(line);
				buf.append("\n");
			}
			return buf.toString();
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}

	@Override
	public String toString() {
		return getClass().getSimpleName();
	}

}
