package de.dfki.lasad.authoring.model.pattern;

import java.util.List;

/**
 * Comparison of a set variable to another set variable.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class Set2ConstSetComparison extends Comparison {

	// standard fields
	private Set2SetOperator operator;
	private List<String> rightExpr;

	// supplemental fields
	private boolean useJessConstantSetFact;

	public Set2SetOperator getOperator() {
		return operator;
	}

	public void setOperator(Set2SetOperator operator) {
		this.operator = operator;
	}

	public List<String> getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(List<String> rightExpr) {
		this.rightExpr = rightExpr;
	}

	public boolean useJessConstantSetFact() {
		return useJessConstantSetFact;
	}

	public void setUseJessConstantSetFact(boolean useJessConstantSetFact) {
		this.useJessConstantSetFact = useJessConstantSetFact;
	}

}
