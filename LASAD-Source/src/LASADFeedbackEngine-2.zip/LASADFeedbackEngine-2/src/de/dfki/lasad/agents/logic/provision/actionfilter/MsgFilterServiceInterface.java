package de.dfki.lasad.agents.logic.provision.actionfilter;

import java.util.List;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public interface MsgFilterServiceInterface {

	public void filter(List<ActionTypeResult> list);

	public boolean keep(ActionTypeResult aTypeResult);
}
