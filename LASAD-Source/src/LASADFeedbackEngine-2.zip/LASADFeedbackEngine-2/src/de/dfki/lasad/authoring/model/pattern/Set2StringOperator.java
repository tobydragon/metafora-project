package de.dfki.lasad.authoring.model.pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author Almer Bolatov, Oliver Scheuer
 *
 */
public enum Set2StringOperator implements Operator{
	CONTAINS("CONTAINS"), 
	NOT_CONTAINS("NOT_CONTAINS");

	private static final Log logger = LogFactory.getLog(Set2StringOperator.class);
	
	private final String operator;

	Set2StringOperator(String operator) {
		this.operator = operator;
	}
	
	public String2SetOperator invert() {
		if (equals(CONTAINS)) {
			return String2SetOperator.IN;
		} else if (equals(NOT_CONTAINS)) {
			return String2SetOperator.NOT_IN;
		} else {
			logger.error("Error in method invert()");
			return null;
		}
	}
}
