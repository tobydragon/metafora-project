package de.dfki.lasad.session.data.meta.ontology.base;

import de.dfki.lasad.session.data.meta.ontology.ComparisonGroup;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * 
 * @author oliverscheuer
 *
 */
public class RatingType extends BaseType {

	private static RatingType instance = new RatingType();
	
	private RatingType(){
		super();
		lasadElementType = "rating";
		jessTemplateName = "elem_rating";
		addComponentSpecification(PropDescr.DEFAULT_COMPONENT_ID, "SCORE", JessDataType.NUMBER, ComparisonGroup.NUMBER);
	}
	
	public static RatingType getInstance(){
		return instance;
	}
}