package de.dfki.lasad.agents.instances.action;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import lasad.shared.dfki.meta.agents.ActionAgentConfigData;
import lasad.shared.dfki.meta.agents.ServiceType;
import lasad.shared.dfki.meta.agents.SupportedOntologiesDef;
import lasad.shared.dfki.meta.agents.action.ActionType;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;
import lasad.shared.dfki.meta.agents.analysis.phases.PhaseModelerDef;
import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.agents.provision.ProvisionType;

import de.dfki.lasad.agents.SessionChecker;
import de.dfki.lasad.agents.SimpleSessionChecker;
import de.dfki.lasad.agents.instances.action.xml.ActionAgentConfigDataXML;
import de.dfki.lasad.core.FeedbackConfigManager;
import de.dfki.lasad.core.components.configuration.IAgentConfiguration;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class ActionAgentConfig implements IAgentConfiguration {

	private String agentID = null;

	private ActionAgentConfigData confData = null;
	private SessionChecker supportedOntologies = null;

	public ActionAgentConfig() {
		super();
	}

	@Override
	public void setComponentID(String componentID) {
		this.agentID = componentID;
	}

	@Override
	public void load(File confFile) {
		loadConfigData(agentID, confFile);
	}

	@Override
	public void init() {
		SupportedOntologiesDef ontoDef = confData.getSupportedOntologiesDef();
		if (ontoDef.isAllOntologies()) {
			supportedOntologies = new SimpleSessionChecker();
		} else {
			supportedOntologies = new SimpleSessionChecker(
					ontoDef.getSupportedOntologies());
		}
	}

	public void compileNotYetCompiledAnalysisTypes() {
		for (AnalysisType aType : confData.getAnalysisTypes()) {
			if (aType instanceof StructureAnalysisType) {
				StructureAnalysisType saType = (StructureAnalysisType) aType;
				if (!FeedbackConfigManager.isJessRuleGenerated(saType))
					FeedbackConfigManager.generateJessRule(saType);
			}
		}
	}

	private final void loadConfigData(String agentID, File confFile) {
		confData = ActionAgentConfigDataXML.fromXMLFile(agentID, confFile);
	}

	public String getAgentID() {
		return confData.getAgentID();
	}

	@Override
	public List<ServiceType> getServiceTypes() {
		return confData.getServiceTypes();
	}

	@Override
	public SessionChecker getSessionChecker() {
		return supportedOntologies;
	}

	public Collection<AnalysisType> getAnalysisTypes() {
		return confData.getAnalysisTypes();
	}

	public Collection<ActionType> getActionTypes() {
		return confData.getActionTypes();
	}

	public Collection<ProvisionType> getProvisionTypes() {
		return confData.getProvisionTypes();
	}

	public PhaseModelerDef getPhaseModelerDef() {
		return confData.getPhaseModelerDef();
	}

	public ActionAgentConfigData getConfData() {
		return confData;
	}

	@Override
	public String toString() {

		StringBuffer analysisTypesBuf = new StringBuffer();
		analysisTypesBuf.append("{");
		for (Iterator<AnalysisType> iter = confData.getAnalysisTypes()
				.iterator(); iter.hasNext();) {
			analysisTypesBuf.append(iter.next().getServiceID().getTypeID());
			if (iter.hasNext()) {
				analysisTypesBuf.append(", ");
			}
		}
		analysisTypesBuf.append("}");

		StringBuffer actionTypesBuf = new StringBuffer();
		actionTypesBuf.append("{");
		for (Iterator<ActionType> iter = confData.getActionTypes().iterator(); iter
				.hasNext();) {
			actionTypesBuf.append(iter.next().getServiceID().getTypeID());
			if (iter.hasNext()) {
				actionTypesBuf.append(", ");
			}
		}
		actionTypesBuf.append("}");

		StringBuffer provisionTypesBuf = new StringBuffer();
		provisionTypesBuf.append("{");
		for (Iterator<ProvisionType> iter = confData.getProvisionTypes()
				.iterator(); iter.hasNext();) {
			provisionTypesBuf.append(iter.next().getServiceID().getTypeID());
			if (iter.hasNext()) {
				provisionTypesBuf.append(", ");
			}
		}
		provisionTypesBuf.append("}");

		return getClass().getSimpleName() + " agentID=" + confData.getAgentID()
				+ ", analysisTypes=" + analysisTypesBuf.toString()
				+ ", simpleActionTypes=" + actionTypesBuf.toString()
				+ ", compoundActionTypes=" + provisionTypesBuf.toString();
	}

}
