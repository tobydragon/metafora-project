package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import java.util.Vector;

import lasad.shared.communication.objects.Action;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.dataservice.lasad.LasadActionFactory;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;

public class CreateHelpRequest extends CfCreateObjectAction {
	private static Log logger = LogFactory.getLog(CreateHelpRequest.class);

	
	public CreateHelpRequest(CfAction cfAction){
		super(cfAction);
	}
	
	@Override
	public Vector<Action> buildLasadActions() {
		if (state == CfActionState.create){
			return buildCreateActions("resources/xml/lasad/CreateHelpRequestObject.xml");
		}
		else if (state == CfActionState.waitingToModifyEUE){
			CfObject objectToUpdate = cfAction.getCfObjects().get(0);
			String mapId = objectToUpdate.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING);

			String viewElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING).getId();
			String viewUrl = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING).getValue();
			String textElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).getId();
			String text = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).getValue();
			String referenceUrlElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).getId();
			String referenceUrl = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).getValue();

			Vector<Action> actions = new Vector<Action>();
			actions.add(LasadActionFactory.createUpdateUrlElement(viewElementId, mapId, viewUrl));
			actions.add(LasadActionFactory.createUpdateTextElement(textElementId, mapId, text));
			actions.add(LasadActionFactory.createUpdateUrlElement(referenceUrlElementId, mapId, referenceUrl));
			return actions;
		}
		else {
			logger.error("[buildLasadActions] no actions designed for state - " + state);
			return null;
		}
	}
	
	public void moveToUpdatePhase(CreateObjectEvent uEvent){
		setState(CfActionState.waitingToModifyEUE);
		
		String boxElementId =  uEvent.getEueObjectList().get(0).getID().getIdAsString();
		cfAction.getCfObjects().get(0).setId(boxElementId);
				
		String viewId =  uEvent.getEueObjectList().get(1).getID().getIdAsString();
		cfAction.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING).setId(viewId);
		
		String textElementId =  uEvent.getEueObjectList().get(2).getID().getIdAsString();
		cfAction.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).setId(textElementId);
		
		String refUrlElementId =  uEvent.getEueObjectList().get(3).getID().getIdAsString();
		cfAction.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).setId(refUrlElementId);
	}


}
