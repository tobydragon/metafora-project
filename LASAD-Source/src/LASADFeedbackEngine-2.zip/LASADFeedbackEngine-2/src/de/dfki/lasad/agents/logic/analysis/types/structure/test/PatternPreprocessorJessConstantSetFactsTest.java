package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import java.util.List;
import java.util.Map;

import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPatternSuppl;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.PatternPreprocessor;

/**
 * 
 * 
 * 
 * @author oliverscheuer
 * 
 */
public class PatternPreprocessorJessConstantSetFactsTest {

	static PatternPreprocessor preprocessor = new PatternPreprocessor(
			TestData.largoOntology);

	static {
		preprocessor.testModePrintIntermediateResults = false;
		preprocessor.testModeOmitSequentialization = false;
	}

	public static void main(String[] args) {
		printPreparedCase();
	}

	static void printPreparedCase() {
		StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
				.parsePattern(TestData.TESTFILE_JESS_CONST_SET_FACTS);
		preprocessor.preprocess(pattern.getPattern());
		System.out.println("-------- comparisons -------- ");
		ComparisonPrinterHelper.printAllComparisons(pattern.getPattern());
		System.out
				.println("-------- constant set facts indexed in pattern -------- ");
		printConstSetFactMapping(pattern.getPattern());
	}

	static void printConstSetFactMapping(StructuralPattern pattern) {
		String patternID = pattern.getID();
		if (pattern.getSubID() != null) {
			patternID = patternID + "/" + pattern.getSubID();
		}
		System.out.println("----- " + patternID + " -----");
		StructuralPatternSuppl patternSupplData = pattern.getSupplData();
		Map<Integer, List<String>> comparisonID2ConstValues = patternSupplData
				.getConstantNumID2Values();
		for (Integer compID : comparisonID2ConstValues.keySet()) {
			List<String> values = comparisonID2ConstValues.get(compID);
			System.out
					.println("ID=" + compID + ", values=" + values.toString());
		}

		for (StructuralPattern notPattern : pattern.getNotPatterns()) {
			printConstSetFactMapping(notPattern);
		}
	}

}
