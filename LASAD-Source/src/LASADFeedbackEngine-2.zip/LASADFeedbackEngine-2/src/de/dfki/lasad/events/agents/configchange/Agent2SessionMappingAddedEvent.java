package de.dfki.lasad.events.agents.configchange;

/**
 * Notification that the Feedback-Engine configuration has changed.
 * 
 * @author oliverscheuer
 * 
 */
public class Agent2SessionMappingAddedEvent extends AFStateChangedEvent {

	private String agentID;
	private String sessionID;

	public Agent2SessionMappingAddedEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	@Override
	public String toString() {
		return "Agent2SessionMappingAddedEvent [agentID=" + agentID
				+ ", sessionID=" + sessionID + "]";
	}

}
