package de.dfki.lasad.events.agents.configchange;

import lasad.shared.dfki.meta.ServiceStatus;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ComponentRuntimeStatusChangedEvent extends AFStateChangedEvent {

	private String changedComponentID = null;
	private ServiceStatus oldStatus = null;
	private ServiceStatus newStatus = null;

	public ComponentRuntimeStatusChangedEvent(String srcCompId) {
		super(srcCompId);
	}

	public ServiceStatus getOldStatus() {
		return oldStatus;
	}

	public void setOldStatus(ServiceStatus oldStatus) {
		this.oldStatus = oldStatus;
	}

	public ServiceStatus getNewStatus() {
		return newStatus;
	}

	public void setNewStatus(ServiceStatus newStatus) {
		this.newStatus = newStatus;
	}

	public String getChangedComponentID() {
		return changedComponentID;
	}

	public void setChangedComponentID(String changedComponentID) {
		this.changedComponentID = changedComponentID;
	}

	@Override
	public String toString() {
		return "ComponentRuntimeStatusChangedEvent [componentID="
				+ changedComponentID + ", oldStatus=" + oldStatus
				+ ", newStatus=" + newStatus + "]";
	}

}
