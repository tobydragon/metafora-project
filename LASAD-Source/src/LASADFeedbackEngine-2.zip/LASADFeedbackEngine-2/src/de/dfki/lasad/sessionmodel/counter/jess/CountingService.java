package de.dfki.lasad.sessionmodel.counter.jess;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.List;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jess.Context;
import jess.Fact;
import jess.Funcall;
import jess.JessEvent;
import jess.JessException;
import jess.JessListener;
import jess.Value;
import de.dfki.lasad.sessionmodel.counter.Index;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class CountingService implements Serializable, JessListener {

	private Log logger = LogFactory.getLog(CountingService.class);

	private Context context = null;
	private List<Fact> resultFactsUsingCounter = new Vector<Fact>(); 
	
	protected PropertyChangeSupport m_pcs;

	int actionCount;

	Index index;

	public CountingService() {
		actionCount = 0;
		index = new Index();
		m_pcs = new PropertyChangeSupport(this);
	}

	public int getActionCount() {
		return actionCount;
	}

	public void setActionCount(int actionCount) {
		this.actionCount = actionCount;
	}

	public Index getIndex() {
		return index;
	}

	@Override
	public void eventHappened(JessEvent je) throws JessException {
		int eventType = je.getType();
		switch (eventType) {
		case JessEvent.FACT:
			Fact assertFact = (Fact) je.getObject();
			
			if ("MAIN::analysis_result".equals(assertFact.getName())) {
				context = je.getContext();
				Value logicalSupportVal = assertFact.getSlotValue("dynamic_counter");
				if(logicalSupportVal.equals(Funcall.TRUE)){
					resultFactsUsingCounter.add(assertFact);
					logger.debug("Added to AnalysisResult facts that use counters: " + assertFact);
				}
			} else if ("MAIN::node_action".equals(assertFact.getName())) {
				ActionAttributes generalAtts = getActionAttributes(assertFact,
						je.getContext());
				logger.debug("Forward Node action to index: " + generalAtts);
				index.addNodeAction(generalAtts);
				m_pcs.firePropertyChange("actionCount", actionCount, ++actionCount);
			} else if ("MAIN::link_action".equals(assertFact.getName())) {
				ActionAttributes generalAtts = getActionAttributes(assertFact,
						je.getContext());

				String source = null;
				Value sourceVal = assertFact.getSlotValue("source");
				if (!sourceVal.equals(Funcall.NIL)) {
					source = sourceVal.stringValue(je.getContext());
				}

				String target = null;
				Value targetVal = assertFact.getSlotValue("target");
				if (!targetVal.equals(Funcall.NIL)) {
					target = targetVal.stringValue(je.getContext());
				}

				logger.debug("Forward Link action to index: " + generalAtts
						+ ", source=" + source + ", target=" + target);
				index.addLinkAction(generalAtts, source, target);
				m_pcs.firePropertyChange("actionCount", actionCount, ++actionCount);
			} else {
				break;
			}
			break;
		default:
			// ignore
		}

	}

	public void addNodeAction(String actionType, String actor, long ts,
			String objectID, String objectType) {
		clearDynamicCounterFacts();
		logger.debug("ADD NODE-ACTION ...");
		index.addNodeAction(actionType, actor, ts, objectID, objectType);
		logger.debug("... NODE-ACTION ADDED. New index: " + toString());
		m_pcs.firePropertyChange("actionCount", actionCount, ++actionCount);
	}

	public void addLinkAction(String actionType, String actor, long ts,
			String objectID, String objectType, String sourceID, String targetID) {
		clearDynamicCounterFacts();
		logger.debug("ADD LINK-ACTION ...");
		index.addLinkAction(actionType, actor, ts, objectID, objectType,
				sourceID, targetID);
		logger.debug("... LINK-ACTION ADDED. New index: " + toString());
		m_pcs.firePropertyChange("actionCount", actionCount, ++actionCount);
	}

	private ActionAttributes getActionAttributes(Fact actionFact, Context c)
			throws JessException {
		ActionAttributes atts = new ActionAttributes();

		Value typeVal = actionFact.getSlotValue("type");
		if (!typeVal.equals(Funcall.NIL)) {
			atts.type = typeVal.stringValue(c);
		}

		Value actorVal = actionFact.getSlotValue("actor");
		if (!actorVal.equals(Funcall.NIL)) {
			atts.actor = actorVal.stringValue(c);
		}

		Value tsVal = actionFact.getSlotValue("ts");
		if (!tsVal.equals(Funcall.NIL)) {
			atts.ts = tsVal.longValue(c);
		}

		Value objectIDVal = actionFact.getSlotValue("object_id");
		if (!objectIDVal.equals(Funcall.NIL)) {
			atts.objectID = objectIDVal.stringValue(c);
		}

		Value objectTypeVal = actionFact.getSlotValue("object_type");
		if (!objectTypeVal.equals(Funcall.NIL)) {
			atts.objectType = objectTypeVal.stringValue(c);
		}

		return atts;
	}

	public void addPropertyChangeListener(PropertyChangeListener p) {
		m_pcs.addPropertyChangeListener(p);
	}

	public void removePropertyChangeListener(PropertyChangeListener p) {
		m_pcs.removePropertyChangeListener(p);
	}

	@Override
	public String toString() {
		return "CountingService [index=" + index + "]";
	}

	public void clearDynamicCounterFacts(){
		try{
			logger.debug("Retract all AnalyisResults that are based on dynamic counters.");
		for(Fact f: resultFactsUsingCounter){
			logger.debug("Retracted fact: " + f);
			context.getEngine().retract(f);
		}
		}catch(Exception e){
			logger.error(e);
		}
	}
	
	public class ActionAttributes {
		public String type = null;
		public String actor = null;
		public long ts = -1;
		public String objectID = null;
		public String objectType = null;

		@Override
		public String toString() {
			return "[type=" + type + ", actor=" + actor + ", ts=" + ts
					+ ", objectID=" + objectID + ", objectType=" + objectType
					+ "]";
		}

	}
	
}
