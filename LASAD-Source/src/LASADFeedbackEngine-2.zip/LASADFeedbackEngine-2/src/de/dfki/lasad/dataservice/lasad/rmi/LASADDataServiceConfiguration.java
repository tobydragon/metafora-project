package de.dfki.lasad.dataservice.lasad.rmi;

import java.io.File;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.components.configuration.IDataServiceConfiguration;

/**
 * 
 * @author Anahuac Valero, Oliver Scheuer
 * 
 */

public class LASADDataServiceConfiguration implements IDataServiceConfiguration {
	
	static Log logger = LogFactory.getLog(LASADDataServiceConfiguration.class);

	private String componentID = null;
	
	private String username = null;
	private String password = null;

	private int heartBeatRate = 10; // in secs

	private String serverIP = null;
	private int serverPort;
	private String serverName = null;
	private int serverRegistryPort;
	private String clientName = "LASADFeedbackEngineClient";
	private int clientRegistryPort;

	public LASADDataServiceConfiguration() {
	}

	@Override
	public void setComponentID(String componentID) {
		this.componentID = componentID;
	}

	@Override
	public void load(File confFile) {
		LASADDataServiceConfigParser.loadConfig(this, confFile);
	}
	
	@Override
	public void init() {
		// nothing to do
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getHeartBeatRate() {
		return heartBeatRate;
	}

	public void setHeartBeatRate(int heartBeatRate) {
		this.heartBeatRate = heartBeatRate;
	}

	public String getServerIP() {
		return serverIP;
	}

	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}

	public int getServerPort() {
		return serverPort;
	}

	public void setServerPort(int serverPort) {
		this.serverPort = serverPort;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public int getServerRegistryPort() {
		return serverRegistryPort;
	}

	public void setServerRegistryPort(int serverRegistryPort) {
		this.serverRegistryPort = serverRegistryPort;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public int getClientRegistryPort() {
		return clientRegistryPort;
	}

	public void setClientRegistryPort(int clientRegistryPort) {
		this.clientRegistryPort = clientRegistryPort;
	}

	public boolean autoHeartBeat() {
		if (heartBeatRate > 0) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + "[username=" + username
				+ ", password=" + password + ", heartBeatRate=" + heartBeatRate
				+ ", doJoinAllPossibleMapsOnStartup=" + ", serverIP="
				+ serverIP + ", serverPort=" + serverPort
				+ ", serverRegistryPort=" + serverRegistryPort
				+ ", clientName=" + clientName + ", clientRegistryPort="
				+ clientRegistryPort + "]";
	}

}
