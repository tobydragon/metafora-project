package de.dfki.lasad.agents.instances.xmpp;

import java.util.Date;
import java.util.Iterator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.instances.xmpp.xmppaction.CfActionDuringExecution;
import de.dfki.lasad.agents.instances.xmpp.xmppaction.CfCreateObjectAction;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.uds.cfcommunication.MetaforaCfFactory;
import de.uds.commonformat.CfAction;
import de.uds.commonformatparser.CfActionParser;
import de.uds.util.GeneralUtil;

public class CfUserActivityAgent extends CfAbstractAgent{
	
	Log logger = LogFactory.getLog(this.getClass());
	
	//Standard call to create xmppAgent
	public CfUserActivityAgent(){
		this(true);
		logger.info("XmppUserActivityAgent created at" + new Date());
	}
	
	//special constructor to allow for disabled xmpp agent for testing
	CfUserActivityAgent(boolean connectToSource){
		super(connectToSource);
	}
	
	
	public synchronized void processEvent(Event event) {
		if (event instanceof UserEvent){
			if ( GeneralUtil.isTimeRecent(event.getTs())){
				UserEvent actionEvent = (UserEvent) event;
				logger.debug("[onEUEEvent] userActionEvent xml - \n" + actionEvent.toXml().toString());
				
				if (event instanceof CreateObjectEvent){
					CreateObjectEvent uEvent = (CreateObjectEvent) event;
					checkForCreateResponse(uEvent);	
				}
				else if (event instanceof ModifyObjectEvent){
					checkForModifyResponse((ModifyObjectEvent) event);
				}
			}
		}
	}
	
	private void checkForCreateResponse(CreateObjectEvent uEvent){
		Iterator<CfActionDuringExecution> actionsToCheck = actionsWaitingForResponse.iterator();
		logger.debug("[checkForCreateResponse] checking if this is an action response.");
		boolean actionFound = false;
		while (!actionFound && actionsToCheck.hasNext()){
			CfActionDuringExecution actionToCheck = actionsToCheck.next();
			if (actionToCheck instanceof CfCreateObjectAction){
				CfCreateObjectAction createObjectActionToCheck = (CfCreateObjectAction) actionToCheck;
				if (createObjectActionToCheck.eventIsResponseToMe(uEvent)){
					actionFound = true;
					actionsToCheck.remove();
					createObjectActionToCheck.moveToUpdatePhase(uEvent);
					sendActionsToEUE(actionToCheck);
				}
			}
		}
	}
	
	private void checkForModifyResponse(ModifyObjectEvent modifyEvent){
		//right now this is a hard-coded solution to sending the xmpp message when an xmpp url button is clicked.
		String modifiedType = modifyEvent.getEueObjectList().get(0).getType();
		
		if ("issue-xmpp-button".equalsIgnoreCase(modifiedType) ){
			String mapId = modifyEvent.getSessionID().getIdAsString();
			String userId = modifyEvent.getUserID().getIdAsString();
			String stateUrl = modifyEvent.getEueObjectList().get(0).getPropValue("LINK").getValueAsString();
			CfAction action = MetaforaCfFactory.buildDisplayStateUrlMessage(mapId, userId, stateUrl);
			logger.debug("[onEUEEvent] Sending DISPLAY_STATE_URL command - " + CfActionParser.toXml(action));
			communicationManager.sendMessage(action);
		}		
	}
	
}