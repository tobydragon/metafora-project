package de.dfki.lasad.agents.instances;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public interface TaskScheduler {

	public void scheduleAnalysisTask(AnalysisResult result, long delay);

	public void cancelTasks(Integer targetResultID);

}
