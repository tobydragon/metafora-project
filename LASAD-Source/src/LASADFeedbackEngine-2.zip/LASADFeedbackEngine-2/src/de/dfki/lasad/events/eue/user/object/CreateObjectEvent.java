package de.dfki.lasad.events.eue.user.object;

import java.util.List;

import de.dfki.lasad.events.eue.EUEEventID;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.objects.EUEObject;

/**
 * @author Oliver Scheuer
 * 
 */
public class CreateObjectEvent extends ObjectActionEvent {

	public CreateObjectEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID, List<EUEObject> eueObject) {
		super(sessionID, srcCompId, eueEventID, userID, eueObject);
	}

	public CreateObjectEvent(SessionID sessionID, EUEEventID eueEventId,
			String srcComponentId) {
		super(sessionID, srcComponentId, eueEventId);
	}

	public CreateObjectEvent cloneWithoutObjects() {
		CreateObjectEvent clone = new CreateObjectEvent(getSessionID(),
				getEueEventID(), getSourceComponentID());
		clone.setUserID(getUserID());
		return clone;
	}
}
