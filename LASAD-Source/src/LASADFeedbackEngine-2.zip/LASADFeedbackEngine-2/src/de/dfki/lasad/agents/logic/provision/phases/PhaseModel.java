package de.dfki.lasad.agents.logic.provision.phases;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.analysis.phases.PhaseDef;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PhaseModel {

	private List<Phase> phases = new Vector<Phase>();
	private Phase mostLikelyPhase = null;
	private Map<String, Phase> ids2phases = new HashMap<String, Phase>();

	public PhaseModel(List<PhaseDef> phaseList) {
		double uniformProbability = 1.0 / phaseList.size();
		for (PhaseDef phase : phaseList) {
			Phase p = new Phase(phase.getID(), uniformProbability);
			phases.add(p);
			this.ids2phases.put(phase.getID(), p);
		}
		if (phaseList.size() > 0) {
			mostLikelyPhase = ids2phases.get(phaseList.get(0));
		}
	}

	public void updateProbabilities(Map<String, Double> phase2Probability) {
		double currentMaxProb = 0;
		for (String phaseID : ids2phases.keySet()) {
			double newProb = phase2Probability.get(phaseID);
			Phase p = ids2phases.get(phaseID);
			p.probability = newProb;
			if (newProb > currentMaxProb) {
				mostLikelyPhase = p;
				currentMaxProb = newProb;
			}
		}
	}

	/**
	 * 
	 * @return most likely phase or <code>null</code> if no such phase exists
	 */
	public Phase getMostLikelyPhase() {
		return mostLikelyPhase;
	}

	public List<Phase> getPhasesInDefinitionOrder() {
		return phases;
	}

	public List<Phase> getPhasesInProbabilisticOrder() {
		List<Phase> orderedPhases = new Vector<Phase>();
		orderedPhases.addAll(ids2phases.values());
		Collections.sort(orderedPhases, new PhaseProbabilityComparator());
		return orderedPhases;
	}

	@Override
	public String toString() {
		return "PhaseModel [phases=" + phases + "]";
	}

}
