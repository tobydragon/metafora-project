package de.dfki.lasad.core;

import java.util.List;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.session.Session;

/**
 * Provides access to resource configurations ({@link #getResourcesManager()})
 * and the runtime configuration ({@link #getRuntimeManager()}). Provides
 * methods to access the configured {@link DataServiceDescription} (
 * {@link #getDSDescription()}), {@link SessionModelDescription} (
 * {@link #getSessionModelDescription()}) and {@link AgentDescriptions} (
 * {@link #getSessionSpecificAgentDescriptions(Session)}) based on the current runtime
 * configuration.
 * 
 * @author oliverscheuer
 * 
 */
public class ConfigurationManager {

	static Log logger = LogFactory.getLog(ConfigurationManager.class);

	private ResourcesConfigManager resourcesManager;
	private RuntimeConfigManager runtimeManager;

	public ConfigurationManager() {
		resourcesManager = new ResourcesConfigManager();
		runtimeManager = new RuntimeConfigManager();
	}

	/**
	 * Initialize configuration from filesystem
	 */
	public void loadConf() {
		resourcesManager.loadDescriptionsFromFile();
		runtimeManager.loadRuntimeConf();
	}

	public DataServiceDescription getDSDescription() {
		String dsID = runtimeManager.getRuntimeDS();
		DataServiceDescription ds = resourcesManager
				.getDataServiceDescription(dsID);
		return ds;
	}

	public SessionModelDescription getSessionModelDescription() {
		String smID = runtimeManager.getRuntimeModel();
		SessionModelDescription sm = resourcesManager
				.getSessionModelDescription(smID);
		return sm;
	}

	public List<AgentDescription> getSessionSpecificAgentDescriptions(Session session) {

		String sessionID = session.getID().getIdAsString();
		List<String> sessionAgentIDs = runtimeManager.getAgentRuntime()
				.getAgentsForSession(sessionID);

		List<String> ontologyAgentIDs = new Vector<String>();

		if (session.getOntology() != null) {
			String ontologyID = session.getOntology().getOntologyID();
			ontologyAgentIDs = runtimeManager.getAgentRuntime()
					.getAgentsForOntology(ontologyID);
		} else {
			logger.warn("No ontology defined for session: " + session.getID());
		}

		List<AgentDescription> runtimeAgentDescrs = new Vector<AgentDescription>();

		for (String aID : sessionAgentIDs) {
			AgentDescription a = resourcesManager.getAgentDescription(aID);
			runtimeAgentDescrs.add(a);
		}

		for (String aID : ontologyAgentIDs) {
			AgentDescription a = resourcesManager.getAgentDescription(aID);
			if (a != null) {
				runtimeAgentDescrs.add(a);
			} else {
				logger.warn("AgentDescription not found: " + aID);
			}
		}
		return runtimeAgentDescrs;
	}

	public List<AgentDescription> getSessionGeneralAgentDescriptions() {

		List<String> agentIDs = runtimeManager.getAgentRuntime()
				.getSessionGeneralAgents();

		List<AgentDescription> runtimeAgentDescrs = new Vector<AgentDescription>();

		for (String aID : agentIDs) {
			AgentDescription a = resourcesManager.getAgentDescription(aID);
			runtimeAgentDescrs.add(a);
		}
		return runtimeAgentDescrs;
	}

	public ResourcesConfigManager getResourcesManager() {
		return resourcesManager;
	}

	public RuntimeConfigManager getRuntimeManager() {
		return runtimeManager;
	}

}
