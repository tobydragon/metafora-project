package de.dfki.lasad.dataservice.lasad.rmi;

import java.io.File;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

/**
 * 
 * @author Anahuac Valero
 * 
 */
public class LASADDataServiceConfigParser {

	private static Log logger = LogFactory
			.getLog(LASADDataServiceConfigParser.class);

	public static LASADDataServiceConfiguration loadConfig(
			LASADDataServiceConfiguration conf, File confFile) {
		try {
			// Namespace classifierNs = Namespace
			// .getNamespace(classifierDescriptionNS);
			SAXBuilder builder = new SAXBuilder();
			Document doc = builder.build(confFile);

			Element usernameElem = doc.getRootElement().getChild("username");
			String username = usernameElem.getText();
			conf.setUsername(username);

			Element pwElem = doc.getRootElement().getChild("password");
			String pw = pwElem.getText();
			conf.setPassword(pw);

			Element serverIPElem = doc.getRootElement().getChild("serverip");
			String serverIP = serverIPElem.getText();
			conf.setServerIP(serverIP);

			Element serverPortElem = doc.getRootElement()
					.getChild("serverport");
			int serverPort = Integer.parseInt(serverPortElem.getText());
			conf.setServerPort(serverPort);

			Element serverNameElem = doc.getRootElement()
					.getChild("servername");
			String serverName = serverNameElem.getText();
			conf.setServerName(serverName);

			Element serverRegistryPortElem = doc.getRootElement().getChild(
					"serverregistryport");
			int serverRegistryPort = Integer.parseInt(serverRegistryPortElem
					.getText());
			conf.setServerRegistryPort(serverRegistryPort);

			Element clientNameElem = doc.getRootElement()
					.getChild("clientname");
			String clientName = clientNameElem.getText();
			conf.setClientName(clientName);

			Element clientRegistryPortElem = doc.getRootElement().getChild(
					"clientregistryport");
			int clientRegistryPort = Integer.parseInt(clientRegistryPortElem
					.getText());
			conf.setClientRegistryPort(clientRegistryPort);

			Element heartbeatrateElem = doc.getRootElement().getChild(
					"heartbeatrate");
			int heartbeatRate = Integer.parseInt(heartbeatrateElem.getText());
			conf.setHeartBeatRate(heartbeatRate);

			logger.debug("LASAD-DS Configuration: " + conf.toString());

			return conf;
		} catch (Exception e) {
			logger.error("Error while loading cpmnfog file: " + e.getClass()
					+ ": " + e.getMessage(), e);
			return null;
		}
	}
}
