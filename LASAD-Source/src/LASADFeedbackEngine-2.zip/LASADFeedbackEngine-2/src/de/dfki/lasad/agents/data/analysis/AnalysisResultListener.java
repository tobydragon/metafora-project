package de.dfki.lasad.agents.data.analysis;

/**
 * 
 * @author oliverscheuer
 * 
 */
public interface AnalysisResultListener {

	public void onResultChanged(AnalysisResult resultData, boolean deleted);
}
