package de.dfki.lasad.events.agents;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.events.EventImpl;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AnalysisResultsChangedEvent extends EventImpl {

	private Set<AnalysisResult> resultsToAdd = new HashSet<AnalysisResult>();
	private Set<Integer> resultsToRemove = new HashSet<Integer>();

	public AnalysisResultsChangedEvent(String srcCompId) {
		super(srcCompId);
	}

	public Set<AnalysisResult> getResultsToAdd() {
		return resultsToAdd;
	}

	public void setResultsToAdd(Set<AnalysisResult> analysisResults) {
		this.resultsToAdd = analysisResults;
	}

	public void addResultToAdd(AnalysisResult result) {
		resultsToAdd.add(result);
	}

	public Set<Integer> getResultIDsToRemove() {
		return resultsToRemove;
	}

	public void setResultsToRemove(Set<Integer> resultIDs) {
		this.resultsToRemove = resultIDs;
	}

	public void addResultIDToRemove(Integer resultID) {
		resultsToRemove.add(resultID);
	}

	@Override
	public String toString() {
		return "AnalysisResultsChangedEvent [resultsToAdd=" + resultsToAdd
				+ ", resultsToRemove=" + resultsToRemove + "]";
	}

	public String toSimpleString() {
		StringBuffer buf = new StringBuffer();
		buf.append("AnalysisResultsChangedEvent [ADD: ");
		for (Iterator<AnalysisResult> iter = resultsToAdd.iterator(); iter
				.hasNext();) {
			AnalysisResult result = iter.next();
			buf.append(result.toSimpleString());
			if (iter.hasNext()) {
				buf.append(", ");
			}
		}
		buf.append("]");
		buf.append("[REMOVE: ");
		buf.append(resultsToRemove);
		buf.append("]");
		return buf.toString();
	}
}
