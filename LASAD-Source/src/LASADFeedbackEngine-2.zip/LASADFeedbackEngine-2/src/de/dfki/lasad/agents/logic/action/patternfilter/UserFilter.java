package de.dfki.lasad.agents.logic.action.patternfilter;

import de.dfki.lasad.agents.data.analysis.user.UserResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class UserFilter {

	public abstract boolean keep(UserResult result);
}
