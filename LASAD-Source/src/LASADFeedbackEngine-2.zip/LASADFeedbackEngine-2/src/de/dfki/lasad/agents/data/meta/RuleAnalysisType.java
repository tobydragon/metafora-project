package de.dfki.lasad.agents.data.meta;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;

/**
 * An {@link AnalysisType} that is associated with a declarative description of
 * how to compute corresponding {@link AnalysisResult}s. The interpretation of
 * this string-based description is up to the {@link IAgent} who offers that
 * {@link AnalysisType}.
 * 
 * @author oliverscheuer
 * 
 */
public class RuleAnalysisType extends AnalysisType {

	private String rule;

	public RuleAnalysisType(Class<? extends AnalysisResult> resultType,
			String agentID, String typeID, String rule) {
		super(resultType, agentID, typeID);
		this.rule = rule;
	}

	public String getDefinition() {
		return rule;
	}

	public void setDefinition(String definition) {
		this.rule = definition;
	}
}
