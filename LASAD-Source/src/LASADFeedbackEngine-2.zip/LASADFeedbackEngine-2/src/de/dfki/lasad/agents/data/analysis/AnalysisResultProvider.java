package de.dfki.lasad.agents.data.analysis;

/**
 * 
 * @author oliverscheuer
 * 
 */
public interface AnalysisResultProvider {

	public void register(AnalysisResultListener listener);
}
