package de.dfki.lasad.events.agents;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Vector;

import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.session.data.SessionID;

/**
 * Provides {@link AnalysisResult} previously requested through a
 * {@link AnalysisRequestEvent}. Feedback-Engine internal communication.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AnalysisResultEvent extends SessionEvent {

	private Map<AnalysisType, List<AnalysisResult>> resultMap = new HashMap<AnalysisType, List<AnalysisResult>>();

	private UUID transactionID = null;

	public AnalysisResultEvent(SessionID sessionID, String srcCompId,
			Map<AnalysisType, List<AnalysisResult>> resultMap) {
		super(sessionID, srcCompId);
		this.resultMap = resultMap;
	}

	public void addResult(AnalysisResult result) {
		List<AnalysisResult> results = resultMap.get(result.getAnalysisType());
		if (results == null) {
			results = new Vector<AnalysisResult>();
			resultMap.put(result.getAnalysisType(), results);
		}
		results.add(result);
	}

	public void addResults(List<AnalysisResult> results) {
		for (AnalysisResult result : results) {
			addResult(result);
		}
	}

	public List<AnalysisResult> getResults(AnalysisType aType) {
		return resultMap.get(aType);
	}

	public Map<AnalysisType, List<AnalysisResult>> getResults() {
		return resultMap;
	}

	public Set<AnalysisType> getAnalysisType() {
		return resultMap.keySet();
	}

	/**
	 * 
	 * @return transactionID or <code>null</code> if event not part of an
	 *         transaction
	 */
	public UUID getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(UUID transactionID) {
		this.transactionID = transactionID;
	}

}
