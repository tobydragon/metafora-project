package de.dfki.lasad.core;

import java.io.File;

/**
 * for testing purposes: Grants access to fields in
 * {@link ConfigurationDatabase} that should not be modified in the runtume
 * system.
 * 
 * @author oliverscheuer
 * 
 */
public class ConfigurationDatabaseAccessor extends ConfigurationDatabase {

	static void setResourceDir(String relResourceDirName) {
		try {
			ConfigurationDatabase.resourcesDir = new File(configHome,
					relResourceDirName);
			ConfigurationDatabase.resourcesBasicFile = new File(
					ConfigurationDatabase.resourcesDir,
					ConfigurationDatabase.resourcesBasicLocalFilename);
			ConfigurationDatabase.resourcesAgentsFile = new File(
					ConfigurationDatabase.resourcesDir,
					ConfigurationDatabase.resourcesAgentsLocalFilename);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	static void setRuntimeDir(String relRuntimeDirName) {
		ConfigurationDatabase.runtimeDir = new File(configHome,
				relRuntimeDirName);
		ConfigurationDatabase.runtimeBasicFile = new File(
				ConfigurationDatabase.runtimeDir,
				ConfigurationDatabase.runtimeBasicLocalFilename);
		ConfigurationDatabase.runtimeAgentsFile = new File(
				ConfigurationDatabase.runtimeDir,
				ConfigurationDatabase.runtimeAgentsLocalFilename);
	}
}
