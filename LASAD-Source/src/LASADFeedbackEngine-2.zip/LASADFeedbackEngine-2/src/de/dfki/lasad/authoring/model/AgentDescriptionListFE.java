package de.dfki.lasad.authoring.model;

import java.util.List;
import java.util.Vector;

import org.jdom.Element;

import de.dfki.lasad.util.XMLUtil;

/**
 * a list of agent descriptions (to be used in the graphical frontend).
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescriptionListFE {

	private List<AgentDescriptionFE> agentDescriptions = new Vector<AgentDescriptionFE>();

	public Element toXMLElem() {
		Element descrsElem = new Element(ElementStrings.AGENT_DESCRIPTIONS);
		for (AgentDescriptionFE aDescr : agentDescriptions) {
			Element descrElem = aDescr.toXMLElem();
			descrsElem.addContent(descrElem);
		}
		return descrsElem;
	}

	public static AgentDescriptionListFE fromXMLElem(Element xml) {
		AgentDescriptionListFE aDescrList = new AgentDescriptionListFE();
		for (Element elem : (List<Element>) xml
				.getChildren(ElementStrings.AGENT_DESCRIPTION)) {
			AgentDescriptionFE aDescr = AgentDescriptionFE.fromXMLElem(elem);
			aDescrList.add(aDescr);
		}
		return aDescrList;
	}

	public void add(AgentDescriptionFE agentDescr) {
		agentDescriptions.add(agentDescr);
	}

	public String toXMLString() {
		Element e = toXMLElem();
		return XMLUtil.xmlElem2docString(e);
	}

	public static AgentDescriptionListFE fromXMLString(String xml) {
		Element e = XMLUtil.string2xmlElem(xml);
		return fromXMLElem(e);
	}

	@Override
	public String toString() {
		return "AgentDescriptionListFE [agentDescriptions=" + agentDescriptions
				+ "]";
	}

}
