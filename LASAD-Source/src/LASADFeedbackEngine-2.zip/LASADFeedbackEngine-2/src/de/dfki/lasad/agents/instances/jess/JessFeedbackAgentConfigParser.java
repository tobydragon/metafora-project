package de.dfki.lasad.agents.instances.jess;

import java.io.File;
import java.io.StringWriter;
import java.util.List;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import de.dfki.lasad.agents.data.analysis.BinaryResult;
import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.CompoundActionType;
import de.dfki.lasad.agents.data.meta.RuleAnalysisType;
import de.dfki.lasad.agents.data.meta.AnalysisActionType;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessFeedbackAgentConfigParser {

	static Log logger = LogFactory.getLog(JessFeedbackAgentConfigParser.class);

	public void fillInConfigFromFile(File confFile,
			JessFeedbackAgentConfiguration conf) {
		try {

			SAXBuilder builder = new SAXBuilder();
			Document doc = builder.build(confFile);

			Element agentElem = doc.getRootElement();
			String agentID = agentElem.getAttributeValue("id");
			conf.setAgentID(agentID);

			String exposeAllString = agentElem.getAttributeValue("expose_all");
			if (exposeAllString != null && Boolean.valueOf(exposeAllString)) {
				boolean exposeAll = Boolean.valueOf(exposeAllString);
				conf.setPublishAllActionTypes(exposeAll);
			}

			String provideRawResultsString = agentElem
					.getAttributeValue("raw_results");
			if (provideRawResultsString != null
					&& Boolean.valueOf(provideRawResultsString)) {
				conf.setProvideRawResults(Boolean
						.valueOf(provideRawResultsString));
			}

			Element supportedOntologiesElem = agentElem
					.getChild("supported_ontologies");
			String supportAllOntologiesString = supportedOntologiesElem
					.getAttributeValue("support_all");
			if (supportAllOntologiesString != null
					&& Boolean.valueOf(supportAllOntologiesString)) {
				conf.setSupportedAllOntologies();
			} else {
				@SuppressWarnings("unchecked")
				List<Element> ontologyIDElements = supportedOntologiesElem
						.getChildren("ontology");
				List<String> supportedOntologyIDs = parseOntologyIDElements(ontologyIDElements);
				conf.setSupportedOntologies(supportedOntologyIDs);
			}

			Element phaseDefElem = agentElem.getChild("phase_def");
			@SuppressWarnings("unchecked")
			List<Element> phaseIDElements = phaseDefElem.getChildren("phase");
			List<String> phaseIDs = parsePhaseIDElements(phaseIDElements);
			conf.setPhaseIDs(phaseIDs);

			@SuppressWarnings("unchecked")
			Element patternsElement = agentElem.getChild("patterns");
			@SuppressWarnings("unchecked")
			List<Element> patternElements = patternsElement
					.getChildren("pattern");
			List<RuleAnalysisType> patterns = parsePatternElements(
					patternElements, agentID);
			addPatternsToConf(patterns, conf);

			@SuppressWarnings("unchecked")
			List<Element> ruleActionElements = agentElem
					.getChildren("rule-action");
			List<AnalysisActionType> simpleActionTypes = parseSimpleActionElements(
					ruleActionElements, agentID, conf);
			addSimpleActionsToConf(simpleActionTypes, conf);

			@SuppressWarnings("unchecked")
			List<Element> filterActionElements = agentElem
					.getChildren("filter-action");
			List<CompoundActionType> compoundActionTypes = parseFilterActionElements(
					filterActionElements, agentID, simpleActionTypes);
			addFilterActionElementsToConf(compoundActionTypes, conf);

		} catch (Exception e) {
			logger.error("Error while parsing conf file: " + e.getClass()
					+ ": " + e.getMessage(), e);
		}
	}

	private void addPatternsToConf(List<RuleAnalysisType> patterns,
			JessFeedbackAgentConfiguration conf) {
		for (RuleAnalysisType p : patterns) {
			conf.addRuleAnalysisType(p);
		}
	}

	private void addSimpleActionsToConf(
			List<AnalysisActionType> simpleActionTypes,
			JessFeedbackAgentConfiguration conf) {
		for (AnalysisActionType ruleActionType : simpleActionTypes) {
			conf.addSimpleActionType(ruleActionType);
		}
	}

	private List<String> parsePhaseIDElements(List<Element> phaseIDElements) {
		List<String> phaseIDs = new Vector<String>();
		for (Element phaseIDElem : phaseIDElements) {
			String phaseID = phaseIDElem.getAttributeValue("id");
			phaseIDs.add(phaseID);
		}
		return phaseIDs;
	}

	private List<String> parseOntologyIDElements(
			List<Element> ontologyIDElements) {
		List<String> ontologyIDs = new Vector<String>();
		for (Element ontologyIDElem : ontologyIDElements) {
			String ontologyID = ontologyIDElem.getAttributeValue("idref");
			ontologyIDs.add(ontologyID);
		}
		return ontologyIDs;
	}

	private List<RuleAnalysisType> parsePatternElements(
			List<Element> patternElements, String agentID) {

		List<RuleAnalysisType> result = new Vector<RuleAnalysisType>();
		for (Element patternElem : patternElements) {
			String pID = patternElem.getAttributeValue("id");
			String def = patternElem.getText();
			RuleAnalysisType patDef = new RuleAnalysisType(BinaryResult.class,
					agentID, pID, def);
			result.add(patDef);
		}
		return result;
	}

	private List<AnalysisActionType> parseSimpleActionElements(
			List<Element> ruleActionElements, String agentID,
			JessFeedbackAgentConfiguration conf) {

		List<AnalysisActionType> simpleActionTypes = new Vector<AnalysisActionType>();
		for (Element ruleActionElem : ruleActionElements) {
			String actionTypeID = ruleActionElem.getAttributeValue("id");

			Element patternElem = ruleActionElem.getChild("pattern");
			String analysisTypeID = patternElem.getAttributeValue("idref");
			RuleAnalysisType ruleType = conf
					.getRuleAnalysisType(analysisTypeID);

			AnalysisActionType simpleType = new AnalysisActionType(agentID,
					actionTypeID, ruleType);

			Element displayNameElement = ruleActionElem
					.getChild("display-name");
			if (displayNameElement != null) {
				String displayName = displayNameElement.getText();
				simpleType.setDisplayName(displayName);
			}

			Element feedbackShortElem = ruleActionElem
					.getChild("feedback-short");
			String feedbackShort = feedbackShortElem.getTextNormalize();
			simpleType.setFeedbackShort(feedbackShort);

			Element feedbackLongElem = ruleActionElem.getChild("feedback-long");
			String feedbackLong = feedbackLongElem.getTextNormalize();
			simpleType.setFeedbackLong(feedbackLong);

			Element highlightingElem = ruleActionElem.getChild("highlighting");
			String highlightingString = highlightingElem.getTextNormalize();
			boolean highlighting = Boolean.parseBoolean(highlightingString);
			simpleType.setHighlighting(highlighting);

			Element additionalParamsElem = ruleActionElem
					.getChild("addition-params");
			if (additionalParamsElem != null) {
				@SuppressWarnings("unchecked")
				List<Element> paramElems = additionalParamsElem
						.getChildren("param");
				parseAdditionalParameters(simpleType, paramElems);
			}

			Element phasesElem = ruleActionElem.getChild("phases");
			@SuppressWarnings("unchecked")
			List<Element> phaseElements = phasesElem.getChildren("phase");
			for (Element phaseElem : phaseElements) {
				String phaseID = phaseElem.getAttributeValue("idref");
				Element priorityElem = phaseElem.getChild("priority");
				int priority = Integer.parseInt(priorityElem
						.getAttributeValue("value"));
				simpleType.addPriority(phaseID, priority);

				Element representativenessElem = phaseElem
						.getChild("representativeness");
				int representativeness = Integer
						.parseInt(representativenessElem
								.getAttributeValue("value"));
				simpleType.addRepresentativeness(phaseID, representativeness);
			}
			Element defaultSettingsElem = phasesElem.getChild("default");
			if (defaultSettingsElem != null) {
				Element priorityElem = defaultSettingsElem.getChild("priority");
				int priority = Integer.parseInt(priorityElem
						.getAttributeValue("value"));
				simpleType.setDefaultPriority(priority);

				Element representativenessElem = defaultSettingsElem
						.getChild("representativeness");
				int representativeness = Integer
						.parseInt(representativenessElem
								.getAttributeValue("value"));
				simpleType.setDefaultRepresentativeness(representativeness);
			}

			Element exposeElem = ruleActionElem.getChild("expose");
			boolean doExpose = Boolean.parseBoolean(exposeElem.getTextTrim());
			simpleType.setDoPublishToEndUser(doExpose);

			simpleActionTypes.add(simpleType);
		}
		return simpleActionTypes;
	}

	private void parseAdditionalParameters(AnalysisActionType actionType,
			List<Element> paramElems) {
		for (Element paramElem : paramElems) {
			String paramName = paramElem.getAttributeValue("name");
			String paramValue = paramElem.getAttributeValue("value");
			Boolean paramIsDynamic = Boolean.parseBoolean(paramElem
					.getAttributeValue("dynamic"));
			if (paramIsDynamic) {
				actionType.addDynamicParam(paramName);
			} else {
				// assume: param is static
				actionType.addParam(paramName, paramValue);
			}
		}
	}

	private void addFilterActionElementsToConf(
			List<CompoundActionType> filterActionTypes,
			JessFeedbackAgentConfiguration conf) {
		for (CompoundActionType compoundActionType : filterActionTypes) {
			conf.addCompoundActionType(compoundActionType);
		}
	}

	private List<CompoundActionType> parseFilterActionElements(
			List<Element> filterActionElements, String agentID,
			List<AnalysisActionType> simpleActionTypes) {
		List<CompoundActionType> compoundActionTypes = new Vector<CompoundActionType>();
		for (Element filterActionElem : filterActionElements) {
			String typeID = filterActionElem.getAttributeValue("id");
			CompoundActionType actionType = new CompoundActionType(agentID,
					typeID);

			Element displayNameElement = filterActionElem
					.getChild("display-name");
			if (displayNameElement != null) {
				String displayName = displayNameElement.getTextNormalize();
				actionType.setDisplayName(displayName);
			}

			Element numberElem = filterActionElem.getChild("number");
			String numberString = numberElem.getTextTrim();
			if ("all".equals(numberString)) {
				actionType.setMaxNumResults(CompoundActionType.ALL_RESULTS);
			} else {
				try {
					int number = Integer.parseInt(numberString);
					actionType.setMaxNumResults(number);
				} catch (NumberFormatException e) {
					logger.warn("Parameter 'number' not formatted correctly "
							+ "in config file. Will use default value: "
							+ actionType.getMaxNumResults());
				}
			}

			Element dependentActionsElem = filterActionElem
					.getChild("subactions");

			String allSubTypesString = dependentActionsElem
					.getAttributeValue("all");
			if (allSubTypesString != null && Boolean.valueOf(allSubTypesString)) {
				boolean allSubTypes = Boolean.valueOf(allSubTypesString);
				actionType.setAllTypes(allSubTypes);

				for (ActionType subType : simpleActionTypes) {
					actionType.addActionType(subType);
				}
			} else {
				@SuppressWarnings("unchecked")
				List<Element> agentElements = dependentActionsElem
						.getChildren("action");
				for (Element agentElem : agentElements) {
					String dependentTypeID = agentElem
							.getAttributeValue("type");
					for (ActionType subType : simpleActionTypes) {
						if (subType.getTypeID().equals(dependentTypeID)) {
							actionType.addActionType(subType);
						}
					}
				}
			}

			Element filterCriteriaElem = filterActionElem
					.getChild("filter-criteria");
			@SuppressWarnings("unchecked")
			List<Element> criterionElements = filterCriteriaElem
					.getChildren("criterion");
			for (Element criterionElement : criterionElements) {
				String criterionType = criterionElement
						.getAttributeValue("type");
				actionType.addFilterCriterion(criterionType);
			}

			Element exposeElem = filterActionElem.getChild("expose");
			boolean doExpose = Boolean.parseBoolean(exposeElem.getTextTrim());
			actionType.setDoPublishToEndUser(doExpose);

			compoundActionTypes.add(actionType);
		}
		return compoundActionTypes;
	}

	private String getXMLContentAsString(Element elem) {
		try {
			StringWriter writer = new StringWriter();
			XMLOutputter xmlOutputter = new XMLOutputter(Format.getRawFormat());
			xmlOutputter.output(elem.getContent(), writer);
			return writer.toString();
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}
}
