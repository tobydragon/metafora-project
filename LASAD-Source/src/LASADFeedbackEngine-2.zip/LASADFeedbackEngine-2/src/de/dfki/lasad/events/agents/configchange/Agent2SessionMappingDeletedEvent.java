package de.dfki.lasad.events.agents.configchange;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class Agent2SessionMappingDeletedEvent extends AFStateChangedEvent {

	private String agentID;
	private String sessionID;

	public Agent2SessionMappingDeletedEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getAgentID() {
		return agentID;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	@Override
	public String toString() {
		return "Agent2SessionMappingDeletedEvent [agentID=" + agentID
				+ ", sessionID=" + sessionID + "]";
	}

}
