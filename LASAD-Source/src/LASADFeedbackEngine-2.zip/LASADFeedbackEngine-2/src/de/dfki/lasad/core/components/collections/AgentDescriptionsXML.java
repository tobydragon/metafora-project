package de.dfki.lasad.core.components.collections;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.AgentDescriptionXML;

/**
 * XML (de-)serialization for {@link AgentDescriptions} objects.
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescriptionsXML {

	static Log logger = LogFactory.getLog(AgentDescriptionsXML.class);

	public static AgentDescriptions fromXML(Element agentsElem) {
		AgentDescriptions agentDescrs = new AgentDescriptions();

		for (Element elem : (List<Element>) agentsElem.getChildren("agent")) {
			AgentDescription aDescr = AgentDescriptionXML.fromXML(elem);
			agentDescrs.addOrUpdateDescription(aDescr);
		}
		return agentDescrs;
	}

	public static Element toXML(AgentDescriptions agentDescrs) {

		Element resourcesElem = new Element("agents");

		for (AgentDescription aDescr : agentDescrs.getAgentDescriptions()) {
			Element childElem = AgentDescriptionXML.toXML(aDescr);
			resourcesElem.addContent(childElem);
		}
		return resourcesElem;
	}

	public static void updateXMLFile(File file, AgentDescriptions agentDescrs) {
		try {
			if (file.exists()) {
				file.delete();
			}
			Element elem = toXML(agentDescrs);
			XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
			Document doc = new Document();
			doc.setRootElement(elem);
			outputter.output(doc, new FileWriter(file));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

}
