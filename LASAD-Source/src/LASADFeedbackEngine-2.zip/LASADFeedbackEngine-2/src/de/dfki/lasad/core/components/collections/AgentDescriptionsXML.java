package de.dfki.lasad.core.components.collections;

import java.io.File;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.AgentDescriptionXML;
import de.dfki.lasad.util.XMLUtil;

/**
 * XML (de-)serialization for {@link AgentDescriptions} objects.
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescriptionsXML {

	static Log logger = LogFactory.getLog(AgentDescriptionsXML.class);

	public static AgentDescriptions fromXML(Element agentsElem) {
		AgentDescriptions agentDescrs = new AgentDescriptions();

		for (Element elem : (List<Element>) agentsElem.getChildren("agent")) {
			AgentDescription aDescr = AgentDescriptionXML.fromXML(elem);
			agentDescrs.addOrUpdateDescription(aDescr);
		}
		return agentDescrs;
	}

	public static Element toXML(AgentDescriptions agentDescrs) {

		Element resourcesElem = new Element("resources");

		for (AgentDescription aDescr : agentDescrs.getAgentDescriptions()) {
			Element childElem = AgentDescriptionXML.toXML(aDescr);
			resourcesElem.addContent(childElem);
		}
		return resourcesElem;
	}

	/**
	 * Creates (or overwrites) given file with given {@link AgentDescriptions}
	 * 
	 * @param file
	 * @param agentDescrs
	 */
	public static void updateXMLFile(File file, AgentDescriptions agentDescrs) {
		try {
			Element elem = toXML(agentDescrs);
			XMLUtil.xmlElem2File(file, elem);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

}
