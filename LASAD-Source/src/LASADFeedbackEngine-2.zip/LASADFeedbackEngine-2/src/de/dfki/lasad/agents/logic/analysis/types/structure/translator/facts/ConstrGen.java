package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Num2NumOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Operator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2SetOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Set2StringOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2SetOperator;
import lasad.shared.dfki.meta.agents.analysis.structure.model.String2StringOperator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ConstrGen {

	private static final Log logger = LogFactory.getLog(ConstrGen.class);

	private JessIDAndSlotNameGenerator idGen;

	// in
	private Comparison comparison;
	private Bin bin;
	private int tempVarAppendix;
	private boolean useTempVarLeft;
	private boolean useTempVarRight;

	// generated
	private ConstrLHSGen lhsGen;
	private ConstrRHSGen rhsGen;

	/**
	 * Generates one slot constraint based on given {@link Comparison},
	 * according to given specification.
	 * 
	 * @param comparison
	 *            {@link Comparison}
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 * @param useElemTempVar
	 *            use appendix for elem variable
	 * @param useTempVarLeft
	 *            use appendix for property variable on the LHS of the
	 *            {@link Comparison}
	 * @param useTempVarRight
	 *            use appendix for property variable on the RHS of the
	 *            {@link Comparison}
	 */
	public ConstrGen(JessIDAndSlotNameGenerator idGen, Comparison comparison,
			Bin bin, int tempVarAppendix, boolean useTempVarLeft,
			boolean useTempVarRight) {
		this.idGen = idGen;
		this.comparison = comparison;
		this.bin = bin;
		this.tempVarAppendix = tempVarAppendix;
		this.useTempVarLeft = useTempVarLeft;
		this.useTempVarRight = useTempVarRight;

		this.lhsGen = new ConstrLHSGen(idGen, comparison.getLeftExpr(),
				tempVarAppendix, useTempVarLeft);

		this.rhsGen = new ConstrRHSGen(idGen, comparison, tempVarAppendix,
				useTempVarRight);

	}

	public String getString() {
		String leftExp = lhsGen.getString();
		String rightExp = rhsGen.getString();
		return generateComparison(comparison, leftExp, rightExp, bin);
	}

	/**
	 * Generates Jess string for given {@link Comparison}.
	 * 
	 * @param comparison
	 * @param leftExp
	 * @param rightExp
	 * @param bin
	 * @return
	 */
	private String generateComparison(Comparison comparison, String leftExp,
			String rightExp, Bin bin) {

		if (bin.getNum() <= 2) {
			return getValue2ValueComparison(comparison, leftExp, rightExp);
		} else if (bin.getNum() <= 6) {
			return getComponent2ValueComparison(comparison, leftExp, rightExp);
		} else {
			return getComponent2ComponentComparison(comparison, leftExp,
					rightExp);
		}
	}

	private static String getValue2ValueComparison(Comparison comparison,
			String leftExp, String rightExp) {
		Operator operator = comparison.getOperator();
		if (operator.equals(String2StringOperator.EQUAL)
				|| operator.equals(Num2NumOperator.EQUAL)) {
			return "&:(eq* " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(String2StringOperator.NOT_EQUAL)
				|| operator.equals(Num2NumOperator.NOT_EQUAL)) {
			return "&:(not (eq* " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Num2NumOperator.LESS)) {
			return "&:(< " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Num2NumOperator.LESS_OR_EQUAL)) {
			return "&:(<= " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Num2NumOperator.GREATER)) {
			return "&:(> " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Num2NumOperator.GREATER_OR_EQUAL)) {
			return "&:(>= " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(String2SetOperator.IN)) {
			return "&:(member$ " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(String2SetOperator.NOT_IN)) {
			return "&:(not(member$ " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Set2StringOperator.CONTAINS)) {
			return "&:(member$ " + rightExp + " " + leftExp + ")";
		} else if (operator.equals(Set2StringOperator.NOT_CONTAINS)) {
			return "&:(not(member$ " + rightExp + " " + leftExp + "))";
		} else if (operator.equals(Set2SetOperator.SUBSET)) {
			return "&:(= length$(complement$ " + leftExp + " " + rightExp
					+ ") 0)";
		} else if (operator.equals(Set2SetOperator.NOT_SUBSET)) {
			return "&:(> length$(complement$ " + leftExp + " " + rightExp
					+ ") 0)";
		} else if (operator.equals(Set2SetOperator.SUPERSET)) {
			return "&:(= length$(complement$ " + rightExp + " " + leftExp
					+ ") 0)";
		} else if (operator.equals(Set2SetOperator.NOT_SUPERSET)) {
			return "&:(> length$(complement$ " + rightExp + " " + leftExp
					+ ") 0)";
		} else if (operator.equals(Set2SetOperator.INTERSECT)) {
			return "&:(> length$(intersection$ " + leftExp + " " + rightExp
					+ ") 0)";
		} else if (operator.equals(Set2SetOperator.NOT_INTERSECT)) {
			return "&:(= length$(intersection$ " + leftExp + " " + rightExp
					+ ") 0)";
		}
		logger.error("Unhandled operator in 'getValue2ValueComparison()': "
				+ operator);
		return null;
	}

	private String getComponent2ValueComparison(Comparison comparison,
			String leftExp, String rightExp) {
		Operator operator = comparison.getOperator();
		if (operator.equals(Set2StringOperator.CONTAINS)) {
			// nested in EXISTS expression
			return "&:(eq " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2StringOperator.NOT_CONTAINS)) {
			// nested in FORALL expression
			return "&:(not(eq " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Set2SetOperator.SUBSET)) {
			// nested in EXISTS expression
			return "&:(member$ " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2SetOperator.NOT_SUBSET)) {
			// nested in FORALL expression
			return "&:(not(member$ " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Set2SetOperator.INTERSECT)) {
			// nested in EXISTS expression
			return "&:(member$ " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2SetOperator.NOT_INTERSECT)) {
			// nested in FORALL expression
			return "&:(not(member$ " + leftExp + " " + rightExp + "))";
		}
		logger.error("Unhandled operator in 'getComponent2ValueComparison()': "
				+ operator);
		return null;
	}

	private String getComponent2ComponentComparison(Comparison comparison,
			String leftExp, String rightExp) {
		Operator operator = comparison.getOperator();
		if (operator.equals(Set2SetOperator.SUBSET)) {
			return "&:(eq " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2SetOperator.SUPERSET)) {
			return "&:(eq " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2SetOperator.INTERSECT)) {
			return "&:(eq " + leftExp + " " + rightExp + ")";
		} else if (operator.equals(Set2SetOperator.NOT_SUBSET)) {
			return "&:(not(eq " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Set2SetOperator.NOT_SUPERSET)) {
			return "&:(not(eq " + leftExp + " " + rightExp + "))";
		} else if (operator.equals(Set2SetOperator.NOT_INTERSECT)) {
			return "&:(not(eq " + leftExp + " " + rightExp + "))";
		}
		logger.error("Unhandled operator in 'getComponent2ComponentComparison(): "
				+ operator);
		return null;
	}
}
