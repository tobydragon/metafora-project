package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import junit.framework.TestCase;

public class KeyToMappingTemplateTest extends TestCase {

	public void testKeyMapping(){
		KeyToTemplateMapping keyToTemplateMapping = new KeyToTemplateMapping("conf/metafora/details/agents/types/xmpp/cf-key-to-template-settings.xml");
		assertEquals("DiscussingMicroworlds-4", keyToTemplateMapping.getTemplate("0"));
		assertEquals("DiscussingPlans-1", keyToTemplateMapping.getTemplate("1"));
		assertEquals("DiscussingMicroworlds-4", keyToTemplateMapping.getTemplate("3"));

	}
}
