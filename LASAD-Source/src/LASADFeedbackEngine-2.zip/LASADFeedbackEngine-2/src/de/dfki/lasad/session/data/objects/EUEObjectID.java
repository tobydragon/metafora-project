package de.dfki.lasad.session.data.objects;

import de.dfki.lasad.session.data.EUEID;

public class EUEObjectID extends EUEID {

	public EUEObjectID(String id) {
		super(id);
	}
}
