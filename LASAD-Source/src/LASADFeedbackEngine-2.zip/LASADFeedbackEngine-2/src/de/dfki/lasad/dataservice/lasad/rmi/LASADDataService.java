package de.dfki.lasad.dataservice.lasad.rmi;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.ActionPackage;
import lasad.shared.communication.objects.Parameter;
import lasad.shared.dfki.meta.ServiceStatus;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.DefaultEventPrioritizer;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.instance.IComponent;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.dataservice.AbstractDataService;
import de.dfki.lasad.dataservice.lasad.ActionPackageFactory;
import de.dfki.lasad.dataservice.lasad.AnalysisAndFeedbackTypeAdapter;
import de.dfki.lasad.dataservice.lasad.translators.EventTranslatorAF2LASAD;
import de.dfki.lasad.dataservice.lasad.translators.EventTranslatorAgentAuthoringOut;
import de.dfki.lasad.dataservice.lasad.translators.EventTranslatorLASAD2AF;
import de.dfki.lasad.dataservice.lasad.translators.LASADVocabulary;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.events.agents.OnRequestServiceSpec;
import de.dfki.lasad.events.agents.OnRequestServicesPublishEvent;
import de.dfki.lasad.events.agents.OnRequestServicesUnpublishEvent;
import de.dfki.lasad.events.agents.configchange.AFStateChangedEvent;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;
import de.dfki.lasad.events.eue.admin.config.OntologyListEvent;
import de.dfki.lasad.events.eue.admin.config.SessionListEvent;
import de.dfki.lasad.events.eue.admin.session.SessionOverviewEvent;
import de.dfki.lasad.session.SessionConfig;
import de.dfki.lasad.session.data.SessionID;

/**
 * {@link IDataService} implementation to interact with the LASAD-Server over an
 * RMI interface.
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent}, {@link IDataService},
 * {@link AbstractDataService})
 * 
 * @author oliverscheuer
 * 
 */
public class LASADDataService extends AbstractDataService {

	private static Log logger = LogFactory.getLog(LASADDataService.class);

	protected ActionPackageFactory actionPackageFactory;

	private EventTranslatorLASAD2AF eventTranslatorLASAD2AF;
	private EventTranslatorAF2LASAD eventTranslatorAF2LASAD;
	private RemoteSenderRMI remoteActionSender;
	private RemoteListenerRMI actionListenerServer;

	private LASADDataServiceConfiguration configuration;

	// flag indicating whether initial SessionListEvent has already been created
	private boolean initializeSessionListEventCreated = false;

	@Override
	public void init(AbstractComponentDescription description,
			SessionConfig sessionConfig) {
		super.init(description, sessionConfig);
		configuration = (LASADDataServiceConfiguration) description
				.getConfiguration();

		actionPackageFactory = new ActionPackageFactory(
				configuration.getClientName(), configuration.getUsername(),
				configuration.getPassword(), LASADVocabulary.ACTION_METHOD_RMI);
		eventTranslatorLASAD2AF = new EventTranslatorLASAD2AF();
		eventTranslatorAF2LASAD = new EventTranslatorAF2LASAD(
				actionPackageFactory);

		remoteActionSender = new RemoteSenderRMI();
		remoteActionSender.register(this);
		remoteActionSender.setConfiguration(configuration);
		setServiceStatus(ServiceStatus.READY_TO_START);
	}

	@Override
	protected void startServiceImpl() {
		super.startServiceImpl();
		remoteActionSender.init();
		prepareAndStartListeningServer();
		registerAtRemoteServer();
		setupAutoHeartBeatIfConfigured();

		requestOntologyIDs();
		requestSessionOverview();

		MyShutdownHook shutdownHook = new MyShutdownHook();
		Runtime.getRuntime().addShutdownHook(shutdownHook);
	}

	@Override
	protected void stopServiceImpl() {
		logger.info("Stopping event processing thread ...");
		super.stopServiceImpl();
		logger.info("Stopping event processing thread: DONE.");

		logger.info("Unregister feedback menu entries ...");
		logger.info("...maps: " + eventTranslatorLASAD2AF.getSupportedMaps());
		for (String mapID : eventTranslatorLASAD2AF.getSupportedMaps()) {
			leaveSessionAtRemoteService(mapID);
		}
		logger.info("Unregister feedback menu entries: DONE");

		ActionPackage logoutMessage = actionPackageFactory
				.createLogoutMessage();
		logger.info("Sending out logout message: " + logoutMessage);
		sendActionPackage(logoutMessage);
	}

	public void setActionListeningService(RemoteListenerRMI actionListenerServer) {
		this.actionListenerServer = actionListenerServer;
	}

	/**
	 * Set up and start RMI Listener
	 */
	private void prepareAndStartListeningServer() {
		if (actionListenerServer == null) {
			actionListenerServer = new RemoteListenerRMI();
		}
		actionListenerServer.register(this);

		actionListenerServer.registerAtServerRegistry(
				configuration.getServerIP(),
				configuration.getServerRegistryPort(),
				configuration.getClientRegistryPort(),
				configuration.getUsername());
	}

	/**
	 * Send 'Login' message to remote LASAD server
	 */
	private void registerAtRemoteServer() {
		ActionPackage loginRequest = actionPackageFactory.createLoginMessage();
		sendActionPackage(loginRequest);
	}

	/**
	 * Send 'Request-Ontology-IDs' message to remote LASAD server
	 */
	private void requestOntologyIDs() {
		ActionPackage getOntologyIDsRequest = actionPackageFactory
				.createGetOntologyIDsMessage();
		sendActionPackage(getOntologyIDsRequest);
	}

	/**
	 * Send 'Request-Session-Overview' message to remote LASAD server (to get:
	 * sessionIDs incl. IDs of used Template and Ontologies)
	 */
	private void requestSessionOverview() {
		ActionPackage listMapIDsRequest = actionPackageFactory
				.createListMapsMessage();
		sendActionPackage(listMapIDsRequest);
	}

	/**
	 * Send 'Request-Ontology-Details' message to remote LASAD server (to get:
	 * ontologyXML)
	 */
	private void requestOntologyDetails(String ontologyID) {
		ActionPackage getOntologyDetailsRequest = actionPackageFactory
				.createGetOntologyDetailsMessage(ontologyID);
		sendActionPackage(getOntologyDetailsRequest);
	}

	/**
	 * Send 'Request-Ontology-Info' message to remote LASAD server (to get:
	 * ontologyXML)
	 */
	private void requestOntologyInfo(SessionID sessionID) {
		ActionPackage getOntologyInfosRequest = actionPackageFactory
				.createGetOntologyMessage(sessionID.getIdAsString());
		sendActionPackage(getOntologyInfosRequest);
	}

	/**
	 * Send 'Request-Template-Info' message to remote LASAD server (to get:
	 * templateXML)
	 */
	private void requestTemplateInfo(SessionID sessionID) {
		ActionPackage getMapDetailsRequest = actionPackageFactory
				.createGetMapDetailsMessage(sessionID.getIdAsString());
		sendActionPackage(getMapDetailsRequest);
	}

	/**
	 * Send 'Join-Map' message and 'Register-Feedback-Menu-Item' messages to
	 * remote LASAD server
	 */
	private void joinSessionAtRemoteServer(SessionID sessionID,
			List<OnRequestServiceSpec> services) {
		ActionPackage joinRequest = actionPackageFactory
				.createJoinMapMessage(sessionID.getIdAsString());
		sendActionPackage(joinRequest);

		for (OnRequestServiceSpec service : services) {

			String mapID = sessionID.getIdAsString();
			String serviceName = service.getDisplayName();
			String agentID = service.getProvisionServiceID().getAgentID();
			String typeID = service.getProvisionServiceID().getTypeID();

			if (AnalysisAndFeedbackTypeAdapter.getServiceTypeID(mapID, agentID,
					serviceName) == null) {
				AnalysisAndFeedbackTypeAdapter.addMapping(mapID, agentID,
						typeID, serviceName);
				logger.debug("Add mapping <action type> -> <display type>: ("
						+ agentID + ", " + typeID + ") -> " + serviceName);
				ActionPackage announceServices = actionPackageFactory
						.createPublishServiceMessage(mapID, agentID,
								serviceName);
				sendActionPackage(announceServices);
			} else {
				logger.error("Display type '" + serviceName
						+ "' has already been announced to server. Ignore.");
			}
		}
	}

	/**
	 * Send 'Leave-Map' message and 'Unregister-Feedback-Menu-Item' messages to
	 * remote LASAD server
	 */
	private void leaveSessionAtRemoteService(String mapID) {
		logger.info("Shutting down services for session " + mapID
				+ ". Unregister feedback menu entries ...");
		Set<String> feedbackMenuItemIDs = eventTranslatorLASAD2AF
				.getFeedbackMenuItemIDs(mapID);
		for (String feedbackMenuItemID : feedbackMenuItemIDs) {
			ActionPackage deleteFeedbackMenuItemMessage = actionPackageFactory
					.createDeleteElementMessage(mapID, feedbackMenuItemID);
			logger.info("Sending out message for session " + mapID
					+ ", feedback menu item ID = " + feedbackMenuItemID);
			sendActionPackage(deleteFeedbackMenuItemMessage);
		}

		ActionPackage leaveMapMessage = actionPackageFactory
				.createLeaveMapMessage(mapID);
		logger.info("Sending out message for leaving session " + mapID + ": "
				+ leaveMapMessage);
		sendActionPackage(leaveMapMessage);
	}

	/**
	 * Process {@link ActionPackage} received from RMIListener
	 */
	public void processActionPackage(ActionPackage actionPackage) {
		sendHeartbeatIfRequested(actionPackage);
		List<EUEEvent> events = eventTranslatorLASAD2AF
				.translate(actionPackage);

		for (EUEEvent event : events) {
			if (event instanceof SessionOverviewEvent) {
				if (!initializeSessionListEventCreated) {
					createInitialSessionListEvent(events);
				}
				SessionOverviewEvent listMapEvent = (SessionOverviewEvent) event;
				SessionID sessionID = listMapEvent.getSessionID();
				logger.debug("[processActionPackage] SessionOverviewEvent received: " + listMapEvent.toString());
				requestOntologyInfo(sessionID);
				requestTemplateInfo(sessionID);
			} else if (event instanceof OntologyListEvent) {
				OntologyListEvent ontoIDListEvent = (OntologyListEvent) event;
				for (String ontologyID : ontoIDListEvent.getOntologyIDs()) {
					requestOntologyDetails(ontologyID);
				}
			}
			logger.debug("[processActionPackage] session event received: " + event.toString());
			sessionManager.onEvent(event);
		}
	}

	/**
	 * Creates {@link SessionListEvent} based on the provided
	 * {@link SessionOverviewEvent}s to represent the set of sessions existent
	 * at the LASAD-Server at one point in time.
	 * 
	 * Assumption: all initial SessionOverviewEvents are contained in the input
	 * list, i.e., the list describes the complete initial state of the
	 * LASAD-Server
	 * 
	 * @param events
	 */
	private void createInitialSessionListEvent(List<EUEEvent> events) {
		Set<String> sessionIDs = new HashSet<String>();
		long ts = Long.MAX_VALUE;
		for (Event e : events) {
			if (e instanceof SessionOverviewEvent) {
				SessionOverviewEvent sEvent = (SessionOverviewEvent) e;
				String sID = sEvent.getSessionID().getIdAsString();
				sessionIDs.add(sID);
				if (e.getTs() < ts) {
					ts = e.getTs();
				}
			}
		}
		if (ts == Long.MAX_VALUE) {
			ts = System.currentTimeMillis();
		}
		SessionListEvent sListEvent = new SessionListEvent(
				this.getComponentID());
		sListEvent.setSessionIDs(new Vector<String>(sessionIDs));
		sListEvent.setTs(ts);
		DefaultEventPrioritizer.assignPriority(sListEvent);
		sessionManager.onEvent(sListEvent);
	}

	/**
	 * Send {@link ActionPackage} to LASAD-Server (using RMI-Sender)
	 */
	protected void sendActionPackage(final ActionPackage outPackage) {
		try {
			remoteActionSender.doActionOnServer(outPackage);
		} catch (RemoteException e) {
			System.out.println("Error sendActionPackage: " + e.getClass()
					+ ": " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Translate {@link EventImpl} produced within Feedback-Engine into an
	 * {@link ActionPackage} and send out {@link ActionPackage} to LASAD-Server
	 */
	@Override
	protected void processEvent(Event event) {
		if (event instanceof ActionSpecEvent) {
			List<ActionPackage> actionPackages = eventTranslatorAF2LASAD
					.translate((ActionSpecEvent) event);
			for (ActionPackage aPackage : actionPackages) {
				sendActionPackage(aPackage);
			}
		}

		else if (event instanceof OnRequestServicesPublishEvent) {
			OnRequestServicesPublishEvent startServicesEvent = (OnRequestServicesPublishEvent) event;
			SessionID sessionID = startServicesEvent.getSessionID();
			List<OnRequestServiceSpec> services = startServicesEvent
					.getServices();
			joinSessionAtRemoteServer(sessionID, services);
		}

		else if (event instanceof OnRequestServicesUnpublishEvent) {
			OnRequestServicesUnpublishEvent stopServicesEvent = (OnRequestServicesUnpublishEvent) event;
			SessionID sessionID = stopServicesEvent.getSessionID();
			String sessionIDString = sessionID.getIdAsString();
			leaveSessionAtRemoteService(sessionIDString);
		}

		else if (event instanceof EUEAgentAdminEvent) {
			EUEAgentAdminEvent agentAdminEvent = (EUEAgentAdminEvent) event;
			ActionPackage agentAdminMessage = EventTranslatorAgentAuthoringOut
					.translate(agentAdminEvent);
			if (agentAdminMessage != null) {
				agentAdminMessage.getParameters().add(
						actionPackageFactory.getSessionParam());
				logger.info("Sending out message: " + agentAdminMessage);
				sendActionPackage(agentAdminMessage);
			}
		}

		else if (event instanceof AFStateChangedEvent) {
			AFStateChangedEvent afStateChangedEvent = (AFStateChangedEvent) event;
			ActionPackage stateChangedMessage = EventTranslatorAgentAuthoringOut
					.translate(afStateChangedEvent);
			if (stateChangedMessage != null) {
				stateChangedMessage.getParameters().add(
						actionPackageFactory.getSessionParam());
				logger.info("Sending out message: " + stateChangedMessage);
				sendActionPackage(stateChangedMessage);
			}
		}
	}

	/**
	 * Send 'Heartbeat' message to LASAD-Server if requested in provided
	 * {@link ActionPackage}
	 */
	private void sendHeartbeatIfRequested(ActionPackage actionPackage) {
		if (actionPackage == null) {
			logger.info("ActionPackage is null!");
		}
		if (eventTranslatorLASAD2AF.containsHeartbeatRequest(actionPackage)) {
			sendActionPackage(actionPackageFactory.createHeartbeatMessage());
		}
	}

	/**
	 * Instantiate heartbeat configuration (i.e., 'Heartbeat' message will be
	 * send out all x milliseconds)
	 */
	private void setupAutoHeartBeatIfConfigured() {
		if (configuration.autoHeartBeat()) {
			int heartBeatRate = configuration.getHeartBeatRate();

			Timer timerThread = new Timer(true);
			TimerTask heartBeatTask = new TimerTask() {
				@Override
				public void run() {
					try {
						sendActionPackage(actionPackageFactory
								.createHeartbeatMessage());
					} catch (Exception e) {
						logger.error("Error occurred.", e);
					}
				}
			};
			timerThread.schedule(heartBeatTask, 0, heartBeatRate * 1000);

		}
	}

	public static String actionPackage2String(ActionPackage actionPackage) {
		if (actionPackage == null) {
			logger.info("ActionPackage is null!");
			return null;
		}
		StringBuffer buffer = new StringBuffer();
		buffer.append("ActionPackage (");
		Iterator<Parameter> paramIter = actionPackage.getParameters()
				.iterator();
		while (paramIter.hasNext()) {
			Parameter param = paramIter.next();
			buffer.append(param.getType() + "-> " + param.getValue());
			if (paramIter.hasNext()) {
				buffer.append(", ");
			}
		}
		buffer.append(") ");
		List<Action> receivedActions = actionPackage.getActions();
		Iterator<Action> actionIter = receivedActions.iterator();
		buffer.append("{");
		while (actionIter.hasNext()) {
			Action act = actionIter.next();
			buffer.append("[");
			buffer.append("ACTION: ");
			buffer.append("CATEGORY: " + act.getCategory());
			buffer.append(", COMMAND: " + act.getCmd());
			buffer.append(", PARAMETERS: ");
			paramIter = act.getParameters().iterator();
			while (paramIter.hasNext()) {
				Parameter param = paramIter.next();
				buffer.append(param.getType() + "-> " + param.getValue());
				if (paramIter.hasNext()) {
					buffer.append(", ");
				}
			}
			buffer.append("]");
			if (actionIter.hasNext()) {
				buffer.append(", ");
			}
		}
		buffer.append("}");
		return buffer.toString().replace("\\s", " ");
	}

	public static String actionPackage2StringForTesting(
			ActionPackage actionPackage) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("{" + "\n");
		Iterator<Parameter> paramIter = actionPackage.getParameters()
				.iterator();
		List<Action> receivedActions = actionPackage.getActions();
		Iterator<Action> actionIter = receivedActions.iterator();
		while (actionIter.hasNext()) {
			Action act = actionIter.next();
			buffer.append("[" + "\n");
			buffer.append("ACTION: " + "\n");
			buffer.append("CATEGORY: " + act.getCategory() + "\n");
			buffer.append("COMMAND: " + act.getCmd() + "\n");
			buffer.append("PARAMETERS: " + "\n");
			paramIter = act.getParameters().iterator();
			while (paramIter.hasNext()) {
				Parameter param = paramIter.next();
				buffer.append(param.getType() + ":" + param.getValue() + "\n");
				if (paramIter.hasNext()) {
				}
			}
			buffer.append("]" + "\n");
			if (actionIter.hasNext()) {
			}
		}
		buffer.append("}" + "\n");
		return buffer.toString();
	}

	private class MyShutdownHook extends Thread {
		public void run() {
			stopServiceImpl();
		}
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		buffer.append(this.getClass().getSimpleName());
		String confString = "null";
		if (getDescription() != null
				&& getDescription().getConfiguration() != null) {
			confString = getDescription().getConfiguration().toString();
		}
		buffer.append(": ").append(confString);
		buffer.append("]");
		return buffer.toString();
	}
}
