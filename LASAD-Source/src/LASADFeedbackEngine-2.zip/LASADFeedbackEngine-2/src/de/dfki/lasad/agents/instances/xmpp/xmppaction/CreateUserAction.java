package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import java.util.Vector;

import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.commands.Commands;

import org.apache.log4j.Logger;

import de.dfki.lasad.dataservice.lasad.LasadActionFactory;
import de.dfki.lasad.events.eue.admin.session.ManagementResponseEvent;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;

public class CreateUserAction extends CfManagementAction{

	Logger logger = Logger.getLogger(this.getClass());
	
	public CreateUserAction(CfAction cfAction) {
		super(cfAction);
	}

	@Override
	public Vector<Action> buildLasadActions() {
		Vector<Action> actions = new Vector<Action>();
		
		//TODO don't assume that there is only one object, and it is a user	
		CfObject userObject = cfAction.getCfObjects().get(0);
		String username = userObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_USERNAME_STRING);
		String password = userObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_PASSWORD_STRING);
		String role = userObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_ROLE_STRING);
		String isPasswordEncryptedString = userObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_PASSWORD_ENCYRPTED_STRING);
		boolean isPasswordEncrypted = isPasswordEncrypted(isPasswordEncryptedString);
		actions.add(LasadActionFactory.createUser(username, password, role, isPasswordEncrypted));
			
		return actions;
	}
	
	public boolean eventIsResponseToMe(ManagementResponseEvent mEvent) {
		String username = cfAction.getCfObjects().get(0).getPropertyValue(MetaforaStrings.PROPERTY_TYPE_USERNAME_STRING);
		String messageString = "(" + username + ")";
		if (mEvent.getCommand() == Commands.AuthoringFailed){
			return true;
		}
		else if (mEvent.getMessage().contains(messageString)){
			return true;
		}
		return false;
	}
	

	public Boolean isPasswordEncrypted(String alreadyConvertedPasswordString) {
		boolean alreadyConvertedPassword = false;
		if (alreadyConvertedPasswordString != null){
			try {
				alreadyConvertedPassword = Boolean.valueOf(alreadyConvertedPasswordString);
				return alreadyConvertedPassword;
			}
			catch (Exception e){
				logger.warn("[isPasswordConverted] bad format of boolean value for string : " + alreadyConvertedPasswordString);
			}
		}
		return false;
	}

}
