package de.dfki.lasad.sessionmodel.jessfunctions;

import java.util.List;
import java.util.Vector;

import jess.Context;
import jess.Fact;
import jess.JessException;
import jess.Userfunction;
import jess.Value;
import jess.ValueVector;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ModifyFact implements Userfunction {

	public ModifyFact() {
		super();
	}

	/**
	 * @see jess.Userfunction#getName()
	 */
	public String getName() {
		return "my-modify";
	}

	/**
	 * Call the sort ValueVector user function
	 * 
	 * @see jess.Userfunction#call(jess.ValueVector, jess.Context)
	 */
	public Value call(ValueVector vv, final Context context)
			throws JessException {
		if (vv.size() != 4) {
			throw new JessException(getName(), getName()
					+ " takes exactly three arguments.", vv.size() - 1);
		}

		List<String> changedPropNames = new Vector<String>();
		List<Value> changedPropValues = new Vector<Value>();

		Value factVal = vv.get(1).resolveValue(context);
		Fact oldFact = factVal.factValue(context);

		ValueVector propNamesValues = vv.get(2).listValue(context);
		for (int i = 0; i < propNamesValues.size(); i++) {
			changedPropNames.add(propNamesValues.get(i).stringValue(context));
		}

		ValueVector propValuesValues = vv.get(3).listValue(context);
		for (int i = 0; i < propValuesValues.size(); i++) {
			changedPropValues.add(propValuesValues.get(i));
		}
		
		Fact newFact = context.getEngine().modify(oldFact,
				changedPropNames.toArray(new String[changedPropNames.size()]),
				changedPropValues.toArray(new Value[changedPropValues.size()]));
		return new Value(newFact);
	}

}
