package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ComparisonPrinterHelper {

	/**
	 * retrieve comparisons using standard approachs
	 * 
	 * @param pattern
	 */
	public static void printAllComparisons(StructuralPattern pattern) {

		Map<Integer, ComparisonSimplified> id2comparison = new HashMap<Integer, ComparisonSimplified>();
		String patternID = pattern.getID();
		if (pattern.getSubID() != null) {
			patternID = patternID + "/" + pattern.getSubID();
		}
		addComparisons(id2comparison,
				ComparisonSimplifier.generateComparisonsSimplified(patternID, pattern
						.getNodeVars()));

		addComparisons(id2comparison,
				ComparisonSimplifier.generateComparisonsSimplified(patternID, pattern
						.getLinkVars()));

		Collection<StructuralPattern> notPatterns = pattern.getNotPatterns();
		for (StructuralPattern notPattern : notPatterns) {
			String notPatternID = notPattern.getID();
			if (notPattern.getSubID() != null) {
				notPatternID = notPatternID + "/" + notPattern.getSubID();
			}
			addComparisons(id2comparison,
					ComparisonSimplifier
							.generateComparisonsSimplified(notPatternID, notPattern
									.getNodeVars()));

			addComparisons(id2comparison,
					ComparisonSimplifier
							.generateComparisonsSimplified(notPatternID, notPattern
									.getLinkVars()));
		}

		printComparisonsOrderedByID(id2comparison);
	}

	public static void printComparisonsOrderedByID(
			Map<Integer, ComparisonSimplified> id2comparison) {
		TreeMap<Integer, ComparisonSimplified> id2comparisonSorted = new TreeMap<Integer, ComparisonSimplified>(
				id2comparison);

		Iterator<Integer> idIter = id2comparisonSorted.keySet().iterator();
		while (idIter.hasNext()) {
			System.out.println(id2comparisonSorted.get(idIter.next()));
		}
	}

	public static void addComparisons(
			Map<Integer, ComparisonSimplified> id2comparison,
			List<ComparisonSimplified> comparisonsSimplified) {
		for (ComparisonSimplified comp : comparisonsSimplified) {
			Integer id = Integer.valueOf(comp.comparisonID);
			if (id2comparison.containsKey(id)) {
				System.out.println("Duplicate comparison ID: "
						+ comp.comparisonID);
				System.exit(1);
			}
			id2comparison.put(id, comp);
		}
	}

	public static void printComparisons(List<ComparisonSimplified> comparisons) {
		for (ComparisonSimplified comparison : comparisons) {
			System.out.println(comparison.toString());
		}
	}
}
