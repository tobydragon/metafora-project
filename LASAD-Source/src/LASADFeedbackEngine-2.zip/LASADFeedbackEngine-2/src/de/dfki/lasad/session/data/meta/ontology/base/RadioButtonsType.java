package de.dfki.lasad.session.data.meta.ontology.base;

import de.dfki.lasad.session.data.meta.ontology.ComparisonGroup;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * 
 * @author oliverscheuer
 *
 */
public class RadioButtonsType extends BaseType {

	private static RadioButtonsType instance = new RadioButtonsType();
	
	private RadioButtonsType(){
		super();
		lasadElementType = "radiobtn";
		jessTemplateName = "elem_radiobtn";
		addComponentSpecification(PropDescr.DEFAULT_COMPONENT_ID,"Mycheck", JessDataType.STRING, ComparisonGroup.TEXT);
	}
	
	public static RadioButtonsType getInstance(){
		return instance;
	}
}