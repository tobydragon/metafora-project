package de.dfki.lasad.agents.logic.provision.actiongen.xml;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.action.feedback.MsgCompDef;
import lasad.shared.dfki.meta.agents.action.feedback.MsgCompDef_Highlighting;
import lasad.shared.dfki.meta.agents.action.feedback.MsgCompDef_LongText;
import lasad.shared.dfki.meta.agents.action.feedback.MsgCompDef_ShortText;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.CDATA;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgCompDefListXML {

	private static Log logger = LogFactory.getLog(MsgCompDefListXML.class);

	public static final String ELEMENT_NAME = "message";

	public static List<MsgCompDef> fromXML(Element messageElem) {
		List<MsgCompDef> msgComponents = new Vector<MsgCompDef>();

		Element shortTextElem = messageElem.getChild("short");
		if (shortTextElem != null) {
			MsgCompDef_ShortText shortTextDef = getShortTextDef(shortTextElem);
			msgComponents.add(shortTextDef);
		}

		Element longTextElem = messageElem.getChild("long");
		if (longTextElem != null) {
			MsgCompDef_LongText longTextDef = getLongTextDef(longTextElem);
			msgComponents.add(longTextDef);
		}

		Element highlightingElem = messageElem.getChild("highlighting");
		if (highlightingElem != null) {
			MsgCompDef_Highlighting highlightingDef = getHighlightingDef(highlightingElem);
			msgComponents.add(highlightingDef);
		}

		return msgComponents;
	}

	protected static MsgCompDef_ShortText getShortTextDef(Element shortTextElem) {
		String text = shortTextElem.getTextTrim();
		return new MsgCompDef_ShortText(text);
	}

	protected static MsgCompDef_LongText getLongTextDef(Element longTextElem) {
		String text = longTextElem.getTextTrim();
		String responsePromptString = longTextElem
				.getAttributeValue("response-prompt");
		boolean responsePrompt = Boolean.parseBoolean(responsePromptString);
		MsgCompDef_LongText msgLong = new MsgCompDef_LongText(text);
		msgLong.setResponsePrompt(responsePrompt);
		return msgLong;
	}

	protected static MsgCompDef_Highlighting getHighlightingDef(
			Element highlightingElem) {
		return new MsgCompDef_Highlighting();
	}

	public static Element toXML(List<MsgCompDef> msgComponents) {
		Element msgElem = new Element(ELEMENT_NAME);
		for (MsgCompDef cmp : msgComponents) {
			if (cmp instanceof MsgCompDef_ShortText) {
				Element shortElem = getShortElem((MsgCompDef_ShortText) cmp);
				msgElem.addContent(shortElem);
			} else if (cmp instanceof MsgCompDef_LongText) {
				Element longElem = getLongElem((MsgCompDef_LongText) cmp);
				msgElem.addContent(longElem);
			} else if (cmp instanceof MsgCompDef_Highlighting) {
				Element highlightingElem = getHighlightingElem((MsgCompDef_Highlighting) cmp);
				msgElem.addContent(highlightingElem);
			} else {
				logger.warn("Unhandled msg component type: " + cmp);
			}
		}
		return msgElem;
	}

	protected static Element getShortElem(MsgCompDef_ShortText cmp) {
		Element shortElem = new Element("short");
		CDATA cdata = new CDATA(cmp.getText());
		shortElem.addContent(cdata);
		return shortElem;
	}

	protected static Element getLongElem(MsgCompDef_LongText cmp) {
		Element longElem = new Element("long");
		CDATA cdata = new CDATA(cmp.getText());
		longElem.addContent(cdata);
		if (cmp.isResponsePrompt()) {
			longElem.setAttribute("response-prompt", String.valueOf(true));
		}
		return longElem;
	}

	protected static Element getHighlightingElem(MsgCompDef_Highlighting cmp) {
		Element highlightingElem = new Element("highlighting");
		return highlightingElem;
	}
}
