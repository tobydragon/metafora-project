package de.dfki.lasad.dataservice.lasad.translators;

import de.dfki.lasad.events.eue.EUEEventID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class EUEEventIDGenerator {

	private static int counter = 0;

	public static synchronized EUEEventID getNextID() {
		return new EUEEventID(String.valueOf(++counter));
	}
}
