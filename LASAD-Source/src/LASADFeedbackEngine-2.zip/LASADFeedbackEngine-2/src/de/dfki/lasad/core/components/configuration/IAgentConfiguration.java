package de.dfki.lasad.core.components.configuration;

import java.util.List;

import lasad.shared.dfki.meta.agents.ServiceType;

import de.dfki.lasad.agents.SessionChecker;

/**
 * (see {@link IComponentConfiguration})
 * 
 * @author oliverscheuer
 * 
 */
public interface IAgentConfiguration extends IComponentConfiguration {

	public SessionChecker getSessionChecker();

	public List<ServiceType> getServiceTypes();

	public void compileNotYetCompiledAnalysisTypes();
}
