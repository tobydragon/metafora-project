package de.dfki.lasad.core.components.configuration;

import java.util.List;

import de.dfki.lasad.agents.SessionChecker;
import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.authoring.model.AgentConfigFE;

/**
 * (see {@link IComponentConfiguration})
 * 
 * @author oliverscheuer
 * 
 */
public interface IAgentConfiguration extends IComponentConfiguration {

	public SessionChecker getSessionChecker();

	/**
	 * Replaces the agentID generally and for all {@link AnalysisType}s
	 * 
	 * @param agentID
	 */
	public void replaceAgentID(String agentID);

	public List<ActionType> getActionTypes();

	public List<AnalysisType> getAnalysisTypes();

	public boolean doPublishAllActionTypes();

	public boolean doPublishAllAnalysisTypes();

	/**
	 * 
	 * @return Feedback configuration as defined in the feedback authoring
	 *         frontend or <code>null</code> if not supported.
	 */
	public AgentConfigFE getConfigFE();

	/**
	 * 
	 * @param agentConfigFE
	 *            Feedback configuration as defined in the feedback authoring
	 *            frontend
	 */
	public void setConfigFE(AgentConfigFE agentConfigFE);

	public boolean hasConfigFE();
}
