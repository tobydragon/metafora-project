package de.dfki.lasad.agents.logic.provision.phases.xml;

import java.util.List;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.analysis.phases.PhaseDef;
import lasad.shared.dfki.meta.agents.analysis.phases.PhasesDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;


/**
 * 
 * @author oliverscheuer
 * 
 */
public class PhasesDefXML {

	private static Log logger = LogFactory.getLog(PhasesDefXML.class);

	public static final String ELEMENT_NAME = "phases";
	public static final String PHASE_ELEMENT_NAME = "phase";

	public static PhasesDef fromXML(Element phasesElem) {
		List<PhaseDef> phases = new Vector<PhaseDef>();
		for (Element phaseElem : (List<Element>) phasesElem.getChildren(PHASE_ELEMENT_NAME)) {
			PhaseDef phase = PhaseDefXML.fromXML(phaseElem);
			phases.add(phase);
		}
		return new PhasesDef(phases);
	}

	public static Element toXML(PhasesDef phasesDef) {
		Element phasesDefElem = new Element(ELEMENT_NAME);
		for (PhaseDef phaseDef : phasesDef.getPhases()) {
			Element phaseElem = PhaseDefXML.toXML(phaseDef);
			phasesDefElem.addContent(phaseElem);
		}
		return phasesDefElem;
	}
}
