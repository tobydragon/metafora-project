package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import java.util.Vector;

import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.commands.Commands;
import lasad.shared.communication.objects.parameters.ParameterTypes;

import org.apache.log4j.Logger;

import de.dfki.lasad.dataservice.lasad.LasadActionFactory;
import de.dfki.lasad.events.eue.admin.session.ManagementResponseEvent;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;
import de.uds.commonformat.CfProperty;

public class CreateMapAction extends CfManagementAction{
	Logger logger = Logger.getLogger(this.getClass());
	private static KeyToTemplateMapping keyToTemplateMapping = new KeyToTemplateMapping("conf/metafora/details/agents/types/xmpp/cf-key-to-template-settings.xml");
	
	public CreateMapAction(CfAction cfAction) {
		super(cfAction);
	}

	@Override
	public Vector<Action> buildLasadActions() {
		Vector<Action> actions = new Vector<Action>();
		
		CfObject mapObject = cfAction.getCfObjects().get(0);
		String mapName = mapObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAPNAME_STRING);
		String templateName = getTemplate(mapObject);
		actions.add(LasadActionFactory.createMap(mapName, templateName, ""));
		
		return actions;
	}
	
	public boolean eventIsResponseToMe(ManagementResponseEvent mEvent) {
		String mapName = cfAction.getCfObjects().get(0).getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAPNAME_STRING);
		String messageString = "(" + mapName ;
		String eventMessage = mEvent.getMessage();
		if (mEvent.getCommand() == Commands.AuthoringFailed){
			return true;
		}
		else if (eventMessage.contains(messageString)){
			//find and set the ID of the map
			try {
				String mapId = eventMessage.substring(eventMessage.indexOf(":")+1, eventMessage.indexOf(")"));
				mapId = mapId.trim();
				logger.debug("[eventIsResponseToMe] for map - " + mapName + " - ID - " + mapId);
				//set the ID
				CfObject mapObject = cfAction.getCfObjects().get(0);
				mapObject.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING, mapId));
			}
			catch (Exception e){
				logger.error("[eventIsResponseToMe] Id not found: " + eventMessage);
			}
			return true;
		}
		return false;
	}

	private String getTemplate(CfObject mapObject){
		
		//if there is a key present, use the mapping from that key
		String templateKey = mapObject.getPropertyValue(ParameterTypes.challengeId.getOldParameter());
		if (templateKey != null){
			return keyToTemplateMapping.getTemplate(templateKey);
		}
		//else look for specified template
		String directTemplateName = mapObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_TEMPLATE_STRING);
		if (directTemplateName != null){
			return directTemplateName;
		}
		
		//else return the default from settings
		return keyToTemplateMapping.getDefaultTemplate();
	}

}
