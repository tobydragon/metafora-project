package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import java.util.Vector;

import org.apache.log4j.Logger;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.commands.Commands;
import de.dfki.lasad.dataservice.lasad.LasadActionFactory;
import de.dfki.lasad.events.eue.admin.session.ManagementResponseEvent;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;
import de.uds.commonformat.CfProperty;

public class CreateMapAction extends CfManagementAction{
	Logger logger = Logger.getLogger(this.getClass());
	
	public CreateMapAction(CfAction cfAction) {
		super(cfAction);
	}

	@Override
	public Vector<Action> buildLasadActions() {
		Vector<Action> actions = new Vector<Action>();
		
		CfObject mapObject = cfAction.getCfObjects().get(0);
		String mapName = mapObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAPNAME_STRING);
		String templateName = mapObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_TEMPLATE_STRING);
		actions.add(LasadActionFactory.createMap(mapName, templateName, ""));
		
		return actions;
	}
	
	public boolean eventIsResponseToMe(ManagementResponseEvent mEvent) {
		String mapName = cfAction.getCfObjects().get(0).getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAPNAME_STRING);
		String messageString = "(" + mapName ;
		String eventMessage = mEvent.getMessage();
		if (mEvent.getCommand() == Commands.AuthoringFailed){
			return true;
		}
		else if (eventMessage.contains(messageString)){
			//find and set the ID of the map
			try {
				String mapId = eventMessage.substring(eventMessage.indexOf(":")+1, eventMessage.indexOf(")"));
				mapId = mapId.trim();
				logger.debug("[eventIsResponseToMe] for map - " + mapName + " - ID - " + mapId);
				//set the ID
				CfObject mapObject = cfAction.getCfObjects().get(0);
				mapObject.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING, mapId));
			}
			catch (Exception e){
				logger.error("[eventIsResponseToMe] Id not found: " + eventMessage);
			}
			return true;
		}
		return false;
	}

}
