package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import java.io.File;

import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;

import org.jdom.Element;

import de.dfki.lasad.agents.logic.analysis.types.structure.StructureAnalysisTypeXML;

/**
 * 
 * Tests the {@link StructureAnalysisTypeXML} parser
 * 
 * @author oliverscheuer
 * 
 */
public class StructureAnalysisTypeXMLTest {

	static StructureAnalysisType parsePattern(String localFileName) {
		File patternFile = TestData.getTestFileFromTestFolder(localFileName);
		return parsePattern(patternFile);
	}

	static StructureAnalysisType parsePattern(File patternFile) {
		Element patternElement = TestData.loadXMLFromTestFolder(patternFile);
		return parsePattern(patternElement);
	}

	static StructureAnalysisType parsePattern(Element patternElem) {
		StructureAnalysisType type = StructureAnalysisTypeXML.fromXML(
				"TEST-AGENT", "LARGO", patternElem);
		return type;
	}

	public static void parseAndPrintTestData() {
		for (File testFile : TestData.testFiles) {
			System.out.println("----- " + testFile.getName() + " -----\n");
			StructureAnalysisType type = parsePattern(testFile);
			System.out.println(type.getPattern().toPrettyString("") + "\n");

		}
	}

	public static void main(String[] args) {
		StructureAnalysisTypeXMLTest.parseAndPrintTestData();
	}
}
