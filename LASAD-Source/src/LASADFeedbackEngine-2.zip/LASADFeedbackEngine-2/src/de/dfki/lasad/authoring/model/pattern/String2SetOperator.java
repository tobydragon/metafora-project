package de.dfki.lasad.authoring.model.pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public enum String2SetOperator implements Operator{
	IN("IN"), 
	NOT_IN("NOT_IN");
	// contains_kw, RED
	// not_contains_kw RED

	private static final Log logger = LogFactory.getLog(String2SetOperator.class);
	
	private final String operator;

	String2SetOperator(String operator) {
		this.operator = operator;
	}
	
	public Set2StringOperator invert() {
		if (equals(IN)) {
			return Set2StringOperator.CONTAINS;
		} else if (equals(NOT_IN)) {
			return Set2StringOperator.NOT_CONTAINS;
		} else {
			logger.error("Error in method invert()");
			return null;
		}
	}
}
