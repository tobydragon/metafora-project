package de.dfki.lasad.events.eue;

import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.session.data.SessionID;

/**
 * Event associated with an EUE session
 * 
 * @author oliverscheuer
 *
 */
public class EUESessionEvent extends SessionEvent implements EUEEvent{

	protected EUEEventID eueEventID;

	public EUESessionEvent(String srcCompId) {
		super(srcCompId);
	}
	
	public EUESessionEvent(SessionID sessionID, String srcCompId) {
		super(sessionID, srcCompId);
	}

	public EUESessionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID) {
		this(sessionID, srcCompId);
		this.eueEventID = eueEventID;
	}

	public void setEueEventID(EUEEventID eueEventID) {
		this.eueEventID = eueEventID;
	}

	public EUEEventID getEueEventID() {
		return eueEventID;
	}

	@Override
	public String toString() {
		return super.toString() + ", eueEventID=" + eueEventID;
	}

}
