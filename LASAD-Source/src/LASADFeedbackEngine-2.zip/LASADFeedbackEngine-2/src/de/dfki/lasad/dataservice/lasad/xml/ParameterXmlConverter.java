package de.dfki.lasad.dataservice.lasad.xml;

import lasad.shared.communication.objects.Parameter;
import lasad.shared.communication.objects.parameters.ParameterTypes;

import org.apache.log4j.Logger;

import de.uds.xml.XmlFragment;


public class ParameterXmlConverter {
	static Logger logger = Logger.getLogger(ParameterXmlConverter.class);
	
	public static XmlFragment toXml(Parameter parameter){
		XmlFragment xmlFragment = new XmlFragment("Parameter");
		xmlFragment.setAttribute("NAME", parameter.getType().toString());
		xmlFragment.setAttribute("VALUE", parameter.getValue());
		return xmlFragment;
	}
	
	public static Parameter fromXml(XmlFragment xmlFragment){
		try {
			String name = xmlFragment.getAttributeValue("NAME");
			String value = xmlFragment.getAttributeValue("VALUE");
			return new Parameter(ParameterTypes.valueOf(name), value);
		}
		catch (Exception e){
			logger.error("[fromXML]:  Bad XML input: \n" + xmlFragment );
			return null;
		}
	}

}
