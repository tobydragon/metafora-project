package de.dfki.lasad.agents.data.action;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Specifies a verbal system action (usually, displaying a textual message).
 * 
 * @author Oliver Scheuer
 * 
 */
public class Message implements ActionComponent {

	private String messageShort = null;
	private String messageLong = null;
	private boolean responsePrompt = false;

	// private Map<String, String> parameters = new HashMap<String, String>();

	public Message(String messageShort) {
		this.messageShort = messageShort;
	}

	public Message(String messageShort, String messageLong) {
		this.messageShort = messageShort;
		this.messageLong = messageLong;
	}

	public String getMessageShort() {
		return messageShort;
	}

	public String getMessageLong() {
		return messageLong;
	}

	public boolean isResponsePrompt() {
		return responsePrompt;
	}

	public void setResponsePrompt(boolean responsePrompt) {
		this.responsePrompt = responsePrompt;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((messageLong == null) ? 0 : messageLong.hashCode());
		result = prime * result
				+ ((messageShort == null) ? 0 : messageShort.hashCode());
		result = prime * result + (responsePrompt ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Message other = (Message) obj;
		if (messageLong == null) {
			if (other.messageLong != null)
				return false;
		} else if (!messageLong.equals(other.messageLong))
			return false;
		if (messageShort == null) {
			if (other.messageShort != null)
				return false;
		} else if (!messageShort.equals(other.messageShort))
			return false;
		if (responsePrompt != other.responsePrompt)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Message [messageShort=" + messageShort + ", messageLong="
				+ messageLong + ", responsePrompt=" + responsePrompt + "]";
	}

}
