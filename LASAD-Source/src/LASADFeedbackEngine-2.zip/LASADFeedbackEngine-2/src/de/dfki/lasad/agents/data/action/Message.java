package de.dfki.lasad.agents.data.action;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;



/**
 * Specifies a verbal system action (usually, displaying a textual message).
 * 
 * @author Oliver Scheuer
 * 
 */
public class Message implements ActionComponent {

	private String messageShort = null;
	private String messageLong = null;

	private Map<String, String> parameters = new HashMap<String, String>();

	public Message(String messageShort) {
		this.messageShort = messageShort;
	}

	public Message(String messageShort, String messageLong) {
		this.messageShort = messageShort;
		this.messageLong = messageLong;
	}

	public String getMessageShort() {
		return messageShort;
	}

	public String getMessageLong() {
		return messageLong;
	}

	public void addParameter(String name, String value) {
		parameters.put(name, value);
	}

	public Set<String> getParamNames() {
		return parameters.keySet();
	}

	public String getParamValue(String paramName) {
		return parameters.get(paramName);
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((messageLong == null) ? 0 : messageLong.hashCode());
		result = prime * result
				+ ((messageShort == null) ? 0 : messageShort.hashCode());
		result = prime * result
				+ ((parameters == null) ? 0 : parameters.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Message other = (Message) obj;
		if (messageLong == null) {
			if (other.messageLong != null)
				return false;
		} else if (!messageLong.equals(other.messageLong))
			return false;
		if (messageShort == null) {
			if (other.messageShort != null)
				return false;
		} else if (!messageShort.equals(other.messageShort))
			return false;
		if (parameters == null) {
			if (other.parameters != null)
				return false;
		} else if (!parameters.equals(other.parameters))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Message [short message=" + messageShort + "long message="
				+ messageLong + ", displayResponsePrompt="
				+ parameters.toString() + "]";
	}

}
