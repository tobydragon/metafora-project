package de.dfki.lasad.agents.logic.analysis.types.structure.test;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import lasad.shared.dfki.meta.agents.analysis.structure.StructureAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.StructuralPattern;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.PatternPreprocessor;

/**
 * Print out comparisons after pre-processing to check whether they have been
 * classified into the correct {@link Bin}
 * 
 * @author oliverscheuer
 * 
 */
public class PatternPreprocessorBinTest {

	static PatternPreprocessor preprocessor = new PatternPreprocessor(
			TestData.largoOntology);
	static {
		preprocessor.testModePrintIntermediateResults = true;
		preprocessor.testModeOmitSequentialization = true;
	}

	public static void main(String[] args) {
		printPreparedCase();
	}

	static void printPreparedCase() {
		StructureAnalysisType pattern = StructureAnalysisTypeXMLTest
				.parsePattern(TestData.TESTFILE_BINS);
		preprocessor.preprocess(pattern.getPattern());
		System.out.println("-------- comparisons from BIN datastructure");
		printComparisonsFromBinDataStructure(pattern.getPattern());
		System.out.println("--------  all comparisons -------- ");
		ComparisonPrinterHelper.printAllComparisons(pattern.getPattern());
	}

	/**
	 * retrieve comparisons from data structure where comparisons are indexed by
	 * bin and property
	 * 
	 * @param pattern
	 */
	public static void printComparisonsFromBinDataStructure(
			StructuralPattern pattern) {

		Map<Integer, ComparisonSimplified> id2comparison = new HashMap<Integer, ComparisonSimplified>();
		String patternID = pattern.getID();
		if (pattern.getSubID() != null) {
			patternID = patternID + "/" + pattern.getSubID();
		}

		ComparisonPrinterHelper.addComparisons(id2comparison,
				ComparisonSimplifier
						.generateComparisonsSimplifiedIncludingBins(patternID,
								pattern.getNodeVars()));

		ComparisonPrinterHelper.addComparisons(id2comparison,
				ComparisonSimplifier
						.generateComparisonsSimplifiedIncludingBins(patternID,
								pattern.getLinkVars()));

		Collection<StructuralPattern> notPatterns = pattern.getNotPatterns();
		for (StructuralPattern notPattern : notPatterns) {
			String notPatternID = notPattern.getID();
			if (notPattern.getSubID() != null) {
				notPatternID = notPatternID + "/" + notPattern.getSubID();
			}
			ComparisonPrinterHelper.addComparisons(id2comparison,
					ComparisonSimplifier
							.generateComparisonsSimplifiedIncludingBins(
									notPatternID, notPattern.getNodeVars()));

			ComparisonPrinterHelper.addComparisons(id2comparison,
					ComparisonSimplifier
							.generateComparisonsSimplifiedIncludingBins(
									notPatternID, notPattern.getLinkVars()));
		}

		ComparisonPrinterHelper.printComparisonsOrderedByID(id2comparison);
	}

}
