package de.dfki.lasad.agents.instances.jess;

import java.io.File;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.Format.TextMode;
import org.jdom.output.XMLOutputter;

import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.RuleAnalysisType;
import de.dfki.lasad.core.AgentsConfigManager;
import de.dfki.lasad.core.ConfigurationDatabase;

import junit.framework.TestCase;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class JessFeedbackAgentConfigurationXMLTest extends TestCase {

	// private static final String IN_CONF_DIR =
	// "details/agents/types/largo-default/largo-default.jess.xml";
	private static final String IN_CONF_AGENT = "largo-default";
	private static final String OUT_CONF_AGENT = "largo-DEBUG";

	public void testMasterXML2Console() {
		try {
			JessFeedbackAgentConfiguration conf = new JessFeedbackAgentConfiguration();

			File inFile = ConfigurationDatabase
					.getAgentConfigBEMasterFile(IN_CONF_AGENT);
			JessFeedbackAgentConfigurationXML.fromXMLFile(conf, inFile);

			Document doc = JessFeedbackAgentConfigurationXML
					.toMasterXMLDoc(conf);
			Format format = Format.getPrettyFormat();
			format.setTextMode(TextMode.PRESERVE);
			XMLOutputter o = new XMLOutputter(format);
			System.out.println(o.outputString(doc));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void testPatternXML2Console() {
		try {
			JessFeedbackAgentConfiguration conf = new JessFeedbackAgentConfiguration();
			File inFile = ConfigurationDatabase
					.getAgentConfigBEMasterFile(IN_CONF_AGENT);
			JessFeedbackAgentConfigurationXML.fromXMLFile(conf, inFile);

			for (AnalysisType aType : conf.getAnalysisTypes()) {
				RuleAnalysisType rType = (RuleAnalysisType) aType;
				Element ruleElem = JessFeedbackAgentConfigurationXML
						.toPatternXMLElem(rType);

				Format format = Format.getPrettyFormat();
				format.setTextMode(TextMode.PRESERVE);
				XMLOutputter o = new XMLOutputter(format);
				System.out.println("\n\n");
				System.out.println(o.outputString(ruleElem));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void testMasterXML2File() {
		try {
			JessFeedbackAgentConfiguration conf = new JessFeedbackAgentConfiguration();

			File inFile = ConfigurationDatabase
					.getAgentConfigBEMasterFile(IN_CONF_AGENT);
			JessFeedbackAgentConfigurationXML.fromXMLFile(conf, inFile);

			File outFile = ConfigurationDatabase
					.getAgentConfigBEMasterFile(OUT_CONF_AGENT);
			System.out.println("Writing to file: " + outFile.getAbsolutePath());
			AgentsConfigManager.createAgentFolderStructure(OUT_CONF_AGENT);
			JessFeedbackAgentConfigurationXML.writeMasterXMLFile(outFile, conf);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void testPatternXML2File() {
		try {
			JessFeedbackAgentConfiguration conf = new JessFeedbackAgentConfiguration();
			File inFile = ConfigurationDatabase
					.getAgentConfigBEMasterFile(IN_CONF_AGENT);
			JessFeedbackAgentConfigurationXML.fromXMLFile(conf, inFile);

			for (AnalysisType aType : conf.getAnalysisTypes()) {
				RuleAnalysisType rType = (RuleAnalysisType) aType;
				File outFile = ConfigurationDatabase
						.getAgentConfigBEPatternFile(OUT_CONF_AGENT,
								rType.getTypeID());
				System.out.println("Writing to file: "
						+ outFile.getAbsolutePath());
				AgentsConfigManager.createAgentFolderStructure(OUT_CONF_AGENT);
				JessFeedbackAgentConfigurationXML.writePatternXMLFile(outFile,
						rType);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
