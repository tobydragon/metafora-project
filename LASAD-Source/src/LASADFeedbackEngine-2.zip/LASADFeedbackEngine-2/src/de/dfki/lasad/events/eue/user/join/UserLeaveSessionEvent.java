package de.dfki.lasad.events.eue.user.join;

import de.dfki.lasad.events.eue.EUEEventID;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;

/**
 * Event denoting that a user has left an EUE session
 * 
 * @author Oliver Scheuer
 *
 */
public class UserLeaveSessionEvent extends UserEvent {

	public UserLeaveSessionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID) {
		super(sessionID, srcCompId, eueEventID);
	}

	public UserLeaveSessionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID) {
		super(sessionID, srcCompId, eueEventID);
		this.userID = userID;
	}
	
}
