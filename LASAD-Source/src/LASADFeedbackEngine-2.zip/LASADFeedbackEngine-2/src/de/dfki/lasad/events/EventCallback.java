package de.dfki.lasad.events;

/**
 * 
 * @author oliverscheuer
 *
 */
public interface EventCallback {

	public void onEvent(Event e);
}
