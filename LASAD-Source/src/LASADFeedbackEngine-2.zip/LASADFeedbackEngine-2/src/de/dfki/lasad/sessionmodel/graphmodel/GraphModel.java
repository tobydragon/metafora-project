package de.dfki.lasad.sessionmodel.graphmodel;

import java.util.Hashtable;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sun.org.apache.bcel.internal.generic.LNEG;

import de.dfki.lasad.core.DisplayedObjectIDTracker;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.DeleteObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.dfki.lasad.session.Session;
import de.dfki.lasad.session.SessionActiveRuntime;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;

public class GraphModel {
	Logger logger = Logger.getLogger(this.getClass());

	private Map<String, GraphElement> currentElements;
	// private Map<String, GraphElement> currentLinks;

	private Map<String, GraphElement> deletedElements;
	// private Map<String, GraphElement> deletedLinks;

	private Map<String, GraphElement> subElement2GraphNodeMap;
	SessionActiveRuntime sessionRuntime;

	public GraphModel() {

		currentElements = new Hashtable<String, GraphElement>();
		// currentLinks = new Hashtable<String, GraphElement>();
		deletedElements = new Hashtable<String, GraphElement>();
		// deletedLinks = new Hashtable<String, GraphElement>();

		subElement2GraphNodeMap = new Hashtable<String, GraphElement>();

	}

	public void setSessionRuntime(SessionActiveRuntime sessionRuntime) {
		this.sessionRuntime = sessionRuntime;
	}

	// ------------

	public void insertNode(Node node, CreateObjectEvent createEvent) {
		// TODO: create diff. nodes and links, each containing an element
		insertElement(node, createEvent);
	}

	public void insertLink(Link link, CreateObjectEvent createEvent) {
		// TODO: create separate link object,
		insertElement(link, createEvent);
	}

	private void insertElement(EUEObject element, CreateObjectEvent createEvent) {
		String displayId = DisplayedObjectIDTracker.getDisplayID(
				sessionRuntime.getSessionID(), element.getID());

		GraphElement newNode = new GraphElement(element, createEvent, displayId);
		currentElements.put(newNode.getId(), newNode);
	}

	public void insertSubElement(Node subElement, CreateObjectEvent createEvent) {
		String displayId = DisplayedObjectIDTracker.getDisplayID(
				sessionRuntime.getSessionID(), subElement.getID());

		String graphNodeId = subElement.getParentID().getIdAsString();
		GraphElement graphNode = currentElements.get(graphNodeId);
		if (graphNode != null) {
			graphNode.addSubElement(new GraphElement(subElement, createEvent,
					displayId));
			subElement2GraphNodeMap.put(subElement.getID().getIdAsString(),
					graphNode);
		}
	}

	// ------------

	public void deleteNode(Node node, DeleteObjectEvent deleteObjectEvent) {
		// TODO: delete all associated links
		deleteElement(node, deleteObjectEvent);
	}

	public void deleteLink(Link link, DeleteObjectEvent deleteObjectEvent) {
		// TODO: update all associated nodes
		deleteElement(link, deleteObjectEvent);
	}

	public void deleteElement(EUEObject element,
			DeleteObjectEvent deleteObjectEvent) {
		GraphElement graphNode = currentElements.get(element.getID()
				.getIdAsString());
		graphNode.delete(deleteObjectEvent);
		currentElements.remove(graphNode.getId());
		deletedElements.put(graphNode.getId(), graphNode);
	}

	public void deleteSubElement(Node subElement,
			DeleteObjectEvent deleteObjectEvent) {
		GraphElement graphNode = subElement2GraphNodeMap.get(subElement.getID()
				.getIdAsString());
		graphNode.deleteSubElement(subElement, deleteObjectEvent);
	}

	// ------------

	public void modifyNode(Node node, ModifyObjectEvent modifyObjectEvent) {
		modifyElement(node, modifyObjectEvent);
	}

	public void modifyLink(Link link, ModifyObjectEvent modifyObjectEvent) {
		modifyElement(link, modifyObjectEvent);
	}

	public void modifyElement(EUEObject element,
			ModifyObjectEvent modifyObjectEvent) {
		GraphElement graphNode = currentElements.get(element.getID()
				.getIdAsString());
		graphNode.modify(modifyObjectEvent);
	}

	public void modifySubElement(Node node, ModifyObjectEvent modifyObjectEvent) {
		GraphElement graphNode = currentElements.get(node.getParentID()
				.getIdAsString());
		graphNode.modifySubElement(node, modifyObjectEvent);
	}

	// ------------

	public GraphElement getNode(String eueObjectId) {
		GraphElement element = currentElements.get(eueObjectId);
		if (element == null) {
			element = subElement2GraphNodeMap.get(eueObjectId);
		}
		if (element == null) {
			element = deletedElements.get(eueObjectId);
		}
		if (element == null) {
			logger.error("[getNode] Request for node that does not exist: "
					+ eueObjectId);
		}
		return element;
	}

}
