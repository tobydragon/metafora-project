package de.dfki.lasad.agents.logic.provision.phases;

import java.util.Comparator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PhaseProbabilityComparator implements Comparator<Phase> {

	@Override
	public int compare(Phase o1, Phase o2) {
		double probDiff = o2.probability - o1.probability;
		if (probDiff == 0) {
			return 0;
		}
		return (probDiff > 0) ? 1 : -1;
	}
}
