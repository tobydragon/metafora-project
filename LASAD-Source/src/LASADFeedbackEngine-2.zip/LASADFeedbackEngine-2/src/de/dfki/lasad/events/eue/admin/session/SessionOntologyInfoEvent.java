package de.dfki.lasad.events.eue.admin.session;

import de.dfki.lasad.session.data.meta.Ontology;

/**
 * Provides information about all available sessions (in particular, the used
 * {@link Ontology}s).
 * 
 * @author Oliver Scheuer
 * 
 */
public class SessionOntologyInfoEvent extends EUESessionInfoEvent {

	String ontologyXML;
	Ontology ontology;

	public SessionOntologyInfoEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getOntologyXML() {
		return ontologyXML;
	}

	public void setOntologyXML(String ontologyXML) {
		this.ontologyXML = ontologyXML;
	}

	public Ontology getOntology() {
		return ontology;
	}

	public void setOntology(Ontology ontology) {
		this.ontology = ontology;
	}

	@Override
	public String toString() {
		return "sessionID=" + sessionID +  ", ontology="
				+ (ontology == null ? "null" : ontology.toString());
	}
}
