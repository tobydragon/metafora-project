package de.dfki.lasad.agents.logic.analysis.types.counter.test;

import java.io.File;

import lasad.shared.dfki.meta.agents.analysis.counter.CounterAnalysisType;

import org.jdom.Element;

import de.dfki.lasad.agents.logic.analysis.types.counter.CounterAnalysisTypeXML;
import de.dfki.lasad.util.ClasspathResourceUtil;
import de.dfki.lasad.util.XMLUtil;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class CounterAnalysisTypeXMLTest {

	public static void main(String[] args) {
		reGenerateAndPrintXML("testcase-1.xml");
		reGenerateAndPrintXML("testcase-2.xml");
		reGenerateAndPrintXML("testcase-3.xml");
	}

	public static void reGenerateAndPrintXML(String localFilename) {
		System.out.println(localFilename);
		System.out.println("-----------------");
		String filePathCase = ClasspathResourceUtil
				.getAbsoluteFilepathFromResourceOnClasspath(
						CounterAnalysisTypeXMLTest.class, localFilename);

		CounterAnalysisType type = parseFile(filePathCase);
		// System.out.println(type);
		String xmlString = toXMLString(type);
		System.out.println(xmlString);
	}

	public static CounterAnalysisType parseFile(String absPathXML) {
		try {

			File file = new File(absPathXML);
			Element elem = XMLUtil.file2xmlElem(file);
			return CounterAnalysisTypeXML.fromXML("ANALYSIS-AGENT", elem);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String toXMLString(CounterAnalysisType counterType) {
		try {

			Element elem = CounterAnalysisTypeXML.toXML(counterType);
			return XMLUtil.xmlElem2docString(elem);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
