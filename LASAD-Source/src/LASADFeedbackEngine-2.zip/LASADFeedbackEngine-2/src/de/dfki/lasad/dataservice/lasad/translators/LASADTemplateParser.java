package de.dfki.lasad.dataservice.lasad.translators;

import java.io.BufferedReader;
import java.io.Reader;
import java.io.StringReader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import de.dfki.lasad.session.data.meta.ToolContext;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class LASADTemplateParser {

	private static Log logger = LogFactory.getLog(LASADTemplateParser.class);

	public static ToolContext parseToolContext(String templateXML) {
		try {
			ToolContext tc = new ToolContext();

			// Namespace classifierNs = Namespace
			// .getNamespace(classifierDescriptionNS);
			SAXBuilder builder = new SAXBuilder();
			Reader ontologyReader = new StringReader(templateXML);
			BufferedReader bufOntologyReader = new BufferedReader(
					ontologyReader);
			Document doc = builder.build(bufOntologyReader);

			Element mapTemplateElem = doc.getRootElement();

			Element mapDetailsElem = mapTemplateElem.getChild("mapdetails");
			Element optionsElem = mapDetailsElem.getChild("options");

			Attribute chatSystemAttr = optionsElem.getAttribute("chatsystem");
			boolean chatsystem = false;
			if (chatSystemAttr != null) {
				chatsystem = Boolean.getBoolean(chatSystemAttr.getValue());
			}

			Attribute sentenceOpenerAttr = optionsElem
					.getAttribute("sentenceopener");
			boolean sentenceopener = false;
			if (sentenceOpenerAttr != null) {
				sentenceopener = Boolean.getBoolean(sentenceOpenerAttr
						.getValue());
			}

			if (chatsystem && sentenceopener) {
				tc.setSoChat(true);
			} else if (chatsystem) {
				tc.setSimpleChat(true);
			}

			Element transcriptElem = mapTemplateElem.getChild("transcript");
			if (transcriptElem != null) {
				Attribute transcriptIDAttr = transcriptElem.getAttribute("id");
				String transcriptID = transcriptIDAttr.getValue();
				tc.addTranscriptID(transcriptID);
			}

			return tc;

		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}

}
