package de.dfki.lasad.authoring.model.pattern;

/**
 * Comparison of a set variable to some constant string value.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class Set2ConstStringComparison extends Comparison {
	private Set2StringOperator operator;
	private String rightExpr;

	public Set2StringOperator getOperator() {
		return operator;
	}

	public void setOperator(Set2StringOperator operator) {
		this.operator = operator;
	}

	public String getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(String rightExpr) {
		this.rightExpr = rightExpr;
	}

}
