package de.dfki.lasad.sessionmodel.jessfunctions;


import jess.Context;
import jess.Funcall;
import jess.JessException;
import jess.Userfunction;
import jess.Value;
import jess.ValueVector;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class StrCompareList2Scalar implements Userfunction {

	/** Create a new StrCompareList2Scalar userfunction object */
	public StrCompareList2Scalar() {
		super();
	}

	/**
	 * Get the name of the strcompare-l2s user function
	 * 
	 * @see jess.Userfunction#getName()
	 */
	public String getName() {
		return "strcompare-l2s";
	}

	/**
	 * 
	 * Call the strcompare-l2s user function
	 * 
	 * @see jess.Userfunction#call(jess.ValueVector, jess.Context)
	 */
	public Value call(ValueVector vv, final Context context)
			throws JessException {
		if (vv.size() != 5) {
			throw new JessException(getName(), getName()
					+ " takes exactly four arguments:"
					+ "list selector, list, operator, scalar", vv.size() - 1);
		}

		Value listSelectorAsValue = vv.get(1).resolveValue(context);
		String listselector = listSelectorAsValue.stringValue(context);
		
		Value listAsValue = vv.get(2).resolveValue(context);
		ValueVector list = listAsValue.listValue(context);
		
		Value operatorAsValue = vv.get(3).resolveValue(context);
		String operator = operatorAsValue.stringValue(context);
		
		Value scalarAsValue = vv.get(4).resolveValue(context);

		boolean result;
		if ("EXISTS".equalsIgnoreCase(listselector)) {
			result = compareExists(list, operator, scalarAsValue, context);
		} else if ("FORALL".equalsIgnoreCase(listselector)) {
			result = compareForall(list, operator, scalarAsValue, context);
		} else {
			throw new JessException(getName(),
					"Unable to compare value with list",
					"The first argument should be either \"EXISTS\" or \"FORALL\" ");
		}

		return new Value(result);
	}

	private boolean compareExists(ValueVector list, String operator,
			Value scalarAsValue, final Context context) throws JessException {
		for (int i = 0; i < list.size(); ++i) {
			Funcall strcmp = new Funcall("str-compare", context.getEngine());
			strcmp.add(list.get(i));
			strcmp.add(scalarAsValue);
			Value compResult = strcmp.execute(context);
			Funcall f = new Funcall(operator, context.getEngine());
			f.add(compResult);
			f.add(0);
			Value retValue = f.execute(context);
			if (retValue.equals(Funcall.TRUE)) {
				return true;
			}
		}
		return false;
	}

	private boolean compareForall(ValueVector list, String operator,
			Value scalarAsValue, final Context context) throws JessException {
		for (int i = 0; i < list.size(); ++i) {
			Funcall strcmp = new Funcall("str-compare", context.getEngine());
			strcmp.add(list.get(i));
			strcmp.add(scalarAsValue);
			Value compResult = strcmp.execute(context);
			Funcall f = new Funcall(operator, context.getEngine());
			f.add(compResult);
			f.add(0);
			Value retValue = f.execute(context);
			if (retValue.equals(Funcall.FALSE)) {
				return false;
			}
		}
		return true;
	}

}
