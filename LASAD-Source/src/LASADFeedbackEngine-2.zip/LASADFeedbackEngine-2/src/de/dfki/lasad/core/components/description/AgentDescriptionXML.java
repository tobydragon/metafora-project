package de.dfki.lasad.core.components.description;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescriptionXML {

	private static Log logger = LogFactory.getLog(AgentDescriptionXML.class);

	public static AgentDescription fromXML(Element agentElem) {
		try {
			BasicDescription basicDescr = BasicDescriptionXML
					.fromXML(agentElem);
			AgentDescription ad = new AgentDescription(basicDescr);

			String ontology = agentElem.getAttributeValue("ontology");
			String readableString = agentElem.getAttributeValue("isreadable");
			boolean readable = new Boolean(readableString);
			String writableString = agentElem.getAttributeValue("iswritable");
			boolean writable = new Boolean(writableString);
			String confXMLFilePath = agentElem.getAttributeValue("confxmlfile");
			String displayName = agentElem.getAttributeValue("displayname");

			ad.setSupportedOntology(ontology);
			ad.setConfigReadable(readable);
			ad.setConfigWritable(writable);
			ad.setConfigFEFilepath(confXMLFilePath);
			ad.setDisplayName(displayName);

			ad.setup();
			return ad;
		} catch (Exception e) {
			logger.error("Error in 'fromXML(...)'", e);
			return null;
		}
	}

	public static Element toXML(AgentDescription agentDescr) {
		Element agentDescriptionXML = BasicDescriptionXML.toXML("agent",
				agentDescr);
		String ontologyID = agentDescr.getSupportedOntology();
		if (ontologyID != null) {
			agentDescriptionXML.setAttribute("ontology", ontologyID);
		}
		agentDescriptionXML.setAttribute("isreadable",
				String.valueOf(agentDescr.isConfigReadable()));
		agentDescriptionXML.setAttribute("iswritable",
				String.valueOf(agentDescr.isConfigWritable()));
		String displayName = agentDescr.getDisplayName();
		if (displayName != null) {
			agentDescriptionXML.setAttribute("displayname", displayName);
		}
		String confXMLFilePath = agentDescr.getConfigFEFilepath();
		if (confXMLFilePath != null) {
			agentDescriptionXML.setAttribute("confxmlfile", confXMLFilePath);
		}
		return agentDescriptionXML;
	}
}
