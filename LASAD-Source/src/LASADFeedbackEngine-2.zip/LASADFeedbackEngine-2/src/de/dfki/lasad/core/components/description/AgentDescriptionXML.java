package de.dfki.lasad.core.components.description;

import lasad.shared.dfki.meta.agents.SupportedOntologiesDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.CDATA;
import org.jdom.Element;

import de.dfki.lasad.agents.SupportedOntologiesDefXML;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AgentDescriptionXML {

	private static Log logger = LogFactory.getLog(AgentDescriptionXML.class);

	public static AgentDescription fromXML(Element agentElem) {
		try {
			BasicDescription basicDescr = BasicDescriptionXML
					.fromXML(agentElem);
			AgentDescription ad = new AgentDescription(basicDescr);

			String readableString = agentElem.getAttributeValue("readable");
			boolean readable = Boolean.parseBoolean(readableString);
			ad.setConfigReadable(readable);

			String writableString = agentElem.getAttributeValue("writable");
			boolean writable = Boolean.parseBoolean(writableString);
			ad.setConfigWritable(writable);

			String compiledString = agentElem.getAttributeValue("compiled");
			boolean compiled = Boolean.parseBoolean(compiledString);
			ad.setConfigCompiled(compiled);

			Element ontosElem = agentElem
					.getChild(SupportedOntologiesDefXML.ELEMENT_NAME);
			if (ontosElem != null) {
				SupportedOntologiesDef ontoDef = SupportedOntologiesDefXML
						.fromXML(ontosElem);
				ad.setSupportedOntology(ontoDef);
			} else {
				logger.error("Required XML element not defined: "
						+ SupportedOntologiesDefXML.ELEMENT_NAME);
				return null;
			}

			Element displayNameElem = agentElem.getChild("display-name");
			if (displayNameElem != null) {
				String displayName = displayNameElem.getText();
				ad.setDisplayName(displayName);
			}

			Element descriptionElem = agentElem.getChild("description");
			if (descriptionElem != null) {
				String description = descriptionElem.getText();
				ad.setDescription(description);
			}

			ad.init();
			return ad;
		} catch (Exception e) {
			logger.error("Error in 'fromXML(...)'", e);
			return null;
		}
	}

	public static Element toXML(AgentDescription agentDescr) {
		Element agentElem = BasicDescriptionXML.toXML("agent", agentDescr);

		agentElem.setAttribute("readable",
				String.valueOf(agentDescr.isConfigReadable()));
		agentElem.setAttribute("writable",
				String.valueOf(agentDescr.isConfigWritable()));
		agentElem.setAttribute("compiled",
				String.valueOf(agentDescr.isConfigCompiled()));

		String displayName = agentDescr.getDisplayName();
		if (displayName != null) {
			Element displayNameElem = new Element("display-name");
			CDATA displayNameCData = new CDATA(displayName);
			displayNameElem.addContent(displayNameCData);
			agentElem.addContent(displayNameElem);
		}

		String description = agentDescr.getDescription();
		if (description != null) {
			Element descriptionElem = new Element("description");
			CDATA descriptionCData = new CDATA(description);
			descriptionElem.addContent(descriptionCData);
			agentElem.addContent(descriptionElem);
		}

		Element ontoDefElem = SupportedOntologiesDefXML.toXML(agentDescr
				.getSupportedOntology());
		agentElem.addContent(ontoDefElem);

		return agentElem;
	}
}
