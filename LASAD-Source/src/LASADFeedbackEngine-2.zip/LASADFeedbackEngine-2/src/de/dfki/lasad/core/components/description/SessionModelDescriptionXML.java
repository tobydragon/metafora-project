package de.dfki.lasad.core.components.description;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class SessionModelDescriptionXML {

	private static Log logger = LogFactory
			.getLog(SessionModelDescriptionXML.class);

	public static SessionModelDescription fromXML(Element modelElem) {
		try {
			BasicDescription basicDescr = BasicDescriptionXML
					.fromXML(modelElem);
			SessionModelDescription modelDescr = new SessionModelDescription(
					basicDescr);
			modelDescr.setup();
			return modelDescr;
		} catch (Exception e) {
			logger.error("Error in 'fromXML(...)'", e);
			return null;
		}
	}

	public static Element toXML(SessionModelDescription agentDescr) {
		return BasicDescriptionXML.toXML("sessionmodel", agentDescr);
	}
}
