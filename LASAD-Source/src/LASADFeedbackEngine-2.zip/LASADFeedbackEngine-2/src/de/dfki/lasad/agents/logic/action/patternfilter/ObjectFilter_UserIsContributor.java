package de.dfki.lasad.agents.logic.action.patternfilter;

import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ObjectFilter_UserIsContributor extends ObjectFilter {

	private UserID referenceUser;

	public ObjectFilter_UserIsContributor(UserID referenceUser) {
		this.referenceUser = referenceUser;
	}

	@Override
	public boolean keep(ObjectResult oResult) {
		return oResult.getContributors().contains(referenceUser);
	}

}
