package de.dfki.lasad.events.eue.admin.agent.in;

import de.dfki.lasad.events.eue.admin.agent.EUEAgentAdminEvent;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class StartSessionEvent extends EUEAgentAdminEvent {

	private String sessionID;

	public StartSessionEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	@Override
	public String toString() {
		return "StartSessionEvent [sessionID=" + sessionID + "]";
	}

}
