package de.dfki.lasad.agents.data.analysis;

import lasad.shared.dfki.meta.agents.action.ActionType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * An {@link ActionType} and an associated {@link AnalysisResult}.
 * 
 * @author oliverscheuer
 * 
 */
public class ActionTypeResult {

	private Log logger = LogFactory.getLog(ActionTypeResult.class);

	private int id;
	private ActionType actionType;
	private AnalysisResult result;

	double utility = -1;

	public ActionTypeResult(ActionType actionType, AnalysisResult result) {
		this.actionType = actionType;
		this.result = result;
		this.id = ActionTypeResultIDGenerator.getFreshID();
	}

	public int getId() {
		return id;
	}

	public double getUtility() {
		return utility;
	}

	public void setUtility(double utility) {
		this.utility = utility;
	}

	public ActionType getActionType() {
		return actionType;
	}

	public void setActionType(ActionType actionType) {
		this.actionType = actionType;
	}

	public AnalysisResult getResult() {
		return result;
	}

	public void setResult(AnalysisResult result) {
		this.result = result;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((actionType == null) ? 0 : actionType.hashCode());
		result = prime * result
				+ ((this.result == null) ? 0 : this.result.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ActionTypeResult other = (ActionTypeResult) obj;
		if (actionType == null) {
			if (other.actionType != null)
				return false;
		} else if (!actionType.equals(other.actionType))
			return false;
		if (result == null) {
			if (other.result != null)
				return false;
		} else if (!result.equals(other.result))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ActionTypeResult [actionTypeID=" + actionType.getServiceID()
				+ ", result=" + result.toSimpleString() + ", utility="
				+ utility + "]";
	}

}
