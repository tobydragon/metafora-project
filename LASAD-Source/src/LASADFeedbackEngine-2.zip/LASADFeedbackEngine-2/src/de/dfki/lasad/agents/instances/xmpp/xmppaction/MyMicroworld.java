package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import lasad.gwt.client.communication.objects.Action;
import de.dfki.lasad.dataservice.lasad.LasadActionFactory;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;

public class MyMicroworld extends CfCreateObjectAction{
	private static Log logger = LogFactory.getLog(MyMicroworld.class);


	public MyMicroworld(CfAction cfAction) {
		super(cfAction);
	}

	@Override
	public Vector<Action> buildLasadActions() {
		if (state == CfActionState.create){
			return buildCreateActions("resources/xml/lasad/CreateMyMicroworldObject.xml");	
		}
		else if (state == CfActionState.waitingToModifyEUE){
			CfObject objectToUpdate = cfAction.getCfObjects().get(0);
			String mapId = objectToUpdate.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING);
			
			String viewElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING).getId();
			String viewUrl = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING).getValue();
			String textElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).getId();
			String text = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).getValue();
			String referenceUrlElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).getId();
			String referenceUrl = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).getValue();
			
			Vector<Action> actions = new Vector<Action>();
			actions.add(LasadActionFactory.createUpdateUrlElement(viewElementId, mapId, viewUrl));
			actions.add(LasadActionFactory.createUpdateTextElement(textElementId, mapId, text));
			actions.add(LasadActionFactory.createUpdateUrlElement(referenceUrlElementId, mapId, referenceUrl));
			return actions;
		}
		else {
			logger.error("[buildLasadActions] no actions designed for state - " + state);
			return null;
		}
	}
	
	@Override
	public void moveToUpdatePhase(CreateObjectEvent uEvent){
		setState(CfActionState.waitingToModifyEUE);
		
		String boxElementId =  uEvent.getEueObjectList().get(0).getID().getIdAsString();
		cfAction.getCfObjects().get(0).setId(boxElementId);
		
		//don't set type box (index 1)
		
		String viewId =  uEvent.getEueObjectList().get(2).getID().getIdAsString();
		cfAction.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING).setId(viewId);
		
		String textElementId =  uEvent.getEueObjectList().get(3).getID().getIdAsString();
		cfAction.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).setId(textElementId);
		
		String refUrlElementId =  uEvent.getEueObjectList().get(4).getID().getIdAsString();
		cfAction.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).setId(refUrlElementId);
		
	}

}
