package de.dfki.lasad.agents.data.analysis;

import de.dfki.lasad.agents.data.meta.AnalysisType;

/**
 * 
 * @author oliverscheuer
 *
 */
public class NoAnalysisResults extends AnalysisResult {

	public NoAnalysisResults(AnalysisType analysisType) {
		super(analysisType, new AnalyzableEntity());
	}

	@Override
	public String getValueAsString() {
		return "NO RESULTS";
	}

	@Override
	public String toString() {
		return getValueAsString();
	}
}
