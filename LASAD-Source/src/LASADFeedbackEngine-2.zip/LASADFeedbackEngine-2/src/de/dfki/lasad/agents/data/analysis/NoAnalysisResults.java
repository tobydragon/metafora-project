package de.dfki.lasad.agents.data.analysis;

import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class NoAnalysisResults extends AnalysisResult {

	public NoAnalysisResults(AnalysisType analysisType) {
		super(analysisType);
	}

	@Override
	public String getValueAsString() {
		return "NO RESULTS";
	}

	@Override
	public String toString() {
		return getValueAsString();
	}
}
