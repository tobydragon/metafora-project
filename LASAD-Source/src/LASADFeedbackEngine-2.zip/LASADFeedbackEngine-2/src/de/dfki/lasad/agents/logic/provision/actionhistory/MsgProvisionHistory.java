package de.dfki.lasad.agents.logic.provision.actionhistory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.action.ActionType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.object.AnalyzableEntity;
import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgProvisionHistory {

	private static Log logger = LogFactory.getLog(MsgProvisionHistory.class);

	private Map<UserID, Map<ServiceID, Map<AnalyzableEntity, List<MsgProvisionRecord>>>> user2type2entity2records = new HashMap<UserID, Map<ServiceID, Map<AnalyzableEntity, List<MsgProvisionRecord>>>>();

	private List<MsgProvisionHistoryChangedListener> listeners = new Vector<MsgProvisionHistoryChangedListener>();

	public void addListener(MsgProvisionHistoryChangedListener listener) {
		listeners.add(listener);
	}

	public synchronized void addRecords(UserID uID,
			List<ActionTypeResult> results) {
		Long currentTS = System.currentTimeMillis();
		List<MsgProvisionRecord> addedRecords = new Vector<MsgProvisionRecord>();
		for (ActionTypeResult result : results) {
			MsgProvisionRecord addedRecord = addRecord(uID, result, currentTS);
			addedRecords.add(addedRecord);
		}
		notifyListeners(addedRecords);
	}

	public synchronized boolean recordExists(UserID uID, ActionType aType,
			AnalyzableEntity entity) {
		List<MsgProvisionRecord> matchesInHistory = getRecords(uID, aType,
				entity);
		logger.debug("Matching records in history: " + matchesInHistory);
		return matchesInHistory.size() > 0;
	}

	private void notifyListeners(List<MsgProvisionRecord> addedRecords) {
		for (MsgProvisionHistoryChangedListener listener : listeners) {
			listener.onHistoryChanged(addedRecords);
		}
	}

	private MsgProvisionRecord addRecord(UserID uID, ActionTypeResult result,
			Long currentTS) {
		ActionType actionType = result.getActionType();
		AnalysisResult analysisResult = result.getResult();
		AnalyzableEntity entity;
		if (analysisResult instanceof ObjectResult) {
			ObjectResult objectResult = (ObjectResult) analysisResult;
			entity = objectResult.getAnalyzedEntity();
		} else {
			entity = new AnalyzableEntity();
		}
		return addRecord(uID, actionType, entity, currentTS);
	}

	private MsgProvisionRecord addRecord(UserID uID, ActionType actionType,
			AnalyzableEntity entity, Long currentTS) {
		MsgProvisionRecord record = new MsgProvisionRecord(uID, actionType,
				entity, currentTS);
		logger.debug("Record added: " + record);
		ServiceID serviceID = actionType.getServiceID();

		Map<ServiceID, Map<AnalyzableEntity, List<MsgProvisionRecord>>> type2entity2records = user2type2entity2records
				.get(uID);
		if (type2entity2records == null) {
			type2entity2records = new HashMap<ServiceID, Map<AnalyzableEntity, List<MsgProvisionRecord>>>();
			user2type2entity2records.put(uID, type2entity2records);
		}

		Map<AnalyzableEntity, List<MsgProvisionRecord>> entity2records = type2entity2records
				.get(serviceID);
		if (entity2records == null) {
			entity2records = new HashMap<AnalyzableEntity, List<MsgProvisionRecord>>();
			type2entity2records.put(serviceID, entity2records);
		}

		List<MsgProvisionRecord> records = entity2records.get(entity);
		if (records == null) {
			records = new Vector<MsgProvisionRecord>();
			entity2records.put(entity, records);
		}

		records.add(record);
		return record;
	}

	private List<MsgProvisionRecord> getRecords(UserID uID, ActionType aType,
			AnalyzableEntity entity) {

		Map<ServiceID, Map<AnalyzableEntity, List<MsgProvisionRecord>>> type2entity2records = user2type2entity2records
				.get(uID);
		if (type2entity2records != null) {
			Map<AnalyzableEntity, List<MsgProvisionRecord>> entity2records = type2entity2records
					.get(aType.getServiceID());
			if (entity2records != null) {
				List<MsgProvisionRecord> records = entity2records.get(entity);
				if (records != null) {
					return records;
				}
			}
		}
		return new Vector<MsgProvisionRecord>();
	}

}
