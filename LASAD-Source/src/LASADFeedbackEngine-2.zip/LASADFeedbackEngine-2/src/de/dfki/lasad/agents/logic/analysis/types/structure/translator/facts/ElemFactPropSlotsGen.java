package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.analysis.structure.model.Bin;
import lasad.shared.dfki.meta.agents.analysis.structure.model.Comparison;
import lasad.shared.dfki.meta.agents.analysis.structure.model.ElementVariableProp;
import lasad.shared.dfki.meta.ontology.Ontology;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ElemFactPropSlotsGen {

	private static final Log logger = LogFactory
			.getLog(ElemFactPropSlotsGen.class);

	private Ontology ontology;
	private JessIDAndSlotNameGenerator idGen;

	// in
	private Map<ElementVariableProp, List<Comparison>> propVars2Comparisons;
	private Bin bin;

	// generated
	private List<PropSlotGen> propSlotGens = new Vector<PropSlotGen>();

	/**
	 * Generates Jess 'property' slots, according to the given specification, to
	 * be used within a Jess 'node' or 'link' Fact pattern.
	 * 
	 * 
	 * @param bin
	 *            {@link Comparison} selector (only from {@link Bin})
	 */
	public ElemFactPropSlotsGen(JessIDAndSlotNameGenerator idGen,
			Ontology ontology,
			Map<ElementVariableProp, List<Comparison>> propVars2Comparisons,
			Bin bin) {
		this.idGen = idGen;
		this.ontology = ontology;

		this.propVars2Comparisons = propVars2Comparisons;
		this.bin = bin;

		// List<PropDescr> props = elemVar.getPropDescrs(ontology);

		for (ElementVariableProp propVar : propVars2Comparisons.keySet()) {
			List<Comparison> comparisons = propVars2Comparisons.get(propVar);
			PropSlotGen propSlotGen = new PropSlotGen(idGen, propVar,
					comparisons, bin, -1, false, false);
			propSlotGens.add(propSlotGen);
		}

	}

	public int getNumConstrainedSlots() {
		int count = 0;
		for (PropSlotGen propSlotGen : propSlotGens) {
			if (propSlotGen.getNumConstrs() > 0) {
				++count;
			}
		}
		return count;
	}

	public String getString() {
		StringBuffer buf = new StringBuffer();
		Iterator<PropSlotGen> iter = propSlotGens.iterator();
		while (iter.hasNext()) {
			PropSlotGen propSlotGen = iter.next();
			String slotExp = propSlotGen.getString();
			buf.append(slotExp);
			if (iter.hasNext()) {
				buf.append("\n");
			}
		}
		return buf.toString();
	}
}
