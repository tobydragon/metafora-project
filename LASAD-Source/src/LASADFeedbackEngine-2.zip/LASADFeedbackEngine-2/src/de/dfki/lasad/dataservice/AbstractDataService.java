package de.dfki.lasad.dataservice;

import java.util.concurrent.PriorityBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ConfigurationManager;
import de.dfki.lasad.core.DefaultEventPrioritizer;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.instance.AbstractComponent;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.IComponent;
import de.dfki.lasad.core.components.instance.IDataService;
import de.dfki.lasad.core.components.instance.ServiceStatus;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.session.SessionManager;
import de.dfki.lasad.util.threads.Signal;

/**
 * Provides default implementations for most methods, most notably an
 * {@link PriorityBlockingQueue<Event>} to keep received {@link EventImpl}s and a
 * {@link Thread} that dequeues and processes {@link EventImpl}s.
 * 
 * <br/>
 * <br/>
 * (see also {@link IComponent}, {@link IAgent})
 * 
 * @author Oliver Scheuer
 * 
 */
public abstract class AbstractDataService extends AbstractComponent implements
		IDataService {

	protected DataServiceDescription description;

	private boolean processEvents = false;
	private Signal signal = new Signal();

	Log logger = LogFactory.getLog(AbstractDataService.class);

	protected SessionManager sessionManager;
	protected ConfigurationManager configManager;

	protected PriorityBlockingQueue<EventImpl> outQueue = new PriorityBlockingQueue<EventImpl>();
	private Thread eventThread;

	@Override
	public void configure(AbstractComponentDescription description) {
		this.description = (DataServiceDescription) description;
	}

	@Override
	public AbstractComponentDescription getDescription() {
		return description;
	}

	@Override
	public String getComponentID() {
		return description.getComponentID();
	}

	@Override
	public void doWire(SessionManager sessionManager,
			ConfigurationManager configManager) {
		this.sessionManager = sessionManager;
		this.configManager = configManager;
		setServiceStatus(ServiceStatus.READY_TO_START);
	}

	@Override
	public synchronized void startService() {
		outQueue = new PriorityBlockingQueue<EventImpl>();
		startEventThread();
	}

	@Override
	public synchronized void stopService() {
		try {
			processEvents = false;
		} catch (Exception e) {
			logger.error("stop() " + e.getClass(), e);
		}
	}

	@Override
	public void onOutEvent(EventImpl event) {
		DefaultEventPrioritizer.assignPriority(event);
		outQueue.put(event);
		logger.debug("Send event to server: " + event.toString());
	}

	protected abstract void processEvent(Event event);

	private final void startEventThread() {
		processEvents = true;
		eventThread = new Thread(new Consumer());
		eventThread.start();
		logger.info(getComponentID()
				+ ": Waiting for event thread to start ...");
		signal.waitForSignal(true);
		logger.info(getComponentID()
				+ ": Waiting for event thread to start: DONE");
	}

	class Consumer implements Runnable {

		@Override
		public void run() {
			try {
				signal.signalGo();
				do {
					Event event = outQueue.take();
					processEvent(event);
				} while (processEvents);
				signal.signalStop();
			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}
		}

	}

}
