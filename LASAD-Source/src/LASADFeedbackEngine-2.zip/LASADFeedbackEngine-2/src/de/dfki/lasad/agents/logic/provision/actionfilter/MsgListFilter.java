package de.dfki.lasad.agents.logic.provision.actionfilter;

import java.util.List;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;

public interface MsgListFilter {

	/**
	 * Removes all elements from the given list according to the filter
	 * definition
	 * 
	 * @param unfilteredList
	 */
	public void filter(List<ActionTypeResult> unfilteredList);
}
