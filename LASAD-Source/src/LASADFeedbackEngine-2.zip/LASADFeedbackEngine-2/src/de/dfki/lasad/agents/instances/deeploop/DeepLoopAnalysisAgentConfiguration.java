package de.dfki.lasad.agents.instances.deeploop;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import de.dfki.lasad.agents.SessionChecker;
import de.dfki.lasad.agents.SimpleSessionChecker;
import de.dfki.lasad.agents.data.analysis.BinaryResult;
import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.instances.deeploop.preprocessing.SimplePropertyMappingsConfiguration;
import de.dfki.lasad.authoring.model.AgentConfigFE;
import de.dfki.lasad.core.components.configuration.IAgentConfiguration;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class DeepLoopAnalysisAgentConfiguration implements IAgentConfiguration {

	private String agentID = "DL";

	// Classifier IDs
	public static final String CoR_en = "CoR_en";
	public static final String QA_en = "QA_en";
	public static final String CQ_en = "CQ_en";
	public static final String CSA_en = "CSA_en";
	public static final String CCA_en = "CCA_en";
	public static final String NonTF_en = "NonTF_en";

	// public static final String argEval1 = "argEval1";
	public static final String argEval2 = "argEval2";
	// public static final String clarif1 = "clarif1";
	public static final String clarif2 = "clarif2";
	// public static final String chainOpposition1 = "chainOpposition1";
	public static final String chainOpposition2 = "chainOpposition2";
	public static final String newPerspective1 = "newPerspective1";
	public static final String buildOn1 = "buildOn1";

	protected SessionChecker ontologyChecker;
	protected SimplePropertyMappingsConfiguration mappingConfiguration = new SimplePropertyMappingsConfiguration();
	private String wsAddress = "http://amath07.activemath.org:28080/axis2/services/DeepLoopClassificationV2";
	
	private List<AnalysisType> analysisTypeList = new Vector<AnalysisType>();

	private boolean publishAllActionTypes = false;
	private boolean publishAllAnalysisTypes = false;
	
	public DeepLoopAnalysisAgentConfiguration() {
		addAnalysisTypes();
		List<String> ontologyIDs = new Vector<String>();
		ontologyIDs.add("Argunaut");
		ontologyChecker = new SimpleSessionChecker(ontologyIDs);
	}

	@Override
	public void load(File configFile) {
		// nothing to do
	}

	@Override
	public boolean doPublishAllActionTypes() {
		return publishAllActionTypes;
	}
	
	@Override
	public boolean doPublishAllAnalysisTypes() {
		return publishAllAnalysisTypes;
	}
	
	@Override
	public boolean hasConfigFE() {
		return false;
	}

	@Override
	public AgentConfigFE getConfigFE() {
		return null;
	}

	@Override
	public void setConfigFE(AgentConfigFE agentConfigFE) {
		// ignore
	}

	@Override
	public void replaceAgentID(String agentID) {
		this.agentID = agentID;
		for (AnalysisType aType : analysisTypeList) {
			aType.setAgentID(agentID);
		}
	}

	public void addAnalysisType(AnalysisType analysisType) {
		analysisTypeList.add(analysisType);
	}

	@Override
	public List<AnalysisType> getAnalysisTypes() {
		return analysisTypeList;
	}

	@Override
	public List<ActionType> getActionTypes() {
		return new Vector<ActionType>();
	}

	public void setSupportedOntologies(List<String> supportedOntologies) {
		this.ontologyChecker = new SimpleSessionChecker(supportedOntologies);
	}

	@Override
	public SessionChecker getSessionChecker() {
		return ontologyChecker;
	}

	public SimplePropertyMappingsConfiguration getMappingConfiguration() {
		return mappingConfiguration;
	}

	public void setMappingConfiguration(
			SimplePropertyMappingsConfiguration mappingConfiguration) {
		this.mappingConfiguration = mappingConfiguration;
	}

	public String getWsAddress() {
		return wsAddress;
	}

	public void setWsAddress(String wsAddress) {
		this.wsAddress = wsAddress;
	}

	private void addAnalysisTypes() {

		AnalysisType analysisType_CoR_en = new AnalysisType(BinaryResult.class,
				agentID, CoR_en, true);
		analysisType_CoR_en.setDisplayName("Reasoned Claim");

		AnalysisType analysisType_QA_en = new AnalysisType(BinaryResult.class,
				agentID, QA_en, true);
		analysisType_QA_en.setDisplayName("Question-Answer");

		AnalysisType analysisType_CQ_en = new AnalysisType(BinaryResult.class,
				agentID, CQ_en, true);
		analysisType_CQ_en.setDisplayName("Contribution-Followed-By-Question");

		AnalysisType analysisType_CSA_en = new AnalysisType(BinaryResult.class,
				agentID, CSA_en, true);
		analysisType_CSA_en.setDisplayName("Contribution-SupportArgument");

		AnalysisType analysisType_CCA_en = new AnalysisType(BinaryResult.class,
				agentID, CCA_en, true);
		analysisType_CCA_en.setDisplayName("Contribution-CounterArgument");

		AnalysisType analysisType_NonTF_en = new AnalysisType(
				BinaryResult.class, agentID, NonTF_en, true);
		analysisType_NonTF_en.setDisplayName("Off-topic contribution");

		AnalysisType analysisType_argEval2 = new AnalysisType(
				BinaryResult.class, agentID, argEval2, true);
		analysisType_argEval2.setDisplayName("Argument + Evaluation");

		AnalysisType analysisType_clarif2 = new AnalysisType(
				BinaryResult.class, agentID, clarif2, true);
		analysisType_clarif2.setDisplayName("Clarification of opinion");

		AnalysisType analysisType_chainOpposition2 = new AnalysisType(
				BinaryResult.class, agentID, chainOpposition2, true);
		analysisType_chainOpposition2.setDisplayName("Chain of Opposition");

		AnalysisType analysisType_newPerspective1 = new AnalysisType(
				BinaryResult.class, agentID, newPerspective1, true);
		analysisType_newPerspective1.setDisplayName("New Perspective");

		AnalysisType analysisType_buildOn1 = new AnalysisType(
				BinaryResult.class, agentID, buildOn1, true);
		analysisType_buildOn1.setDisplayName("Build On");

		addAnalysisType(analysisType_CoR_en);
		addAnalysisType(analysisType_QA_en);
		addAnalysisType(analysisType_CQ_en);
		addAnalysisType(analysisType_CSA_en);
		addAnalysisType(analysisType_CCA_en);
		addAnalysisType(analysisType_NonTF_en);

		addAnalysisType(analysisType_argEval2);
		addAnalysisType(analysisType_clarif2);
		addAnalysisType(analysisType_chainOpposition2);
		addAnalysisType(analysisType_newPerspective1);
		addAnalysisType(analysisType_buildOn1);
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + " [wsaddress = " + wsAddress + "]";
	}
}
