package de.dfki.lasad.agents.instances.deeploop;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.ServiceType;
import lasad.shared.dfki.meta.agents.analysis.AnalysisResultDatatype;
import lasad.shared.dfki.meta.agents.analysis.AnalysisType;

import de.dfki.lasad.agents.SessionChecker;
import de.dfki.lasad.agents.SimpleSessionChecker;
import de.dfki.lasad.agents.instances.deeploop.preprocessing.SimplePropertyMappingsConfiguration;
import de.dfki.lasad.core.components.configuration.IAgentConfiguration;
import de.dfki.lasad.events.agents.OnRequestServiceSpec;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class DeepLoopAnalysisAgentConfiguration implements IAgentConfiguration {

	private String agentID = null;

	// Classifier IDs
	public static final String CoR_en = "CoR_en";
	public static final String QA_en = "QA_en";
	public static final String CQ_en = "CQ_en";
	public static final String CSA_en = "CSA_en";
	public static final String CCA_en = "CCA_en";
	public static final String NonTF_en = "NonTF_en";

	// public static final String argEval1 = "argEval1";
	public static final String argEval2 = "argEval2";
	// public static final String clarif1 = "clarif1";
	public static final String clarif2 = "clarif2";
	// public static final String chainOpposition1 = "chainOpposition1";
	public static final String chainOpposition2 = "chainOpposition2";
	public static final String newPerspective1 = "newPerspective1";
	public static final String buildOn1 = "buildOn1";

	protected SessionChecker ontologyChecker;
	protected SimplePropertyMappingsConfiguration mappingConfiguration = new SimplePropertyMappingsConfiguration();
	private String wsAddress = "http://amath07.activemath.org:28080/axis2/services/DeepLoopClassificationV2";

	private List<ServiceType> serviceTypeList = new Vector<ServiceType>();
	private Map<ServiceID, AnalysisType> provisionTypeID2analysisType = new HashMap<ServiceID, AnalysisType>();

	private List<OnRequestServiceSpec> onRequestServiceList = new Vector<OnRequestServiceSpec>();

	public DeepLoopAnalysisAgentConfiguration() {
		super();
	}

	@Override
	public void setComponentID(String componentID) {
		this.agentID = componentID;
	}

	@Override
	public void load(File configFile) {
		// nothing to do
	}

	@Override
	public void init() {
		addTypes();
		List<String> ontologyIDs = new Vector<String>();
		ontologyIDs.add("Argunaut");
		ontologyChecker = new SimpleSessionChecker(ontologyIDs);
	}

	@Override
	public void compileNotYetCompiledAnalysisTypes() {
		// nothing to do
	}

	public List<OnRequestServiceSpec> getTypesToPublish() {
		return onRequestServiceList;
	}

	public AnalysisType getRequestedAnalysisType(ServiceID provisionServiceID) {
		return provisionTypeID2analysisType.get(provisionServiceID);
	}

	public List<ServiceType> getServiceTypes() {
		return serviceTypeList;
	}

	public void setSupportedOntologies(List<String> supportedOntologies) {
		this.ontologyChecker = new SimpleSessionChecker(supportedOntologies);
	}

	@Override
	public SessionChecker getSessionChecker() {
		return ontologyChecker;
	}

	public SimplePropertyMappingsConfiguration getMappingConfiguration() {
		return mappingConfiguration;
	}

	public void setMappingConfiguration(
			SimplePropertyMappingsConfiguration mappingConfiguration) {
		this.mappingConfiguration = mappingConfiguration;
	}

	public String getWsAddress() {
		return wsAddress;
	}

	public void setWsAddress(String wsAddress) {
		this.wsAddress = wsAddress;
	}

	private void addTypes() {

		addType(CoR_en, "Reasoned Claim", false);
		addType(QA_en, "Question-Answer", false);
		addType(CQ_en, "Contribution-Followed-By-Question", false);
		addType(CSA_en, "Contribution-SupportArgument", false);
		addType(CCA_en, "Contribution-CounterArgument", false);
		addType(NonTF_en, "Off-topic contribution", false);

		addType(argEval2, "Argument + Evaluation", true);
		addType(clarif2, "Clarification of opinion", true);
		addType(chainOpposition2, "Chain of Opposition", true);
		addType(newPerspective1, "New Perspective", true);
		addType(buildOn1, "Build On", true);
	}

	private void addType(String typeID, String displayName,
			boolean onlyPositiveInstances) {
		AnalysisType analysisType = new AnalysisType(
				AnalysisResultDatatype.object_binary_result, new ServiceID(
						agentID, typeID, ServiceClass.ANALYSIS));
		analysisType.setOnlyPositiveInstances(onlyPositiveInstances);

		ServiceID provisionID = new ServiceID(agentID, typeID,
				ServiceClass.PROVISION);
		OnRequestServiceSpec provisionSpec = new OnRequestServiceSpec(
				provisionID, displayName);

		serviceTypeList.add(analysisType);
		provisionTypeID2analysisType.put(provisionID, analysisType);
		onRequestServiceList.add(provisionSpec);
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + " [wsaddress = " + wsAddress + "]";
	}
}
