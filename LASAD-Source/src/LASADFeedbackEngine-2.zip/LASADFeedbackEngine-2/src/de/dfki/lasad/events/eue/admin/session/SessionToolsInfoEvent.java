package de.dfki.lasad.events.eue.admin.session;

import de.dfki.lasad.session.data.meta.Ontology;
import de.dfki.lasad.session.data.meta.ToolContext;

/**
 * Provides information about all available sessions (in particular, the used
 * {@link Ontology}s).
 * 
 * @author Oliver Scheuer
 * 
 */
public class SessionToolsInfoEvent extends EUESessionInfoEvent {

	String ontologyID;
	String templateID;
	String templateXML;

	ToolContext toolContext;

	public SessionToolsInfoEvent(String srcCompId) {
		super(srcCompId);
	}

	public String getOntologyID() {
		return ontologyID;
	}

	public void setOntologyID(String ontologyID) {
		this.ontologyID = ontologyID;
	}

	public String getTemplateID() {
		return templateID;
	}

	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}

	public String getTemplateXML() {
		return templateXML;
	}

	public void setTemplateXML(String templateXML) {
		this.templateXML = templateXML;
	}

	public ToolContext getToolContext() {
		return toolContext;
	}

	public void setToolContext(ToolContext toolContext) {
		this.toolContext = toolContext;
	}

	@Override
	public String toString() {
		return "sessionID=" + sessionID + ", ontologyID=" + ontologyID
				+ ", templateID=" + templateID + ", toolContext="
				+ (toolContext == null ? "null" : toolContext.toString());
	}

}
