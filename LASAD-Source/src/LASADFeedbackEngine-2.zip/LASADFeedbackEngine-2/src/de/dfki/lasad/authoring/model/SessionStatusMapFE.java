package de.dfki.lasad.authoring.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jdom.Element;

import de.dfki.lasad.util.XMLUtil;

/**
 * runtime status of sessions and agents (to be used in the graphical frontend).
 * 
 * @author oliverscheuer
 * 
 */
public class SessionStatusMapFE {

	private Map<String, ServiceStatusFE> sessionID2Status = new HashMap<String, ServiceStatusFE>();
	private Map<String, Map<String, ServiceStatusFE>> sessionID2agent2Status = new HashMap<String, Map<String, ServiceStatusFE>>();

	public Map<String, ServiceStatusFE> getSessionID2Status() {
		return sessionID2Status;
	}

	public void setSessionID2Status(
			Map<String, ServiceStatusFE> sessionID2Status) {
		this.sessionID2Status = sessionID2Status;
	}

	public void addSessionStatus(String sessionID, ServiceStatusFE status) {
		sessionID2Status.put(sessionID, status);
	}

	public void addAgentStatus(String sessionID, String agentID,
			ServiceStatusFE status) {
		Map<String, ServiceStatusFE> agent2Status = sessionID2agent2Status
				.get(sessionID);
		if (agent2Status == null) {
			agent2Status = new HashMap<String, ServiceStatusFE>();
			sessionID2agent2Status.put(sessionID, agent2Status);
		}
		agent2Status.put(agentID, status);
	}

	public Map<String, Map<String, ServiceStatusFE>> getSessionID2agent2Status() {
		return sessionID2agent2Status;
	}

	public void setSessionID2agent2Status(
			Map<String, Map<String, ServiceStatusFE>> sessionID2agent2Status) {
		this.sessionID2agent2Status = sessionID2agent2Status;
	}

	public Element toXMLElem() {
		Set<String> sessionList = sessionID2Status.keySet();

		Element descrsElem = new Element(ElementStrings.SESSION_STATUS_MAP);

		for (String session : sessionList) {
			Element sess = new Element(ElementStrings.SESSION);
			String sessionStatus = sessionID2Status.get(session).toString();
			sess.setAttribute(ElementStrings.NAME, session);
			sess.setAttribute(ElementStrings.STATUS, sessionStatus);

			if (sessionID2agent2Status.containsKey(session)) {
				Map<String, ServiceStatusFE> agentStatusMap = sessionID2agent2Status
						.get(session);
				Set<String> agentList = agentStatusMap.keySet();
				for (String agent : agentList) {
					Element ag = new Element(ElementStrings.AGENT);
					String agentStatus = agentStatusMap.get(agent).toString();
					ag.setAttribute(ElementStrings.NAME, agent);
					ag.setAttribute(ElementStrings.STATUS, agentStatus);
					sess.addContent(ag);
				}
			}
			descrsElem.addContent(sess);
		}

		return descrsElem;
	}

	public static SessionStatusMapFE fromXMLElem(Element xml) {
		SessionStatusMapFE sessionStatusMapFE = new SessionStatusMapFE();

		List<Element> sessionElemList = (List<Element>) xml
				.getChildren(ElementStrings.SESSION);
		for (Element session : sessionElemList) {
			String sessName = session.getAttribute(ElementStrings.NAME)
					.getValue();
			String sessStatus = session.getAttribute(ElementStrings.STATUS)
					.getValue();

			sessionStatusMapFE.addSessionStatus(sessName,
					ServiceStatusFE.valueOf(sessStatus));

			List<Element> agentElemList = (List<Element>) xml
					.getChildren(ElementStrings.AGENT);
			HashMap<String, ServiceStatusFE> agent2Status = new HashMap<String, ServiceStatusFE>();

			for (Element agent : agentElemList) {
				String agentName = agent.getAttribute(ElementStrings.NAME)
						.getValue();
				String agentStatus = agent.getAttribute(ElementStrings.STATUS)
						.getValue();
				sessionStatusMapFE.addAgentStatus(sessName, agentName,
						ServiceStatusFE.valueOf(agentStatus));
			}
		}

		return sessionStatusMapFE;
	}

	public String toXMLString() {
		Element e = toXMLElem();
		return XMLUtil.xmlElem2docString(e);
	}

	public static SessionStatusMapFE fromXMLString(String xml) {
		Element e = XMLUtil.string2xmlElem(xml);
		return fromXMLElem(e);
	}

	@Override
	public String toString() {
		return "SessionStatusMapFE [sessionID2Status=" + sessionID2Status
				+ ", sessionID2agent2Status=" + sessionID2agent2Status + "]";
	}

}
