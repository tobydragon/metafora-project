package de.dfki.lasad.authoring.model.pattern;

/**
 * Comparison of a string variable to some set variable.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class String2VarSetComparison extends VariableComparison{
	private String2SetOperator operator;
	private PropertyVariable rightExpr;

	public String2SetOperator getOperator() {
		return operator;
	}

	public void setOperator(String2SetOperator operator) {
		this.operator = operator;
	}

	public PropertyVariable getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(PropertyVariable rightExpr) {
		this.rightExpr = rightExpr;
	}

	protected VariableComparison getInverseBasic() {
		Set2VarStringComparison inverted = new Set2VarStringComparison();
		inverted.setOperator(getOperator().invert());
		return inverted;
	}
}
