package de.dfki.lasad.agents.instances.xmpp.xmppaction;

import java.awt.Point;
import java.util.Vector;

import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.parameters.ParameterTypes;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.dataservice.lasad.xml.ElementCordinate;
import de.uds.cfcommunication.MetaforaStrings;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;

public abstract class CfActionDuringExecution {
	private static Log logger = LogFactory.getLog(CfActionDuringExecution.class);
		
	CfAction cfAction;
	CfActionState state;
	
	public CfActionDuringExecution(CfAction cfAction){
		this.cfAction = cfAction;
		this.state = CfActionState.create;
	}
	
	public void setState(CfActionState state) {
		this.state = state;
	}


	public CfAction getCfResponseAction(){
		if (state!=CfActionState.waitingToReportToXmpp){
			logger.error("[getCfResponseAction] object not in correct state for return message, state - " + state);
		}
		return cfAction;
	}

	public abstract Vector<Action> buildLasadActions(); 
	
//////////////////////  Static methods  /////////////////////////////////	
	
	public static CfActionDuringExecution buildActionfromCf(CfAction cfAction) {
		String cfActionType = cfAction.getCfActionType().getType();
		if (MetaforaStrings.ACTION_TYPE_CREATE_ELEMENT_STRING.equalsIgnoreCase(cfActionType)) {
			CfObject elementObject = cfAction.getCfObjects().get(0);
			String typeToCheck = elementObject.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_ELEMENT_TYPE_STRING);
			if (MetaforaStrings.OBJECT_TYPE_HELP_REQUEST_STRING.equalsIgnoreCase(typeToCheck)){
					return new CreateHelpRequest(cfAction);
			}
			else if (MetaforaStrings.OBJECT_TYPE_MY_MICROWORLD_STRING.equalsIgnoreCase(typeToCheck)){
				return new CreateMyMicroworld(cfAction);
			}
			else {
				logger.error("[buildActionfromCf] unknown element type - " + typeToCheck);
				return null;
			}
		}
		else if (MetaforaStrings.ACTION_TYPE_CREATE_FEEDBACK_STRING.equalsIgnoreCase(cfActionType)) {
			//TODO: Replace with real CreateFeedbackAction class 
			return new CreateChatAction(cfAction);
		}
		else if (MetaforaStrings.ACTION_TYPE_CREATE_USER_STRING.equalsIgnoreCase(cfActionType)) {
			return new CreateUserAction(cfAction);
		}
		else if (MetaforaStrings.ACTION_TYPE_CREATE_MAP_STRING.equalsIgnoreCase(cfActionType)) {
			return new CreateMapAction(cfAction);
		}
		else {
			logger.error("[buildActionfromCf] unknown action type - " + cfActionType);
			return null;
		}
	}
	
	
	//MUTATOR: changes actions vector
	static void replaceInfo(Vector<Action> actions, String mapId, String userName){
		Point current_p=ElementCordinate.getPoint(mapId);
		for (Action action : actions){
		
			logger.debug("[replaceInfo] coordinates found");
			action.replaceParameter(ParameterTypes.MapId, mapId);
			action.replaceParameter(ParameterTypes.UserName, userName);
			action.replaceParameter(ParameterTypes.PosX,Integer.toString(current_p.x));
			action.replaceParameter(ParameterTypes.PosY,Integer.toString(current_p.y));			   
		}
		
	}

	

}
