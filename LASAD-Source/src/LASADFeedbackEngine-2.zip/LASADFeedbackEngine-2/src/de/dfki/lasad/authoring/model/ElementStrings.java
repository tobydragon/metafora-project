package de.dfki.lasad.authoring.model;

public class ElementStrings {
	public static final String AGENT_DESCRIPTIONS = "agent-descriptions";
	public static final String AGENT_DESCRIPTION = "agent-description";
	public static final String AGENT_ID = "agent-id";
	public static final String DISPLAY_NAME = "display-name";
	public static final String CONF_READABLE = "conf-readable";
	public static final String CONF_WRITEABLE = "conf-writeable";
	public static final String SUPPORTED_ONTOLOGY = "supported-ontology";
	public static final String AGENT = "agent";
	
	public static final String AGENTS_TO_ONTOLOGIES = "agents-to-ontologies";
	public static final String ONTOLOGY = "ontology";
	public static final String NAME = "name";
	public static final String AGENTS_TO_SESSIONS = "agents-to-sessions";
	public static final String SESSION = "session";
	
	public static final String SESSION_STATUS_MAP = "session-status-map";
	public static final String STATUS = "status";
}
