package de.dfki.lasad.agents.logic.provision.actionfilter;

import lasad.shared.dfki.meta.agents.action.ActionType;
import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.agents.data.analysis.object.AnalyzableEntity;
import de.dfki.lasad.agents.data.analysis.object.ObjectResult;
import de.dfki.lasad.agents.logic.provision.actionhistory.MsgProvisionHistory;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgFilter_DiscardInstancesAlreadyPointedTo implements MsgFilter {

	private UserID userID = null;
	private MsgProvisionHistory msgHistoryRef = null;

	public MsgFilter_DiscardInstancesAlreadyPointedTo(UserID userID,
			MsgProvisionHistory msgHistoryRef) {
		this.userID = userID;
		this.msgHistoryRef = msgHistoryRef;
	}

	@Override
	public boolean keep(ActionTypeResult aTypeResult) {
		ActionType actionType = aTypeResult.getActionType();
		AnalysisResult analysisResult = aTypeResult.getResult();
		AnalyzableEntity entity;
		if (analysisResult instanceof ObjectResult) {
			entity = ((ObjectResult) analysisResult).getAnalyzedEntity();
		} else {
			entity = new AnalyzableEntity();
		}
		return !(msgHistoryRef.recordExists(userID, actionType, entity));
	}

}
