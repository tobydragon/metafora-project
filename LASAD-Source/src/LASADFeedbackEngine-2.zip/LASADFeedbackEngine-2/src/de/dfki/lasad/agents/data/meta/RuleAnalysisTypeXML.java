package de.dfki.lasad.agents.data.meta;

import org.jdom.CDATA;
import org.jdom.Element;

import de.dfki.lasad.agents.data.analysis.BinaryResult;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class RuleAnalysisTypeXML {

	public static final String ELEMENT_NAME = "pattern";

	public static RuleAnalysisType fromXML(String agentID, Element elem) {
		String pID = elem.getAttributeValue("id");
		String def = elem.getText();
		RuleAnalysisType patDef = new RuleAnalysisType(BinaryResult.class,
				agentID, pID, def);
		return patDef;
	}

	public static Element toXML(RuleAnalysisType aType) {

		Element elem = new Element(ELEMENT_NAME);
		elem.setAttribute("id", aType.getTypeID());
		CDATA ruleDefinition = new CDATA(aType.getDefinition());
		elem.addContent("\n");
		elem.addContent(ruleDefinition);

		return elem;
	}
}
