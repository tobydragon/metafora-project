package de.dfki.lasad.events.eue.admin.session;

import de.dfki.lasad.events.eue.EUESessionEvent;
import de.dfki.lasad.events.eue.admin.EUEAdminEvent;
import de.dfki.lasad.session.data.SessionID;

/**
 * Event providing some information regarding the configuration of a specific
 * EUE session.
 * 
 * @author Oliver Scheuer
 * 
 */
public class EUESessionInfoEvent extends EUESessionEvent implements
		EUEAdminEvent {

	public EUESessionInfoEvent(String srcCompId) {
		super(srcCompId);
	}

	public EUESessionInfoEvent(SessionID sessionID, String srcCompId) {
		super(sessionID, srcCompId);
	}
}
