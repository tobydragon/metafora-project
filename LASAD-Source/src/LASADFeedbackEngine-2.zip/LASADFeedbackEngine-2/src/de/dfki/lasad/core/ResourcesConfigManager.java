package de.dfki.lasad.core;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;
import lasad.shared.dfki.meta.agents.SupportedOntologiesDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import de.dfki.lasad.core.components.collections.AgentDescriptions;
import de.dfki.lasad.core.components.collections.AgentDescriptionsXML;
import de.dfki.lasad.core.components.collections.BasicResourceDescriptions;
import de.dfki.lasad.core.components.collections.BasicResourceDescriptionsXML;
import de.dfki.lasad.core.components.configuration.IAgentConfiguration;
import de.dfki.lasad.core.components.configuration.IDataServiceConfiguration;
import de.dfki.lasad.core.components.configuration.ISessionModelConfiguration;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.BasicDescription;
import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.core.components.instance.AbstractComponent;
import de.dfki.lasad.events.agents.configchange.AFStateChangedEventListener;
import de.dfki.lasad.events.agents.configchange.AgentDescriptionAddedOrUpdatedEvent;
import de.dfki.lasad.events.agents.configchange.AgentDescriptionDeletedEvent;
import de.dfki.lasad.util.ObjectToFETranslator;
import de.dfki.lasad.util.XMLUtil;

/**
 * Provides {@link AbstractComponentDescription}s, which can be used to
 * initialize instance of these {@link AbstractComponent}s during runtime, in
 * particular {@link DataServiceDescription}s, {@link SessionModelDescription}s
 * and {@link AgentDescription}s.
 * 
 * @author oliverscheuer
 * 
 */
public class ResourcesConfigManager {

	static Log logger = LogFactory.getLog(ResourcesConfigManager.class);

	private List<AFStateChangedEventListener> afStateChangedListeners = new Vector<AFStateChangedEventListener>();

	private BasicResourceDescriptions basicResourceDescr = new BasicResourceDescriptions();
	private AgentDescriptions agentDescrs = new AgentDescriptions();

	/**
	 * Loads {@link AbstractComponentDescription}s from
	 * {@link ConfigurationDatabase}.
	 */
	public void loadDescriptions() {

		logger.info("Load component descriptions ...");

		loadBasicResourceDescrsFromFile();
		loadAgentDescrsFromFile();

		logDescriptions();
	}

	public void addOrUpdateAgentDescription(AgentDescription agentDescr) {
		boolean agentDescrsChanged = agentDescriptionsChanged(agentDescr);
		if (agentDescrsChanged) {
			agentDescrs.addOrUpdateDescription(agentDescr);
			File resourcesAgentsFile = ConfigurationDatabase
					.getResourcesAgentsFile();
			AgentDescriptionsXML
					.updateXMLFile(resourcesAgentsFile, agentDescrs);
		}
		notifyListenersAgentDescriptionAddedOrUpdated(agentDescr,
				agentDescrsChanged);
	}

	public void deleteAgentDescription(String agentID) {
		boolean agentDescrsChanged = agentDescrs.contains(agentID);
		if (agentDescrsChanged) {
			agentDescrs.removeDescription(agentID);
			File resourcesAgentsFile = ConfigurationDatabase
					.getResourcesAgentsFile();
			AgentDescriptionsXML
					.updateXMLFile(resourcesAgentsFile, agentDescrs);
		}
		notifyListenersAgentDescriptionDeleted(agentID, agentDescrsChanged);
	}

	public Set<String> getDataServiceDescriptionIDs() {
		return basicResourceDescr.getDataServiceDescriptionIDs();
	}

	public DataServiceDescription getDataServiceDescription(String id) {
		return basicResourceDescr.getDataServiceDescription(id);
	}

	public Set<String> getSessionModelDescriptionIDs() {
		return basicResourceDescr.getSessionModelDescriptionIDs();
	}

	public SessionModelDescription getSessionModelDescription(String id) {
		return basicResourceDescr.getSessionModelDescription(id);
	}

	public AgentDescriptions getAgentDescriptions() {
		return agentDescrs;
	}

	public Set<String> getAgentDescriptionIDs() {
		return agentDescrs.getAgentDescriptionIDs();
	}

	public AgentDescription getAgentDescription(String id) {
		return agentDescrs.getAgentDescription(id);
	}

	private void loadBasicResourceDescrsFromFile() {
		File basicResourcesFile = ConfigurationDatabase.getResourcesBasicFile();
		BasicResourceDescriptions brd = parseBasicResourceDescrs(basicResourcesFile);
		this.basicResourceDescr = brd;
	}

	private void loadAgentDescrsFromFile() {
		File agentsFile = ConfigurationDatabase.getResourcesAgentsFile();
		AgentDescriptions ad = parseAgentDescrs(agentsFile);
		this.agentDescrs = ad;
	}

	private BasicResourceDescriptions parseBasicResourceDescrs(File f) {
		try {
			Element rootElem = XMLUtil.file2xmlElem(f);
			BasicResourceDescriptions brd = BasicResourceDescriptionsXML
					.fromXML(rootElem);
			return brd;
		} catch (Exception e) {
			logger.error("Error in 'loadBasicResourceDescrs()'", e);
			return null;
		}
	}

	private AgentDescriptions parseAgentDescrs(File f) {
		try {
			Element rootElem = XMLUtil.file2xmlElem(f);
			AgentDescriptions ad = AgentDescriptionsXML.fromXML(rootElem);
			return ad;
		} catch (Exception e) {
			logger.error("Error in 'parseAgentDescrs()'", e);
			return null;
		}
	}

	private void logDescriptions() {
		logger.info("#### DataSevices ####");

		for (DataServiceDescription dsDescription : basicResourceDescr
				.getDataServiceDescriptions()) {
			logger.info(dsDescription.toString());
			IDataServiceConfiguration conf = dsDescription.getConfiguration();
			logger.info(" --- Conf: " + (conf == null ? null : conf.toString()));
		}

		logger.info("#### SessionModels ####");

		for (SessionModelDescription smDescription : basicResourceDescr
				.getSessionModelDescriptions()) {
			logger.info(smDescription.toString());
			ISessionModelConfiguration conf = smDescription.getConfiguration();
			logger.info(" --- Conf: " + (conf == null ? null : conf.toString()));
		}

		logger.info("#### Agents ####");

		for (AgentDescription agentDescription : agentDescrs
				.getAgentDescriptions()) {
			logger.info(agentDescription.toString());
			IAgentConfiguration conf = agentDescription.getConfiguration();
			logger.info(" --- Conf: " + (conf == null ? null : conf.toString()));
		}
	}

	private boolean agentDescriptionsChanged(AgentDescription newDescr) {
		AgentDescription oldDescr = agentDescrs.getAgentDescription(newDescr
				.getComponentID());
		if (oldDescr == null) {
			return true;
		}
		return fileAttributesChanged(oldDescr, newDescr);
	}

	private boolean fileAttributesChanged(AgentDescription oldDescr,
			AgentDescription newDescr) {
		BasicDescription oldBasic = oldDescr.getBasicDescr();
		BasicDescription newBasic = newDescr.getBasicDescr();
		if (!oldBasic.equals(newBasic)) {
			return true;
		}
		String oldDisplayName = oldDescr.getDisplayName();
		String newDisplayName = newDescr.getDisplayName();
		if (oldDisplayName != newDisplayName) {
			// at least one value is != null
			if (oldDisplayName == null || newDisplayName == null) {
				// one value null, the other not
				return true;
			}
			if (!oldDisplayName.equals(newDisplayName)) {
				return true;
			}
		}

		String oldDescription = oldDescr.getDescription();
		String newDescription = newDescr.getDescription();
		if (oldDescription != newDescription) {
			// at least one value is != null
			if (oldDescription == null || newDescription == null) {
				// one value null, the other not
				return true;
			}
			if (!oldDescription.equals(newDescription)) {
				return true;
			}
		}

		SupportedOntologiesDef oldOntology = oldDescr.getSupportedOntology();
		SupportedOntologiesDef newOntology = newDescr.getSupportedOntology();
		if (!oldOntology.equals(newOntology)) {
			return true;
		}

		boolean oldIsCompiled = oldDescr.isConfigCompiled();
		boolean newIsCompiled = newDescr.isConfigCompiled();
		if (oldIsCompiled != newIsCompiled) {
			return true;
		}

		boolean oldIsWritable = oldDescr.isConfigWritable();
		boolean newIsWritable = newDescr.isConfigWritable();
		if (oldIsWritable != newIsWritable) {
			return true;
		}

		boolean oldIsReadable = oldDescr.isConfigReadable();
		boolean newIsReadable = newDescr.isConfigReadable();
		if (oldIsReadable != newIsReadable) {
			return true;
		}

		return false;
	}

	public void addListener(AFStateChangedEventListener l) {
		afStateChangedListeners.add(l);
	}

	private void notifyListenersAgentDescriptionAddedOrUpdated(
			AgentDescription agentDescr, boolean agentDescrsChanged) {
		AgentDescriptionAddedOrUpdatedEvent aDescrsChangedEv = new AgentDescriptionAddedOrUpdatedEvent(
				getClass().toString());
		aDescrsChangedEv.setChanged(agentDescrsChanged);
		AgentDescriptionFE agentDescriptionFE = ObjectToFETranslator.translate(agentDescr);
		aDescrsChangedEv.setAgentDescr(agentDescriptionFE);
		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(aDescrsChangedEv);
		}
	}

	private void notifyListenersAgentDescriptionDeleted(String agentID,
			boolean agentDescrsChanged) {
		AgentDescriptionDeletedEvent aDescrsChangedEv = new AgentDescriptionDeletedEvent(
				getClass().toString());
		aDescrsChangedEv.setChanged(agentDescrsChanged);
		aDescrsChangedEv.setAgentID(agentID);
		for (AFStateChangedEventListener l : afStateChangedListeners) {
			l.onConfigChangedEvent(aDescrsChangedEv);
		}
	}
}
