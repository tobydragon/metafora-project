package de.dfki.lasad.session.data.meta.ontology;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class CreatorPropDescr extends StandardPropDescr {

	public CreatorPropDescr() {
		super("creator", null, "creator", JessDataType.STRING, ComparisonGroup.USER);
	}
}
