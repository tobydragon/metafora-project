package de.dfki.lasad.session.data;


/**
 * 
 * @author Oliver Scheuer
 *
 */
public class UserIDAll extends UserID {

	public UserIDAll() {
		super("ALL USERS");
	}
}
