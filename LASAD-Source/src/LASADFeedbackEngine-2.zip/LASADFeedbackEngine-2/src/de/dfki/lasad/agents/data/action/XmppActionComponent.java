package de.dfki.lasad.agents.data.action;

import de.dfki.lasad.agents.instances.xmpp.xmppaction.CfActionDuringExecution;
import de.uds.commonformat.CfAction;
import de.uds.commonformatparser.CfActionParser;

public class XmppActionComponent implements ActionComponent{
	
	public CfActionDuringExecution action;
	
	public CfActionDuringExecution getAction() {
		return action;
	}

	public XmppActionComponent(CfActionDuringExecution action) {
		super();
		this.action = action;
	}
	
	public XmppActionComponent(CfAction action) {
		super();
		this.action = CfActionDuringExecution.buildActionfromCf(action);
	}

	public static XmppActionComponent getTestableInstance() {
		return new XmppActionComponent(CfActionParser.getTestableInstance());
	}

}
