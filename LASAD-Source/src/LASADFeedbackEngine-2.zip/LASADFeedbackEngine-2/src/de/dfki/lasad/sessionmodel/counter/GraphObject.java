package de.dfki.lasad.sessionmodel.counter;

import java.util.HashSet;
import java.util.Set;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class GraphObject {

	String objectID;

	String type;
	String creator;
	Set<String> modifiers = new HashSet<String>();

	long firstTs;
	long lastTs;

	public String getObjectID() {
		return objectID;
	}

	public void setObjectID(String objectID) {
		this.objectID = objectID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public Set<String> getModifiers() {
		return modifiers;
	}

	public void setModifiers(Set<String> modifiers) {
		this.modifiers = modifiers;
	}

	public long getFirstTs() {
		return firstTs;
	}

	public void setFirstTs(long firstTs) {
		this.firstTs = firstTs;
	}

	public long getLastTs() {
		return lastTs;
	}

	public void setLastTs(long lastTs) {
		this.lastTs = lastTs;
	}

	@Override
	public String toString() {
		return "[" + objectID + "]";
	}

	public String toDetailedString() {
		return "[" + objectID + ": type=" + type + ", creator=" + creator
				+ ", modifiers=" + modifiers + ", firstTs=" + firstTs
				+ ", lastTs=" + lastTs + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((objectID == null) ? 0 : objectID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GraphObject other = (GraphObject) obj;
		if (objectID == null) {
			if (other.objectID != null)
				return false;
		} else if (!objectID.equals(other.objectID))
			return false;
		return true;
	}

}
