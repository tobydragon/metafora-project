package de.dfki.lasad.agents.logic.analysis.aggr;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceClass;
import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterAnalysisType;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterCriterionDef;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterCriterionOperator;
import lasad.shared.dfki.meta.agents.analysis.counter.CounterDef;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeGeneral;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeSpecific;
import lasad.shared.dfki.meta.agents.analysis.counter.InstanceTypeSpecific_Object;
import lasad.shared.dfki.meta.agents.analysis.counter.UserSelectionSetting;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.events.agents.AnalysisResultsChangedEventListener;

/**
 * Plug this class into {@link SessioModel} to test basic functionality.
 * 
 * @author oliverscheuer
 * 
 */
public class AggrServiceTest extends AggrService {

	private Log logger = LogFactory.getLog(AggrServiceTest.class);

	public AggrServiceTest(
			AnalysisResultsChangedEventListener resultsChangedListener,
			List<CounterAnalysisType> aggegrationTypes) {
		super(resultsChangedListener, aggegrationTypes);
		super.initAggregationType(getTestCounter1());
	}

	private CounterAnalysisType getTestCounter1() {

		List<InstanceTypeSpecific> relevantSpecificTypes = new Vector<InstanceTypeSpecific>();
		relevantSpecificTypes.add(new InstanceTypeSpecific_Object(
				"hypothetical"));

		CounterDef counterDef = new CounterDef(UserSelectionSetting.FOREACH,
				null, null, InstanceTypeGeneral.NODE, relevantSpecificTypes,
				null, 20);
		// null);
		CounterCriterionDef counterCriterion = new CounterCriterionDef(
				CounterCriterionOperator.GREATER_OR_EQUAL, 3);

		ServiceID id = new ServiceID("Counting-System", "Test-Counter-1",
				ServiceClass.ANALYSIS);
		CounterAnalysisType aType = new CounterAnalysisType(id, counterDef,
				counterCriterion);
		return aType;
	}

	@Override
	public void counterChanged(Counter changedCounter) {
		super.counterChanged(changedCounter);
		Set<UserCounterAnalysisType> dependentAnalysisTypes = counters2counterTypes
				.get(changedCounter);

		StringBuffer buf = new StringBuffer();
		buf.append("{");
		for (Iterator<UserCounterAnalysisType> iter = dependentAnalysisTypes
				.iterator(); iter.hasNext();) {
			UserCounterAnalysisType type = iter.next();
			buf.append(type.analysisType.getServiceID().getTypeID());
			buf.append(" (" + type.userID + ")");
			List<CounterCriterionDef> criteria = type.analysisType
					.getCounterCriteria();
			boolean conditionFulfilledNow = true;
			for (CounterCriterionDef criterion : criteria) {
				if (!criterion.isFulfilled(changedCounter.count)) {
					conditionFulfilledNow = false;
					break;
				}
			}
			boolean conditionFulfilledBefore = fulfilledCounterConditions
					.containsKey(type);
			String status = "";
			if (conditionFulfilledNow && conditionFulfilledBefore) {
				status = "[remains ACTIVE]";
			}
			if (conditionFulfilledNow && !conditionFulfilledBefore) {
				status = "[becomes ACTIVE]";
			}
			if (!conditionFulfilledNow && conditionFulfilledBefore) {
				status = "[becomes INACTIVE]";
			}
			if (!conditionFulfilledNow && !conditionFulfilledBefore) {
				status = "[remains INACTIVE]";
			}

			buf.append(" " + status);

			if (iter.hasNext()) {
				buf.append(", ");
			}
		}
		buf.append("}");
		logger.debug("Counter changed: " + changedCounter.count
				+ ". Dependent analysis types: " + buf.toString());
	}

	@Override
	public void checkConditionsAndNotify() {
		super.checkConditionsAndNotify();
	}

}
