package de.dfki.lasad.core.components.description;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class BasicDescription {

	public String id = null;
	public String classs = null;
	public String confclass = null;
	public String conffile = null;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((classs == null) ? 0 : classs.hashCode());
		result = prime * result
				+ ((confclass == null) ? 0 : confclass.hashCode());
		result = prime * result
				+ ((conffile == null) ? 0 : conffile.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BasicDescription other = (BasicDescription) obj;
		if (classs == null) {
			if (other.classs != null)
				return false;
		} else if (!classs.equals(other.classs))
			return false;
		if (confclass == null) {
			if (other.confclass != null)
				return false;
		} else if (!confclass.equals(other.confclass))
			return false;
		if (conffile == null) {
			if (other.conffile != null)
				return false;
		} else if (!conffile.equals(other.conffile))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
