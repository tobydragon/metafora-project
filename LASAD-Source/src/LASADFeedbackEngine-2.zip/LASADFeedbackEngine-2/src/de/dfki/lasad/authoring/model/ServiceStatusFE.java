package de.dfki.lasad.authoring.model;

/**
 * Runtime status of Feedback-Engine components (to be used in the graphical
 * frontend).
 * 
 * @author oliverscheuer
 * 
 */
public enum ServiceStatusFE {

	/**
	 * component not fully instantiated yet
	 */
	UNDER_CONSTRUCTION("UNDER_CONSTRUCTION"),

	/**
	 * component instantiated and ready to start services
	 */
	READY_TO_START("READY_TO_START"),

	/**
	 * component about to start
	 */
	STARTING("STARTING"),

	/**
	 * component is currently providing services
	 */
	RUNNING("RUNNING"),

	/**
	 * component about to stop
	 */
	STOPPING("STOPPING"),

	/**
	 * component is used up and cannot be used anymore
	 */
	STALE("STALE");

	private final String status;

	ServiceStatusFE(String status) {
		this.status = status;
	}
}
