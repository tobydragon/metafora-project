package de.dfki.lasad.core;

import java.util.List;
import java.util.Set;

import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.session.Session;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.meta.Ontology;
import junit.framework.TestCase;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ConfigurationManagerTest extends TestCase {

	public void testDescriptions() {
		System.out.println("#### testDescriptions() ####");
		ConfigurationManager confManager = new ConfigurationManager();
		confManager.loadConf();

		System.out.println("#### DataService Description ####");
		DataServiceDescription ds = confManager.getDSDescription();
		System.out.println(ds.toString());

		System.out.println("#### SessionModel Description ####");
		SessionModelDescription sm = confManager.getSessionModelDescription();
		System.out.println(sm.toString());

		System.out.println("#### Agents - Session '31' ####");
		Session s31 = new Session(new SessionID("31"));
		List<AgentDescription> agents31 = confManager
				.getSessionSpecificAgentDescriptions(s31);
		System.out.println(agents31.toString());

		System.out.println("#### Agents - Session 'argunaut' ####");
		Session sArgunaut = new Session(new SessionID("99"));
		sArgunaut.setOntology(new Ontology("argunaut"));
		List<AgentDescription> aArgunaut = confManager
				.getSessionSpecificAgentDescriptions(sArgunaut);
		System.out.println(aArgunaut.toString());
	}
}
