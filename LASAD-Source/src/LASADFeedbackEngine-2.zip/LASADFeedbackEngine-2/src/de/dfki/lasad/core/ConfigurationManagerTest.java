package de.dfki.lasad.core;

import java.util.List;

import junit.framework.TestCase;
import lasad.shared.dfki.meta.ontology.Ontology;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.DataServiceDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.session.Session;
import de.dfki.lasad.session.data.SessionID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ConfigurationManagerTest extends TestCase {

	public static final String ONTOLOGY_ID = "LARGO";
	public static final String SESSION_ID = "31";
	
	public void testGetBasicResourceDescriptions() {
		System.out.println("#### testGetBasicResourceDescriptions() ####");
		ConfigurationManager confManager = getConfManagerAndLoadConfig();

		System.out.println("#### DataService Description ####");
		DataServiceDescription ds = confManager.getDSDescription();
		System.out.println(ds.toString());

		System.out.println("#### SessionModel Description ####");
		SessionModelDescription sm = confManager.getSessionModelDescription();
		System.out.println(sm.toString());

	}

	public void testGetAgentDescriptionsForSession() {
		System.out.println("#### Agents - Session '" + SESSION_ID +"' ####");
		ConfigurationManager confManager = getConfManagerAndLoadConfig();
		Session s = new Session(new SessionID(SESSION_ID));
		List<AgentDescription> agents = confManager
				.getSessionSpecificAgentDescriptions(s);
		System.out.println(agents.toString());
	}

	public void testGetAgentDescriptionsForOntology() {
		System.out.println("#### Agents - Session '" + ONTOLOGY_ID + "' ####");
		ConfigurationManager confManager = getConfManagerAndLoadConfig();
		Session s = new Session(new SessionID("XXX"));
		s.setOntology(new Ontology(ONTOLOGY_ID));
		List<AgentDescription> as = confManager
				.getSessionSpecificAgentDescriptions(s);
		System.out.println(as.toString());
	}

	private ConfigurationManager getConfManagerAndLoadConfig() {
		ConfigurationManager confManager = new ConfigurationManager();
		confManager.loadConf();
		return confManager;
	}
}
