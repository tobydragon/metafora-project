package de.dfki.lasad.authoring.model.pattern;

/**
 * (see {@link ElementConstr})
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class LinkConstr extends ElementConstr {

	private ElementVariable source;
	private ElementVariable target;
	private boolean undefinedDirection;

	public ElementVariable getSource() {
		return source;
	}

	public void setSource(ElementVariable source) {
		this.source = source;
	}

	public ElementVariable getTarget() {
		return target;
	}

	public void setTarget(ElementVariable target) {
		this.target = target;
	}

	public boolean isUndefinedDirection() {
		return undefinedDirection;
	}

	public void setUndefinedDirection(boolean undefinedDirection) {
		this.undefinedDirection = undefinedDirection;
	}

}
