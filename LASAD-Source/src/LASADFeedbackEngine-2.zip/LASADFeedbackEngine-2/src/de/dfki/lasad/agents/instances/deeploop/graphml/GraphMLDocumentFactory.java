package de.dfki.lasad.agents.instances.deeploop.graphml;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xmlbeans.XmlObject;
import org.graphdrawing.graphml.xmlns.x1.DataType;
import org.graphdrawing.graphml.xmlns.x1.EdgeType;
import org.graphdrawing.graphml.xmlns.x1.GraphType;
import org.graphdrawing.graphml.xmlns.x1.GraphmlDocument;
import org.graphdrawing.graphml.xmlns.x1.GraphmlType;
import org.graphdrawing.graphml.xmlns.x1.NodeType;

import de.dfki.lasad.agents.instances.deeploop.preprocessing.FlatGraphModeler;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.objects.EUEObjectID;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;
import de.dfki.lasad.session.data.objects.ObjectProperty;

/**
 * 
 * @author Oliver Scheuer, Muhammad Zeshan Afzal
 * 
 */
public class GraphMLDocumentFactory {

	private static Log logger = LogFactory.getLog(GraphMLDocumentFactory.class);

	public static GraphmlDocument fillGML(SessionID sessionID,
			FlatGraphModeler model) {
		GraphmlDocument doc = GraphmlDocument.Factory.newInstance();
		GraphmlType graphml = doc.addNewGraphml();
		GraphType graphtype = graphml.addNewGraph();
		graphtype.setId(sessionID.getIdAsString());

		for (Node modelNode : model.getNodes()) {
			NodeType graphmlNode = graphtype.addNewNode();

			graphmlNode.setId(modelNode.getID().getIdAsString());

			addProp(graphmlNode, GraphMLVocabulary.NODE_TYPE, modelNode
					.getType());

			for (String propName : modelNode.getProps().keySet()) {
				// we assume: property names and values have already been mapped
				// in an appropriate way such that they can be handled by Deep
				// Loop.
				ObjectProperty property = modelNode.getProps().get(propName);
				addProp(graphmlNode, property.getName(), property
						.getValueAsString());
			}
		}

		for (Link modelLink : model.getLinks()) {
			EdgeType graphmlLink = graphtype.addNewEdge();

			graphmlLink.setId(modelLink.getID().getIdAsString());
			addProp(graphmlLink, GraphMLVocabulary.LINK_TYPE, modelLink
					.getType());

			// add link source
			if (checkLinkSource(modelLink)) {
				EUEObjectID sourceID = modelLink.getSources().get(0);
				graphmlLink.setSource(sourceID.getIdAsString());
			}

			// add link target
			if (checkLinkTarget(modelLink)) {
				EUEObjectID targetID = modelLink.getTargets().get(0);
				graphmlLink.setTarget(targetID.getIdAsString());
			}

			for (String propName : modelLink.getProps().keySet()) {
				// we assume: property names and values have already been mapped
				// in an appropriate way such that they can be handled by Deep
				// Loop.
				ObjectProperty property = modelLink.getProps().get(propName);
				addProp(graphmlLink, property.getName(), property
						.getValueAsString());
			}

		}
		//doc = (new HUJIDataProvider()).getGraphML(); 
		logger.info(doc);
		return doc;
	}

	private static void addProp(XmlObject nodeOrEdge, String key, Object value) {
		DataType data;
		if (nodeOrEdge instanceof NodeType) {
			data = ((NodeType) nodeOrEdge).addNewData();
		} else {
			// assume: EdgeType
			data = ((EdgeType) nodeOrEdge).addNewData();
		}

		data.setKey(key);
		org.w3c.dom.Node n = data.getDomNode().getOwnerDocument()
				.createTextNode(value.toString());
		data.getDomNode().appendChild(n);
	}

	/**
	 * 
	 * @return is node compatible with Deep Loop service?
	 */
	private static boolean checkNodeProperties(Node modelNode) {

		if (modelNode.getID() == null) {
			logger.error("Node without ID: " + modelNode);
			return false;
		}

		if (modelNode.getType() == null) {
			logger.error("Node without type: " + modelNode);
			return false;
		}

		List<String> requiredPropNames = new Vector<String>();
		requiredPropNames.add(GraphMLVocabulary.NODE_TITLE);
		requiredPropNames.add(GraphMLVocabulary.NODE_CONTENT);
		requiredPropNames.add(GraphMLVocabulary.NODE_CREATOR);
		requiredPropNames.add(GraphMLVocabulary.NODE_FIRST_MODIFICATIONDATE);

		Set<String> propNames = modelNode.getProps().keySet();
		for (String requiredProp : requiredPropNames) {
			if (!propNames.contains(requiredProp)) {
				logger.error("Property '" + requiredProp
						+ "' not defined for node '"
						+ modelNode.getID().getIdAsString() + "'.");
				return false;
			}
		}
		return true;
	}

	/**
	 * 
	 * @return is link compatible with Deep Loop service?
	 */
	private static boolean checkLinkProperties(Link modelLink) {
		if (modelLink.getID() == null) {
			logger.error("Link without ID: " + modelLink);
			return false;
		}

		if (!checkLinkSource(modelLink)) {
			return false;
		}

		if (!checkLinkTarget(modelLink)) {
			return false;
		}

		List<String> requiredPropNames = new Vector<String>();
		requiredPropNames.add(GraphMLVocabulary.LINK_TYPE);
		requiredPropNames.add(GraphMLVocabulary.LINK_CREATOR);
		requiredPropNames.add(GraphMLVocabulary.LINK_CREATIONDATE);

		Set<String> propNames = modelLink.getProps().keySet();
		for (String requiredProp : requiredPropNames) {
			if (!propNames.contains(requiredProp)) {
				logger.error("Property '" + requiredProp
						+ "' not defined for link '"
						+ modelLink.getID().getIdAsString() + "'.");
				return false;
			}
		}
		return true;
	}

	private static boolean checkLinkSource(Link modelLink) {
		if (modelLink.getSources().size() == 1) {
			return true;
		} else {
			if (modelLink.getSources().size() > 1) {
				logger.error("Link '" + modelLink.getID()
						+ "' has more than 1 source: "
						+ Arrays.toString(modelLink.getSources().toArray())
						+ ".");
			} else {
				// 0 sources
				logger.error("Link '" + modelLink.getID()
						+ "' has no source element defined.");
			}
			return false;
		}
	}

	private static boolean checkLinkTarget(Link modelLink) {
		if (modelLink.getTargets().size() == 1) {
			return true;
		} else {
			if (modelLink.getTargets().size() > 1) {
				logger.error("Link '" + modelLink.getID()
						+ "' has more than 1 target: "
						+ Arrays.toString(modelLink.getTargets().toArray())
						+ ".");
			} else {
				// 0 targets
				logger.error("Link '" + modelLink.getID()
						+ "' has no target element defined.");
			}
			return false;
		}
	}

}
