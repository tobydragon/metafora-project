package de.dfki.lasad.dataservice.lasad.xml;

import java.util.List;

import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.ActionPackage;
import lasad.shared.communication.objects.Parameter;

import de.uds.xml.XmlFragment;
import de.uds.xml.XmlFragmentInterface;

public class ActionPackageXmlConverter {
	
	public static XmlFragmentInterface toXml(ActionPackage actionPackage){
		XmlFragmentInterface xmlFragment = new XmlFragment("ActionPackage");
		for (Action action : actionPackage.getActions()){
			xmlFragment.addContent(ActionXmlConverter.toXml(action));
		}
		for (Parameter parameter :actionPackage.getParameters()){
			xmlFragment.addContent(ParameterXmlConverter.toXml(parameter));
		}
		return xmlFragment;
	}
	
	public static ActionPackage createFromXml(XmlFragment fragment){
		ActionPackage actionPackage = new ActionPackage();
		List<XmlFragmentInterface> children = fragment.getChildren("Action");
		for (XmlFragmentInterface actionElement : children){
			Action a = ActionXmlConverter.fromXml((XmlFragment)actionElement);
			if (a != null){
				actionPackage.addAction(a);
			}
		}
		for (XmlFragmentInterface paramElement : fragment.getChildren("Parameter")){
			Parameter p = ParameterXmlConverter.fromXml((XmlFragment)paramElement);
			if (p != null){
				actionPackage.addParameter(p.getType(), p.getValue());
			}	
		}
		return actionPackage;
	}

}
