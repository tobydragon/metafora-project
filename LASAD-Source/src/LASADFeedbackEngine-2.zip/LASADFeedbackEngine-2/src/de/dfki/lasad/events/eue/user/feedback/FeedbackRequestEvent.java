package de.dfki.lasad.events.eue.user.feedback;

import de.dfki.lasad.events.eue.EUEEventID;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.UserID;

/**
 * Event describing a user feedback request action within an EUE session
 * 
 * @author oliverscheuer
 * 
 */
public class FeedbackRequestEvent extends UserEvent {

	private FeedbackRequestSpec feedbackRequestSpec;

	public FeedbackRequestEvent(FeedbackRequestSpec feedbackRequestSpec,
			SessionID sessionID, String srcCompId, EUEEventID eueEventID,
			UserID userID) {
		super(sessionID, srcCompId, eueEventID, userID);
		this.feedbackRequestSpec = feedbackRequestSpec;
	}

	public FeedbackRequestSpec getFeedbackRequestSpec() {
		return feedbackRequestSpec;
	}

	@Override
	public String toString() {
		return super.toString() + ", feedbackRequestSpec="
				+ feedbackRequestSpec;
	}

}
