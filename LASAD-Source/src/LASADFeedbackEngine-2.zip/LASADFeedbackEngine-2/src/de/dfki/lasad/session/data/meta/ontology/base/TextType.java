package de.dfki.lasad.session.data.meta.ontology.base;

import de.dfki.lasad.session.data.meta.ontology.ComparisonGroup;
import de.dfki.lasad.session.data.meta.ontology.JessDataType;
import de.dfki.lasad.session.data.meta.ontology.PropDescr;

/**
 * 
 * @author oliverscheuer
 *
 */
public class TextType extends BaseType {

	private static TextType instance = new TextType();
	
	private TextType(){
		super();
		lasadElementType = "text";
		jessTemplateName = "elem_text";
		addComponentSpecification(PropDescr.DEFAULT_COMPONENT_ID, "TEXT", JessDataType.STRING, ComparisonGroup.TEXT);
	}
	
	public static TextType getInstance(){
		return instance;
	}
}