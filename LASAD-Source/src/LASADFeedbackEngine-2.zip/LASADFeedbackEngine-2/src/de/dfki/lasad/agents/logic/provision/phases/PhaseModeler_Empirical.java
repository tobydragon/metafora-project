package de.dfki.lasad.agents.logic.provision.phases;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.action.ActionType;
import lasad.shared.dfki.meta.agents.action.feedback.FeedbackActionType;
import lasad.shared.dfki.meta.agents.analysis.phases.PhaseDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.data.analysis.ActionTypeResult;
import de.dfki.lasad.agents.data.analysis.AnalysisResult;
import de.dfki.lasad.sessionmodel.SessionModelChangeRecord;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class PhaseModeler_Empirical extends PhaseModeler {

	private static Log logger = LogFactory.getLog(PhaseModeler_Empirical.class);

	private Set<ActionType> actionTypes = new HashSet<ActionType>();
	private Map<ServiceID, Set<ActionType>> analysisType2dependentActionTypes = new HashMap<ServiceID, Set<ActionType>>();

	private Map<Integer, AnalysisResult> modeledResults = new HashMap<Integer, AnalysisResult>();

	private Map<String, Set<ActionType>> phases2actionTypes = new HashMap<String, Set<ActionType>>();
	private Map<String, Map<ActionType, Integer>> phases2actionTypes2ResultCount = new HashMap<String, Map<ActionType, Integer>>();

	private boolean probsUptodate = true;
	private Map<String, Double> phases2aggregateActual = new HashMap<String, Double>();
	private Map<String, Double> phases2aggregateMax = new HashMap<String, Double>();
	private Map<String, Double> phases2aggregateNormalizedByMax = new HashMap<String, Double>();

	PhaseModeler_Empirical(List<PhaseDef> phases,
			List<ActionType> relevantActionTypes) {
		this.phaseModel = new PhaseModel(phases);
		for (ActionType actionType : relevantActionTypes) {
			addActionType(actionType);
		}
		init();
	}

	/**
	 * 
	 * Updates internal pattern counts (will be used to determine phase
	 * probabilities)
	 * 
	 */
	public void processModelChanged(SessionModelChangeRecord changeRecord) {
		probsUptodate = false;
		for (AnalysisResult result : changeRecord.getAddedOrModifiedResults()) {
			modeledResults.put(result.getId(), result);
			ServiceID analysisID = result.getAnalysisType().getServiceID();
			Set<ActionType> dependentTypes = analysisType2dependentActionTypes
					.get(analysisID);
			if (dependentTypes != null) {
				for (ActionType type : dependentTypes) {
					ActionTypeResult actionResult = new ActionTypeResult(type,
							result);
					update(actionResult, false);
				}
			}
		}

		for (Integer resultID : changeRecord.getRemovedResultsIDs()) {
			AnalysisResult result = modeledResults.remove(resultID);
			ServiceID analysisID = result.getAnalysisType().getServiceID();
			Set<ActionType> dependentTypes = analysisType2dependentActionTypes
					.get(analysisID);
			if (dependentTypes != null) {
				for (ActionType type : dependentTypes) {
					ActionTypeResult actionResult = new ActionTypeResult(type,
							result);
					update(actionResult, true);
				}
			}
		}
		// logger.debug("PHASE MODEL (AFTER processModelChanged - probabilities not updated yet.)");
		// printModel();
		updatePhaseProbabilitiesIfNeeded();
	}

	protected void addActionType(ActionType actionType) {
		if (actionType instanceof FeedbackActionType) {
			FeedbackActionType fType = (FeedbackActionType) actionType;
			this.actionTypes.add(fType);

			ServiceID triggerID = fType.getTriggerID();
			Set<ActionType> actionTypesForTrigger = analysisType2dependentActionTypes
					.get(triggerID);
			if (actionTypesForTrigger == null) {
				actionTypesForTrigger = new HashSet<ActionType>();
				analysisType2dependentActionTypes.put(triggerID,
						actionTypesForTrigger);
			}
			actionTypesForTrigger.add(fType);
		}
	}

	protected void init() {
		for (Phase p : phaseModel.getPhasesInDefinitionOrder()) {
			String phaseID = p.getPhaseID();
			phases2aggregateMax.put(phaseID, 0.0);
			phases2aggregateActual.put(phaseID, 0.0);
			phases2aggregateNormalizedByMax.put(phaseID, 0.0);
			phases2actionTypes.put(phaseID, new HashSet<ActionType>());
			phases2actionTypes2ResultCount.put(phaseID,
					new HashMap<ActionType, Integer>());
		}

		// computing for each phase the max possible value
		for (ActionType aType : actionTypes) {

			for (Phase p : phaseModel.getPhasesInDefinitionOrder()) {
				String phaseID = p.getPhaseID();
				double representativeness = aType.getPriorityDef()
						.getRepresentativeness(phaseID);
				if (representativeness != 0) {
					phases2actionTypes.get(phaseID).add(aType);
					phases2actionTypes2ResultCount.get(phaseID).put(aType, 0);
				}
				double aggregateOld = phases2aggregateMax.get(phaseID);
				double aggregateNew = aggregateOld + representativeness;
				phases2aggregateMax.put(phaseID, aggregateNew);
			}
		}
	}

	@Override
	public void updatePhaseProbabilitiesIfNeeded() {
		if (probsUptodate) {
			return;
		}
		Map<String, Double> phase2ScoreNormalized = new HashMap<String, Double>();
		double phaseScoresSum = 0;
		for (Phase phase : phaseModel.getPhasesInDefinitionOrder()) {
			String phaseID = phase.getPhaseID();
			// phaseScoresSum += phases2aggregateNormalizedByMax.get(phaseID);
			phaseScoresSum += phases2aggregateActual.get(phaseID);
		}
		for (Phase phase : phaseModel.getPhasesInDefinitionOrder()) {
			String phaseID = phase.getPhaseID();
			// double phaseScoreSumNormalized = (phases2aggregateNormalizedByMax
			// .get(phaseID) / phaseScoresSum);
			double phaseScoresSumNormalized = (phases2aggregateActual
					.get(phaseID) / phaseScoresSum);
			phase2ScoreNormalized.put(phaseID, phaseScoresSumNormalized);
		}
		phaseModel.updateProbabilities(phase2ScoreNormalized);
		probsUptodate = true;
		logger.debug("PHASE MODEL (AFTER updateProbabilities)");
		printModel();
	}

	private void update(ActionTypeResult result, boolean retracted) {

		ActionType aType = result.getActionType();
		for (Phase phase : phaseModel.getPhasesInDefinitionOrder()) {
			String phaseID = phase.phaseID;
			if (phases2actionTypes.get(phaseID).contains(aType)) {
				// relevant type
				int prevCount = phases2actionTypes2ResultCount.get(phaseID)
						.get(aType);
				if (retracted) {
					if (prevCount == 1) {
						updateScore(phaseID, (-1 * aType.getPriorityDef()
								.getRepresentativeness(phaseID)));
					}
					phases2actionTypes2ResultCount.get(phaseID).put(aType,
							prevCount - 1);

				} else {
					if (prevCount == 0) {
						updateScore(phaseID,
								(aType.getPriorityDef()
										.getRepresentativeness(phaseID)));
					}
					phases2actionTypes2ResultCount.get(phaseID).put(aType,
							prevCount + 1);
				}

			}
		}
	}

	private void updateScore(String phaseID, double change) {
		double newScoreActual = phases2aggregateActual.get(phaseID) + change;
		phases2aggregateActual.put(phaseID, newScoreActual);

		double scoreMax = phases2aggregateMax.get(phaseID);
		phases2aggregateNormalizedByMax.put(phaseID, newScoreActual / scoreMax);
	}

	private void printModel() {
		for (Phase p : phaseModel.getPhasesInDefinitionOrder()) {
			String pID = p.getPhaseID();
			double aggrScore = phases2aggregateActual.get(pID);
			double aggrScoreMax = phases2aggregateMax.get(pID);
			double aggrScoreNormalized = phases2aggregateNormalizedByMax
					.get(pID);
			double probability = p.getProbability();
			List<ServiceID> detectedPatterns = new Vector<ServiceID>();
			Map<ActionType, Integer> actionType2Count = phases2actionTypes2ResultCount
					.get(pID);
			for (ActionType actionType : actionType2Count.keySet()) {
				int count = actionType2Count.get(actionType);
				if (count > 0) {
					detectedPatterns.add(actionType.getServiceID());
				}
			}
			logger.debug(pID + ": abs_score(actual)=" + aggrScore
					+ ", abs_score(max)=" + aggrScoreMax + ", rel_score="
					+ Math.round((100 * aggrScoreNormalized)) + ", prob="
					+ Math.round(100 * probability) + ", patterns: "
					+ detectedPatterns);
		}

		logger.debug("Most likely phase: " + phaseModel.getMostLikelyPhase());
	}
}
