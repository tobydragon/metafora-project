package de.dfki.lasad.agents.logic.analysis.types.structure.translator.facts;

import lasad.shared.dfki.meta.ontology.Ontology;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.Indent;
import de.dfki.lasad.agents.logic.analysis.types.structure.translator.JessIDAndSlotNameGenerator;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ConstFactGen {

	protected JessIDAndSlotNameGenerator idGen;

	// in
	private String agentID;
	private String patternID;
	private int constNumID;

	public ConstFactGen(JessIDAndSlotNameGenerator idGen, String agentID,
			String patternID, int constNumID) {
		this.idGen = idGen;
		this.agentID = agentID;
		this.patternID = patternID;
		this.constNumID = constNumID;
	}

	public String getString() {
		StringBuffer buf = new StringBuffer();

		String constantFactID = idGen.generateConstantFactID(agentID,
				patternID, constNumID);
		String idSlot = "(id \"" + constantFactID + "\")";

		String constantValueVar = idGen
				.generateConstantFactValueTempVar(constNumID);
		String valuesSlot = "(values $? " + constantValueVar + " $?)";

		buf.append("(constant-set");
		buf.append("\n");
		buf.append(Indent.apply(idSlot, Indentations.INDENT_CONSTSET));
		buf.append("\n");
		buf.append(Indent.apply(valuesSlot, Indentations.INDENT_CONSTSET));
		buf.append(")");
		return buf.toString();
	}
}
