package de.dfki.lasad.session.data.meta.ontology;

/**
 * (see {@link ElementDescr})
 * 
 * @author oliverscheuer
 * 
 */
public class LinkDescr extends ElementDescr {

	public LinkDescr(String elemTypeID) {
		super(elemTypeID);
	}
}
