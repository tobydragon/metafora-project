package de.dfki.lasad.events.agents;

import java.util.HashSet;
import java.util.Set;

import de.dfki.lasad.agents.data.action.AgentAction;
import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.session.data.SessionID;

/**
 * Specification of {@link AgentAction}s to be executed in the EUE.
 * 
 * @author oliverscheuer
 * 
 */
public class ActionSpecEvent extends SessionEvent {

	private Set<AgentAction> actionSpecs = new HashSet<AgentAction>();

	public ActionSpecEvent(Set<AgentAction> actionSpecs, SessionID sessionID,
			String srcCompId) {
		super(sessionID, srcCompId);
		this.actionSpecs = actionSpecs;
	}

	public ActionSpecEvent(AgentAction actionSpec, SessionID sessionID,
			String srcCompId) {
		super(sessionID, srcCompId);
		actionSpecs = new HashSet<AgentAction>();
		actionSpecs.add(actionSpec);
	}

	public ActionSpecEvent(SessionID sessionID, String srcCompId) {
		super(sessionID, srcCompId);
		actionSpecs = new HashSet<AgentAction>();
	}

	@Override
	public String toString() {
		return super.toString() + ", actionSpec=" + actionSpecs.toString();
	}

	public Set<AgentAction> getAgentActions() {
		return actionSpecs;
	}

	public void addActionSpec(AgentAction aSpec) {
		actionSpecs.add(aSpec);
	}
}
