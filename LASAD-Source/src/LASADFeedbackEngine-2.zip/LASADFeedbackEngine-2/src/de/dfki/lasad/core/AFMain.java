package de.dfki.lasad.core;

/**
 * Application starting point
 * 
 * @author oliverscheuer
 * 
 */
public class AFMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AppBuilder appBuilder = new AppBuilder();
		appBuilder.doWireAndStart();
	}

}
