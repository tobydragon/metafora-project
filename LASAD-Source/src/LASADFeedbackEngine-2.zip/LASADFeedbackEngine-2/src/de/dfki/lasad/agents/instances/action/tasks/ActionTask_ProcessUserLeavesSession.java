package de.dfki.lasad.agents.instances.action.tasks;

import de.dfki.lasad.agents.instances.action.ActionAgent;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 *
 */
public class ActionTask_ProcessUserLeavesSession extends ActionTask {

	private ActionAgent agent = null;
	private UserID userID = null;

	public ActionTask_ProcessUserLeavesSession(ActionAgent agent, UserID userID) {
		this.agent = agent;
		this.userID = userID;
	}
	
	@Override
	public void run() {
		agent.processUserLeavesSession(userID);
	}

}
