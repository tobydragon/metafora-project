package de.dfki.lasad.agents.logic.analysis.aggr.tasks;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.aggr.AggrService;
import de.dfki.lasad.agents.logic.analysis.aggr.AggrServiceFactory;
import de.dfki.lasad.agents.logic.analysis.aggr.CountableInstance;
import de.dfki.lasad.agents.logic.analysis.aggr.Counter;

/**
 * Updates the {@link #counter} state, based on the given instance, and triggers
 * the {@link #manager} to check all counter conditions if the an analysis is
 * currently NOT running. (If an analysis IS running counter conditions will be
 * checked anyway when the analysis run is finished.)
 * 
 * @author oliverscheuer
 * 
 */
public class AggTask_CounterRecheckInstance extends AggTask {

	private static Log logger = LogFactory
			.getLog(AggTask_CounterRecheckInstance.class);

	AggrService manager;
	Counter counter;
	CountableInstance instance;

	public AggTask_CounterRecheckInstance(AggrService manager, Counter counter,
			CountableInstance instance) {
		this.manager = manager;
		this.counter = counter;
		this.instance = instance;
	}

	@Override
	public void run() {
		logger.debug("Re-check instance");
		counter.updateCounter(instance, false);
		manager.checkConditionsAndNotify();
	}

}
