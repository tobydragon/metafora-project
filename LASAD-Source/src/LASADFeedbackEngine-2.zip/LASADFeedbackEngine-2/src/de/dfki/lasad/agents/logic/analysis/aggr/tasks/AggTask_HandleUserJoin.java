package de.dfki.lasad.agents.logic.analysis.aggr.tasks;

import java.util.List;

import lasad.shared.dfki.meta.agents.analysis.counter.CounterAnalysisType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.logic.analysis.aggr.AggrService;
import de.dfki.lasad.session.data.UserID;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AggTask_HandleUserJoin extends AggTask {

	private static Log logger = LogFactory.getLog(AggTask_HandleUserJoin.class);

	private AggrService manager;
	private UserID userID;

	public AggTask_HandleUserJoin(AggrService manager, UserID userID) {
		this.manager = manager;
		this.userID = userID;
	}

	@Override
	public void run() {
		logger.debug("Handle user join");
		if (manager.getUsers().contains(userID)) {
			// ignore: user joined session already some time before
		} else {
			manager.getUsers().add(userID);
			List<CounterAnalysisType> oneUserCounterTypes = manager
					.getDecomposedAnalysisTypesForNewUser(userID);
			for (CounterAnalysisType oneUserCounterType : oneUserCounterTypes) {
				manager.registerCounterAnalysisTypeDecomposed(oneUserCounterType);
			}
			manager.checkConditionsAndNotify();
		}
	}

}
