package de.dfki.lasad.session;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import de.dfki.lasad.agents.data.meta.ActionType;
import de.dfki.lasad.agents.data.meta.AnalysisType;
import de.dfki.lasad.agents.data.meta.ServiceType;
import de.dfki.lasad.core.RuntimeConfigManager;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.core.components.description.SessionModelDescription;
import de.dfki.lasad.core.components.instance.IAgent;
import de.dfki.lasad.core.components.instance.ISessionModel;
import de.dfki.lasad.events.EventImpl;
import de.dfki.lasad.session.data.SessionID;
import de.dfki.lasad.session.data.meta.Ontology;
import de.dfki.lasad.session.data.meta.ToolContext;
import de.dfki.lasad.sessionmodel.SessionModel;

/**
 * Comprises all components ({@link ISessionModel} and {@link IAgent}s) that
 * have been initialized and attached to a specific session, as well as
 * information about the {@link Session} itself (ID, {@link Ontology} and
 * {@link ToolContext}).
 * 
 * <br/>
 * <br/>
 * <b>NOTE:</b> The {@link SessionActiveRuntime} does not necessarily correspond
 * to configured runtime, see notes in {@link RuntimeConfigManager}.
 * 
 * @author oliverscheuer
 * 
 */
public class SessionActiveRuntime {

	private SessionID sID = null;
	private Ontology ontology = null;
	private ToolContext tools = null;

	private SessionModelDescription modelDescription = null;
	private ISessionModel model = null;
	private Map<String, AgentDescription> agentDescriptions = new HashMap<String, AgentDescription>();
	private Map<String, IAgent> agents = new HashMap<String, IAgent>();

	// needed to delete feedback menu items again when shutting down the service
	private Set<String> feedbackMenuItemIDs = new HashSet<String>();

	public SessionActiveRuntime(SessionID sID, Ontology o, ToolContext tc) {
		this.sID = sID;
		this.ontology = o;
		this.tools = tc;
	}

	public void addAgentDescription(AgentDescription aDescr) {
		this.agentDescriptions.put(aDescr.getComponentID(), aDescr);
	}

	public void addAgentDescriptions(Collection<AgentDescription> aDescrs) {
		for (AgentDescription aDescr : aDescrs) {
			addAgentDescription(aDescr);
		}
	}

	public void setModelDescription(SessionModelDescription mDescr) {
		this.modelDescription = mDescr;
	}

	public void addAgent(IAgent a) {
		this.agents.put(a.getComponentID(), a);
	}

	public void setModel(ISessionModel sm) {
		this.model = sm;
	}

	public void clear() {
		modelDescription = null;
		model = null;
		agentDescriptions.clear();
		agents.clear();
		feedbackMenuItemIDs.clear();
	}

	public Collection<IAgent> getAgents() {
		return agents.values();
	}

	public ISessionModel getModel() {
		return model;
	}

	public void onEvent(EventImpl event) {
		// TD: update the model before the agents have access
		// In the future, we might want the agents to add facts before the model
		// is updated,
		// requiring this to be changed again.
		if (model != null) {
			model.onEvent(event);
		}
		for (IAgent agent : agents.values()) {
			agent.onEvent(event);
		}
	}

	public SessionID getSessionID() {
		return sID;
	}

	public Ontology getOntology() {
		return ontology;
	}

	public ToolContext getTools() {
		return tools;
	}

	public SessionModelDescription getModelDescription() {
		return modelDescription;
	}

	public Map<String, AgentDescription> getAgentDescriptions() {
		return agentDescriptions;
	}

	public List<ServiceType> getServicesToPublish() {
		List<ServiceType> result = new Vector<ServiceType>();
		for (IAgent agent : agents.values()) {
			result.addAll(agent.getTypesToPublish());
		}
		return result;
	}

	public AnalysisType getAnalysisType(String agentID, String typeID) {
		AgentDescription aDescr = agentDescriptions.get(agentID);
		return aDescr.getAnalysisType(typeID);
	}

	public ActionType getActionType(String agentID, String typeID) {
		AgentDescription aDescr = agentDescriptions.get(agentID);
		return aDescr.getActionType(typeID);
	}
}
