package de.dfki.lasad.util.threads;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class Signal {

	static Log logger = LogFactory.getLog(Signal.class);
	
	MonitorObject monitorObject = new MonitorObject();
	boolean signal = false;

	public void waitForSignal(boolean signal) {
		synchronized (monitorObject) {
			while (this.signal != signal) {
				try {
					monitorObject.wait();
				} catch (InterruptedException e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
	}

	public void signalGo() {
		synchronized (monitorObject) {
			signal = true;
			monitorObject.notifyAll();
		}
	}
	
	public void signalStop() {
		synchronized (monitorObject) {
			signal = false;
			monitorObject.notifyAll();
		}
	}

}
