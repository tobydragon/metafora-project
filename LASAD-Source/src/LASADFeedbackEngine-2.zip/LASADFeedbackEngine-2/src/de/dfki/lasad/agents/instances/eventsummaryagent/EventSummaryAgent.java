package de.dfki.lasad.agents.instances.eventsummaryagent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.AbstractAgent;
import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.components.description.AbstractComponentDescription;
import de.dfki.lasad.core.components.description.AgentDescription;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.AnalysisResultsProvisionEvent;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.events.eue.user.join.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.user.join.UserLeaveSessionEvent;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.DeleteObjectEvent;
import de.dfki.lasad.events.eue.user.object.FocusObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.SessionConfig;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;
import de.dfki.lasad.sessionmodel.graphmodel.GraphElement;
import de.uds.cfcommunication.CfMultiSessionCommunicationManager;
import de.uds.cfcommunication.CommunicationChannelType;
import de.uds.cfcommunication.CommunicationMethodType;
import de.uds.commonformat.CfAction;
import de.uds.translator.CfActionTranslatorConfig;
import de.uds.translator.CfObjectTranslatorConfig;
import de.uds.translator.EueToCfActionTranslator;
import de.uds.util.GeneralUtil;

public class EventSummaryAgent extends AbstractAgent {
	Log logger = LogFactory.getLog(this.getClass());

	CfMultiSessionCommunicationManager communicationManager;
	EueToCfActionTranslator translator;

	public EventSummaryAgent() {
		communicationManager = CfMultiSessionCommunicationManager.getInstance(CommunicationMethodType.xmpp, CommunicationChannelType.analysis);
		
	}
	
	@Override
	public void init(AbstractComponentDescription description,SessionConfig sessionConfig) throws ComponentInitException {
		super.init(description, sessionConfig);
		
		//ontology is not available until SessionConfig is parsed
		CfActionTranslatorConfig cfActionTranslatorConfig = new CfActionTranslatorConfig("conf/metafora/details/agents/types/eventsummary/CfActionTranslatorConfig.xml");
		CfObjectTranslatorConfig cfObjectTranslatorConfig = new CfObjectTranslatorConfig("conf/metafora/details/agents/types/eventsummary/CfObjectTranslatorConfig.xml");
		translator = new EueToCfActionTranslator(cfActionTranslatorConfig, cfObjectTranslatorConfig, sessionConfig.getOntology());	
	}


	@Override
	protected void processEvent(Event event) {
		if (event instanceof UserEvent) {
			UserEvent userActionEvent = (UserEvent) event;
			if (GeneralUtil.isTimeRecent(event.getTs())){
				if (userActionEvent instanceof ObjectActionEvent) {
					List<CfAction> indicators = buildUserObjectActionIndicator((ObjectActionEvent) userActionEvent);
					for (CfAction indicator : indicators){
						communicationManager.sendMessage(indicator);
					}
				}
				if (userActionEvent instanceof UserJoinSessionEvent || userActionEvent instanceof UserLeaveSessionEvent ){
					CfAction indicator = translator.translateJoinOrLeaveEventToCfActionIndicator(userActionEvent);
					if (indicator != null){
						communicationManager.sendMessage(indicator);
					}
				}
			}
		}
	}

	private List<CfAction> buildUserObjectActionIndicator(ObjectActionEvent eueObjectAction){
		List<CfAction> indicators = new ArrayList<CfAction>();
		for (EUEObject object : eueObjectAction.getEueObjectList()){
			if (shouldReportObject(eueObjectAction, object)){
				String eueObjectId = object.getID().getIdAsString();
				GraphElement element = model.getElement(eueObjectId);
				if (element != null){
					CfAction indicator = translator.translateEueObjectActionEventToCfActionIndicator(eueObjectAction, element);
					if (indicator != null){
						indicators.add(indicator);
					}
					else {
						logger.error("[buildUserObjectActionIndicator] Null indicator returned for object id: " + eueObjectId);
					}
				}
				else {
					logger.error("[buildUserObjectActionIndicator] No graphModel entry found for object id: " + eueObjectId);
				}
			}
		}
		return indicators;
	}

	private boolean shouldReportObject(ObjectActionEvent action, EUEObject object ){
		//only report CREATE or DELETE on top-level objects
		if (action instanceof CreateObjectEvent || action instanceof DeleteObjectEvent){
			if ( (object instanceof Link) || (object instanceof Node && object.isTopLevelObject()) ){
				return true;
			}
		}
		else if (action instanceof ModifyObjectEvent){
			//ignore box mods because they are only move events, not important.
			boolean notOnlyBoxes = false;
			ModifyObjectEvent modifyEvent = (ModifyObjectEvent) action;
			
			//Don't send indicators for object modifications by the system.
			if (action.getUserID().getIdAsString().equals("DFKI")){
				return false;
			}
			
			for (EUEObject modifiedObject : modifyEvent.getEueObjectList()){
				if (! modifiedObject.getDataType().equalsIgnoreCase("box")){
					notOnlyBoxes = true;
				}
			}
			return notOnlyBoxes;
		}
		
		//ignore focus events
		return false;
	}
	
}
