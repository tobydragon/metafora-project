package de.dfki.lasad.agents.instances.eventsummaryagent;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.agents.AbstractAgent;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.agents.AnalysisResultEvent;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.events.eue.user.join.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.user.join.UserLeaveSessionEvent;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.DeleteObjectEvent;
import de.dfki.lasad.events.eue.user.object.FocusObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.session.data.objects.Node;
import de.dfki.lasad.sessionmodel.graphmodel.GraphElement;
import de.uds.cfcommunication.CfMultiSessionCommunicationManager;
import de.uds.cfcommunication.CommunicationChannelType;
import de.uds.cfcommunication.CommunicationMethodType;
import de.uds.commonformat.CfAction;
import de.uds.translator.EueToCfActionTranslator;
import de.uds.util.GeneralUtil;

public class EventSummaryAgent extends AbstractAgent {
	Log logger = LogFactory.getLog(this.getClass());

	CfMultiSessionCommunicationManager communicationManager;

	public EventSummaryAgent() {
		communicationManager = CfMultiSessionCommunicationManager.getInstance(CommunicationMethodType.xmpp, CommunicationChannelType.analysis);
	}


	@Override
	protected void processEvent(Event event) {
		if (event instanceof UserEvent) {
			UserEvent userActionEvent = (UserEvent) event;
			if (GeneralUtil.isTimeRecent(event.getTs())){
				if (userActionEvent instanceof ObjectActionEvent) {
					List<CfAction> indicators = buildUserObjectActionIndicator((ObjectActionEvent) userActionEvent);
					for (CfAction indicator : indicators){
						communicationManager.sendMessage(indicator);
					}
				}
				if (userActionEvent instanceof UserJoinSessionEvent || userActionEvent instanceof UserLeaveSessionEvent ){
					CfAction indicator = EueToCfActionTranslator.translateJoinOrLeaveEventToCfActionIndicator(userActionEvent);
					if (indicator != null){
						communicationManager.sendMessage(indicator);
					}
				}
			}
		}
	}

	private List<CfAction> buildUserObjectActionIndicator(ObjectActionEvent eueObjectAction){
		List<CfAction> indicators = new ArrayList<CfAction>();
		for (EUEObject object : eueObjectAction.getEueObjectList()){
			if (shouldReportObject(eueObjectAction, object)){
				String eueObjectId = object.getID().getIdAsString();
				GraphElement element = model.getElement(eueObjectId);
				if (element != null){
					CfAction indicator = EueToCfActionTranslator.translateEueObjectActionEventToCfActionIndicator(eueObjectAction, element);
					if (indicator != null){
						indicators.add(indicator);
					}
					else {
						logger.error("[buildUserObjectActionIndicator] Null indicator returned for object id: " + eueObjectId);
					}
				}
				else {
					logger.error("[buildUserObjectActionIndicator] No graphModel entry found for object id: " + eueObjectId);
				}
			}
		}
		return indicators;
	}

	private boolean shouldReportObject(ObjectActionEvent action, EUEObject object ){
		//only report CREATE or DELETE on top-level objects
		if (action instanceof CreateObjectEvent || action instanceof DeleteObjectEvent){
			if ( (object instanceof Link) || (object instanceof Node && object.isTopLevelObject()) ){
				return true;
			}
		}
		else if (action instanceof ModifyObjectEvent){
			return true;
		}
		//ignore focus events
		return false;
	}
	
}
