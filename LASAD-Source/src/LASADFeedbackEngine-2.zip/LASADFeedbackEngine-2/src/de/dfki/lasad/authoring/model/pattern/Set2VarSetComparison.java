package de.dfki.lasad.authoring.model.pattern;

/**
 * Comparison of a set variable to another set variable.
 * 
 * @author Almer Bolatov, Oliver Scheuer
 * 
 */
public class Set2VarSetComparison extends VariableComparison {
	private Set2SetOperator operator;
	private PropertyVariable rightExpr;

	public Set2SetOperator getOperator() {
		return operator;
	}

	public void setOperator(Set2SetOperator operator) {
		this.operator = operator;
	}

	public PropertyVariable getRightExpr() {
		return rightExpr;
	}

	public void setRightExpr(PropertyVariable rightExpr) {
		this.rightExpr = rightExpr;
	}

	protected VariableComparison getInverseBasic() {
		Set2VarSetComparison inverted = new Set2VarSetComparison();
		inverted.setOperator(getOperator().invert());
		return inverted;
	}
}
