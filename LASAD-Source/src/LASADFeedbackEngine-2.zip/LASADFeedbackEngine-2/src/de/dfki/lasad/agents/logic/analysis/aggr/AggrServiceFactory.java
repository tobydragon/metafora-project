package de.dfki.lasad.agents.logic.analysis.aggr;

import java.util.List;

import lasad.shared.dfki.meta.agents.analysis.counter.CounterAnalysisType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.events.agents.AnalysisResultsChangedEventListener;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class AggrServiceFactory {

	private static Log logger = LogFactory
			.getLog(AggrServiceFactory.class);

	public static AggrServiceInterface createAggregationService(
			AnalysisResultsChangedEventListener resultsChangedListener,
			List<CounterAnalysisType> aggregationTypes) {
		return new AggrService(resultsChangedListener, aggregationTypes);
	}
}
