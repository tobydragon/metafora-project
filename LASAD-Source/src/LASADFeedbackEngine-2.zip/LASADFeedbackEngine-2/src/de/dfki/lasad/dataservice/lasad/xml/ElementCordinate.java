package de.dfki.lasad.dataservice.lasad.xml;

import java.awt.Point;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import de.uds.xml.XmlConfigParser;
import de.uds.xml.XmlFragment;
import de.uds.xml.XmlFragmentInterface;

public class ElementCordinate {

public static String  configPath="conf/metafora/details/agents/types/xmpp/xmpp-point-settings.xml";
public static  Map<String, Point> map_cordinates= new HashMap<String, Point>();; 
	 
public static boolean mapIntialized=false;	 
	 
	 
	 public static void getPointsFromXml(){	
		 map_cordinates.clear();
			List<XmlFragmentInterface> map_points= new ArrayList<XmlFragmentInterface>();; 
				map_points=XmlFragment.getFragmentFromFile(configPath).getChildren("coordinate");
			
			for(XmlFragmentInterface point : map_points ){
				Point new_point=new Point();
				  String _mapId= point.getChildValue("mapid");
					 new_point.x=Integer.parseInt(point.getChildValue("posx"));
					 new_point.y=Integer.parseInt(point.getChildValue("posy"));
				
					 map_cordinates.put(_mapId, new_point);  			  
				  }
			
			 }
	 
	 public static void removePoints(String mapId){
			try { 
				
				SAXBuilder  builder = new SAXBuilder();
				File xmlFile = new File(configPath);
				Document doc;
				doc = (Document) builder.build(xmlFile);
				Element rootNode = doc.getRootElement();
				int i=0;
				for( Object child : rootNode.getChildren("point")){
					Element element=(Element) child;
					String _mapId=element.getChild("mapid").getText();
					if(_mapId.equalsIgnoreCase(mapId)){
					 rootNode.getChildren("point").remove(i);
						break;
					}
					i++;
				}
				XMLOutputter xmlOutput = new XMLOutputter();
				xmlOutput.setFormat(Format.getPrettyFormat());	
				xmlOutput.output(doc, new FileWriter(configPath));
				
		} catch (JDOMException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		}
	 
	 
	
	
	 public static  void savePoints(){
			try {
			SAXBuilder builder = new SAXBuilder();
			File xmlFile = new File(configPath);
			Document doc;
			doc = (Document) builder.build(xmlFile);
			Element rootNode = doc.getRootElement();
			
		
			rootNode.removeContent();
			 Set key_set = map_cordinates.keySet();
			
			 Iterator iter = key_set.iterator();
		        while (iter.hasNext())
		        {
		    Object o = iter.next();
		    String map_id=o.toString();
	     	Element new_point = new Element("coordinate");
			Element mapId = new Element("mapid").setText(map_id);
			Element posX = new Element("posx").setText(String.valueOf(map_cordinates.get(map_id).x));
			Element posY = new Element("posy").setText(String.valueOf(map_cordinates.get(map_id).y));
			new_point.addContent(mapId);
			new_point.addContent(posX);
			new_point.addContent(posY);
			rootNode.addContent(new_point);
			}
			
			
			
		        File f1 = new File(configPath);
		        f1.delete();
	 		XMLOutputter xmlOutput = new XMLOutputter();
			xmlOutput.setFormat(Format.getPrettyFormat());
			xmlOutput.output(doc, new FileWriter(configPath,false));			
			} catch (JDOMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	 
		public static  void addPointOld(String _mapId,Point _elementPoint){
			try {
			SAXBuilder builder = new SAXBuilder();
			File xmlFile = new File(configPath);
			Document doc;
			doc = (Document) builder.build(xmlFile);
			Element rootNode = doc.getRootElement();
	     	Element new_point = new Element("point");
			Element mapId = new Element("mapid").setText(_mapId);
			Element posX = new Element("posx").setText(String.valueOf(_elementPoint.x));
			Element posY = new Element("posy").setText(String.valueOf(_elementPoint.y));
			new_point.addContent(mapId);
			new_point.addContent(posX);
			new_point.addContent(posY);
			rootNode.addContent(new_point);
	 		XMLOutputter xmlOutput = new XMLOutputter();
			xmlOutput.setFormat(Format.getPrettyFormat());
			xmlOutput.output(doc, new FileWriter(configPath));			
			} catch (JDOMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			 
	 
	 public static Point getPointFromXmls(String mapId){	
    
	List<XmlFragmentInterface> map_points= new ArrayList<XmlFragmentInterface>();; 
	boolean hasPoint=false;	 
	Point new_point=new Point();
	map_points=XmlFragment.getFragmentFromFile(configPath).getChildren("point");
	
	for(XmlFragmentInterface point : map_points ){
		  String _mapId= point.getChildValue("mapid");
		  if(mapId.equalsIgnoreCase(_mapId)){
			 new_point.x=Integer.parseInt(point.getChildValue("posx"));
			 new_point.y=Integer.parseInt(point.getChildValue("posy"));
			 
			  hasPoint=true;
			  break;			  
		  }}
	if(!hasPoint){	
		new_point.x=100;
		new_point.y=100;
	}	
	
	//UpdatePointToXml(mapId,new_point);
		return new_point; 
	 }
	 
	 
static int getElementCount(int element_x){
	
	int default_x=map_cordinates.get("default").x;
	int last_x=element_x;
	int count=(last_x-default_x)/20;
	
	System.out.println("Element count:"+count);
	return  count;
}
	//static int   cordinateLastX=0;
	public  static Point getPoint(String mapid){
		
		
		
		if(!mapIntialized)
		{
			getPointsFromXml();
			mapIntialized=true;
		}
			
			 
		Point new_point=new Point();
				if(map_cordinates.containsKey(mapid) )
			{	
				
			  int cordinateMode=getElementCount(map_cordinates.get(mapid).x)%12;
				if(cordinateMode==11)
				{
						
					new_point.x=map_cordinates.get("default").x;
					new_point.y=map_cordinates.get("default").y;		
				}
				else{
					
				new_point.x=map_cordinates.get(mapid).x;
				new_point.y=map_cordinates.get(mapid).y;
				}
				
				
				map_cordinates.remove(mapid);
				
				
			} else{
				
				if(map_cordinates.containsKey("default")) {
					new_point.x=map_cordinates.get("default").x;
					new_point.y=map_cordinates.get("default").y;					
				}
				else{
				new_point.x=100;
				new_point.y=100;
				}
			}
			
			
			map_cordinates.put(mapid, new Point(new_point.x+20,new_point.y+30));
			savePoints();
			return new_point;
		}
		
		

}
