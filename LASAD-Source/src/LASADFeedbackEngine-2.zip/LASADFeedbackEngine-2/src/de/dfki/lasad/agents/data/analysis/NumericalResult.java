package de.dfki.lasad.agents.data.analysis;

import de.dfki.lasad.agents.data.meta.AnalysisType;

public class NumericalResult extends AnalysisResult {

	private double value;

	public NumericalResult(AnalysisType analysisType,
			AnalyzableEntity analyzableEntity, double value) {
		super(analysisType, analyzableEntity);
		this.value = value;
	}

	public double getValue() {
		return value;
	}

	@Override
	public String getValueAsString() {
		return String.valueOf(value);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		long temp;
		temp = Double.doubleToLongBits(value);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		NumericalResult other = (NumericalResult) obj;
		if (Double.doubleToLongBits(value) != Double
				.doubleToLongBits(other.value))
			return false;
		return true;
	}

	
}
