package de.uds.cfcommunication;

import de.uds.commonformat.CfAction;

public interface CfCommunicationListener {
	
	public void processCfAction(String user, CfAction action);

}
