package de.uds.cfcommunication;

import org.apache.log4j.Logger;

import de.uds.commonformat.CfAction;
import de.uds.commonformatparser.CfActionParser;

public class CfCommunicationListenerTest implements CfCommunicationListener{

	Logger logger = Logger.getLogger(this.getClass());
	
	@Override
	public void processCfAction(String user, CfAction action) {
		logger.debug("[processCfAction] \n" + CfActionParser.toXml(action));		
	}
	
	

}
