package de.uds.cfcommunication;

import de.uds.commonformat.CfAction;

public interface CfCommunicationBridge {
	
	public void registerListener(CfCommunicationListener listener);
	public void sendAction(CfAction actionToSend);

}
