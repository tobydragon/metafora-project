package de.uds.xmppGui;

import de.uds.commonformat.CfAction;

public interface CreatePanel {
	
	public CfAction getMessage();

}
