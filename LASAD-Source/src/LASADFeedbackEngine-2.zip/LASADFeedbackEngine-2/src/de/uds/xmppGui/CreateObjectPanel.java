package de.uds.xmppGui;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

import de.uds.cfcommunication.MetaforaCfFactory;
import de.uds.commonformat.CfAction;

public class CreateObjectPanel extends JPanel implements CreatePanel{
	
	
	 JTextArea mapIdTextArea = new JTextArea("1", 1, 65);
	 JTextArea senderNameTextArea = new JTextArea("Metafora-test", 1, 65);
	 JTextArea viewUrlTextArea = new JTextArea("http://web-expresser.appspot.com/?userKey=3CykTKeEMd7VVmxJ19PF55&thumbnail=150", 1, 65);
	 JTextArea textTextArea = new JTextArea("Here is my model", 1, 65);
	 JTextArea referenceUrlTextArea = new JTextArea("http://web-expresser.appspot.com/?userKey=3CykTKeEMd7VVmxJ19PF55", 1, 65);
	 JTextArea usernameTextArea = new JTextArea("Toby", 1, 65);
	 
	 JRadioButton questionButton;
	 JRadioButton myMicroworld3Button;
	 JRadioButton helpRequestButton;


	 JPanel messageTypeChooserPanel = new JPanel();
	  
	 public CreateObjectPanel(){
		 
		 ButtonGroup buttonGroup = new ButtonGroup();
		  
		  myMicroworld3Button = new JRadioButton("'My Microworld' Message");
		  buttonGroup.add(myMicroworld3Button);
		  messageTypeChooserPanel.add(myMicroworld3Button);
		  
		  helpRequestButton = new JRadioButton("'Help Request' Message");
		  buttonGroup.add(helpRequestButton);
		  messageTypeChooserPanel.add(helpRequestButton);
		  
		  questionButton = new JRadioButton("'Question' Message");
		  buttonGroup.add(questionButton);
		  messageTypeChooserPanel.add(questionButton);
		  
		  helpRequestButton.setSelected(true);
		  
		    this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		    this.add(messageTypeChooserPanel);
		    this.add(createLabeledTextArea("MapId", mapIdTextArea));
		    this.add(createLabeledTextArea("Sender", senderNameTextArea));
		    this.add(createLabeledTextArea("View URL", viewUrlTextArea));
		    this.add(createLabeledTextArea("Message", textTextArea));
		    this.add(createLabeledTextArea("Reference URL", referenceUrlTextArea));
		    this.add(createLabeledTextArea("Username", usernameTextArea));
	 }
	 
	 public JPanel createLabeledTextArea(String labelString, JTextArea textArea){
		 JPanel labeledTextPanel = new JPanel();
		 labeledTextPanel.setLayout(new FlowLayout());
		 labeledTextPanel.add(new JLabel(labelString));
		 labeledTextPanel.add( textArea);
		 labeledTextPanel.setPreferredSize(new Dimension(500, 100));
		 return labeledTextPanel;
	 }
	 
	 public String getMapIdTextArea(){
		 return mapIdTextArea.getText();
	 }
	 
	 public String getViewUrlTextArea(){
		 return viewUrlTextArea.getText();
	 }
	 
	 public String getReferenceUrlTextArea(){
		 return referenceUrlTextArea.getText();
	 }
	 
	 public String getSenderNameTextArea(){
		 return senderNameTextArea.getText();
	 }
	 
	 public String getUsernameTextArea(){
		 return usernameTextArea.getText();
	 }
	 
	 public String getText(){
		 return textTextArea.getText();
	 }
	 
	 public CfAction getMessage(){
    	CfAction cfAction=null;;
    	if (questionButton.isSelected()){
			cfAction = MetaforaCfFactory.buildQuestionMessage(this.getMapIdTextArea(),
					this.getSenderNameTextArea(),  this.getText(), this.getUsernameTextArea());
		}
    	if (myMicroworld3Button.isSelected()){
			 cfAction = MetaforaCfFactory.buildMyMicroworldObjectMessage(this.getMapIdTextArea(),
					 this.getSenderNameTextArea(), this.getViewUrlTextArea(), this.getReferenceUrlTextArea(), 
					 this.getText(),  this.getUsernameTextArea());
		}
    	if (helpRequestButton.isSelected()){
			 cfAction = MetaforaCfFactory.buildHelpRequestObjectMessage(this.getMapIdTextArea(),
					 this.getSenderNameTextArea(), this.getViewUrlTextArea(), this.getReferenceUrlTextArea(), 
					 this.getText(),  this.getUsernameTextArea());
		}
		return cfAction;
	 }
}
