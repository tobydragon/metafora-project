package de.uds.xmppGui;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import de.uds.cfcommunication.MetaforaCfFactory;
import de.uds.commonformat.CfAction;

public class CreateUserPanel extends JPanel implements CreatePanel{
	 JTextArea senderNameTextArea = new JTextArea("Metafora-test", 1, 65);
	 JTextArea usernameTextArea = new JTextArea("testUser", 1, 65);
	 JTextArea passwordTextArea = new JTextArea("t", 1, 65);
	 JTextArea roleTextArea = new JTextArea("Standard", 1, 65);
	 JCheckBox passwordEncrypted = new JCheckBox("Password Encrypted");

	 public CreateUserPanel(){
		    this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		    this.add(createLabeledTextArea("Sender", senderNameTextArea));
		    this.add(createLabeledTextArea("Username", usernameTextArea));
		    this.add(createLabeledTextArea("View URL", passwordTextArea));
		    this.add(createLabeledTextArea("Message", roleTextArea));
		    this.add(passwordEncrypted);
	 }
	 
	 public JPanel createLabeledTextArea(String labelString, JTextArea textArea){
		 JPanel labeledTextPanel = new JPanel();
		 labeledTextPanel.setLayout(new FlowLayout());
		 labeledTextPanel.add(new JLabel(labelString));
		 labeledTextPanel.add( textArea);
		 labeledTextPanel.setPreferredSize(new Dimension(500, 100));
		 return labeledTextPanel;
	 }
	 
	 public String getPasswordTextArea(){
		 return passwordTextArea.getText();
	 }
	 
	 public String getSenderNameTextArea(){
		 return senderNameTextArea.getText();
	 }
	 
	 public String getUsernameTextArea(){
		 return usernameTextArea.getText();
	 }
	 
	 public String getRoleTextArea(){
		 return roleTextArea.getText();
	 }
	 
	 public boolean getPasswordEncryptedCheckBox(){
		 return passwordEncrypted.isSelected();
	 }
	 
	 public CfAction getMessage(){
    	CfAction cfAction= MetaforaCfFactory.buildCreateUserMessage(getSenderNameTextArea(), getUsernameTextArea(), getPasswordTextArea(), getRoleTextArea(), getPasswordEncryptedCheckBox());
    	return cfAction;
	 }
}
