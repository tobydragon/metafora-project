package de.uds.xmppGui;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

import de.kuei.metafora.xmpp.XMPPBridge;
import de.uds.commonformat.CfAction;
import de.uds.commonformatparser.CfActionParser;
 
//
public class XmppGui extends JFrame implements ActionListener
{
  
	static {
		try {
			XMPPBridge.createConnection("XmppGuiTest", "XmppGuiTest", "XmppGuiTest", "command@conference.metafora.ku-eichstaett.de", "XmppGuiTest", "GuiTest");
		}
		catch(Exception e){
			System.out.println("[CfXmppWriter] error creating connection - " + e.getMessage());
		}
	}

  JButton myButton = new JButton("Send message");
  JPanel bottomPanel = new JPanel();
  JPanel holdAll = new JPanel();
  
  JTabbedPane createTabs = new JTabbedPane();
  CreateObjectPanel createObjectPanel = new CreateObjectPanel();
  CreateUserPanel createUserPanel = new CreateUserPanel();
  CreateMapPanel createMapPanel = new CreateMapPanel();
  
  JTextArea messageText;
  XMPPBridge xmppBridge;

  public XmppGui()
  {
	  createTabs.addTab("Create Objects", createObjectPanel);
	  createTabs.addTab("Create Users", createUserPanel);
	  createTabs.addTab("Create Maps", createMapPanel);

	  bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
	  bottomPanel.add(myButton);
	  messageText = new JTextArea("", 20, 80);
	  messageText.setEditable(false);
	  bottomPanel.add(messageText);
 
    holdAll.setLayout(new BorderLayout());
    holdAll.add(bottomPanel, BorderLayout.SOUTH);
    holdAll.add(createTabs, BorderLayout.CENTER);
 
    getContentPane().add(holdAll, BorderLayout.CENTER);
 
    myButton.addActionListener(this);
 
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    
    xmppBridge = XMPPBridge.getConnection("XmppGuiTest");
	xmppBridge.connect(true);
	xmppBridge.sendMessage("XmppGuiTest connected at " + System.currentTimeMillis());
  }
 
  public static void main(String[] args)
  {
	  XmppGui myApplication = new XmppGui();
 
    // Specify where will it appear on the screen:
    myApplication.setLocation(10, 10);
    myApplication.setSize(900, 600);
 
    // Show it!
    myApplication.setVisible(true);
  }
 
  public void actionPerformed(ActionEvent e)
  {
    if (e.getSource() == myButton){
    	CreatePanel selected = (CreatePanel)createTabs.getSelectedComponent(); 
		CfAction cfAction = selected.getMessage();
		System.out.println("Sending action:\n" + CfActionParser.toXml(cfAction));
		messageText.setText("Sending action:\n" + CfActionParser.toXml(cfAction));
		xmppBridge.sendMessage(CfActionParser.toXml(cfAction).toString());	
    }
  }
}