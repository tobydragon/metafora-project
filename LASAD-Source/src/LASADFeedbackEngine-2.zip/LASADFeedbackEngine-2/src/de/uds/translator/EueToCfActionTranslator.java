package de.uds.translator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import de.dfki.lasad.agents.data.action.ActionComponent;
import de.dfki.lasad.agents.data.action.AgentAction;
import de.dfki.lasad.agents.data.action.Message;
import de.dfki.lasad.agents.data.action.MessageWithHighlighting;
import de.dfki.lasad.core.components.instance.ISessionModel;
import de.dfki.lasad.events.agents.ActionSpecEvent;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.user.UserEvent;
import de.dfki.lasad.events.eue.user.join.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.user.join.UserLeaveSessionEvent;
import de.dfki.lasad.events.eue.user.object.CreateObjectEvent;
import de.dfki.lasad.events.eue.user.object.DeleteObjectEvent;
import de.dfki.lasad.events.eue.user.object.ModifyObjectEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.data.EUEID;
import de.dfki.lasad.session.data.UserID;
import de.dfki.lasad.session.data.objects.EUEObject;
import de.dfki.lasad.session.data.objects.ObjectProperty;
import de.dfki.lasad.sessionmodel.graphmodel.GraphElement;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfActionType;
import de.uds.commonformat.CfContent;
import de.uds.commonformat.CfObject;
import de.uds.commonformat.CfProperty;
import de.uds.commonformat.CfUser;

public class EueToCfActionTranslator {
	
	private static Logger logger = Logger.getLogger(EueToCfActionTranslator.class);
	
	public static CfAction translateEueEventToCfAction(EUEEvent event) {
		return null;
	}

//	public static List<CfObject> translateEueObjectsToCfObjects(List<EUEObject> eueObjects){
//		List<CfObject> cfObjects = new ArrayList<CfObject>();
//		for (EUEObject eueObject : eueObjects){
//			cfObjects.add(translateEueObjectToCfObject(eueObject));
//		}
//		return cfObjects;
//	}
	
//	public static CfObject translateEueObjectToCfObject(EUEObject eueObject){
//		CfObject cfObject = new CfObject(eueObject.getID().getIdAsString(), eueObject.getType());
//		for (Entry<String, ObjectProperty> entry : eueObject.getProps().entrySet() ){
//			cfObject.addProperty(new CfProperty(entry.getKey(), entry.getValue().getValueAsString()));
//		}
//		return cfObject;	
//	}
	
	public static List <CfUser> translateEueUserToCfUsers(UserID userId){
		List<CfUser> cfUsers = new ArrayList<CfUser>();
		cfUsers.add (new CfUser(userId.getIdAsString(), "student"));
		return cfUsers;
	}
	
	public static CfAction translateEueObjectActionEventToCfActionIndicator(ObjectActionEvent eueObjectAction, GraphElement element){
		String description = "No description available";
		
		CfActionClassificationType classification = CfActionClassificationType.OTHER;
		if (eueObjectAction instanceof CreateObjectEvent) {
			classification = CfActionClassificationType.CREATE;
		} 
		else if (eueObjectAction instanceof DeleteObjectEvent) {
			classification = CfActionClassificationType.DELETE;
		}
		else if (eueObjectAction instanceof ModifyObjectEvent) {
			classification = CfActionClassificationType.MODIFY;
		}
		
		description = EueStatementBuilder.buildObjectEventStatement(eueObjectAction, element, classification);
		
		CfActionType cfActionType = new CfActionType("indicator", classification.toString(), "true", "false");
		
		CfContent cfContent = new CfContent(description);
		cfContent.addProperty(new CfProperty("TOOL", "LASAD-TEST"));
		cfContent.addProperty(new CfProperty("INDICATOR_TYPE", "activity"));
		
		List<CfUser> cfUsers = translateEueUserToCfUsers(eueObjectAction.getUserID());
		
		List<CfObject> cfObjects = new ArrayList<CfObject>();
		cfObjects.add(element.translateToCfObject());
		
		CfAction cfAction = new CfAction(eueObjectAction.getTs(), cfActionType, cfUsers, cfObjects, cfContent);

		return cfAction;
	}
	
	public static CfAction translateJoinOrLeaveEventToCfActionIndicator(UserEvent userEvent) {
		String description = "No description available";
		
		if (userEvent instanceof UserJoinSessionEvent){
			description = EueStatementBuilder.buildUserJoinSessionEventStatement((UserJoinSessionEvent) userEvent);
		}
		else if (userEvent instanceof UserLeaveSessionEvent){
			description = EueStatementBuilder.buildUserLeaveSessionEventStatement((UserLeaveSessionEvent) userEvent);
		}
		else {
			logger.error("[translateJoinOrLeaveEventToCfActionIndicator] not join or leave event : " + userEvent);
		}
				
		CfActionType cfActionType = new CfActionType("indicator", "OTHER", "true", "false");
		
		CfContent cfContent = new CfContent(description);
		cfContent.addProperty(new CfProperty("TOOL", "LASAD-TEST"));
		cfContent.addProperty(new CfProperty("INDICATOR_TYPE", "activity"));
		
		List<CfUser> cfUsers = translateEueUserToCfUsers(userEvent.getUserID());
		
		CfAction cfAction = new CfAction(userEvent.getTs(), cfActionType, cfUsers, new ArrayList<CfObject>(), cfContent);

		return cfAction;
	}

	public static List<CfAction> translateActionSpecEventToIndicators(ActionSpecEvent actionSpecEvent, ISessionModel model) {
		List<CfAction> indicators = new ArrayList<CfAction>();
		
		for (AgentAction action : actionSpecEvent.getAgentActions()){
			CfAction indicator = translateAgentActionToIndicator(actionSpecEvent.getTs(), action, model);
			if (indicator != null){
				indicators.add(indicator);
			}
		}
		return indicators;
	}

	private static CfAction translateAgentActionToIndicator(long ts, AgentAction agentActions, ISessionModel model) {
		ActionComponent  action = agentActions.getActionComponents().iterator().next();
		if (action != null){
			if (agentActions.getActionComponents().size() > 1){
				logger.warn("[translateAgentActionToIndicator] using only first action component, others exist for AgentAction - " + agentActions);
			}
			if (action instanceof Message){
				Message message = (Message) action;
				String description = message.getMessageLong();
				
				CfActionType cfActionType = new CfActionType("indicator", "OTHER", "true", "false");
				
				List<CfObject> cfObjects = new ArrayList<CfObject>();
				if (message instanceof MessageWithHighlighting){
					MessageWithHighlighting messageWithHighlighting = (MessageWithHighlighting) message;
					for (EUEID eueId : messageWithHighlighting.getAnalyzableEntity().getEntityComponents()){
						GraphElement element = model.getElement(eueId.getIdAsString());
						cfObjects.add(element.translateToCfObject());
					}
				}
				
				
				CfContent cfContent = new CfContent(description);
				cfContent.addProperty(new CfProperty("TOOL", "LASAD-TEST"));
				cfContent.addProperty(new CfProperty("INDICATOR_TYPE", message.getMessageShort()));
				
				CfAction cfAction = new CfAction(ts, cfActionType, new ArrayList<CfUser>(), cfObjects, cfContent);
				return cfAction;
			}
			
		}
		else {
			logger.warn("[translateAgentActionToIndicator] No action for AgentAction - " + agentActions);
		}
		return null;
	}
	
	public static CfAction translateModifyEventAndTagsToCfActionIndicator(ObjectActionEvent eueObjectAction, GraphElement element, String text, List<String> tags){
		
		String description = EueStatementBuilder.buildObjectTaggedStatement(eueObjectAction, element, text, tags);
		
		CfActionType cfActionType = new CfActionType("indicator", "OTHER", "true", "false");
		
		CfContent cfContent = new CfContent(description);
		cfContent.addProperty(new CfProperty("TOOL", "LASAD-TEST"));
		cfContent.addProperty(new CfProperty("INDICATOR_TYPE", "TAG"));
		cfContent.addProperty(new CfProperty("TAGS", tags.toString()));
		
		List<CfUser> cfUsers = translateEueUserToCfUsers(eueObjectAction.getUserID());
		
		List<CfObject> cfObjects = new ArrayList<CfObject>();
		cfObjects.add(element.translateToCfObject());
		
		CfAction cfAction = new CfAction(eueObjectAction.getTs(), cfActionType, cfUsers, cfObjects, cfContent);

		return cfAction;
	}

	
	
}
