package de.uds.translator;

import java.util.List;

import de.dfki.lasad.events.eue.user.join.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.user.join.UserLeaveSessionEvent;
import de.dfki.lasad.events.eue.user.object.ObjectActionEvent;
import de.dfki.lasad.session.data.objects.Link;
import de.dfki.lasad.sessionmodel.graphmodel.GraphElement;

public class EueStatementBuilder {
	
	
	public static String buildUserJoinSessionEventStatement(UserJoinSessionEvent event) {
		String translation = "";
		translation += event.getUserID().getIdAsString() + " has joined LASAD map " + event.getSessionID().getIdAsString();
		return translation;
	}
	
	public static String buildUserLeaveSessionEventStatement(UserLeaveSessionEvent event) {
		String translation = "";
		translation += event.getUserID().getIdAsString() + " has left LASAD map " + event.getSessionID().getIdAsString();
		return translation;
	}
	
	public static String buildObjectEventStatement(ObjectActionEvent event, GraphElement element, CfActionClassificationType classificationType) {
		String translation = "";
		translation += event.getUserID().getIdAsString() + " has " + classificationType.getPastTenseActionVersion() + " " + getElementTypeName(element) + " "+ element.getDisplayID() + " of type " + element.getType();
		return translation;
	}
	
	public static String buildObjectTaggedStatement(ObjectActionEvent event, GraphElement element, String text, List<String> tags ) {
		String tagStatement = tags.toString();
		String translation = "";
		translation += getElementTypeName(element) + " "+ element.getDisplayID() +  " contains text tagged as " + tagStatement + " Text: " + text;
		return translation;
	}
	
	public static String getElementTypeName(GraphElement element){
		String object = "box";
		if (element.getEueObject() instanceof Link){
			object = "link";
		}
		return object;
	}

}
