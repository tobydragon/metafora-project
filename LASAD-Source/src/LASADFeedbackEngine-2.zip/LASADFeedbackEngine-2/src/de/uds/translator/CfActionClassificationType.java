package de.uds.translator;

public enum CfActionClassificationType {
	CREATE, DELETE, MODIFY, OTHER;
	
	public String getPastTenseActionVersion(){
		if (this == CREATE){
			return "created";
		}
		else if (this == DELETE){
			return "deleted";
		}
		else if (this == MODIFY){
			return "modified";
		}
		else {
			return "affected";
		}
	}

}
