package de.uds.xml;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class XmlConfigParser {
	private Logger logger = Logger.getLogger(this.getClass());
	
	XmlFragmentInterface configFragment;
	
 
	public XmlConfigParser(XmlFragmentInterface newStart){
		configFragment = newStart;
	}
	
	public XmlConfigParser(String filename){
		configFragment = XmlFragment.getFragmentFromFile(filename);
	}
	
	public XmlConfigParser getfragmentById(String fragmentType, String idAttrName,  String id){
		List<XmlFragmentInterface> frags = configFragment.getChildren(fragmentType);
		for (XmlFragmentInterface frag : frags){
			if( frag.getAttributeValue(idAttrName).equalsIgnoreCase(id)){
				return new XmlConfigParser(frag);
			}
		}
		return null;
	}
	
	public String getConfigValue(String name){
		try {
			return configFragment.cloneChild(name).getRootElement().getText();
		}
		catch (Exception e){
			logger.error("[getConfigValue] error in getting child: " + name);
			return null;
		}
	}
	
	public List<String> getConfigValues(String name){
		List<String> values = new ArrayList<String>();
		try {
			for (XmlFragmentInterface childFragment :  configFragment.getChildren(name)){ 
				values.add(childFragment.getRootElement().getText());
			}
			return values;
		}
		catch (Exception e){
			logger.error("[getConfigValues] error in getting children: " + name);
			return values;
		}
	}

}
