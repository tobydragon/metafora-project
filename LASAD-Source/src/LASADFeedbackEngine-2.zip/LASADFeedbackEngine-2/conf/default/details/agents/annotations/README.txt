Annotations of resources (e.g., transcripts) will be read from this folder and
added to the Jess WM.

The file name must have the following form:

<RESOURCE-ID>.clp.txt 