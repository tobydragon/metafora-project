Jess definitions (e.g., templates, deffacts, functions, etc) that are specific
to an ontology will be read from this folder and added to the Jess WM.

The file name must have the following form:

<ONTOLOGY-ID>.clp.txt 