package lasad.processors.specific;

import lasad.entity.User;
import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.categories.Categories;
import lasad.processors.ActionObserver;

public class QuestionnaireActionProcessor extends AbstractActionObserver
		implements ActionObserver {

	public QuestionnaireActionProcessor() {
		super();
	}

	@Override
	public boolean processAction(Action a, User u, String sessionID) {
		boolean returnValue = false;
		if (u != null&&a.getCategory().equals(Categories.Questionnaire)){
			//TODO not implemented yet
			returnValue = true;
		}
		return returnValue;
	}

}
