package lasad.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import lasad.Server;

public class DatabaseConnectionHandler {

	public static void initDatabase(Server myServerReference) {

		// If required, you can set this parameter to false, to reload old data
		if ("true".equalsIgnoreCase(myServerReference.conf.parameters.get("Fresh Server"))) {
			Connection con = null;

			try {

				String dbProvider = myServerReference.conf.parameters.get("Database Provider");
				String dbHost = myServerReference.conf.parameters.get("Database Host");
				String dbPort = myServerReference.conf.parameters.get("Database Port");
				String dbName = myServerReference.conf.parameters.get("Database Name");
				String dbUser = myServerReference.conf.parameters.get("Database User");
				String dbPassword = myServerReference.conf.parameters.get("Database Password");

				con = DriverManager.getConnection("jdbc:" + dbProvider + "://" + dbHost + ":" + dbPort + "/" + dbName, dbUser, dbPassword);

				// Check which tables exist and delete them
				PreparedStatement getTableList = con.prepareStatement("SHOW TABLES FROM " + dbName + ";");
				ResultSet rs = getTableList.executeQuery();

				boolean first = true;
				StringBuilder dropSQLString = new StringBuilder();
				dropSQLString.append("DROP TABLE ");
				while (rs.next()) {
					if(first) {
						dropSQLString.append(dbName + "." + rs.getString(1));
						first = false;
					}
					else {
						dropSQLString.append(", " + dbName + "." + rs.getString(1));
					}
				}
				
				if(!first) {					
					Statement clearAll = con.createStatement();
					clearAll.execute(dropSQLString.toString());
				}

				// Create new tables needed for the system
				Statement createTable = con.createStatement();

				createTable.execute("CREATE TABLE " + dbName + ".users (id SMALLINT( 5 ) UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR ( 255 ) NOT NULL, pw CHAR ( 32 ) NOT NULL, role VARCHAR ( 255 ) NOT NULL, PRIMARY KEY (id), KEY name (name), KEY pw (pw)) engine 'InnoDB' DEFAULT CHARSET=utf8 ;");
				createTable.execute("CREATE TABLE " + dbName + ".ontologies (id TINYINT( 3 ) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR ( 255 ) NOT NULL, xmlConfig TEXT NOT NULL) engine 'InnoDB' DEFAULT CHARSET=utf8 ;");
				
				// A possible foreign key constraint (Example)
				//createTable.execute("CREATE TABLE " + dbName + ".templates (id SMALLINT( 5 ) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR ( 255 ) NOT NULL, xmlConfig TEXT NOT NULL, ontology_id TINYINT ( 3 ) UNSIGNED NOT NULL, INDEX ( `ontology_id` ), FOREIGN KEY ( `ontology_id` ) REFERENCES `lasad`.`ontologies` (`id`) ON DELETE CASCADE) engine 'InnoDB';");
				
				createTable.execute("CREATE TABLE " + dbName + ".templates (id SMALLINT( 5 ) UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR ( 255 ) NOT NULL, xmlConfig TEXT NOT NULL, ontology_id TINYINT ( 3 ) UNSIGNED NOT NULL, PRIMARY KEY (id), KEY ontology_id (ontology_id)) engine 'InnoDB' DEFAULT CHARSET=utf8 ;");
				
				createTable.execute("CREATE TABLE " + dbName + ".maps (id SMALLINT( 5 ) UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR ( 255 ) NOT NULL, template_id SMALLINT ( 5 ) UNSIGNED NOT NULL, creator_user_id SMALLINT ( 5 ) UNSIGNED NOT NULL, last_root_element_id INT ( 11 ) UNSIGNED NOT NULL, timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY template_id (template_id)) engine 'InnoDB'DEFAULT CHARSET=utf8 ;");

				createTable.execute("CREATE TABLE " + dbName + ".revisions (id INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT, map_id SMALLINT ( 5 ) UNSIGNED NOT NULL, creator_user_id SMALLINT ( 5 ) UNSIGNED NOT NULL, description VARCHAR ( 255 ) NULL, timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY map_id (map_id)) engine 'InnoDB' DEFAULT CHARSET=utf8 ;");
				createTable.execute("CREATE TABLE " + dbName + ".actions (id INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT, revision_id INT ( 11 ) UNSIGNED NOT NULL, element_id INT ( 11 ) UNSIGNED DEFAULT NULL, parameter VARCHAR ( 255 ) NULL, value TEXT, PRIMARY KEY (id), KEY revision_id (revision_id), KEY element_id (element_id)) engine 'InnoDB' DEFAULT CHARSET=utf8 ;");
				createTable.execute("CREATE TABLE " + dbName + ".elements (id INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT, map_id SMALLINT ( 5 ) UNSIGNED NOT NULL, start_revision_id INT( 11 ) UNSIGNED NOT NULL, end_revision_id INT( 11 ) UNSIGNED DEFAULT NULL, type VARCHAR ( 255 ) NOT NULL, last_modified BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY map_id (map_id), KEY start_revision_id (start_revision_id), KEY end_revision_id (end_revision_id)) engine 'InnoDB' DEFAULT CHARSET=utf8 ;");
				createTable.execute("CREATE TABLE " + dbName + ".element_parent_mapping (id SMALLINT( 5 ) UNSIGNED NOT NULL AUTO_INCREMENT, element_id INT ( 11 ) UNSIGNED NOT NULL, parent_element_id INT( 11 ) UNSIGNED NOT NULL, PRIMARY KEY (id), KEY element_id (element_id), KEY parent_element_id (parent_element_id)) engine 'InnoDB' DEFAULT CHARSET=utf8 ;");

				// A seperated Table for map and the corresponding user Gzy
				createTable.execute("CREATE TABLE " + dbName + ".map_to_user_restriction (id INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, map_id SMALLINT ( 5 ) UNSIGNED NOT NULL, user_id SMALLINT ( 5 ) UNSIGNED NOT NULL) engine 'InnoDB' DEFAULT CHARSET=utf8 ;");

			} catch (SQLException e) {
				System.err.println("ERROR in SQL: " + e.getSQLState());
				e.printStackTrace();
			} catch (Exception e) {
				myServerReference.debugLog("ERROR: " + e.toString());
				e.printStackTrace();
			} finally {
				if (con != null) {
					try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
