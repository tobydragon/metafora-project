package lasad.helper;

import lasad.ActionProcessor;
import lasad.Server;
import lasad.entity.User;
import lasad.gwt.client.communication.objects.ActionFactory;
import lasad.gwt.client.communication.objects.ActionPackage;

public class HeartbeatChecker extends Thread {

	private Server myServer;
	private ActionProcessor ap;

	private boolean requestNeeded = false;

	public HeartbeatChecker(Server myServer, ActionProcessor ap) {
		this.myServer = myServer;
		this.ap = ap;
	}

	public void run() {

		try {
			while (true) {
				requestNeeded = false;
				sleep(Long.parseLong(myServer.conf.parameters.get("Heartbeat-Checker-Timer")));

				long currentTime = System.currentTimeMillis();

				synchronized (ActionProcessor.sessionToUserLock) {
					myServer.debugLog("Enable lock sessionToUserLock from HeartbeatChecker.run()");

					for (String sessionID : myServer.currentState.sessionToUser.keySet()) {
						User u = myServer.currentState.sessionToUser.get(sessionID);

						myServer.log("Checking heartbeat of client: " + sessionID + " [" + (currentTime - u.getLastHeartbeat()) + "] Max: " + Integer.parseInt(myServer.conf.parameters.get("Timeout-Limit")));

						if (currentTime - u.getLastHeartbeat() > 2 * Integer.parseInt(myServer.conf.parameters.get("Timeout-Limit"))) {
							// Heartbeat request was not answered -> logout user
							myServer.log("Logging out user: " + sessionID);
							ap.processActionPackage(ActionFactory.getLogOutActionPackage(u.getSessionID(), u.getNickname()));
							continue;
						} else if (currentTime - u.getLastHeartbeat() > Integer.parseInt(myServer.conf.parameters.get("Timeout-Limit"))) {
							myServer.log("Sending heartbeat request for user: " + sessionID);
							ActionPackage ap1 = ActionFactory.heartbeatRequest();
							ap.doCFLogging(ap1);
							ap.addToUsersActionQueue(ap1, u.getSessionID());
							requestNeeded = true;
						}
					}
					myServer.debugLog("Disable lock sessionToUserLock from HeartbeatChecker.run()");
				}
				if (requestNeeded) {
					ap.sendActionsToConnectedClients();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
