package lasad;

import java.rmi.Remote;
import java.rmi.RemoteException;

import lasad.gwt.client.communication.objects.ActionPackage;

public interface ServerInterface extends Remote {
	
	public void doActionOnServer(ActionPackage p) throws RemoteException;
}
