package lasad.logging.commonformat;

import java.util.List;

import de.kuei.metafora.xmpp.XMPPBridge;

import lasad.logging.commonformat.util.CF2StringUtil;
import lasad.logging.commonformat.util.CFWriter;
import lasad.logging.commonformat.util.jaxb.Action;
import lasad.logging.commonformat.util.jaxb.Preamble;

public class CfXmppWriter implements CFWriter{

	private XMPPBridge xmppBridge;
	
	private CF2StringUtil cf2SUtil;
	 
	 public CfXmppWriter(){
		try{
			cf2SUtil = new CF2StringUtil();
			xmppBridge = XMPPBridge.getInstance();
			xmppBridge.connect(true);
			xmppBridge.sendMessage("LASAD CF logger connected");
		} catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	@Override
	public void closeWriter(String sessionID) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void writePreamble(String sessionID, Preamble preamble) {
		try {
			xmppBridge.sendMessage(CF2StringUtil.getFileHeader());
			xmppBridge.sendMessage(cf2SUtil.preamble2String(preamble));
			xmppBridge.sendMessage(CF2StringUtil.getOpenActions());
		} catch (Exception e) {
	        e.printStackTrace();
	    }
		
	}

	@Override
	public void writeActionList(String sessionID, List<Action> actionList) {
		
		for(Action act : actionList){
			try {
				xmppBridge.sendMessage(cf2SUtil.action2String(act));
			} catch (Exception e) {
		        e.printStackTrace();
		    }
			
		}
	}

}
