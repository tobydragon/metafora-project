package lasad.logging.xml;

import lasad.gwt.client.communication.objects.Parameter;

public class ParameterXmlConverter {
	
	public static XmlFragment toXml(Parameter parameter){
		XmlFragment xmlFragment = new XmlFragment("Parameter");
		xmlFragment.setAttribute("NAME", parameter.getName());
		xmlFragment.setAttribute("VALUE", parameter.getValue());
		return xmlFragment;
	}
	
	public static Parameter fromXml(XmlFragment xmlFragment){
		String name = xmlFragment.getAttributeValue("NAME");
		String value = xmlFragment.getAttributeValue("VALUE");
		return new Parameter(name, value);
	}

}
