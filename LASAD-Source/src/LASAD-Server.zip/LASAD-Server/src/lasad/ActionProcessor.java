package lasad;

import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.Naming;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;
import java.util.Vector;

import lasad.entity.ActionParameter;
import lasad.entity.Element;
import lasad.entity.Map;
import lasad.entity.Ontology;
import lasad.entity.Revision;
import lasad.entity.Template;
import lasad.entity.User;
import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionFactory;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.Parameter;
import lasad.helper.HeartbeatChecker;
import lasad.logging.xml.ActionPackageXmlConverter;

import org.jdom.Document;
import org.jdom.input.SAXBuilder;

public class ActionProcessor {

	private static final Object addToGWTUserQueueAndSendActionsLock = new Object();
	private static final Object addToRMIUserQueueAndSendActionsLock = new Object();
	private static final Object session2RemoveLock = new Object();
	private static final Object userMapsLock = new Object();
	private static final Object createElementLock = new Object();

	private static final Object DeleteUpdateJoinActionLock = new Object();

	public static final Object mapUsersLock = new Object();
	public static final Object sessionToUserLock = new Object();
	public static final Object userIdToSessionLock = new Object();

	public HashMap<Integer, User> usersToBeRemovedFromMaps = new HashMap<Integer, User>();

	private String userToBeRemoved = null;
	private String userFailedToLogin = null;

	private Server myServer;

	public ActionProcessor(Server s) {
		this.myServer = s;

		HeartbeatChecker hbc = new HeartbeatChecker(myServer, this);
		hbc.start();
	}

	/**
	 * @param p
	 */
	public void processActionPackage(ActionPackage p) {
		myServer.log("Action Package arrived : ");
		myServer.logPackage(p);

		String sessionID = p.getParameter("SESSION-ID");
		 System.out.println("processActionPackage -\n" + ActionPackageXmlConverter.toXml(p));

		// Update timeout status for the current user
		updateTimeOut(sessionID);

		// Process actual package
		
		addMetaInformation(p, sessionID);

		if (checkIfPackageContainsMapCreateActions(p)) {
			// Lock required to make sure the LAST-ID is used correctly.
			// The lock is shared by the creation of pre-defined elements
			synchronized (createElementLock) {
				myServer.debugLog("Enable lock createElementLock from processActionPackage");
				for (Action a : p.getActions()) {
					try {
						distributeByActionCategory(a, sessionID);
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				myServer.debugLog("Disable lock createElementLock from processActionPackage");
			}
		} else {
			// No lock required
			for (Action a : p.getActions()) {
				try {
					distributeByActionCategory(a, sessionID);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		sendActionsToConnectedClients();
		removeUserThatDidNotLoginCorrectly();
		removeUsersWhoLeftAMap();
		removeUserWhoLoggedOff();
	}

	private boolean checkIfPackageContainsMapCreateActions(ActionPackage p) {
		for (Action a : p.getActions()) {
			if (a.getCmd().equalsIgnoreCase("CREATE-ELEMENT")) {
				return true;
			}
		}
		return false;
	}

	private void updateTimeOut(String sessionID) {
		User u = null;

		synchronized (sessionToUserLock) {
			myServer.debugLog("Enable lock sessionToUserLock from updateTimeOut");
			u = myServer.currentState.sessionToUser.get(sessionID);
			myServer.debugLog("Disable lock sessionToUserLock from updateTimeOut");
		}

		if (u != null) {
			u.setLastHeartbeat(System.currentTimeMillis());
		}
	}

	private void distributeByActionCategory(Action a, String sessionID) throws SQLException {

		User u = null;

		synchronized (sessionToUserLock) {
			myServer.debugLog("Enable lock sessionToUserLock from distributeByActionCategory");
			u = myServer.currentState.sessionToUser.get(sessionID);
			myServer.debugLog("Disable lock sessionToUserLock from distributeByActionCategory");
		}

		if (a.getCategory().equalsIgnoreCase("MANAGEMENT")) { // Check
			workOnManagementActions(a, u, sessionID);
		} else {
			if (u != null) {
				if (a.getCategory().equalsIgnoreCase("MAP")) { // Check
					workOnMapActions(a, u);
				} else if (a.getCategory().equalsIgnoreCase("COMMUNICATION")) { // Check
					workOnCommunicationActions(a, u);
				} else if (a.getCategory().equalsIgnoreCase("FEEDBACK")) { // Check
					workOnFeedbackActions(a, u);
				} else if (a.getCategory().equals("QUESTIONNAIRE")) { // TODO Re-implement questionnaire handling
					workOnQuestionnaireActions(a, u);
				} else if (a.getCategory().equals("AUTHORING")) { // Check
					workOnAuthoringActions(a, u);
				} else if (a.getCategory().equals("REPLAY")) { // Check
					processReplay(a, u);
				} else if (a.getCategory().equals("FILE")) { // Check
					if (a.getCmd().equalsIgnoreCase("IMPORT-FINISHED")) {
						ActionPackage ap = ActionFactory.loadFromFileFinished(a.getParameter("IMPORT-TYPE"));
						doCFLogging(ap);
						addToUsersActionQueue(ap, u.getSessionID());
					}
					else {
						processLoadMapFromFile(a, u);
					}
				}
			} else {
				myServer.debugLog("User is null (maybe logged out before) --> Action ignored: " + a.toString());
			}
		}
	}

	private void processLoadMapFromFile(Action a, User u) {
		String sessionName = a.getParameter("SESSION");
		if (Map.getMapID(sessionName) != -1) {
			ActionPackage ap1 = ActionFactory.error("Session does already exist. Please choose a different name...");
			doCFLogging(ap1);
			addToUsersActionQueue(ap1, u.getSessionID());

			// Send end action to close any loading dialogues
			ActionPackage ap2 = ActionFactory.loadFromFileFinished("LASAD");
			doCFLogging(ap2);
			addToUsersActionQueue(ap2, u.getSessionID());
			return;
		}

		// Create ontology if not existent
		String ontologyXML = a.getParameter("ONTOLOGY-XML");
		if (!Ontology.isExisting(Ontology.getOntologyNameFromXMLFile(ontologyXML))) {
			(Ontology.parseOntologyFromXML(ontologyXML)).saveToDatabase();
		} else {
			myServer.log("Load from file: Ontology found.");
		}

		// Create template if not existent
		String templateXML = a.getParameter("TEMPLATE-XML");
		String templateName = Template.getTemplateNameFromXMLFile(templateXML);
		int templateID = Template.getTemplateID(templateName);
		if (templateID == -1) {
			(Template.parseTemplateFromXML(templateXML)).saveToDatabase();
		} else {
			myServer.log("Load from file: Template found.");
		}

		// Create map / session
		
		String username = a.getParameter("RESTRICTED-TO");
		
		int mapID = processAuthoringCreateSession(ActionFactory.getCreateMapAction(sessionName, templateName, username), u, false);

		// Parse content
		processParseContentFromXML(mapID, a.getParameter("CONTENT-XML"), u.getUserID());

		// Join map
		processJoin(ActionFactory.joinMap(mapID), u);

		// Send end action to close any loading dialogues
		ActionPackage ap = ActionFactory.loadFromFileFinished("LASAD");
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());

	}

	private void processParseContentFromXML(int mapID, String contentXML, int userID) {
		int maxRootElementID = 0;

		HashMap<String, Integer> rootElementIDToElementID = new HashMap<String, Integer>();

		StringReader in = null;
		try {
			in = new StringReader(contentXML);

			SAXBuilder saxIn = new SAXBuilder();
			Document doc;

			doc = saxIn.build(in);

			org.jdom.Element contentElement = doc.getRootElement();

			List<org.jdom.Element> elements = contentElement.getChildren("element");
			for (org.jdom.Element element : elements) {

				String rootElementID = element.getAttributeValue("root-element-id");

				if (rootElementID != null) {
					int currentRootElementID = Integer.parseInt(rootElementID);
					if (currentRootElementID > maxRootElementID) {
						maxRootElementID = currentRootElementID;
					}
				}

				String ontologyID = element.getAttributeValue("element-id");
				String type = element.getAttributeValue("type");
				String posX = element.getAttributeValue("pos-x");
				String posY = element.getAttributeValue("pos-y");
				String height = element.getAttributeValue("height");
				String width = element.getAttributeValue("width");
				String username = element.getAttributeValue("username");

				String startParent = element.getAttributeValue("start-parent-root-element-id");
				String endParent = element.getAttributeValue("end-parent-root-element-id");

				Action a = new Action("CREATE-ELEMENT", "MAP");
				a.addParameter("MAP-ID", mapID + "");
				a.addParameter("TYPE", type);
				a.addParameter("ELEMENT-ID", ontologyID);
				a.addParameter("ROOTELEMENTID", rootElementID);

				if (startParent != null && endParent != null) {
					startParent = rootElementIDToElementID.get(startParent).toString();
					endParent = rootElementIDToElementID.get(endParent).toString();

					a.addParameter("PARENT", startParent);
					a.addParameter("PARENT", endParent);
				} else {
					a.addParameter("POS-X", posX);
					a.addParameter("POS-Y", posY);
				}

				// This lock is required for the LAST-ID
				// It is shared with the normal create-element processing as it
				// is using the same lock

				synchronized (createElementLock) {
					myServer.debugLog("Enable lock createElementLock from processParseContentFromXML");
					int concreteElementID = processCreatePreDefinedElement(a, mapID, getUserID(username));
					rootElementIDToElementID.put(rootElementID, concreteElementID);

					List<org.jdom.Element> subelements = element.getChildren("sub-element");
					for (org.jdom.Element subelement : subelements) {
						// Parse attributes
						String subType = subelement.getAttributeValue("type");
						String subUsername = null;

						Action b = new Action("CREATE-ELEMENT", "MAP");
						b.addParameter("MAP-ID", mapID + "");
						b.addParameter("TYPE", subType);
						b.addParameter("PARENT", "LAST-ID");

						// Parse parameters
						List<org.jdom.Element> parameters = subelement.getChildren("parameter");
						for (org.jdom.Element parameter : parameters) {
							String name = parameter.getChildText("name");
							String value = parameter.getChildText("value");

							b.addParameter(name, value);

							if (name.equalsIgnoreCase("USERNAME")) {
								subUsername = value;
							}
						}
						processCreatePreDefinedElement(b, mapID, getUserID(subUsername));
					}

					// The update action is required to force the client to show
					// the
					// correct size (especially height)
					Action upd = new Action("UPDATE-ELEMENT", "MAP");
					upd.addParameter("MAP-ID", mapID + "");
					upd.addParameter("ID", concreteElementID + "");
					upd.addParameter("HEIGHT", height);
					upd.addParameter("WIDTH", width);
					processUpdateElementLocal(upd, getUserID(username));

					myServer.debugLog("Disable lock createElementLock from processParseContentFromXML");
				}
			}

		} catch (Exception e) {

		} finally {
			in.close();
		}

		// Update last root element id used on this map
		Map.setLastRootElementID(mapID, maxRootElementID);
	}

	private int getUserID(String username) {
		int creatorID = 1;
		if (username != null) {
			int tempID = User.getUserID(username);
			if (tempID != -1) {
				creatorID = tempID;
			}
		}
		return creatorID;
	}

	private void processReplay(Action a, User u) {

		int mapID = getMapIDFromAction(a);

		Vector<Integer> allMapRevisionIDs = Revision.getIDsOfRevisionsConnectedToMap(mapID);

		// If only 1 revision --> Empty map, Ignore.
		if (allMapRevisionIDs.size() == 1) {
			ActionPackage ap = ActionFactory.errorReplay(mapID, Map.getMapName(mapID), -3);
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
			return;
		}

		// Remove first revision from list (it is not required, it says only
		// that the map has been created)
		allMapRevisionIDs.removeElementAt(0);

		// Estimate replay time in seconds
		long realStartSec = (Revision.getTime(allMapRevisionIDs.firstElement()) / 1000) - 1;
		long totalSec = Revision.getTime(allMapRevisionIDs.lastElement()) - Revision.getTime(allMapRevisionIDs.firstElement());
		totalSec = (totalSec / 1000) + 1;

		// Create response
		ActionPackage ap = ActionFactory.startInitReplay(mapID);

		ap = Map.getCompleteElementInformationForReplay(ap, mapID, true, realStartSec);

		// Create final action to initialize the replay-client
		ap = ActionFactory.endInitReplay(ap, mapID, totalSec, myServer.currentState);
		// Add Map-ID to ActionPackage
		ap.addParameter("MAP-ID", a.getParameter("MAP-ID"));
		// Add ActionPackage to UsersActionQueue
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());

	}

	private void workOnAuthoringActions(Action a, User u) {
		if (a.getCmd().equalsIgnoreCase("GET-TEMPLATES")) {
			processAuthoringGetTemplates(u, true);
		} else if (a.getCmd().equalsIgnoreCase("CREATE-TEMPLATE")) {
			processAuthoringCreateTemplate(a, u);
		} else if (a.getCmd().equalsIgnoreCase("DELETE-TEMPLATE")) {
			processAuthoringDeleteTemplate(a, u);
		} else if (a.getCmd().equalsIgnoreCase("GET-ONTOLOGIES")) {
			processAuthoringGetOntologies(u);
		} else if (a.getCmd().equalsIgnoreCase("GET-ONTOLOGY-DETAILS")) {
			processOntologyDetails(a, u);
		} else if (a.getCmd().equalsIgnoreCase("CREATE-ONTOLOGY")) {
			processAuthoringCreateOntology(a, u);
		} else if (a.getCmd().equalsIgnoreCase("DELETE-ONTOLOGY")) {
			processAuthoringDeleteOntology(a, u);
		} else if (a.getCmd().equalsIgnoreCase("UPDATE-ONTOLOGY")) {
			processAuthoringUpdateOntology(a, u);
		} else if (a.getCmd().equalsIgnoreCase("GET-MAPS-AND-TEMPLATES")) {
			processAuthoringGetMapsAndTemplates(u);
		} else if (a.getCmd().equalsIgnoreCase("CREATE-MAP")) {
			processAuthoringCreateSession(a, u, true);
		} else if (a.getCmd().equalsIgnoreCase("DELETE-MAP")) {
			processAuthoringDeleteMap(a, u);
		} else if (a.getCmd().equalsIgnoreCase("GET-USERS")) {
			processAuthoringGetUsers(a, u);
		} else if (a.getCmd().equalsIgnoreCase("CREATE-USER")) {
			processAuthoringCreateUser(a, u);
		} else if (a.getCmd().equalsIgnoreCase("DELETE-USER")) {
			processAuthoringDeleteUser(a, u);
		}
	}

	private void processAuthoringCreateOntology(Action a, User u) {

		if(Ontology.getOntologyID(a.getParameter("ONTOLOGYNAME")) != -1) {
			ActionPackage ap = ActionFactory.authoringFailed("Ontology already exists, please choose another name.");
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
		}
		else {	
			if(a.getParameter("CLONE") != null) {
				String xml = Ontology.getOntologyXML(Ontology.getOntologyID(a.getParameter("CLONE")));
				xml = xml.replace("type=\""+a.getParameter("CLONE")+"\"", "type=\""+a.getParameter("ONTOLOGYNAME")+"\"");
				
				a.replaceParameter("ONTOLOGY-XML", xml);
				
				Ontology newOntology = new Ontology(a.getParameter("ONTOLOGYNAME"), xml);
				newOntology.saveToDatabase();
				
				
			}
			else {
				Ontology.parseOntologyFromXML(a.getParameter("ONTOLOGY-XML")).saveToDatabase();
			}
			
			File f = Ontology.generateOntologyConfigurationFile(a);
			processAuthoringGetOntologies(u);
			
			ActionPackage ap = ActionFactory.getInfoAction("Ontology successfully created.");
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
		}
	}

	private void processAuthoringUpdateOntology(Action a, User u) {
		String ontologyName = a.getParameter("ONTOLOGYNAME");
		int ontologyID = Ontology.getOntologyID(ontologyName);
		
		// Check if there are already sessions that are using this template. If that is the case the sessions must be deleted to avoid any errors caused by the modifications of the ontology.
		if (!"TRUE".equalsIgnoreCase(a.getParameter("CONFIRMED"))) {

			Vector<Integer> templateIDs = Template.getIDsOfTemplatesThatUseTheOntology(ontologyID);
			
			int numberOfSessions = 0;
			
			for(Integer templateID : templateIDs) {
				Vector<Integer> sessionIDs = Map.getIDsOfMapsThatUseTheTemplate(templateID);
				numberOfSessions += sessionIDs.size();
			}
			
			if (templateIDs.size() > 0) {
				
				String msg = "";
				
				if (numberOfSessions > 0) {				
					msg = "The ontology is used by " + templateIDs.size() + " template(s) and " + numberOfSessions + " session(s). These template(s) and all session(s) (including their content) that are created based on these template(s) will be deleted. Are you sure, you want to update the ontology?";
				}
				else {
					msg = "The ontology is used by " + templateIDs.size() + " template(s). These template(s) will be deleted. Are you sure, you want to update the ontology?";
				}
				
				ActionPackage ap = ActionFactory.getConfirmActionFromExistingAction(a, msg);
				doCFLogging(ap);
				addToUsersActionQueue(ap, u.getSessionID());
				return;
			}

		}
		
		// Delete templates & sessions (recursive) that use the ontology
		Vector<Integer> templateIDs = Template.getIDsOfTemplatesThatUseTheOntology(ontologyID);
		for(int i : templateIDs) {
			Template.delete(i, myServer);
		}
		
		// Update ontology saved in database with new ontology
		String xml = a.getParameter("ONTOLOGY-XML");
		Ontology.updateOntologyInDB(ontologyName, xml);

		// Update local ontology xml file
		Ontology.updateOntologyInFileSystem(ontologyName, xml);

		// Update client view
		processOntologyDetails(a, u);

		ActionPackage ap = ActionFactory.getInfoAction("Ontology successfully updated.");
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());
	}

	private void processOntologyDetails(Action a, User u) {
		String ontologyName = a.getParameter("ONTOLOGYNAME");

		ActionPackage ap = ActionFactory.getOntologyDetails(ontologyName);
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());

	}

	private void processAuthoringGetOntologies(User u) {
		Vector<String> ontologyList = Ontology.getAllOntologyNames();
		ActionPackage ap = ActionFactory.getOntologyList(ontologyList);
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());
	}

	private void processAuthoringDeleteUser(Action a, User u) {
		String username = a.getParameter("USERNAME");
		int userID = User.getUserID(username);

		if (!"TRUE".equalsIgnoreCase(a.getParameter("CONFIRMED"))) {

			String msg = "";

			Vector<Integer> authorOfMapIDs = Map.getIDsOfMapsThatAreCreatedByUser(userID);
			if (authorOfMapIDs.size() > 0) {
				msg += "The user is author of " + authorOfMapIDs.size() + " sessions. ";
			}

			int sessionIDsWhereUserDidParticipate = Map.getNumberOfMapRevisionsCreatedByUser(userID);
			if (sessionIDsWhereUserDidParticipate > 0) {
				msg += "The user provided " + sessionIDsWhereUserDidParticipate + " revisions in one or multiple sessions. ";
			}

			if (!msg.equals("")) {
				msg += "To keep the internal validity, the user will be replaced by \"Unknown\". Are you sure, you want to proceed?";
				ActionPackage ap = ActionFactory.getConfirmActionFromExistingAction(a, msg);
				doCFLogging(ap);
				addToUsersActionQueue(ap, u.getSessionID());
				return;
			}
		}

		// Remove from client list
		ActionPackage ap = ActionFactory.getRemoveUserAction(username, User.getRole(username));
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());

		User.delete(username, User.getUserID(username), User.getUserID("Unknown"), myServer);
	}

	private void processAuthoringCreateUser(Action a, User u) {
		
		int userID = User.getUserID(a.getParameter("USERNAME"));
		if(userID != -1) {
			ActionPackage ap = ActionFactory.authoringFailed("Username already exists, please choose another one.");
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
		}
		else {
			User.generateUserConfigurationFile(a);
	
			User user = new User(a.getParameter("USERNAME"), a.getParameter("PW"), a.getParameter("ROLE"));
			user.saveToDatabase();
	
			ActionPackage ap = ActionFactory.getNewUserAction(user);
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
		}
	}

	private void processAuthoringGetUsers(Action a, User u) {
		if ("TRUE".equals(a.getParameter("GET-ROLES"))) {
			Vector<User> t = User.getAllUsers();

			ActionPackage ap = ActionFactory.getUserListActionPackage(t);
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
		} else {
			Vector<String> usernames = User.getUserListWithoutRoles();

			ActionPackage ap = ActionFactory.getUserListWithoutRolesActionPackage(usernames);
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
		}
	}

	private void processAuthoringDeleteMap(Action a, User u) {
		String mapName = a.getParameter("MAPNAME");

		// Remove from client list
		ActionPackage ap = ActionFactory.getRemoveMapAction(mapName, Map.getTemplate(Map.getMapID(mapName)).getName());
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());

		// Delete map from file system and database
		Map.delete(Map.getMapID(mapName), myServer);
	}

	private int processAuthoringCreateSession(Action a, User u, boolean enableCheck) {
		
		if(Map.getMapID(a.getParameter("MAPNAME")) != -1 && enableCheck) {
			ActionPackage ap = ActionFactory.authoringFailed("Session already exists, please choose a different name.");
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
			
			return -1;
		}
		else {
			
			Vector<Integer> userList = new Vector<Integer>();
			
			if(a.getParameterVector("RESTRICTED-TO") != null) {			
				if(a.getParameterVector("RESTRICTED-TO").size()>0)
				{
					for(int i = 0 ; i< a.getParameterVector("RESTRICTED-TO").size();i++)
					{
						if(a.getParameterVector("RESTRICTED-TO").get(i) != null && !a.getParameterVector("RESTRICTED-TO").get(i).equals("")) {
							System.out.println("User: \n"+a.getParameterVector("RESTRICTED-TO").get(i)+"\"");
							userList.add(User.getUserID(a.getParameterVector("RESTRICTED-TO").get(i)));
						}
					}
				}
			}
			Map m = new Map(a.getParameter("MAPNAME"), Template.getTemplateID(a.getParameter("TEMPLATE")), u.getUserID(), userList);
			m.saveToDatabase(this);
	
			myServer.currentState.maps.put(m.getId(), m);
			myServer.currentState.mapUsers.put(m.getId(), new Vector<User>());
			
			if("TRUE".equalsIgnoreCase(a.getParameter("PERSISTENT"))) {
				m.generateMapConfigurationFile();
			}
			
			ActionPackage ap = ActionFactory.getNewMapAction(m);
			doCFLogging(ap);
			addToAllUsersActionQueue(ap);
	
			return m.getId();
		}
	}

	private void processAuthoringGetMapsAndTemplates(User u) {
		ActionPackage ap = ActionFactory.getMapsAndTemplates();
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());
	}

	private void processAuthoringDeleteOntology(Action a, User u) {
		String ontologyName = a.getParameter("ONTOLOGYNAME");
		int ontologyID = Ontology.getOntologyID(ontologyName);

		if (!"TRUE".equalsIgnoreCase(a.getParameter("CONFIRMED"))) {

			Vector<Integer> templateIDs = Template.getIDsOfTemplatesThatUseTheOntology(ontologyID);
			if (templateIDs.size() > 0) {
				String msg = "The ontology is used by " + templateIDs.size() + " templates. These templates and all sessions that are created based on these templates will be deleted. Are you sure, you want to proceed?";

				ActionPackage ap = ActionFactory.getConfirmActionFromExistingAction(a, msg);
				doCFLogging(ap);
				addToUsersActionQueue(ap, u.getSessionID());
				return;
			}
		}

		// Remove from client list
		ActionPackage ap = ActionFactory.getRemoveOntologyAction(ontologyName);
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());

		// Delete ontology from file system and database
		Ontology.delete(Ontology.getOntologyID(ontologyName), myServer);
	}

	private void processAuthoringDeleteTemplate(Action a, User u) {
		String templateName = a.getParameter("TEMPLATE");

		if (!"TRUE".equalsIgnoreCase(a.getParameter("CONFIRMED"))) {

			Vector<Integer> mapIDs = Map.getIDsOfMapsThatUseTheTemplate(Template.getTemplateID(templateName));
			if (mapIDs.size() > 0) {
				String msg = "There are " + mapIDs.size() + " sessions that use this template. These sessions will no longer be valid and will be deleted. Are you sure, you want to proceed?";
				ActionPackage ap = ActionFactory.getConfirmActionFromExistingAction(a, msg);
				doCFLogging(ap);
				addToUsersActionQueue(ap, u.getSessionID());
				return;
			}
		}

		// Remove from client list
		ActionPackage ap = ActionFactory.getRemoveTemplateAction(templateName, Ontology.getOntologyName(Template.getOntologyID(templateName)));
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());

		Template.delete(Template.getTemplateID(templateName), myServer);
	}

	private void processAuthoringCreateTemplate(Action a, User u) {
		
		if(Template.getTemplateID(a.getParameter("TEMPLATE-NAME")) != -1) {
			ActionPackage ap = ActionFactory.authoringFailed("Template already exists, please choose another name.");
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
		}
		else {	
			// TODO Check if the ontology allows transcript, if transcript is set.
			File f = Template.generateTemplateConfigurationFile(a);
	
			Template t = Template.parseTemplateFromFile(f, this);
			t.saveToDatabase();
	
			ActionPackage ap = ActionFactory.getNewTemplateAction(t);
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
		}
	}

	private void processAuthoringGetTemplates(User u, boolean authoring) {

		ActionPackage ap = ActionFactory.getTemplateListActionPackage(authoring);
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());
	}

	private void workOnQuestionnaireActions(Action a, User u) {
	}

	private void workOnFeedbackActions(Action a, User u) {
		if (a.getCmd().equals("REQUEST")) {
			distributeToAllUsersWithoutSaving(a, u);
		} else if (a.getCmd().equals("CREATE-ELEMENT") || a.getCmd().equals("HIGHLIGHT")) {
			processCreateElement(a, u);
		}
	}

	private void workOnCommunicationActions(Action a, User u) {
		// Currently, there are only chat messages in this category, thus, a
		// further differentiation is not needed
		int mapID = getMapIDFromAction(a);

		Revision r = new Revision(mapID, "Chat message", u.getUserID());
		r.saveToDatabase();

		ActionParameter.saveParametersForRevision(r.getId(), a);
		a.addParameter("USERNAME", u.getNickname());
		a.addParameter("TIME", System.currentTimeMillis() + "");

		ActionPackage ap = ActionPackage.wrapAction(a);
		doCFLogging(ap);
		addToAllUsersOnMapActionQueue(ap, mapID);
	}

	private void workOnManagementActions(Action a, User u, String sessionID) throws SQLException {
		if (a.getCmd().equalsIgnoreCase("LOGIN")) { // Check
			processLogin(a, sessionID);
		}

		else {
			if (u != null) {
				if (a.getCmd().equalsIgnoreCase("JOIN")) { // Check
					processJoin(a, u);
				} else if (a.getCmd().equalsIgnoreCase("LEAVE")) { // Check
					processLeaveMap(a, u);
				} else if (a.getCmd().equalsIgnoreCase("LOGOUT")) { // Check
					processLogout(a, u);
				} else if (a.getCmd().equalsIgnoreCase("LIST")) { // Check
					processList(a, u);
				} else if (a.getCmd().equalsIgnoreCase("MAPDETAILS")) { // Check
					processMapDetails(a, sessionID);
				} else if (a.getCmd().equalsIgnoreCase("TEMPLATEDETAILS")) { // Check
					processTemplateDetails(a, u);
				} else if (a.getCmd().equalsIgnoreCase("GETALLONTOLOGIESANDTEMPLATES")) { // Check
					processGetAllOntologiesAndTemplates(u);
				} else if (a.getCmd().equalsIgnoreCase("GETONTOLOGY")) { // Check
					processGetOntology(a, u);
				} else if (a.getCmd().equalsIgnoreCase("CREATEANDJOIN")) { // Check
					processCreateAndJoinMap(a, u);
				} else if (a.getCmd().equalsIgnoreCase("GET-TEMPLATES")) { // Check
					processAuthoringGetTemplates(u, false);
				}
			} else {
				myServer.debugLog("User is null (maybe logged out before) --> Action ignored: " + a.toString());
			}
		}
	}

	private void processTemplateDetails(Action a, User u) {
		ActionPackage ap = ActionFactory.getTemplateDetails(a.getParameter("TEMPLATE"));
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());
	}

	private void processCreateAndJoinMap(Action a, User u) {
		if (Map.getMapID(a.getParameter("MAPNAME")) == -1) {
			Map m = new Map(a.getParameter("MAPNAME"), Template.getTemplateID(a.getParameter("TEMPLATE")), u.getUserID(), null);
			m.saveToDatabase(this);

			myServer.currentState.maps.put(m.getId(), m);
			myServer.currentState.mapUsers.put(m.getId(), new Vector<User>());

			// m.generateMapConfigurationFile();
			ActionPackage ap = ActionFactory.getNewMapAction(m);
			doCFLogging(ap);
			addToAllUsersActionQueue(ap);

			Action joinMap = ActionFactory.joinMap(m.getId());
			if (a.getParameter("XMLTEXT") != null) {
				joinMap.addParameter("XMLTEXT", a.getParameter("XMLTEXT"));
			}
			processJoin(joinMap, u);
		} else {
			ActionPackage ap = ActionFactory.error("Session already exists! Please choose a different name");
			doCFLogging(ap);
			addToUsersActionQueue(ap, u.getSessionID());
		}

	}

	private void processGetOntology(Action a, User u) {
		int mapID = getMapIDFromAction(a);
		ActionPackage ap = ActionFactory.getOntology(mapID);
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());
	}

	private void processGetAllOntologiesAndTemplates(User u) {
		// Returns a List of all Ontologies and Templates
		ActionPackage ap = ActionFactory.getAllOntologiesAndTemplates();
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());
	}

	private void processMapDetails(Action a, String sessionID) {
		ActionPackage ap = ActionFactory.getMapDetails((Integer.parseInt(a.getParameter("MAP-ID"))), myServer.currentState);
		doCFLogging(ap);
		addToUsersActionQueue(ap, sessionID);
	}

	/**
	 * Generate response to list all active maps on server
	 * 
	 * @param a
	 * @param u
	 */
	private void processList(Action a, User u) {
		myServer.debugLog("Processing request: List maps");

		ActionPackage ap = ActionFactory.listMaps(myServer.currentState, u.getUserID());
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());
	}

	private void processLeaveMap(Action a, User u) {

		int mapID = getMapIDFromAction(a);

		ActionPackage ap1 = ActionFactory.forcedClose();
		doCFLogging(ap1);
		addToUsersActionQueue(ap1, u.getSessionID());

		// Leave the map
		ActionPackage ap2 = ActionFactory.leaveMap(mapID);
		doCFLogging(ap2);
		addToUsersActionQueue(ap2, u.getSessionID());

		ActionPackage ap =  ActionFactory.userEventUserLeave(mapID, u.getNickname());
		doCFLogging(ap);
		addToAllUsersOnMapActionQueue(ap, mapID);

		this.usersToBeRemovedFromMaps.put(mapID, u);

		// Remove Awareness Cursor
		removeAwarenessCursor(mapID, u);

		// Remove Locks
		removeLocks(mapID, u);
	}

	private void removeAwarenessCursor(int mapID, User u) {
		int elementID = Element.getAwarenessCursorElementID(mapID, u.getUserID());
		// 0 means that there is no awareness cursor of this user on the map
		if (elementID != 0) {
			// Create new revision of the map
			Revision r = new Revision(mapID, u.getUserID());
			r.saveToDatabase();

			// Set elements.end_revision_id to new Revision for the main element
			Element.updateEndRevisionID(elementID, r.getId());

			ActionPackage ap = ActionFactory.deleteElement(mapID, elementID, u.getNickname());
			doCFLogging(ap);
			addToAllUsersButMySelfOnMapActionQueue(ap, mapID, u);
		}
	}

	private void removeLocks(int mapID, User u) {
		Action a = Element.removeLastActiveLockOfUser(u, mapID);

		// If there is an active lock of this user
		if (a != null) {
			processUpdateElement(a, u);
		}
	}

	private void processLogin(Action a, String sessionID) throws SQLException {
		synchronized (mapUsersLock) {
			myServer.debugLog("Enable lock mapUsersLock from processLogin Part");
			// Check if session ID is already assigned to a user --> Inactive
			// the old user
			User oldUser = null;
			
			/*
			 * This code allows a user to kick out a user already logged in with the same ID/PWD
			 */
			String autoLogoutOnLoginStr = myServer.conf.parameters.get("Auto-Logout-On-Login");
			boolean autoLogoutOnLogin = false;
			
			if (autoLogoutOnLoginStr != null) {
				autoLogoutOnLogin = Boolean.parseBoolean(autoLogoutOnLoginStr);
			}
			
			if(autoLogoutOnLogin){
				synchronized (userIdToSessionLock) {
					myServer.debugLog("Enable lock userIdToSessionLock from processLogin");
					synchronized (sessionToUserLock) {
						myServer.debugLog("Enable lock sessionToUserLock from processLogin");
						
						if(myServer.currentState.userIdToSession.containsKey(a.getParameter("USERNAME"))){
							String oldSessionId = myServer.currentState.userIdToSession.remove(a.getParameter("USERNAME"));
							myServer.currentState.userIdToSession.put(a.getParameter("USERNAME"), sessionID);
							
							if(myServer.currentState.sessionToUser.containsKey(oldSessionId)){
								User tmpUser = myServer.currentState.sessionToUser.remove(oldSessionId);
								myServer.currentState.sessionToUser.put(sessionID, tmpUser);
								
							}
							else{
								myServer.debugLog("sessionToUser does not contain key:" + oldSessionId);
							}
							
							synchronized (addToGWTUserQueueAndSendActionsLock) {
								myServer.debugLog("Enable lock addToGWTUserQueueAndSendActionsLock from processLogin");
								if(myServer.currentState.actionPackagesForGWTClients.containsKey(oldSessionId)){
									Vector<ActionPackage> tmp = myServer.currentState.actionPackagesForGWTClients.remove(oldSessionId);
									myServer.currentState.actionPackagesForGWTClients.put(sessionID, tmp);
									
									Vector<ActionPackage> v = new Vector<ActionPackage>();
									ActionPackage apKickOut = ActionFactory.getKickOutAction();
									doCFLogging(apKickOut);
									v.add(apKickOut);
									myServer.currentState.session2Remove.put(oldSessionId, v);
									
								}
								myServer.debugLog("Disable lock addToGWTUserQueueAndSendActionsLock from processLogin");
							}
							
							synchronized (addToRMIUserQueueAndSendActionsLock) {
								myServer.debugLog("Enable lock addToRMIUserQueueAndSendActionsLock from processLogin");
								if(myServer.currentState.actionPackagesForRMIClients.containsKey(oldSessionId)){
									Vector<ActionPackage> tmp = myServer.currentState.actionPackagesForRMIClients.remove(oldSessionId);
									myServer.currentState.actionPackagesForRMIClients.put(sessionID, tmp);
								}
								myServer.debugLog("Disable lock addToRMIUserQueueAndSendActionsLock from processLogin");
							}
						}
						
						myServer.debugLog("Disable lock sessionToUserLock from processLogin");
					}
					myServer.debugLog("Disable lock userIdToSessionLock from processLogin");
				}
			}
			

			synchronized (sessionToUserLock) {
				myServer.debugLog("Enable lock sessionToUserLock from processLogin");
				oldUser = myServer.currentState.sessionToUser.get(sessionID);
				myServer.debugLog("Disable lock sessionToUserLock from processLogin");
			}	
			

			if (oldUser != null) {

				synchronized (userMapsLock) {
					myServer.debugLog("Enable lock userMapsLock from processLogin");

					for (Integer mapID : myServer.currentState.userMaps.get(oldUser)) {
						ActionPackage ap =  ActionFactory.userEventUserLeave(mapID, oldUser.getNickname());
						doCFLogging(ap);
						addToAllUsersOnMapActionQueue(ap, mapID);

						myServer.currentState.mapUsers.get(mapID).remove(oldUser);

						synchronized (addToRMIUserQueueAndSendActionsLock) {
							myServer.debugLog("Enable lock addToRMIUserQueueAndSendActionsLock from processLogin");
							myServer.currentState.actionPackagesForRMIClients.remove(sessionID);
							myServer.debugLog("Enable lock addToRMIUserQueueAndSendActionsLock from processLogin");
						}

						synchronized (addToGWTUserQueueAndSendActionsLock) {
							myServer.debugLog("Enable lock addToGWTUserQueueAndSendActionsLock from processLogin");
							myServer.currentState.actionPackagesForGWTClients.remove(sessionID);
							myServer.debugLog("Disable lock addToGWTUserQueueAndSendActionsLock from processLogin");
						}

						// Remove Awareness Cursor
						removeAwarenessCursor(mapID, oldUser);

						// Remove Locks
						removeLocks(mapID, oldUser);
					}
					myServer.currentState.userMaps.remove(oldUser);

					myServer.debugLog("Disable lock userMapsLock from processLogin");
				}

			}

			// Returns in any case (login successful or not) a new User.
			// However, if
			// login failed, then the User will not have a nickname and a
			// password.
			User u = User.login(a.getParameter("USERNAME"), a.getParameter("PW"));

			// Differentiate between GWT, RMI and WS clients
			// TODO Implement WS client handling if required.
			Vector<ActionPackage> v = new Vector<ActionPackage>();

			if (("RMI").equals(a.getParameter("METHOD"))) {
				u.setUsingWebservice(true);
				myServer.currentState.actionPackagesForRMIClients.put(sessionID, v);
			} else {
				myServer.currentState.actionPackagesForGWTClients.put(sessionID, v);
			}

			// This is required to send the answer later
			myServer.currentState.sessionToUser.put(sessionID, u);
			myServer.currentState.userIdToSession.put(a.getParameter("USERNAME"),sessionID);

			// Correct username and password combination
			if (u.getNickname() != null) {

				// Check if username is already used by another client --> Send
				// error
				for (User loggedInUser : myServer.currentState.userMaps.keySet()) {
					if (loggedInUser.getNickname().equalsIgnoreCase(u.getNickname())) {
						// Username already in use...
						
						ActionPackage ap = ActionFactory.failedLogin("Login failed. Username already in use");
						doCFLogging(ap);
						addToUsersActionQueue(ap, sessionID);
						this.userFailedToLogin = sessionID;
						return;
					}
				}

				// Username not in use, everything ok
				u.setSessionID(sessionID);

				ActionPackage ap = ActionFactory.confirmLogin(u.getNickname(), u.getRole());
				doCFLogging(ap);
				addToUsersActionQueue(ap, sessionID);
				myServer.log("Login successful. Username: " + u.getNickname() + ", Role: " + u.getRole());

				// Add mapping to get all maps of a user later
				myServer.currentState.userMaps.put(u, new Vector<Integer>());
			}

			// Login failed
			else {
				String error = "Login failed. Username (" + a.getParameter("USERNAME") + ") or password (" + a.getParameter("PW") + ") wrong";
				myServer.log(error);

				ActionPackage ap = ActionFactory.failedLogin(error);
				doCFLogging(ap);
				addToUsersActionQueue(ap, sessionID);
				this.userFailedToLogin = sessionID;
			}
			myServer.debugLog("Disable lock mapUsersLock from processLogin");
		}
	}

	private void processLogout(Action a, User u) {

		// Leave all maps, remove awareness-cursors and locks

		synchronized (userMapsLock) {
			myServer.debugLog("Enable lock userMapsLock from processLogout");

			for (Integer mapID : myServer.currentState.userMaps.get(u)) {
				processLeaveMap(ActionFactory.getLeaveMapAction(mapID), u);
			}
			myServer.debugLog("Disable lock userMapsLock from processLogout");
		}

		// Send Logout
		ActionPackage ap = ActionFactory.logOut();
		doCFLogging(ap);
		addToUsersActionQueue(ap, u.getSessionID());

		// Remove user from push list
		this.userToBeRemoved = u.getSessionID();
	}

	private void processJoin(Action a, User u) {

		int mapID = getMapIDFromAction(a);

		// Check if map exists
		if (Map.isExisting(mapID)) {
			synchronized (DeleteUpdateJoinActionLock) {

			// If first user on the map
			synchronized (mapUsersLock) {
				myServer.debugLog("Enable lock mapUsersLock from processJoin");
				if (myServer.currentState.mapUsers.get(mapID) == null) {
					myServer.currentState.mapUsers.put(mapID, new Vector<User>());
				}
				// Add user to the active users on the map
				myServer.currentState.mapUsers.get(mapID).add(u);

					// Add the map to the user's maplist
					synchronized (userMapsLock) {
						myServer.debugLog("Enable lock userMapsLock from processJoin");
						myServer.currentState.userMaps.get(u).add(mapID);
						myServer.debugLog("Disable lock userMapsLock from processJoin");
					}
					myServer.debugLog("Disable lock mapUsersLock from processJoin");
				}

				// Generate new revision for the map
				Revision r = new Revision(mapID, "User join", u.getUserID());
				r.saveToDatabase();

				// Add to users action queue
				ActionPackage ap = ActionFactory.joinMap(mapID, myServer.currentState);
				doCFLogging(ap);
				addToUsersActionQueue(ap, u.getSessionID());

				// Notify all users on map that a new user joined
				ActionPackage ua = ActionFactory.userEventUserJoin(mapID, u.getNickname());
				doCFLogging(ua);
				addToAllUsersOnMapActionQueue(ua, mapID);

				// Send list of all users already active on the map to the new
				// client
				ActionPackage ul = ActionFactory.userEventUserList(mapID, myServer.currentState);
				doCFLogging(ul);
				addToUsersActionQueue(ul, u.getSessionID());

				// Load existing elements from database
				ActionPackage completeActionsHistory = getAllActionsHappenedBefore(mapID, u);
				
				Action joinComplete = new Action("JOIN-COMPLETE", "INFO");
				
				// GWT clients do not need the complete history
				if("TRUE".equalsIgnoreCase(a.getParameter("SUMMARY"))) {
					ActionPackage filteredActions = filterForJoin(completeActionsHistory);
					filteredActions.addAction(joinComplete);
					
					doCFLogging(filteredActions);
					addToUsersActionQueue(filteredActions, u.getSessionID());
				}
				// AI clients need it...
				else {
					completeActionsHistory.addAction(joinComplete);
					
					doCFLogging(completeActionsHistory);
					addToUsersActionQueue(completeActionsHistory, u.getSessionID());
				}
				
				//Needed when user imports a largo/argunaut file
				if (a.getParameter("XMLTEXT") != null) {
					ActionPackage pack = new ActionPackage();
					Action action = new Action("IMPORT", "MAP");
					action.addParameter("MAP-ID", Integer.toString(mapID));
					action.addParameter("XMLTEXT", a.getParameter("XMLTEXT"));
					pack.addAction(action);
					addToUsersActionQueue(pack, u.getSessionID());
				}
			}
		}
	}
	
	/**
	 * Joining users usually don't need the complete history of actions
	 * so this procedure iterates over the history and generates
	 * a current-state-ActionPackage
	 * @param The ActionPackage with the whole history of actions
	 * @return Only necessary 
	 */
	private ActionPackage filterForJoin(ActionPackage p) {
		ActionPackage newActionPackage = new ActionPackage();
		
		//Note: Integer is used as key for sorting purposes
		//Temporarily stores all parsed CREATE-Actions
		TreeMap<Integer, Action> createActions = new TreeMap<Integer, Action>();
		
		//Temporarily stores all parsed UPDATE-Actions. Every UPDATE-Action
		//for an element after the first one will update this first UPDATE-Action
		//(and won't be put into the Map)
		TreeMap<Integer, Action> updateActions = new TreeMap<Integer, Action>();
		
		Vector<Action> chatMessageActions = new Vector<Action>();
		
		for (Action action : p.getActions()) {
			if (action.getCmd().equalsIgnoreCase("CREATE-ELEMENT")) {
				createActions.put(Integer.parseInt(action.getParameter("ID")), action);
			}
			//Second condition filters LOCK-Update-Packages, which ain't needed for user joins
			else if (action.getCmd().equalsIgnoreCase("UPDATE-ELEMENT") && action.getParameter("STATUS") == null) {
				String elementId = action.getParameter("ID");
				//If there's already an UPDATE-ACTION for the element with elementId 
				//then update all existing parameters and add the new ones
				//else just add a new UPDATE-ACTION
				if (updateActions.containsKey(Integer.parseInt(elementId))) {
					Vector<String> parameterNames = updateActions.get(Integer.parseInt(elementId)).getParameterNames();
					Action outdatedAction = updateActions.get(Integer.parseInt(elementId));
					for (Parameter parameter : action.getParameters()) {
						if (parameterNames.contains(parameter.getName())) {
							//This DIRECTION condition is needed because of the special 
							//mechanism of the starting/ending-Connectors of a link
							//The Problem is that atm we cannot navigate from a link 
							//over the corresponding connector to the linked element's object
							//
							//TODO Another known problem is that if the UPDATE-ACTIONS for a
							//certain link element only consist of DIRECTION changes 
							//then it may result in a "ghost"-UPDATE-Action which
							//appears in the UPDATE-Actions list but does not change anything,
							//which is the case when the last direction update switches the 
							//link's direction to the one it had on creation
							if (parameter.getName().equals("DIRECTION")) {
								outdatedAction = Action.removeParameter(outdatedAction, "DIRECTION");
							} else {
								outdatedAction.replaceParameter(parameter.getName(), parameter.getValue());
							}
						}
						else {
							outdatedAction.addParameter(parameter.getName(), parameter.getValue());
						}
					}
					updateActions.put(Integer.parseInt(elementId), outdatedAction);
				}
				else {
					updateActions.put(Integer.parseInt(elementId), action);
				}
			}
			else if (action.getCmd().equalsIgnoreCase("DELETE-ELEMENT")) {
				createActions.remove(Integer.parseInt(action.getParameter("ID")));
			}
			else if (action.getCmd().equalsIgnoreCase("CHAT-MSG")) {
				newActionPackage.addAction(action);
			}
		}
		
		for (Action action : createActions.values()) {
			newActionPackage.addAction(action);
		}
		for (Integer key : updateActions.keySet()) {
			//Work-Around info: Filter UPDATE-ACTIONS that do not have an element
			//which could happen if an edited element was deleted later
			//Atm there's no other way to deal with this because the create und update actions
			//are not added to the new ActionPackage in the order they actually occurred
			if (createActions.containsKey(key)) {
				newActionPackage.addAction(updateActions.get(key));
			}
		}
		
		return newActionPackage;
	}

	/**
	 * Get all actions that happened on this map before
	 */
	private ActionPackage getAllActionsHappenedBefore(int mapID, User u) {
		ActionPackage p = Map.getCompleteElementInformation(mapID);
		
		return p;
	}

	private int getMapIDFromAction(Action a) {
		int mapID = 0;

		try {
			mapID = Integer.parseInt(a.getParameter("MAP-ID"));
		} catch (Exception e) {
			myServer.debugLog("ERROR: No valid map-id.");
		}

		return mapID;
	}

	/**
	 * Process all actions that are somewhat connected to a specific map, e.g.
	 * element creation and modification
	 * 
	 * @param a
	 * @param u
	 */
	private void workOnMapActions(Action a, User u) {
		if (a.getCmd().equals("CREATE-ELEMENT")) { // Check
			processCreateElement(a, u);
		} else if (a.getCmd().equals("UPDATE-ELEMENT")) { // Check
			processUpdateElement(a, u);
		} else if (a.getCmd().equals("UPDATE-CURSOR-POSITION")) { // Check
			processCursorUpdate(a, u);
		} else if (a.getCmd().equals("DELETE-ELEMENT")) { // Check
			processDeleteElement(a, u);
		} else if (a.getCmd().equals("UNDO")) { // TODO Implement an UNDO
			processUndo(a, u);
		}
	}

	private void distributeToAllUsersButMeWithoutSaving(Action a, User u) {
		int mapID = getMapIDFromAction(a);

		ActionPackage ap = ActionPackage.wrapAction(a);
		doCFLogging(ap);
		addToAllUsersButMySelfOnMapActionQueue(ap, mapID, u);
	}

	private void distributeToAllUsersWithoutSaving(Action a, User u) {
		int mapID = getMapIDFromAction(a);

		ActionPackage ap = ActionPackage.wrapAction(a);
		doCFLogging(ap);
		addToAllUsersOnMapActionQueue(ap, mapID);
	}

	private void processCreateElement(Action a, User u) {
		int mapID = getMapIDFromAction(a);

		Vector<String> parents = a.getParameterVector("PARENT");
		if (parents != null) {
			if (!parentsDoExist(a.getParameterVector("PARENT"), a.getParameter("TYPE"))) {
				myServer.log("One of the parents is no longer active. Create element failed.");
				ActionPackage ap = ActionFactory.error("One of the parents is no longer present on map. Create element failed");
				doCFLogging(ap);
				addToUsersActionQueue(ap, u.getSessionID());
				return;
			}
		}

		// Create new revision of the map
		Revision r = new Revision(mapID, u.getUserID());
		r.saveToDatabase();

		// Create an element in the database with type information; replace
		// parents (LAST-ID) with correct top level element's ID
		Element e = new Element(mapID, a, r.getId(), myServer.currentState);

		// Replace TIME, ROOTELEMENTID, PARENT with actual values instead of
		// place holders
		a = replacePlaceHoldersAddIDsAddMetadata(a, e.getId(), u.getNickname());

		// Save action parameters for the revision
		ActionParameter.saveParametersForRevision(r.getId(), e.getId(), a);

		// Add to users' action queues
		ActionPackage ap = ActionPackage.wrapAction(a);
		doCFLogging(ap);
		addToAllUsersOnMapActionQueue(ap, mapID);
	}

	private boolean parentsDoExist(Vector<String> parameterVector, String type) {
		for (String p : parameterVector) {
			int elementID = -1;
			if (p.equalsIgnoreCase("LAST-ID")) {
				if ("LAST-ID".equalsIgnoreCase(p)) {
					elementID = myServer.currentState.lastTopLevelElementID;
				}
			} else {
				elementID = Integer.parseInt(p);
			}

			if (!Element.isElementActive(elementID)) {
				myServer.debugLog("ERROR: Element " + elementID + " is no longer active!");
				return false;
			} else {
				myServer.log("Element " + elementID + " is still active.");
			}
		}
		return true;
	}

	public int processCreatePreDefinedElement(Action a, int mapID, int userID) {

		Revision r = null;

		if (a.getParameter("TIME") != null && !a.getParameter("TIME").equalsIgnoreCase("CURRENT-TIME")) {
			r = new Revision(mapID, userID, Long.parseLong(a.getParameter("TIME")));
		} else {
			r = new Revision(mapID, userID);
		}
		// Create new revision of the map

		r.saveToDatabase();

		// Create an element in the database with type information; replace
		// parents (LAST-ID) with correct top level element's ID
		Element e = new Element(mapID, a, r.getId(), myServer.currentState);

		// Replace TIME, ROOTELEMENTID, PARENT with actual values instead of
		// place holders
		a = replacePlaceHoldersAddIDsAddMetadata(a, e.getId(), User.getName(userID));

		// Save action parameters for the revision
		ActionParameter.saveParametersForRevision(r.getId(), e.getId(), a);

		return e.getId();
	}

	/**
	 * Replaces TIME, ROOTELEMENTID, PARENT with actual values instead of place
	 * holders
	 * 
	 * @param a
	 * @return
	 */
	private Action replacePlaceHoldersAddIDsAddMetadata(Action a, int ID, String username) {

		int mapID = getMapIDFromAction(a);

		boolean usernamePresent = false, idPresent = false;
		boolean relation = false;
		boolean addRootElementID = false;

		for (Parameter p : a.getParameters()) {

			if (p.getName().equalsIgnoreCase("USERNAME")) {
				usernamePresent = true;
			} else if (p.getName().equalsIgnoreCase("TYPE")) {
				if (p.getValue().equalsIgnoreCase("relation") || p.getValue().equalsIgnoreCase("emptyrelation")) {
					addRootElementID = true;
					relation = true;
				} else if (p.getValue().equalsIgnoreCase("box") || p.getValue().equalsIgnoreCase("emptybox")) {
					addRootElementID = true;
				}
			} else if (p.getName().equalsIgnoreCase("ID")) {
				idPresent = true;
			}

			// Replace LAST-ID of parent parameters
			// The secondLastTopLevelElementID is required if the user creates a
			// box and a relation in the same step to avoid the relation to use
			// itself as parent
			if ("LAST-ID".equalsIgnoreCase(p.getValue())) {
				if (!relation) {
					p.setValue(myServer.currentState.lastTopLevelElementID + "");
				} else {
					p.setValue(myServer.currentState.secondLastTopLevelElementID + "");
				}
			}

			// Replace CURRENT-TIME of time parameters
			else if ("CURRENT-TIME".equalsIgnoreCase(p.getValue())) {
				p.setValue(System.currentTimeMillis() + "");
			}
		}

		if (!idPresent) {
			a.addParameter("ID", ID + "");
		}

		if (!usernamePresent) {
			a.addParameter("USERNAME", username);
		}

		if (addRootElementID) {
			if (a.getParameter("ROOTELEMENTID") == null) {
				a.addParameter("ROOTELEMENTID", Map.getNewRootElementID(mapID) + "");
			}
		}

		return a;
	}

	private void processUpdateElement(Action a, User u) {
		a.addParameter("RECEIVED", System.currentTimeMillis() + "");

		int mapID = getMapIDFromAction(a);
		int elementID = Integer.parseInt(a.getParameter("ID"));

		synchronized (DeleteUpdateJoinActionLock) {

			// Action is already obsolete
			if (Element.getLastModificationTime(elementID) > Long.parseLong(a.getParameter("RECEIVED"))) {
				return;
			}

			if (!Element.isElementActive(elementID)) {
				myServer.log("Element " + elementID + " is no longer active. Update failed.");
				ActionPackage ap = ActionFactory.error("Element is no longer present on map. Update failed");
				doCFLogging(ap);
				addToUsersActionQueue(ap, u.getSessionID());
				return;
			}

			// Create new revision of the map
			Revision r = new Revision(mapID, u.getUserID());
			r.saveToDatabase();

			// If it is a lock / unlock update of an element, check if element is already locked or unlocked
			if (a.getParameter("STATUS") != null) {
				String lockStatus = Element.getLastValueOfElementParameter(elementID, "STATUS");
				if (a.getParameter("STATUS").equalsIgnoreCase(lockStatus)) {
					return;
				}
			}

			// Update elements last update time
			Element.updateModificationTime(elementID, Long.parseLong(a.getParameter("RECEIVED")));

			// Add the username, etc.
			a = replacePlaceHoldersAddIDsAddMetadata(a, elementID, u.getNickname());

			// Save action parameters for the revision
			ActionParameter.saveParametersForRevision(r.getId(), elementID, a);
			
			// Add to users' action queues
			if (a.getCmd().equals("UPDATE-CURSOR-POSITION")) {
				ActionPackage ap = ActionPackage.wrapAction(a);
				doCFLogging(ap);
				addToAllUsersButMySelfOnMapActionQueue(ap, mapID, u);
			} else {
				ActionPackage ap = ActionPackage.wrapAction(a);
				doCFLogging(ap);
				addToAllUsersOnMapActionQueue(ap, mapID);
			}
		}
	}

	private void processUpdateElementLocal(Action a, int userID) {
		int mapID = getMapIDFromAction(a);

		int elementID = Integer.parseInt(a.getParameter("ID"));

		// Create new revision of the map
		Revision r = new Revision(mapID, userID);
		r.saveToDatabase();

		// Add the username, etc.
		a = replacePlaceHoldersAddIDsAddMetadata(a, elementID, User.getName(userID));

		// Save action parameters for the revision
		ActionParameter.saveParametersForRevision(r.getId(), elementID, a);
	}

	private void processCursorUpdate(Action a, User u) {
		if ("TRUE".equalsIgnoreCase(a.getParameter("PERSISTENT"))) {
			processPersistentCursorUpdate(a, u);
		} else {
			distributeToAllUsersButMeWithoutSaving(a, u);
		}
	}

	private void processPersistentCursorUpdate(Action a, User u) {
		processUpdateElement(a, u);
	}

	private void processDeleteElement(Action a, User u) {

		int mapID = getMapIDFromAction(a);
		int elementID = Integer.parseInt(a.getParameter("ID"));

		synchronized (DeleteUpdateJoinActionLock) {

			if (!Element.isElementActive(elementID)) {
				myServer.log("Element " + elementID + " is no longer active. Delete failed.");
				ActionPackage ap = ActionFactory.error("Element is already deleted. Delete failed");
				doCFLogging(ap);
				addToUsersActionQueue(ap, u.getSessionID());
				return;
			}

			// Create new revision of the map
			Revision r = new Revision(mapID, u.getUserID());
			r.saveToDatabase();

			ActionParameter.saveParametersForRevision(r.getId(), elementID, a);

			deleteElementAndChildren(elementID, r.getId(), mapID, u.getNickname());
		}
	}

	private void deleteElementAndChildren(int elementID, int revisionID, int mapID, String username) {
		Element.updateEndRevisionID(elementID, revisionID);

		Vector<Integer> childElements = Element.getChildElementIDs(elementID);

		for (Integer i : childElements) {
			deleteElementAndChildren(i, revisionID, mapID, username);
		}
		
		ActionPackage ap = ActionFactory.deleteElement(mapID, elementID, username);
		doCFLogging(ap);
		addToAllUsersOnMapActionQueue(ap, mapID);

	}

	private void processUndo(Action a, User u) {
	}

	/**
	 * To send a error message to the client (which says that either username or
	 * password was wrong), we needed his sessionID stored. However, we no
	 * longer need it after sending out the error message. As a matter of fact,
	 * it would be even causing problems later. Thus, we drop all sessionIDs
	 * from users that did not login correctly
	 */
	private void removeUserThatDidNotLoginCorrectly() {
		if (this.userFailedToLogin != null) {
			synchronized (sessionToUserLock) {
				myServer.debugLog("Enable lock sessionToUserLock from removeUserThatDidNotLoginCorrectly");
				myServer.currentState.sessionToUser.remove(this.userFailedToLogin);
				myServer.debugLog("Disable lock sessionToUserLock from removeUserThatDidNotLoginCorrectly");
			}
			this.userFailedToLogin = null;
		}
	}

	/**
	 * This method is used to remove a user from all relevant HashMaps AFTER
	 * sending him/her the actions left in his/her queue
	 */
	private void removeUsersWhoLeftAMap() {
		for (Integer mapID : this.usersToBeRemovedFromMaps.keySet()) {
			User u = this.usersToBeRemovedFromMaps.get(mapID);

			synchronized (sessionToUserLock) {
				myServer.debugLog("Enable lock sessionToUserLock from removeUsersWhoLeftAMap");
				myServer.debugLog("Tried to remove user " + u.getSessionID() + ": " + myServer.currentState.mapUsers.get(mapID).remove(u));
				myServer.debugLog("Disable lock sessionToUserLock from removeUsersWhoLeftAMap");
			}

			synchronized (userMapsLock) {
				myServer.debugLog("Enable lock userMapsLock from removeUsersWhoLeftAMap");
				myServer.currentState.userMaps.get(u).remove(mapID);
				myServer.debugLog("Disable lock userMapsLock from removeUsersWhoLeftAMap");
			}
		}

		this.usersToBeRemovedFromMaps.clear();
	}

	private void removeUserWhoLoggedOff() {
		if (this.userToBeRemoved != null) {

			if (myServer.currentState.sessionToUser.get(this.userToBeRemoved) != null) {
				synchronized (userMapsLock) {
					myServer.debugLog("Enable lock userMapsLock from removeUserWhoLoggedOff");
					myServer.currentState.userMaps.remove(myServer.currentState.sessionToUser.get(this.userToBeRemoved));
					myServer.debugLog("Disable lock userMapsLock from removeUserWhoLoggedOff");
				}
			}
			User loggedOutUser = myServer.currentState.sessionToUser.remove(this.userToBeRemoved);
			
			synchronized (userIdToSessionLock) {
				myServer.debugLog("Enable lock userIdToSessionLock from processLogin");
				if(myServer.currentState.userIdToSession.containsKey(loggedOutUser.getNickname())){
					myServer.currentState.userIdToSession.remove(loggedOutUser.getNickname());
				}
				myServer.debugLog("Disable lock userIdToSessionLock from processLogin");
			}

			synchronized (addToRMIUserQueueAndSendActionsLock) {
				myServer.debugLog("Enable lock addToRMIUserQueueAndSendActionsLock from removeUserWhoLoggedOff");
				myServer.currentState.actionPackagesForRMIClients.remove(this.userToBeRemoved);
				myServer.debugLog("Disable lock addToRMIUserQueueAndSendActionsLock from removeUserWhoLoggedOff");
			}

			synchronized (addToGWTUserQueueAndSendActionsLock) {
				myServer.debugLog("Enable lock addToGWTUserQueueAndSendActionsLock from removeUserWhoLoggedOff");
				myServer.currentState.actionPackagesForGWTClients.remove(this.userToBeRemoved);
				myServer.debugLog("Disable lock addToGWTUserQueueAndSendActionsLock from removeUserWhoLoggedOff");
			}

			this.userToBeRemoved = null;
		} else {
			myServer.debugLog("No user logout detected.");
		}
	}

	
	/**
	 * @param p
	 * @param sessionID
	 * @param flagCFLogging
	 * 			true -> p is logged by CF logger
	 * 			false-> p is not logged by CF logger
	 */
	public void addToUsersActionQueue(ActionPackage p, String sessionID) {
		
		synchronized (sessionToUserLock) {
			myServer.debugLog("Enable lock sessionToUserLock from addToUsersActionQueue");
			
			addMetaInformation(p, sessionID);
			
			if(myServer.currentState.sessionToUser.get(sessionID) != null) {
				if (!myServer.currentState.sessionToUser.get(sessionID).isUsingWebservice()) {
					synchronized (addToGWTUserQueueAndSendActionsLock) {
						myServer.debugLog("Enable lock addToGWTUserQueueAndSendActionsLock from addToUsersActionQueue");
						Vector<ActionPackage> packages = myServer.currentState.actionPackagesForGWTClients.get(sessionID);
						if (packages != null) {
							packages.add(p);
						}
						myServer.debugLog("Disable lock addToGWTUserQueueAndSendActionsLock from addToUsersActionQueue");
					}
				} else {
					synchronized (addToRMIUserQueueAndSendActionsLock) {
						myServer.debugLog("Enable lock addToRMIUserQueueAndSendActionsLock from addToUsersActionQueue");
						Vector<ActionPackage> packages = myServer.currentState.actionPackagesForRMIClients.get(sessionID);
						if (packages != null) {
							packages.add(p);
						}
						myServer.debugLog("Disable lock addToRMIUserQueueAndSendActionsLock from addToUsersActionQueue");
					}
				}
			}
			else {
				// TODO Remove the non-existing user from all lists
			}
			myServer.debugLog("Disable lock sessionToUserLock from addToUsersActionQueue");
		}
	}

	private void addToAllUsersOnMapActionQueue(ActionPackage p, int mapID) {
		synchronized (mapUsersLock) {
			myServer.debugLog("Enable lock mapUsersLock from addToAllUsersOnMapActionQueue");
			
			for (User u : myServer.currentState.mapUsers.get(mapID)) {
				addToUsersActionQueue(p, u.getSessionID());
				myServer.debugLog("Added to user's queue: ");
				myServer.debugLog(p.toString());
			}
			myServer.debugLog("Disable lock mapUsersLock from addToAllUsersOnMapActionQueue");
		}
	}

	private void addToAllUsersButMySelfOnMapActionQueue(ActionPackage p, int mapID, User me) {
		synchronized (mapUsersLock) {
			myServer.debugLog("Enable lock mapUsersLock from addToAllUsersButMySelfOnMapActionQueue");
			
			for (User u : myServer.currentState.mapUsers.get(mapID)) {
				if (!u.equals(me)) {
					addToUsersActionQueue(p, u.getSessionID());
					myServer.debugLog("Added to user's queue: ");
					myServer.debugLog(p.toString());
				}
			}
			myServer.debugLog("Disable lock mapUsersLock from addToAllUsersButMySelfOnMapActionQueue");
		}
	}
	
	private void addToAllUsersActionQueue(ActionPackage p) {
		synchronized (mapUsersLock) {
			myServer.debugLog("Enable lock mapUsersLock from addToAllUsersActionQueue");
			
			for (User u : myServer.currentState.userMaps.keySet()) {
					addToUsersActionQueue(p, u.getSessionID());
					myServer.debugLog("Added to user's queue: ");
					myServer.debugLog(p.toString());
			}
			myServer.debugLog("Disable lock mapUsersLock from addToAllUsersActionQueue");
		}
	}
	
	/**
	 * Server push to inform the Servlet that there are new Actions for the
	 * clients. The Servlet will then forward the Actions to the connected
	 * clients.
	 */
	public void sendActionsToConnectedClients() {

		// TODO Filter out empty user queues to reduce network load
		myServer.debugLog("@sendActionsToConnectedClients");
		
		
		synchronized (session2RemoveLock) {
			myServer.debugLog("Disable lock session2RemoveLock from sendActionsToConnectedClients");
			int toRemoveActions = 0;
			for (String s : myServer.currentState.session2Remove.keySet()) {
				toRemoveActions += myServer.currentState.session2Remove.get(s).size();
			}
			
			myServer.debugLog("@sendActionsToConnectedClients actionsNum:" + toRemoveActions);
			
			if (toRemoveActions > 0) {
				// Send actions to GWT users
				URL gwtServlet = null;
				try {
					gwtServlet = new URL(myServer.conf.parameters.get("Servlet URL"));
					HttpURLConnection servletConnection = (HttpURLConnection) gwtServlet.openConnection();
					servletConnection.setRequestMethod("POST");
					servletConnection.setDoOutput(true);

					ObjectOutputStream objOut = new ObjectOutputStream(servletConnection.getOutputStream());

					objOut.writeObject(myServer.currentState.session2Remove);
					objOut.flush();
					objOut.close();

					// Important! Even though, the answer is not needed, it is
					// required to actually execute the call.
					int result = servletConnection.getResponseCode();
					if (result != 200) {
						myServer.logError("PushServlet call failed, error code: " + result); // 200
						// =
						// successful
					}
					else {
						cleanSession2RemoveActionsSent();
					}
						
				} catch (MalformedURLException e) {
					myServer.debugLog(e.toString());
				} catch (IOException e) {
					myServer.debugLog(e.toString());
				}
			}
			myServer.debugLog("Disable lock session2RemoveLock from sendActionsToConnectedClients");
		}
		

		synchronized (addToGWTUserQueueAndSendActionsLock) {
			myServer.debugLog("Enable lock addToGWTUserQueueAndSendActionsLock from sendActionsToConnectedClients");

			// Check to avoid unnecessary calls
			int gwtActions = 0;
			for (String s : myServer.currentState.actionPackagesForGWTClients.keySet()) {
				gwtActions += myServer.currentState.actionPackagesForGWTClients.get(s).size();
			}

			myServer.debugLog("@sendActionsToConnectedClients actionsNum:" + gwtActions);
			
			if (gwtActions > 0) {
				// Send actions to GWT users
				URL gwtServlet = null;
				try {
					gwtServlet = new URL(myServer.conf.parameters.get("Servlet URL"));
					HttpURLConnection servletConnection = (HttpURLConnection) gwtServlet.openConnection();
					servletConnection.setRequestMethod("POST");
					servletConnection.setDoOutput(true);

					ObjectOutputStream objOut = new ObjectOutputStream(servletConnection.getOutputStream());

					objOut.writeObject(myServer.currentState.actionPackagesForGWTClients);
					objOut.flush();
					objOut.close();

					// Important! Even though, the answer is not needed, it is
					// required to actually execute the call.
					int result = servletConnection.getResponseCode();
					if (result != 200) {
						myServer.logError("PushServlet call failed, error code: " + result); // 200
						// =
						// successful
					}
					else {
						cleanGWTActionsSent();
					}
						
				} catch (MalformedURLException e) {
					myServer.debugLog(e.toString());
				} catch (IOException e) {
					myServer.debugLog(e.toString());
				}
			}
			myServer.debugLog("Disable lock addToGWTUserQueueAndSendActionsLock from sendActionsToConnectedClients");
		}
		
		// Send actions to RMI users
		// Check to avoid unnecessary calls

		synchronized (addToRMIUserQueueAndSendActionsLock) {
			myServer.debugLog("Enable lock addToRMIUserQueueAndSendActionsLock from sendActionsToConnectedClients");
			int rmiActions = 0;
			for (String s : myServer.currentState.actionPackagesForRMIClients.keySet()) {
				rmiActions += myServer.currentState.actionPackagesForRMIClients.get(s).size();
			}

			if (rmiActions > 0) {
				// Send actions to RMI users
				for (String s : myServer.currentState.actionPackagesForRMIClients.keySet()) {
					if (myServer.currentState.actionPackagesForRMIClients.get(s).size() > 0) {

						// Add meta information (number of update, create
						// actions +
						// one generic id for actions that belong together) to
						// each
						// package
						// This is required for the current feedback
						// implementation
							//for(ActionPackage p : myServer.currentState.actionPackagesForRMIClients.get(s))
						//{
						//	 addMetaInformation(p, s);
						//}

						sendToRMIClient(s, myServer.currentState.actionPackagesForRMIClients.get(s));
					}
				}

				cleanRMIActionsSent();
			}
			myServer.debugLog("Disable lock addToRMIUserQueueAndSendActionsLock from sendActionsToConnectedClients");
		}
	}

	private void sendToRMIClient(String user, Vector<ActionPackage> vp) {
		try {
			ClientInterface client = (ClientInterface) Naming.lookup("rmi://localhost:" + myServer.conf.parameters.get("RMI-Registry Port") + "/" + user);
			client.doActionPackagesOnClient(vp);
		} catch (Exception E) {
			E.printStackTrace();
		}
	}
	
	private void cleanSession2RemoveActionsSent() {
		for (String session : myServer.currentState.session2Remove.keySet()) {
			myServer.currentState.session2Remove.get(session).clear();
		}
		myServer.currentState.session2Remove.clear();
	}

	private void cleanGWTActionsSent() {
		for (String session : myServer.currentState.actionPackagesForGWTClients.keySet()) {
			myServer.currentState.actionPackagesForGWTClients.get(session).clear();
		}
	}

	private void cleanRMIActionsSent() {
		for (String session : myServer.currentState.actionPackagesForRMIClients.keySet()) {
			myServer.currentState.actionPackagesForRMIClients.get(session).clear();
		}
	}

	private void addMetaInformationAndLog(ActionPackage p, String sessionID) {
		int numActions = 0;
		
		for (Action a : p.getActions()) {
			if (a.getParameter("USERACTION-ID") != null) {
				return;
			}
		}
		
		for (Action a : p.getActions()) {
			// Count update and create actions
			if (a.getCmd().equalsIgnoreCase("UPDATE-ELEMENT") || a.getCmd().equalsIgnoreCase("CREATE-ELEMENT") || a.getCmd().equalsIgnoreCase("DELETE-ELEMENT")) {
				numActions++;
			}
		}

		// Nothing to add?
		if (numActions == 0) {
			return;
		}

		long time = System.currentTimeMillis();
		// System.out.println("addMetaInformationToPackage SESSION-ID:" +
		// sessionID);

		for (Action a : p.getActions()) {
			if (a.getCmd().equalsIgnoreCase("UPDATE-ELEMENT") || a.getCmd().equalsIgnoreCase("CREATE-ELEMENT") || a.getCmd().equalsIgnoreCase("DELETE-ELEMENT")) {
				a.addParameter("USERACTION-ID", sessionID + time);
				a.addParameter("NUM-ACTIONS", "" + numActions);
			}
		}
		try {
			myServer.logPackage2CF(p);
		} catch (Exception e) {
			myServer.debugLog(e.toString());
		}
	}
	
	private void addMetaInformation(ActionPackage p, String sessionID) {
		int numActions = 0;
		
		//to avoid adding meta-information twice, for example during a replay.
		for (Action a : p.getActions()) {
			if (a.getParameter("USERACTION-ID") != null) {
				return;
			}
		}
		
		//TODO check if this is necessary
		//only count Actions that have several steps 
		for (Action a : p.getActions()) {
			// Count update and create actions
			if (a.getCmd().equalsIgnoreCase("UPDATE-ELEMENT") || a.getCmd().equalsIgnoreCase("CREATE-ELEMENT") || a.getCmd().equalsIgnoreCase("DELETE-ELEMENT")) {
				numActions++;
			}
		}

		// Nothing to add?
		if (numActions == 0) {
			return;
		}

		long time = System.currentTimeMillis();
		// System.out.println("addMetaInformationToPackage SESSION-ID:" +
		// sessionID);

		for (Action a : p.getActions()) {
			if (a.getCmd().equalsIgnoreCase("UPDATE-ELEMENT") || a.getCmd().equalsIgnoreCase("CREATE-ELEMENT") || a.getCmd().equalsIgnoreCase("DELETE-ELEMENT")) {
				a.addParameter("USERACTION-ID", sessionID + time);
				a.addParameter("NUM-ACTIONS", "" + numActions);
			}
		}
	}
	
	public void doCFLogging(ActionPackage p) {

		try {
			myServer.logPackage2CF(p);
		} catch (Exception e) {
			myServer.debugLog(e.toString());
		}
	}
	
	
}
