package lasad.gwt.client.communication.objects;

import java.util.Vector;

import lasad.ActionProcessor;
import lasad.State;
import lasad.entity.Map;
import lasad.entity.Ontology;
import lasad.entity.Revision;
import lasad.entity.Template;
import lasad.entity.User;

public class ActionFactory {

	public static ActionPackage forcedClose() {
		ActionPackage p = new ActionPackage();

		Action a = new Action("FORCED-LOGOUT", "AUTH");
		a.addParameter("STATUS", "OK");

		p.addAction(a);
		return p;
	}

	public static ActionPackage logOut() {
		ActionPackage p = new ActionPackage();

		Action a = new Action("LOGOUT", "AUTH");
		a.addParameter("STATUS", "OK");
		p.addAction(a);
		return p;
	}

	public static ActionPackage leaveMap(int mapID) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("LEAVE", "MANAGEMENT");
		a.addParameter("MAP-ID", String.valueOf(mapID));

		p.addAction(a);
		return p;
	}

	public static ActionPackage error(String errorMessage) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("ERROR", "ERROR");
		a.addParameter("MESSAGE", errorMessage);

		p.addAction(a);
		return p;
	}

	public static ActionPackage confirmLogin(String nickname, String role) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("LOGIN", "AUTH");
		a.addParameter("STATUS", "OK");
		a.addParameter("USERNAME", nickname);
		a.addParameter("ROLE", role);
		p.addAction(a);
		return p;
	}

	public static ActionPackage failedLogin(String errorMessage) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("LOGIN-FAILED", "AUTH");
		a.addParameter("MESSAGE", errorMessage);
		p.addAction(a);
		return p;
	}

	public static ActionPackage heartbeatRequest() {
		ActionPackage p = new ActionPackage();

		Action a = new Action("HEARTBEATREQUEST", "SESSION");

		p.addAction(a);
		return p;
	}

	public static ActionPackage listMaps(State state, int userID) {
		ActionPackage p = new ActionPackage();

		Vector<Map> maps = Map.getMapList();

		String userRole = User.getRoleByID(userID);

		// Restrictions do not count for teachers and developers
		boolean ignoreRestriction = false;
		if ("Teacher".equals(userRole) || "Developer".equals(userRole)) {
			ignoreRestriction = true;
		}

		for (Map m : maps) {

			if (!ignoreRestriction) {
				
				// Is the current map restricted to specific users?
				if (m.getRestricted_to_user_id().size() > 0) {
					
					boolean userAllowed = false;
					for (int i = 0; i < m.getRestricted_to_user_id().size(); i++) {
						if (m.getRestricted_to_user_id().get(i) == userID) {
							userAllowed = true;
							break;
						}
					}
					if (!userAllowed) {
						continue;
					}
				}
			}

			Template t = Map.getTemplate(m.getId());

			Action action = new Action("LISTMAP", "MAP");
			action.addParameter("MAP-ID", m.getId() + "");
			action.addParameter("MAPNAME", m.getName());
			action.addParameter("CREATOR-ID", m.getCreator_user_id() + "");
			action.addParameter("CREATORNAME", User.getName(m.getCreator_user_id()));
			action.addParameter("TEMPLATETITLE", t.getTitle());
			action.addParameter("ONTOLOGYNAME", t.getOntologyNameFromDB());
			action.addParameter("TEMPLATENAME", t.getName());
			action.addParameter("CREATED", Revision.getTimeOfMapRevision(m.getId(), 0) + "");
			action.addParameter("MODIFIED", Revision.getTimeOfMapRevision(m.getId(), 1) + "");
			action.addParameter("ACTIVEUSERS", state.mapUsers.get(m.getId()).size() + "");

			p.addAction(action);
		}

		if (p.getActions().size() == 0) {
			Action endAction = new Action("LISTMAP", "MAP");
			endAction.addParameter("STATUS", "END");
			p.addAction(endAction);
		} else {
			p.getActions().lastElement().addParameter("STATUS", "END");
		}

		return p;
	}

	public Action deleteReplayElement(int mapElementID, String nickname, long time, int mapID) {
		// Build delete action for replay-client
		Action a = new Action("DELETE-ELEMENT", "REPLAY");
		a.addParameter("ID", mapElementID + "");
		a.addParameter("REPLAY-TIME", time + "");
		a.addParameter("USERNAME", nickname);
		a.addParameter("MAP-ID", mapID + "");
		return a;
	}

	public static ActionPackage errorReplay(int mapID, String mapName, int errorIndex) {
		// Create ActionPackage
		ActionPackage p = new ActionPackage();
		Action a;
		if (errorIndex == -1) {
			// No map exists
			a = new Action("NO-MAP", "REPLAY");
		} else if (errorIndex == -2) {
			// User is not logged in
			a = new Action("NO-USER", "REPLAY");
		} else if (errorIndex == -3) {
			// Map is empty - only one revision (create map) exists
			a = new Action("EMPTY-MAP", "REPLAY");
		} else {
			// No specific error
			a = new Action("ERROR", "REPLAY");
		}
		// Add Map-Parameters
		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("MAPNAME", mapName);
		// Add Action
		p.addAction(a);
		return p;
	}

	public static ActionPackage startInitReplay(int mapID) {
		// Create first action package to initialize the replay-client
		ActionPackage p = new ActionPackage();
		Action a = new Action("INIT-START", "REPLAY");
		// Add Map-Parameters
		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("MAPNAME", Map.getMapName(mapID));
		// Add Action
		p.addAction(a);
		return p;
	}

	public static ActionPackage endInitReplay(ActionPackage p, int mapID, long totalSec, State state) {
		Map m = state.maps.get(mapID);
		Template mTemplate = Map.getTemplate(mapID);

		// Create final action to initialize the replay-client
		Action a = new Action("INIT-END", "REPLAY");
		// Add Map-Parameters
		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("MAPNAME", m.getName());
		a.addParameter("ONTOLOGYNAME", mTemplate.getOntologyNameFromDB());
		a.addParameter("TEMPLATENAME", mTemplate.getName());
		a.addParameter("ONTOLOGY", Ontology.getOntologyXML(mTemplate.getOntologyID()));
		a.addParameter("TEMPLATE", Map.getTemplate(mapID).getXml());
		a.addParameter("TOTAL-SEC", totalSec + "");

		// Add Action
		p.addAction(a);
		return p;
	}

	public Action createReplayElement(int mapElementID, String type, String nickname, long time, int mapID) {
		// Build create action for replay-client
		Action a = new Action("CREATE-ELEMENT", "REPLAY");
		a.addParameter("ID", mapElementID + "");
		a.addParameter("TYPE", type);
		a.addParameter("REPLAY-TIME", time + "");
		a.addParameter("USERNAME", nickname);
		a.addParameter("MAP-ID", mapID + "");
		return a;
	}

	public Action updateReplayElement(int mapElementID, String nickname, long time, int mapID) {
		// Build update action for replay-client
		Action a = new Action("UPDATE-ELEMENT", "REPLAY");
		a.addParameter("ID", mapElementID + "");
		a.addParameter("REPLAY-TIME", time + "");
		a.addParameter("USERNAME", nickname);
		a.addParameter("MAP-ID", mapID + "");
		return a;
	}

	public static ActionPackage joinMap(int mapID, State state) {

		Map m = state.maps.get(mapID);
		Template mTemplate = Map.getTemplate(mapID);

		ActionPackage p = new ActionPackage();
		Action a = new Action("JOIN", "MAP");

		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("MAPNAME", m.getName());
		a.addParameter("ONTOLOGYNAME", mTemplate.getOntologyNameFromDB());
		a.addParameter("TEMPLATENAME", mTemplate.getName());
		a.addParameter("ONTOLOGY", Ontology.getOntologyXML(mTemplate.getOntologyID()));
		a.addParameter("TEMPLATE", Map.getTemplate(mapID).getXml());

		p.addAction(a);
		return p;
	}

	/**
	 * Notification that a new user joined the map
	 * 
	 * @param mapID
	 * @param nickname
	 * @return
	 */
	public static ActionPackage userEventUserJoin(int mapID, String nickname) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("USERJOIN", "USEREVENT");
		a.addParameter("USERNAME", nickname);
		a.addParameter("MAP-ID", mapID + "");

		p.addAction(a);
		return p;
	}

	/**
	 * Notification that a user has left the map
	 * 
	 * @param mapID
	 * @param nickname
	 * @return
	 */
	public static ActionPackage userEventUserLeave(int mapID, String nickname) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("USERLEAVE", "USEREVENT");
		a.addParameter("USERNAME", nickname);
		a.addParameter("MAP-ID", mapID + "");

		p.addAction(a);
		return p;
	}

	/**
	 * Creates a list that contains all active users on the map
	 * 
	 * @param mapID
	 * @param state
	 * @return
	 */
	public static ActionPackage userEventUserList(int mapID, State state) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("USERLIST", "USEREVENT");

		synchronized (ActionProcessor.mapUsersLock) {
			for (User u : state.mapUsers.get(mapID)) {
				a.addParameter("USERNAME", u.getNickname());
			}
		}

		a.addParameter("MAP-ID", mapID + "");

		p.addAction(a);
		return p;
	}

	public static ActionPackage getMapDetails(int mapID, State state) {
		Map m = state.maps.get(mapID);
		Template mTemplate = Map.getTemplate(mapID);

		ActionPackage p = new ActionPackage();

		Action action = new Action("MAPDETAILS", "MAP");
		action.addParameter("STATUS", "OK");
		action.addParameter("MAP-ID", mapID + "");
		action.addParameter("MAPNAME", m.getName());
		action.addParameter("CREATORNAME", User.getName(m.getCreator_user_id()));
		action.addParameter("CREATORID", m.getCreator_user_id() + "");
		action.addParameter("ONTOLOGYNAME", mTemplate.getOntologyNameFromDB());
		action.addParameter("TEMPLATENAME", mTemplate.getName());
		action.addParameter("TEMPLATETITLE", mTemplate.getTitle());
		action.addParameter("TEMPLATEXML", mTemplate.getXml());
		action.addParameter("ACTIVEUSERS", state.mapUsers.get(mapID).size() + "");
		action.addParameter("TEMPLATEMAXUSER", Template.getTemplateMaxUsers(mTemplate.getXml()) + "");

		p.addAction(action);
		return p;
	}

	public static ActionPackage getOntology(int mapID) {

		Template mTemplate = Map.getTemplate(mapID);

		ActionPackage p = new ActionPackage();

		Action action = new Action("ONTOLOGY", "MAP");
		action.addParameter("MAP-ID", mapID + "");
		action.addParameter("ONTOLOGY", Ontology.getOntologyXML(mTemplate.getOntologyID()));

		p.addAction(action);

		return p;
	}

	public static ActionPackage deleteElement(int mapID, int elementID, String username) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("DELETE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("ID", elementID + "");
		a.addParameter("USERNAME", username);

		p.addAction(a);

		return p;
	}

	public static ActionPackage getAllOntologiesAndTemplates() {
		ActionPackage p = new ActionPackage();

		for (Ontology o : Ontology.getOntologyList()) {
			for (Template t : Template.getAllTemplatesWithOntology(o.getId())) {
				Action a = new Action("TEMPLATELISTELEMENT", "MAP");
				a.addParameter("ONTOLOGYNAME", o.getName());
				a.addParameter("TEMPLATENAME", t.getName());
				a.addParameter("TEMPLATETITLE", t.getTitle());
				p.addAction(a);
			}
		}
		return p;
	}

	public static ActionPackage getMapsAndTemplates() {
		ActionPackage p = new ActionPackage();

		// TODO Optimize so that templates with a map will not be send to client
		// empty in the first step

		// Add templates without map first to catch all templates, even those
		// which do not have any map instance
		Vector<Template> templates = Template.getAllTemplates();
		for (int i = 0; i < templates.size(); i++) {
			Template t = templates.get(i);

			Action a = new Action("ADD-MAP-TO-LIST", "AUTHORING");
			a.addParameter("TEMPLATE", t.getName());
			a.addParameter("MAP-ID", i + ""); // In this case, it is NOT the
			// internal map id!
			a.addParameter("MAP-MAXID", templates.size() - 1 + "");
			p.addAction(a);
		}

		// Add all concrete maps
		Vector<Map> mapList = Map.getMapList();
		for (int i = 0; i < mapList.size(); i++) {
			Map m = mapList.get(i);

			Action a = new Action("ADD-MAP-TO-LIST", "AUTHORING");
			a.addParameter("MAPNAME", m.getName());
			a.addParameter("TEMPLATE", Template.getTemplateName(m.getTemplate_id()));
			a.addParameter("MAP-ID", i + ""); // In this case, it is NOT the
			// internal map id!
			a.addParameter("MAP-MAXID", mapList.size() - 1 + "");
			p.addAction(a);
		}

		return p;
	}

	public static Action joinMap(int mapID) {
		Action a = new Action("JOIN", "MANAGEMENT");
		a.addParameter("MAP-ID", mapID + "");

		return a;
	}

	public static Action getLeaveMapAction(int mapID) {

		Action a = new Action("LEAVE", "MANAGEMENT");
		a.addParameter("MAP-ID", mapID + "");

		return a;
	}

	public static Action getUnlockElementAction(User u, int mapID, int lockedElementID) {

		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("USERNAME", u.getNickname());
		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("ID", lockedElementID + "");
		a.addParameter("STATUS", "UNLOCK");

		return a;
	}

	public static ActionPackage getLogOutActionPackage(String sessionID, String username) {

		ActionPackage p = new ActionPackage();
		p.addParameter("SESSION-ID", sessionID);

		Action a = new Action("LOGOUT", "MANAGEMENT");
		a.addParameter("USERNAME", username);

		p.addAction(a);

		return p;
	}

	public static ActionPackage getTemplateListActionPackage(boolean authoring) {
		Vector<String> o = Ontology.getAllOntologyNames();

		ActionPackage p = new ActionPackage();

		if (authoring) {
			for (int i = 0; i < o.size(); i++) {
				String ontology = o.get(i);

				Action a = null;

				// Create ontology folders without templates
				a = new Action("ADD-TEMPLATE-TO-LIST", "AUTHORING");
				a.addParameter("ONTOLOGY", ontology);
				a.addParameter("TEMPLATE-ID", i + "");
				a.addParameter("TEMPLATE-MAXID", o.size() - 1 + "");
				p.addAction(a);
			}
		}

		// Create templates to fill the ontology folders
		Vector<Template> t = Template.getAllTemplates();
		for (int i = 0; i < t.size(); i++) {
			Template temp = t.get(i);

			Action a = null;
			if (authoring) {
				a = new Action("ADD-TEMPLATE-TO-LIST", "AUTHORING");
			} else {
				a = new Action("ADD-TEMPLATE-TO-LIST", "MANAGEMENT");
			}
			a.addParameter("ONTOLOGY", temp.getOntologyName());
			a.addParameter("TEMPLATE", temp.getName());
			a.addParameter("TEMPLATE-ID", i + "");
			a.addParameter("TEMPLATE-MAXID", t.size() - 1 + "");

			p.addAction(a);
		}

		return p;
	}

	public static ActionPackage getNewTemplateAction(Template t) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("ADD-TEMPLATE-TO-LIST", "AUTHORING");
		a.addParameter("ONTOLOGY", t.getOntologyNameFromDB());
		a.addParameter("TEMPLATE", t.getName());

		String templateID = t.getId() + "";
		a.addParameter("TEMPLATE-ID", templateID);
		a.addParameter("TEMPLATE-MAXID", templateID);

		p.addAction(a);

		a = new Action("TEMPLATE-CREATED", "NOTIFY");
		a.addParameter("MESSAGE", "Template (" + t.getName() + ") successfully created.");

		p.addAction(a);

		return p;
	}

	public static ActionPackage getRemoveTemplateAction(String templateName, String ontologyName) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("DELETE-TEMPLATE-FROM-LIST", "AUTHORING");
		a.addParameter("ONTOLOGY", ontologyName);
		a.addParameter("TEMPLATE", templateName);

		p.addAction(a);

		a = new Action("INFO", "NOTIFY");
		a.addParameter("MESSAGE", "Template (" + templateName + ") successfully removed.");
		p.addAction(a);

		return p;
	}
	
	public static ActionPackage getKickOutAction() {
		ActionPackage p = new ActionPackage();

		Action a = new Action("ERROR-INFO", "NOTIFY");
		a.addParameter("USER-KICKOUT", "true");
		a.addParameter("MESSAGE", "Another user has logged in using your account," 
						+ " thus your session has been closed.");
		p.addAction(a);

		return p;
	}

	public static ActionPackage getInfoAction(String info) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("ONTOLOGY-CREATED", "NOTIFY");
		a.addParameter("MESSAGE", info);
		p.addAction(a);

		return p;
	}

	public static ActionPackage getUserListActionPackage(Vector<User> u) {
		ActionPackage p = new ActionPackage();

		for (int i = 0; i < u.size(); i++) {
			User user = u.get(i);

			Action a = new Action("ADD-USER-TO-LIST", "AUTHORING");
			a.addParameter("USERNAME", user.getNickname());
			a.addParameter("ROLE", user.getRole());
			a.addParameter("USER-ID", i + "");
			a.addParameter("USER-MAXID", u.size() - 1 + "");

			p.addAction(a);
		}

		return p;
	}

	public static ActionPackage getNewUserAction(User user) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("ADD-USER-TO-LIST", "AUTHORING");
		a.addParameter("USERNAME", user.getNickname());
		a.addParameter("ROLE", user.getRole());

		String userID = user.getUserID() + "";
		a.addParameter("USER-ID", userID);
		a.addParameter("USER-MAXID", userID);

		p.addAction(a);

		a = new Action("USER-CREATED", "NOTIFY");
		a.addParameter("MESSAGE", "User (" + user.getNickname() + ") successfully created.");

		p.addAction(a);

		return p;
	}

	public static ActionPackage getRemoveUserAction(String username, String role) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("DELETE-USER-FROM-LIST", "AUTHORING");
		a.addParameter("USERNAME", username);
		a.addParameter("ROLE", role);

		p.addAction(a);

		a = new Action("INFO", "NOTIFY");
		a.addParameter("MESSAGE", "User (" + username + ") successfully removed.");
		p.addAction(a);

		return p;
	}

	public static ActionPackage getUserListWithoutRolesActionPackage(Vector<String> u) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("LIST-USERS", "AUTHORING");

		for (int i = 0; i < u.size(); i++) {
			String user = u.get(i);
			a.addParameter("USERNAME", user);
		}

		p.addAction(a);
		return p;
	}

	public static ActionPackage getNewMapAction(Map m) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("ADD-MAP-TO-LIST", "AUTHORING");
		a.addParameter("MAPNAME", m.getName());
		a.addParameter("TEMPLATE", Template.getTemplateName(m.getTemplate_id()));
		a.addParameter("MAP-ID", m.getId() + "");
		a.addParameter("MAP-MAXID", m.getId() + "");

		p.addAction(a);

		a = new Action("SESSION-CREATED", "NOTIFY");
		a.addParameter("MESSAGE", "A new session (" + m.getName() + ") has been successfully created.");

		p.addAction(a);

		return p;
	}

	public static ActionPackage getRemoveMapAction(String mapName, String templateName) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("DELETE-MAP-FROM-LIST", "AUTHORING");
		a.addParameter("MAPNAME", mapName);
		a.addParameter("TEMPLATE", templateName);

		p.addAction(a);

		a = new Action("INFO", "NOTIFY");
		a.addParameter("MESSAGE", "Map (" + mapName + ") successfully removed.");
		p.addAction(a);

		return p;
	}

	public static ActionPackage getRemoveOntologyAction(String ontologyName) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("DELETE-ONTOLOGY-FROM-LIST", "AUTHORING");
		a.addParameter("ONTOLOGYNAME", ontologyName);

		p.addAction(a);

		a = new Action("INFO", "NOTIFY");
		a.addParameter("MESSAGE", "Ontology (" + ontologyName + ") successfully removed.");
		p.addAction(a);

		return p;
	}

	public static ActionPackage getOntologyList(Vector<String> ontologyList) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("LIST-ONTOLOGIES", "AUTHORING");

		for (int i = 0; i < ontologyList.size(); i++) {
			a.addParameter("ONTOLOGYNAME", ontologyList.get(i));
		}

		p.addAction(a);

		return p;
	}

	public static ActionPackage getOntologyDetails(String ontologyName) {
		ActionPackage p = new ActionPackage();

		Action action = new Action("ONTOLOGY-DETAILS", "AUTHORING");
		action.addParameter("ONTOLOGY", Ontology.getOntologyXML(Ontology.getOntologyID(ontologyName)));
		p.addAction(action);

		return p;
	}

	public static ActionPackage getTemplateDetails(String tName) {

		Template mTemplate = Template.getTemplate(tName);

		ActionPackage p = new ActionPackage();

		Action action = new Action("TEMPLATEDETAILS", "MAP");
		action.addParameter("STATUS", "OK");

		action.addParameter("ONTOLOGY", mTemplate.getOntologyNameFromDB());
		action.addParameter("TEMPLATE", mTemplate.getName());
		action.addParameter("TEMPLATETITLE", mTemplate.getTitle());
		action.addParameter("TEMPLATEMAXUSER", Template.getTemplateMaxUsers(mTemplate.getXml()) + "");

		p.addAction(action);
		return p;

	}

	public static Action getCreateMapAction(String sessionName, String templateName, String username) {
		Action a = new Action();
		a.addParameter("MAPNAME", sessionName);
		a.addParameter("TEMPLATE", templateName);
		a.addParameter("RESTRICTED-TO", username);
		return a;
	}

	public static ActionPackage loadFromFileFinished(String importType) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("READY", "INFO");
		a.addParameter("IMPORT-TYPE", importType);
		p.addAction(a);
		return p;
	}

	public static ActionPackage getConfirmActionFromExistingAction(Action a, String msg) {
		ActionPackage p = new ActionPackage();

		Action action = new Action("CONFIRMATION-REQUEST", "AUTHORING");
		action.getParameters().addAll(a.getParameters());
		action.addParameter("ORIGINAL-COMMAND", a.getCmd());
		action.addParameter("MESSAGE", msg);

		p.addAction(action);

		return p;
	}

	public static ActionPackage authoringFailed(String msg) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("AUTHORING-FAILED", "INFO");
		a.addParameter("MESSAGE", msg);
		p.addAction(a);
		return p;
	}
}
