package lasad.shared.dfki.meta.agents.analysis;

/**
 * 
 * @author oliverscheuer
 * 
 */
public enum AnalysisResultDatatype {

	object_result, object_binary_result, user_result, user_binary_result, session_result, session_binary_result;
}
