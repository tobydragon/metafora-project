package lasad.shared.dfki.meta.agents.analysis.structure.model;

/**
 * Marker interface
 * @author oliverscheuer
 *
 */
public interface Set2SomethingComparison {

}
