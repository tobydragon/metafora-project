package lasad.shared.dfki.meta.agents;

/**
 * 
 * @author oliverscheuer
 * 
 */
public enum ServiceClass {

	ANALYSIS, ACTION, PROVISION;
//pattern, feedback, 
}
