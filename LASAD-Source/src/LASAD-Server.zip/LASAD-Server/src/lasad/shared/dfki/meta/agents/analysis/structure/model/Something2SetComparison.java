package lasad.shared.dfki.meta.agents.analysis.structure.model;

/**
 * Marker interface
 * 
 * @author oliverscheuer
 * 
 */
public interface Something2SetComparison {

}
