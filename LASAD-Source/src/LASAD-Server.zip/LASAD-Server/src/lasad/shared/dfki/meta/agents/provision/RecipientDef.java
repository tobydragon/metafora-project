package lasad.shared.dfki.meta.agents.provision;

import java.io.Serializable;

/**
 * 
 * @author oliverscheuer
 *
 */
public class RecipientDef implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9181291618446594544L;
	
	public RecipientDef(){
		
	}
}
