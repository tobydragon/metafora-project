package lasad.shared.dfki.meta.agents.provision.priority;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgFilterDef_DiscardAllButOneInstancePerType extends MsgFilterDef {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6932605853616731688L;
	
	public MsgFilterDef_DiscardAllButOneInstancePerType(){
		
	}

}
