package lasad.shared.dfki.meta.agents.analysis;

import lasad.shared.dfki.meta.agents.ServiceID;
import lasad.shared.dfki.meta.agents.ServiceType;

/**
 * Metadata about a type of analysis an {@link IAgent} can carry out.
 * 
 * @author Oliver Scheuer, isha
 * 
 */
public class AnalysisType extends ServiceType {

	private static final long serialVersionUID = 8365168400985153693L;

	private AnalysisResultDatatype resultDatatype;

	private boolean onlyPositiveInstances = true;

	public AnalysisType() {

	}

	public AnalysisType(AnalysisResultDatatype resultDataype, ServiceID id) {
		super(id);
		this.resultDatatype = resultDataype;
	}

	public AnalysisResultDatatype getResultDatatype() {
		return resultDatatype;
	}

	/**
	 * 
	 * @return whether only positive results are meaningful and will be provided
	 */
	public boolean isOnlyPositiveInstances() {
		return onlyPositiveInstances;
	}

	public void setOnlyPositiveInstances(boolean onlyPositiveInstances) {
		this.onlyPositiveInstances = onlyPositiveInstances;
	}

	public boolean userSpecificLogic() {
		return false;
	}

}
