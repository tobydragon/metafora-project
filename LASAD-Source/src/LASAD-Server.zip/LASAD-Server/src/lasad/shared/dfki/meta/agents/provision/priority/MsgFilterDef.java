package lasad.shared.dfki.meta.agents.provision.priority;

import java.io.Serializable;

/**
 * 
 * @author oliverscheuer
 * 
 */
public abstract class MsgFilterDef implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3681291596228409324L;

	public MsgFilterDef(){
		
	}
}
