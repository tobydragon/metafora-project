package lasad.shared.dfki.meta.agents.analysis.counter;

/**
 * 
 * @author oliverscheuer
 *
 */
public enum CounterCriterionOperator {

	GREATER, GREATER_OR_EQUAL, EQUAL, LESS_OR_EQUAL, LESS;
}
