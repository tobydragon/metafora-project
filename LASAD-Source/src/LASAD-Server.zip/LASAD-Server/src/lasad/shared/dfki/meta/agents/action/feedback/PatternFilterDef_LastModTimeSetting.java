package lasad.shared.dfki.meta.agents.action.feedback;

/**
 * 
 * @author oliverscheuer
 * 
 */
public enum PatternFilterDef_LastModTimeSetting {

	NONE, MIN_AGE, MAX_AGE;
}
