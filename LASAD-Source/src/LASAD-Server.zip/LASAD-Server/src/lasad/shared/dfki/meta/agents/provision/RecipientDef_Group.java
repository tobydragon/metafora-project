package lasad.shared.dfki.meta.agents.provision;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class RecipientDef_Group extends RecipientDef {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4779614468334775000L;
	
	public RecipientDef_Group(){
		
	}

}
