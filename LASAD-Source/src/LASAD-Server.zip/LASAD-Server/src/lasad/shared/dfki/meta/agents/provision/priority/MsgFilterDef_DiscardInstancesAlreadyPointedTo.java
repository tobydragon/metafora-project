package lasad.shared.dfki.meta.agents.provision.priority;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgFilterDef_DiscardInstancesAlreadyPointedTo extends MsgFilterDef {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1773773605464559180L;

	public MsgFilterDef_DiscardInstancesAlreadyPointedTo(){
		
	}
}
