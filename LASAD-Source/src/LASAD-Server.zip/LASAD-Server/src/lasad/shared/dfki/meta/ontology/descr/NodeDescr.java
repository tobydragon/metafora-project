package lasad.shared.dfki.meta.ontology.descr;

/**
 * (see {@link ElementDescr})
 * 
 * @author oliverscheuer
 * 
 */
public class NodeDescr extends ElementDescr {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5196435673343803392L;

	public NodeDescr(){
		
	}
	public NodeDescr(String elemTypeID) {
		super(elemTypeID);
	}
}
