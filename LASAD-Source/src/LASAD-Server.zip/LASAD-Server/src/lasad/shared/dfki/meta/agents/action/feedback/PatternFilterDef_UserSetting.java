package lasad.shared.dfki.meta.agents.action.feedback;

/**
 * 
 * @author oliverscheuer
 * 
 */
public enum PatternFilterDef_UserSetting {

	NONE, OWNER, CONTRIBUTOR, NON_CONTRIBUTOR;
}
