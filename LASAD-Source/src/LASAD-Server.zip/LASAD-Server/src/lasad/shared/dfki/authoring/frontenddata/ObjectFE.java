package lasad.shared.dfki.authoring.frontenddata;

public interface ObjectFE {

}
