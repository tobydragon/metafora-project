package lasad.shared.dfki.meta.agents.provision.priority;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class MsgSortCriterion_MsgPriority extends MsgSortCriterion {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7370602195703892688L;

	public MsgSortCriterion_MsgPriority(){
		
	}
}
