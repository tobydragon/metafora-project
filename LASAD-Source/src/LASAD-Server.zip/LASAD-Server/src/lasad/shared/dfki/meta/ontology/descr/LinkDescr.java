package lasad.shared.dfki.meta.ontology.descr;

/**
 * (see {@link ElementDescr})
 * 
 * @author oliverscheuer
 * 
 */
public class LinkDescr extends ElementDescr {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4665922851154277767L;

	public LinkDescr(){
		
	}
	public LinkDescr(String elemTypeID) {
		super(elemTypeID);
	}
}
