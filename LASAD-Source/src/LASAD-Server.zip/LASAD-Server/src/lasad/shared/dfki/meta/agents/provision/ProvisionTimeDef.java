package lasad.shared.dfki.meta.agents.provision;

import java.io.Serializable;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class ProvisionTimeDef implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8873489687589337153L;
	
	public ProvisionTimeDef(){
		
	}

}
