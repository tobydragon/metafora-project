package lasad.shared.dfki.meta.agents.provision;

/**
 * 
 * @author oliverscheuer
 * 
 */
public class RecipientDef_Individuals extends RecipientDef {

	/**
	 * 
	 */
	private static final long serialVersionUID = 109267186835240254L;

	public RecipientDef_Individuals(){
		
	}
}
