package de.dfki.lasad.modules.dataservice.lasad.rmi;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.dataservice.DataServiceDescription;
import de.dfki.lasad.core.dataservice.IDataService;
import de.dfki.lasad.modules.dataservice.lasad.LASADDataServiceConfiguration;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMI;

public class LASADDataServiceRMIDescription extends DataServiceDescription {


	public LASADDataServiceRMIDescription(String targetClass,
			LASADDataServiceConfiguration configuration) {
		super(targetClass, targetClass);
		this.configuration = configuration;
	}

	public LASADDataServiceRMIDescription(
			LASADDataServiceConfiguration configuration) {
		this(LASADDataServiceRMI.class.getName(), configuration);
		this.configuration = configuration;
	}
	
	@Override
	public LASADDataServiceConfiguration getConfiguration() {
		return (LASADDataServiceConfiguration)configuration;
	}

	@Override
	public IDataService createInstance() throws ComponentInitException {
		return super.createInstance();
	}

}
