package de.dfki.lasad.core.worldmodel;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * TODO: Currently, this class hard-codes LARGO-specific details. More general
 * LARGO-independent data should be separated cleanly from LARGO-specific data,
 * which should be taken from the ontology.
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessGraphTemplates {

	private Log logger = LogFactory.getLog(JessGraphTemplates.class);

	private HashMap<SessionID, EUEOntology> sessions2ontologies = new HashMap<SessionID, EUEOntology>();

	private static final String resourceMainDir = "jess_graph";
	private static final String ontologyDefinitionsDirName = "ontology_definitions";
	private static final String annotationDirName = "annotations";

	private static final String basicDefinitionsLocalFilename = "basic_definitions.clp.txt";
	private static final String resultQueryDefinitionLocalFilename = "result_query_definition.clp.txt";

	private static final Map<String, IGraphOntologyInfo> ontologyID2OntologyInfo = new HashMap<String, IGraphOntologyInfo>();
	static {
		ontologyID2OntologyInfo.put("LARGO", new LARGOOntologyInfo());
	}

	private static final Map<String, String> resourceID2AnnotationsLocalFilename = new HashMap<String, String>();
	static {
		resourceID2AnnotationsLocalFilename.put("largo_asahi_petitioner",
				"largo_asahi_petitioner.clp.txt");
		resourceID2AnnotationsLocalFilename.put("largo_asahi_respondent",
				"largo_asahi_respondent.clp.txt");
		resourceID2AnnotationsLocalFilename.put("largo_burgerking_petitioner",
				"largo_burgerking_petitioner.clp.txt");
		resourceID2AnnotationsLocalFilename.put("largo_burgerking_respondent",
				"largo_burgerking_respondent.clp.txt");
		resourceID2AnnotationsLocalFilename.put("largo_burnham_petitioner",
				"largo_burnham_petitioner.clp.txt");
		resourceID2AnnotationsLocalFilename.put("largo_burnham_respondent",
				"largo_burnham_respondent.clp.txt");
		resourceID2AnnotationsLocalFilename.put("largo_carney_petitioner",
				"largo_carney_petitioner.clp.txt");
	}

	private String basicDefinitions;
	private String resultQueryDefinition;
	private Map<String, String> resourceID2JessAnnotationBatch = new HashMap<String, String>();
	private Map<String, String> ontologyID2JessDefinitionBatch = new HashMap<String, String>();

	public JessGraphTemplates() {
		loadDefinitionsFromFile();
	}

	public void registerOntology(SessionID sessionID, EUEOntology ontology) {
		sessions2ontologies.put(sessionID, ontology);
	}

	public EUEOntology getOntology(SessionID sessionID) {
		return sessions2ontologies.get(sessionID);
	}

	public String getBasicDefinitions() {
		return basicDefinitions;
	}

	public String getResultQueryDefinition() {
		return resultQueryDefinition;
	}

	public boolean isNodePropSupported(SessionID sessionID, String propName) {
		EUEOntology ontology = sessions2ontologies.get(sessionID);
		IGraphOntologyInfo ontologyInfo = ontologyID2OntologyInfo.get(ontology
				.getOntologyID());
		return ontologyInfo.isNodePropSupported(propName);
	}

	public boolean isSubElementPropSupported(SessionID sessionID,
			String subElementDataType, String propName) {
		EUEOntology ontology = sessions2ontologies.get(sessionID);
		IGraphOntologyInfo ontologyInfo = ontologyID2OntologyInfo.get(ontology
				.getOntologyID());
		return ontologyInfo.isSubElementPropSupported(subElementDataType,
				propName);
	}

	public List<String> getNodeTypes(SessionID sessionID) {
		EUEOntology ontology = sessions2ontologies.get(sessionID);
		IGraphOntologyInfo ontologyInfo = ontologyID2OntologyInfo.get(ontology
				.getOntologyID());
		if (ontologyInfo == null) {
			logger.info("No node type information available for session "
					+ sessionID);
			return new Vector();
		}
		return ontologyInfo.getNodeTypes();
	}

	public List<String> getLinkTypes(SessionID sessionID) {
		EUEOntology ontology = sessions2ontologies.get(sessionID);
		IGraphOntologyInfo ontologyInfo = ontologyID2OntologyInfo.get(ontology
				.getOntologyID());
		if (ontologyInfo == null) {
			logger.info("No link type information available for session "
					+ sessionID);
			return new Vector();
		}
		return ontologyInfo.getLinkTypes();
	}

	public String getOntologyBasedDefinitions(SessionID sessionID) {
		EUEOntology ontology = sessions2ontologies.get(sessionID);
		String batch = ontologyID2JessDefinitionBatch.get(ontology
				.getOntologyID());
		return batch;
	}

	/**
	 * For each available resource annotations might be available
	 * 
	 * @param sessionID
	 * @return
	 */
	public List<String> getAnnotationDefinitionsAndAnnotations(
			SessionID sessionID) {
		EUEOntology ontology = sessions2ontologies.get(sessionID);
		List<String> annotationJessBatches = new Vector<String>();
		for (String resourceID : ontology.getExternalResourceIDs()) {
			String annotationJessBatch = resourceID2JessAnnotationBatch
					.get(resourceID);
			if (annotationJessBatch != null) {
				annotationJessBatches.add(annotationJessBatch);
			}
		}
		return annotationJessBatches;
	}

	private final void loadDefinitionsFromFile() {
		if (ServiceRegistry.getAppConfig() == null) {
			logger.error("ServiceRegistry.getAppConfig() == null");
		}
		File confDir = ServiceRegistry.getAppConfig().getConfDir();
		File jessConfDir = new File(confDir, resourceMainDir);

		File basicDefinitionsFile = new File(jessConfDir,
				basicDefinitionsLocalFilename);
		basicDefinitions = readFileIntoString(basicDefinitionsFile);

		File resultQueryDefinitionFile = new File(jessConfDir,
				resultQueryDefinitionLocalFilename);
		resultQueryDefinition = readFileIntoString(resultQueryDefinitionFile);

		File ontoDir = new File(jessConfDir, ontologyDefinitionsDirName);
		for (String ontologyID : ontologyID2OntologyInfo.keySet()) {
			IGraphOntologyInfo ontologyInfo = ontologyID2OntologyInfo
					.get(ontologyID);
			String ontologyDefinitionsLocalFilename = ontologyInfo
					.getOntologyDefinitionsLocalFilename();
			File ontologydefinitionsLocalFile = new File(ontoDir,
					ontologyDefinitionsLocalFilename);
			String ontologyDefinitionBatch = readFileIntoString(ontologydefinitionsLocalFile);
			ontologyID2JessDefinitionBatch.put(ontologyID,
					ontologyDefinitionBatch);
		}

		File annotationDir = new File(jessConfDir, annotationDirName);
		for (String resourceID : resourceID2AnnotationsLocalFilename.keySet()) {
			String annotationsLocalFilename = resourceID2AnnotationsLocalFilename
					.get(resourceID);
			File annotationsLocalFile = new File(annotationDir,
					annotationsLocalFilename);
			String annotationsJessBatch = readFileIntoString(annotationsLocalFile);
			resourceID2JessAnnotationBatch
					.put(resourceID, annotationsJessBatch);
		}
	}

	private String readFileIntoString(File file) {
		StringBuffer buf = new StringBuffer();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String line;
			while (true) {
				line = in.readLine();
				if (line == null) {
					break;
				}
				buf.append(line);
				buf.append("\n");
			}
			return buf.toString();
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}

	}

}
