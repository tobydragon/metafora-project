package de.dfki.lasad.core;

/**
 * Exchangeable components that can be plugged into the system and which are, in
 * the general case, configurable.
 * 
 * @author Oliver Scheuer
 */
public interface PluggableComponent {

	/**
	 * Setup component using the provided {@link PluggableComponentDescription}.
	 * Apply {@link PluggableComponentConfiguration} (which can be accessed via
	 * the {@link PluggableComponentDescription}).
	 */
	public void configure(PluggableComponentDescription description)
			throws ComponentInitException;

	public PluggableComponentDescription getComponentDescription();
}
