package de.dfki.lasad.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import junit.framework.TestCase;

public class GeneralUtilTest extends TestCase {
	Log logger = LogFactory.getLog(GeneralUtil.class);
	
	public void testIsTimeRecent(){
		assertEquals(false, GeneralUtil.isTimeRecent(TestXmlData.timeFromXml, 300000));
		
		assertEquals(true, GeneralUtil.isTimeRecent(System.currentTimeMillis(), 10000));
		
		long time = System.currentTimeMillis();
		try {
			Thread.sleep(1000);
			assertEquals(false, GeneralUtil.isTimeRecent(time, 500));
			assertEquals(true, GeneralUtil.isTimeRecent(time, 2000));
		}
		catch(Exception e){
			logger.error("[testIsTimeRecent] thread woken prematurely");
		}
		
	}
	
	public void testPrintTime(){
		logger.debug(System.currentTimeMillis());
	}

}
