package de.dfki.lasad.models.eue.ontology;

import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Vector;

/**
 * An {@link EUEOntology} defines the kinds of object a user can manipulate
 * (i.e., create, delete and modify) as well as external resources available to
 * the user (e.g., transcripts). Thus, the {@link EUEOntology} determines which
 * user activities are possible. Knowing which external resources are available
 * allows to determine whether and which expert models / annotations to use when
 * analyzing student activities.
 * 
 * @author Oliver Scheuer
 * 
 */
public class EUEOntology {

	private String ontologyID;

	private SortedSet<String> externalResourceIDs = new TreeSet<String>();

	public EUEOntology(String ontologyID) {
		this.ontologyID = ontologyID;
	}

	public String getOntologyID() {
		return ontologyID;
	}

	public void addExternalResourceID(String id) {
		externalResourceIDs.add(id);
	}

	public void setExternalResourceIDs(SortedSet<String> externalResourceIDs) {
		this.externalResourceIDs = externalResourceIDs;
	}

	public SortedSet<String> getExternalResourceIDs() {
		return externalResourceIDs;
	}

	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("[EUEOntology: ");
		buf.append("id = " + ontologyID);
		buf.append(", resource IDs = " + externalResourceIDs);
		buf.append("]");
		return buf.toString();
	}

}
