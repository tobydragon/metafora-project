package de.dfki.lasad.core;

/**
 * Indicates a failure to initialize or configure a {@link PluggableComponent}.
 * 
 * @author Oliver Scheuer
 * 
 */
public class ComponentInitException extends Exception {

	public ComponentInitException(String message, Throwable cause) {
		super(message, cause);
	}

	public ComponentInitException(String message) {
		super(message);
	}
}
