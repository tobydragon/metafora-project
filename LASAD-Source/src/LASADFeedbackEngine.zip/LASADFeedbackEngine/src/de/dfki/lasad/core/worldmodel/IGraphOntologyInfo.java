package de.dfki.lasad.core.worldmodel;

import java.util.List;

import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * 
 * @author Oliver Scheuer
 *
 */
public interface IGraphOntologyInfo {

	public EUEOntology getOntology();

	public List<String> getNodeTypes();

	public List<String> getLinkTypes();

	public boolean isNodePropSupported(String propName);

	public boolean isSubElementPropSupported(String subElementDataType,
			String propName);

	public String getOntologyDefinitionsLocalFilename();

}
