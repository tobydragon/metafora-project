package de.dfki.lasad.modules.analysis.deeploop;

import java.util.Set;

import de.dfki.lasad.core.analysis.SimpleAnalysisAgentConfiguration;
import de.dfki.lasad.core.analysis.SimpleOntologyChecker;
import de.dfki.lasad.modules.analysis.SimplePropertyMappingsConfiguration;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class DeepLoopAnalysisAgentConfiguration extends
		SimpleAnalysisAgentConfiguration {

	protected SimplePropertyMappingsConfiguration mappingConfiguration = new SimplePropertyMappingsConfiguration();
	private String wsAddress = "http://amath07.activemath.org:28080/axis2/services/DeepLoopClassificationV2";

	public void setSupportedOntologies(Set<String> supportedOntologies) {
		this.ontologyChecker = new SimpleOntologyChecker(supportedOntologies);
	}

	public SimplePropertyMappingsConfiguration getMappingConfiguration() {
		return mappingConfiguration;
	}

	public void setMappingConfiguration(
			SimplePropertyMappingsConfiguration mappingConfiguration) {
		this.mappingConfiguration = mappingConfiguration;
	}

	public String getWsAddress() {
		return wsAddress;
	}

	public void setWsAddress(String wsAddress) {
		this.wsAddress = wsAddress;
	}

}
