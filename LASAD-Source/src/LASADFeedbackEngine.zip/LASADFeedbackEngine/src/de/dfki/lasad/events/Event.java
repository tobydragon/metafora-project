package de.dfki.lasad.events;

import de.dfki.lasad.models.eue.SessionID;

public abstract class Event implements Comparable<Event> {

	private long ts;
	protected String sourceComponentID;
	private int priority = 1;

	public Event(String srcCompId) {
		sourceComponentID = srcCompId;
		ts = System.currentTimeMillis();
	}

	public long getTs() {
		return ts;
	}

	public void setTs(long ts) {
		this.ts = ts;
	}

	public int getEventPriority() {
		return priority;
	}

	public void setEventPriority(int priority) {
		this.priority = priority;
	}

	public void setSourceComponentID(String sourceComponentID) {
		this.sourceComponentID = sourceComponentID;
	}

	public String getSourceComponentID() {
		return sourceComponentID;
	}
	
	public String getClassName() {
		return getClass().getSimpleName();
	}

	@Override
	public int compareTo(Event otherEvent) {
		int priorityDiff = otherEvent.getEventPriority() - priority;
		if (priorityDiff != 0) {
			return priorityDiff;
		}
		long tsDiff = ts - otherEvent.getTs();
		if (tsDiff < 0) {
			return -1;
		} else if (tsDiff > 0) {
			return 1;
		}
		return 0;
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + ": sourceComponentID="
				+ sourceComponentID + ", ts=" + ts;
	}

}
