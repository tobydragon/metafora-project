package de.dfki.lasad.modules.dataservice.lasad.xml;

import lasad.gwt.client.communication.objects.Parameter;
import de.uds.xml.XmlFragment;

import org.jdom.Element;

public class ParameterXmlConverter {
	
	public static XmlFragment toXml(Parameter parameter){
		XmlFragment xmlFragment = new XmlFragment("Parameter");
		xmlFragment.setAttribute("NAME", parameter.getName());
		xmlFragment.setAttribute("VALUE", parameter.getValue());
		return xmlFragment;
	}
	
	public static Parameter fromXml(XmlFragment xmlFragment){
		String name = xmlFragment.getAttributeValue("NAME");
		String value = xmlFragment.getAttributeValue("VALUE");
		return new Parameter(name, value);
	}

}
