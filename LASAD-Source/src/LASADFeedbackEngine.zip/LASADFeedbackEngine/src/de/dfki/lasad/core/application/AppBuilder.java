package de.dfki.lasad.core.application;

import java.util.List;
import java.util.Vector;

import javax.activation.MailcapCommandMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.core.action.IActionAgent;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.IAnalysisController;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.core.dataservice.DataServiceDescription;
import de.dfki.lasad.core.dataservice.IDataService;
import de.dfki.lasad.core.worldmodel.IModelController;
import de.dfki.lasad.core.worldmodel.JessModelController;
import de.dfki.lasad.core.worldmodel.JessModelControllerDescription;

/**
 * Wiring logic: Components provided by a {@link IConfiguration} instance are
 * initialized and wired together at system initialization time.
 * 
 * @author Oliver Scheuer
 */
public class AppBuilder {

	private Log logger = LogFactory.getLog(AppBuilder.class);

	// run levels

	public static final String STOPPED = "STOPPED";

	/**
	 * System components are initialized, configured and registered at the
	 * {@link ServiceRegistry}.
	 */
	public static final String INITIALIZING = "INITIALIZING";

	/**
	 * Runtime connection between local system components is established (i.e.,
	 * components are wired together).
	 */
	public static final String WIRING = "WIRING";

	/**
	 * Session information is fetched from the remote counterpart of the
	 * {@link IDataService} and services prepared for each session.
	 */
	public static final String PREPARING_SERVICES = "PREPARING_SERVICES";

	/**
	 * Services are announced to remote counterpart of the {@link IDataService}
	 * and service is provided.
	 */
	public static final String PROVIDING_SERVICES = "PROVIDING_SERVICES";

	public static String current_runlevel = STOPPED;

	private IConfiguration configuration;

	protected IDataService dataService;
	protected IAnalysisController analysisController;
	protected IActionController actionController;
	protected List<IAnalysisAgent> analysisAgents = new Vector<IAnalysisAgent>();
	protected List<IActionAgent> actionAgents = new Vector<IActionAgent>();

	protected IModelController worldModel;

	public AppBuilder(IConfiguration configuration) {
		current_runlevel = INITIALIZING;
		logger.info("Run level changed to: " + current_runlevel);
		this.configuration = configuration;

		registerXMLDataHandler();

		initWorldModel();
		initDataService();
		initAnalysisController();
		initActionController();
		initAnalysisAgents();
		initActionAgents();

	}

	public void doWireAndStart() {
		try {
			doWire();
			prepareAndStartDataService();
		} catch (Exception e) {
			logger.error("Error occurred", e);
		}
	}

	private void doWire() {
		current_runlevel = WIRING;
		logger.info("Run level changed to: " + current_runlevel);

		dataService.doWire(analysisController, actionController);
		analysisController.doWire(actionController);
		actionController.doWire(analysisController, dataService);

		for (IAnalysisAgent analysisAgent : analysisAgents) {
			analysisController.addAnalysisAgent(analysisAgent);
			analysisAgent.doWire(analysisController, worldModel);
		}

		for (IActionAgent actionAgent : actionAgents) {
			actionController.addActionAgent(actionAgent);
			actionAgent.doWire(actionController, worldModel);
		}
	}

	private void initDataService() {
		DataServiceDescription dataServiceDescription = configuration
				.getDataServiceDescription();
		try {
			dataService = dataServiceDescription.createInstance();
		} catch (ComponentInitException e) {
			logger.error(e.getMessage(), e);
		}
	}

	private void initAnalysisController() {
		IAnalysisController analysisController = configuration
				.getAnalysisController();
		this.analysisController = analysisController;
	}

	private void initActionController() {
		IActionController actionController = configuration
				.getActionController();
		this.actionController = actionController;
	}

	private void initActionAgents() {
		List<ActionAgentDescription> actionAgentDescriptions = configuration
				.getActionAgentDescriptions();
		for (ActionAgentDescription description : actionAgentDescriptions) {
			try {
				IActionAgent actionAgent = description.createInstance();
				this.actionAgents.add(actionAgent);
				ServiceRegistry.registerActionModule(actionAgent);
			} catch (ComponentInitException e) {
				logger.error(e.getMessage(), e);
			}

		}
	}

	private void initAnalysisAgents() {
		List<AnalysisAgentDescription> analysisAgentDescriptions = configuration
				.getAnalysisAgentDescriptions();
		for (AnalysisAgentDescription description : analysisAgentDescriptions) {
			try {
				IAnalysisAgent analysisAgent = description.createInstance();
				this.analysisAgents.add(analysisAgent);
				ServiceRegistry.registerAnalysisModule(analysisAgent);
			} catch (ComponentInitException e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	private void initWorldModel() {
		JessModelControllerDescription modelControllerDescr = configuration
				.getModelControllerDescription();
		if (modelControllerDescr == null) {
			logger.info("No '"
					+ JessModelControllerDescription.class.getSimpleName()
					+ "' configured.");
			return;
		}
		try {
			worldModel = (JessModelController) modelControllerDescr
					.createInstance();
			ServiceRegistry.registerModelController(worldModel);
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}

	private void prepareAndStartDataService() {
		current_runlevel = PREPARING_SERVICES;
		logger.info("Run level changed to: " + current_runlevel);
		dataService.prepareService();
		current_runlevel = PROVIDING_SERVICES;
		logger.info("Run level changed to: " + current_runlevel);
		dataService.startService();
	}

	/**
	 * JRE 1.6 automatically registers an XML data handler for MIME type
	 * "text/xml", when publishing a WS, that throws an exception for all MIME
	 * types that do not exactly match one of the strings "text/xml" or
	 * "application/xml". The DeepLoop WS is based on AXIS2, which automatically
	 * uses "text/xml; charset=UTF-8" as MIME type, which leads to the exception
	 * described above. Therefore, we register the default XML data handler
	 * before the JAX-WS RI has a chance to register the non-functional XML data
	 * handler (the first programmatically registered data handler has
	 * priority).
	 */
	protected void registerXMLDataHandler() {
		MailcapCommandMap mailcapCommandMap = (MailcapCommandMap) MailcapCommandMap
				.getDefaultCommandMap();
		mailcapCommandMap
				.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
	}

	public IDataService getDataService() {
		return dataService;
	}

	public void setDataService(IDataService dataService) {
		this.dataService = dataService;
	}

}
