package de.dfki.lasad.models.action;

import java.util.Set;

import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.UserIDAll;

/**
 * An {@link ActionSpec} consists of a set of {@link ActionComponent}s (
 * {@link #getActionComponents()}) and a user (or all users) as receiver of the
 * action ({@link #getActionRecipient()}).
 * 
 * @author Oliver Scheuer
 * 
 */
public abstract class ActionSpec {

	private UserID actionRecipient = new UserIDAll();

	public UserID getActionRecipient() {
		return actionRecipient;
	}

	public void setActionRecipient(UserID actionRecipient) {
		this.actionRecipient = actionRecipient;
	}

	public abstract Set<? extends ActionComponent> getActionComponents();

	@Override
	public String toString() {
		return "[for user: " + actionRecipient;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((actionRecipient == null) ? 0 : actionRecipient.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ActionSpec other = (ActionSpec) obj;
		if (actionRecipient == null) {
			if (other.actionRecipient != null)
				return false;
		} else if (!actionRecipient.equals(other.actionRecipient))
			return false;
		return true;
	}

}
