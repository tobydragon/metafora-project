package de.dfki.lasad.modules.application.largo;

import de.dfki.lasad.core.application.AppBuilder;

/**
 * 
 * @author Anahuac Valero
 * 
 */
public class GraphGrammarRMIServiceForLASADApp {

	AppBuilder appBuilder;

	public GraphGrammarRMIServiceForLASADApp() {
		GraphGrammarRMIServicesForLASADConfiguration configuration = new GraphGrammarRMIServicesForLASADConfiguration();
		appBuilder = new AppBuilder(configuration);
		appBuilder.doWireAndStart();
	}

	public static void main(String[] args) {
		new GraphGrammarRMIServiceForLASADApp();
	}
}
