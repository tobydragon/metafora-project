package de.dfki.lasad.events.eue.session.objectaction;

import java.util.List;

import de.dfki.lasad.events.eue.session.EUEEventID;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.objects.EUEObject;

/**
 * @author Oliver Scheuer
 * 
 */
public class UserCreateObjectEvent extends UserObjectActionEvent {

	public UserCreateObjectEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID, List<EUEObject> eueObject) {
		super(sessionID, srcCompId, eueEventID, userID, eueObject);
	}

	public UserCreateObjectEvent(SessionID sessionID, EUEEventID eueEventId,
			String srcComponentId) {
		super(sessionID, srcComponentId, eueEventId);
	}

	public UserCreateObjectEvent cloneWithoutObjects() {
		UserCreateObjectEvent clone = new UserCreateObjectEvent(getSessionID(),
				getEueEventID(), getSourceComponentID());
		clone.setUserID(getUserID());
		return clone;
	}
}
