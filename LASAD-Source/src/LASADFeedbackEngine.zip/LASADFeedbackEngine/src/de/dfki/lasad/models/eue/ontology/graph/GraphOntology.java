package de.dfki.lasad.models.eue.ontology.graph;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class GraphOntology extends EUEOntology {

	private List<Element> rootElements = new Vector<Element>(); 

	private Map<String, ElementType> typeDefinitions = new HashMap<String, ElementType>();

	public GraphOntology(String ontologyID) {
		super(ontologyID);
	}

	public void addRootElement(Element root) {
		rootElements.add(root);
	}

	public List<Element> getRootElements() {
		return rootElements;
	}

	public void addElementTypeDefinition(ElementType type) {
		typeDefinitions.put(type.getId(), type);
	}

	public Set<String> getTypeIDs() {
		return typeDefinitions.keySet();
	}

	public ElementType getElementType(String id) {
		return typeDefinitions.get(id);
	}
}
