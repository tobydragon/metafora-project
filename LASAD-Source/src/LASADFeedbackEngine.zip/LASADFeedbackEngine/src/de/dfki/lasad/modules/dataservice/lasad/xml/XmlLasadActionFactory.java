package de.dfki.lasad.modules.dataservice.lasad.xml;

import java.util.Vector;

import de.uds.xml.XmlFragment;
import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;

public class XmlLasadActionFactory {
	
	public static Vector<Action> createQuestionBoxActions(String mapId){
		ActionPackage actionPackage = ActionPackageXmlConverter.createFromXml(XmlFragment.getFragmentFromFile("resources/xml/lasad/createQuestionBox.xml"));
		Vector<Action> actions = actionPackage.getActions();
		for (Action action : actions){
			action.replaceParameter("MAP-ID", mapId);
		}
		return actionPackage.getActions();
	}
	
	public static Vector<Action> createImageElementActions(String mapId){
		ActionPackage actionPackage = ActionPackageXmlConverter.createFromXml(XmlFragment.getFragmentFromFile("resources/xml/lasad/createImage.xml"));
		Vector<Action> actions = actionPackage.getActions();
		for (Action action : actions){
			action.replaceParameter("MAP-ID", mapId);
		}
		return actionPackage.getActions();
	}
	
	public static Vector<Action> createReferenceObjectActions(String mapId){
		ActionPackage actionPackage = ActionPackageXmlConverter.createFromXml(XmlFragment.getFragmentFromFile("resources/xml/lasad/createReferenceObject.xml"));
		Vector<Action> actions = actionPackage.getActions();
		for (Action action : actions){
			action.replaceParameter("MAP-ID", mapId);
		}
		return actionPackage.getActions();
	}
	
	public static Vector<Action> createToolReferenceObjectActions(String mapId){
		ActionPackage actionPackage = ActionPackageXmlConverter.createFromXml(XmlFragment.getFragmentFromFile("resources/xml/lasad/createToolReferenceObject.xml"));
		Vector<Action> actions = actionPackage.getActions();
		for (Action action : actions){
			action.replaceParameter("MAP-ID", mapId);
		}
		return actionPackage.getActions();
	}
	
	public static Vector<Action> createMicroworldIssueObjectActions(String mapId, String username){
		ActionPackage actionPackage = ActionPackageXmlConverter.createFromXml(XmlFragment.getFragmentFromFile("resources/xml/lasad/CreateMicroworldIssueObject.xml"));
		Vector<Action> actions = actionPackage.getActions();
		replaceInfo(actions, mapId, username);
		return actionPackage.getActions();
	}
	
	public static Vector<Action> createMyMicroworldObjectActions(String mapId, String username){
		ActionPackage actionPackage = ActionPackageXmlConverter.createFromXml(XmlFragment.getFragmentFromFile("resources/xml/lasad/CreateMyMicroworldObject.xml"));
		Vector<Action> actions = actionPackage.getActions();
		replaceInfo(actions, mapId, username);
		return actionPackage.getActions();
	}
	
	public static Vector<Action> createMetaforaToolReferenceObjectActions(String mapId, String userName){
		ActionPackage actionPackage = ActionPackageXmlConverter.createFromXml(XmlFragment.getFragmentFromFile("resources/xml/lasad/createMetaforaToolReferenceObject.xml"));
		Vector<Action> actions = actionPackage.getActions();
		replaceInfo(actions, mapId, userName);
		return actionPackage.getActions();
	}
	
	//MUTATOR: changes actions vector
	private static void replaceInfo(Vector<Action> actions, String mapId, String userName){
		for (Action action : actions){
			action.replaceParameter("MAP-ID", mapId);
			action.replaceParameter("USERNAME", userName);
		}
	}

}
