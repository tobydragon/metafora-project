package de.dfki.lasad.models.analysis;

import java.util.HashMap;
import java.util.Map;

import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.models.action.ActionComponent;

/**
 * Output of an {@link IAnalysisAgent}. {@link IAnalysisResult}s can act as an
 * {@link ActionComponent}, i.e., to forward results to requesting components
 * without further processing.
 * 
 * @author Oliver Scheuer
 * 
 */
public abstract class AnalysisResult implements ActionComponent {

	private AnalysisType analysisType;
	private AnalyzableEntity analyzedEntity;

	// generic properties that are associated with the result and that can be
	// used to provide more specific feedback,
	private Map<String, String> properties = new HashMap<String, String>();

	public AnalysisResult(AnalysisType analysisType,
			AnalyzableEntity analyzedEntity) {
		this.analysisType = analysisType;
		this.analyzedEntity = analyzedEntity;
	}

	public AnalysisType getAnalysisType() {
		return analysisType;
	}

	public AnalyzableEntity getAnalyzableEntity() {
		return analyzedEntity;
	}

	public abstract String getValueAsString();

	public void addProperty(String name, String value) {
		properties.put(name, value);
	}

	public String getPropertyValue(String name) {
		return properties.get(name);
	}

	public Map<String, String> getProperties() {
		return properties;
	}

	public String toString() {
		return getClass().getSimpleName() + ": analysisType=["
				+ analysisType.getAgentID() + ", " + analysisType.getTypeID()
				+ "]" + ", analyzedEntity=" + analyzedEntity.toString()
				+ ", value=" + getValueAsString() + ", properties="
				+ properties.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((analysisType == null) ? 0 : analysisType.hashCode());
		result = prime * result
				+ ((analyzedEntity == null) ? 0 : analyzedEntity.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AnalysisResult other = (AnalysisResult) obj;
		if (analysisType == null) {
			if (other.analysisType != null)
				return false;
		} else if (!analysisType.equals(other.analysisType))
			return false;
		if (analyzedEntity == null) {
			if (other.analyzedEntity != null)
				return false;
		} else if (!analyzedEntity.equals(other.analyzedEntity))
			return false;
		return true;
	}

}
