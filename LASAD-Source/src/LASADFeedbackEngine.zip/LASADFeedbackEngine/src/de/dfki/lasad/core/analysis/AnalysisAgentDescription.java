package de.dfki.lasad.core.analysis;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.PluggableComponentDescription;

public class AnalysisAgentDescription extends PluggableComponentDescription {

	private Map<String, AnalysisType> analysisTypes = new HashMap<String, AnalysisType>();

	//this call will not join any maps because it has no agent config to define ontologyChecker
	public AnalysisAgentDescription(String analysisAgentID, String className) {
		this(analysisAgentID, className, new SimpleAnalysisAgentConfiguration());
	}

	public AnalysisAgentDescription(String analysisAgentID, String className, IAnalysisAgentConfiguration configuration) {
		super(className, configuration);
		setComponentID(analysisAgentID);
	}

	@Override
	public IAnalysisAgentConfiguration getConfiguration() {
		return (IAnalysisAgentConfiguration) super.getConfiguration();
	}

	public IAnalysisAgent createInstance() throws ComponentInitException {
		IAnalysisAgent analysisAgent = (IAnalysisAgent) super.createInstance();
		return analysisAgent;
	}

	public void addAnalysisType(AnalysisType analysisType) {
		analysisTypes.put(analysisType.getTypeID(), analysisType);
	}

	public List<AnalysisType> getAllAnalysisTypes() {
		return new Vector<AnalysisType>(analysisTypes.values());
	}

	public List<String> getAllAnalysisTypeIds() {
		return new Vector<String>(analysisTypes.keySet());
	}

	public AnalysisType getAnalysisType(String analysisTypeId) {
		return analysisTypes.get(analysisTypeId);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((componentTypeID == null) ? 0 : componentTypeID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof AnalysisAgentDescription))
			return false;
		AnalysisAgentDescription other = (AnalysisAgentDescription) obj;
		if (componentTypeID == null) {
			if (componentTypeID != null)
				return false;
		} else if (!componentTypeID.equals(other.componentTypeID))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		buffer.append(this.getClass().toString());
		buffer.append(": ").append(getDataString());
		buffer.append("]");
		return buffer.toString();
	}

	public String getDataString() {
		StringBuffer buffer = new StringBuffer();

		buffer.append("analysisAgentID=").append(componentTypeID);
		buffer.append(", class=").append(className);
		buffer.append(", analysisTypes =").append(analysisTypesToString());
		return buffer.toString();
	}

	public String analysisTypesToString() {
		StringBuffer buffer = new StringBuffer();
		AnalysisType types;
		buffer.append("{");
		Iterator<AnalysisType> iter = analysisTypes.values().iterator();
		while (iter.hasNext()) {
			types = iter.next();
			buffer.append(types.toString());
			if (iter.hasNext()) {
				buffer.append(", \n");
			}
		}
		buffer.append("}");
		return buffer.toString();
	}

}
