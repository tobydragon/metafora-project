package de.dfki.lasad.core;

/**
 * Representation of a set of configuration settings for
 * {@link PluggableComponent}s.
 * 
 * @author Oliver Scheuer
 */
public interface PluggableComponentConfiguration {

}
