package de.dfki.lasad.modules.dataservice.lasad.xml;


import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.Parameter;
import de.uds.xml.XmlFragment;

public class ActionXmlConverter {
	
	public static XmlFragment toXml(Action action){
		
		XmlFragment xmlFragment = new XmlFragment("Action");
		xmlFragment.setAttribute("COMMAND", action.getCmd());
		xmlFragment.setAttribute("CATEGORY", action.getCategory());
		for (Parameter parameter :action.getParameters()){
			xmlFragment.addContent(ParameterXmlConverter.toXml(parameter));
		}
		return xmlFragment;
	}
	
	public static Action fromXml(XmlFragment fragment){
		
		String cmd = fragment.getAttributeValue("COMMAND");
		String category = fragment.getAttributeValue("CATEGORY");
		Action action = new Action(cmd, category);
		for (XmlFragment paramElement : fragment.getChildren("Parameter")){
			Parameter p = ParameterXmlConverter.fromXml(paramElement);
			action.addParameter(p.getName(), p.getValue());
		}
		return action;
	}

}
