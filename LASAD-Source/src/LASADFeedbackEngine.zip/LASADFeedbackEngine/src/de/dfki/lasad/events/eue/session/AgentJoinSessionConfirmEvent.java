package de.dfki.lasad.events.eue.session;

import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.models.eue.SessionID;

/**
 * Acknowledgment in response to a {@link AgentJoinSessionAnnounceEvent}.
 * Indicates that all necessary preparatory steps are accomplished and the
 * session can be joined.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AgentJoinSessionConfirmEvent extends SessionEvent {

	public AgentJoinSessionConfirmEvent(SessionID sessionID, String srcComponent) {
		super(sessionID, srcComponent);
	}
}
