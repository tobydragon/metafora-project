package de.dfki.lasad.modules.application.largo;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.SimpleAnalysisAgentConfiguration;
import de.dfki.lasad.core.application.AbstractAppConfiguration;
import de.dfki.lasad.core.dataservice.DataServiceDescription;
import de.dfki.lasad.core.worldmodel.JessModelControllerDescription;
import de.dfki.lasad.core.worldmodel.ModelControllerConfiguration;
import de.dfki.lasad.modules.action.jess.JessFeedbackAgentConfiguration;
import de.dfki.lasad.modules.action.jess.JessFeedbackAgentDescription;
import de.dfki.lasad.modules.analysis.graphmodeler.JessGraphModelerDescription;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIDescription;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIConfiguration;

/**
 * 
 * @author Anahuac Valero
 * 
 */
public class GraphGrammarRMIServicesForLASADConfiguration extends AbstractAppConfiguration{


	private final static String GG_AGENT_CONFIG_FILENAME = "LARGO_FEEDBACK_ALL.conf.xml";

	private LASADDataServiceRMIDescription dataServiceDescription;

	private List<AnalysisAgentDescription> analysisAgentDescriptions = new Vector<AnalysisAgentDescription>();
	private List<ActionAgentDescription> actionAgentDescriptions = new Vector<ActionAgentDescription>();

	public GraphGrammarRMIServicesForLASADConfiguration() {
		super();
		// create {@link LASADDataServiceDescription}
		LASADDataServiceRMIConfiguration dataServiceConf = LASADDataServiceRMIConfiguration
				.readDefaultConfig();
		dataServiceDescription = new LASADDataServiceRMIDescription(
				dataServiceConf);

		// create {@link JessFeedbackAgentDescription}
		JessFeedbackAgentConfiguration jessFeedbackAgentConf = new JessFeedbackAgentConfiguration(
				GG_AGENT_CONFIG_FILENAME);
		JessFeedbackAgentDescription jessFeedbackAgentDescr = new JessFeedbackAgentDescription(
				jessFeedbackAgentConf);
		actionAgentDescriptions.add(jessFeedbackAgentDescr);

		// create {@link JessGraphModelerDescription} and {@link
		// JessModelControllerDescription}
		Set<String> jessModelerSupportedOntologies = new HashSet<String>();
		jessModelerSupportedOntologies.add("LARGO");
		SimpleAnalysisAgentConfiguration simpleConf = new SimpleAnalysisAgentConfiguration(
				jessModelerSupportedOntologies);
		JessGraphModelerDescription jessGraphModelerDescription = new JessGraphModelerDescription(
				simpleConf);
		analysisAgentDescriptions.add(jessGraphModelerDescription);
		this.modelControllerDescr = new JessModelControllerDescription(
				new ModelControllerConfiguration(jessModelerSupportedOntologies));
	}

	@Override
	public DataServiceDescription getDataServiceDescription() {
		return dataServiceDescription;
	}

	@Override
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions() {
		return analysisAgentDescriptions;
	}

	@Override
	public List<ActionAgentDescription> getActionAgentDescriptions() {
		return actionAgentDescriptions;
	}

}

