package de.dfki.lasad.core.action;

/**
 * 
 * An {@link ActionType} that describes an analysis that is based on a
 * {@link #rule}.
 * 
 * @author Oliver Scheuer
 * 
 */
public class RuleBasedActionType extends SimpleActionType {

	private String rule;

	public RuleBasedActionType(String actionAgentID, String actionTypeID) {
		super(actionAgentID, actionTypeID);
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

}
