package de.dfki.lasad.events.action;

public interface ActionSpecEventListener {

	public void onActionSpecEvent(ActionSpecEvent event);
}
