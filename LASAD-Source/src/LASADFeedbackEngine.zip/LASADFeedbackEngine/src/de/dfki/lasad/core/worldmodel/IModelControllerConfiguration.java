package de.dfki.lasad.core.worldmodel;

import de.dfki.lasad.core.PluggableComponentConfiguration;
import de.dfki.lasad.core.analysis.OntologyChecker;

public interface IModelControllerConfiguration extends
		PluggableComponentConfiguration {

	public OntologyChecker getOntologySupportChecker();

}