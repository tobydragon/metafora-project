package de.dfki.lasad.core;

import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;

/**
 * Assigns priority values to {@link Event}s that are used to determine the
 * order of processing.
 * 
 * @author Zeshan
 */
public class DefaultEventPrioritizer {
	public static final int EUE_EVENT_PRIORITY = 4;
	public static final int ANALYSIS_ACTION_SPEC_EVENT_PRIORITY = 3;
	public static final int ANALYSIS_RESULT_EVENT_PRIORITY = 2;
	public static final int ANALYSIS_REQUEST_EVENT_PRIORITY = 1;

	public static void assignPriority(Event event) {
		/*
		 * Its a very simple first version implementation In second version the
		 * decision logic will be based on the role of the component which it is
		 * currently playing
		 */

		if (event instanceof EUESessionEvent) {
			event.setEventPriority(EUE_EVENT_PRIORITY);

		} else if (event instanceof ActionSpecEvent) {
			event.setEventPriority(ANALYSIS_ACTION_SPEC_EVENT_PRIORITY);

		} else if (event instanceof AnalysisRequestEvent) {
			event.setEventPriority(ANALYSIS_REQUEST_EVENT_PRIORITY);

		} else if (event instanceof AnalysisResultEvent) {
			event.setEventPriority(ANALYSIS_RESULT_EVENT_PRIORITY);
		}
	}

}