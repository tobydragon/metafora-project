package de.dfki.lasad.modules.dataservice.lasad;

import java.util.HashMap;

/**
 * Translates between the feedback types displayed in the GUI and 'technical'
 * IDs used for internal processing.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AnalysisAndFeedbackTypeAdapter {

	private static HashMap<AgentIDTypeIDPair, String> analysisID2displayName = new HashMap<AgentIDTypeIDPair, String>();
	private static HashMap<String, AgentIDTypeIDPair> displayName2analysisID = new HashMap<String, AgentIDTypeIDPair>();
	private static HashMap<AgentIDTypeIDPair, String> actionID2displayName = new HashMap<AgentIDTypeIDPair, String>();
	private static HashMap<String, AgentIDTypeIDPair> displayName2actionID = new HashMap<String, AgentIDTypeIDPair>();

	public static void addAnalysisMapping(String agentID, String typeID,
			String displayName) {
		AgentIDTypeIDPair idPair = new AgentIDTypeIDPair(agentID, typeID);
		analysisID2displayName.put(idPair, displayName);
		displayName2analysisID.put(displayName, idPair);
	}

	public static void addActionMapping(String agentID, String typeID,
			String displayName) {
		AgentIDTypeIDPair idPair = new AgentIDTypeIDPair(agentID, typeID);
		actionID2displayName.put(idPair, displayName);
		displayName2actionID.put(displayName, idPair);
	}

	public static String getAnalysisTypeID(String displayType) {
		AgentIDTypeIDPair idPair = displayName2analysisID.get(displayType);
		return idPair.typeID;
	}

	public static String getActionTypeID(String displayType) {
		AgentIDTypeIDPair idPair = displayName2actionID.get(displayType);
		return idPair.typeID;
	}

	public static String getAnalysisDisplayName(String agentID, String typeID) {
		AgentIDTypeIDPair idPair = new AgentIDTypeIDPair(agentID, typeID);
		return analysisID2displayName.get(idPair);
	}

	public static String getActionDisplayName(String agentID, String typeID) {
		AgentIDTypeIDPair idPair = new AgentIDTypeIDPair(agentID, typeID);
		return actionID2displayName.get(idPair);
	}

	private static class AgentIDTypeIDPair {
		String agentID;
		String typeID;

		public AgentIDTypeIDPair(String agentID, String typeID) {
			this.agentID = agentID;
			this.typeID = typeID;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result
					+ ((agentID == null) ? 0 : agentID.hashCode());
			result = prime * result
					+ ((typeID == null) ? 0 : typeID.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			AgentIDTypeIDPair other = (AgentIDTypeIDPair) obj;
			if (agentID == null) {
				if (other.agentID != null)
					return false;
			} else if (!agentID.equals(other.agentID))
				return false;
			if (typeID == null) {
				if (other.typeID != null)
					return false;
			} else if (!typeID.equals(other.typeID))
				return false;
			return true;
		}

	}
}
