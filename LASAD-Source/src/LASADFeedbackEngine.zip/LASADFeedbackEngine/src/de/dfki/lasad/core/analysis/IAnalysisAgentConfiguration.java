package de.dfki.lasad.core.analysis;

import de.dfki.lasad.core.PluggableComponentConfiguration;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public interface IAnalysisAgentConfiguration extends
		PluggableComponentConfiguration {

	public OntologyChecker getOntologySupportChecker();

}
