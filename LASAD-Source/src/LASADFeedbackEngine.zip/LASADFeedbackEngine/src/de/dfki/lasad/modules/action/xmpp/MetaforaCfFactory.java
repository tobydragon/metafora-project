package de.dfki.lasad.modules.action.xmpp;

import java.util.ArrayList;
import java.util.List;

import lasad.gwt.client.communication.objects.Action;

import com.sun.java.swing.plaf.motif.resources.motif_zh_TW;

import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfActionType;
import de.uds.commonformat.CfObject;
import de.uds.commonformat.CfProperty;
import de.uds.commonformat.CfUser;
import de.uds.metafora.MetaforaStrings;
import de.uds.xml.XmlFragment;

public class MetaforaCfFactory {
	
//	public static CfAction createDisplayStateUrlMessage(String mapId, String userId, String stateUrl){
//	
//		XmlFragment messageXml = XmlFragment.getFragmentFromFile("resources/xml/commonformat/DisplayStateUrl.xml");
//		if (messageXml != null){
//			CfAction action = CfAction.fromXml(messageXml);
//			action.getCfUsers().get(0).setid(userId);
//			action.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING).setValue(mapId);
//			action.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).setValue(stateUrl);
//			return action;
//		}
//		return null;
//		
//	}
	
	public static CfAction createDisplayStateUrlMessage2(String mapId, String userId, String stateUrl){
		
		CfObject element = new CfObject("0", "element");
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING, mapId));
		element.addProperty(new CfProperty(MetaforaStrings.OBJECT_TYPE_STRING, MetaforaStrings.REFERABLE_OBJECT_STRING));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING, stateUrl));
		CfActionType cfActionType = new CfActionType(MetaforaStrings.ACTION_TYPE_DISPLAY_STATE_URL_STRING, 
				MetaforaStrings.CLASSIFICATION_OTHER_STRING, MetaforaStrings.ACTION_TYPE_SUCCEEDED_UNKNOWN_STRING);
		CfAction cfAction = new CfAction(System.currentTimeMillis(), cfActionType);
		cfAction.addUser(new CfUser(userId, MetaforaStrings.USER_ROLE_ORIGINATOR_STRING));
		cfAction.addObject(element);
		return cfAction;
	}
	

//	<?xml version="1.0" encoding="UTF-8"?>
//	<Action time="1304954004228">
//	  <ActionType type="DISPLAY_STATE_URL" classification="USER_INTERACTION" succeeded="UNKNOWN" />
//	  <users>
//	    <User id="LasadCommand" role="controller" />
//	  </users>
//	  <objects>
//	    <Object id="0" type="element">
//	      <properties>
//	        <Property name="MAP_ID" value="1" />
//	        <Property name="ELEMENT_TYPE" value="Reference" />
//	        <Property name="REFERENCE_URL" value="http://sara.alexander.free.fr/rw_common/themes/blendit/images/header/image4.jpg"/>
//	        </properties>
//	    </Object>
//	  </objects>
//	</Action>
	
//	public static CfAction createObjectMessage(String mapId, String userId, String viewUrl, String text,  String referenceUrl){
//		
//		XmlFragment messageXml = XmlFragment.getFragmentFromFile("resources/xml/commonformat/CreateReferenceNode.xml");
//		if (messageXml != null){
//			CfAction action = CfAction.fromXml(messageXml);
//			action.setTime(System.currentTimeMillis());
//			action.getCfUsers().get(0).setid(userId);
//			action.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING).setValue(mapId);
//			action.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).setValue(referenceUrl);
//			action.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_IMAGE_URL_STRING).setValue(viewUrl);
//			action.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).setValue(text);
//
//			return action;
//		}
//		return null;
//		
//	}
	
	public static CfAction createObjectMessage2(String mapId, String userId, String viewUrl, String text,  String referenceUrl, String username){
		CfObject element = new CfObject("0", "element");
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING, mapId));
		element.addProperty(new CfProperty(MetaforaStrings.OBJECT_TYPE_STRING, MetaforaStrings.OBJECT_TYPE_MICROWORLD_ISSUE_STRING));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING, viewUrl));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING, text));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING, referenceUrl));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_USERNAME_STRING, username));
		CfActionType cfActionType = new CfActionType(MetaforaStrings.ACTION_TYPE_CREATE_ELEMENT_STRING, 
				MetaforaStrings.CLASSIFICATION_OTHER_STRING, MetaforaStrings.ACTION_TYPE_SUCCEEDED_UNKNOWN_STRING);
		CfAction cfAction = new CfAction(System.currentTimeMillis(), cfActionType);
		cfAction.addUser(new CfUser(userId, MetaforaStrings.USER_ROLE_ORIGINATOR_STRING));
		cfAction.addObject(element);
		return cfAction;
	}
	
	public static CfAction createMyModelObjectMessage(String mapId, String userId, String url, String text, String username){
		CfObject element = new CfObject("0", "element");
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING, mapId));
		element.addProperty(new CfProperty(MetaforaStrings.OBJECT_TYPE_STRING, MetaforaStrings.OBJECT_TYPE_MY_MICROWORLD_STRING));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_MODEL_VIEW_URL, url + "&thumbnail=150"));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_RULE_VIEW_URL, url + "&RulesThumbnail=1"));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING, text));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING, url));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_USERNAME_STRING, username));
		CfActionType cfActionType = new CfActionType(MetaforaStrings.ACTION_TYPE_CREATE_ELEMENT_STRING, 
				MetaforaStrings.CLASSIFICATION_OTHER_STRING, MetaforaStrings.ACTION_TYPE_SUCCEEDED_UNKNOWN_STRING);
		CfAction cfAction = new CfAction(System.currentTimeMillis(), cfActionType);
		cfAction.addUser(new CfUser(userId, MetaforaStrings.USER_ROLE_ORIGINATOR_STRING));
		cfAction.addObject(element);
		return cfAction;
	}
	
	
//	public static CfAction createQuestionMessage(String mapId, String userId,String text){
//		
//		XmlFragment messageXml = XmlFragment.getFragmentFromFile("resources/xml/commonformat/CreateQuestionElement.xml");
//		if (messageXml != null){
//			CfAction action = CfAction.fromXml(messageXml);
//			action.setTime(System.currentTimeMillis());
//			action.getCfUsers().get(0).setid(userId);
//			action.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING).setValue(mapId);
//			action.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).setValue(text);
//
//			return action;
//		}
//		return null;
//		
//	}
	
	public static CfAction createQuestionMessage2(String mapId, String userId, String text){
		CfObject element = new CfObject("0", "element");
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING, mapId));
		element.addProperty(new CfProperty(MetaforaStrings.OBJECT_TYPE_STRING, MetaforaStrings.OBJECT_TYPE_QUESTION_STRING));
		element.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING, text));
		CfActionType cfActionType = new CfActionType(MetaforaStrings.ACTION_TYPE_CREATE_ELEMENT_STRING, 
				MetaforaStrings.CLASSIFICATION_OTHER_STRING, MetaforaStrings.ACTION_TYPE_SUCCEEDED_UNKNOWN_STRING);
		CfAction cfAction = new CfAction(System.currentTimeMillis(), cfActionType);
		cfAction.addUser(new CfUser(userId, MetaforaStrings.USER_ROLE_ORIGINATOR_STRING));
		cfAction.addObject(element);
		return cfAction;
	}

}
