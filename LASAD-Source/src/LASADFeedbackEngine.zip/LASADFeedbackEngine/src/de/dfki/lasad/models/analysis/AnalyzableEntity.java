package de.dfki.lasad.models.analysis;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import de.dfki.lasad.models.eue.EUEID;

public class AnalyzableEntity {
	private Set<EUEID> entityComponents = new HashSet<EUEID>();
    
	public AnalyzableEntity(){
		
	}
	
	public AnalyzableEntity(Collection<EUEID> entityComponents) {
		this.entityComponents= new HashSet<EUEID>(entityComponents);
	}
	
	public void setEntityComponents(Collection<EUEID> entityComponents) {
		this.entityComponents= new HashSet<EUEID>(entityComponents);
	}

	public Set<EUEID> getEntityComponents() {
		return entityComponents;
	}
	
	public void addEntityComponent(EUEID entityComponent){
		entityComponents.add(entityComponent);
	}
	
	public String toString(){
		return entityComponents.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((entityComponents == null) ? 0 : entityComponents.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AnalyzableEntity other = (AnalyzableEntity) obj;
		if (entityComponents == null) {
			if (other.entityComponents != null)
				return false;
		} else if (!entityComponents.equals(other.entityComponents))
			return false;
		return true;
	}
	
	
}
