package de.dfki.lasad.core.analysis;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * 
 * @author Oliver Scheuer, isha
 * 
 */
public class AnalysisType {

	private Log logger = LogFactory.getLog(AnalysisType.class);

	private String agentID;
	private String typeID;

	// at system init type: loose coupling through String IDs
	private Map<String, Set<String>> requiredAnalysisAgentIDs2analysisTypeIDs = new HashMap<String, Set<String>>();

	// at service time: tight coupling through Java object references
	private Set<AnalysisType> requiredAnalysisTypes = null;

	private Class<? extends AnalysisResult> resultType;

	protected Locale locale = Locale.ENGLISH;
	String localizedName;

	private OntologyChecker ontologyChecker = new SimpleOntologyChecker();
	private boolean doPublishToEndUser = false;

	public AnalysisType(Class<? extends AnalysisResult> resultType,
			String agentID, String typeID, boolean doPublishToEndUser,
			OntologyChecker ontologyChecker) {
		this.agentID = agentID;
		this.typeID = typeID;
		this.resultType = resultType;
		this.doPublishToEndUser = doPublishToEndUser;
		this.ontologyChecker = ontologyChecker;
	}

	public AnalysisType(Class<? extends AnalysisResult> resultType,
			String agentID, String typeID) {
		this.agentID = agentID;
		this.typeID = typeID;
		this.resultType = resultType;
	}

	public AnalysisType(String agentID, String typeID) {
		this.agentID = agentID;
		this.typeID = typeID;

	}

	public Object getResultType() {
		return resultType;

	}

	public String getAgentID() {
		return agentID;
	}

	public String getTypeID() {
		return typeID;
	}

	public Set<AnalysisType> getRequiredAnalysisTypes() {
		if (requiredAnalysisTypes == null) {
			// initialize action set
			requiredAnalysisTypes = new HashSet<AnalysisType>();
			for (String agentID : getRequiredAnalysisAgentIDs()) {
				for (String typeID : getRequiredAnalysisTypeIDs(agentID)) {
					AnalysisType analysisType = ServiceRegistry
							.getAnalysisType(agentID, typeID);
					requiredAnalysisTypes.add(analysisType);
				}
			}
		}
		return requiredAnalysisTypes;
	}

	private Set<String> getRequiredAnalysisAgentIDs() {
		return requiredAnalysisAgentIDs2analysisTypeIDs.keySet();
	}

	private Set<String> getRequiredAnalysisTypeIDs(String agentID) {
		Set<String> analysisTypes = requiredAnalysisAgentIDs2analysisTypeIDs
				.get(agentID);
		if (analysisTypes != null) {
			return analysisTypes;
		}
		return new HashSet<String>();
	}

	public void addAnalysisTypeID(String agentID, String typeID) {
		Set<String> analysisTypes = requiredAnalysisAgentIDs2analysisTypeIDs
				.get(agentID);
		if (analysisTypes == null) {
			analysisTypes = new HashSet<String>();
			requiredAnalysisAgentIDs2analysisTypeIDs
					.put(agentID, analysisTypes);
		}
		analysisTypes.add(typeID);
	}

	public boolean doPublishToEndUser() {
		return doPublishToEndUser;
	}

	public void setOntologyChecker(OntologyChecker ontologyChecker) {
		this.ontologyChecker = ontologyChecker;
	}

	// all required analysis types must support ontology
	public boolean isOntologySupported(EUEOntology ontology) {
		if (!ontologyChecker.isOntologySupported(ontology)) {
			return false;
		}
		for (AnalysisType analysisType : getRequiredAnalysisTypes()) {
			if (!analysisType.isOntologySupported(ontology)) {
				return false;
			}
		}
		return true;
	}

	public void setDisplayName(String name) {
		localizedName = name;
	}

	public String getDisplayName() {
		return localizedName;
	}

	public void setDoPublishToEndUser(boolean doPublishToEndUser) {
		this.doPublishToEndUser = doPublishToEndUser;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agentID == null) ? 0 : agentID.hashCode());
		result = prime * result + ((typeID == null) ? 0 : typeID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof AnalysisType))
			return false;
		AnalysisType other = (AnalysisType) obj;
		if (agentID == null) {
			if (other.agentID != null)
				return false;
		} else if (!agentID.equals(other.agentID))
			return false;
		if (typeID == null) {
			if (other.typeID != null)
				return false;
		} else if (!typeID.equals(other.typeID))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AnalysisType [agentID=" + agentID + ", typeID=" + typeID + "]";
	}

}
