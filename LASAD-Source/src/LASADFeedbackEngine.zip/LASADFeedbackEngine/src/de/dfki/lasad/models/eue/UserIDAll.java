package de.dfki.lasad.models.eue;

/**
 * 
 * @author Oliver Scheuer
 *
 */
public class UserIDAll extends UserID {

	public UserIDAll() {
		super("ALL USERS");
	}
}
