package de.dfki.lasad.events.eue.session;

import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.models.eue.SessionID;

/**
 * Notification message indicating that the A&F agent is about to join an EUE
 * session. Has to be acknowledged with an {@link AgentJoinSessionConfirmEvent}
 * before the session is actually joined.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AgentJoinSessionAnnounceEvent extends SessionEvent {

	public AgentJoinSessionAnnounceEvent(SessionID sessionID,
			String srcComponent) {
		super(sessionID, srcComponent);
	}

}
