package de.dfki.lasad.core.action;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * An {@link ActionType} describes a specific type of analysis that is used to
 * decide actions / feedback.
 * 
 * @author Oliver Scheuer
 * 
 */
public class SimpleActionType extends ActionType {

	private Log logger = LogFactory.getLog(SimpleActionType.class);

	public static final String DEFAULT_PHASE = "default";
	public static final int DEFAULT_PRIORITY = 0;
	public static final int DEFAULT_REPRESENTATIVENESS = 0;
	public static final boolean DEFAULT_HIGHLIGHTING = true;

	private String defaultFeedbackText = null;

	private Map<String, String> phase2shortFeedback = new HashMap<String, String>();
	private Map<String, String> phase2longFeedback = new HashMap<String, String>();
	private Map<String, Double> phase2Priority = new HashMap<String, Double>();
	private Map<String, Double> phase2Representativeness = new HashMap<String, Double>();
	private Map<String, Boolean> phase2Highlighting = new HashMap<String, Boolean>();

	// control flags that specify how feedback is presented
	private Map<String, Map<String, String>> phase2propName2propValue = new HashMap<String, Map<String, String>>();

	// the actual value will be instantiated dynamically at run time
	private Map<String, Set<String>> phase2dynamicProps = new HashMap<String, Set<String>>();

	public SimpleActionType(String agentID, String typeID) {
		super(agentID, typeID);
	}

	/**
	 * short feedback best suitable for one particular phase
	 * 
	 * @param phaseID
	 * @return short feedback string or <code>null</code> if not available
	 */
	public String getFeedbackShort(String phaseID) {
		String feedback = phase2shortFeedback.get(phaseID);
		return feedback;
	}

	/**
	 * short feedback if phase is unknown
	 * 
	 * @return
	 */
	public String getFeedbackShort() {
		String feedback = phase2shortFeedback.get(DEFAULT_PHASE);
		if (feedback != null) {
			return feedback;
		}
		return getDefaultFeedbackText();
	}

	/**
	 * long feedback if phase is unknown
	 * 
	 * @return
	 */
	public String getFeedbackLong() {
		String feedback = phase2longFeedback.get(DEFAULT_PHASE);
		return feedback;
	}

	public void addFeedbackShort(String phaseID, String feedbackShort) {
		phase2shortFeedback.put(phaseID, feedbackShort);
	}

	/**
	 * 
	 * @param phaseID
	 * @return long feedback string or <code>null</code> if not available
	 */
	public String getFeedbackLong(String phaseID) {
		String feedback = phase2longFeedback.get(phaseID);
		if (feedback != null) {
			return feedback;
		}
		// try ALL_PHASES ...
		return phase2longFeedback.get(DEFAULT_PHASE);
	}

	public void addFeedbackLong(String phaseID, String feedbackLong) {
		phase2longFeedback.put(phaseID, feedbackLong);
	}

	public void addPriority(String phaseID, double priority) {
		phase2Priority.put(phaseID, priority);
	}

	public double getPriority(String phaseID) {
		Double priority = phase2Priority.get(phaseID);
		if (priority != null) {
			return priority;
		}
		// try ALL_PHASES ...
		priority = phase2Priority.get(DEFAULT_PHASE);
		if (priority != null) {
			return priority;
		}
		return DEFAULT_PRIORITY;
	}

	public void addRepresentativeness(String phaseID, double representativeness) {
		phase2Representativeness.put(phaseID, representativeness);
	}

	public double getRepresentativeness(String phaseID) {
		Double representativeness = phase2Representativeness.get(phaseID);
		if (representativeness != null) {
			return representativeness;
		}
		// try ALL_PHASES ...
		representativeness = phase2Representativeness.get(DEFAULT_PHASE);
		if (representativeness != null) {
			return representativeness;
		}
		return DEFAULT_REPRESENTATIVENESS;
	}

	public Boolean doHighlighting(String phaseID) {
		Boolean doHighlighting = phase2Highlighting.get(phaseID);
		return doHighlighting;
	}

	public Boolean doHighlighting() {
		Boolean doHighlighting = phase2Highlighting.get(DEFAULT_PHASE);
		if (doHighlighting != null) {
			return doHighlighting;
		}
		return DEFAULT_HIGHLIGHTING;
	}

	public void addDoHighlighting(String phaseID, boolean doHighlighting) {
		phase2Highlighting.put(phaseID, doHighlighting);
	}

	public String getDefaultFeedbackText() {
		if (defaultFeedbackText == null) {
			defaultFeedbackText = getDisplayName();
		}
		return defaultFeedbackText;
	}

	public void addParam(String phaseID, String paramName, String paramValue) {
		Map<String, String> paramsForPhase = phase2propName2propValue
				.get(phaseID);
		if (paramsForPhase == null) {
			paramsForPhase = new HashMap<String, String>();
			phase2propName2propValue.put(phaseID, paramsForPhase);
		}
		paramsForPhase.put(paramName, paramValue);
	}

	/**
	 * 
	 * @param phaseID
	 * @return set of parameter names for given phaseID or <code>null</code> if
	 *         no params defined for the given phase ID.
	 */
	public Set<String> getParamNames(String phaseID) {
		Map<String, String> paramsForPhase = phase2propName2propValue
				.get(phaseID);
		if (paramsForPhase == null) {
			return null;
		}
		return paramsForPhase.keySet();
	}

	/**
	 * 
	 * @return set of parameter names for default phase or <code>null</code> if
	 *         no params defined for the default phase is not defined.
	 */
	public Set<String> getParamNames() {
		Map<String, String> paramsForPhase = phase2propName2propValue
				.get(DEFAULT_PHASE);
		if (paramsForPhase == null) {
			return null;
		}
		return paramsForPhase.keySet();
	}

	/**
	 * 
	 * @param phaseID
	 * @param paramName
	 * @return parameter value for given phaseID and param name, or
	 *         <code>null</code> if phaseID and param name are not defined.
	 */
	public String getParamValue(String phaseID, String paramName) {
		Map<String, String> paramsForPhase = phase2propName2propValue
				.get(phaseID);
		if (paramsForPhase == null) {
			return null;
		}
		return paramsForPhase.get(paramName);
	}

	/**
	 * 
	 * @param phaseID
	 * @param paramName
	 * @return parameter value for given phaseID and param name, or
	 *         <code>null</code> if phaseID and param name are not defined.
	 */
	public String getParamValue(String paramName) {
		Map<String, String> paramsForPhase = phase2propName2propValue
				.get(DEFAULT_PHASE);
		if (paramsForPhase == null) {
			return null;
		}
		return paramsForPhase.get(paramName);
	}

	public void addDynamicParam(String phaseID, String paramName) {
		Set<String> paramsForPhase = phase2dynamicProps.get(phaseID);

		if (paramsForPhase == null) {
			paramsForPhase = new HashSet<String>();
			phase2dynamicProps.put(phaseID, paramsForPhase);
		}
		paramsForPhase.add(paramName);
	}

	/**
	 * 
	 * @param phaseID
	 * @return set of parameter names for given phaseID or <code>null</code> if
	 *         no params defined for the given phase ID.
	 */
	public Set<String> getDynamicParamNames(String phaseID) {
		return phase2dynamicProps.get(phaseID);
	}

	/**
	 * 
	 * @return set of parameter names for default phase or <code>null</code> if
	 *         no params defined for the default phase is not defined.
	 */
	public Set<String> getDynamicParamNames() {
		return phase2dynamicProps.get(DEFAULT_PHASE);
	}

}
