package de.dfki.lasad.models.action;

import de.dfki.lasad.models.analysis.AnalysisResult;

/**
 * Marker interface for {@link ActionComponent}s that resulted from a
 * pedagogical strategy (e.g., {@link Message}s and {@link MessageWithHighlighting}),
 * and 'raw' {@link AnalysisResult}s.
 * 
 * @author Oliver Scheuer
 * 
 */
public interface ActionComponent {

}
