package de.dfki.lasad.events.eue.session;

import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.models.eue.SessionID;

public class EUESessionEvent extends SessionEvent implements EUEEvent{

	protected EUEEventID eueEventID;

	public EUESessionEvent(SessionID sessionID, String srcCompId) {
		super(sessionID, srcCompId);
	}

	public EUESessionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID) {
		this(sessionID, srcCompId);
		this.eueEventID = eueEventID;
	}

	public void setEueEventID(EUEEventID eueEventID) {
		this.eueEventID = eueEventID;
	}

	public EUEEventID getEueEventID() {
		return eueEventID;
	}

	@Override
	public String toString() {
		return super.toString() + ", eueEventID=" + eueEventID;
	}

}
