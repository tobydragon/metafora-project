package de.dfki.lasad.modules.application.argunaut;

import de.dfki.lasad.models.eue.objects.BasicPropertyFactory;
import de.dfki.lasad.modules.analysis.SimplePropertyMappingsConfiguration;
import de.dfki.lasad.modules.analysis.deeploop.graphml.GraphMLVocabulary;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class DeepLoopPropertyMappingsConfiguration extends
		SimplePropertyMappingsConfiguration {

	public DeepLoopPropertyMappingsConfiguration() {
		addPropMapping("headline", "TEXT", GraphMLVocabulary.NODE_TITLE);
		addPropMapping("text", "TEXT", GraphMLVocabulary.NODE_CONTENT);

		addNodePropMappings("claim");
		addNodePropMappings("argument");
		addNodePropMappings("task");
		addNodePropMappings("question");
		addNodePropMappings("explanation");

		addLinkPropMappings("Link");
		addLinkPropMappings("oppose");
		addLinkPropMappings("support");
	}

	public final void addNodePropMappings(String nodeType) {
		addPropMapping(nodeType, BasicPropertyFactory.CREATOR,
				GraphMLVocabulary.NODE_CREATOR);
		addPropMapping(nodeType, BasicPropertyFactory.CREATION_TS,
				GraphMLVocabulary.NODE_CREATIONDATE);
		addPropMapping(nodeType, BasicPropertyFactory.FIRST_MODIFIER,
				GraphMLVocabulary.NODE_FIRST_MODIFICATOR);
		addPropMapping(nodeType, BasicPropertyFactory.FIRST_MODIFICATION_TS,
				GraphMLVocabulary.NODE_FIRST_MODIFICATIONDATE);
		addPropMapping(nodeType, BasicPropertyFactory.LAST_MODIFIER,
				GraphMLVocabulary.NODE_LAST_MODIFICATOR);
		addPropMapping(nodeType, BasicPropertyFactory.LAST_MODIFICATION_TS,
				GraphMLVocabulary.NODE_LAST_MODIFICATIONDATE);
	}

	public final void addLinkPropMappings(String linkType) {
		addPropMapping(linkType, BasicPropertyFactory.CREATOR,
				GraphMLVocabulary.LINK_CREATOR);
		addPropMapping(linkType, BasicPropertyFactory.CREATION_TS,
				GraphMLVocabulary.LINK_CREATIONDATE);
		addPropMapping(linkType, BasicPropertyFactory.LAST_MODIFICATION_TS,
				GraphMLVocabulary.LINK_LAST_MODIFICATIONDATE);
	}
}
