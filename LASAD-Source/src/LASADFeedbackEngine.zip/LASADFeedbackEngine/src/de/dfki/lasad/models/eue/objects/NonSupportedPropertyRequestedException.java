package de.dfki.lasad.models.eue.objects;

/**
 * 
 * @author Oliver Scheuer
 *
 */
public class NonSupportedPropertyRequestedException extends Exception {

	public NonSupportedPropertyRequestedException(String source, String propName) {
		super("Property type '" + propName + "' is not supported by '" + source + "'.");
	}
}
