package de.dfki.lasad.models.eue.ontology.graph;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class NodeType extends ElementType {

	public NodeType(String id) {
		super(id);
	}

}
