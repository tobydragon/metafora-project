package de.dfki.lasad.modules.dataservice.lasad.translators;

import de.dfki.lasad.events.eue.session.EUEEventID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class EUEEventIDGenerator {

	private static int counter = 0;

	public static synchronized EUEEventID getNextID() {
		return new EUEEventID(String.valueOf(++counter));
	}
}
