package de.dfki.lasad.core.action;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * An {@link ActionType} that describes an analysis that is based on the
 * filtering and ordering of Actions according to a predefined set of criteria.
 * 
 * @author Oliver Scheuer
 * 
 */
public class CompoundActionType extends ActionType {

	public static final int ALL_RESULTS = -1;
	
	// subactions are all actions from one agent
	public static final String ALL_TYPES = "ALL_TYPES";

	// filter and sort criteria
	public static final String ONE_PER_TYPE = "ONE_PER_TYPE";
	
	// at system init type: loose coupling through String IDs
	private Map<String, Set<String>> subActionAgentIDs2actionTypeIDs = new HashMap<String, Set<String>>();

	// at service time: tight coupling through Java object references
	private Set<ActionType> subActionTypes = null;

	private int maxNumResults = ALL_RESULTS; // -1 ... unlimited
	private List<String> filterAndSortCriteria = new Vector<String>();

	public CompoundActionType(String actionAgentID, String actionTypeID) {
		super(actionAgentID, actionTypeID);
	}

	/**
	 * For debugging purposes. Instead of using the full-fledged infrastructure
	 * to access dependent {@link ActionType}s (which might not be initialized
	 * in a testing scenario), {@link ActionType}s are provided here directly.
	 * 
	 * @param actionAgentID
	 * @param actionTypeID
	 * @param subActionTypes
	 */
	public CompoundActionType(String actionAgentID, String actionTypeID,
			Set<ActionType> subActionTypes) {
		this(actionAgentID, actionTypeID);
		this.subActionTypes = subActionTypes;
	}

	public void addFilterCriterion(String criterion) {
		filterAndSortCriteria.add(criterion);
	}

	/**
	 * Returns all dependent {@link ActionType}s. Important: If this is the
	 * first access {@link ActionType}s will be retrieved from the
	 * {@link ServiceRegistry}.
	 * 
	 * @return
	 */
	public Set<ActionType> getSubActionTypes() {
		if (subActionTypes == null) {
			// initialize action set
			subActionTypes = new HashSet<ActionType>();
			for (String agentID : getActionAgentIDs()) {
				for (String typeID : getActionTypeIDs(agentID)) {
					if (ALL_TYPES.equals(typeID)) {
						IActionAgent agent = ServiceRegistry
								.getActionAgent(agentID);
						for (ActionType actionType : agent
								.getComponentDescription().getAllActionTypes()) {
							if (actionType instanceof SimpleActionType) {
								subActionTypes.add(actionType);
							}
						}
					} else {
						ActionType actionType = ServiceRegistry.getActionType(
								agentID, typeID);
						subActionTypes.add(actionType);
					}

				}
			}
		}
		return subActionTypes;
	}

	private Set<String> getActionAgentIDs() {
		return subActionAgentIDs2actionTypeIDs.keySet();
	}

	private Set<String> getActionTypeIDs(String agentID) {
		Set<String> actionTypes = subActionAgentIDs2actionTypeIDs.get(agentID);
		if (actionTypes != null) {
			return actionTypes;
		}
		return new HashSet<String>();
	}

	public void addActionTypeID(String agentID, String typeID) {
		Set<String> actionTypes = subActionAgentIDs2actionTypeIDs.get(agentID);
		if (actionTypes == null) {
			actionTypes = new HashSet<String>();
			subActionAgentIDs2actionTypeIDs.put(agentID, actionTypes);
		}
		actionTypes.add(typeID);
	}

	public List<String> getCriteria() {
		return filterAndSortCriteria;
	}

	public int getMaxNumResults() {
		return maxNumResults;
	}

	public void setMaxNumResults(int maxNumResults) {
		this.maxNumResults = maxNumResults;
	}

	@Override
	public boolean isOntologySupported(EUEOntology ontology) {
		if (!super.isOntologySupported(ontology)) {
			return false;
		}
		for (ActionType actionType : getSubActionTypes()) {
			if (!actionType.isOntologySupported(ontology)) {
				return false;
			}
		}
		return true;
	}

}
