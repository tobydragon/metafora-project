package de.dfki.lasad.modules.action.jess;

import java.io.File;
import java.io.StringWriter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import de.dfki.lasad.core.action.ActionType;
import de.dfki.lasad.core.action.CompoundActionType;
import de.dfki.lasad.core.action.RuleBasedActionType;
import de.dfki.lasad.core.action.SimpleActionType;
import de.dfki.lasad.core.analysis.OntologyChecker;
import de.dfki.lasad.core.analysis.SimpleOntologyChecker;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessFeedbackAgentConfigParser {

	static Log logger = LogFactory.getLog(JessFeedbackAgentConfigParser.class);

	private static boolean exposeAll = false;
	private static Set<String> supportedOntologyIDs = new HashSet<String>();

	public static void fillInConfigFromFile(File confFile,
			JessFeedbackAgentConfiguration conf) {
		try {

			SAXBuilder builder = new SAXBuilder();
			Document doc = builder.build(confFile);

			Element agentElem = doc.getRootElement();
			String agentID = agentElem.getAttributeValue("id");
			conf.setAgentID(agentID);

			String exposeAllString = agentElem.getAttributeValue("expose_all");
			if (exposeAllString != null && Boolean.valueOf(exposeAllString)) {
				exposeAll = Boolean.valueOf(exposeAllString);
			}

			String provideRawResultsString = agentElem
					.getAttributeValue("raw_results");
			if (provideRawResultsString != null
					&& Boolean.valueOf(provideRawResultsString)) {
				conf.setProvideRawResults(Boolean
						.valueOf(provideRawResultsString));
			}

			Element supportedOntologyElem = agentElem
					.getChild("supported_ontologies");
			@SuppressWarnings("unchecked")
			List<Element> ontologyIDElements = supportedOntologyElem
					.getChildren("ontology");
			supportedOntologyIDs = parseOntologyIDElements(ontologyIDElements);

			Element phaseDefElem = agentElem.getChild("phase_def");
			@SuppressWarnings("unchecked")
			List<Element> phaseIDElements = phaseDefElem.getChildren("phase");
			Set<String> phaseIDs = parsePhaseIDElements(phaseIDElements);
			conf.setPhaseIDs(phaseIDs);

			@SuppressWarnings("unchecked")
			List<Element> ruleActionElements = agentElem
					.getChildren("rule-action");
			List<RuleBasedActionType> ruleActionTypes = parseRuleActionElements(
					ruleActionElements, agentID);
			addRuleActionElementsToConf(ruleActionTypes, conf);

			@SuppressWarnings("unchecked")
			List<Element> filterActionElements = agentElem
					.getChildren("filter-action");
			List<CompoundActionType> compoundActionTypes = parseFilterActionElements(
					filterActionElements, agentID);
			addFilterActionElementsToConf(compoundActionTypes, conf);

		} catch (Exception e) {
			logger.error("Error while parsing log file: " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	private static void addRuleActionElementsToConf(
			List<RuleBasedActionType> ruleActionTypes,
			JessFeedbackAgentConfiguration conf) {
		for (RuleBasedActionType ruleActionType : ruleActionTypes) {
			conf.addRuleBaseActionType(ruleActionType);
		}
	}

	private static Set<String> parsePhaseIDElements(
			List<Element> phaseIDElements) {
		Set<String> phaseIDs = new HashSet<String>();
		for (Element phaseIDElem : phaseIDElements) {
			String phaseID = phaseIDElem.getAttributeValue("id");
			phaseIDs.add(phaseID);
		}
		return phaseIDs;
	}

	private static Set<String> parseOntologyIDElements(
			List<Element> ontologyIDElements) {
		Set<String> ontologyIDs = new HashSet<String>();
		for (Element ontologyIDElem : ontologyIDElements) {
			String ontologyID = ontologyIDElem.getAttributeValue("id");
			ontologyIDs.add(ontologyID);
		}
		return ontologyIDs;
	}

	private static List<RuleBasedActionType> parseRuleActionElements(
			List<Element> ruleActionElements, String agentID) {

		List<RuleBasedActionType> ruleBasedActionTypes = new Vector<RuleBasedActionType>();
		for (Element ruleActionElem : ruleActionElements) {
			String typeID = ruleActionElem.getAttributeValue("id");
			RuleBasedActionType actionType = new RuleBasedActionType(agentID,
					typeID);

			Element displayNameElement = ruleActionElem
					.getChild("display-name");
			if (displayNameElement != null) {
				String displayName = displayNameElement.getText();
				actionType.setDisplayName(displayName);
			}

			Element ruleSpecElem = ruleActionElem.getChild("rule_spec");
			String ruleSpec = ruleSpecElem.getText();
			actionType.setRule(ruleSpec);

			Element phasesElem = ruleActionElem.getChild("phases");
			@SuppressWarnings("unchecked")
			List<Element> phaseElements = phasesElem.getChildren("phase");
			boolean defaultPhaseFound = false;
			for (Element phaseElem : phaseElements) {
				String phaseID = phaseElem.getAttributeValue("id");
				if ("default".equals(phaseID)) {
					if (defaultPhaseFound == true) {
						logger.warn("Two default phases defined for: "
								+ actionType);
					}
					defaultPhaseFound = true;
					phaseID = SimpleActionType.DEFAULT_PHASE;
				}
				String isDefaultPhaseString = phaseElem
						.getAttributeValue("is_default");
				boolean isDefaultPhase = Boolean.valueOf(isDefaultPhaseString);
				if (isDefaultPhase == true) {
					if (defaultPhaseFound == true) {
						logger.warn("Two default phases defined for: "
								+ actionType);
					}
					defaultPhaseFound = true;
				}

				Element priorityElem = phaseElem.getChild("priority");
				double priority = Double
						.parseDouble(priorityElem.getTextTrim());
				actionType.addPriority(phaseID, priority);

				Element representativenessElem = phaseElem
						.getChild("representativeness");
				double representativeness = Double
						.parseDouble(representativenessElem.getTextTrim());
				actionType.addRepresentativeness(phaseID, representativeness);

				Element feedbackShortElem = phaseElem
						.getChild("feedback-short");
				// String feedbackShort =
				// getXMLContentAsString(feedbackShortElem).trim();
				String feedbackShort = feedbackShortElem.getTextNormalize();
				if (!feedbackShort.isEmpty()) {
					actionType.addFeedbackShort(phaseID, feedbackShort);
					if (isDefaultPhase) {
						actionType.addFeedbackShort(
								SimpleActionType.DEFAULT_PHASE, feedbackShort);
					}
				}

				Element feedbackLongElem = phaseElem.getChild("feedback-long");
				// String feedbackLong =
				// getXMLContentAsString(feedbackLongElem).trim();
				String feedbackLong = feedbackLongElem.getTextNormalize();
				if (!feedbackLong.isEmpty()) {
					actionType.addFeedbackLong(phaseID, feedbackLong);
					if (isDefaultPhase) {
						actionType.addFeedbackLong(
								SimpleActionType.DEFAULT_PHASE, feedbackLong);
					}
				}

				Element highlightingElem = phaseElem.getChild("highlighting");
				if (highlightingElem != null) {
					String highlightingString = highlightingElem
							.getTextNormalize();
					boolean highlighting = Boolean
							.parseBoolean(highlightingString);
					actionType.addDoHighlighting(phaseID, highlighting);
					if (isDefaultPhase) {
						actionType.addDoHighlighting(
								SimpleActionType.DEFAULT_PHASE, highlighting);
					}
				}

				Element additionalParamsElem = phaseElem
						.getChild("addition-params");
				if (additionalParamsElem != null) {
					@SuppressWarnings("unchecked")
					List<Element> paramElems = additionalParamsElem
							.getChildren("param");
					parseAdditionalParameters(actionType, paramElems, phaseID,
							isDefaultPhase);
				}
			}
			if (exposeAll) {
				actionType.setDoPublishToEndUser(true);
			} else {
				// read individual property
				Element exposeElem = ruleActionElem.getChild("expose");
				boolean doExpose = Boolean.parseBoolean(exposeElem
						.getTextTrim());
				actionType.setDoPublishToEndUser(doExpose);
			}
			// TODO: process dependent analyses

			setSupportedOntologyIDs(actionType);
			ruleBasedActionTypes.add(actionType);
		}
		return ruleBasedActionTypes;
	}

	private static void parseAdditionalParameters(
			RuleBasedActionType actionType, List<Element> paramElems,
			String phaseID, boolean isDefaultPhase) {
		for (Element paramElem : paramElems) {
			String paramName = paramElem.getAttributeValue("name");
			String paramValue = paramElem.getAttributeValue("value");
			Boolean paramIsDynamic = Boolean.parseBoolean(paramElem
					.getAttributeValue("dynamic"));
			if (paramIsDynamic) {
				actionType.addDynamicParam(phaseID, paramName);
				if (isDefaultPhase) {
					actionType.addDynamicParam(SimpleActionType.DEFAULT_PHASE,
							paramName);
				}
			} else {
				// assume: param is static
				actionType.addParam(phaseID, paramName, paramValue);
				if (isDefaultPhase) {
					actionType.addParam(SimpleActionType.DEFAULT_PHASE,
							paramName, paramValue);
				}
			}
		}
	}

	private static void addFilterActionElementsToConf(
			List<CompoundActionType> filterActionTypes,
			JessFeedbackAgentConfiguration conf) {
		for (CompoundActionType compoundActionType : filterActionTypes) {
			conf.addCompoundActionType(compoundActionType);
		}
	}

	private static List<CompoundActionType> parseFilterActionElements(
			List<Element> filterActionElements, String agentID) {
		List<CompoundActionType> compoundActionTypes = new Vector<CompoundActionType>();
		for (Element filterActionElem : filterActionElements) {
			String typeID = filterActionElem.getAttributeValue("id");
			CompoundActionType actionType = new CompoundActionType(agentID,
					typeID);

			Element displayNameElement = filterActionElem
					.getChild("display-name");
			if (displayNameElement != null) {
				String displayName = displayNameElement.getTextNormalize();
				actionType.setDisplayName(displayName);
			}

			Element numberElem = filterActionElem.getChild("number");
			String numberString = numberElem.getTextTrim();
			if ("all".equals(numberString)) {
				actionType.setMaxNumResults(CompoundActionType.ALL_RESULTS);
			} else {
				try {
					int number = Integer.parseInt(numberString);
					actionType.setMaxNumResults(number);
				} catch (NumberFormatException e) {
					logger.warn("Parameter 'number' not formatted correctly "
							+ "in config file. Will use default value: "
							+ actionType.getMaxNumResults());
				}
			}

			Element dependentActionsElem = filterActionElem
					.getChild("subactions");
			@SuppressWarnings("unchecked")
			List<Element> agentElements = dependentActionsElem
					.getChildren("action");
			for (Element agentElem : agentElements) {
				String dependentAgentID = agentElem.getAttributeValue("agent");
				String dependentTypeID = agentElem.getAttributeValue("type");
				if ("all_types".equals(dependentTypeID)) {
					actionType.addActionTypeID(dependentAgentID,
							CompoundActionType.ALL_TYPES);
				} else {
					actionType.addActionTypeID(dependentAgentID,
							dependentTypeID);
				}
			}

			Element filterCriteriaElem = filterActionElem
					.getChild("filter-criteria");
			@SuppressWarnings("unchecked")
			List<Element> criterionElements = filterCriteriaElem
					.getChildren("criterion");
			for (Element criterionElement : criterionElements) {
				String criterionID = criterionElement.getAttributeValue("id");
				actionType.addFilterCriterion(criterionID);
			}

			Element exposeElem = filterActionElem.getChild("expose");
			boolean doExpose = Boolean.parseBoolean(exposeElem.getTextTrim());
			actionType.setDoPublishToEndUser(doExpose);

			compoundActionTypes.add(actionType);
		}
		return compoundActionTypes;
	}

	private static void setSupportedOntologyIDs(ActionType actionType) {
		OntologyChecker ontologyChecker = new SimpleOntologyChecker(
				supportedOntologyIDs);
		actionType.setOntologyChecker(ontologyChecker);
	}

	private static String getXMLContentAsString(Element elem) {
		try {
			StringWriter writer = new StringWriter();
			XMLOutputter xmlOutputter = new XMLOutputter(Format.getRawFormat());
			xmlOutputter.output(elem.getContent(), writer);
			return writer.toString();
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}
}
