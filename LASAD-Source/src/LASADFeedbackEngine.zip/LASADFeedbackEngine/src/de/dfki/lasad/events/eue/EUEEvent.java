package de.dfki.lasad.events.eue;

/**
 * Marker interface.
 * @author Oliver Scheuer
 *
 */
public interface EUEEvent {

}
