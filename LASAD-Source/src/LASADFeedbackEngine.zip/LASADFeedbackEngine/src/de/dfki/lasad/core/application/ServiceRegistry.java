package de.dfki.lasad.core.application;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.action.ActionType;
import de.dfki.lasad.core.action.IActionAgent;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.core.dataservice.IDataService;
import de.dfki.lasad.core.worldmodel.IModelController;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class ServiceRegistry {

	static Log logger = LogFactory.getLog(ServiceRegistry.class);

	private static IConfiguration appConfiguration = new MinimalAppConfiguration();
	private static Map<String, IAnalysisAgent> analysisAgents = new HashMap<String, IAnalysisAgent>();
	private static Map<String, IActionAgent> actionAgents = new HashMap<String, IActionAgent>();
	private static IDataService dataService;
	private static IModelController worldModel;

	private static Map<SessionID, EUEOntology> sessionID2ontology = new HashMap<SessionID, EUEOntology>();

	public static void registerAppConfig(IConfiguration conf) {
		if (!(ServiceRegistry.appConfiguration instanceof MinimalAppConfiguration)) {
			logger.warn("There is already an instance of '"
					+ IConfiguration.class.getName()
					+ "' registered. Will overwrite.");
		} else {
			logger.info("Replacing "
					+ MinimalAppConfiguration.class.getSimpleName() + " with "
					+ conf.getClass().getSimpleName() + ".");
		}
		appConfiguration = conf;
	}

	public static IConfiguration getAppConfig() {
		if (ServiceRegistry.appConfiguration instanceof MinimalAppConfiguration) {
			logger.warn("No instance of '" + IConfiguration.class.getName()
					+ "' registered yet. Use "
					+ MinimalAppConfiguration.class.getName());
		}
		return appConfiguration;
	}

	public static void registerModelController(IModelController worldModel) {
		ServiceRegistry.worldModel = worldModel;
	}

	public static IModelController getModelController() {
		return worldModel;
	}

	public static void registerDataService(IDataService dataService) {
		ServiceRegistry.dataService = dataService;
	}

	public static IDataService getDataService() {
		return dataService;
	}

	public static void registerAnalysisModule(IAnalysisAgent analysisAgent) {
		analysisAgents.put(analysisAgent.getComponentDescription()
				.getComponentID(), analysisAgent);
	}

	public static Set<String> getAnalysisAgentIDs() {
		return analysisAgents.keySet();
	}

	public static IAnalysisAgent getAnalysisAgent(String analysisAgentID) {
		return analysisAgents.get(analysisAgentID);
	}

	public static AnalysisType getAnalysisType(String analysisAgentID,
			String analysisTypeID) {
		return analysisAgents.get(analysisAgentID).getComponentDescription()
				.getAnalysisType(analysisTypeID);
	}

	public static void registerActionModule(IActionAgent actionAgent) {
		actionAgents.put(
				actionAgent.getComponentDescription().getComponentID(),
				actionAgent);
	}

	public static Set<String> getActionAgentIDs() {
		return actionAgents.keySet();
	}

	public static IActionAgent getActionAgent(String actionAgentID) {
		return actionAgents.get(actionAgentID);
	}

	public static ActionType getActionType(String actionAgentID,
			String actionTypeID) {
		return actionAgents.get(actionAgentID).getComponentDescription()
				.getActionType(actionTypeID);
	}

	public static void registerOntology(SessionID sessionID,
			EUEOntology ontology) {
		sessionID2ontology.put(sessionID, ontology);
	}

	public static Map<SessionID, EUEOntology> getOntologies() {
		return sessionID2ontology;
	}

	public static EUEOntology getOntology(SessionID sessionID) {
		return sessionID2ontology.get(sessionID);
	}

}
