package de.dfki.lasad.modules.action.xmpp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.action.AbstractActionAgent;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.ManagementResponseEvent;
import de.dfki.lasad.events.eue.session.UserActionEvent;
import de.dfki.lasad.events.eue.session.UserFeedbackRequestEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserCreateObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserModifyObjectEvent;
import de.dfki.lasad.models.action.XmppActionComponent;
import de.dfki.lasad.models.action.XmppActionSpec;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.objects.EUEObject;
import de.dfki.lasad.modules.dataservice.lasad.translators.LASADVocabulary;
import de.dfki.lasad.util.ErrorUtil;
import de.dfki.lasad.util.GeneralUtil;
import de.kuei.metafora.xmpp.XMPPBridge;
import de.kuei.metafora.xmpp.XMPPMessageListener;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;
import de.uds.commonformat.CfProperty;
import de.uds.metafora.MetaforaStrings;
import de.uds.xml.XmlConfigParser;
import de.uds.xml.XmlFragment;

public class XmppActionAgent extends AbstractActionAgent implements XMPPMessageListener{
	
//---------------------------  static xmpp config --------------------------//
	
	private static final long MAX_LAG_MESSAGE_MILLIS = 20000;
	private static final List<String> controllingUsers = new ArrayList<String>();
	private static String connectionName = null;
	
	static {
		try {
			String connectionConfigFilepath = "conf/xmpp/xmpp-command-connect-settings.xml";
			XmlConfigParser connectionParser = new XmlConfigParser(connectionConfigFilepath);
			
			connectionName = connectionParser.getConfigValue("connection-name");
			controllingUsers.add(connectionParser.getConfigValue("controller-name"));

			String userName = connectionParser.getConfigValue("username");
			String password = connectionParser.getConfigValue("password");
			String chatroom = connectionParser.getConfigValue("chatroom");
			String alias = connectionParser.getConfigValue("alias");
			String device = connectionParser.getConfigValue("device");
			XMPPBridge.createConnection(connectionName, userName, password, chatroom, alias, device);
		}
		catch(Exception e){
			System.out.println("[CfXmppWriter] error creating connection - " + e.getMessage());
		}
	}
	

//-----------------------------Object level (non-static) -----------------//
	
	Log logger = LogFactory.getLog(XmppActionAgent.class);

	XMPPBridge xmppBridge;
	List<CfAction> managementEventsAwaitingResponse;
	List<CfAction> createWaitingToModifyActions;
	
	//Standard call to create xmppAgent
	public XmppActionAgent(){
		this(true);
	}
	
	//special constructor to allow for disabled xmpp agent for testing
	XmppActionAgent(boolean connectToSource){
		managementEventsAwaitingResponse = new ArrayList<CfAction>();
		createWaitingToModifyActions = new ArrayList<CfAction>();
		if (connectToSource){
			try{
				xmppBridge = XMPPBridge.getConnection(connectionName);
				xmppBridge.connect(true);
				xmppBridge.registerListener(this);
				xmppBridge.sendMessage(connectionName + " connected at " + System.currentTimeMillis());
				logger.info(connectionName + " connected to xmppBridge at" + new Date());

			}
			catch(Exception e){
				logger.error("[constructor] " + ErrorUtil.getStackTrace(e) );
			}
		}
		else {
			logger.info("LasadCommand NOT connected at" + new Date());
		}
	}
	
	
//------------------------  XMPP message handling  -----------------------//
	
	public void newMessage(String user, String message, String chat) {
		logger.info("[" + user + "]" + message);
		processNewMessage(message);		
	}
	
	public void processNewMessage(String message){
		message = XmlFragment.convertSpecialCharactersToDescripitons(message);
		XmlFragment actionXml = XmlFragment.getFragmentFromString(message);
		if (actionXml != null){
			CfAction action = CfAction.fromXml(actionXml);
			if (shouldTakeActionOnMessage(action)){
				sendAction(action);	
			}
		}
		else {
			logger.info("[newMessage] No Action xml recognized" );
		}
	}

	boolean shouldTakeActionOnMessage(CfAction action) {
		String userId = action.getUserWithRole(MetaforaStrings.USER_ROLE_ORIGINATOR_STRING).getid();
		if (shouldTakeActionsFromUser(userId)){
			if (isMessageRecent(action.getTime())){
				return true;
			}
			else {
				logger.info("[newMessage] Old action being ignored");
			}
		}
		else {
			logger.info("[newMessage] Ignoring messages from user - " + userId );
		}
		return false;
	}
	
	public boolean shouldTakeActionsFromUser(String userId){
		for (String controllingUser : controllingUsers){
			if (controllingUser.equalsIgnoreCase(userId)){
				return true;
			}
		}
		return false;
	}
	
	public static boolean isMessageRecent(long messageTime){
		return GeneralUtil.isTimeRecent(messageTime, MAX_LAG_MESSAGE_MILLIS);
	}
	
	public void sendAction(CfAction action){
		
		//todo: update with expresser and remove
		expresserFixes(action);
		
		XmppActionComponent xmppActionComponent = new XmppActionComponent(action);
		addToResponseLists(action);
		
		ActionSpecEvent actionSpecEvent = new ActionSpecEvent(null, null);
		XmppActionSpec xmppActionSpec = new XmppActionSpec();
		xmppActionSpec.addActionComponent(xmppActionComponent);
		actionSpecEvent.addActionSpec(xmppActionSpec);
		forwardToActionController(actionSpecEvent);
	}
	
	private void addToResponseLists(CfAction action){
		if (MetaforaStrings.ACTION_TYPE_CREATE_ELEMENT_STRING.equalsIgnoreCase(action.getCfActionType().getType())){
			createWaitingToModifyActions.add(action);
		}
		else if (MetaforaStrings.CLASSIFICATION_OTHER_STRING.equalsIgnoreCase(action.getCfActionType().getClassification())){
			if (isManagementAction(action)){
					managementEventsAwaitingResponse.add(action);
			}
		}
	}
	
	
	
	private boolean isManagementAction(CfAction action) {
		String actionType = action.getCfActionType().getType();
		if (actionType.equalsIgnoreCase(MetaforaStrings.CREATE_USER_STRING)
				|| actionType.equalsIgnoreCase(MetaforaStrings.CREATE_MAP_STRING)){
			return true;
		}
		return false;
	}

	//------------------------  EUEEvent handling  -----------------------//
	
	
	
	@Override
	public void onEUEEvent(EUESessionEvent event) {
		if (event instanceof UserActionEvent){
			if (isMessageRecent(event.getTs())){
				UserActionEvent actionEvent = (UserActionEvent) event;
				logger.debug("[onEUEEvent] userActionEvent xml - \n" + actionEvent.toXml().toString());
				
				if (event instanceof UserCreateObjectEvent){
					UserCreateObjectEvent uEvent = (UserCreateObjectEvent) event;
					sendCreateResponseUpdates(uEvent);	
				}
				else if (event instanceof UserModifyObjectEvent){
					UserModifyObjectEvent modifyEvent = (UserModifyObjectEvent) event;
					String modifiedType = modifyEvent.getEueObjectList().get(0).getType();
					
					if ("issue-xmpp-button".equalsIgnoreCase(modifiedType) ){
						String mapId = modifyEvent.getSessionID().getIdAsString();
						String userId = modifyEvent.getUserID().getIdAsString();
						String stateUrl = modifyEvent.getEueObjectList().get(0).getPropValue("LINK").getValueAsString();
						CfAction action = MetaforaCfFactory.createDisplayStateUrlMessage2(mapId, userId, stateUrl);
						logger.debug("[onEUEEvent] Sending DISPLAY_STATE_URL command - " + action.toXml());
						String toSend = action.toXml().toStringRaw();
		//					toSend = XmlFragment.convertSpecialCharacterDescriptionsBack(toSend);
						xmppBridge.sendMessage(toSend);
					}
				}
		//		else if (event instanceof UserDeleteObjectEvent){
		//			UserDeleteObjectEvent uEvent = (UserDeleteObjectEvent) event;
		//		}
			}
		}
		else if (event instanceof ManagementResponseEvent){
			logger.debug("[onEUEEvent] [ManagementResponseEvent - " + event.toString() + "]");
			sendManagementAcknowledgements((ManagementResponseEvent)event);
		}
	}
	
	private void sendManagementAcknowledgements(ManagementResponseEvent mEvent){
		
		boolean foundOriginalManagmentAction = false;
		Iterator<CfAction> actionsToCheck = managementEventsAwaitingResponse.iterator();
		while (actionsToCheck.hasNext()){
			CfAction actionToCheck = actionsToCheck.next();
			if (!foundOriginalManagmentAction && eventIsManagementResponse(mEvent, actionToCheck)){
				actionsToCheck.remove();				
				sendManagementAcknowledgement(actionToCheck, mEvent);
				foundOriginalManagmentAction = true;
			}
				
		}
		if (! foundOriginalManagmentAction) {
			logger.error("[onEUEEvent] ManagemtResponse with no match for [event - " + mEvent +" ]");
		}
	}
	
	private void sendManagementAcknowledgement(CfAction actionToAcknowledge, ManagementResponseEvent response){
		actionToAcknowledge.setTime(System.currentTimeMillis());
		actionToAcknowledge.getCfActionType().setSucceed(Boolean.toString( (response).isSuccess()) );
		actionToAcknowledge.getUserWithRole(MetaforaStrings.USER_ROLE_ORIGINATOR_STRING).setid(MetaforaStrings.LASAD_AGENT_USER_ID_STRING);
		String  messageToSend = actionToAcknowledge.toXml().toString();
		if (messageToSend != null){
			xmppBridge.sendMessage(messageToSend);
			logger.info("[onEUEEvent] sent message: " + messageToSend);
		}
		else {
			logger.error("[onEUEEvent] no message to send for [event - " + response +"]");
		}
	}
	
	private boolean eventIsManagementResponse(ManagementResponseEvent mEvent, CfAction actionToCheck){
		String username = actionToCheck.getCfObjects().get(0).getPropertyValue(MetaforaStrings.PROPERTY_USERNAME_STRING);
		String messageString = "(" + username + ")";
		if (mEvent.getCommand().equalsIgnoreCase("AUTHORING-FAILED")){
			return true;
		}
		else if (mEvent.getMessage().contains(messageString)){
			return true;
		}
		return false;
	}
	
	private void sendCreateResponseUpdates(UserCreateObjectEvent uEvent){
		Iterator<CfAction> actionsToCheck = createWaitingToModifyActions.iterator();
		while (actionsToCheck.hasNext()){
			CfAction actionToCheck = actionsToCheck.next();
			if (eventIsActionResponse(uEvent, actionToCheck)){
				//send the modify request that came with the original create
				String typeToCheck = actionToCheck.getCfObjects().get(0).getPropertyValue(MetaforaStrings.OBJECT_TYPE_STRING);
				if (MetaforaStrings.OBJECT_TYPE_QUESTION_STRING.equalsIgnoreCase(typeToCheck)){
					actionsToCheck.remove();
					sendUpdateBoxRequest(uEvent, actionToCheck);
				}
				else if (MetaforaStrings.OBJECT_TYPE_IMAGE_STRING.equalsIgnoreCase(typeToCheck)){
					actionsToCheck.remove();
					sendUpdateBoxRequest(uEvent, actionToCheck);
				}
				else if (MetaforaStrings.OBJECT_TYPE_MICROWORLD_ISSUE_STRING.equalsIgnoreCase(typeToCheck)){
					actionsToCheck.remove();
					sendUpdateMicroworldIssueObjectRequest(uEvent, actionToCheck);
				}
				else if (MetaforaStrings.OBJECT_TYPE_MY_MICROWORLD_STRING.equalsIgnoreCase(typeToCheck)){
					actionsToCheck.remove();
					sendUpdateMyMicroworldObjectRequest(uEvent, actionToCheck);
				}
			}    
		}
	}

	private void sendUpdateBoxRequest(UserCreateObjectEvent uEvent, CfAction actionToCheck) {
		actionToCheck.getCfActionType().setType(MetaforaStrings.ACTION_TYPE_UPDATE_ELEMENT_STRING);
		String boxId = uEvent.getEueObjectList().get(1).getID().getIdAsString();
		actionToCheck.getCfObjects().get(0).setId(boxId);
		sendAction(actionToCheck);
	}
	
	private void sendUpdateMicroworldIssueObjectRequest(UserCreateObjectEvent uEvent, CfAction actionToCheck){
		//TODO make this check the element strings rather than assume positioning
//		for (EUEObject element : uEvent.getEueObjectList()){
//			String type = element.getDataType();
//			if (LASADVocabulary.ACTION_PROP_VALUE_REFERENCE_OBJECT.equalsIgnoreCase(type)){
//				element.getID().getIdAsString();
//			}
//			String ObjectElementId =  uEvent.getEueObjectList().get(0).getID().getIdAsString();
//		}
		actionToCheck.getCfActionType().setType(MetaforaStrings.ACTION_TYPE_UPDATE_ELEMENT_STRING);
		String boxElementId =  uEvent.getEueObjectList().get(0).getID().getIdAsString();
		actionToCheck.getCfObjects().get(0).setId(boxElementId);
		String imageElementId =  uEvent.getEueObjectList().get(3).getID().getIdAsString();
		actionToCheck.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING).setId(imageElementId);
		String textElementId =  uEvent.getEueObjectList().get(2).getID().getIdAsString();
		actionToCheck.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).setId(textElementId);
		String refUrlElementId =  uEvent.getEueObjectList().get(4).getID().getIdAsString();
		actionToCheck.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).setId(refUrlElementId);
		sendAction(actionToCheck);
		
	}
	
	private void sendUpdateMyMicroworldObjectRequest(UserCreateObjectEvent uEvent, CfAction actionToCheck){
		//TODO make this check the element strings rather than assume positioning
//		for (EUEObject element : uEvent.getEueObjectList()){
//			String type = element.getDataType();
//			if (LASADVocabulary.ACTION_PROP_VALUE_REFERENCE_OBJECT.equalsIgnoreCase(type)){
//				element.getID().getIdAsString();
//			}
//			String ObjectElementId =  uEvent.getEueObjectList().get(0).getID().getIdAsString();
//		}
		actionToCheck.getCfActionType().setType(MetaforaStrings.ACTION_TYPE_UPDATE_ELEMENT_STRING);
		String boxElementId =  uEvent.getEueObjectList().get(0).getID().getIdAsString();
		actionToCheck.getCfObjects().get(0).setId(boxElementId);
		
		String modelViewId =  uEvent.getEueObjectList().get(1).getID().getIdAsString();
		actionToCheck.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_MODEL_VIEW_URL).setId(modelViewId);
		
		String ruleViewId =  uEvent.getEueObjectList().get(2).getID().getIdAsString();
		actionToCheck.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_RULE_VIEW_URL).setId(ruleViewId);
		
		//don't set explain box
		
		String textElementId =  uEvent.getEueObjectList().get(4).getID().getIdAsString();
		actionToCheck.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).setId(textElementId);
		
		String refUrlElementId =  uEvent.getEueObjectList().get(5).getID().getIdAsString();
		actionToCheck.getCfObjects().get(0).getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).setId(refUrlElementId);
		
		sendAction(actionToCheck);
		
	}

	private boolean eventIsActionResponse(UserCreateObjectEvent createEvent, CfAction actionToCheck) {
		String createdType = createEvent.getEueObjectList().get(0).getType();
		String typeToCheck = actionToCheck.getCfObjects().get(0).getPropertyValue(MetaforaStrings.OBJECT_TYPE_STRING);
		String createdMapId = createEvent.getSessionID().getIdAsString();
		String mapIdToCheck = actionToCheck.getCfObjects().get(0).getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING);
		
		typeToCheck = getTypeMappedFromMetafora(typeToCheck);
		if ((createdType.equalsIgnoreCase(typeToCheck)) && createdMapId.equalsIgnoreCase(mapIdToCheck)){
			return true;
		}
		return false;
	}
	
	private String getTypeMappedFromMetafora(String cfName){
		if (cfName.equalsIgnoreCase(MetaforaStrings.OBJECT_TYPE_MICROWORLD_ISSUE_STRING)){
			return "Microworld Issue";
		}
		return cfName;
	}

	@Override
	public void onActionSpecEvent(ActionSpecEvent actionSpecEvent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onAnalysisResultEvent(AnalysisResultEvent analysisResultEvent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processUserFeedbackRequestEvent(
			UserFeedbackRequestEvent feedbackRequestEvent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processEUEEvent(EUESessionEvent eueEvent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processActionSpecEvent(ActionSpecEvent actionSpecEvent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processAnalysisResultEvent(
			AnalysisResultEvent analysisResultEvent) {
		// TODO Auto-generated method stub
		
	}
	
	private void expresserFixes(CfAction action){
		//fix for expresser sending different view url tags... 
		if (action.getCfActionType().getType().equals(MetaforaStrings.ACTION_TYPE_CREATE_ELEMENT_STRING)){
			CfObject object = action.getCfObjects().get(0);
			if (object.getPropertyValue("ELEMENT_TYPE").equals(MetaforaStrings.OBJECT_TYPE_MICROWORLD_ISSUE_STRING)){
				CfProperty viewUrlProp = object.removeProperty("RULE_VIEW_URL");
				if (viewUrlProp != null){
					object.addProperty(new CfProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING, viewUrlProp.getValue()));
				}
			}
			
		}
	}

}
