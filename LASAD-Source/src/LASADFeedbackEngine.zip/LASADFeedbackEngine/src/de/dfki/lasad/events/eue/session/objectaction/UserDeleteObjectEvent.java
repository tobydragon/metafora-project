package de.dfki.lasad.events.eue.session.objectaction;

import java.util.List;

import de.dfki.lasad.events.eue.session.EUEEventID;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.objects.EUEObject;

public class UserDeleteObjectEvent extends UserObjectActionEvent {

	public UserDeleteObjectEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID,
			List<EUEObject> eueObject) {
		super(sessionID, srcCompId, eueEventID, userID, eueObject);
	}

	public UserDeleteObjectEvent(SessionID sessionID,
			EUEEventID eueEventId, String srcComponentId) {
		super(sessionID, srcComponentId, eueEventId);
	}
	
	public UserDeleteObjectEvent cloneWithoutObjects() {
		UserDeleteObjectEvent clone = new UserDeleteObjectEvent(getSessionID(),
				getEueEventID(), getSourceComponentID());
		clone.setUserID(getUserID());
		return clone;
	}

}
