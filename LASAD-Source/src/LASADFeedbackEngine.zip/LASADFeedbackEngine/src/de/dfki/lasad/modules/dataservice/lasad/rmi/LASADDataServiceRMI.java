package de.dfki.lasad.modules.dataservice.lasad.rmi;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.Parameter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.PluggableComponentDescription;
import de.dfki.lasad.core.action.ActionType;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.core.dataservice.AbstractDataService;
import de.dfki.lasad.core.worldmodel.IModelController;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.admin.EUESessionListEvent;
import de.dfki.lasad.events.eue.session.AgentJoinSessionAnnounceEvent;
import de.dfki.lasad.events.eue.session.AgentJoinSessionConfirmEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.ontology.EUEOntology;
import de.dfki.lasad.modules.dataservice.lasad.ActionPackageFactory;
import de.dfki.lasad.modules.dataservice.lasad.ActionPackageListener;
import de.dfki.lasad.modules.dataservice.lasad.ActionPackageListener.Direction;
import de.dfki.lasad.modules.dataservice.lasad.AnalysisAndFeedbackTypeAdapter;
import de.dfki.lasad.modules.dataservice.lasad.translators.EventTranslatorAF2LASAD;
import de.dfki.lasad.modules.dataservice.lasad.translators.EventTranslatorLASAD2AF;
import de.dfki.lasad.modules.dataservice.lasad.translators.LASADVocabulary;
import de.dfki.lasad.modules.dataservice.lasad.translators.MapDetails;
import de.dfki.lasad.modules.dataservice.lasad.xml.ActionPackageXmlConverter;

public class LASADDataServiceRMI extends AbstractDataService {


	private static Log logger = LogFactory.getLog(LASADDataServiceRMI.class);

	protected ActionPackageFactory actionPackageFactory;

	private EventTranslatorLASAD2AF eventTranslatorLASAD2AF;
	private EventTranslatorAF2LASAD eventTranslatorAF2LASAD;
	private RemoteActionSenderRMI remoteActionSender;
	private RemoteActionListenerRMI actionListenerServer;

	// for testing purposes only (accessible via test subclass)
	protected List<ActionPackageListener> incomingActionPackListeners = new Vector<ActionPackageListener>();
	protected List<ActionPackageListener> outgoingActionPackListeners = new Vector<ActionPackageListener>();

	// needed to delete feedback menu items again when shutting down the service
	protected Map<String, Set<String>> session2FeedbackMenuItemIDs = new HashMap<String, Set<String>>();
	
	private Vector<Object> initObjList = new Vector<Object>();
	private Object initObjMutex = new Object();
	private String newMapId = null;

	@Override
	public void configure(PluggableComponentDescription description) {
		super.configure(description);

		LASADDataServiceRMIConfiguration configuration = (LASADDataServiceRMIConfiguration) description
				.getConfiguration();
		
		actionPackageFactory = new ActionPackageFactory(configuration.getClientName(), configuration
				.getUsername(), configuration.getPassword(), LASADVocabulary.ACTION_METHOD_RMI);
		eventTranslatorLASAD2AF = new EventTranslatorLASAD2AF();
		eventTranslatorAF2LASAD = new EventTranslatorAF2LASAD(
				actionPackageFactory);
		
		remoteActionSender = new RemoteActionSenderRMI();
		remoteActionSender.register(this);
		remoteActionSender.setConfiguration(configuration);
	}

	@Override
	public void prepareService() {
		/*
		 * To handle the incoming packages 
		 * our client needs to register twice:
		 * 1. once via an Action as before
		 * 2. the other one on the server registry to start listening
		 */
		remoteActionSender.init();
		prepareAndStartListeningServer();
		registerAtRemoteServer();
		
		updateApplicableServicesAndWorldModel();

		MyShutdownHook shutdownHook = new MyShutdownHook();
		Runtime.getRuntime().addShutdownHook(shutdownHook);

	}

	@Override
	public void startService() {
		LASADDataServiceRMIConfiguration configuration = (LASADDataServiceRMIConfiguration) description
				.getConfiguration();
		if (configuration.doJoinAllPossibleMapsOnStartup()) {
			enablePossibleServicesForEachSession();
		} else {
			enablePossibleServicesForConfiguredSessions();
		}
		setupAutoHeartBeatIfConfigured();
	}

	public void setActionListeningService(RemoteActionListenerRMI actionListenerServer) {
		this.actionListenerServer = actionListenerServer;
	}

	private void prepareAndStartListeningServer() {
		if (actionListenerServer == null) {
			actionListenerServer = new RemoteActionListenerRMI();
		}
		actionListenerServer.register(this);
		LASADDataServiceRMIConfiguration configuration = (LASADDataServiceRMIConfiguration) description
				.getConfiguration();
		//actionListenerServer.setConfiguration(configuration);
		if (configuration.doDeploy()) {
			actionListenerServer.registerAtServerRegistry(configuration.getServerIP(), configuration.getServerRegistryPort(), 
					configuration.getClientRegistryPort(), configuration.getUsername());
		}
	}

	/**
	 * Registering at remote service (i.e., establishing a connection) without
	 * joining a specific session.
	 */
	private void registerAtRemoteServer() {
		ActionPackage loginRequest = actionPackageFactory.createLoginMessage();
		sendActionPackage(loginRequest);
	}
	
	

	/**
	 * Retrieves sessions and corresponding {@link EUEOntology}s from the remote
	 * service, determine which analysis / feedback services can be applied to
	 * which session (according to the {@link EUEOntology}s), and registering
	 * all {@link SessionID}-{@link EUEOntology} mappings in the
	 * {@link IModelController}.
	 */
	private void updateApplicableServicesAndWorldModel() {
		clearServiceLists();
		
		EUESessionListEvent sessionListEvent = getMapInfosFromRemoteServer();
		registerApplicableServicesAndWorldModel(sessionListEvent);
	}
	
	private void registerApplicableServicesAndWorldModel(EUESessionListEvent sessionListEvent){
		Map<SessionID, EUEOntology> sessions2ontologies = sessionListEvent
		.getSessionIDs2Ontology();
		for (SessionID sessionID : sessions2ontologies.keySet()) {
			EUEOntology ontology = sessions2ontologies.get(sessionID);
			ServiceRegistry.registerOntology(sessionID, ontology);
			addServicesForSession(sessionID, ontology);

		}
		/**
		 * Forwarding information to {@link IModelController} if available.
		 */
		if (ServiceRegistry.getModelController() != null) {
			ServiceRegistry.getModelController().executeSessionListEvent(
					sessionListEvent);
		}
	}

	/**
	 * Join all sessions at the remote service where analysis and feedback
	 * services are available and announce corresponding analysis and feedback
	 * services to the remote service.
	 */
	private void enablePossibleServicesForEachSession() {
		joinAllMapsWhereServicesAreAvailable();
	}

	/**
	 * Join only explicitly configured sessions at the remote service and
	 * announce corresponding analysis and feedback services to the remote
	 * service.
	 */
	private void enablePossibleServicesForConfiguredSessions() {
		LASADDataServiceRMIConfiguration configuration = (LASADDataServiceRMIConfiguration) description
				.getConfiguration();
		for (String mapID : configuration.getMapsToJoinOnStartup()) {
			if (sessionsThatCanBeSupportedWithServices.contains(new SessionID(
					mapID))) {
				requestJoinSession(new SessionID(mapID));
				joinMapAtRemoteServer(mapID);
				announceServicesToRemoteRMIServer(mapID);
			}
		}
	}
	
	/**
	 * Issues several requests to the remote service to collect information
	 * about the available sessions, in particular their {@link EUEOntology}s.
	 * 
	 * @return
	 */
	public EUESessionListEvent getMapInfosFromRemoteServer() {
		ActionPackage listMapIDsRequest = actionPackageFactory.createListMapsMessage();
		
		sendActionPackage(listMapIDsRequest);
		
		ActionPackage lasadResponseListMaps = null;
		synchronized(initObjMutex) {
			while(initObjList.size() == 0){
				try {
					initObjMutex.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			lasadResponseListMaps = (ActionPackage) initObjList.remove(0);
		}
		
		EUESessionListEvent sessionListEvent = eventTranslatorLASAD2AF.translateSessionListEvent(lasadResponseListMaps);
		Map<SessionID, EUEOntology> sessionID2ontology = sessionListEvent
				.getSessionIDs2Ontology();
		
		for (SessionID sessionID : sessionID2ontology.keySet()) {
			
			EUEOntology fullOntology = getMapInfoFromRemoteServer(sessionID);
			// replace minimal ontology with full ontology
			sessionID2ontology.put(sessionID, fullOntology);
			
		}
		return sessionListEvent;
	}
	
	private EUEOntology getMapInfoFromRemoteServer(SessionID sessionID){
		ActionPackage getOntologyInfosRequest = actionPackageFactory.createGetOntologyMessage(sessionID.getIdAsString());
		logger.debug("requesting Ontology");
		sendActionPackage(getOntologyInfosRequest);
		
		ActionPackage lasadResponseGetOntology = null;
		synchronized(initObjMutex) {
			while(initObjList.size() == 0){
				try {
					logger.debug("waiting for Ontology");
					initObjMutex.wait();
					logger.debug("awake Ontology received");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			logger.debug("about to get fullOntology from initObjList");
			lasadResponseGetOntology = (ActionPackage) initObjList.remove(0);
		}
		logger.debug("About to call translateOntologyInfoEvent()");
		EUEOntology fullOntology = eventTranslatorLASAD2AF.translateOntologyInfoEvent(sessionID.getIdAsString(),
						lasadResponseGetOntology);

		logger.debug("About to call createGetMapDetailsMessage()");
		ActionPackage getMapDetailsRequest = actionPackageFactory.createGetMapDetailsMessage(sessionID.getIdAsString());
		logger.debug("requesting MapDetails");
		sendActionPackage(getMapDetailsRequest);
		
		ActionPackage lasadResponseGetMapDetails = null;
		synchronized(initObjMutex) {
			while(initObjList.size() == 0){
				try {
					logger.debug("waiting for Map details");
					initObjMutex.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			logger.debug("getting lasadResponseGetMapDetails from initObjList");
			lasadResponseGetMapDetails = (ActionPackage) initObjList.remove(0);
		}
		
		logger.debug("About to call extractResourceIDsAndMapInfo()");
		MapDetails mapDetails = eventTranslatorLASAD2AF.extractResourceIDsAndMapInfo(sessionID.getIdAsString(),
				lasadResponseGetMapDetails);
		logger.debug("About to setExternalResourceIDs()");
		fullOntology.setExternalResourceIDs(mapDetails.getTranscriptIDs());
		//TODO get map information to create file
		
		logger.debug("Associating SessionID '" + sessionID.getIdAsString()
				+ "' with Ontology '" + fullOntology + "'");
		return fullOntology;
	}

	private void joinAllMapsWhereServicesAreAvailable() {
		// join all maps and issue internal JoinSession request
		for (SessionID sessionID : sessionsThatCanBeSupportedWithServices) {
			requestJoinSession(sessionID);
			joinMapAtRemoteServer(sessionID.getIdAsString());
		}

		// announce services to remote service
		for (SessionID sessionID : session2analysisServices.keySet()) {
			announceServicesToRemoteRMIServer(sessionID.getIdAsString());
		}
		for (SessionID sessionID : session2actionServices.keySet()) {
			announceServicesToRemoteRMIServer(sessionID.getIdAsString());
		}

	}

	private void requestJoinSession(SessionID sessionID) {
		AgentJoinSessionAnnounceEvent joinSessionAnnounceEvent = new AgentJoinSessionAnnounceEvent(
				sessionID, getComponentDescription().getComponentID());
		ServiceRegistry.getModelController()
				.executeAgentJoinSessionAnnounceEvent(joinSessionAnnounceEvent);
	}

	private void announceServicesToRemoteRMIServer(String sessionID) {
		Set<AnalysisType> analysisTypes = session2analysisServices
				.get(new SessionID(sessionID));
		Set<ActionType> actionTypes = session2actionServices.get(new SessionID(
				sessionID));

		if (analysisTypes != null) {
			for (AnalysisType analysisType : analysisTypes) {
				String agentID = analysisType.getAgentID();
				String typeID = analysisType.getTypeID();
				String displayType = analysisType.getDisplayName();

				AnalysisAndFeedbackTypeAdapter.addAnalysisMapping(agentID,
						typeID, displayType);
				announceServiceToRemoteServer(sessionID, agentID, displayType, true);
			}
		}
		if (actionTypes != null) {
			for (ActionType actionType : actionTypes) {

				String agentID = actionType.getAgentID();
				String typeID = actionType.getTypeID();
				String displayType = actionType.getDisplayName();

				AnalysisAndFeedbackTypeAdapter.addActionMapping(agentID,
						typeID, displayType);
				announceServiceToRemoteServer(sessionID, agentID, displayType,
						false);
			}
		}

		if (analysisTypes == null && actionTypes == null) {
			logger
					.warn("Neither analysis services nor action services available for session '"
							+ sessionID + "'.");
		}
	}

	public void announceServiceToRemoteServer(String mapID, String agentID,
			String typeID, boolean isAnalysisType) {
		ActionPackage announceServiceRequest = actionPackageFactory
				.createPublishServiceMessage(mapID, agentID, typeID,
						isAnalysisType);
		sendActionPackage(announceServiceRequest);
		
		ActionPackage lasadResponse = null;
		synchronized(initObjMutex) {
			while(initObjList.size() == 0){
				try {
					initObjMutex.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			lasadResponse = (ActionPackage) initObjList.remove(0);
		}

		//TODO check if we have to validate the null in case this is not the expected ActionPackage
		String feedbackMenuItemID = getFeedbackMenuItemID(mapID, lasadResponse);
		

		Set<String> feedbackMenuItemIDs = session2FeedbackMenuItemIDs
				.get(mapID);
		if (feedbackMenuItemIDs == null) {
			feedbackMenuItemIDs = new HashSet<String>();
			session2FeedbackMenuItemIDs.put(mapID, feedbackMenuItemIDs);
		}
		feedbackMenuItemIDs.add(feedbackMenuItemID);
	}

	public void joinMapAtRemoteServer(String mapID) {
		ActionPackage joinRequest = actionPackageFactory
				.createJoinMapMessage(mapID);
		sendActionPackage(joinRequest);
	}

	/*
	 * In this function we receive messages from the server.
	 */
	public void processActionPackage(ActionPackage actionPackage) {
//		logger.debug("processActionPackage: " + actionPackage2String(actionPackage));
		logger.info("processActionPackage: xml - \n" + ActionPackageXmlConverter.toXml(actionPackage));
				
		if (eventTranslatorLASAD2AF.isCreateMapAP(actionPackage)){
			logger.debug("CreateMap received");
			handleMapCreation(actionPackage);
			return;
		}
		
		if(handleRequestedInfo(actionPackage)){
			return;
		}
		
		notifyAboutIncomingActionPackage(actionPackage);
		sendHeartbeatIfRequested(actionPackage);

		List<EUESessionEvent> eueEventList = eventTranslatorLASAD2AF
				.translate(actionPackage);
		for (EUEEvent eueEvent : eueEventList) {
			processEUEEvent(eueEvent);
		}
	}
	
	private boolean isSessionSupportedAndConfigured(String mapId){
		boolean returnVal = false;
		LASADDataServiceRMIConfiguration configuration = (LASADDataServiceRMIConfiguration) description
		.getConfiguration();
		if (configuration.doJoinAllPossibleMapsOnStartup()){
			logger.debug("configuration.doJoinAllPossibleMapsOnStartup() == true");
//			if (sessionsThatCanBeSupportedWithServices.contains(new SessionID(mapId))){
				logger.debug("sessionsThatCanBeSupportedWithServices.contains(new SessionID(mapId)) == true");
//				returnVal = true;
//			}
			returnVal = true;
		} else {
			if (configuration.getMapsToJoinOnStartup().contains(mapId) &&
					(sessionsThatCanBeSupportedWithServices.contains(new SessionID(mapId)))){
				returnVal = true;
			}
		}
		
		return returnVal;
	}
	
	private void handleMapCreation(final ActionPackage actionPackage){
		
		new Thread() {
			@Override
			public void run() {
				String mapId =  eventTranslatorLASAD2AF.getMapIdFromAP(actionPackage);
				this.setName("Map" + mapId);
				newMapId = new String(mapId);
				
				if(isSessionSupportedAndConfigured(mapId)){
					//we assume that the MAP-ID is always provided, thus
					SessionID sessionId = new SessionID(mapId);
					EUEOntology ontology = getMapInfoFromRemoteServer(sessionId);
					EUESessionListEvent event = eventTranslatorLASAD2AF.createSessionListEvent(sessionId, ontology);
					registerApplicableServicesAndWorldModel(event);
					requestJoinSession(sessionId);
					joinMapAtRemoteServer(sessionId.getIdAsString());
					announceServicesToRemoteRMIServer(sessionId.getIdAsString());
					newMapId = null;
				}
			}
		}.start();
		return;
	}
	
	private boolean handleRequestedInfo(ActionPackage actionPackage){
		logger.debug("handleRequestedInfo");
		boolean retVal = false;
		List<Action> actions = actionPackage.getActions();
		Action action = actions.get(0);
		String actionCommand = action.getCmd();
		String actionCategory = action.getCategory();
		if (LASADVocabulary.ACTION_CMD_LISTMAP.equalsIgnoreCase(actionCommand)){
			logger.debug("ACTION_CMD_LISTMAP");
			synchronized(initObjMutex) {
				initObjList.add(actionPackage);
				logger.debug("ACTION_CMD_LISTMAP notifying");
				initObjMutex.notifyAll();
			}
			retVal = true;
		}else if (LASADVocabulary.ACTION_CMD_ONTOLOGY.equalsIgnoreCase(actionCommand)) {
			logger.debug("ACTION_CMD_ONTOLOGY");
			synchronized(initObjMutex) {
				initObjList.add(actionPackage);
				logger.debug("ACTION_CMD_ONTOLOGY notifying");
				initObjMutex.notifyAll();
			}
			retVal = true;
		}else if (LASADVocabulary.ACTION_CAT_MAP.equalsIgnoreCase(actionCategory)
				&& LASADVocabulary.ACTION_CMD_MAPDETAILS.equalsIgnoreCase(actionCommand)){
			logger.debug("ACTION_CMD_MAPDETAILS");
			synchronized(initObjMutex) {
				initObjList.add(actionPackage);
				logger.debug("ACTION_CMD_MAPDETAILS notifying");
				initObjMutex.notifyAll();
			}
			retVal = true;
		}else if (LASADVocabulary.ACTION_CMD_CREATE_ELEMENT
				.equalsIgnoreCase(actionCommand)) {

			String mapID = null;
			String objectType = null;
			String feedbackMenuItemID = null;
			// ID-> 7, TYPE-> FEEDBACK-AGENT
			for (Parameter actionParam : action.getParameters()) {
				if (LASADVocabulary.ACTION_PROP_MAPID
						.equalsIgnoreCase(actionParam.getName())) {
					mapID = actionParam.getValue();
				} else if (LASADVocabulary.ACTION_PROP_TYPE
						.equalsIgnoreCase(actionParam.getName())) {
					objectType = actionParam.getValue();
				} else if (LASADVocabulary.ACTION_PROP_ID
						.equalsIgnoreCase(actionParam.getName())) {
					feedbackMenuItemID = actionParam.getValue();
				}
			}
//			if (targetMapID.equals(mapID)
//					&& LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK_AGENT
//							.equals(objectType)
			if (newMapId != null && mapID.equals(newMapId) && 
					LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK_AGENT.equals(objectType) && 
					feedbackMenuItemID != null) {
				logger.debug("ACTION_CMD_CREATE_ELEMENT & ACTION_PROP_VALUE_FEEDBACK_AGENT");
				synchronized(initObjMutex) {
					initObjList.add(actionPackage);
					logger.debug("ACTION_CMD_CREATE_ELEMENT & ACTION_PROP_VALUE_FEEDBACK_AGENT notyfying");
					initObjMutex.notify();
				}
				retVal = true;
			}
		}
		logger.debug("Returning:" + retVal);
		return retVal;
	}

	protected void sendActionPackage(final ActionPackage outPackage) {
		logger.debug("Send out ActionPackage: "
				+ actionPackage2String(outPackage) + "...");
		notifyAboutOutgoingActionPackage(outPackage);
		
		try {
			remoteActionSender.doActionOnServer(outPackage);
		} catch (RemoteException e) {
			System.out.println("Error sendActionPackage: " + e.getClass()
					+ ": " + e.getMessage());
					e.printStackTrace();
		}
		
	}

	@Override
	protected void processActionSpecEvent(ActionSpecEvent actionSpecEvent) {
		List<ActionPackage> actionPackages = eventTranslatorAF2LASAD
				.translate(actionSpecEvent);
		for (ActionPackage aPackage : actionPackages) {
			sendActionPackage(aPackage);
		}
	}

	@Override
	public void processAgentJoinSessionConfirmEvent(
			AgentJoinSessionConfirmEvent confirmEvent) {
		SessionID sessionID = confirmEvent.getSessionID();
		joinMapAtRemoteServer(sessionID.getIdAsString());
		announceServicesToRemoteRMIServer(sessionID.getIdAsString());
	}

	private void notifyAboutIncomingActionPackage(ActionPackage actionPackage) {
		for (ActionPackageListener listener : incomingActionPackListeners) {
			listener.onActionPackage(actionPackage, Direction.IN);
		}
	}

	private void notifyAboutOutgoingActionPackage(ActionPackage actionPackage) {
		for (ActionPackageListener listener : outgoingActionPackListeners) {
			listener.onActionPackage(actionPackage, Direction.OUT);
		}
	}

	private void sendHeartbeatIfRequested(ActionPackage actionPackage) {
		if (actionPackage == null) {
			logger.info("ActionPackage is null!");
		}
		if (eventTranslatorLASAD2AF.containsHeartbeatRequest(actionPackage)) {
			sendActionPackage(actionPackageFactory.createHeartbeatMessage());
		}
	}

	private void setupAutoHeartBeatIfConfigured() {
		LASADDataServiceRMIConfiguration configuration = (LASADDataServiceRMIConfiguration) description
				.getConfiguration();
		if (configuration.autoHeartBeat()) {
			int heartBeatRate = configuration.getHeartBeatRate();

			Timer timerThread = new Timer(true);
			TimerTask heartBeatTask = new TimerTask() {
				@Override
				public void run() {
					try {
						sendActionPackage(actionPackageFactory
								.createHeartbeatMessage());
					} catch (Exception e) {
						logger.error("Error occurred.", e);
					}
				}
			};
			timerThread.schedule(heartBeatTask, 0, heartBeatRate * 1000);

		}
	}

	public static String actionPackage2String(ActionPackage actionPackage) {
		if (actionPackage == null) {
			logger.info("ActionPackage is null!");
			return null;
		}
		StringBuffer buffer = new StringBuffer();
		buffer.append("ActionPackage (");
		Iterator<Parameter> paramIter = actionPackage.getParameters()
				.iterator();
		while (paramIter.hasNext()) {
			Parameter param = paramIter.next();
			buffer.append(param.getName() + "-> " + param.getValue());
			if (paramIter.hasNext()) {
				buffer.append(", ");
			}
		}
		buffer.append(") ");
		List<Action> receivedActions = actionPackage.getActions();
		Iterator<Action> actionIter = receivedActions.iterator();
		buffer.append("{");
		while (actionIter.hasNext()) {
			Action act = actionIter.next();
			buffer.append("[");
			buffer.append("ACTION: ");
			buffer.append("CATEGORY: " + act.getCategory());
			buffer.append(", COMMAND: " + act.getCmd());
			buffer.append(", PARAMETERS: ");
			paramIter = act.getParameters().iterator();
			while (paramIter.hasNext()) {
				Parameter param = paramIter.next();
				buffer.append(param.getName() + "-> " + param.getValue());
				if (paramIter.hasNext()) {
					buffer.append(", ");
				}
			}
			buffer.append("]");
			if (actionIter.hasNext()) {
				buffer.append(", ");
			}
		}
		buffer.append("}");
		return buffer.toString().replace("\\s", " ");
	}

	public static String actionPackage2StringForTesting(
			ActionPackage actionPackage) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("{" + "\n");
		Iterator<Parameter> paramIter = actionPackage.getParameters()
				.iterator();
		List<Action> receivedActions = actionPackage.getActions();
		Iterator<Action> actionIter = receivedActions.iterator();
		while (actionIter.hasNext()) {
			Action act = actionIter.next();
			buffer.append("[" + "\n");
			buffer.append("ACTION: " + "\n");
			buffer.append("CATEGORY: " + act.getCategory() + "\n");
			buffer.append("COMMAND: " + act.getCmd() + "\n");
			buffer.append("PARAMETERS: " + "\n");
			paramIter = act.getParameters().iterator();
			while (paramIter.hasNext()) {
				Parameter param = paramIter.next();
				buffer.append(param.getName() + ":" + param.getValue() + "\n");
				if (paramIter.hasNext()) {
				}
			}
			buffer.append("]" + "\n");
			if (actionIter.hasNext()) {
			}
		}
		buffer.append("}" + "\n");
		return buffer.toString();
	}

	private class MyShutdownHook extends Thread {
		public void run() {
			shutdown();
		}
	}

	// unregister all feedback menu entries
	private void shutdown() {
		logger
				.info("Shutting down service. Unregister feedback menu entries ...");
		for (String mapID : session2FeedbackMenuItemIDs.keySet()) {
			Set<String> feedbackMenuItemIDs = session2FeedbackMenuItemIDs
					.get(mapID);
			for (String feedbackMenuItemID : feedbackMenuItemIDs) {
				ActionPackage deleteFeedbackMenuItemMessage = actionPackageFactory
						.createDeleteElementMessage(mapID, feedbackMenuItemID);
				logger.info("Sending out message for session " + mapID
						+ ", feedback menu item ID = " + feedbackMenuItemID);
				sendActionPackage(deleteFeedbackMenuItemMessage);
			}

			ActionPackage leaveMapMessage = actionPackageFactory
					.createLeaveMapMessage(mapID);
			logger.info("Sending out message for leaving session " + mapID
					+ ": " + leaveMapMessage);
			sendActionPackage(leaveMapMessage);
		}
		ActionPackage logoutMessage = actionPackageFactory
				.createLogoutMessage();
		logger.info("Sending out message logout message: " + logoutMessage);
		sendActionPackage(logoutMessage);
		logger.info("... shutting down DONE.");
	}

	// method should be moved to {@link EventTranslatorLASAD2AF}
	public String getFeedbackMenuItemID(String targetMapID,
			ActionPackage actionPackage) {
		List<Action> actions = actionPackage.getActions();
		for (Iterator<Action> iter = actions.iterator(); iter.hasNext();) {

			Action action = iter.next();
			String actionCommand = action.getCmd();

			if (LASADVocabulary.ACTION_CMD_CREATE_ELEMENT
					.equalsIgnoreCase(actionCommand)) {

				String mapID = null;
				String objectType = null;
				String feedbackMenuItemID = null;
				// ID-> 7, TYPE-> FEEDBACK-AGENT
				for (Parameter actionParam : action.getParameters()) {
					if (LASADVocabulary.ACTION_PROP_MAPID
							.equalsIgnoreCase(actionParam.getName())) {
						mapID = actionParam.getValue();
					} else if (LASADVocabulary.ACTION_PROP_TYPE
							.equalsIgnoreCase(actionParam.getName())) {
						objectType = actionParam.getValue();
					} else if (LASADVocabulary.ACTION_PROP_ID
							.equalsIgnoreCase(actionParam.getName())) {
						feedbackMenuItemID = actionParam.getValue();
					}
				}
				if (targetMapID.equals(mapID)
						&& LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK_AGENT
								.equals(objectType)
						&& feedbackMenuItemID != null) {
					return feedbackMenuItemID;
				} else {
					logger
							.error("Could not feedbackMenuItemID from extract ActionPackage: "
									+ actionPackage2String(actionPackage));
				}
			}
		}
		return null;
	}
}
