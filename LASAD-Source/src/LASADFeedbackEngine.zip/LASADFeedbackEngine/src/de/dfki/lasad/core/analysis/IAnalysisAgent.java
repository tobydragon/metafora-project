package de.dfki.lasad.core.analysis;

import de.dfki.lasad.core.PluggableComponent;
import de.dfki.lasad.core.worldmodel.IModelController;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * Abstraction of an Analysis module. Implementations might run locally or might
 * be local proxies that communicate with remote analysis services.
 * 
 * @author Oliver Scheuer
 * 
 */
public interface IAnalysisAgent extends PluggableComponent {

	/**
	 * Establish runtime dependencies at system initialization time.
	 */
	public void doWire(IAnalysisController analysisController,
			IModelController worldModel);

	/**
	 * Notification message about a new {@link EUESessionEvent} to process. The
	 * concrete processing depends on the specific implementation. State-based
	 * {@link IAnalysisAgent}s might update an internal model of the current
	 * state of the EUE (e.g., a graph representing the current state of an
	 * argument diagram constructed in the EUEs), process-based
	 * {@link IAnalysisAgent}s might keep a "sliding window" for the most recent
	 * x events, other {@link IAnalysisAgent}s again might operate on single
	 * events and thus don't need to keep an internal model. If an internal
	 * model is used the processing always involves an update of the internal
	 * model. The actual analysis can be done immediately or might be deferred
	 * until {@link AnalysisResult}s have been requested (i.e., until
	 * {@link #onAnalysisRequestEvent(AnalysisRequestEvent)} is invoked).
	 */
	public void onEUEEvent(EUESessionEvent eueEvent);

	/**
	 * Request for {@link AnalysisResult}s. Depending on the implementation
	 * {@link AnalysisResult}s might be computed when this method is invoked or
	 * have been computed already in advance.
	 */
	public void onAnalysisRequestEvent(AnalysisRequestEvent request);

	@Override
	public AnalysisAgentDescription getComponentDescription();

	/**
	 * The {@link IAnalysisAgent} decides whether to support the provided
	 * {@link SessionID} based on the provided {@link EUEOntology}.
	 * 
	 * @param sessionID
	 * @param ontology
	 */
	public void requestSupportSession(SessionID sessionID, EUEOntology ontology);
}
