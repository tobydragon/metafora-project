package de.dfki.lasad.modules.dataservice.lasad.rmi;


import java.io.File;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.filter.ElementFilter;
import org.jdom.input.SAXBuilder;

/**
 * 
 * @author Anahuac Valero
 * 
 */
public class LASADDataServiceRMIConfigParser {

	private static Log logger = LogFactory.getLog(LASADDataServiceRMIConfigParser.class);

	public static LASADDataServiceRMIConfiguration loadConfig(File confFile) {
		LASADDataServiceRMIConfiguration conf = new LASADDataServiceRMIConfiguration();
		try {
			// Namespace classifierNs = Namespace
			// .getNamespace(classifierDescriptionNS);
			SAXBuilder builder = new SAXBuilder();
			Document doc = builder.build(confFile);

			Element usernameElem = doc.getRootElement().getChild("username");
			String username = usernameElem.getText();
			conf.setUsername(username);

			Element pwElem = doc.getRootElement().getChild("password");
			String pw = pwElem.getText();
			conf.setPassword(pw);

			Element serverIPElem = doc.getRootElement().getChild(
					"serverip");
			String serverIP = serverIPElem.getText();
			conf.setServerIP(serverIP);
			
			Element serverPortElem = doc.getRootElement().getChild(
			"serverport");
			int serverPort = Integer.parseInt(serverPortElem.getText());
			conf.setServerPort(serverPort);

			Element serverNameElem = doc.getRootElement().getChild(
			"servername");
			String serverName = serverNameElem.getText();
			conf.setServerName(serverName);
			
			Element serverRegistryPortElem = doc.getRootElement().getChild(
			"serverregistryport");
			int serverRegistryPort = Integer.parseInt(serverRegistryPortElem.getText());
			conf.setServerRegistryPort(serverRegistryPort);
			
			Element clientNameElem = doc.getRootElement().getChild(
			"clientname");
			String clientName = clientNameElem.getText();
			conf.setClientName(clientName);
			
			Element clientRegistryPortElem = doc.getRootElement().getChild(
			"clientregistryport");
			int clientRegistryPort = Integer.parseInt(clientRegistryPortElem.getText());
			conf.setClientRegistryPort(clientRegistryPort);

			Element heartbeatrateElem = doc.getRootElement().getChild(
					"heartbeatrate");
			int heartbeatRate = Integer.parseInt(heartbeatrateElem.getText());
			conf.setHeartBeatRate(heartbeatRate);

			Element autodeployElem = doc.getRootElement()
					.getChild("autodeploy");
			boolean doAutodeploy = Boolean.parseBoolean(autodeployElem
					.getText());
			conf.setDoDeploy(doAutodeploy);

			Element autojoinElem = doc.getRootElement().getChild("autojoin");

			boolean joinAllFlag = Boolean.parseBoolean(autojoinElem
					.getAttributeValue("joinall"));
			conf.setJoinAllPossibleMapsOnStartup(joinAllFlag);

			if (!joinAllFlag) {
				// Check which maps to join on startup
				Iterator autojoinMapIter = autojoinElem
						.getDescendants(new ElementFilter("mapid"));
				while (autojoinMapIter.hasNext()) {
					Element mapIDElem = (Element) autojoinMapIter.next();
					String mapID = mapIDElem.getText();
					if (mapID != null) {
						conf.addMapToJoinOnStartup(mapID);
					}
				}

			}
			System.out.println(conf.toString());

			return conf;
		} catch (Exception e) {
			logger.error("Error while loading cpmnfog file: " + e.getClass()
					+ ": " + e.getMessage(), e);
			return null;
		}
	}
}
