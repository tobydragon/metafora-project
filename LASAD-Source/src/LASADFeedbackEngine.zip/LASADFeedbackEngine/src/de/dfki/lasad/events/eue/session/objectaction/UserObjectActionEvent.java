package de.dfki.lasad.events.eue.session.objectaction;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.events.eue.session.EUEEventID;
import de.dfki.lasad.events.eue.session.UserActionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.objects.EUEObject;
import de.uds.xml.XmlFragment;

public abstract class UserObjectActionEvent extends UserActionEvent {
	protected List<EUEObject> eueObjectList = new Vector<EUEObject>();

	public UserObjectActionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID) {
		super(sessionID, srcCompId, eueEventID);
	}

	public UserObjectActionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID) {
		super(sessionID, srcCompId, eueEventID, userID);
	}

	public UserObjectActionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID,
			List<EUEObject> eueObjectList) {
		super(sessionID, srcCompId, eueEventID, userID);
		this.eueObjectList = eueObjectList;
	}

	public void setEueObjectList(List<EUEObject> eueObjectList) {
		this.eueObjectList = eueObjectList;
	}

	public List<EUEObject> getEueObjectList() {
		return eueObjectList;
	}
	
	public void addEueObject(EUEObject eueObject) {
		eueObjectList.add(eueObject);
	}
	
	public int getEueObjectIndex(EUEObject eueObject){
		int index = -1;
		for (int i =0;i < eueObjectList.size(); i++){
			if (eueObjectList.get(i).equals(eueObject)){
				index = i;
				break;
			}
		}
		return index;
	}
	
	public boolean deleteEueObjectWithIndex(int index){
		boolean flag = false;
		if ((0 == eueObjectList.size()) || (index < 0) || 
			(index > eueObjectList.size()-1)){
			return flag;
		}else{
			eueObjectList.remove(index);
			flag = true;
		}
		return flag;
	}

	@Override
	public String toString() {
		StringBuffer str = new StringBuffer();
		str.append(super.toString() +  ", eueObjectList=[");
		for (EUEObject obj: eueObjectList){
			str.append("["+ obj.toString() + "]");
		}
		str.append("]");
		return super.toString() +  ", eueObjectList=" + eueObjectList;
	}
	
	public abstract UserObjectActionEvent cloneWithoutObjects();
	
	public XmlFragment toXml(){
		XmlFragment xmlFragment = super.toXml();
		XmlFragment objectElement = new XmlFragment("Objects");
		for (EUEObject obj: eueObjectList){
			objectElement.addContent(obj.toXml());
		}
		xmlFragment.addContent(objectElement);
		return xmlFragment;
	}

}
