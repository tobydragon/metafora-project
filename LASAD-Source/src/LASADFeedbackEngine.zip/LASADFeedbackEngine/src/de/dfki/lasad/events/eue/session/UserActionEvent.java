package de.dfki.lasad.events.eue.session;

import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.uds.xml.XmlFragment;

/**
 * @author Oliver Scheuer
 * 
 */
public class UserActionEvent extends EUESessionEvent {

	protected UserID userID;

	public UserActionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID) {
		super(sessionID, srcCompId, eueEventID);
	}

	public UserActionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID) {
		super(sessionID, srcCompId, eueEventID);
		this.userID = userID;
	}

	public void setUserID(UserID userID) {
		this.userID = userID;
	}

	public UserID getUserID() {
		return userID;
	}

	@Override
	public String toString() {
		return super.toString() + ", userID=" + userID + "";
	}
	

	public XmlFragment toXml(){

		XmlFragment element = new XmlFragment("UserActionEvent");
		element.setAttribute("userActionEventType", getUserActionEventType());
		element.setAttribute("sourceComponentId", sourceComponentID);
		element.addContent(userID.toXml());
		element.addContent(sessionID.toXml());
		element.addContent(eueEventID.toXml());
		
		return element;	

	}
	
	public String getUserActionEventType(){
		return getClass().getSimpleName();
	}

}
