package de.dfki.lasad.models.eue.objects.graph;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import de.dfki.lasad.models.eue.objects.EUEObject;
import de.dfki.lasad.models.eue.objects.EUEObjectID;

public class Link extends EUEObject {

	private List<EUEObjectID> sources = new Vector<EUEObjectID>();
	private List<EUEObjectID> targets = new Vector<EUEObjectID>();

	public void addSource(EUEObjectID id) {
		sources.add(id);
	}

	public void addTarget(EUEObjectID id) {
		targets.add(id);
	}

	public List<EUEObjectID> getSources() {
		return sources;
	}

	public List<EUEObjectID> getTargets() {
		return targets;
	}

	@Override
	public boolean isTopLevelObject() {
		return true;
	}

	public void setSources(List<EUEObjectID> sources) {
		this.sources = sources;
	}

	public void setTargets(List<EUEObjectID> targets) {
		this.targets = targets;
	}

	@Override
	public String toString() {
		return super.toString() + ", sources=" + listToString(sources)
				+ ", targets=" + listToString(targets);
	}

	private String listToString(List<EUEObjectID> input) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("{");

		EUEObjectID id;
		for (Iterator<EUEObjectID> iter = input.iterator(); iter.hasNext();) {
			id = iter.next();
			buffer.append(id);
			if (iter.hasNext()) {
				buffer.append(", ");
			}
		}
		buffer.append("}");
		return buffer.toString();
	}
}
