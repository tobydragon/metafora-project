package de.dfki.lasad.util;

import java.io.StringReader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

public class XmlHelper {
	Log logger = LogFactory.getLog(XmlHelper.class);
	
	static SAXBuilder builder = new SAXBuilder();
	
    Document doc;
    
    public XmlHelper(Document doc){
    	this.doc = doc;
    }
    
    public XmlHelper(String xmlString){
    	doc = getDocument(xmlString);
    }
    
     private Document getDocument(String xmlString){
    	 try {
    		 return builder.build( new StringReader(xmlString ) );
    	 }
    	 catch (Exception e){
    		 return null;
    	 }
     }
     
     public String getElementString(String elementName){
    	 return doc.getRootElement().getChild(elementName).getText();
     }
     
     public String getElementAttributeString(String elementName, String attributeName){
    	 return doc.getRootElement().getChild(elementName).getAttribute(attributeName).getValue();
     }
     
     public Element getElement(){
    	 return doc.getRootElement();
     }
     
     public String getRootName(){
    	 if (doc != null){
    		 return getElement().getName();
    	 }
    	 else {
    		 return null;
    	 }
     }
     
     public String toString(){
	    XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
	    return outputter.outputString(doc);
     }
    
}
