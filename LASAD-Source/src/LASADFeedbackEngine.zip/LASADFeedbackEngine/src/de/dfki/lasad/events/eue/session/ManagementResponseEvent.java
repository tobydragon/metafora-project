package de.dfki.lasad.events.eue.session;

import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.modules.action.xmpp.XmppActionAgent;

public class ManagementResponseEvent extends EUESessionEvent {

	String command;
	String message;
	
	public ManagementResponseEvent(SessionID sessionID, String srcCompId, String command, String message) {
		super(sessionID, srcCompId);
		this.command = command;
		this.message = message;
	}
	
	public String toString(){
		return "[command - " + command + "] [message - " + message + "]";
	}

	public String getCommand() {
		return command;
	}

	public String getMessage() {
		return message;
	}

	public boolean isSuccess(){
		if (command.equals("AUTHORING-FAILED")){
			return false;
		}
		return true;
	}
	
	public static ManagementResponseEvent getTestableInstance() {
		return new ManagementResponseEvent(null, XmppActionAgent.class.getName(), "AUTHORING-FAILED", "Username already exists, please choose another one.");
	}
	
	

	
}
