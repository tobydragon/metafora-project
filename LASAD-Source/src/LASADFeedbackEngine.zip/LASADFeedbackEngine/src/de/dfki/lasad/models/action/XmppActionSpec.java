package de.dfki.lasad.models.action;

public class XmppActionSpec extends ActionComponentSpec {
	
}
