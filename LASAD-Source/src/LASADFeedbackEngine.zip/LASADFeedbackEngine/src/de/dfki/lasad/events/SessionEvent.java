package de.dfki.lasad.events;

import de.dfki.lasad.models.eue.SessionID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class SessionEvent extends Event {

	protected SessionID sessionID;

	public SessionEvent(SessionID sessionID, String srcCompId) {
		super(srcCompId);
		this.sessionID = sessionID;
	}

	public void setSessionID(SessionID sessionID) {
		this.sessionID = sessionID;
	}

	public SessionID getSessionID() {
		return sessionID;
	}

	@Override
	public String toString() {
		return super.toString() + ", sessionID=" + sessionID;
	}

}
