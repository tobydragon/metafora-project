package de.dfki.lasad.models.eue.objects;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import de.uds.xml.XmlFragment;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class ListProperty extends ObjectProperty {

	private final List<String> valueList;

	public ListProperty(String name, List<String> valueList) {
		super(name);
		this.valueList = valueList;
	}

	/**
	 * 
	 * @return value Strings concatenated, separated by empty spaces.
	 */
	@Override
	public String getValueAsString() {
		StringBuffer valuesAsString = new StringBuffer();
		for (Iterator<String> iter = valueList.iterator(); iter.hasNext();) {
			String value = iter.next();
			valuesAsString.append(value);
			if (iter.hasNext()) {
				valuesAsString.append(" ");
			}
		}
		return valuesAsString.toString();
	}

	public List<String> getValues() {
		return valueList;
	}

	@Override
	public String toString() {
		return name + "->" + Arrays.toString(valueList.toArray());
	}

}
