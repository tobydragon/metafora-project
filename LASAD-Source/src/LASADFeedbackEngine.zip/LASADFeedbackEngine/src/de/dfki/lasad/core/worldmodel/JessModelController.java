package de.dfki.lasad.core.worldmodel;

import java.io.Reader;
import java.io.StringReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import jess.Context;
import jess.Fact;
import jess.HasLHS;
import jess.Jesp;
import jess.JessException;
import jess.LongValue;
import jess.QueryResult;
import jess.RU;
import jess.Rete;
import jess.Value;
import jess.ValueVector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.PluggableComponentDescription;
import de.dfki.lasad.core.action.ActionType;
import de.dfki.lasad.core.action.CompoundActionType;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.core.analysis.OntologyChecker;
import de.dfki.lasad.core.application.DisplayedObjectIDTracker;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.admin.EUESessionListEvent;
import de.dfki.lasad.events.eue.session.AgentJoinSessionAnnounceEvent;
import de.dfki.lasad.events.eue.session.AgentJoinSessionConfirmEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserCreateObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserDeleteObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserModifyObjectEvent;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.analysis.AnalyzableEntity;
import de.dfki.lasad.models.analysis.BinaryResult;
import de.dfki.lasad.models.analysis.NominalResult;
import de.dfki.lasad.models.analysis.NumericalResult;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.objects.EUEObject;
import de.dfki.lasad.models.eue.objects.EUEObjectID;
import de.dfki.lasad.models.eue.objects.ObjectProperty;
import de.dfki.lasad.models.eue.objects.graph.Link;
import de.dfki.lasad.models.eue.objects.graph.Node;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessModelController implements IModelController {

	private Log logger = LogFactory.getLog(JessModelController.class);

	private static final boolean LOG_ALL_FACT_TO_CONSOLE_ON_UPDATE = true;

	private String componentID = getClass().getName();

	public static final String CHILDREN_PREFIX = "elem_";
	public static final String COUNTER_NODE_PREFIX = "n_";

	public static final String COUNTER_NODE_ALL = COUNTER_NODE_PREFIX + "all";
	public static final String COUNTER_LINK_PREFIX = "l_";

	public static final String COUNTER_LINK_ALL = COUNTER_LINK_PREFIX + "all";
	public static final String COUNTER_USER_PREFIX = "u_";
	public static final String COUNTER_USER_ALL = COUNTER_USER_PREFIX + "all";

	private List<IAnalysisAgent> modelUpdatingAgents = new Vector<IAnalysisAgent>();

	private HashMap<AnalysisType, String> analysisTypes2PatternSpecs = new HashMap<AnalysisType, String>();

	// to impose an ordering on IDs (to ensure a unique mapping from sets to
	// lists)
	private Comparator<EUEObjectID> idComparator = new Comparator<EUEObjectID>() {
		@Override
		public int compare(EUEObjectID o1, EUEObjectID o2) {
			return o1.getIdAsString().compareTo(o2.getIdAsString());
		}
	};

	private HashMap<SessionID, Rete> sessions2JessEngine = new HashMap<SessionID, Rete>();
	private Map<SessionID, Map<EUEObjectID, Fact>> sessions2objectID2fact = new HashMap<SessionID, Map<EUEObjectID, Fact>>();

	private Map<SessionID, Map<EUEObjectID, Set<EUEObjectID>>> sessions2nodeID2inLinkIDs = new HashMap<SessionID, Map<EUEObjectID, Set<EUEObjectID>>>();
	private Map<SessionID, Map<EUEObjectID, Set<EUEObjectID>>> sessions2nodeID2outLinkIDs = new HashMap<SessionID, Map<EUEObjectID, Set<EUEObjectID>>>();
	private Map<SessionID, Map<EUEObjectID, Set<EUEObjectID>>> sessions2linkID2sourceIDs = new HashMap<SessionID, Map<EUEObjectID, Set<EUEObjectID>>>();
	private Map<SessionID, Map<EUEObjectID, Set<EUEObjectID>>> sessions2linkID2targetIDs = new HashMap<SessionID, Map<EUEObjectID, Set<EUEObjectID>>>();

	private Map<SessionID, Map<StringPair, Integer>> sessions2counterTargetUserPair2Count = new HashMap<SessionID, Map<StringPair, Integer>>();
	private Map<SessionID, Map<StringPair, Fact>> sessions2counterTargetUserPair2Fact = new HashMap<SessionID, Map<StringPair, Fact>>();

	private JessGraphTemplates graphTemplates;
	private JessModelControllerDescription description;

	@Override
	public void configure(PluggableComponentDescription description)
			throws ComponentInitException {
		graphTemplates = new JessGraphTemplates();
		this.description = (JessModelControllerDescription) description;
	}

	@Override
	public JessModelControllerDescription getComponentDescription() {
		return description;
	}

	@Override
	public void registerAnalysisPattern(AnalysisType analysisType,
			String patternSpec) {
		logger.info("Registering analysis pattern for " + analysisType + ": "
				+ patternSpec);
		analysisTypes2PatternSpecs.put(analysisType, patternSpec);
	}

	/**
	 * Add / update session-ontology mappings
	 */
	@Override
	public void executeSessionListEvent(EUESessionListEvent sessionListEvent) {
		Map<SessionID, EUEOntology> changedOntologies = sessionListEvent
				.getSessionIDs2Ontology();
		for (SessionID sessionID : changedOntologies.keySet()) {
			EUEOntology ontology = changedOntologies.get(sessionID);
			logger.info("Set ontology for session '" + sessionID + "': "
					+ ontology);
			graphTemplates.registerOntology(sessionID, ontology);
		}
	}

	/**
	 * Prepare world model for new session ({@link SessionID}) before A&F agent
	 * actually joins the session.
	 */
	@Override
	public void executeAgentJoinSessionAnnounceEvent(
			AgentJoinSessionAnnounceEvent joinSessionAnnounceEvent) {

		SessionID sessionID = joinSessionAnnounceEvent.getSessionID();
		EUEOntology ontology = graphTemplates.getOntology(sessionID);

		IModelControllerConfiguration configuration = description
				.getConfiguration();
		OntologyChecker ontologyChecker = configuration
				.getOntologySupportChecker();
		if (!ontologyChecker.isOntologySupported(ontology)) {
			logger.info("Ontology '" + ontology + "' of session '" + sessionID
					+ "' not supported.");
			return;
		}
		logger
				.info("Start preparing model for session '" + sessionID
						+ "' ...");
		if (sessions2JessEngine.keySet().contains(sessionID)) {
			logger.warn("Session '" + sessionID.getIdAsString()
					+ "' does already exist in Jess. "
					+ "Will re-initialize Jess working memory.");
			cleanSession(sessionID);
		}
		Rete jessEngine = new Rete();
		sessions2JessEngine.put(sessionID, jessEngine);
		initEngine(sessionID, jessEngine);
	}

	private void cleanSession(SessionID sessionID) {
		sessions2JessEngine.remove(sessionID);
		sessions2objectID2fact.remove(sessionID);

		sessions2nodeID2inLinkIDs.remove(sessionID);
		sessions2nodeID2outLinkIDs.remove(sessionID);
		sessions2linkID2sourceIDs.remove(sessionID);
		sessions2linkID2targetIDs.remove(sessionID);

		sessions2counterTargetUserPair2Count.remove(sessionID);
		sessions2counterTargetUserPair2Fact.remove(sessionID);
	}

	/**
	 * Initialization work for new session.
	 * 
	 * @param sessionID
	 * @param jessEngine
	 */
	private void initEngine(SessionID sessionID, Rete jessEngine) {
		try {

			// Create new index entries for sessions
			sessions2objectID2fact.put(sessionID,
					new HashMap<EUEObjectID, Fact>());
			sessions2nodeID2inLinkIDs.put(sessionID,
					new HashMap<EUEObjectID, Set<EUEObjectID>>());
			sessions2nodeID2outLinkIDs.put(sessionID,
					new HashMap<EUEObjectID, Set<EUEObjectID>>());
			sessions2linkID2sourceIDs.put(sessionID,
					new HashMap<EUEObjectID, Set<EUEObjectID>>());
			sessions2linkID2targetIDs.put(sessionID,
					new HashMap<EUEObjectID, Set<EUEObjectID>>());
			sessions2counterTargetUserPair2Count.put(sessionID,
					new HashMap<StringPair, Integer>());
			sessions2counterTargetUserPair2Fact.put(sessionID,
					new HashMap<StringPair, Fact>());

			addBasicDefinitions(sessionID);
			addOntologyBasedDefinitions(sessionID);
			addAnnotationDefinitionsAndAnnotations(sessionID);
			addApplicableRules(sessionID);
			addResultQueryDefinition(sessionID);

			jessEngine.reset();

			initializeTallies(sessionID);

			jessEngine.run();

			AgentJoinSessionConfirmEvent confirmEvent = new AgentJoinSessionConfirmEvent(
					sessionID, componentID);

			// ServiceRegistry.getDataService().onAgentJoinSessionConfirmEvent(
			// confirmEvent);
		} catch (JessException e) {
			logger.error("initEngine " + e.getClass(), e);
		}
	}

	public void executeJessBatch(SessionID sessionID, String batch)
			throws JessException {
		Rete jessEngine = sessions2JessEngine.get(sessionID);
		Reader r = new StringReader(batch);
		Jesp j = new Jesp(r, jessEngine);
		j.parse(false);
	}

	protected void addBasicDefinitions(SessionID sessionID) {
		String basicDefinitionsBatch = graphTemplates.getBasicDefinitions();
		try {
			executeJessBatch(sessionID, basicDefinitionsBatch);
			logger.info("Basic definitions added to session '" + sessionID
					+ "'.");
		} catch (Exception e) {
			logger.error("addBasicDefinitions " + e.getClass(), e);
		}
	}

	protected void addOntologyBasedDefinitions(SessionID sessionID) {
		String ontologyBasedDefinitionsBatch = graphTemplates
				.getOntologyBasedDefinitions(sessionID);
		if (ontologyBasedDefinitionsBatch == null) {
			logger.info("No Ontology-based definitions defined for session '"
					+ sessionID + "'.");
		} else {
			try {
				executeJessBatch(sessionID, ontologyBasedDefinitionsBatch);
				logger.info("Ontology-based definitions added to session '"
						+ sessionID + "'.");
			} catch (Exception e) {
				logger.error("addOntologyBasedDefinitions" + e.getClass(), e);
			}
		}
	}

	protected void addAnnotationDefinitionsAndAnnotations(SessionID sessionID) {
		List<String> annotationsJessBatches = graphTemplates
				.getAnnotationDefinitionsAndAnnotations(sessionID);
		try {
			for (String annotationsJessBatch : annotationsJessBatches) {
				executeJessBatch(sessionID, annotationsJessBatch);
				logger
						.info("Annotations added to session '" + sessionID
								+ "'.");
			}
		} catch (Exception e) {
			logger.error("addAnnotationDefinitionsAndAnnotations(), "
					+ e.getClass(), e);
		}
	}

	/**
	 * Add rules (analysis patterns) that can be applied to session.
	 * 
	 * @param sessionID
	 * @param jessEngine
	 */
	protected void addApplicableRules(SessionID sessionID) {
		EUEOntology ontology = graphTemplates.getOntology(sessionID);
		for (AnalysisType aType : analysisTypes2PatternSpecs.keySet()) {
			if (aType.isOntologySupported(ontology)) {
				String ruleDefinition = analysisTypes2PatternSpecs.get(aType);
				try {
					executeJessBatch(sessionID, ruleDefinition);
					logger.info("Rule definition added to session '"
							+ sessionID + "'.");
				} catch (Exception e) {
					logger.error("addApplicableRules(), " + e.getClass(), e);
				}
			}
		}
	}

	private void addResultQueryDefinition(SessionID sessionID) {
		String resultQueryDefinition = graphTemplates
				.getResultQueryDefinition();
		try {
			executeJessBatch(sessionID, resultQueryDefinition);
			logger.info("Result query added to session '" + sessionID + "'.");
		} catch (Exception e) {
			logger.error("addResultQueryDefinition(), " + e.getClass(), e);
		}
	}

	private void initializeTallies(SessionID sessionID) {
		logger.info("Start initializing tallies for session '" + sessionID
				+ "' ...");
		Map<StringPair, Integer> tallies = sessions2counterTargetUserPair2Count
				.get(sessionID);

		// create initial state
		StringPair allNodesTallyID = new StringPair(COUNTER_NODE_ALL,
				COUNTER_USER_ALL);
		tallies.put(allNodesTallyID, 0);

		StringPair allLinksTallyID = new StringPair(COUNTER_LINK_ALL,
				COUNTER_USER_ALL);
		tallies.put(allLinksTallyID, 0);

		for (String nodeType : graphTemplates.getNodeTypes(sessionID)) {
			String tallyType = COUNTER_NODE_PREFIX + nodeType;
			StringPair nodeTypeSpecificTally = new StringPair(tallyType,
					COUNTER_USER_ALL);
			tallies.put(nodeTypeSpecificTally, 0);
		}

		for (String linkType : graphTemplates.getLinkTypes(sessionID)) {
			String tallyType = COUNTER_LINK_PREFIX + linkType;
			StringPair linkTypeSpecificTally = new StringPair(tallyType,
					COUNTER_USER_ALL);
			tallies.put(linkTypeSpecificTally, 0);
		}

		for (StringPair tallyID : tallies.keySet()) {
			initializeTalliesinJess(sessionID, tallyID.getFirst(), tallyID
					.getSecond());
		}
	}

	private void initializeTalliesinJess(SessionID sessionID, String tallyType,
			String userID) {
		try {
			Rete jessEngine = sessions2JessEngine.get(sessionID);
			Fact tallyFact = new Fact("tally", jessEngine);
			tallyFact.setSlotValue("type", new Value(tallyType, RU.STRING));
			tallyFact.setSlotValue("user_id", new Value(userID, RU.STRING));
			tallyFact.setSlotValue("value", new Value(0, RU.INTEGER));
			Fact fact = jessEngine.assertFact(tallyFact);
			sessions2counterTargetUserPair2Fact.get(sessionID).put(
					new StringPair(tallyType, userID), fact);
		} catch (Exception e) {
			logger.error("initializeTalliesinJess(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	@Override
	public void executeEUESessionEvent(EUESessionEvent sessionEvent) {
		SessionID sessionID = sessionEvent.getSessionID();
		logger.debug("Execute event in session '" + sessionID + "' ...");
		Rete jessEngine = sessions2JessEngine.get(sessionID);
		if (sessionEvent instanceof UserCreateObjectEvent) {
			UserCreateObjectEvent createEvent = (UserCreateObjectEvent) sessionEvent;
			List<EUEObject> objects = createEvent.getEueObjectList();
			for (EUEObject object : objects) {
				if (object instanceof Node && object.isTopLevelObject()) {
					// top-level node
					insertNode((Node) object, createEvent, jessEngine);
				} else if (object instanceof Node) {
					// child node
					insertChildNode((Node) object, createEvent, jessEngine);
				} else if (object instanceof Link) {
					// link node
					insertLink((Link) object, createEvent, jessEngine);
				}
			}
		} else if (sessionEvent instanceof UserDeleteObjectEvent) {
			UserDeleteObjectEvent deleteEvent = (UserDeleteObjectEvent) sessionEvent;
			List<EUEObject> objects = deleteEvent.getEueObjectList();
			for (EUEObject object : objects) {
				if (object instanceof Node && object.isTopLevelObject()) {
					// top-level node
					deleteNode((Node) object, deleteEvent, jessEngine);
				} else if (object instanceof Node) {
					deleteChildNode((Node) object, deleteEvent, jessEngine);
				} else if (object instanceof Link) {
					deleteLink((Link) object, deleteEvent, jessEngine);
				}
			}
		} else if (sessionEvent instanceof UserModifyObjectEvent) {
			UserModifyObjectEvent modifyEvent = (UserModifyObjectEvent) sessionEvent;
			List<EUEObject> objects = modifyEvent.getEueObjectList();
			for (EUEObject object : objects) {
				if (object instanceof Node && object.isTopLevelObject()) {
					// top-level node
					modifyNode((Node) object, modifyEvent, jessEngine);
				} else if (object instanceof Node) {
					// child node
					modifyChildNode((Node) object, modifyEvent, jessEngine);
				} else if (object instanceof Link) {
					modifyLink((Link) object, modifyEvent, jessEngine);
				}
			}
		} else if (sessionEvent instanceof UserJoinSessionEvent) {
			/**
			 * TODO - Add / retract / modify Jess facts
			 */
		}

		if (LOG_ALL_FACT_TO_CONSOLE_ON_UPDATE) {
			for (Iterator<Fact> factIter = getWorkingMemoryFacts(sessionID); factIter
					.hasNext();) {
				logger.debug(factIter.next());
			}
		}

		try {
			jessEngine.run();
		} catch (Exception e) {
			logger.error("executeEUESessionEvent(), " + e.getClass() + ": "
					+ e.getMessage());
		}
	}

	/**
	 * Inserts a (top-level) {@link Node}. This includes:
	 * <ul>
	 * <li>insert {@link Node} in Jess</li>
	 * <li>keep track of {@link Node} in internal indices</li>
	 * <li>increment counters</li>
	 * </ul>
	 * 
	 * @param node
	 * @param createEvent
	 * @param jessEngine
	 */
	private void insertNode(Node node, UserCreateObjectEvent createEvent,
			Rete jessEngine) {
		try {
			SessionID sessionID = createEvent.getSessionID();
			logger.debug("Inserting (top-level) node in session '" + sessionID
					+ "': " + node);

			String id = node.getID().getIdAsString();
			String displayID = DisplayedObjectIDTracker.getDisplayID(sessionID, node.getID());  
			
			String type = node.getType();
			String creatorID = createEvent.getUserID().getIdAsString();
			long creationTs = createEvent.getTs();

			Fact nodeFact = new Fact("node", jessEngine);

			nodeFact.setSlotValue("type", new Value(type, RU.STRING));
			nodeFact.setSlotValue("id", new Value(id, RU.STRING));
			nodeFact.setSlotValue("display_id", new Value(displayID, RU.STRING));
			nodeFact
					.setSlotValue("creator_id", new Value(creatorID, RU.STRING));
			nodeFact.setSlotValue("creation_ts", new LongValue(creationTs));

			nodeFact.setSlotValue("last_modificator_id", new Value(creatorID,
					RU.STRING));
			nodeFact.setSlotValue("last_modification_ts", new LongValue(
					creationTs));

			for (String propName : node.getProps().keySet()) {
				if (graphTemplates.isNodePropSupported(sessionID, propName)) {
					ObjectProperty prop = node.getProps().get(propName);
					nodeFact.setSlotValue(propName, new Value(prop
							.getValueAsString(), RU.STRING));
				}
			}

			// Update Jess working memory
			Fact fact = jessEngine.assertFact(nodeFact);
			logger.debug("New Jess fact: " + fact);

			sessions2objectID2fact.get(sessionID).put(node.getID(), fact);

			// Create new index entries for node neighbors
			sessions2nodeID2inLinkIDs.get(sessionID).put(node.getID(),
					new TreeSet<EUEObjectID>(idComparator));
			sessions2nodeID2outLinkIDs.get(sessionID).put(node.getID(),
					new TreeSet<EUEObjectID>(idComparator));

			// update tallies
			updateTally(sessionID, COUNTER_NODE_ALL, COUNTER_USER_ALL, 1);
			String typeSpecificTally = COUNTER_NODE_PREFIX + type;
			updateTally(sessionID, typeSpecificTally, COUNTER_USER_ALL, 1);
		} catch (Exception e) {
			logger.error("insertNode(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	/**
	 * Inserts a (child) {@link Node}. This includes:
	 * <ul>
	 * <li>insert {@link Node} in Jess</li>
	 * <li>keep track of {@link Node} in internal indices</li>
	 * </ul>
	 * 
	 * @param node
	 * @param createEvent
	 * @param jessEngine
	 */
	private void insertChildNode(Node node, UserCreateObjectEvent createEvent,
			Rete jessEngine) {
		try {
			SessionID sessionID = createEvent.getSessionID();
			logger.debug("Inserting (child) node in session '" + sessionID
					+ "': " + node);

			String jessID = node.getID().getIdAsString();

			String type = node.getType();
			String creatorID = createEvent.getUserID().getIdAsString();
			long creationTs = createEvent.getTs();
			String parentID = node.getParentID().getIdAsString();

			String dataType = CHILDREN_PREFIX + node.getDataType();
			Fact nodeFact = new Fact(dataType, jessEngine);

			nodeFact.setSlotValue("type", new Value(type, RU.STRING));
			nodeFact.setSlotValue("id", new Value(jessID, RU.STRING));
			nodeFact.setSlotValue("parent_id", new Value(parentID, RU.STRING));
			nodeFact
					.setSlotValue("creator_id", new Value(creatorID, RU.STRING));
			nodeFact.setSlotValue("creation_ts", new LongValue(creationTs));

			nodeFact.setSlotValue("last_modificator_id", new Value(creatorID,
					RU.STRING));
			nodeFact.setSlotValue("last_modification_ts", new LongValue(
					creationTs));

			for (String propName : node.getProps().keySet()) {
				if (graphTemplates.isSubElementPropSupported(sessionID, node
						.getDataType(), propName)) {
					ObjectProperty prop = node.getProps().get(propName);
					nodeFact.setSlotValue(propName, new Value(prop
							.getValueAsString(), RU.STRING));
				}
			}

			// Update Jess working memory
			Fact fact = jessEngine.assertFact(nodeFact);
			logger.debug("New Jess fact: " + fact);
			sessions2objectID2fact.get(sessionID).put(node.getID(), fact);

		} catch (Exception e) {
			logger.error("insertChildNode(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	/**
	 * Inserts a {@link Link}. This includes:
	 * <ul>
	 * <li>insert {@link Link} in Jess</li>
	 * <li>keep track of {@link Link} in internal indices</li>
	 * <li>update {@link Node} neighborhood for {@link Link} sources and targets
	 * </li>
	 * <li>increment counters</li>
	 * </ul>
	 * 
	 * @param link
	 * @param createEvent
	 * @param jessEngine
	 */
	private void insertLink(Link link, UserCreateObjectEvent createEvent,
			Rete jessEngine) {
		try {
			SessionID sessionID = createEvent.getSessionID();
			logger.debug("Inserting link in session '" + sessionID + "': "
					+ link);

			String id = link.getID().getIdAsString();
			String displayID = DisplayedObjectIDTracker.getDisplayID(sessionID, link.getID());

			String type = link.getType();
			String creatorID = createEvent.getUserID().getIdAsString();
			long creationTs = createEvent.getTs();

			String dataType = link.getDataType();

			Fact linkFact = new Fact("link", jessEngine);

			linkFact.setSlotValue("type", new Value(type, RU.STRING));
			linkFact.setSlotValue("id", new Value(id, RU.STRING));
			linkFact.setSlotValue("display_id", new Value(displayID, RU.STRING));
			
			linkFact
					.setSlotValue("creator_id", new Value(creatorID, RU.STRING));
			linkFact.setSlotValue("creation_ts", new LongValue(creationTs));

			linkFact.setSlotValue("last_modificator_id", new Value(creatorID,
					RU.STRING));
			linkFact.setSlotValue("last_modification_ts", new LongValue(
					creationTs));

			// Add Source and Targets

			List<EUEObjectID> sourceIDs = link.getSources();
			List<EUEObjectID> targetIDs = link.getTargets();
			ValueVector valVecSources = new ValueVector();
			ValueVector valVecTargets = new ValueVector();

			for (EUEObjectID source : sourceIDs) {
				String val = source.getIdAsString();
				valVecSources.add(new Value(val, RU.STRING));
			}

			for (EUEObjectID target : targetIDs) {
				String val = target.getIdAsString();
				valVecTargets.add(new Value(val, RU.STRING));
			}

			linkFact.setSlotValue("source_ids", new Value(valVecSources,
					RU.LIST));
			linkFact.setSlotValue("target_ids", new Value(valVecTargets,
					RU.LIST));

			for (String propName : link.getProps().keySet()) {
				if (graphTemplates.isSubElementPropSupported(sessionID,
						dataType, propName)) {
					ObjectProperty prop = link.getProps().get(propName);
					linkFact.setSlotValue(propName, new Value(prop
							.getValueAsString(), RU.STRING));
				}
			}

			// Update Jess working memory
			Fact newFact = jessEngine.assertFact(linkFact);
			logger.debug("New Jess fact: " + newFact);

			// Update internal index (facts)
			sessions2objectID2fact.get(sessionID).put(link.getID(), newFact);

			// Update internal index (initialize source and target set for new
			// link)
			Set<EUEObjectID> linkSourcesSet = new HashSet<EUEObjectID>(
					sourceIDs);
			Set<EUEObjectID> linkTargetsSet = new HashSet<EUEObjectID>(
					targetIDs);
			sessions2linkID2sourceIDs.get(sessionID).put(link.getID(),
					linkSourcesSet);
			sessions2linkID2targetIDs.get(sessionID).put(link.getID(),
					linkTargetsSet);

			// Update internal index (node in- and out-links)
			for (EUEObjectID sourceID : sourceIDs) {
				Set<EUEObjectID> sourceOutLinkSet = sessions2nodeID2outLinkIDs
						.get(sessionID).get(sourceID);
				sourceOutLinkSet.add(link.getID());
			}
			for (EUEObjectID targetID : targetIDs) {
				Set<EUEObjectID> sourceInLinkSet = sessions2nodeID2inLinkIDs
						.get(sessionID).get(targetID);
				sourceInLinkSet.add(link.getID());
			}

			// update source and target element neighborhood if necessary (in
			// Jess)
			updateNeighbors(sessionID, linkSourcesSet, linkTargetsSet,
					jessEngine);

			// update tallies
			updateTally(sessionID, COUNTER_LINK_ALL, COUNTER_USER_ALL, 1);
			String typeSpecificTally = COUNTER_LINK_PREFIX + type;
			updateTally(sessionID, typeSpecificTally, COUNTER_USER_ALL, 1);

		} catch (Exception e) {
			logger.error("insertLink(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	/**
	 * Modifies a (top-level) {@link Node}. This includes:
	 * <ul>
	 * <li>update {@link Node} in Jess (type, properties, modification TSs)</li>
	 * <li>update internal indices</li>
	 * <li>update {@link Node} neighborhood for {@link Link} sources and targets
	 * </li>
	 * <li>update counters when type has changed</li>
	 * </ul>
	 * 
	 * @param node
	 * @param modifyEvent
	 * @param jessEngine
	 */
	private void modifyNode(Node node, UserModifyObjectEvent modifyEvent,
			Rete jessEngine) {
		try {
			SessionID sessionID = modifyEvent.getSessionID();
			logger.debug("Modifying node in session '" + sessionID + "': "
					+ node);

			String jessID = node.getID().getIdAsString();
			Fact oldFact = sessions2objectID2fact.get(sessionID).get(
					node.getID());

			List<String> changedPropNames = new Vector<String>();
			List<Value> changedPropValues = new Vector<Value>();

			String oldType = oldFact.getSlotValue("type").stringValue(
					jessEngine.getGlobalContext());
			String newType = node.getType();
			if (!newType.equals(oldType)) {
				changedPropNames.add("type");
				changedPropValues.add(new Value(newType, RU.STRING));
			}

			for (String propName : node.getProps().keySet()) {
				if (graphTemplates.isNodePropSupported(sessionID, propName)) {
					changedPropNames.add(propName);
					String value = node.getProps().get(propName)
							.getValueAsString();
					changedPropValues.add(new Value(value, RU.STRING));
				}
			}

			String modificatorID = modifyEvent.getUserID().getIdAsString();
			long modificationTs = modifyEvent.getTs();

			changedPropNames.add("last_modificator_id");
			changedPropValues.add(new Value(modificatorID, RU.STRING));

			changedPropNames.add("last_modification_ts");
			changedPropValues.add(new LongValue(modificationTs));

			// Update Jess working memory
			Fact newFact = jessEngine.modify(oldFact, changedPropNames
					.toArray(new String[changedPropNames.size()]),
					changedPropValues.toArray(new Value[changedPropValues
							.size()]));
			logger.debug("Modified Jess fact: " + newFact);

			// Update internal index (facts)
			sessions2objectID2fact.get(sessionID).put(node.getID(), newFact);

			// update counters if type has changed
			if (!newType.equals(oldType)) {
				String typeSpecificTallyNew = COUNTER_NODE_PREFIX + newType;
				updateTally(sessionID, typeSpecificTallyNew, COUNTER_USER_ALL,
						1);
				String typeSpecificTallyOld = COUNTER_NODE_PREFIX + oldType;
				updateTally(sessionID, typeSpecificTallyOld, COUNTER_USER_ALL,
						-1);
			}
		} catch (Exception e) {
			logger.error("modifyNode(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	/**
	 * Modifies a (child) {@link Node}. This includes:
	 * <ul>
	 * <li>update {@link Node} in Jess (properties, modification TSs)</li>
	 * <li>update internal indices</li>
	 * </ul>
	 * 
	 * @param node
	 * @param modifyEvent
	 * @param jessEngine
	 */
	private void modifyChildNode(Node node, UserModifyObjectEvent modifyEvent,
			Rete jessEngine) {
		try {
			SessionID sessionID = modifyEvent.getSessionID();
			logger.debug("Modifying child node in session '" + sessionID
					+ "': " + node);

			String jessID = node.getID().getIdAsString();
			Fact oldFact = sessions2objectID2fact.get(sessionID).get(
					node.getID());

			List<String> changedPropNames = new Vector<String>();
			List<Value> changedPropValues = new Vector<Value>();

			String dataType = node.getDataType();
			for (String propName : node.getProps().keySet()) {
				if (graphTemplates.isSubElementPropSupported(sessionID,
						dataType, propName)) {
					changedPropNames.add(propName);
					String value = node.getProps().get(propName)
							.getValueAsString();
					changedPropValues.add(new Value(value, RU.STRING));
				}
			}

			String modificatorID = modifyEvent.getUserID().getIdAsString();
			long modificationTs = modifyEvent.getTs();

			changedPropNames.add("last_modificator_id");
			changedPropValues.add(new Value(modificatorID, RU.STRING));

			changedPropNames.add("last_modification_ts");
			changedPropValues.add(new LongValue(modificationTs));

			// Update Jess working memory
			Fact newFact = jessEngine.modify(oldFact, changedPropNames
					.toArray(new String[changedPropNames.size()]),
					changedPropValues.toArray(new Value[changedPropValues
							.size()]));
			logger.debug("Modified Jess fact: " + newFact);

			// Update internal index (facts)
			sessions2objectID2fact.get(sessionID).put(node.getID(), newFact);

		} catch (Exception e) {
			logger.error("modifyNode(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	/**
	 * Modifies a {@link Link}. This includes:
	 * <ul>
	 * <li>update {@link Link} in Jess (type, properties, modification TSs)</li>
	 * <li>update internal indices</li>
	 * <li>update {@link Node} neighborhood for {@link Link} sources and
	 * targets, if necessary</li>
	 * <li>update counters when type has changed</li>
	 * </ul>
	 * 
	 * @param link
	 * @param modifyEvent
	 * @param jessEngine
	 */
	private void modifyLink(Link link, UserModifyObjectEvent modifyEvent,
			Rete jessEngine) {
		try {
			SessionID sessionID = modifyEvent.getSessionID();
			logger.debug("Modifying link in session '" + sessionID + "': "
					+ link);

			String jessID = link.getID().getIdAsString();
			Fact oldFact = sessions2objectID2fact.get(sessionID).get(
					link.getID());

			List<String> changedPropNames = new Vector<String>();
			List<Value> changedPropValues = new Vector<Value>();

			// check whether type has changed
			String oldType = oldFact.getSlotValue("type").stringValue(
					jessEngine.getGlobalContext());
			String newType = link.getType();
			if (!newType.equals(oldType)) {
				changedPropNames.add("type");
				changedPropValues.add(new Value(newType, RU.STRING));
			}

			Set<EUEObjectID> oldSourceIDs = sessions2linkID2sourceIDs.get(
					sessionID).get(link.getID());
			List<EUEObjectID> newSourceIDs = link.getSources();
			Set<EUEObjectID> oldTargetIDs = sessions2linkID2targetIDs.get(
					sessionID).get(link.getID());
			List<EUEObjectID> newTargetIDs = link.getTargets();

			// Check whether sources have changed
			boolean sourcesChanged = false;

			// we collect changed sources' targets to update their neighborhood
			Set<EUEObjectID> changedSourceTargets = new HashSet<EUEObjectID>();

			// check for added sources
			for (EUEObjectID newSourceID : newSourceIDs) {
				if (!oldSourceIDs.contains(newSourceID)) {
					// add new outlink to source
					sessions2nodeID2outLinkIDs.get(sessionID).get(newSourceID)
							.add(link.getID());
					// changedSources.add(newSourceID);
					changedSourceTargets.addAll(newTargetIDs);
					sourcesChanged = true;
				}
			}
			// check for removed sources
			for (EUEObjectID oldSourceID : oldSourceIDs) {
				if (!newSourceIDs.contains(oldSourceID)) {
					// remove outdated outlink from source
					sessions2nodeID2outLinkIDs.get(sessionID).get(oldSourceID)
							.remove(link.getID());
					// changedSources.add(oldSourceID);
					changedSourceTargets.addAll(oldTargetIDs);
					sourcesChanged = true;
				}
			}

			// Adding source_ids to changed properties
			if (sourcesChanged) {
				changedPropNames.add("source_ids");
				ValueVector newSourcesVector = new ValueVector();
				for (EUEObjectID sourceId : newSourceIDs) {
					Value v = new Value(sourceId.getIdAsString(), RU.STRING);
					newSourcesVector.add(v);
				}
				changedPropValues.add(new Value(newSourcesVector, RU.LIST));

				// update internal index (link -> sourceIDs)
				Set<EUEObjectID> newSourceIDSet = new TreeSet<EUEObjectID>(
						idComparator);
				newSourceIDSet.addAll(newSourceIDs);
				sessions2linkID2sourceIDs.get(sessionID).put(link.getID(),
						newSourceIDSet);
			}

			// Check whether targets have changed
			boolean targetsChanged = false;

			// we collect changed targets' sources to update their neighborhood
			Set<EUEObjectID> changedTargetSources = new HashSet<EUEObjectID>();

			// check for added targets
			for (EUEObjectID newTargetID : newTargetIDs) {
				if (!oldTargetIDs.contains(newTargetID)) {
					// add new inlink to targets
					sessions2nodeID2inLinkIDs.get(sessionID).get(newTargetID)
							.add(link.getID());
					// changedTargets.add(newTargetID);
					changedTargetSources.addAll(newSourceIDs);
					targetsChanged = true;
				}
			}
			// check for removed targets
			for (EUEObjectID oldTargetID : oldTargetIDs) {
				if (!newTargetIDs.contains(oldTargetID)) {
					// remove outdated inlink from target
					sessions2nodeID2inLinkIDs.get(sessionID).get(oldTargetID)
							.remove(link.getID());
					// changedTargets.add(oldTargetID);
					changedTargetSources.addAll(oldSourceIDs);
					targetsChanged = true;
				}
			}

			if (targetsChanged) {
				// Adding target_ids to changed properties
				changedPropNames.add("target_ids");
				ValueVector newTargetsVector = new ValueVector();
				for (EUEObjectID targetId : newTargetIDs) {
					Value v = new Value(targetId.getIdAsString(), RU.STRING);
					newTargetsVector.add(v);
				}
				changedPropValues.add(new Value(newTargetsVector, RU.LIST));

				// update internal index (link -> targetIDs)
				Set<EUEObjectID> newTargetIDSet = new TreeSet<EUEObjectID>(
						idComparator);
				newTargetIDSet.addAll(newTargetIDs);
				sessions2linkID2targetIDs.get(sessionID).put(link.getID(),
						newTargetIDSet);
			}

			for (String propName : link.getProps().keySet()) {
				if (graphTemplates.isNodePropSupported(sessionID, propName)) {
					changedPropNames.add(propName);
					String value = link.getProps().get(propName)
							.getValueAsString();
					changedPropValues.add(new Value(value, RU.STRING));
				}
			}

			String modificatorID = modifyEvent.getUserID().getIdAsString();
			long modificationTs = modifyEvent.getTs();

			changedPropNames.add("last_modificator_id");
			changedPropValues.add(new Value(modificatorID, RU.STRING));

			changedPropNames.add("last_modification_ts");
			changedPropValues.add(new LongValue(modificationTs));

			// Update Jess working memory
			Fact newFact = jessEngine.modify(oldFact, changedPropNames
					.toArray(new String[changedPropNames.size()]),
					changedPropValues.toArray(new Value[changedPropValues
							.size()]));
			logger.debug("Modified Jess fact: " + newFact);

			// Update internal index (facts)
			sessions2objectID2fact.get(sessionID).put(link.getID(), newFact);

			// update source and target element neighborhood if necessary
			updateNeighbors(sessionID, changedTargetSources,
					changedSourceTargets, jessEngine);

			// update counters if type has changed
			if (!newType.equals(oldType)) {
				String typeSpecificTallyNew = COUNTER_LINK_PREFIX + newType;
				updateTally(sessionID, typeSpecificTallyNew, COUNTER_USER_ALL,
						1);
				String typeSpecificTallyOld = COUNTER_LINK_PREFIX + oldType;
				updateTally(sessionID, typeSpecificTallyOld, COUNTER_USER_ALL,
						-1);
			}
		} catch (Exception e) {
			logger.error("modifyLink(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	/**
	 * Deletes a (top-level) {@link Node}. This includes:
	 * <ul>
	 * <li>retract {@link Node} from Jess</li>
	 * <li>update internal indices</li>
	 * <li>update {@link Link} sources and targets for {@link Link} that connect
	 * to this {@link Node}</li>
	 * <li>update {@link Node} neighborhood for neighboring {@link Node}s (i.e.,
	 * delete this {@link Node} from neighbors)</li>
	 * <li>update counters</li>
	 * </ul>
	 * 
	 * @param node
	 * @param deleteEvent
	 * @param jessEngine
	 */
	private void deleteNode(Node node, UserDeleteObjectEvent deleteEvent,
			Rete jessEngine) {
		try {
			SessionID sessionID = deleteEvent.getSessionID();
			logger.debug("Deleting (top-level) node in session '" + sessionID
					+ "': " + node);

			EUEObjectID nodeID = node.getID();
			// remove node itself
			Fact nodeFact = sessions2objectID2fact.get(sessionID)
					.remove(nodeID);
			jessEngine.retract(nodeFact);

			// remove node as link source (internal index + Jess); collect all
			// affected link targets (since their neighborhood changed)
			Set<EUEObjectID> relevantOutLinks = sessions2nodeID2outLinkIDs.get(
					sessionID).remove(nodeID);
			Set<EUEObjectID> affectedOutLinkTargets = new HashSet<EUEObjectID>();
			for (EUEObjectID outLinkID : relevantOutLinks) {
				// remove node as link source (internal index)
				Set<EUEObjectID> outLinkSources = sessions2linkID2sourceIDs
						.get(sessionID).get(outLinkID);
				outLinkSources.remove(nodeID);

				// remove node as link source (Jess)
				List<String> changedPropNames = new Vector<String>();
				changedPropNames.add("source_ids");
				List<Value> changedPropValues = new Vector<Value>();
				ValueVector newSourcesVector = new ValueVector();
				for (EUEObjectID sourceId : outLinkSources) {
					Value v = new Value(sourceId.getIdAsString(), RU.STRING);
					newSourcesVector.add(v);
				}
				changedPropValues.add(new Value(newSourcesVector, RU.LIST));
				Fact linkFact = sessions2objectID2fact.get(sessionID).get(
						outLinkID);
				Fact newFact = jessEngine.modify(linkFact, changedPropNames
						.toArray(new String[changedPropNames.size()]),
						changedPropValues.toArray(new Value[changedPropValues
								.size()]));

				// Update internal index (facts)
				sessions2objectID2fact.get(sessionID).put(outLinkID, newFact);

				logger
						.debug("Modified Link fact (deleted node -> changed sources): "
								+ newFact);

				// add affected link targets (to update their neighborhood)
				Set<EUEObjectID> outLinkTargets = sessions2linkID2targetIDs
						.get(sessionID).get(outLinkID);
				affectedOutLinkTargets.addAll(outLinkTargets);
			}

			// remove node as link target (internal index + Jess); collect all
			// affected link sources (since their neighborhood changed)
			Set<EUEObjectID> relevantInLinks = sessions2nodeID2inLinkIDs.get(
					sessionID).remove(nodeID);
			Set<EUEObjectID> affectedInLinkSources = new HashSet<EUEObjectID>();
			for (EUEObjectID inLinkID : relevantInLinks) {
				// remove node as link target (internal index)
				Set<EUEObjectID> inLinkTargets = sessions2linkID2targetIDs.get(
						sessionID).get(inLinkID);
				inLinkTargets.remove(nodeID);

				// remove node as link target (Jess)
				List<String> changedPropNames = new Vector<String>();
				changedPropNames.add("target_ids");
				List<Value> changedPropValues = new Vector<Value>();
				ValueVector newTargetVector = new ValueVector();
				for (EUEObjectID targetId : inLinkTargets) {
					Value v = new Value(targetId.getIdAsString(), RU.STRING);
					newTargetVector.add(v);
				}
				changedPropValues.add(new Value(newTargetVector, RU.LIST));
				Fact linkFact = sessions2objectID2fact.get(sessionID).get(
						inLinkID);
				Fact newFact = jessEngine.modify(linkFact, changedPropNames
						.toArray(new String[changedPropNames.size()]),
						changedPropValues.toArray(new Value[changedPropValues
								.size()]));

				// Update internal index (facts)
				sessions2objectID2fact.get(sessionID).put(inLinkID, newFact);

				logger
						.debug("Modified Link fact (deleted node -> changed targets): "
								+ newFact);

				// add affected link sources (to update their neighborhood)
				Set<EUEObjectID> inLinkSources = sessions2linkID2sourceIDs.get(
						sessionID).get(inLinkID);
				affectedInLinkSources.addAll(inLinkSources);
			}

			// update neighborhoods (i.e., remove node as neighbor, in-neighbor,
			// out-neighbor)
			updateNeighbors(sessionID, affectedInLinkSources,
					affectedOutLinkTargets, jessEngine);

			// update tallies
			updateTally(sessionID, COUNTER_NODE_ALL, COUNTER_USER_ALL, -1);
			String typeSpecificTally = COUNTER_NODE_PREFIX + node.getType();
			updateTally(sessionID, typeSpecificTally, COUNTER_USER_ALL, -1);

		} catch (Exception e) {
			logger.error("deleteNode(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	/**
	 * Deletes a (child) {@link Node}. This includes:
	 * <ul>
	 * <li>retract {@link Node} from Jess</li>
	 * <li>update internal indices</li>
	 * </ul>
	 * 
	 * @param node
	 * @param deleteEvent
	 * @param jessEngine
	 */
	private void deleteChildNode(Node node, UserDeleteObjectEvent deleteEvent,
			Rete jessEngine) {
		try {
			SessionID sessionID = deleteEvent.getSessionID();
			logger.debug("Deleting (child) node in session '" + sessionID
					+ "': " + node);

			EUEObjectID nodeID = node.getID();
			// remove node itself
			Fact nodeFact = sessions2objectID2fact.get(sessionID)
					.remove(nodeID);
			jessEngine.retract(nodeFact);
		} catch (Exception e) {
			logger.error("deleteChildNode(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	/**
	 * Deletes a {@link Link}. This includes:
	 * <ul>
	 * <li>retract {@link Link} from Jess</li>
	 * <li>update internal indices</li>
	 * <li>update {@link Node} neighborhood for connected {@link Node}s)</li>
	 * <li>update counters</li>
	 * </ul>
	 * 
	 * @param link
	 * @param deleteEvent
	 * @param jessEngine
	 */
	private void deleteLink(Link link, UserDeleteObjectEvent deleteEvent,
			Rete jessEngine) {
		try {
			SessionID sessionID = deleteEvent.getSessionID();
			logger.debug("Deleting link in session '" + sessionID + "': "
					+ link);

			EUEObjectID linkID = link.getID();

			// remove link itself (internal index + Jess)
			Fact linkFact = sessions2objectID2fact.get(sessionID)
					.remove(linkID);
			jessEngine.retract(linkFact);

			// remove link sources (internal indices)
			Set<EUEObjectID> linkSources = sessions2linkID2sourceIDs.get(
					sessionID).remove(linkID);
			for (EUEObjectID sourceID : linkSources) {
				Set<EUEObjectID> sourceOutLinks = sessions2nodeID2outLinkIDs
						.get(sessionID).get(sourceID);
				if (sourceOutLinks != null) {
					sourceOutLinks.remove(linkID);
				}
			}

			// remove link targets (internal indices)
			Set<EUEObjectID> linkTargets = sessions2linkID2targetIDs.get(
					sessionID).remove(linkID);
			for (EUEObjectID targetID : linkTargets) {
				Set<EUEObjectID> targetInLinks = sessions2nodeID2inLinkIDs.get(
						sessionID).get(targetID);
				if (targetInLinks != null) {
					targetInLinks.remove(linkID);
				}
			}

			// update neighborhoods (i.e., remove node as neighbor, in-neighbor,
			// out-neighbor)
			updateNeighbors(sessionID, linkSources, linkTargets, jessEngine);

			// update tallies
			updateTally(sessionID, COUNTER_LINK_ALL, COUNTER_USER_ALL, -1);
			String typeSpecificTally = COUNTER_LINK_PREFIX + link.getType();
			updateTally(sessionID, typeSpecificTally, COUNTER_USER_ALL, -1);

		} catch (Exception e) {
			logger.error("deleteLink(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
	}

	/**
	 * Assuming the the internal indices have already been updated (
	 * {@link #sessions2nodeID2inLinkIDs}, {@link #sessions2nodeID2outLinkIDs},
	 * {@link #sessions2linkID2sourceIDs}, {@link #sessions2linkID2targetIDs}),
	 * this method updates the node neighborhoods in Jess.
	 * 
	 * @param sessionID
	 * @param changedSources
	 *            objects that take the role of a source in a relation whose
	 *            targets changed (i.e., target has been added or removed). The
	 *            out-neighbors will be updated.
	 * @param changedTargets
	 *            objects that take the role of a target in a relation whose
	 *            sources changed (i.e., source has been added or removed). The
	 *            in-neighbors will be updated.
	 * @param jessEngine
	 */
	private void updateNeighbors(SessionID sessionID,
			Set<EUEObjectID> changedSources, Set<EUEObjectID> changedTargets,
			Rete jessEngine) {
		try {
			if (changedSources.isEmpty() && changedTargets.isEmpty()) {
				// nothing to do
				return;
			}
			Set<EUEObjectID> changedObjects = new HashSet<EUEObjectID>();
			changedObjects.addAll(changedSources);
			changedObjects.addAll(changedTargets);

			for (EUEObjectID objectID : changedObjects) {
				List<String> changedPropNames = new Vector<String>();
				List<Value> changedPropValues = new Vector<Value>();

				// Collect new in-neighbors
				Set<EUEObjectID> newInNeighbors = new TreeSet<EUEObjectID>(
						idComparator);
				Set<EUEObjectID> inLinks = sessions2nodeID2inLinkIDs.get(
						sessionID).get(objectID);
				for (EUEObjectID inLinkID : inLinks) {
					Set<EUEObjectID> newInNeighborsOneLink = sessions2linkID2sourceIDs
							.get(sessionID).get(inLinkID);
					newInNeighbors.addAll(newInNeighborsOneLink);
				}

				// Collect new out-neighbors
				Set<EUEObjectID> newOutNeighbors = new TreeSet<EUEObjectID>(
						idComparator);
				Set<EUEObjectID> outLinks = sessions2nodeID2outLinkIDs.get(
						sessionID).get(objectID);
				for (EUEObjectID outLinkID : outLinks) {
					Set<EUEObjectID> newOutNeighborsOneLink = sessions2linkID2targetIDs
							.get(sessionID).get(outLinkID);
					newOutNeighbors.addAll(newOutNeighborsOneLink);
				}

				// check whether inNeighbors have changed (i.e.,
				// object is target of a changed relation)
				if (changedTargets.contains(objectID)) {
					changedPropNames.add("in_neighbors");
					// Construct new value vector
					ValueVector newInNeighborVector = new ValueVector();
					for (EUEObjectID inNeighborID : newInNeighbors) {
						Value v = new Value(inNeighborID.getIdAsString(),
								RU.STRING);
						newInNeighborVector.add(v);
					}
					changedPropValues.add(new Value(newInNeighborVector,
							RU.LIST));
				}

				// check whether outNeighbors have changed (i.e.,
				// object is source of a changed relation)
				if (changedSources.contains(objectID)) {
					changedPropNames.add("out_neighbors");
					// Construct new value vector
					ValueVector newOutNeighborVector = new ValueVector();
					for (EUEObjectID outNeighborID : newOutNeighbors) {
						Value v = new Value(outNeighborID.getIdAsString(),
								RU.STRING);
						newOutNeighborVector.add(v);
					}
					changedPropValues.add(new Value(newOutNeighborVector,
							RU.LIST));
				}

				// update neighbors (we know already that something changed wrt
				// neighborhood)
				changedPropNames.add("neighbors");

				Set<EUEObjectID> newNeighbors = new TreeSet<EUEObjectID>(
						idComparator);
				newNeighbors.addAll(newInNeighbors);
				newNeighbors.addAll(newOutNeighbors);

				// Construct new value vector
				ValueVector newNeighborVector = new ValueVector();
				for (EUEObjectID neighborID : newNeighbors) {
					Value v = new Value(neighborID.getIdAsString(), RU.STRING);
					newNeighborVector.add(v);
				}
				changedPropValues.add(new Value(newNeighborVector, RU.LIST));

				// Update Jess working memory
				Fact oldFact = sessions2objectID2fact.get(sessionID).get(
						objectID);

				Fact newFact = jessEngine.modify(oldFact, changedPropNames
						.toArray(new String[changedPropNames.size()]),
						changedPropValues.toArray(new Value[changedPropValues
								.size()]));

				// Update internal index (facts)
				sessions2objectID2fact.get(sessionID).put(objectID, newFact);

			}
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}

	/**
	 * Updates internal indices as well as the Jess working memory.
	 * 
	 * @param sessionID
	 * @param tallyType
	 * @param userID
	 * @param change
	 */
	private void updateTally(SessionID sessionID, String tallyType,
			String userID, int change) {
		try {
			// update internal index
			StringPair tallyID = new StringPair(tallyType, userID);
			int oldCount = sessions2counterTargetUserPair2Count.get(sessionID)
					.get(tallyID);
			int newCount = oldCount + change;
			sessions2counterTargetUserPair2Count.get(sessionID).put(tallyID,
					newCount);

			// update Jess working memory
			Rete jessEngine = sessions2JessEngine.get(sessionID);
			Fact oldFact = sessions2counterTargetUserPair2Fact.get(sessionID)
					.get(tallyID);
			Fact newFact = jessEngine.modify(oldFact, "value", new Value(
					newCount, RU.INTEGER));

			// Update internal index (facts)
			sessions2counterTargetUserPair2Fact.get(sessionID).put(tallyID,
					newFact);

		} catch (Exception e) {
			logger.error(
					"updateTally, " + e.getClass() + ": " + e.getMessage(), e);
		}
	}

	public Iterator<Fact> getWorkingMemoryFacts(SessionID sessionID) {
		if (sessions2JessEngine.containsKey(sessionID)) {
			return sessions2JessEngine.get(sessionID).listFacts();
		}
		logger.warn("getWorkingMemoryFacts(): session '" + sessionID
				+ "' not available in Jess.");
		return new Vector<Fact>().iterator();
	}

	public Iterator<HasLHS> getWorkingMemoryRules(SessionID sessionID) {
		if (sessions2JessEngine.containsKey(sessionID)) {
			return sessions2JessEngine.get(sessionID).listDefrules();
		}
		logger.warn("getWorkingMemoryRules(): session '" + sessionID
				+ "' not available in Jess.");
		return new Vector<HasLHS>().iterator();
	}

	@Override
	public void addAnalysisResults(AnalysisResultEvent analysisResultEvent) {
		/**
		 * TODO - Add analysis results as Jess facts
		 */
	}

	@Override
	public void clearAnalysisResults(SessionID sessionID, AnalysisType type) {
		/**
		 * TODO - Remove all Jess facts that correspond to given AnalysisType in
		 * given Session
		 */
	}

	@Override
	public Map<AnalysisType, List<AnalysisResult>> getAnalysisResults(
			SessionID sessionID, AnalysisType analysisType) {
		Map<AnalysisType, List<AnalysisResult>> type2Results = new HashMap<AnalysisType, List<AnalysisResult>>();
		if (analysisType instanceof CompoundActionType) {
			for (ActionType basicType : ((CompoundActionType) analysisType)
					.getSubActionTypes()) {
				List<AnalysisResult> results = getResultsBasicType(sessionID,
						basicType);
				if (!results.isEmpty()) {
					type2Results.put(basicType, results);
				}
			}
			return type2Results;
		} else {
			type2Results.put(analysisType, getResultsBasicType(sessionID,
					analysisType));
			return type2Results;
		}
	}

	private List<AnalysisResult> getResultsBasicType(SessionID sessionID,
			AnalysisType analysisType) {
		List<AnalysisResult> results = new Vector<AnalysisResult>();
		try {
			Rete jessEngine = sessions2JessEngine.get(sessionID);
			Context jessGlobalContext = jessEngine.getGlobalContext();
			String agentID = analysisType.getAgentID();
			String typeID = analysisType.getTypeID();
			ValueVector inputArgs = new ValueVector();
			inputArgs.add(new Value(agentID, RU.STRING));
			inputArgs.add(new Value(typeID, RU.STRING));

			QueryResult resultsJess = jessEngine.runQueryStar("get-result",
					inputArgs);

			while (resultsJess.next()) {

				// setting the entity
				AnalyzableEntity entity = new AnalyzableEntity();
				Value entityComponents = resultsJess.get("entity_ids");

				ValueVector entityComponentsAsJessVector = entityComponents
						.listValue(jessGlobalContext);
				for (int i = 0; i < entityComponentsAsJessVector.size(); ++i) {
					Value componentIDJess = entityComponentsAsJessVector.get(i);
					// check for 'nil' values (will be filtered out; nil is of type "RU.SYMBOL")
					if (componentIDJess.type() == RU.STRING) {
						String componentIDAsString = componentIDJess
								.stringValue(jessGlobalContext);
						entity.addEntityComponent(JessIDMapper
								.jess2EUEID(componentIDAsString));
					}
				}

				// setting the actual result
				AnalysisResult aResult = null;
				if (BinaryResult.class.equals(analysisType.getResultType())) {
					boolean value = resultsJess.getBoolean("value");
					aResult = new BinaryResult(analysisType, entity, value);
					results.add(aResult);
				} else if (NumericalResult.class.equals(analysisType
						.getResultType())) {
					double value = resultsJess.getDouble("value");
					aResult = new NumericalResult(analysisType, entity, value);
					results.add(aResult);
				} else if (NominalResult.class.equals(analysisType
						.getResultType())) {
					String value = resultsJess.getString("value");
					aResult = new NominalResult(analysisType, entity, value);
					results.add(aResult);
				} else {
					logger.warn("Unknown (or unset) result type for "
							+ analysisType.toString());
				}

				// setting result property / value pairs
				if (aResult != null) {

					// prop names
					List<String> propNameList = new Vector<String>();
					Value propNamesJess = resultsJess.get("prop_names");

					ValueVector propNamesAsJessVector = propNamesJess
							.listValue(jessGlobalContext);
					for (int i = 0; i < propNamesAsJessVector.size(); ++i) {
						Value propNameJess = propNamesAsJessVector.get(i);
						// check for 'nil' values (will be filtered out; nil is of type "RU.SYMBOL")
						if (propNameJess.type() == RU.STRING) {
							String propNameAsString = propNameJess
									.stringValue(jessGlobalContext);
							propNameList.add(propNameAsString);
						}
					}

					// prop values
					List<String> propValuesList = new Vector<String>();
					Value propValuesJess = resultsJess.get("prop_values");

					ValueVector propValuesAsJessVector = propValuesJess
							.listValue(jessGlobalContext);
					for (int i = 0; i < propValuesAsJessVector.size(); ++i) {
						Value propValueJess = propValuesAsJessVector.get(i);
						// check for 'nil' values (will be filtered out; nil is of type "RU.SYMBOL")
						if (propValueJess.type() != RU.SYMBOL) {
							String propValueAsString = propValueJess
									.stringValue(jessGlobalContext);
							propValuesList.add(propValueAsString);
						}
					}

					if (propNameList.size() == propValuesList.size()) {
						Iterator<String> valueIter = propValuesList.iterator();
						for (String propName : propNameList) {
							String propValue = valueIter.next();
							aResult.addProperty(propName, propValue);
						}

					} else {
						logger
								.error("Number of result properties differs from number of result values.");
					}

				}
			}

		} catch (Exception e) {
			logger.error("getResultsBasicType(), " + e.getClass() + ": "
					+ e.getMessage(), e);
		}
		return results;
	}

	@Override
	public List<IAnalysisAgent> getModelUpdatingAgents() {
		return modelUpdatingAgents;
	}

	public boolean doesSessionExist(SessionID sessionID) {
		return sessions2JessEngine.containsKey(sessionID);
	}

	private class StringPair {

		private String[] data;

		public StringPair(String first, String second) {
			data = new String[] { first, second };
		}

		public String getFirst() {
			return data[0];
		}

		public String getSecond() {
			return data[1];
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + Arrays.hashCode(data);
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			StringPair other = (StringPair) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (!Arrays.equals(data, other.data))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "[" + data[0] + ", " + data[1] + "]";
		}

		private JessModelController getOuterType() {
			return JessModelController.this;
		}

	}

}
