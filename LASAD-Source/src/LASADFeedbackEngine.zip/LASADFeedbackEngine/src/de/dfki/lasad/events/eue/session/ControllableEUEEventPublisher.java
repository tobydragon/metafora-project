package de.dfki.lasad.events.eue.session;

import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.EUEEventPublisher;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * Abstraction of an {@link Event} source. Allows pull access to {@link Event}s
 * (via interface {@link Iterable<EUEEvent>}, and push access (via interface
 * {@link EUEEventPublisher} and control methods {@link #startPublishingEUESessionEvents()} and
 * {@link #isFinishedPublishingEUEEvents()}).
 * 
 * @author Oliver Scheuer
 * 
 */
public interface ControllableEUEEventPublisher extends EUEEventPublisher,
		Iterable<EUEEvent> {

	public void initSessionInWorldModel();
	
	public void startPublishingEUESessionEvents();

	public boolean isFinishedPublishingEUEEvents();

	// data has to be associated with a session
	public SessionID getSessionID();
	
	// data has to be associated with an ontology
	public EUEOntology getOntology();
}
