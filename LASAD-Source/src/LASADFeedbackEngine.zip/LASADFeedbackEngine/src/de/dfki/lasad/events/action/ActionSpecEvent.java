package de.dfki.lasad.events.action;

import java.util.HashSet;
import java.util.Set;

import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.models.action.ActionSpec;
import de.dfki.lasad.models.eue.SessionID;

public class ActionSpecEvent extends SessionEvent {

	private Set<ActionSpec> actionSpecs = new HashSet<ActionSpec>();

	public ActionSpecEvent(Set<ActionSpec> actionSpecs, SessionID sessionID,
			String srcCompId) {
		super(sessionID, srcCompId);
		this.actionSpecs = actionSpecs;
	}

	public ActionSpecEvent(ActionSpec actionSpec, SessionID sessionID,
			String srcCompId) {
		super(sessionID, srcCompId);
		actionSpecs = new HashSet<ActionSpec>();
		actionSpecs.add(actionSpec);
	}

	public ActionSpecEvent(SessionID sessionID, String srcCompId) {
		super(sessionID, srcCompId);
		actionSpecs = new HashSet<ActionSpec>();
	}

	@Override
	public String toString() {
		return super.toString() + ", actionSpec=" + actionSpecs.toString();
	}

	public Set<ActionSpec> getActionSpecs() {
		return actionSpecs;
	}

	public void addActionSpec(ActionSpec aSpec) {
		actionSpecs.add(aSpec);
	}
}
