package de.dfki.lasad.modules.dataservice.lasad.translators;

import java.util.SortedSet;

public class MapDetails {
	//String templateXML = null;
	String mapID = null;
	String mapName = null;
	String templateName = null;
	SortedSet<String> transcriptIDs;
	
	/**
	 * 
	 */
	public MapDetails() {
		super();
	}

//	public String getTemplateXML() {
//		return templateXML;
//	}
//
//	public void setTemplateXML(String templateXML) {
//		this.templateXML = templateXML;
//	}

	public String getMapID() {
		return mapID;
	}

	public void setMapID(String mapID) {
		this.mapID = mapID;
	}

	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public SortedSet<String> getTranscriptIDs() {
		return transcriptIDs;
	}

	public void setTranscriptIDs(SortedSet<String> transcriptIDs) {
		this.transcriptIDs = transcriptIDs;
	}
	
}
