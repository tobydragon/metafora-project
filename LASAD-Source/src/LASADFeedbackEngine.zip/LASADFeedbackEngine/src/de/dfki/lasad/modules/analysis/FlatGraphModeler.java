package de.dfki.lasad.modules.analysis;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.events.eue.session.objectaction.UserCreateObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserDeleteObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;
import de.dfki.lasad.models.eue.objects.ActionHistory;
import de.dfki.lasad.models.eue.objects.BasicPropertyFactory;
import de.dfki.lasad.models.eue.objects.EUEObject;
import de.dfki.lasad.models.eue.objects.EUEObjectID;
import de.dfki.lasad.models.eue.objects.HistoryAwareEUEObject;
import de.dfki.lasad.models.eue.objects.ListProperty;
import de.dfki.lasad.models.eue.objects.ObjectProperty;
import de.dfki.lasad.models.eue.objects.SimpleProperty;
import de.dfki.lasad.models.eue.objects.ActionHistory.Action;
import de.dfki.lasad.models.eue.objects.ActionHistory.ActionType;
import de.dfki.lasad.models.eue.objects.graph.Link;
import de.dfki.lasad.models.eue.objects.graph.Node;

/**
 * Provides a "flattened" representation of a graph. That is, the originally
 * hierarchical structure of nodes and links is translated to a flat structure.
 * Important information that is contained in child elements is propagated
 * upwards in the hierarchy and represented as property-value pairs within the
 * top-level elements. How this is done is governed by a
 * {@link SimplePropertyMappingsConfiguration}.<br/>
 * 
 * Note: This class is not thread-safe!
 * 
 * 
 * @author Oliver Scheuer
 * 
 */
public class FlatGraphModeler extends AbstractGraphModeler {

	private Log logger = LogFactory.getLog(FlatGraphModeler.class);

	protected SimplePropertyMappingsConfiguration mappingConfiguration;

	private String newType = null;
	private HashMap<String, List<String>> propValueAccumulator = new HashMap<String, List<String>>();

	// process information tracking
	private long currentFirstModificationTS = -1;
	private long currentLastModificationTS = -1;

	private Map<EUEObjectID, Node> id2flattenedNode = new HashMap<EUEObjectID, Node>();
	private Map<EUEObjectID, Link> id2flattenedLink = new HashMap<EUEObjectID, Link>();

	private int numRelevantChangesSinceLastUpdate = 0;
	private int numCreateDeleteActionsSinceLastUpdate = 0;

	public FlatGraphModeler(SimplePropertyMappingsConfiguration configuration) {
		super();
		this.mappingConfiguration = configuration;
	}

	@Override
	public void executeEvent(UserObjectActionEvent objectEvent) {
		super.executeEvent(objectEvent);
		updateNumberofRelevantChanges(objectEvent);
	}

	public Node getNode(EUEObjectID nodeID) {
		Node node = id2flattenedNode.get(nodeID);
		return node;
	}

	public Link getLink(EUEObjectID linkID) {
		Link link = id2flattenedLink.get(linkID);
		return link;
	}

	public Collection<Node> getNodes() {
		return id2flattenedNode.values();
	}

	public Collection<Link> getLinks() {
		return id2flattenedLink.values();
	}

	// Method has to be called to get the most recent representation
	public void updateFlatRepresentations() {
		logger.debug("Num relevant changes since last update: "
				+ numRelevantChangesSinceLastUpdate + " ...");
		if (numRelevantChangesSinceLastUpdate == 0) {
			logger.debug("... no model update needed.");
			return;
		}
		logger.debug("... start updating model.");
		id2flattenedNode.clear();
		id2flattenedLink.clear();
		for (HistoryAwareEUEObject node : nodes) {
			accumulateStateProperties(node);
			accumulateProcessProperties(node);
			Node hierarchicalNode = (Node) node.getObject();
			Node flatNode = generateFlatNode(hierarchicalNode.getID());
			clearProperties();
			id2flattenedNode.put(hierarchicalNode.getID(), flatNode);
			logger.debug("Node added to flat graph representation: "
					+ flatNode);
		}

		for (HistoryAwareEUEObject link : links) {
			accumulateStateProperties(link);
			accumulateProcessProperties(link);
			Link hierarchicalLink = (Link) link.getObject();
			Link flatLink = generateFlatLink(hierarchicalLink.getID(),
					hierarchicalLink.getSources(), hierarchicalLink
							.getTargets());
			clearProperties();
			id2flattenedLink.put(hierarchicalLink.getID(), flatLink);
			logger.debug("Link added to flat graph representation: "
					+ flatLink);
		}

		numRelevantChangesSinceLastUpdate = 0;
		numCreateDeleteActionsSinceLastUpdate = 0;
	}

	public int getNumRelevantChangesSinceLastUpdate() {
		return numRelevantChangesSinceLastUpdate;
	}

	public int getNumCreateDeleteActionsSinceLastUpdate() {
		return numCreateDeleteActionsSinceLastUpdate;
	}

	private void accumulateStateProperties(
			HistoryAwareEUEObject historyAwareObject) {
		EUEObject hierarchicalObject = historyAwareObject.getObject();

		String oldType = hierarchicalObject.getType();

		// translate and keep type for root elements
		if (hierarchicalObject.isTopLevelObject()) {
			newType = mappingConfiguration.getNewElemType(oldType);
		}
		for (String oldPropName : hierarchicalObject.getProps().keySet()) {

			// translate and keep property name
			ObjectProperty oldProp = hierarchicalObject.getProps().get(
					oldPropName);

			String newPropName = mappingConfiguration.getNewPropName(oldType,
					oldPropName);

			// retrieve and keep property type (simple vs list)
			List<String> oldPropValueList = new Vector<String>();
			if (oldProp instanceof SimpleProperty) {
				SimpleProperty oldPropSimple = (SimpleProperty) oldProp;
				oldPropValueList.add(oldPropSimple.getValueAsString());
			} else {
				// assume: ListProperty
				ListProperty oldPropList = (ListProperty) oldProp;
				oldPropValueList.addAll(oldPropList.getValues());

			}

			// translate and keep property value
			List<String> newPropValueList = new Vector<String>();
			for (String oldValue : oldPropValueList) {
				String newPropValue = mappingConfiguration.getNewValName(oldType,
						oldPropName, oldValue);
				newPropValueList.add(newPropValue);
			}

			List<String> accumulatedPropValueList = propValueAccumulator
					.get(newPropName);

			if (accumulatedPropValueList == null) {
				// first prop with this name
				accumulatedPropValueList = new Vector<String>();
				propValueAccumulator.put(newPropName, accumulatedPropValueList);
			}
			accumulatedPropValueList.addAll(newPropValueList);

		}
		// recursion (depth-first)
		List<EUEObjectID> childrenIDs = ids2Children.get(hierarchicalObject
				.getID());
		for (EUEObjectID childID : childrenIDs) {
			HistoryAwareEUEObject child = ids2Objects.get(childID);
			accumulateStateProperties(child);
		}
	}

	private void accumulateProcessProperties(
			HistoryAwareEUEObject historyAwareObject) {
		ActionHistory history = historyAwareObject.getActionHistory();

		Action createAction = null;
		Action firstModifyAction = null;
		Action lastModifyAction = null;

		for (Action action : history.getActionHistory()) {
			if (ActionType.CREATE.equals(action.actionType)) {
				createAction = action;
				firstModifyAction = action;
				lastModifyAction = action;
				break;
			}
		}

		for (Action action : history.getActionHistory()) {
			if (ActionType.MODIFY.equals(action.actionType)) {
				firstModifyAction = action;
				break;
			}
		}

		for (Action action : history.getActionHistory()) {
			if (ActionType.MODIFY.equals(action.actionType)) {
				lastModifyAction = action;
			}
		}

		EUEObject eueObject = historyAwareObject.getObject();
		String oldObjectType = eueObject.getType();

		// creator and creationTS are always taken from the root object
		if (eueObject.isTopLevelObject()) {
			updatePropValueAccumulator(oldObjectType,
					BasicPropertyFactory.CREATION_TS, String
							.valueOf(createAction.ts));

			updatePropValueAccumulator(oldObjectType,
					BasicPropertyFactory.CREATOR,
					createAction.manipulatorUserID.getIdAsString());
		}

		if (currentFirstModificationTS == -1
				|| currentFirstModificationTS > firstModifyAction.ts) {

			currentFirstModificationTS = firstModifyAction.ts;

			updatePropValueAccumulator(oldObjectType,
					BasicPropertyFactory.FIRST_MODIFICATION_TS, String
							.valueOf(firstModifyAction.ts));

			updatePropValueAccumulator(oldObjectType,
					BasicPropertyFactory.FIRST_MODIFIER,
					firstModifyAction.manipulatorUserID.getIdAsString());
		}

		if (currentLastModificationTS == -1
				|| currentLastModificationTS < lastModifyAction.ts) {

			currentLastModificationTS = lastModifyAction.ts;

			updatePropValueAccumulator(oldObjectType,
					BasicPropertyFactory.LAST_MODIFIER,
					lastModifyAction.manipulatorUserID.getIdAsString());

			updatePropValueAccumulator(oldObjectType,
					BasicPropertyFactory.LAST_MODIFICATION_TS, String
							.valueOf(lastModifyAction.ts));
		}

		// recursion (depth-first)
		List<EUEObjectID> childrenIDs = ids2Children.get(eueObject.getID());
		for (EUEObjectID childID : childrenIDs) {
			HistoryAwareEUEObject child = ids2Objects.get(childID);
			accumulateProcessProperties(child);
		}
	}

	private void updatePropValueAccumulator(String oldObjectType,
			String oldPropName, String value) {
		String newPropName = mappingConfiguration.getNewPropName(oldObjectType,
				oldPropName);
		propValueAccumulator.put(newPropName, createSingleValueList(value));
	}

	private List<String> createSingleValueList(String value) {
		List<String> valueList = new Vector<String>();
		valueList.add(value);
		return valueList;
	}

	private void clearProperties() {
		newType = null;
		propValueAccumulator.clear();
		currentFirstModificationTS = -1;
		currentLastModificationTS = -1;
	}

	private Node generateFlatNode(EUEObjectID id) {
		Node node = new Node();
		node.setID(id);
		node.setType(newType);

		for (String propName : propValueAccumulator.keySet()) {
			List<String> valueList = propValueAccumulator.get(propName);
			ObjectProperty prop = generateProperty(newType, propName, valueList);

			node.addProperty(prop);
		}
		return node;
	}

	private Link generateFlatLink(EUEObjectID id, List<EUEObjectID> sources,
			List<EUEObjectID> targets) {
		Link link = new Link();
		link.setID(id);
		link.setType(newType);

		for (EUEObjectID source : sources) {
			link.addSource(source);
		}

		for (EUEObjectID target : targets) {
			link.addTarget(target);
		}

		for (String propName : propValueAccumulator.keySet()) {
			List<String> valueList = propValueAccumulator.get(propName);
			ObjectProperty prop = generateProperty(newType, propName, valueList);
			link.addProperty(prop);
		}

		return link;
	}

	private ObjectProperty generateProperty(String elemType, String propName,
			List<String> valueList) {
		boolean isListType = mappingConfiguration.isPropOfListType(elemType, propName);
		if (isListType) {
			return new ListProperty(propName, valueList);
		} else {
			if (valueList.size() > 1) {
				logger.warn("Multiple values available for [" + elemType + ", "
						+ propName + "]: " + valueList
						+ ". Use only the first one.");
			}
			return new SimpleProperty(propName, valueList.get(0));

		}
	}

	private void updateNumberofRelevantChanges(UserObjectActionEvent objectEvent) {
		if (objectEvent instanceof UserCreateObjectEvent) {
			++numRelevantChangesSinceLastUpdate;
			++numCreateDeleteActionsSinceLastUpdate;
			return;
		}

		if (objectEvent instanceof UserDeleteObjectEvent) {
			++numRelevantChangesSinceLastUpdate;
			++numCreateDeleteActionsSinceLastUpdate;
			return;
		}

		// assume modify action, check whether relevant properties have been
		// changed
		for (EUEObject object : objectEvent.getEueObjectList()) {
			String objectType = object.getType();
			for (String propName : object.getProps().keySet()) {
				if (mappingConfiguration.isPropRelevant(objectType, propName)) {
					++numRelevantChangesSinceLastUpdate;
					return;
				}
			}
		}
		// else: irrelevant action
	}

}
