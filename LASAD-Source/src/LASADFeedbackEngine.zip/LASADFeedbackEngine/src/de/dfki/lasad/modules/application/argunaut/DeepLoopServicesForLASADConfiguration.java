package de.dfki.lasad.modules.application.argunaut;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.application.AbstractAppConfiguration;
import de.dfki.lasad.core.dataservice.DataServiceDescription;
import de.dfki.lasad.core.worldmodel.JessModelControllerDescription;
import de.dfki.lasad.core.worldmodel.ModelControllerConfiguration;
import de.dfki.lasad.modules.analysis.deeploop.DeepLoopAnalysisAgentConfiguration;
import de.dfki.lasad.modules.analysis.deeploop.DeepLoopAnalysisAgentDescription;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIConfiguration;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIDescription;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class DeepLoopServicesForLASADConfiguration extends
		AbstractAppConfiguration {

	private LASADDataServiceRMIDescription dataServiceDescription;

	private List<AnalysisAgentDescription> analysisAgentDescriptions = new Vector<AnalysisAgentDescription>();
	private List<ActionAgentDescription> actionAgentDescriptions = new Vector<ActionAgentDescription>();

	public DeepLoopServicesForLASADConfiguration() {
		super();
		// create {@link LASADDataServiceDescription}
		LASADDataServiceRMIConfiguration dataServiceConf = LASADDataServiceRMIConfiguration
				.readDefaultConfig();
		dataServiceDescription = new LASADDataServiceRMIDescription(
				dataServiceConf);

		// create {@link DeepLoopAnalysisAgentDescription}
		DeepLoopAnalysisAgentConfiguration deeploopConf = new DeepLoopAnalysisAgentConfiguration();
		Set<String> deepLoopSupportedOntologies = new HashSet<String>();
		deepLoopSupportedOntologies.add("Argunaut");
		deeploopConf.setSupportedOntologies(deepLoopSupportedOntologies);
		DeepLoopPropertyMappingsConfiguration propMappingConf = new DeepLoopPropertyMappingsConfiguration();
		deeploopConf.setMappingConfiguration(propMappingConf);
		DeepLoopAnalysisAgentDescription deeploopDescription = new DeepLoopAnalysisAgentDescription(
				deeploopConf);
		analysisAgentDescriptions.add(deeploopDescription);

		// create {@link JessModelControllerDescription}, disable support for
		// any ontology
		Set<String> worldModelSupportedOntologies = new HashSet<String>();
		worldModelSupportedOntologies.add("DISABLE");
		this.modelControllerDescr = new JessModelControllerDescription(
				new ModelControllerConfiguration(worldModelSupportedOntologies));
	}

	@Override
	public DataServiceDescription getDataServiceDescription() {
		return dataServiceDescription;
	}

	@Override
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions() {
		return analysisAgentDescriptions;
	}

	@Override
	public List<ActionAgentDescription> getActionAgentDescriptions() {
		return actionAgentDescriptions;
	}
}
