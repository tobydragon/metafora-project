package de.dfki.lasad.core.worldmodel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class LARGOOntologyInfo extends AbstractGraphOntologyInfo {

	private static EUEOntology ontology;

	private static List<String> supportedNodeTypes = new Vector<String>();
	static {
		supportedNodeTypes.add("fact");
		supportedNodeTypes.add("hypothetical");
		supportedNodeTypes.add("test");
	}

	private static List<String> supportedNodeProperties = new Vector<String>();
	static {
		supportedNodeProperties.add("POS-X");
		supportedNodeProperties.add("POS-Y");
	}

	private static List<String> supportedLinkTypes = new Vector<String>();
	static {
		supportedLinkTypes.add("modified");
		supportedLinkTypes.add("distinguished");
		supportedLinkTypes.add("analogized");
		supportedLinkTypes.add("leads");
		supportedLinkTypes.add("general");
	}

	private static List<String> supportedSubElementDataTypes = new Vector<String>();
	static {
		supportedSubElementDataTypes.add("transcript-link");
		supportedSubElementDataTypes.add("rating");
		supportedSubElementDataTypes.add("awareness");
		supportedSubElementDataTypes.add("text");
	}

	private static Map<String, String> subElementID2DataType = new HashMap<String, String>();
	static {
		subElementID2DataType.put("if", "text");
		subElementID2DataType.put("and", "text");
		subElementID2DataType.put("even", "text");
		subElementID2DataType.put("then", "text");
		subElementID2DataType.put("except", "text");
		subElementID2DataType.put("text", "text");
		subElementID2DataType.put("outcome", "text");
	}

	private static Map<String, List<String>> subElementDataType2Properties = new HashMap<String, List<String>>();
	static {
		List<String> transcriptLinkProps = new Vector<String>();
		subElementDataType2Properties.put("transcript-link",
				transcriptLinkProps);
		transcriptLinkProps.add("STARTROW");
		transcriptLinkProps.add("STARTPOINT");
		transcriptLinkProps.add("ENDROW");
		transcriptLinkProps.add("ENDPOINT");

		List<String> ratingProps = new Vector<String>();
		subElementDataType2Properties.put("rating", ratingProps);
		ratingProps.add("SCORE");

		List<String> awarenessProps = new Vector<String>();
		subElementDataType2Properties.put("awareness", awarenessProps);
		awarenessProps.add("TEXT");

		List<String> textProps = new Vector<String>();
		subElementDataType2Properties.put("text", textProps);
		textProps.add("TEXT");
	}

	@Override
	public List<String> getLinkTypes() {
		return supportedLinkTypes;
	}

	@Override
	public List<String> getNodeTypes() {
		return supportedNodeTypes;
	}

	@Override
	public EUEOntology getOntology() {
		return ontology;
	}

	@Override
	public boolean isNodePropSupported(String propName) {
		return supportedNodeProperties.contains(propName);
	}

	@Override
	public boolean isSubElementPropSupported(String subElementDataType,
			String propName) {
		return subElementDataType2Properties.containsKey(subElementDataType)
				&& subElementDataType2Properties.get(subElementDataType)
						.contains(propName);
	}

	@Override
	public String getOntologyDefinitionsLocalFilename() {
		return "largo.clp.txt";
	}

}
