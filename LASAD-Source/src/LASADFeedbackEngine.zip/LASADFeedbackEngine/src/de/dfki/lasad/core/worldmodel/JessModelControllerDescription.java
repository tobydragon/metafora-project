package de.dfki.lasad.core.worldmodel;

import de.dfki.lasad.core.PluggableComponentDescription;

public class JessModelControllerDescription extends
		PluggableComponentDescription {

	private static String className = JessModelController.class.getName();

	public JessModelControllerDescription() {
		this(new ModelControllerConfiguration());
	}

	public JessModelControllerDescription(ModelControllerConfiguration conf) {
		super(className);
		this.configuration = conf;
	}

	@Override
	public ModelControllerConfiguration getConfiguration() {
		return (ModelControllerConfiguration) this.configuration;
	}
}
