package de.dfki.lasad.events.analysis;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.eue.SessionID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class AnalysisResultEvent extends AnalysisEvent {

	private String targetComponentID;
	private Map<AnalysisType, List<AnalysisResult>> type2results = new HashMap<AnalysisType, List<AnalysisResult>>();

	public AnalysisResultEvent(String transactionID, SessionID sessionID,
			String srcCompId, String targetCompId) {
		super(transactionID, sessionID, srcCompId);
		targetComponentID = targetCompId;
	}

	public AnalysisResultEvent(String transactionID, SessionID sessionID,
			String srcCompId, String targetComponentID,
			List<AnalysisResult> results) {
		this(transactionID, sessionID, srcCompId, targetComponentID);
		addResults(results);
	}

	public void addResult(AnalysisResult result) {
		AnalysisType aType = result.getAnalysisType();
		List<AnalysisResult> resultsForType = type2results.get(aType);
		if (resultsForType == null) {
			resultsForType = new Vector<AnalysisResult>();
			type2results.put(aType, resultsForType);
		}
		resultsForType.add(result);
	}

	public void addResults(List<AnalysisResult> results) {
		for (AnalysisResult result : results) {
			addResult(result);
		}
	}

	/**
	 * Can be used to ensure coverage of {@link AnalysisType}s with an empty
	 * result set
	 * 
	 * @param aType
	 */
	public void addCoveredResultType(AnalysisType aType) {
		if (!type2results.containsKey(aType)) {
			List<AnalysisResult> emptyResultList = new Vector<AnalysisResult>();
			type2results.put(aType, emptyResultList);
		}
	}

	public List<AnalysisResult> getResultsAsList() {
		List<AnalysisResult> resultsAsList = new Vector<AnalysisResult>();
		for (AnalysisType aType : type2results.keySet()) {
			resultsAsList.addAll(type2results.get(aType));
		}
		return resultsAsList;
	}

	public Set<AnalysisType> getCoveredAnalysisTypes() {
		return new HashSet<AnalysisType>(type2results.keySet());
	}

	public boolean containsResult(AnalysisType analysisType) {
		for (AnalysisType coveredType : type2results.keySet()) {
			if (analysisType.equals(coveredType)) {
				return true;
			}
		}
		return false;
	}

	public void setTargetComponentID(String targetComponentID) {
		this.targetComponentID = targetComponentID;
	}

	public String getTargetComponentID() {
		return targetComponentID;
	}

	@Override
	public String toString() {
		return super.toString() + ", results=" + type2results
				+ ", targetComponentID=" + targetComponentID;
	}

}
