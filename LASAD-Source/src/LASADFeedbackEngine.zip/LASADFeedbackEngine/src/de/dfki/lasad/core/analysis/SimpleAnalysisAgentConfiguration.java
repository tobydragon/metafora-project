package de.dfki.lasad.core.analysis;

import java.util.Set;

/**
 * An {@link IAnalysisAgentConfiguration} that only provides an
 * {@link SimpleOntologyChecker}.
 * 
 * @author Oliver Scheuer
 * 
 */
public class SimpleAnalysisAgentConfiguration implements
		IAnalysisAgentConfiguration {

	protected OntologyChecker ontologyChecker;

	//this creates an OnotlogyChecker that joins no maps
	public SimpleAnalysisAgentConfiguration() {
		ontologyChecker = new SimpleOntologyChecker();
	}

	public SimpleAnalysisAgentConfiguration(Set<String> supportedOntologyIDs) {
		ontologyChecker = new SimpleOntologyChecker(supportedOntologyIDs);
	}

	@Override
	public OntologyChecker getOntologySupportChecker() {
		return ontologyChecker;
	}

}
