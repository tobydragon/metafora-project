package de.dfki.lasad.core.action;

import java.util.Hashtable;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.PriorityBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.DefaultEventPrioritizer;
import de.dfki.lasad.core.PluggableComponentDescription;
import de.dfki.lasad.core.worldmodel.IModelController;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.UserFeedbackRequestEvent;

/**
 * TODO: Currently, ActionAgents keep only record of FeedbackRequests. Future
 * versions also have to keep record of issued analysis requests (incoming
 * AnalysisResults have to be linked back to the original UserFeedbackRequest or
 * proactive request)
 */
public abstract class AbstractActionAgent implements IActionAgent {

	Log logger = LogFactory.getLog(AbstractActionAgent.class);

	protected ActionAgentDescription description;

	private PriorityBlockingQueue<Event> queue = new PriorityBlockingQueue<Event>();
	private Thread workingThread;

	private IActionController actionController;
	protected IModelController worldModel;

	// transactionID -> UserFeedbackRequestEvent
	private Map<String, UserFeedbackRequestEvent> pendingFeedbackRequests = new Hashtable<String, UserFeedbackRequestEvent>();

	public AbstractActionAgent() {
		startWorkingThread();
	}

	/**
	 * Only for testing purposes!
	 */
	@Override
	public void stopWorkingThread() {
		workingThread.stop();
	}

	private final void startWorkingThread() {
		workingThread = new Thread(new Consumer());
		workingThread.start();
	}

	@Override
	public void doWire(IActionController actionController,
			IModelController worldModel) {
		this.actionController = actionController;
		this.worldModel = worldModel;
	}

	@Override
	public void configure(PluggableComponentDescription description) {
		this.description = (ActionAgentDescription) description;
	}

	@Override
	public ActionAgentDescription getComponentDescription() {
		return description;
	}

	// Callback methods

	@Override
	public abstract void onEUEEvent(EUESessionEvent event);

	@Override
	public abstract void onActionSpecEvent(ActionSpecEvent actionSpecEvent);

	@Override
	public abstract void onAnalysisResultEvent(
			AnalysisResultEvent analysisResultEvent);

	// Internal event processing logic

	public abstract void processUserFeedbackRequestEvent(
			UserFeedbackRequestEvent feedbackRequestEvent);

	public abstract void processEUEEvent(EUESessionEvent eueEvent);

	public abstract void processActionSpecEvent(ActionSpecEvent actionSpecEvent);

	public abstract void processAnalysisResultEvent(
			AnalysisResultEvent analysisResultEvent);

	// Services for sub classes

	protected void addEventToQueue(Event event) {
		DefaultEventPrioritizer.assignPriority(event);
		queue.put(event);
	}

	protected void forwardToActionController(ActionSpecEvent actionSpecEvent) {
		actionController.onActionSpecEvent(actionSpecEvent);
	}

	protected void forwardToActionController(
			AnalysisRequestEvent analyisRequestEvent) {
		actionController.onAnalysisRequestEvent(analyisRequestEvent);
	}

	protected String addPendingRequestAndReturnTransactionId(
			UserFeedbackRequestEvent feedbackRequestEvent) {
		String transactionId;
		do {
			transactionId = UUID.randomUUID().toString();
		} while (!putPendingFeedbackRequest(transactionId, feedbackRequestEvent));
		return transactionId;
	}

	private boolean putPendingFeedbackRequest(String transactionId,
			UserFeedbackRequestEvent event) {
		if (!pendingFeedbackRequests.containsKey(transactionId)) {
			pendingFeedbackRequests.put(transactionId, event);
			return true;
		}
		return false;
	}

	protected UserFeedbackRequestEvent removePendingFeedbackRequest(
			String transactionID) {
		return pendingFeedbackRequests.remove(transactionID);
	}

	class Consumer implements Runnable {

		@Override
		public void run() {

			try {
				do {
					Event event = queue.take();
					if (event instanceof UserFeedbackRequestEvent) {
						processUserFeedbackRequestEvent((UserFeedbackRequestEvent) event);
					} else if (event instanceof EUESessionEvent) {
						processEUEEvent((EUESessionEvent) event);
					} else if (event instanceof ActionSpecEvent) {
						processActionSpecEvent((ActionSpecEvent) event);
					} else if (event instanceof AnalysisResultEvent) {
						processAnalysisResultEvent((AnalysisResultEvent) event);
					} else {
						logger.warn("Unexpected event type received: "
								+ event.toString());
					}

				} while (true);

			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}

		}

	}

}
