package de.dfki.lasad.core.action;

import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.models.analysis.BinaryResult;

/**
 * An {@link ActionType} describes a specific type of analysis that is used to
 * decide actions / feedback.
 * 
 * @author Oliver Scheuer
 * 
 */
public class ActionType extends AnalysisType {

	public ActionType(String agentID, String typeID) {
		// always binary (action condition fulfilled / action-triggering pattern
		// found?)
		super(BinaryResult.class, agentID, typeID);
	}

}
