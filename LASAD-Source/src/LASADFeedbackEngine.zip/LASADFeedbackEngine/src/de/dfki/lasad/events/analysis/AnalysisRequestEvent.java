package de.dfki.lasad.events.analysis;

import de.dfki.lasad.models.analysis.AnalysisQuery;
import de.dfki.lasad.models.eue.SessionID;

public class AnalysisRequestEvent extends AnalysisEvent {

	private AnalysisQuery query;

	public AnalysisRequestEvent(AnalysisQuery query, String transactionID,
			SessionID sessionID, String srcCompId) {
		super(transactionID, sessionID, srcCompId);
		this.query = query;
	}

	public void setQuery(AnalysisQuery query) {
		this.query = query;
	}

	public AnalysisQuery getQuery() {
		return query;
	}

	@Override
	public String toString() {
		return super.toString() + ", query=" + query;
	}
	
	
}
