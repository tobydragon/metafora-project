package de.dfki.lasad.modules.dataservice.lasad.translators;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.Vector;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.Parameter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.application.DisplayedObjectIDTracker;
import de.dfki.lasad.events.eue.admin.EUESessionListEvent;
import de.dfki.lasad.events.eue.session.EUEEventID;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.ManagementResponseEvent;
import de.dfki.lasad.events.eue.session.UserFeedbackRequestEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserCreateObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserDeleteObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserModifyObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackRequestSpec;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackTypeID;
import de.dfki.lasad.models.eue.objects.EUEObject;
import de.dfki.lasad.models.eue.objects.EUEObjectID;
import de.dfki.lasad.models.eue.objects.EmptyID;
import de.dfki.lasad.models.eue.objects.ObjectProperty;
import de.dfki.lasad.models.eue.objects.SimpleProperty;
import de.dfki.lasad.models.eue.objects.graph.Link;
import de.dfki.lasad.models.eue.objects.graph.Node;
import de.dfki.lasad.models.eue.ontology.EUEOntology;
import de.dfki.lasad.modules.action.xmpp.XmppActionAgent;
import de.dfki.lasad.modules.dataservice.lasad.AnalysisAndFeedbackTypeAdapter;
import de.dfki.lasad.modules.dataservice.lasad.LASADOntologyParser;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMI;

public class EventTranslatorLASAD2AF {

	private static Log logger = LogFactory
			.getLog(EventTranslatorLASAD2AF.class);

	// debugging setting
	private boolean REQUEST_RAW_RESULTS = false;

	private HashMap<EUEObjectID, EUEObjectBasicData> objectTracker = new HashMap<EUEObjectID, EUEObjectBasicData>();

	private HashMap<String, GUIAction> guiActionTracker = new HashMap<String, GUIAction>();
	private HashSet<String> replayedGuiActionTracker = new HashSet<String>();

	// flag indicating that replayed events should be generated
	private boolean generateReplayedEvent = false;

	// used to generate unique event ids in case of replayed actions
	private int replayedEventCounter = 0; // 

	// will be ignored for the time being
	private Map<String, Set<String>> mapID2feedbackElementIDs = new HashMap<String, Set<String>>();

	public List<EUESessionEvent> translate(ActionPackage lasadEvent) {

		logger.debug("Start translating ActionPackage  ...");
		List<EUESessionEvent> translation = translateActionPackage(lasadEvent);
		Collections.sort(translation, new Comparator<EUESessionEvent>() {
			@Override
			public int compare(EUESessionEvent o1, EUESessionEvent o2) {
				long tsDiff = o1.getTs() - o2.getTs();
				if (tsDiff < 0) {
					return -1;
				} else if (tsDiff > 0) {
					return 1;
				}
				return 0;
			}
		});
		logger.debug("Number of produced Events: " + translation.size());
		for (EUESessionEvent event : translation) {
			String eventAsString = event.toString().replace("\\s", " ");
			logger.debug("... Events: " + eventAsString);
		}

		return translation;

	}

	/**
	 * Processes all actions relevant to a session
	 * <ul>
	 * <li>feedback requests</li>
	 * <li>new user joins a session</li>
	 * <li>user creates, modifies or deletes an object within a session</li>
	 * <li><i>... ignore all other actions ...</i></li>
	 * </ul>
	 * 
	 * @param lasadEvent
	 * @return
	 */
	public List<EUESessionEvent> translateActionPackage(ActionPackage lasadEvent) {

		List<EUESessionEvent> generatedEventsList = new Vector<EUESessionEvent>();

		List<Action> actionList = lasadEvent.getActions();

		for (Action action : actionList) {
			String actionCategory = action.getCategory();
			String actionCommand = action.getCmd();
			ParamMap paramMap = extractParams(action.getParameters());

			// translate feedback request
			if (isFeedbackRequest(actionCategory, actionCommand)) {
				UserFeedbackRequestEvent feedbackRequestEvent = translateFeedbackRequestAction(action);
				generatedEventsList.add(feedbackRequestEvent);
			}

			// process feedback presentation to user
			else if (isFeedbackElementDisplayed(actionCategory, actionCommand,
					paramMap)) {
				processFeedbackElementDisplayedAction(action, paramMap);
			}

			// process feedback presentation to user
			else if (isFeedbackElementDisplayed(actionCategory, actionCommand,
					paramMap)) {
				processFeedbackElementDisplayedAction(action, paramMap);
			}

			// translate user join session
			else if (isUserJoin(actionCategory, actionCommand)) {
				// TODO: implement
			}

			// translate session actions (create, modify, delete object)
			else if (isCreateUpdateDelete(actionCategory, actionCommand)) {
				String guiActionID = translateCreateUpdateDeleteAction(action,
						paramMap);
				if (guiActionID == null) {
					logger.debug("IGNORE Action: Property '"
							+ LASADVocabulary.ACTION_PROP_USERACTION_ID
							+ "' is not present");
				} else {
					GUIAction guiAction = guiActionTracker.get(guiActionID);
					if (guiAction != null && guiAction.isComplete() && !guiAction.isReplayedAction()) {
						guiActionTracker.remove(guiActionID);
						List<EUESessionEvent> evList = createEvent(guiAction);
						generatedEventsList.addAll(evList);
					}
				}
			} 
			else if (isManagementResponse(actionCategory, actionCommand)){
				//TD: may cause problems due to null sessionID, but plain EUEEvents are not part of the schema for messages to actionAgents
				generatedEventsList.add(new ManagementResponseEvent(null, XmppActionAgent.class.getName(), actionCommand, paramMap.getFirstValue(LASADVocabulary.ACTION_PROP_MESSAGE)));
			}
			else {
				logger.debug("IGNORE Action: ActionCommand '" + actionCommand
						+ "'");
			}
		}

		logger.debug("Replayed Actions? " + generateReplayedEvent
				+ ", number of replayed Actions:"
				+ replayedGuiActionTracker.size());
		if (generateReplayedEvent) {
			List<EUESessionEvent> replayedEvents = generateReplayedEvents();
			generatedEventsList.addAll(replayedEvents);
			generateReplayedEvent = false;
		}
		return generatedEventsList;

	}
	
	private boolean isManagementResponse (String actionCategory, String actionCommand) {
		boolean managementError = LASADVocabulary.ACTION_CAT_INFO.equalsIgnoreCase(actionCategory) 
			&& LASADVocabulary.ACTION_CMD_AUTHORING_FAILED.equalsIgnoreCase(actionCommand);
		boolean managementSuccess = LASADVocabulary.ACTION_CAT_NOTIFY.equalsIgnoreCase(actionCategory) 
			&& ( LASADVocabulary.ACTION_CMD_USER_CREATED.equalsIgnoreCase(actionCommand)
					|| LASADVocabulary.ACTION_CMD_SESSION_CREATED.equalsIgnoreCase(actionCommand) );
		return managementError || managementSuccess;
	}

	private boolean isFeedbackRequest(String actionCategory,
			String actionCommand) {
		boolean isFeedbackRequest = LASADVocabulary.ACTION_CMD_REQUEST
				.equalsIgnoreCase(actionCommand)
				&& LASADVocabulary.ACTION_CAT_FEEDBACK
						.equalsIgnoreCase(actionCategory);
		return isFeedbackRequest;
	}

	private boolean isFeedbackElementDisplayed(String actionCategory,
			String actionCommand, ParamMap paramMap) {
		String type = paramMap.getFirstValue(LASADVocabulary.ACTION_PROP_TYPE);
		return actionCommand
				.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT)
				&& LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK_CLUSTER
						.equalsIgnoreCase(type);

	}

	private boolean isUserJoin(String actionCategory, String actionCommand) {
		boolean isUserJoin = actionCommand
				.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_USER_JOIN);
		return isUserJoin;
	}

	private boolean isCreateUpdateDelete(String actionCategory,
			String actionCommand) {
		boolean isCreateUpdateDelete = actionCommand
				.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT)
				|| actionCommand
						.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_UPDATE_ELEMENT)
				|| actionCommand
						.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_DELETE_ELEMENT);
		return isCreateUpdateDelete;
	}

	private void processFeedbackElementDisplayedAction(Action action,
			ParamMap paramMap) {
		String mapID = paramMap
				.getFirstValue(LASADVocabulary.ACTION_PROP_MAPID);
		String objectID = paramMap
				.getFirstValue(LASADVocabulary.ACTION_PROP_ID);

		Set<String> objectsForMap = mapID2feedbackElementIDs.get(mapID);
		if (objectsForMap == null) {
			objectsForMap = new HashSet<String>();
			mapID2feedbackElementIDs.put(mapID, objectsForMap);
		}
		objectsForMap.add(objectID);
	}

	private List<EUESessionEvent> generateReplayedEvents() {
		logger.debug("Start generating Events for replayed Actions ...");
		resetReplayedEventCounter();
		List<EUESessionEvent> replayedEvents = createReplayedEvents();
		logger.debug("Number of generated replayed Events:"
				+ replayedEvents.size());
		return replayedEvents;
	}

	private int getReplayedEventCount() {
		return replayedEventCounter;
	}

	private int getReplayedEventCountAndIncrement() {
		return ++replayedEventCounter;
	}

	private void resetReplayedEventCounter() {
		replayedEventCounter = 0;
	}

	private String translateCreateUpdateDeleteAction(Action action,
			ParamMap paramMap) {
		String actionCommand = action.getCmd();

		String displayedID = paramMap
				.getFirstValue(LASADVocabulary.ACTION_PROP_ROOT_ELEMENT_ID);

		String sessionID = paramMap
				.getFirstValue(LASADVocabulary.ACTION_PROP_MAPID);

		String objectID = paramMap
				.getFirstValue(LASADVocabulary.ACTION_PROP_ID);

		if (isFeedbackElement(sessionID, objectID)) {
			// ignore
			return null;
		}

		if (displayedID != null && sessionID != null) {
			// top-level element: we extract the displayed id (== ROOTELEMENTID)
			DisplayedObjectIDTracker.addMapping(new SessionID(sessionID),
					new EUEObjectID(objectID), displayedID);
		}

		String guiActionID = getGuiActionID(paramMap);

		if (guiActionID == null) {
			logger.error(LASADVocabulary.ACTION_PROP_USERACTION_ID
					+ " is not present in Action, action discarded");
		} else {
			if (guiActionTracker.containsKey(guiActionID)) {
				// we receive a new action of an existing UserActionEvent
				processExistingGuiActionID(guiActionID, actionCommand, paramMap);

			} else {
				// we receive a new action, and the GuiActionID is new too,
				// start tracking it.
				processNewGuiAction(guiActionID, actionCommand, paramMap);
			}
		}

		return guiActionID;
	}

	private void processNewGuiAction(String guiActionID, String actionCommand,
			ParamMap paramMap) {

		GUIAction guiAction = new GUIAction(guiActionID);

		guiAction.setUserEventType(actionCommand);

		String sessionID = paramMap
				.removeAndGetFirst(LASADVocabulary.ACTION_PROP_MAPID);
		String userID = paramMap
				.removeAndGetFirst(LASADVocabulary.ACTION_PROP_USERNAME);
		String numActions = paramMap
				.removeAndGetFirst(LASADVocabulary.ACTION_PROP_NUM_ACTIONS);
		String time = paramMap
				.removeAndGetFirst(LASADVocabulary.ACTION_PROP_TIME); // TIME

		guiAction.setSessionID(new SessionID(sessionID));

		if (userID == null) {
			// update and delete actions don't have an userID, i.e. it's not provided...
			// ... Look up userID in tracker system.
			String objectID = paramMap
					.getFirstValue(LASADVocabulary.ACTION_PROP_ID);
			if (objectID != null) {
				EUEObjectID objectIDObj = new EUEObjectID(objectID);
				EUEObjectBasicData objectBasicData = getEUEObjectFromTracker(objectIDObj);
				if (objectBasicData == null) {
					logger.error(LASADVocabulary.ACTION_PROP_USERNAME
							+ " was not provided," + " node: " + objectID
							+ " is not in tracking system, "
							+ "we cannot determine the owner");
					return;
				} else {
					userID = objectBasicData.getUserID();
				}
			} else {
				logger.error("Param 'objectID' not available in Action.");
			}
		}

		guiAction.setUserID(new UserID(userID));
		guiAction.setNumActions(Integer.parseInt(numActions));
		guiAction.setGuiActionID(guiActionID);
		if(time != null){
			guiAction.setTime(Long.parseLong(time));
		}
		else{
			guiAction.setTime(getCurrentTimeAsLong());
		}
		

		if (paramMap.getFirstValue(LASADVocabulary.ACTION_PROP_REPLAY) != null) {
			generateReplayedEvent = true;

			String creationDate = paramMap
					.removeAndGetFirst(LASADVocabulary.ACTION_PROP_CREATIONDATE);
			if (creationDate != null) {
				guiAction.setCreationDate(Long.parseLong(creationDate));
			}
			String modDate = paramMap
					.removeAndGetFirst(LASADVocabulary.ACTION_PROP_MODIFICATIONDATE);
			if (modDate != null) {
				guiAction.setModificationDate(Long.parseLong(modDate));
			}

			String firstModDate = paramMap
					.removeAndGetFirst(LASADVocabulary.ACTION_PROP_FIRSTMODIFICATIONDATE);
			if (firstModDate != null) {
				guiAction.setFirstModDate(Long.parseLong(firstModDate));
			}

			// remove parameters that are not required
			paramMap.remove(LASADVocabulary.ACTION_PROP_REPLAY);

			guiAction.setIsReplayedAction(true);

		} else {
			// TODO each time we receive one of this actions check if
			// list of replay action is empty, if not generate event.
			// not from a graph
		}

		if (paramMap.containsKey(LASADVocabulary.ACTION_PROP_DIRECTION)) {
			String paramValue = paramMap
					.removeAndGetFirst(LASADVocabulary.ACTION_PROP_DIRECTION);

			if (paramValue.equals(LASADVocabulary.ACTION_PROP_VALUE_CHANGED)) {
				String objectID = paramMap
						.getFirstValue(LASADVocabulary.ACTION_PROP_ID); // ID
				EUEObjectID objectIDObj = new EUEObjectID(objectID);
				EUEObjectBasicData oldObjBasic = getEUEObjectFromTracker(objectIDObj);
				
				if(oldObjBasic != null){
					changeLinkDirection(oldObjBasic);
	
					// NOTE: LASAD does only support 2 parents: 1. parent == source,
					// 2. parent == target
					for (EUEObjectID sourceID : oldObjBasic.getSourceList()) {
						paramMap.addParam(LASADVocabulary.ACTION_PROP_PARENT,
								sourceID.getIdAsString());
					}
					for (EUEObjectID targetID : oldObjBasic.getTargetList()) {
						paramMap.addParam(LASADVocabulary.ACTION_PROP_PARENT,
								targetID.getIdAsString());
					}
				}
			}
		}

		EUEObject eueObject = createEUEObjectNew(paramMap);

		if (eueObject != null) {
			EUEObjectBasicData objBasicDesc = createEUEObjectBasicData(
					eueObject, userID);
			
			if(eueObject instanceof Node){
				objBasicDesc.setParentID(((Node)eueObject).getParentID().getIdAsString());
			}
			//guiAction.addEueObject(eueObject);
			guiAction.increaseCurrentActionsByOne();

			// track/untrack the node/link/child
			if (actionCommand.equals(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT)) {
				guiAction.addEueObject2CreateList(eueObject);
				addEUEObjectToTracker(objBasicDesc);
			} else if (actionCommand.equals(LASADVocabulary.ACTION_CMD_UPDATE_ELEMENT)) {
				//this is the timestamp we will use for the update event when creates and updates are mixed
				guiAction.addEueObject2UpdateList(eueObject);
				if(time != null){
					guiAction.setModificationDate(Long.parseLong(time));
				}
				else{
					guiAction.setModificationDate(getCurrentTimeAsLong());
				}
				//updateEUEObjectToTracker(objBasicDesc);
			} else if (actionCommand.equals(LASADVocabulary.ACTION_CMD_DELETE_ELEMENT)) {
				guiAction.addEueObject2DeleteList(eueObject);
				if(time != null){
					guiAction.setModificationDate(Long.parseLong(time));
				}
				else{
					guiAction.setModificationDate(getCurrentTimeAsLong());
				}
				deleteEUEObjectFromTracker(objBasicDesc.getId());
			}
			// track/untrack the node/link/child
//			if (actionCommand
//					.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT)) {
//				addEUEObjectToTracker(objBasicDesc);
//			} else if (actionCommand
//					.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_DELETE_ELEMENT)) {
//				deleteEUEObjectFromTracker(objBasicDesc.getId());
//			}
		} else {
			// the action was a timestamp, action was malformed or a problem
			// occurred, then decrease the total number of actions for that
			// userActionID
			guiAction.decreaseNumActionsByOne();
		}
		if (guiAction.getNumActions() > 0) {
			guiActionTracker.put(guiActionID, guiAction);
			if (guiAction.isReplayedAction()) {
				replayedGuiActionTracker.add(guiActionID);
			}
		}
	}

	private void processExistingGuiActionID(String guiActionID,
			String actionCommand, ParamMap paramMap) {
		// we receive a new action of an existing UserActionEvent
		GUIAction guiAction = guiActionTracker.remove(guiActionID);

		String userID = guiAction.getUserID().getIdAsString();

		String time = paramMap.removeAndGetFirst(LASADVocabulary.ACTION_PROP_TIME); // TIME
		
		// remove parameters that are not required
		paramMap.remove(LASADVocabulary.ACTION_PROP_REPLAY);
		paramMap.remove(LASADVocabulary.ACTION_PROP_NUM_ACTIONS);
		//paramMap.remove(LASADVocabulary.ACTION_PROP_USERNAME);

		if (paramMap.containsKey(LASADVocabulary.ACTION_PROP_DIRECTION)) {
			String paramValue = paramMap
					.removeAndGetFirst(LASADVocabulary.ACTION_PROP_DIRECTION);

			if (paramValue.equals(LASADVocabulary.ACTION_PROP_VALUE_CHANGED)) {
				String objectID = paramMap
						.getFirstValue(LASADVocabulary.ACTION_PROP_ID); // ID
				EUEObjectID objectIDObj = new EUEObjectID(objectID);
				EUEObjectBasicData oldObjBasic = getEUEObjectFromTracker(objectIDObj);
				
				if(oldObjBasic != null){
					changeLinkDirection(oldObjBasic);
					// NOTE: LASAD does only support 2 parents: 1. parent == source,
					// 2. parent == target
					for (EUEObjectID sourceID : oldObjBasic.getSourceList()) {
						paramMap.addParam(LASADVocabulary.ACTION_PROP_PARENT,
								sourceID.getIdAsString());
					}
					for (EUEObjectID targetID : oldObjBasic.getTargetList()) {
						paramMap.addParam(LASADVocabulary.ACTION_PROP_PARENT,
								targetID.getIdAsString());
					}
				}
			}
		}
		EUEObject eueObject = createEUEObjectNew(paramMap);

		if (eueObject != null) {
			EUEObjectBasicData objBasicDesc = createEUEObjectBasicData(
					eueObject, userID);
			if(eueObject instanceof Node){
				objBasicDesc.setParentID(((Node)eueObject).getParentID().getIdAsString());
			}
			
			guiAction.increaseCurrentActionsByOne();
			//System.out.println(objBasicDesc);
			// track/untrack the node/link/child
			if (actionCommand.equals(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT)) {
				if(time != null){
					guiAction.setCreationDate(Long.parseLong(time));
				}
				guiAction.addEueObject2CreateList(eueObject);
				addEUEObjectToTracker(objBasicDesc);
			} else if (actionCommand.equals(LASADVocabulary.ACTION_CMD_UPDATE_ELEMENT)) {
				//this is the timestamp we will use for the update event when creates and updates are mixed
				guiAction.addEueObject2UpdateList(eueObject);
				//updateEUEObjectToTracker(objBasicDesc);
				if(time != null){
					guiAction.setModificationDate(Long.parseLong(time));
				}
				else{
					guiAction.setModificationDate(guiAction.getCreationDate());
				}
			} else if (actionCommand
					.equals(LASADVocabulary.ACTION_CMD_DELETE_ELEMENT)) {
				guiAction.addEueObject2DeleteList(eueObject);
				deleteEUEObjectFromTracker(objBasicDesc.getId());
				if(time != null){
					guiAction.setModificationDate(Long.parseLong(time));
				}
				else{
					guiAction.setModificationDate(guiAction.getCreationDate());
				}
			}
			// track/untrack the node/link/child
//			if (actionCommand
//					.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT)) {
//				addEUEObjectToTracker(objBasicDesc);
//			} else if (actionCommand
//					.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_DELETE_ELEMENT)) {
//				deleteEUEObjectFromTracker(objBasicDesc.getId());
//			}

		} else {
			// the action was a timestamp, action was malformed or a problem
			// occurred, then decrease the total number of actions for that
			// guiActionID
			guiAction.decreaseNumActionsByOne();
		}

		// After the insertions/deletions check if we should continue tracking
		// this guiActionID
		if (guiAction.getNumActions() > 0) {
			guiActionTracker.put(guiActionID, guiAction);
		}
	}

	private String getGuiActionID(ParamMap paramMap) {

		String guiActionID = null;

		String replayValueAsString = paramMap
				.getFirstValue(LASADVocabulary.ACTION_PROP_REPLAY);
		boolean replayParam = Boolean.valueOf(replayValueAsString);

		if (replayParam) {
			// Since the USERACTION-ID (i.e., guiActionID) value might be the
			// same for different action packages we need to generate unique
			// values for each action package.
			paramMap.remove(LASADVocabulary.ACTION_PROP_USERACTION_ID);

			if (!paramMap.containsKey(LASADVocabulary.ACTION_PROP_CREATIONDATE)) {
				// it is a root, i.e. is the box node
				guiActionID = String.valueOf(getReplayedEventCount());
			} else {
				// it is a child of the box, e.g., header or comment section
				guiActionID = String
						.valueOf(getReplayedEventCountAndIncrement());
			}
		} else {
			// we can get the USERACTION-ID value directly, it's a unique value
			// for each actionpackage
			guiActionID = paramMap
					.removeAndGetFirst(LASADVocabulary.ACTION_PROP_USERACTION_ID);
		}
		return guiActionID;
	}

	private List<EUESessionEvent> createEvent(GUIAction guiAction) {
		//UserObjectActionEvent eueEvent = null;
		
		List<EUESessionEvent> eueEventList = new Vector<EUESessionEvent>();

		String srcCompID = LASADDataServiceRMI.class.toString();
		EUEEventID eueEventIDObj = EUEEventIDGenerator.getNextID();
		
		if (guiAction.getCreateEueObjectList().size() > 0){
			UserObjectActionEvent eueEventCreate = new UserCreateObjectEvent(guiAction.getSessionID(),
					eueEventIDObj, srcCompID);
			eueEventCreate.setUserID(guiAction.getUserID());
			eueEventCreate.setTs(guiAction.getTime());
			List<EUEObject> objList = guiAction.getCreateEueObjectList();
			for (EUEObject obj : objList) {
				eueEventCreate.addEueObject(obj);
			}
			eueEventList.add(eueEventCreate);
		}
		if (guiAction.getUpdateEueObjectList().size() > 0){
			UserObjectActionEvent eueEventUpdate = new UserModifyObjectEvent(guiAction.getSessionID(),
					eueEventIDObj, srcCompID);
			eueEventUpdate.setUserID(guiAction.getUserID());
			eueEventUpdate.setTs(guiAction.getTime());
			List<EUEObject> objList = guiAction.getUpdateEueObjectList();
			for (EUEObject obj : objList) {
				eueEventUpdate.addEueObject(obj);
			}
			eueEventList.add(eueEventUpdate);
		}
		if (guiAction.getDeleteEueObjectList().size() > 0){
			UserObjectActionEvent eueEventDelete = new UserDeleteObjectEvent(guiAction.getSessionID(),
					eueEventIDObj, srcCompID);
			eueEventDelete.setUserID(guiAction.getUserID());
			eueEventDelete.setTs(guiAction.getTime());
			List<EUEObject> objList = guiAction.getDeleteEueObjectList();
			for (EUEObject obj : objList) {
				eueEventDelete.addEueObject(obj);
			}
			eueEventList.add(eueEventDelete);
		}
		return eueEventList;
		
//		String eventType = guiAction.getUserEventType();
//		if (eventType.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT)) {
//			eueEvent = new UserCreateObjectEvent(guiAction.getSessionID(),
//					eueEventIDObj, srcCompID);
//		} else if (eventType.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_UPDATE_ELEMENT)) {
//			eueEvent = new UserModifyObjectEvent(guiAction.getSessionID(),
//					eueEventIDObj, srcCompID);
//		} else if (eventType.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_DELETE_ELEMENT)) {
//			eueEvent = new UserDeleteObjectEvent(guiAction.getSessionID(),
//					eueEventIDObj, srcCompID);
//		}
//		eueEvent.setUserID(guiAction.getUserID());
//		eueEvent.setTs(guiAction.getTime());
//		List<EUEObject> objList = guiAction.getEueObjectList();
//		if (eventType
//				.equalsIgnoreCase(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT)) {
//			// TODO This is a hack. Should be addressed in a more systematic
//			// way later!!!!
//			Set<EUEObjectID> alreadyCreatedObjectIDs = new HashSet<EUEObjectID>();
//			for (Iterator<EUEObject> objIter = objList.iterator(); objIter
//					.hasNext();) {
//				EUEObject obj = objIter.next();
//				if (alreadyCreatedObjectIDs.contains(obj.getID())) {
//					objIter.remove();
//				}
//				alreadyCreatedObjectIDs.add(obj.getID());
//			}
//		}
//		for (EUEObject obj : objList) {
//			eueEvent.addEueObject(obj);
//		}
//		return eueEvent;
		
	}

	private List<EUESessionEvent> createReplayedEvents() {

		List<EUESessionEvent> eventList = new Vector<EUESessionEvent>();
		Vector<String> completedGuiActionIDs = new Vector<String>();

		for (String replayedGuiActionID : replayedGuiActionTracker) {
			if (guiActionTracker.containsKey(replayedGuiActionID)) {
				GUIAction guiAction = guiActionTracker.get(replayedGuiActionID);

				String srcCompID = LASADDataServiceRMI.class.toString();
				//List<EUEObject> objList = guiAction.getEueObjectList();
				List<EUEObject> objList = guiAction.getCreateEueObjectList();

				long creationDate = guiAction.getCreationDate();
				if (creationDate > 0L) {
					UserCreateObjectEvent createEvent = new UserCreateObjectEvent(
							guiAction.getSessionID(), EUEEventIDGenerator
									.getNextID(), srcCompID);
					createEvent.setTs(creationDate);
					createEvent.setUserID(guiAction.getUserID());

					for (EUEObject obj : objList) {
						createEvent.addEueObject(obj);
					}
					eventList.add(createEvent);
				}

				long firstModDate = guiAction.getFirstModDate();
				if (firstModDate > 0L) {
					UserModifyObjectEvent firstModEvent = new UserModifyObjectEvent(
							guiAction.getSessionID(), EUEEventIDGenerator
									.getNextID(), srcCompID);
					firstModEvent.setTs(firstModDate);
					firstModEvent.setUserID(guiAction.getUserID());

					for (EUEObject obj : objList) {
						EUEObject objNoProp = createEUEObjectWithoutProps(obj
								.getID(), null, obj.getType());
						firstModEvent.addEueObject(objNoProp);
					}
					eventList.add(firstModEvent);
				}

				long modificationDate = guiAction.getModificationDate();
				if (modificationDate > 0L) {
					UserModifyObjectEvent modEvent = new UserModifyObjectEvent(
							guiAction.getSessionID(), EUEEventIDGenerator
									.getNextID(), srcCompID);
					modEvent.setTs(modificationDate);
					modEvent.setUserID(guiAction.getUserID());

					for (EUEObject obj : objList) {
						EUEObject objNoProp = createEUEObjectWithoutProps(obj
								.getID(), null, obj.getType());
						modEvent.addEueObject(objNoProp);
					}
					eventList.add(modEvent);
				}

			} else {
				logger
						.error(replayedGuiActionID
								+ " does not exist in tracker");
			}
			completedGuiActionIDs.add(replayedGuiActionID);
		}

		// remove entries from tracker
		for (String key : completedGuiActionIDs) {
			guiActionTracker.remove(key);
		}
		replayedGuiActionTracker.clear();
		return eventList;

	}

	public EUEObject createEUEObjectNew(ParamMap paramMap) {

		EUEObject eueObject = null;

		Map<String, ObjectProperty> props = new HashMap<String, ObjectProperty>();

		// get time and discard action
		String dataType = paramMap.removeAndGetFirst(LASADVocabulary.ACTION_PROP_TYPE);  // TYPE
		if (LASADVocabulary.ACTION_PROP_VALUE_AWARENESS.equalsIgnoreCase(dataType) ||
				LASADVocabulary.ACTION_PROP_VALUE_AWARENESS_CURSOR.equalsIgnoreCase(dataType) ||
				LASADVocabulary.ACTION_PROP_VALUE_GROUP_CURSOR.equalsIgnoreCase(dataType)) {
			return null;
		}

		// EUEObject fields
		String objectID = paramMap
				.removeAndGetFirst(LASADVocabulary.ACTION_PROP_ID); // ID
		String nodeType = paramMap
				.removeAndGetFirst(LASADVocabulary.ACTION_PROP_ELEMENT_ID); // ELEMENT_ID

		// remove params not required
		paramMap.remove(LASADVocabulary.ACTION_PROP_STATUS);

		// "ELEMENT-ID" and "TYPE" are not provided in COMMANDs of type
		// UPDATE-ELEMENT and DELETE-ELEMENT
		if (nodeType == null) {
			if (objectID != null) {
				EUEObjectID objectIDObj = new EUEObjectID(objectID);
				EUEObjectBasicData objPreviousState = getEUEObjectFromTracker(objectIDObj);
				if (objPreviousState == null) {
					logger.debug("node: " + objectID
							+ " is not in tracking system, should have type:"
							+ LASADVocabulary.ACTION_PROP_VALUE_AWARENESS);
					return null;
				}
				nodeType = objPreviousState.getNodeType();
			} else {
				logger.error("Param userID not available");
			}
		}
		if (dataType == null) {
			if (objectID != null) {
				EUEObjectID objectIDObj = new EUEObjectID(objectID);
				EUEObjectBasicData objPreviousState = getEUEObjectFromTracker(objectIDObj);
				if (null == objPreviousState) {
					logger.info("node: " + objectID
							+ " is not in tracking system, should have type:"
							+ LASADVocabulary.ACTION_PROP_VALUE_AWARENESS);
					return null;
				}
				dataType = objPreviousState.getDataType();
			} else {
				logger.error("Param userID not available");
			}
		}

		// create objects and add parent props (i.e., parent of child elements,
		// sources and targets of links)
		if (dataType.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_RELATION)) {
			eueObject = createLinkWithoutProps(paramMap);
		} else if (dataType.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_BOX)) {
			eueObject = createNodeWithoutProps();
		} else {
			eueObject = createChildElementWithoutProps(paramMap, objectID);
		}

		// add basic props
		EUEObjectID objectIDObj = new EUEObjectID(objectID);
		eueObject.setID(objectIDObj);
		eueObject.setType(nodeType);
		eueObject.setDataType(dataType);

		// add generic props
		Iterator<String> iter = paramMap.keySet().iterator();
		while (iter.hasNext()) {
			String paramName = iter.next();
			String paramValue = paramMap.getFirstValue(paramName);
			SimpleProperty property = new SimpleProperty(paramName, paramValue);
			props.put(paramName, property);
		}
		eueObject.addProperties(props);

		// objCurrentState.setId(objectID);
		// objCurrentState.setDataType(dataType);
		// objCurrentState.setNodeType(nodeType);
		// objCurrentState.setUserID(userID);

		return eueObject;

	}

	public EUEObjectBasicData createEUEObjectBasicData(EUEObject newEUEObject,
			String userID) {

		EUEObjectBasicData objBasicData = new EUEObjectBasicData();

		String objID = newEUEObject.getID().getIdAsString();
		objBasicData.setId(objID);
		objBasicData.setDataType(newEUEObject.getDataType());
		objBasicData.setNodeType(newEUEObject.getType());
		objBasicData.setUserID(userID);

		String dataType = newEUEObject.getDataType();
		if (dataType
				.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_RELATION)) {
			objBasicData.getSourceList().addAll(
					((Link) newEUEObject).getSources());
			objBasicData.getTargetList().addAll(
					((Link) newEUEObject).getTargets());
		}

		return objBasicData;
	}

	public EUEObject createEUEObjectWithoutProps(EUEObjectID objectIDObj,
			String dataType, String nodeType) {

		EUEObject eueObject = null;

		if (objectIDObj == null) {
			logger.error("userID not available");
			return null;
		}

		if (nodeType == null) {
			EUEObjectBasicData objectBasicData = getEUEObjectFromTracker(objectIDObj);
			if (null == objectBasicData) {
				logger.info("node: " + objectIDObj.getIdAsString()
						+ " is not in tracking system, :-S:");
				return null;
			}
			nodeType = objectBasicData.getNodeType();
		}
		if (dataType == null) {
			EUEObjectBasicData objectBasicData = getEUEObjectFromTracker(objectIDObj);
			if (objectBasicData == null) {
				logger.info("node: " + objectIDObj.getIdAsString()
						+ " is not in tracking system, :-S:");
				return null;
			}
			dataType = objectBasicData.getDataType();
		}

		// CREATE-ELEMENT
		if (dataType
				.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_RELATION)) {
			eueObject = new Link();
		} else if (dataType
				.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_BOX)) {
			eueObject = new Node();
		} else if (dataType
				.equalsIgnoreCase(LASADVocabulary.ACTION_PROP_VALUE_GRAPH)) {
		} else {
			eueObject = new Node();
		}

		eueObject.setID(objectIDObj);
		eueObject.setType(nodeType);
		eueObject.setDataType(dataType);

		return eueObject;
	}

	public void changeLinkDirection(EUEObjectBasicData objBasicData) {

		List<EUEObjectID> newSourceList = new ArrayList<EUEObjectID>();
		List<EUEObjectID> newTargetList = new ArrayList<EUEObjectID>();

		for (EUEObjectID objID : objBasicData.getSourceList()) {
			newTargetList.add(new EUEObjectID(objID.getIdAsString()));
		}
		for (EUEObjectID objID : objBasicData.getTargetList()) {
			newSourceList.add(new EUEObjectID(objID.getIdAsString()));
		}
		objBasicData.getSourceList().clear();
		objBasicData.getTargetList().clear();

		objBasicData.getSourceList().addAll(newSourceList);
		objBasicData.getTargetList().addAll(newTargetList);

	}

	/**
	 * Received ActionPackage: ActionPackage (SESSION-ID->
	 * http://localhost:8081/LASADClientWS) { [ACTION: CATEGORY: FEEDBACK,
	 * COMMAND: REQUEST, PARAMETERS: MAP-ID-> 58, USERNAME-> t1, AGENT-ID->
	 * Event Counter, TYPE-ID-> COUNT_OBJECT_ACTIONS, AGENT-TYPE-> ANALYSIS]}
	 */
	public UserFeedbackRequestEvent translateFeedbackRequestAction(Action action) {

		String mapID = null;
		String userName = null;
		String agentID = null;
		String serviceID = null;
		String agentType = null;

		for (Parameter actionParam : action.getParameters()) {
			if (LASADVocabulary.ACTION_PROP_MAPID.equalsIgnoreCase(actionParam
					.getName())) {
				mapID = actionParam.getValue();
			} else if (LASADVocabulary.ACTION_PROP_USERNAME
					.equalsIgnoreCase(actionParam.getName())) {
				userName = actionParam.getValue();
			} else if (LASADVocabulary.ACTION_PROP_AGENT_ID
					.equalsIgnoreCase(actionParam.getName())) {
				agentID = actionParam.getValue();
			} else if (LASADVocabulary.ACTION_PROP_TYPE_ID
					.equalsIgnoreCase(actionParam.getName())) {
				serviceID = actionParam.getValue();
			} else if (LASADVocabulary.ACTION_PROP_AGENT_TYPE
					.equalsIgnoreCase(actionParam.getName())) {
				agentType = actionParam.getValue();
			}
		}
		if (mapID == null || userName == null || agentID == null
				|| serviceID == null || agentType == null) {
			logger
					.warn("Incomplete information while creating UserFeedbackRequestEvent: mapID='"
							+ mapID
							+ "', userName='"
							+ userName
							+ "', agentID='"
							+ agentID
							+ "', serviceID='"
							+ serviceID + "', agentType='" + agentType + "'.");
		}

		boolean mirrorResults = LASADVocabulary.ACTION_PROP_VALUE_ANALYSIS
				.equalsIgnoreCase(agentType);
		if (mirrorResults) {
			serviceID = AnalysisAndFeedbackTypeAdapter
					.getAnalysisTypeID(serviceID);
		} else {
			serviceID = AnalysisAndFeedbackTypeAdapter
					.getActionTypeID(serviceID);
		}
		FeedbackTypeID feedbackTypeID = new FeedbackTypeID(agentID, serviceID,
				mirrorResults);
		FeedbackRequestSpec feedbackRequestSpec = new FeedbackRequestSpec(
				feedbackTypeID);

		feedbackRequestSpec.setRequestRawResults(REQUEST_RAW_RESULTS);

		UserFeedbackRequestEvent feedbackRequestEvent = new UserFeedbackRequestEvent(
				feedbackRequestSpec, new SessionID(mapID),
				LASADDataServiceRMI.class.toString(), EUEEventIDGenerator
						.getNextID(), new UserID(userName));
		return feedbackRequestEvent;
	}

	public EUESessionListEvent translateSessionListEvent(
			ActionPackage actionPackage) {
		EUESessionListEvent sessionListEvent = new EUESessionListEvent(
				getClass().getName());
		List<Action> actions = actionPackage.getActions();
		for (Iterator<Action> iter = actions.iterator(); iter.hasNext();) {
			Action action = iter.next();
			String actionCommand = action.getCmd();

			if (LASADVocabulary.ACTION_CMD_LISTMAP
					.equalsIgnoreCase(actionCommand)) {
				// remove action from ActionPackage
				iter.remove();

				String mapID = null;
				String ontologyName = null;
				String templateName = null;
				for (Parameter actionParam : action.getParameters()) {
					if (LASADVocabulary.ACTION_PROP_MAPID
							.equalsIgnoreCase(actionParam.getName())) {
						mapID = actionParam.getValue();
					} else if (LASADVocabulary.ACTION_PROP_ONTOLOGYNAME
							.equalsIgnoreCase(actionParam.getName())) {
						ontologyName = actionParam.getValue();
					} else if (LASADVocabulary.ACTION_PROP_TEMPLATENAME
							.equalsIgnoreCase(actionParam.getName())) {
						templateName = actionParam.getValue();
					}
				}

				if (mapID != null && ontologyName != null) {
					SessionID sessionID = new SessionID(mapID);
					EUEOntology ontology = new EUEOntology(ontologyName);
					if (templateName != null) {
						ontology.addExternalResourceID(templateName);
					}
					sessionListEvent.addOntology(sessionID, ontology);
				} else {
					logger
							.error("Incomplete Ontology information: mapID='"
									+ mapID + "', ontologyName='"
									+ ontologyName + "'.");
				}

			}
		}
		if (sessionListEvent.getSessionIDs2Ontology().entrySet().size() == 0) {
			logger
					.warn("Could not extract any ontology information from ActionPackage "
							+ actionPackage);
		}
		return sessionListEvent;
	}
	
	//TODO this method should be called createNewSessionEvent
	public EUESessionListEvent createSessionListEvent(SessionID sessionId, EUEOntology ontology) {
		EUESessionListEvent sessionListEvent = new EUESessionListEvent(getClass().getName());
		
		sessionListEvent.addOntology(sessionId, ontology);
		
		return sessionListEvent;
	}

	public EUEOntology translateOntologyInfoEvent(String forMapID,
			ActionPackage actionPackage) {

		List<Action> actions = actionPackage.getActions();
		for (Iterator<Action> iter = actions.iterator(); iter.hasNext();) {

			Action action = iter.next();
			String actionCommand = action.getCmd();

			if (LASADVocabulary.ACTION_CMD_ONTOLOGY
					.equalsIgnoreCase(actionCommand)) {
				// remove action from ActionPackage
				iter.remove();

				String ontologyXML = null;
				String mapID = null;
				for (Parameter actionParam : action.getParameters()) {
					if (LASADVocabulary.ACTION_PROP_MAPID
							.equalsIgnoreCase(actionParam.getName())) {
						mapID = actionParam.getValue();
					} else if (LASADVocabulary.ACTION_PROP_ONTOLOGY
							.equalsIgnoreCase(actionParam.getName())) {
						ontologyXML = actionParam.getValue();
					}
				}
				if (forMapID.equals(mapID)) {
					return LASADOntologyParser.parseOntology(ontologyXML);
				}
			}
		}
		return null;
	}
	
	public boolean isCreateMapAP(ActionPackage actionPackage){
		boolean retVal = false;
		List<Action> actions = actionPackage.getActions();
		Action action = actions.get(0);
		String actionCommand = action.getCmd();
		String actionCategory = action.getCategory();
		if (LASADVocabulary.ACTION_CAT_AUTHORING.equalsIgnoreCase(actionCategory)
				&& LASADVocabulary.ACTION_CMD_ADD_MAP_TO_LIST.equalsIgnoreCase(actionCommand)){
			retVal = true;
		}
		return retVal;
	}
	
	public String getMapIdFromAP(ActionPackage actionPackage){
		List<Action> actions = actionPackage.getActions();
		Action action = actions.get(0);
		
		String mapID = null;
		for (Parameter actionParam : action.getParameters()) {
			if (LASADVocabulary.ACTION_PROP_MAPID
					.equalsIgnoreCase(actionParam.getName())) {
				mapID = actionParam.getValue();
				break;
			}
		}
		
		return mapID;
	}

	public MapDetails extractResourceIDsAndMapInfo(String forMapID,
			ActionPackage actionPackage) {
		for (Action action : actionPackage.getActions()) {
			String actionCommand = action.getCmd();
			String actionCategory = action.getCategory();
			if (LASADVocabulary.ACTION_CAT_MAP.equalsIgnoreCase(actionCategory)
					&& LASADVocabulary.ACTION_CMD_MAPDETAILS
							.equalsIgnoreCase(actionCommand)) {
				
				MapDetails mapDetails = new MapDetails();
				String templateXML = null;
				//String mapID = null;
				//String mapName = null;
				//String templateName = null;
				for (Parameter actionParam : action.getParameters()) {
					if (LASADVocabulary.ACTION_PROP_MAPID
							.equalsIgnoreCase(actionParam.getName())) {
						//mapID = actionParam.getValue();
						mapDetails.setMapID(actionParam.getValue());
					} else if (LASADVocabulary.ACTION_PROP_TEMPLATEXML
							.equalsIgnoreCase(actionParam.getName())) {
						templateXML = actionParam.getValue();
						//mapDetails.setTemplateXML(actionParam.getValue());
					} else if (LASADVocabulary.ACTION_PROP_MAPNAME
							.equalsIgnoreCase(actionParam.getName())) {
						//mapName = actionParam.getValue();
						mapDetails.setMapName(actionParam.getValue());
					} else if (LASADVocabulary.ACTION_PROP_TEMPLATENAME
							.equalsIgnoreCase(actionParam.getName())) {
						//templateName = actionParam.getValue();
						mapDetails.setTemplateName(actionParam.getValue());
					}
				}
				
				if (forMapID.equals(mapDetails.getMapID())) {
					SortedSet<String> transcriptIDs = LASADOntologyParser
							.parseMapTemplateXMLAndExtractResourceIDs(templateXML);
					mapDetails.setTranscriptIDs(transcriptIDs);
					return mapDetails;
				}
			}
		}
		return null;
	}

	private ParamMap extractParams(List<Parameter> paramList) {
		ParamMap paramMap = new ParamMap();

		for (Parameter param : paramList) {
			String paramName = param.getName().toUpperCase();
			String paramValue = param.getValue();

			paramMap.addParam(paramName, paramValue);
		}

		return paramMap;
	}

	public boolean containsHeartbeatRequest(ActionPackage aPackage) {
		List<Action> actionList = aPackage.getActions();
		for (Action action : actionList) {
			if (LASADVocabulary.ACTION_CMD_HEARTBEATREQUEST
					.equalsIgnoreCase(action.getCmd())) {
				return true;
			}
		}
		return false;
	}

	public Node createNodeWithoutProps() {
		Node eueObject = new Node();
		EmptyID parentID = new EmptyID();
		eueObject.setParentID(parentID);
		return eueObject;
	}

	public Node createChildElementWithoutProps(ParamMap paramMap, String objectID) {
		Node childElem = new Node();

		List<String> parentPropValues = paramMap
				.getAllValues(LASADVocabulary.ACTION_PROP_PARENT);

		if (parentPropValues == null) {
			if (objectID != null) {
				EUEObjectID objectIDObj = new EUEObjectID(objectID);
				EUEObjectBasicData objPreviousState = getEUEObjectFromTracker(objectIDObj);
				if (objPreviousState != null) {
					EUEObjectID parentID = new EUEObjectID(objPreviousState.getParentID());
					childElem.setParentID(parentID);
				}
			} else {
				logger.error("Param userID not available");
			}
		}else if (parentPropValues.size() >= 1) {
			int source = 0;
			EUEObjectID parentID = new EUEObjectID(parentPropValues.get(source));
			childElem.setParentID(parentID);
		}
		return childElem;
	}

	public Link createLinkWithoutProps(ParamMap paramMap) {
		Link link = new Link();

		List<String> parentPropValues = paramMap
				.remove(LASADVocabulary.ACTION_PROP_PARENT);

		if (parentPropValues == null) {
			return link;
		}

		if (parentPropValues.size() >= 1) {
			int source = 0;
			link.addSource(new EUEObjectID(parentPropValues.get(source)));
			logger.debug("Adding source:" + parentPropValues.get(source));
		}
		if (parentPropValues.size() >= 2) {
			int target = 1;
			link.addTarget(new EUEObjectID(parentPropValues.get(target)));
			logger.debug("Adding target:" + parentPropValues.get(target));
		}
		return link;
	}

	private boolean addEUEObjectToTracker(EUEObjectBasicData eueObject) {
		boolean flag = false;
		EUEObjectID eueObjectID = new EUEObjectID(eueObject.getId());
		if (!objectTracker.containsKey(eueObjectID)) {
			objectTracker.put(eueObjectID, eueObject);
			flag = true;
		}
		return flag;
	}

	private boolean deleteEUEObjectFromTracker(String objectID) {
		boolean flag = false;
		EUEObjectID eueObjectID = new EUEObjectID(objectID);
		if (objectTracker.containsKey(eueObjectID)) {
			objectTracker.remove(eueObjectID);
			flag = true;
		}
		return flag;
	}

	private EUEObjectBasicData getEUEObjectFromTracker(EUEObjectID eueObjectID) {
		EUEObjectBasicData tmpEUEObject = null;
		if (objectTracker.containsKey(eueObjectID)) {
			tmpEUEObject = objectTracker.get(eueObjectID);
		}
		return tmpEUEObject;
	}

	private boolean isFeedbackElement(String mapID, String objectID) {
		Set<String> objectsForMap = mapID2feedbackElementIDs.get(mapID);
		if (objectsForMap == null) {
			return false;
		}
		return objectsForMap.contains(objectID);
	}
	
	public static String getCurrentTime(){
		return new String("" + System.currentTimeMillis());
	}
	public static long getCurrentTimeAsLong(){
		return System.currentTimeMillis();
	}

	private class ParamMap {

		private Map<String, List<String>> paramName2ValueList = new HashMap<String, List<String>>();

		public void addParam(String paramName, String paramValue) {
			List<String> paramValues = paramName2ValueList.get(paramName
					.toUpperCase());
			if (paramValues == null) {
				paramValues = new Vector<String>();
				paramName2ValueList.put(paramName.toUpperCase(), paramValues);
			}
			paramValues.add(paramValue);
		}

		public List<String> getAllValues(String paramName) {
			return paramName2ValueList.get(paramName.toUpperCase());
		}

		public String getFirstValue(String paramName) {
			List<String> paramValues = paramName2ValueList.get(paramName
					.toUpperCase());
			if (paramValues == null) {
				return null;
			}
			return paramValues.get(0);
		}

		public List<String> remove(String paramName) {
			return paramName2ValueList.remove(paramName.toUpperCase());
		}

		public String removeAndGetFirst(String paramName) {
			List<String> paramValues = paramName2ValueList.remove(paramName
					.toUpperCase());
			if (paramValues == null) {
				return null;
			}
			return paramValues.get(0);
		}

		public boolean containsKey(String paramName) {
			return paramName2ValueList.containsKey(paramName.toUpperCase());
		}

		public Set<String> keySet() {
			return paramName2ValueList.keySet();
		}
	}
}
