package de.dfki.lasad.modules.analysis.eventcounter;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.analysis.AbstractAnalysisAgent;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.UserFeedbackRequestEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserCreateObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserDeleteObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserModifyObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.analysis.AnalyzableEntity;
import de.dfki.lasad.models.analysis.NumericalResult;
import de.dfki.lasad.models.eue.SessionID;

public class EUEEventCounter extends AbstractAnalysisAgent {

	Log logger = LogFactory.getLog(EUEEventCounter.class);

	// internal data structures to keep the current analysis state
	private Map<SessionID, Integer> countObjectActions = new HashMap<SessionID, Integer>();
	private Map<SessionID, Integer> countCreateActions = new HashMap<SessionID, Integer>();
	private Map<SessionID, Integer> countDeleteActions = new HashMap<SessionID, Integer>();
	private Map<SessionID, Integer> countModifyActions = new HashMap<SessionID, Integer>();
	private Map<SessionID, Integer> countFeedbackRequests = new HashMap<SessionID, Integer>();

	private Map<String, Map<SessionID, Integer>> analysisID2lookupTable = new HashMap<String, Map<SessionID, Integer>>();
	AnalysisResultEvent resultEvent;
	public EUEEventCounter() {
		analysisID2lookupTable.put(EUEEventCounterDescription.COUNT_OBJECT_ACTIONS, countObjectActions);
		analysisID2lookupTable.put(EUEEventCounterDescription.COUNT_CREATE_OBJECT, countCreateActions);
		analysisID2lookupTable.put(EUEEventCounterDescription.COUNT_DELETE_OBJECT, countDeleteActions);
		analysisID2lookupTable.put(EUEEventCounterDescription.COUNT_UPDATE_OBJECT, countModifyActions);
		analysisID2lookupTable.put(EUEEventCounterDescription.COUNT_FEEDBACK_REQUESTS,
				countFeedbackRequests);
	}

	/**
	 * TODO: Check for right addressee of event should happen in the
	 * AnalysisController
	 */
	@Override
	public void processAnalysisRequestEvent(AnalysisRequestEvent event) {
		String eueAgentID = description.getComponentID();
		Set<String> analysisAgentIDs = event.getQuery().getAnalysisAgentIDs();
		if (analysisAgentIDs.contains(eueAgentID)) {
			Set<String> analysisIDs = event.getQuery().getAnalysisTypeIDs(
					eueAgentID);
			List<AnalysisResult> resultList = new Vector<AnalysisResult>();
			SessionID sessionID = event.getSessionID();
			for (String analysisID : analysisIDs) {
				NumericalResult result = getNumericResult(analysisID, sessionID);
				resultList.add(result);
			}
			 resultEvent = new AnalysisResultEvent(event
					.getTransactionID(), event.getSessionID(), eueAgentID,
					event.getSourceComponentID(), resultList);
			analysisController.onAnalysisResultEvent(resultEvent);
		}
	}

	public AnalysisResultEvent getResultEvent() {
		return resultEvent;
	}

	private NumericalResult getNumericResult(String analysisID,
			SessionID sessionID) {
		Map<SessionID, Integer> discussion2value = analysisID2lookupTable
				.get(analysisID);
		Integer valueInt = discussion2value.get(sessionID);
		if(valueInt == null){
			//TODO: Throw exception
			logger.error("Requested sessionId not found: " + sessionID);
			return null;
		}
		Double valueDouble = valueInt.doubleValue();
		AnalysisType analysisType = description.getAnalysisType(analysisID);
		AnalyzableEntity entity = new AnalyzableEntity();
		entity.addEntityComponent(sessionID);
		NumericalResult result = new NumericalResult(analysisType, entity, valueDouble);
		return result;
	}

	@Override
	public void processEUEEvent(EUESessionEvent eueEvent) {
		logger.debug("Event received: " + eueEvent.toString());
		if (eueEvent instanceof UserObjectActionEvent) {
			processUserObjectActionEvent((UserObjectActionEvent) eueEvent);
		} else if (eueEvent instanceof UserFeedbackRequestEvent) {
			SessionID sessionID = eueEvent.getSessionID();
			increment(countFeedbackRequests, sessionID);
		}
	}

	private void processUserObjectActionEvent(UserObjectActionEvent objectEvent) {
		SessionID sessionID = objectEvent.getSessionID();
		increment(countObjectActions, sessionID);
		if (objectEvent instanceof UserCreateObjectEvent) {
			increment(countCreateActions, sessionID);
			logger.debug("'Create'-Model updated. Current counts: "
					+ getModelAsString(countCreateActions));
		} else if (objectEvent instanceof UserDeleteObjectEvent) {
			increment(countDeleteActions, sessionID);
			logger.debug("'Delete'-Model updated. Current counts: "
					+ getModelAsString(countDeleteActions));
		} else if (objectEvent instanceof UserModifyObjectEvent) {
			increment(countModifyActions, sessionID);
			logger.debug("'Modify'-Model updated. Current counts: "
					+ getModelAsString(countModifyActions));
		}
	}

	private void increment(Map<SessionID, Integer> discussion2counter,
			SessionID sessionID) {
		int oldCount = 0;
		if (discussion2counter.containsKey(sessionID)) {
			oldCount = discussion2counter.get(sessionID);
		}
		discussion2counter.put(sessionID, ++oldCount);
	}

	private String getModelAsString(Map<SessionID, Integer> model) {
		StringBuffer buf = new StringBuffer();
		buf.append("{");
		Iterator<SessionID> discussionIter = model.keySet().iterator();
		while (discussionIter.hasNext()) {
			SessionID sessionID = discussionIter.next();
			int count = model.get(sessionID);
			buf.append(sessionID + "->" + count);
			if (discussionIter.hasNext()) {
				buf.append(", ");
			}
		}
		buf.append("}");
		return buf.toString();
	}

}
