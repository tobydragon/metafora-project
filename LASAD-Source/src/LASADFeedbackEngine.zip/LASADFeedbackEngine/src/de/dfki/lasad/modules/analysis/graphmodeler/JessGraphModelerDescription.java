package de.dfki.lasad.modules.analysis.graphmodeler;

import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.SimpleAnalysisAgentConfiguration;

/**
 * 
 * @author Oliver Scheuer
 *
 */
public class JessGraphModelerDescription extends AnalysisAgentDescription {

	private static final String agentName = "Jess World Model Updater";

	private static final String targetClass = JessGraphModeler.class.getName();

	public JessGraphModelerDescription(SimpleAnalysisAgentConfiguration conf) {
		super(agentName, targetClass);
		this.configuration = conf;
	}

	public JessGraphModelerDescription() {
		this(new SimpleAnalysisAgentConfiguration());
	}

	@Override
	public SimpleAnalysisAgentConfiguration getConfiguration() {
		return (SimpleAnalysisAgentConfiguration) configuration;
	}
}
