package de.dfki.lasad.models.eue.ontology.graph;

import java.util.List;
import java.util.Vector;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class Element {

	private String id;
	private ElementType type;
	private List<Element> children = new Vector<Element>();

	public Element(String id, ElementType type) {
		this.id = id;
		this.type = type;
	}

	public List<Element> getChildren() {
		return children;
	}

	public void addChildElement(Element child) {
		this.children.add(child);
	}

	public String getId() {
		return id;
	}

	public ElementType getType() {
		return type;
	}

}
