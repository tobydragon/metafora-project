package de.dfki.lasad.modules.action.xmpp;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import junit.framework.TestCase;
import de.dfki.lasad.util.TestXmlData;

public class XmppActionAgentTest extends TestCase{
	Log logger = LogFactory.getLog(XmppActionAgentTest.class);
	
	XmppActionAgent xmppActionAgent;
	
	public void setUp(){
		xmppActionAgent = new XmppActionAgent(false);
	}
	
	public void tearDown(){
		xmppActionAgent=null;
	}
	
	public void testShouldTakeAction(){
//		logger.info("Expect 3 [newMessage] info next");
//		assertEquals(false, xmppActionAgent.shouldTakeActionOnMessage("", TestXmlData.notXml, ""));
//		assertEquals(false, xmppActionAgent.shouldTakeActionOnMessage("", TestXmlData.notActionMesssage, ""));
//		assertEquals(false, xmppActionAgent.shouldTakeActionOnMessage("", TestXmlData.createUserXml, ""));
	}
}