package de.dfki.lasad.core.worldmodel;

import java.util.List;
import java.util.Map;

import de.dfki.lasad.core.PluggableComponent;
import de.dfki.lasad.core.action.CompoundActionType;
import de.dfki.lasad.core.action.SimpleActionType;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.admin.EUESessionListEvent;
import de.dfki.lasad.events.eue.session.AgentJoinSessionAnnounceEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.eue.SessionID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public interface IModelController extends PluggableComponent {

	/**
	 * Define an analysis pattern that will be associated with the given
	 * {@link AnalysisType}.
	 * 
	 * @param sessionID
	 * @param actionType
	 * @param patternSpec
	 */
	public void registerAnalysisPattern(AnalysisType analysisType,
			String patternSpec);

	/**
	 * Updates session ontologies.
	 * 
	 * @param sessionListEvent
	 */
	public void executeSessionListEvent(EUESessionListEvent sessionListEvent);

	/**
	 * Starts modeling the provided session. This method has to be called before
	 * Session events are provided.
	 * 
	 * @param joinSessionAnnounceEvent
	 */
	public void executeAgentJoinSessionAnnounceEvent(
			AgentJoinSessionAnnounceEvent joinSessionAnnounceEvent);

	/**
	 * Updates session model according to the provided {@link EUESessionEvent}.
	 * 
	 * @param sessionEvent
	 */
	public void executeEUESessionEvent(EUESessionEvent sessionEvent);

	/**
	 * Updates session model according to the provided
	 * {@link AnalysisResultEvent}.
	 * 
	 * @param sessionEvent
	 */
	public void addAnalysisResults(AnalysisResultEvent analysisResultEvent);

	/**
	 * Removes all analysis results of the given {@link AnalysisType} for the
	 * given {@link SessionID}.
	 * 
	 * @param sessionID
	 * @param type
	 */
	public void clearAnalysisResults(SessionID sessionID, AnalysisType type);

	/**
	 * Retrieve all {@link AnalysisResult}s for the given {@link SessionID} and
	 * {@link AnalysisType}, grouped by {@link AnalysisType}s (since the input
	 * might be a {@link CompoundActionType}, which, in general, produces
	 * {@link AnalysisResult}s with different {@link SimpleActionType}s ).
	 * 
	 * @param sessionID
	 * @param analysisType
	 * @return
	 */
	public Map<AnalysisType, List<AnalysisResult>> getAnalysisResults(
			SessionID sessionID, AnalysisType analysisType);

	/**
	 * Returns the list of {@link IAnalysisAgent}s that should be used to update
	 * the model state.
	 * 
	 * @return
	 */
	public List<IAnalysisAgent> getModelUpdatingAgents();

}
