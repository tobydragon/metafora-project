package de.dfki.lasad.modules.action.jess;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.PluggableComponentConfiguration;
import de.dfki.lasad.core.action.CompoundActionType;
import de.dfki.lasad.core.action.RuleBasedActionType;
import de.dfki.lasad.core.application.ServiceRegistry;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessFeedbackAgentConfiguration implements
		PluggableComponentConfiguration {

	static Log logger = LogFactory.getLog(JessFeedbackAgentConfiguration.class);

	private String agentID;

	private boolean provideRawResults = false;

	private Set<String> phaseIDs = new HashSet<String>();
	private List<RuleBasedActionType> ruleBaseActionTypes = new Vector<RuleBasedActionType>();
	private List<CompoundActionType> compoundActionTypes = new Vector<CompoundActionType>();

	public JessFeedbackAgentConfiguration(String localConfFileName) {
		this(localConfFileName, false);
	}

	public JessFeedbackAgentConfiguration(String confFileName,
			boolean isPathAbsolute) {
		File confFile;
		if (isPathAbsolute) {
			confFile = new File(confFileName);
		} else {
			confFile = getFileFromLocalFilename(confFileName);
		}
		readConfig(confFile);
	}

	public String getAgentID() {
		return agentID;
	}

	public List<RuleBasedActionType> getRuleBaseActionTypes() {
		return ruleBaseActionTypes;
	}

	public List<CompoundActionType> getCompoundActionTypes() {
		return compoundActionTypes;
	}

	public Set<String> getPhaseIDs() {
		return phaseIDs;
	}

	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}

	public void addPhaseID(String phaseID) {
		phaseIDs.add(phaseID);
	}

	public void setPhaseIDs(Set<String> phaseIDs) {
		this.phaseIDs = phaseIDs;
	}

	public void addRuleBaseActionType(RuleBasedActionType ruleBaseActionType) {
		this.ruleBaseActionTypes.add(ruleBaseActionType);
	}

	public void addCompoundActionType(CompoundActionType compoundActionType) {
		this.compoundActionTypes.add(compoundActionType);
	}

	private final File getFileFromLocalFilename(String localConfFileName) {
		if (ServiceRegistry.getAppConfig() == null) {
			logger.error("ServiceRegistry.getAppConfig() == null");
		}
		File confDir = ServiceRegistry.getAppConfig().getConfDir();
		File agentConfFile = new File(confDir, localConfFileName);
		return agentConfFile;
	}

	private final void readConfig(File confFile) {
		logger.info("Trying to read configuration from file '"
				+ confFile.getAbsolutePath() + "' ...");
		JessFeedbackAgentConfigParser.fillInConfigFromFile(confFile, this);
		logger.info("... Done.");
	}

	public boolean provideRawResults() {
		return provideRawResults;
	}

	public void setProvideRawResults(boolean provideRawResults) {
		this.provideRawResults = provideRawResults;
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + " agentID=" + agentID
				+ ", ruleBasedActionTypes="
				+ ruleBaseActionTypes.toArray().toString()
				+ ", compoundActionTypes="
				+ compoundActionTypes.toArray().toString();
	}

	public static void main(String[] args) {
		JessFeedbackAgentConfiguration conf = new JessFeedbackAgentConfiguration(
				"rulebased_feedback.conf.xml");
		System.out.println(conf.toString());
	}

}
