package de.dfki.lasad.events.eue.admin;

import java.util.HashMap;
import java.util.Map;

import de.dfki.lasad.events.Event;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * Provides information about all available sessions (in particular, the used
 * {@link EUEOntology}s).
 * 
 * @author Oliver Scheuer
 * 
 */
public class EUESessionListEvent extends Event implements EUEAdminEvent {

	Map<SessionID, EUEOntology> sessionIDs2Ontology = new HashMap<SessionID, EUEOntology>();

	public EUESessionListEvent(String srcCompId) {
		super(srcCompId);
	}

	public void addOntology(SessionID sessionID, EUEOntology ontology) {
		sessionIDs2Ontology.put(sessionID, ontology);
	}

	public Map<SessionID, EUEOntology> getSessionIDs2Ontology() {
		return sessionIDs2Ontology;
	}

}
