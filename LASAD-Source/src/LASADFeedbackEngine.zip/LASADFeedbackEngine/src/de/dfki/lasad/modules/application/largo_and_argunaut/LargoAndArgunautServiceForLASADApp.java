package de.dfki.lasad.modules.application.largo_and_argunaut;

import de.dfki.lasad.core.application.AppBuilder;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class LargoAndArgunautServiceForLASADApp {

	AppBuilder appBuilder;

	public LargoAndArgunautServiceForLASADApp() {
		LargoAndArgunautConfiguration configuration = new LargoAndArgunautConfiguration();
		appBuilder = new AppBuilder(configuration);
		appBuilder.doWireAndStart();
	}

	public static void main(String[] args) {
		new LargoAndArgunautServiceForLASADApp();
	}
}
