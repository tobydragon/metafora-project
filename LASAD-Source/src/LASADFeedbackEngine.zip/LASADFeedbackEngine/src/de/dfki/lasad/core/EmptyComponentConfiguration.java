package de.dfki.lasad.core;

/**
 * To be used when a {@link PluggableComponent} does not make use of
 * configuration options.
 * 
 * @author Oliver Scheuer
 */
public class EmptyComponentConfiguration implements
		PluggableComponentConfiguration {

}
