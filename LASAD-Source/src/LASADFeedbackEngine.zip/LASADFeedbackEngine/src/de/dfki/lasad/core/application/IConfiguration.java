package de.dfki.lasad.core.application;

import java.io.File;
import java.util.List;


import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.IAnalysisController;
import de.dfki.lasad.core.dataservice.DataServiceDescription;
import de.dfki.lasad.core.worldmodel.JessModelControllerDescription;

/**
 * Provides runtime classes that initialize the main 
 * architecture interface. Provides (e.g., platform-specific)
 * configuration options.
 * 
 * @author Oliver Scheuer
 * 
 */
public interface IConfiguration {

	// general configuration settings
	public File getAFHomeDir();

	// place where config files can be found
	public File getConfDir();
	
	// invariable and non-configurable components
	public IAnalysisController getAnalysisController();
	public IActionController getActionController();
	
		
	// variable and configurable components
	public JessModelControllerDescription getModelControllerDescription();
	public DataServiceDescription getDataServiceDescription();
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions();
	public List<ActionAgentDescription> getActionAgentDescriptions();
}
