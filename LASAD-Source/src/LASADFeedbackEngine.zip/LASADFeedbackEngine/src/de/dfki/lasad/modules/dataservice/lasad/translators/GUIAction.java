package de.dfki.lasad.modules.dataservice.lasad.translators;

import java.util.List;
import java.util.Vector;

import lasad.gwt.client.communication.objects.Action;

import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.objects.EUEObject;

/**
 * <p>
 * A {@link GUIAction} represents exactly one manipulation that a user made in
 * the application's GUI (i.e., creating, modifying, or deleting
 * {@link EUEObject}s). A {@link GUIAction} can subsume multiple {@link Action}s
 * for instance, when the user creates an object that is itself composed of
 * multiple components. In this case, one user interface action will be
 * represented as a sequence of {@link Action}s (one action per
 * (sub-)component). In this case each {@link GUIAction} corresponds to one
 * {@link SessionEvent}.
 * </p>
 * <p>
 * Replayed {@link GUIAction}s (cf. {@link #replayed}), on the other hand, can
 * be based on {@link Action}s that solely aim at reconstructing the latest
 * state of {@link EUEObject}s, disregarding the process of how these
 * {@link EUEObject}s have been constructed and manipulated. In this case, some
 * process characteristics might still be reconstructable through timestamp
 * information (cf. {@link #creationDate}, {@link #firstModDate}, and
 * {@link #modificationDate}), i.e., multiple {@link SessionEvent}s can be
 * produced to at least indicate important temporal "landmarks" in the life
 * cycle of the respective {@link EUEObject}s.
 * </p>
 * 
 * @author Anahuac Valero, Oliver Scheuer
 * 
 */
public class GUIAction {

	private String guiActionID;

	private SessionID sessionID;
	private String srcCompId;
	private UserID userID;
	private String userEventType;
	//private List<EUEObject> eueObjectList = new Vector<EUEObject>();
	private List<EUEObject> createEueObjectList = new Vector<EUEObject>();
	private List<EUEObject> updateEueObjectList = new Vector<EUEObject>();
	private List<EUEObject> deleteEueObjectList = new Vector<EUEObject>();
	
	private long time;

	private boolean replayed;
	private long creationDate;
	private long firstModDate;
	private long modificationDate;

	private int numActions;
	private int currentActions;

	public GUIAction(String guiActionID) {
		this.guiActionID = guiActionID;

		numActions = 0;
		currentActions = 0;
		replayed = false;
		creationDate = 0L;
		modificationDate = 0L;
	}

	public boolean isComplete() {
		boolean retVal = false;

		if (numActions == currentActions) {
			retVal = true;
		}
		return retVal;
	}

	public boolean isReplayedAction() {
		return replayed;
	}

	public void setIsReplayedAction(boolean fromGraph) {
		this.replayed = fromGraph;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public long getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(long creationDate) {
		this.creationDate = creationDate;
	}

	public long getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(long modificationDate) {
		this.modificationDate = modificationDate;
	}

	public long getFirstModDate() {
		return firstModDate;
	}

	public void setFirstModDate(long firstModDate) {
		this.firstModDate = firstModDate;
	}

	public String getGuiActionID() {
		return guiActionID;
	}

	public void setGuiActionID(String guiActionID) {
		this.guiActionID = guiActionID;
	}

	public SessionID getSessionID() {
		return sessionID;
	}

	public void setSessionID(SessionID sessionID) {
		this.sessionID = sessionID;
	}

	public String getSrcCompId() {
		return srcCompId;
	}

	public void setSrcCompId(String srcCompId) {
		this.srcCompId = srcCompId;
	}

	public UserID getUserID() {
		return userID;
	}

	public void setUserID(UserID userID) {
		this.userID = userID;
	}

//	public List<EUEObject> getEueObjectList() {
//		return eueObjectList;
//	}
//
//	public void addEueObject(EUEObject eueObject) {
//		eueObjectList.add(eueObject);
//	}

	public List<EUEObject> getCreateEueObjectList() {
		return createEueObjectList;
	}

	public void addEueObject2CreateList(EUEObject createEueObject) {
		this.createEueObjectList.add(createEueObject);
	}

	public List<EUEObject> getUpdateEueObjectList() {
		return updateEueObjectList;
	}

	public void addEueObject2UpdateList(EUEObject updateEueObject) {
		this.updateEueObjectList.add(updateEueObject);
	}

	public List<EUEObject> getDeleteEueObjectList() {
		return deleteEueObjectList;
	}

	public void addEueObject2DeleteList(EUEObject deleteEueObject) {
		this.deleteEueObjectList.add(deleteEueObject);
	}

	public int getNumActions() {
		return numActions;
	}

	public void setNumActions(int numActions) {
		this.numActions = numActions;
	}

	public void decreaseNumActionsByOne() {
		numActions--;
	}

	public int getCurrentActions() {
		return currentActions;
	}

	public void setCurrentActions(int currentActions) {
		this.currentActions = currentActions;
	}

	public void increaseCurrentActionsByOne() {
		currentActions++;
	}

	public String getUserEventType() {
		return userEventType;
	}

	public void setUserEventType(String userEventType) {
		this.userEventType = userEventType;
	}

}
