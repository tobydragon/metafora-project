package de.dfki.lasad.events.eue.admin;

import de.dfki.lasad.events.eue.EUEEvent;

/**
 * Marker interface. {@link EUEAdminEvent}s are not associated with one specific
 * session.
 * 
 * @author Oliver Scheuer
 * 
 */
public interface EUEAdminEvent extends EUEEvent {

}
