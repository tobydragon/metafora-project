package de.dfki.lasad.modules.analysis.deeploop.graphml;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.graphdrawing.graphml.xmlns.x1.DataType;
import org.graphdrawing.graphml.xmlns.x1.EdgeType;
import org.graphdrawing.graphml.xmlns.x1.GraphmlDocument;
import org.graphdrawing.graphml.xmlns.x1.NodeType;

import de.dfki.lasad.core.dataservice.cf.data.CFInputSourceProvider;

/**
 * Adapter class that facilitates accessing important properties from a
 * {@link GraphmlDocument}.
 * 
 * @author Oliver Scheuer
 * 
 */
public class GraphMLReader {

	private GraphmlDocument graphML;

	private List<String> nodeIDs = new Vector<String>();
	private Map<String, Map<String, String>> nodeID2properties = new HashMap<String, Map<String, String>>();

	private List<String> linkIDs = new Vector<String>();
	private Map<String, Map<String, String>> linkID2properties = new HashMap<String, Map<String, String>>();

	public GraphMLReader(GraphmlDocument graphML) {
		this.graphML = graphML;
		analyzeNodes();
		analyzeLinks();
	}

	public String getGraphDataAsString() {
		StringBuffer buffer = new StringBuffer();

		buffer.append("Nodes" + "\n");
		for (String nodeID : nodeIDs) {
			buffer.append(nodeID + "\n");
			Map<String, String> props = nodeID2properties.get(nodeID);
			for (String propName : props.keySet()) {
				String value = props.get(propName);
				buffer.append("\t" + propName + ": " + value + "\n");
			}
		}

		buffer.append("Links" + "\n");
		for (String linkID : linkIDs) {
			buffer.append(linkID + "\n");
			Map<String, String> props = linkID2properties.get(linkID);
			for (String propName : props.keySet()) {
				String value = props.get(propName);
				buffer.append("\t" + propName + ": " + value + "\n");
			}
		}

		return buffer.toString();
	}

	public String getNodeProperty(String nodeID, String propertyName) {
		Map<String, String> nodeProps = nodeID2properties.get(nodeID);
		return nodeProps.get(propertyName);
	}

	public String getLinkProperty(String linkID, String propertyName) {
		Map<String, String> linkProps = linkID2properties.get(linkID);
		return linkProps.get(propertyName);
	}

	public List<String> getNodeIDs() {
		return nodeIDs;
	}

	public List<String> getLinkIDs() {
		return linkIDs;
	}

	private void analyzeNodes() {
		NodeType[] nodeTypeArray = graphML.getGraphml().getGraphArray(0)
				.getNodeArray();

		int size = nodeTypeArray.length;

		for (int i = 0; i < size; ++i) {
			String id = nodeTypeArray[i].getId();
			nodeIDs.add(id);
			DataType[] dataTypeArray = nodeTypeArray[i].getDataArray();
			Map<String, String> properties = analyzeProperties(dataTypeArray);
			nodeID2properties.put(id, properties);
		}
	}

	private void analyzeLinks() {
		EdgeType[] linkTypeArray = graphML.getGraphml().getGraphArray(0)
				.getEdgeArray();

		int size = linkTypeArray.length;

		for (int i = 0; i < size; ++i) {
			String id = linkTypeArray[i].getId();
			linkIDs.add(id);

			DataType[] dataTypeArray = linkTypeArray[i].getDataArray();
			Map<String, String> properties = analyzeProperties(dataTypeArray);
			linkID2properties.put(id, properties);

			properties.put(GraphMLVocabulary.LINK_SOURCE, linkTypeArray[i]
					.getSource());
			properties.put(GraphMLVocabulary.LINK_TARGET, linkTypeArray[i]
					.getTarget());
		}
	}

	private Map<String, String> analyzeProperties(DataType[] dataTypeArray) {
		Map<String, String> properties = new HashMap<String, String>();
		int size = dataTypeArray.length;
		// System.out.println("---------------------------------");
		for (int i = 0; i < size; ++i) {
			String key = dataTypeArray[i].getKey();
			String value = dataTypeArray[i].newCursor().getTextValue();

			// System.out.println(key + ": " + value);
			properties.put(key, value);
		}
		return properties;
	}

}
