package de.dfki.lasad.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import junit.framework.TestCase;

public class XmlHelperTest extends TestCase {
	Log logger = LogFactory.getLog(XmlHelperTest.class);
	
	String simpleXml;
	
	public void setUp(){
		simpleXml=TestXmlData.createUserXmlString;
	}
	
	public void testSimpleXml(){
		XmlHelper xmlHelper = new XmlHelper(simpleXml);
		//logger.debug(xmlHelper.getElement());
		assertEquals("CREATE_USER", xmlHelper.getElementAttributeString("actionType", "type"));
	}
}
