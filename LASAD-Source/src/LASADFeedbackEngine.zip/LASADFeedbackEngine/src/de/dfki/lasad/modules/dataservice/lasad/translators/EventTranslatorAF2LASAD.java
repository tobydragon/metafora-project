package de.dfki.lasad.modules.dataservice.lasad.translators;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.application.DisplayedObjectIDTracker;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.models.action.ActionComponent;
import de.dfki.lasad.models.action.ActionComponentSpec;
import de.dfki.lasad.models.action.ActionSpec;
import de.dfki.lasad.models.action.AnalysisMirroringActionSpec;
import de.dfki.lasad.models.action.XmppActionComponent;
import de.dfki.lasad.models.action.XmppActionSpec;
import de.dfki.lasad.models.action.Message;
import de.dfki.lasad.models.action.MessageWithHighlighting;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.analysis.AnalyzableEntity;
import de.dfki.lasad.models.analysis.BinaryResult;
import de.dfki.lasad.models.analysis.NoAnalysisResults;
import de.dfki.lasad.models.eue.EUEID;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.UserIDAll;
import de.dfki.lasad.models.eue.objects.EUEObjectID;
import de.dfki.lasad.modules.dataservice.lasad.ActionPackageFactory;
import de.dfki.lasad.modules.dataservice.lasad.translators.xmpp.XmppToActionPackage;
import de.dfki.lasad.util.CommonFormatXmlHelper;
import de.uds.commonformat.CfAction;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class EventTranslatorAF2LASAD {

	Log logger = LogFactory.getLog(EventTranslatorAF2LASAD.class);

	private ActionPackageFactory packageFactory;

	public EventTranslatorAF2LASAD(ActionPackageFactory packageFactory) {
		this.packageFactory = packageFactory;
	}

	public List<ActionPackage> translate(ActionSpecEvent actionSpecEvent) {
		SessionID sessionID = actionSpecEvent.getSessionID();

		
		List<ActionPackage> actionPackages = new Vector<ActionPackage>();
			for (ActionSpec actionSpec : actionSpecEvent.getActionSpecs()) {
				actionPackages.addAll(translateActionSpec(actionSpec, sessionID));
			}
		
		return actionPackages;
	}

	private List<ActionPackage> translateActionSpec(ActionSpec actionSpec, SessionID sessionID) {
		UserID userID = actionSpec.getActionRecipient();
		List<ActionPackage> actionPackages = new Vector<ActionPackage>();
		
		//this actions happen outside of a session(map) so they do not need a sessionID
		if (actionSpec instanceof XmppActionSpec) {
			 actionPackages.add(translateXmppActionSpec((XmppActionSpec)actionSpec));
		}
		
		//these actions require a sessionID
		else if (sessionID != null){
			if (actionSpec instanceof AnalysisMirroringActionSpec) {
				actionPackages = translateAnalysisMirroringActionSpec((AnalysisMirroringActionSpec) actionSpec, sessionID, userID);
			} 
			else if (actionSpec instanceof ActionComponentSpec) {
				actionPackages.add(translateActionComponentSpec((ActionComponentSpec) actionSpec, sessionID, userID));
			}
			else {
				logger.error("Cannot translate ActionSpec. Unknown type: " + actionSpec.getClass().getName()); 
				actionPackages = new Vector<ActionPackage>();
			}
		}
		else {
			logger.error("[translateActionSpec] sessionID is null, no action packages created for actionSpec - " + actionSpec.toString());
		}
		
		return actionPackages;
	}

	private ActionPackage translateXmppActionSpec(XmppActionSpec actionSpec) {
		List<Action> actionsToSend = new Vector<Action>();
		
		for (ActionComponent aComponent : actionSpec.getActionComponents()) {
			if (aComponent instanceof XmppActionComponent) {
				CfAction action = ((XmppActionComponent)aComponent).getAction();
				actionsToSend.addAll(XmppToActionPackage.translate(action, packageFactory));
			}
		}
		ActionPackage aPackage = packageFactory.createActionPackage(actionsToSend);
		return aPackage;
	}

	private List<ActionPackage> translateAnalysisMirroringActionSpec(
			AnalysisMirroringActionSpec actionSpec, SessionID sessionID, UserID userID) {
		List<ActionPackage> actionPackageList = new Vector<ActionPackage>();

		Set<AnalysisResult> analysisResults = actionSpec.getActionComponents();

		List<AnalysisResult> resultsToBeDisplayed = new Vector<AnalysisResult>();

		boolean atLeastOnePosResult = false;
		for (AnalysisResult analysisResult : analysisResults) {
			if (!isNegativeBinaryResults(analysisResult)
					&& !isEmptyResultSet(analysisResult)) {
				resultsToBeDisplayed.add(analysisResult);
				atLeastOnePosResult = true;
			}
		}

		if (!atLeastOnePosResult) {
			ActionPackage noPositiveResultsMessage = getNoPositiveResultsMessage(sessionID, userID);
			actionPackageList.add(noPositiveResultsMessage);
			return actionPackageList;
		}

		ActionPackage actionPackage = translateAnalysisResults(resultsToBeDisplayed, sessionID, userID);
		actionPackageList.add(actionPackage);
		return actionPackageList;
	}

	private ActionPackage getNoPositiveResultsMessage(SessionID sessionID, UserID userID) {
		List<Action> actionsToSend = new Vector<Action>();

		String message = "No results.";

		String mapID = sessionID.getIdAsString();
		String recipientID = getRecipientID(userID);

		List<String> highlightableObjectIDs = new Vector<String>();

		Action clusterIndicator = packageFactory.createFeedbackMessage(mapID,
				recipientID, message, null, highlightableObjectIDs,
				new HashMap<String, String>());
		actionsToSend.add(clusterIndicator);
		ActionPackage aPackage = packageFactory
				.createActionPackage(actionsToSend);
		return aPackage;
	}

	private ActionPackage translateActionComponentSpec(
			ActionComponentSpec actionSpec, SessionID sessionID, UserID userID) {
		List<Action> actionsToSend = new Vector<Action>();

		String mapID = sessionID.getIdAsString();
		String recipientID = getRecipientID(userID);
		List<String> highlightableObjectIDs = new Vector<String>();
		String shortMessageString = "NOT SPECIFIED";
		String longMessageString = null;
		Map<String, String> additionalParams = new HashMap<String, String>();
		for (ActionComponent aComponent : actionSpec.getActionComponents()) {
			if (aComponent instanceof Message) {
				Message message = (Message) aComponent;
				shortMessageString = message.getMessageShort();
				longMessageString = message.getMessageLong();
				additionalParams = message.getParameters();
			}
			if (aComponent instanceof MessageWithHighlighting) {
				MessageWithHighlighting highlighting = (MessageWithHighlighting) aComponent;
				AnalyzableEntity entity = highlighting.getAnalyzableEntity();
				for (EUEID componentID : entity.getEntityComponents()) {
					highlightableObjectIDs.add(componentID.getIdAsString());
				}
			}

			Action textMessageAction = packageFactory.createFeedbackMessage(
					mapID, recipientID, shortMessageString, longMessageString,
					highlightableObjectIDs, additionalParams);
			actionsToSend.add(textMessageAction);
		}
		ActionPackage aPackage = packageFactory
				.createActionPackage(actionsToSend);
		return aPackage;
	}

	private ActionPackage translateAnalysisResults(
			List<AnalysisResult> analysisResults, SessionID sessionID, UserID userID) {
		List<Action> actionsToSend = new Vector<Action>();
		for (AnalysisResult analysisResult : analysisResults) {

			List<String> highlightableObjectIDs = getHighlightableObjects(analysisResult);

			// if (highlightableObjectIDs.size() >= 1) {
			AnalysisType analysisType = analysisResult.getAnalysisType();
			String messageP1_category = analysisType.getDisplayName();
			String messageP2_objectDisplayIDs = composeDisplayIDsString(analysisResult, sessionID);
			String messageP3_value = composeValueString(analysisResult);

			String message = messageP1_category + messageP2_objectDisplayIDs
					+ messageP3_value;

			String mapID = sessionID.getIdAsString();
			String recipientID = getRecipientID(userID);

			Action clusterIndicator = packageFactory.createFeedbackMessage(
					mapID, recipientID, message, null, highlightableObjectIDs,
					new HashMap<String, String>());
			actionsToSend.add(clusterIndicator);
			// }
		}
		ActionPackage aPackage = packageFactory
				.createActionPackage(actionsToSend);
		return aPackage;
	}

	private String composeDisplayIDsString(AnalysisResult analysisResult, SessionID sessionID) {
		String messageP2_objectDisplayIDs = "";
		boolean isFirst = true;
		for (EUEID eueID : analysisResult.getAnalyzableEntity()
				.getEntityComponents()) {
			String displayID = DisplayedObjectIDTracker.getDisplayID(sessionID,
					eueID);

			String entityType = "";
			if (eueID instanceof EUEObjectID) {
				entityType = "Element(s)";
			}

			if (displayID != null) {
				if (isFirst) {
					messageP2_objectDisplayIDs += "; " + entityType + ": ";
				} else {
					messageP2_objectDisplayIDs += ", ";
				}
				messageP2_objectDisplayIDs += displayID;
				isFirst = false;
			}
		}
		return messageP2_objectDisplayIDs;
	}

	private String composeValueString(AnalysisResult analysisResult) {
		if (analysisResult instanceof BinaryResult) {
			return "";
		} else {
			return analysisResult.getValueAsString();
		}
	}

	private String getRecipientID(UserID userID) {
		if (userID instanceof UserIDAll) {
			return "";
		} else {
			return userID.getIdAsString();
		}
	}

	private boolean isNegativeBinaryResults(AnalysisResult analysisResult) {
		if (analysisResult instanceof BinaryResult) {
			BinaryResult bResult = (BinaryResult) analysisResult;
			if (bResult.getValue() == false) {
				return true;
			}

		}
		return false;
	}

	private boolean isEmptyResultSet(AnalysisResult analysisResult) {
		return analysisResult instanceof NoAnalysisResults;
	}

	private List<String> getHighlightableObjects(AnalysisResult analysisResult) {
		List<String> idList = new Vector<String>();

		for (EUEID eueID : analysisResult.getAnalyzableEntity()
				.getEntityComponents()) {
			if (eueID instanceof EUEObjectID) {
				idList.add(eueID.getIdAsString());
			}
		}
		return idList;
	}
}
