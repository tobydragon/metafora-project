package de.dfki.lasad.core.worldmodel;

import java.util.Set;

import de.dfki.lasad.core.analysis.OntologyChecker;
import de.dfki.lasad.core.analysis.SimpleOntologyChecker;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class ModelControllerConfiguration implements
		IModelControllerConfiguration {

	protected OntologyChecker ontologyChecker;

	public ModelControllerConfiguration() {
		ontologyChecker = new SimpleOntologyChecker();
	}

	public ModelControllerConfiguration(Set<String> supportedOntologyIDs) {
		ontologyChecker = new SimpleOntologyChecker(supportedOntologyIDs);
	}

	@Override
	public OntologyChecker getOntologySupportChecker() {
		return ontologyChecker;
	}
}
