package de.dfki.lasad.core.dataservice;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.PluggableComponentConfiguration;
import de.dfki.lasad.core.PluggableComponentDescription;

public class DataServiceDescription extends PluggableComponentDescription {

	public DataServiceDescription(String componentID, String className) {
		super(className);
		setComponentID(componentID);
	}

	public DataServiceDescription(String componentID, String className,
			PluggableComponentConfiguration configuration) {
		super(className, configuration);
		setComponentID(componentID);
	}

	public IDataService createInstance() throws ComponentInitException {
		IDataService dataService = (IDataService) super.createInstance();
		return dataService;
	}
}
