package de.dfki.lasad.core.application;

import java.util.List;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.IAnalysisController;
import de.dfki.lasad.core.dataservice.DataServiceDescription;
import de.dfki.lasad.core.worldmodel.JessModelControllerDescription;

/**
 * A minimal {@link IConfiguration} that only provides useful path information
 * (application home and conf home).
 * 
 * @author Oliver Scheuer
 * 
 */
public class MinimalAppConfiguration extends AbstractAppConfiguration {

	static Log logger = LogFactory.getLog(MinimalAppConfiguration.class);

	public MinimalAppConfiguration() {
		super();
	}

	@Override
	public DataServiceDescription getDataServiceDescription() {
		logger.warn("This class is not intended to provide "
				+ DataServiceDescription.class.getName() + ". Return null.");
		return null;
	}

	@Override
	public IAnalysisController getAnalysisController() {
		logger.warn("This class is not intended to provide "
				+ IAnalysisController.class.getName() + ". Return null.");
		return null;
	}

	@Override
	public IActionController getActionController() {
		logger.warn("This class is not intended to provide "
				+ IActionController.class.getName() + ". Return null.");
		return null;
	}

	@Override
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions() {
		logger.warn("This class is not intended to provide "
				+ AnalysisAgentDescription.class.getName()
				+ ". Return empty list.");
		return new Vector<AnalysisAgentDescription>();
	}

	@Override
	public List<ActionAgentDescription> getActionAgentDescriptions() {
		logger.warn("This class is not intended to provide "
				+ ActionAgentDescription.class.getName()
				+ ". Return empty list.");
		return new Vector<ActionAgentDescription>();
	}

	@Override
	public JessModelControllerDescription getModelControllerDescription() {
		logger.warn("This class is not intended to provide "
				+ JessModelControllerDescription.class.getName()
				+ ". Return null.");
		return null;
	}
}
