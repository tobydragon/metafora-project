package de.dfki.lasad.modules.dataservice.lasad.rmi;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;


import lasad.ServerInterface;
import lasad.gwt.client.communication.objects.ActionPackage;


public class RemoteActionSenderRMI implements ServerInterface, Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1157194518661061948L;
	private LASADDataServiceRMI lasadDataService;
	private LASADDataServiceRMIConfiguration configuration;
	private ServerInterface server;
	
	public RemoteActionSenderRMI() {
		super();
		//logger.debug("Service RMI initialized.");
	}
	
	/*
	 * To identify a service, we specify an RMI URL. 
	 * The URL contains the hostname on which the service is located, 
	 * and the logical name of the service. 
	 * This returns a Server instance, 
	 * which can then be used just like a local object reference. 
	 * We can call the methods just as if we'd created an instance of the remote Server ourselves.
	 */
	private ServerInterface getRemoteServerInstance(){
		String address = "rmi://" + configuration.getServerIP() + ":" + 
						configuration.getServerPort() + "/" + configuration.getServerName();
		System.out.println("address: " + address);
		ServerInterface serverI = null;
		try {
			serverI = (ServerInterface) Naming.lookup(address);
		} catch (MalformedURLException e) {
			System.out.println("Error getRemoteServerInstance: " + e.getClass()
					+ ": " + e.getMessage());
			e.printStackTrace();
		} catch (RemoteException e) {
			System.out.println("Error getRemoteServerInstance: " + e.getClass()
					+ ": " + e.getMessage());
			e.printStackTrace();
		} catch (NotBoundException e) {
			System.out.println("Error getRemoteServerInstance: " + e.getClass()
					+ ": " + e.getMessage());
			e.printStackTrace();
		}
		return serverI;
	}

	@Override
	public void doActionOnServer(ActionPackage p) throws RemoteException {
		if(server == null) {
			server = getRemoteServerInstance();
		}
		server.doActionOnServer(p);
		
	}
	
	public void init(){
		// Call registry for Server
		server = getRemoteServerInstance();
	}
	
	/*
	 * register.
	 */
	public void register(LASADDataServiceRMI lasadDataService) {
		this.lasadDataService = lasadDataService;
	}
	
	public void setConfiguration(LASADDataServiceRMIConfiguration configuration){
		this.configuration = configuration;
	}

}
