package de.dfki.lasad.modules.action.analysismirroring;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.PluggableComponentDescription;
import de.dfki.lasad.core.action.AbstractActionAgent;
import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.action.ActionType;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.UserFeedbackRequestEvent;
import de.dfki.lasad.models.action.ActionComponentSpec;
import de.dfki.lasad.models.action.AnalysisMirroringActionSpec;
import de.dfki.lasad.models.action.Message;
import de.dfki.lasad.models.analysis.AnalysisQuery;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.analysis.NoAnalysisResults;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackTypeID;

/**
 * Instances of this class accept all {@link UserFeedbackRequestEvent}s and
 * directly translate {@link FeedbackTypeID}s into {@link AnalysisQuery}.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AnalysisMirroringAgent extends AbstractActionAgent {

	Log logger = LogFactory.getLog(AnalysisMirroringAgent.class);

	public AnalysisMirroringAgent() {
		String classname = getClass().getName();
		description = new ActionAgentDescription(classname);
		description.setComponentID(classname);
	}

	@Override
	public void configure(PluggableComponentDescription description) {
		// ignore, static configuration
	}

	@Override
	public void onEUEEvent(EUESessionEvent eueEvent) {
		if (eueEvent instanceof UserFeedbackRequestEvent) {
			logger.debug("Add event to queue: " + eueEvent.toString());
			addEventToQueue(eueEvent);
		} else {
			// ignore all EUEEvents except feedback requests
		}
	}

	@Override
	public void onAnalysisResultEvent(AnalysisResultEvent analysisResultEvent) {
		addEventToQueue(analysisResultEvent);
	}

	@Override
	public void onActionSpecEvent(ActionSpecEvent actionSpecEvent) {
		// ignore actions from other agents
	}

	@Override
	public void processUserFeedbackRequestEvent(
			UserFeedbackRequestEvent feedbackRequestEvent) {
		logger.debug("Start processing event: "
				+ feedbackRequestEvent.toString());
		FeedbackTypeID feedbackTypeID = feedbackRequestEvent
				.getFeedbackRequestSpec().getFeedbackTypeID();

		AnalysisType analysisType = getAnalysisType(feedbackTypeID);
		AnalysisQuery query = new AnalysisQuery();
		query.addAnalysisType(analysisType);

		SessionID sessionID = feedbackRequestEvent.getSessionID();
		String transactionId = addPendingRequestAndReturnTransactionId(feedbackRequestEvent);
		String actionAgentID = description.getComponentID();
		AnalysisRequestEvent analyisRequestEvent = new AnalysisRequestEvent(
				query, transactionId, sessionID, actionAgentID);

		forwardToActionController(analyisRequestEvent);
		logger.debug("Send out analysis request: "
				+ analyisRequestEvent.toString());
	}

	private AnalysisType getAnalysisType(FeedbackTypeID feedbackTypeID) {
		String analysisAgentID = feedbackTypeID.getFeedbackProvider();
		String analysisTypeID = feedbackTypeID.getFeedbackType();

		AnalysisType analysisType = ServiceRegistry.getAnalysisType(
				analysisAgentID, analysisTypeID);
		if (analysisType == null) {
			logger
					.warn("Could not retrieve AnalysisType for ("
							+ analysisAgentID
							+ ", "
							+ analysisTypeID
							+ ") from ServiceRegistry. Generate new one (will only contain id props).");
			analysisType = new AnalysisType(analysisAgentID, analysisTypeID);
		}
		return analysisType;
	}

	@Override
	public void processEUEEvent(EUESessionEvent eueEvent) {
		// ignore EUEEvents other than feedback requests
	}

	@Override
	public void processAnalysisResultEvent(
			AnalysisResultEvent analysisResultEvent) {
		String actionAgentID = description.getComponentID();
		logger.info(actionAgentID + ": processAnalysisResultEvent");

		String transactionID = analysisResultEvent.getTransactionID();
		UserFeedbackRequestEvent feedbackRequestEvent = removePendingFeedbackRequest(transactionID);

		SessionID sessionID = analysisResultEvent.getSessionID();

		AnalysisMirroringActionSpec actionSpec = new AnalysisMirroringActionSpec();

		// Only the original requester will receive mirroring feedback
		UserID originalRequestorID = feedbackRequestEvent.getUserID();
		actionSpec.setActionRecipient(originalRequestorID);

		ActionSpecEvent actionSpecEvent = new ActionSpecEvent(sessionID,
				actionAgentID);

		List<AnalysisResult> results = analysisResultEvent.getResultsAsList();
		if (results.isEmpty()) {
			//sendNoFeedbackAvailableMessage(actionSpecEvent, originalRequestorID);
			//return;
			FeedbackTypeID fType = feedbackRequestEvent.getFeedbackRequestSpec().getFeedbackTypeID();
			AnalysisType aType = ServiceRegistry.getAnalysisType(fType
					.getFeedbackProvider(), fType.getFeedbackType());
			NoAnalysisResults noResults = new NoAnalysisResults(aType);
			actionSpec.addActionComponent(noResults);
			//return;
		}

		for (AnalysisResult result : results) {
			actionSpec.addActionComponent(result);
		}
		actionSpecEvent.addActionSpec(actionSpec);
		forwardToActionController(actionSpecEvent);
	}

	/**
	private void sendNoFeedbackAvailableMessage(
			ActionSpecEvent incompleteSpecEvent, UserID originalRequestorID) {
		ActionComponentSpec componentSpec = new ActionComponentSpec();
		componentSpec.setActionRecipient(originalRequestorID);
		String messageString = "No feedback available";
		TextMessage message = new TextMessage(messageString);
		componentSpec.addActionComponent(message);
		incompleteSpecEvent.addActionSpec(componentSpec);
		forwardToActionController(incompleteSpecEvent);
	}
	*/

	@Override
	public void processActionSpecEvent(ActionSpecEvent event) {
		// ignore
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AnalysisMirroringAgent [actionAgentID=");
		builder.append(description.getComponentID());
		builder.append("]");
		return builder.toString();
	}

}
