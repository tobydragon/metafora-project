package de.dfki.lasad.modules.dataservice.lasad;

import java.util.Set;

import de.dfki.lasad.core.PluggableComponentConfiguration;

public interface LASADDataServiceConfiguration extends PluggableComponentConfiguration {
	
	public String getUsername();
	public String getPassword();
	public int getHeartBeatRate();
	public boolean doDeploy();
	public Set<String> getMapsToJoinOnStartup();
	public boolean doJoinAllPossibleMapsOnStartup();
	public String getActionListenerWSDeploymentPath();
	public String getServerIP();
	public int getServerPort();
	public String getServerName();
	public int getServerRegistryPort();

}
