package de.dfki.lasad.modules.analysis;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Specifies how to map (element types, oldProp, oldVal) triples to (newProp,
 * newVal) pairs (flat representation). Semantic input units, which are fully
 * specified by a pair (element types, oldProp), are mapped to a (newProp).
 * 
 * @author Oliver Scheuer
 * 
 */
public class SimplePropertyMappingsConfiguration {

	// oldElementType --> newProp
	private Map<String, String> oldType2newType = new HashMap<String, String>();

	// (oldElementType, oldProp) --> newProp
	private Map<StringPair, String> oldProp2newProp = new HashMap<StringPair, String>();

	// (newElementType, newProp) --> should ListProperty be used as type?
	// (alternative: SimpleProperty)
	private Map<StringPair, Boolean> newProp2isListProp = new HashMap<StringPair, Boolean>();

	// (oldElementType, oldProp, oldVal) --> newVal
	private Map<StringTriple, String> oldVal2newVal = new HashMap<StringTriple, String>();

	// (oldElementType, oldProp)
	private boolean areAllPropsRelevant = true;

	private boolean areAllPropsOfListType = false;

	// (oldElementType, oldProp)
	private HashSet<StringPair> relevantProps = new HashSet<StringPair>();

	public void addElemTypeMapping(String oldElementType, String newElementType) {
		oldType2newType.put(oldElementType, newElementType);
	}

	public void addPropMapping(String oldElementType, String oldProp,
			String newProp) {
		oldProp2newProp.put(new StringPair(oldElementType, oldProp), newProp);
	}

	public void addPropType(String newElementType, String newProp,
			boolean isListType) {
		newProp2isListProp.put(new StringPair(newElementType, newProp),
				isListType);
	}

	public void addRelevantProp(String oldElementType, String oldProp) {
		// changes the default behavior that all props are relevant
		areAllPropsRelevant = false;
		relevantProps.add(new StringPair(oldElementType, oldProp));
	}

	public void addValMapping(String elementType, String oldProp,
			String oldVal, String newVal) {
		oldVal2newVal.put(new StringTriple(elementType, oldProp, oldVal),
				newVal);
	}

	public String getNewElemType(String oldElementType) {
		String newType = oldType2newType.get(oldElementType);
		if (newType == null) {
			return oldElementType;
		}
		return newType;
	}

	public String getNewPropName(String elementType, String oldPropName) {
		String newPropName = oldProp2newProp.get(new StringPair(elementType,
				oldPropName));
		if (newPropName == null) {
			return oldPropName;
		}
		return newPropName;
	}

	public boolean isPropOfListType(String newElementType, String newProp) {
		if (areAllPropsOfListType) {
			return true;
		}
		Boolean isPropOfListType = newProp2isListProp.get(new StringPair(
				newElementType, newProp));
		if (isPropOfListType == null) {
			// default: if not specified prop is NOT of list type
			return false;
		}
		return isPropOfListType;
	}

	public String getNewValName(String elementType, String oldProp,
			String oldVal) {
		String newVal = oldVal2newVal.get(new StringTriple(elementType,
				oldProp, oldVal));

		if (newVal == null) {
			return oldVal;
		}
		return newVal;
	}

	public boolean isPropRelevant(String oldElementType, String oldProp) {
		if (areAllPropsRelevant) {
			return true;
		}
		return relevantProps.contains(new StringPair(oldElementType, oldProp));
	}

	public void setAllPropsOfListType(boolean areAllPropsOfListType) {
		this.areAllPropsOfListType = areAllPropsOfListType;
	}

	private class StringPair {

		String first;
		String second;

		public StringPair(String first, String second) {
			this.first = first;
			this.second = second;
		}

		@Override
		public String toString() {
			return "[" + first + ", " + second + "]";
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + ((first == null) ? 0 : first.hashCode());
			result = prime * result
					+ ((second == null) ? 0 : second.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			StringPair other = (StringPair) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (first == null) {
				if (other.first != null)
					return false;
			} else if (!first.equals(other.first))
				return false;
			if (second == null) {
				if (other.second != null)
					return false;
			} else if (!second.equals(other.second))
				return false;
			return true;
		}

		private SimplePropertyMappingsConfiguration getOuterType() {
			return SimplePropertyMappingsConfiguration.this;
		}

	}

	private class StringTriple {

		String first;
		String second;
		String third;

		public StringTriple(String first, String second, String third) {
			this.first = first;
			this.second = second;
			this.third = third;
		}

		@Override
		public String toString() {
			return "[" + first + ", " + second + ", " + third + "]";
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + ((first == null) ? 0 : first.hashCode());
			result = prime * result
					+ ((second == null) ? 0 : second.hashCode());
			result = prime * result + ((third == null) ? 0 : third.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			StringTriple other = (StringTriple) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (first == null) {
				if (other.first != null)
					return false;
			} else if (!first.equals(other.first))
				return false;
			if (second == null) {
				if (other.second != null)
					return false;
			} else if (!second.equals(other.second))
				return false;
			if (third == null) {
				if (other.third != null)
					return false;
			} else if (!third.equals(other.third))
				return false;
			return true;
		}

		private SimplePropertyMappingsConfiguration getOuterType() {
			return SimplePropertyMappingsConfiguration.this;
		}

	}

}
