package de.dfki.lasad.util;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

public class CommonFormatXmlHelper extends XmlHelper {
	Log logger = LogFactory.getLog(CommonFormatXmlHelper.class);
	
	public CommonFormatXmlHelper(String actionXmlString) {
		super(actionXmlString);
	}
	
	public String getObjectPropetyString(String objectType, String propertyName){
		List<Element> objectElements = doc.getRootElement().getChildren("object");
		for (Element objectElement : objectElements ){
			if (objectElement.getAttribute("type").getValue().equals(objectType)){
				List<Element> propertyElements = objectElement.getChild("properties").getChildren("property"); 
				for(Element propertyElement : propertyElements){
					if (propertyElement.getAttribute("name").getValue().equals(propertyName)){
						return propertyElement.getAttribute("value").getValue();
					}
				}
			}
		}
		return null;
	}
	
	public String getObjectString(){
		return doc.getRootElement().getChild("object").getValue();
	}
	
	public long getTime(){
		if (doc != null && doc.getRootElement()!= null){
			String timeStr = doc.getRootElement().getAttributeValue("time");
			//logger.debug("[getTime] timeStr - " + timeStr);
			if (timeStr != null){
				try {
					long time = Long.valueOf(timeStr);
					return time;
				}
				catch (NumberFormatException e){
					logger.error("[getTime] Bad format of time string - " + timeStr);
					return 0;
				}
				
			}
			else {
				logger.error("[getTime] No time string found on xml - " + doc.toString());
				return 0;
			}
		}
		else {
			logger.error("[getTime] No doc or root element found.");
			return 0;
		}
	}
	
	public boolean setTime(long time){
		if (doc != null && doc.getRootElement()!= null){
			doc.getRootElement().setAttribute("time", Long.toString(time));
			return true;
		}
		else {
			logger.error("[setTime] No doc or root element found.");
			return false;
		}
	}
	
	public boolean setActionType(String actionType){
		if (doc != null && doc.getRootElement()!= null && doc.getRootElement().getChild("actionType") != null){
			doc.getRootElement().getChild("actionType").setAttribute("type", actionType);
			return true;
		}
		logger.error("[setActionType] No doc or root element or actionType found.");
		return false;
	}
	
	public boolean setUserId(String userId){
		if (doc != null && doc.getRootElement()!= null && doc.getRootElement().getChild("user") != null){
			doc.getRootElement().getChild("user").setAttribute("id", userId);
			return true;
		}
		logger.error("[setActionType] No doc or root element or actionType found.");
		return false;
	}
	
	public CommonFormatXmlHelper copy(){
		return new CommonFormatXmlHelper(toString());
	}

}
