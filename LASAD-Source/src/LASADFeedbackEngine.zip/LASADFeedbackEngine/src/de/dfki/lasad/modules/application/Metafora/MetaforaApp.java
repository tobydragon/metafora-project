package de.dfki.lasad.modules.application.Metafora;

import de.dfki.lasad.core.application.AppBuilder;
import de.dfki.lasad.modules.application.largo.GraphGrammarRMIServiceForLASADApp;
import de.dfki.lasad.modules.application.largo.GraphGrammarRMIServicesForLASADConfiguration;

public class MetaforaApp {
	
	AppBuilder appBuilder;

	public MetaforaApp() {
		MetaforaConfiguration configuration = new MetaforaConfiguration();
		appBuilder = new AppBuilder(configuration);
		appBuilder.doWireAndStart();
	}

	public static void main(String[] args) {
		new MetaforaApp();
	}

}
