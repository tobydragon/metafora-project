package de.dfki.lasad.modules.application.eventcounter;

import de.dfki.lasad.core.application.AppBuilder;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class EventCounterServicesForLASADApp {

	AppBuilder appBuilder;

	public EventCounterServicesForLASADApp() {
		EventCounterServicesForLASADConfiguration configuration = new EventCounterServicesForLASADConfiguration();
		appBuilder = new AppBuilder(configuration);
		appBuilder.doWireAndStart();
	}

	public static void main(String[] args) {
		new EventCounterServicesForLASADApp();
	}

}
