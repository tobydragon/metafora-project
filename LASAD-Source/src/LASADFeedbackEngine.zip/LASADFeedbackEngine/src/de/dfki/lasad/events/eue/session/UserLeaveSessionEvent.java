package de.dfki.lasad.events.eue.session;

import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;

/**
 * 
 * @author Oliver Scheuer
 *
 */
public class UserLeaveSessionEvent extends UserActionEvent {

	public UserLeaveSessionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID) {
		super(sessionID, srcCompId, eueEventID);
	}

	public UserLeaveSessionEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID) {
		super(sessionID, srcCompId, eueEventID);
		this.userID = userID;
	}
	
}
