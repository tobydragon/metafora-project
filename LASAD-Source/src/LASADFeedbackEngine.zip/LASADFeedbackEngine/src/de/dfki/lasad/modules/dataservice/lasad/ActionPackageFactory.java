package de.dfki.lasad.modules.dataservice.lasad;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.Parameter;

import de.dfki.lasad.modules.dataservice.lasad.translators.LASADVocabulary;


/**
 import lasad.ejb.Action;
 import lasad.ejb.ActionPackage;
 import lasad.ejb.Parameter;
 */

/**
 * Factory to create {@link ActionPackage}s that can be processed by the remote
 * LASAD-WS.
 * 
 * @author Oliver Scheuer
 * 
 */
public class ActionPackageFactory {

	static Log logger = LogFactory.getLog(ActionPackageFactory.class);
	
	private Parameter sessionParam;
	private Parameter usernameParam;
	private Parameter passwordParam;
	private String method = LASADVocabulary.ACTION_METHOD_PUSH;

	public ActionPackageFactory(String sessionId, String username,
			String password) {
		sessionParam = new Parameter();
		sessionParam.setName(LASADVocabulary.ACTIONPACKAGE_PROP_SESSIONID);
		sessionParam.setValue(sessionId);

		usernameParam = new Parameter();
		usernameParam.setName(LASADVocabulary.ACTION_PROP_USERNAME);
		usernameParam.setValue(username);

		passwordParam = new Parameter();
		passwordParam.setName(LASADVocabulary.ACTION_PROP_PW);
		passwordParam.setValue(password);
	}
	
	public ActionPackageFactory(String sessionId, String username,
			String password, String method) {
		sessionParam = new Parameter();
		sessionParam.setName(LASADVocabulary.ACTIONPACKAGE_PROP_SESSIONID);
		sessionParam.setValue(sessionId);

		usernameParam = new Parameter();
		usernameParam.setName(LASADVocabulary.ACTION_PROP_USERNAME);
		usernameParam.setValue(username);

		passwordParam = new Parameter();
		passwordParam.setName(LASADVocabulary.ACTION_PROP_PW);
		passwordParam.setValue(password);
		
		this.method = method;
	}

	public ActionPackage createLoginMessage() {
		ActionPackage retVal;
		if (method.equals(LASADVocabulary.ACTION_METHOD_PUSH)){
			retVal = createLoginMessageWS();
		}else{
			retVal = createLoginMessageRMI();
		}
		return retVal;
	}
	
	public ActionPackage createLoginMessageWS() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action loginAction = new Action();
		loginAction.setCmd(LASADVocabulary.ACTION_CMD_LOGIN);
		loginAction.setCategory(LASADVocabulary.ACTION_CAT_MANAGEMENT);

		loginAction.getParameters().add(usernameParam);
		loginAction.getParameters().add(passwordParam);

		Parameter methodParam = new Parameter();
		methodParam.setName(LASADVocabulary.ACTION_PROP_METHOD);
		methodParam.setValue(LASADVocabulary.ACTION_METHOD_PUSH);
		loginAction.getParameters().add(methodParam);

		actionPackage.getActions().add(loginAction);

		return actionPackage;
	}
	
	public ActionPackage createLoginMessageRMI() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action loginAction = new Action();
		loginAction.setCmd(LASADVocabulary.ACTION_CMD_LOGIN);
		loginAction.setCategory(LASADVocabulary.ACTION_CAT_MANAGEMENT);

		loginAction.getParameters().add(usernameParam);
		loginAction.getParameters().add(passwordParam);

		Parameter methodParam = new Parameter();
		methodParam.setName(LASADVocabulary.ACTION_PROP_METHOD);
		methodParam.setValue(LASADVocabulary.ACTION_METHOD_RMI);
		loginAction.getParameters().add(methodParam);

		actionPackage.getActions().add(loginAction);

		return actionPackage;
	}

	public ActionPackage createListMapsMessage() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCmd(LASADVocabulary.ACTION_CMD_LIST);
		action.setCategory(LASADVocabulary.ACTION_CAT_MANAGEMENT);
		actionPackage.getActions().add(action);

		return actionPackage;
	}

	public ActionPackage createGetOntologyMessage(String mapID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCmd(LASADVocabulary.ACTION_CMD_GETONTOLOGY);
		action.setCategory(LASADVocabulary.ACTION_CAT_MANAGEMENT);

		Parameter mapIDParam = new Parameter();
		mapIDParam.setName(LASADVocabulary.ACTION_PROP_MAPID);
		mapIDParam.setValue(mapID);
		action.getParameters().add(mapIDParam);
		actionPackage.getActions().add(action);

		return actionPackage;
	}

	public ActionPackage createGetMapDetailsMessage(String mapID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCmd(LASADVocabulary.ACTION_CMD_MAPDETAILS);
		action.setCategory(LASADVocabulary.ACTION_CAT_MANAGEMENT);

		Parameter mapIDParam = new Parameter();
		mapIDParam.setName(LASADVocabulary.ACTION_PROP_MAPID);
		mapIDParam.setValue(mapID);
		action.getParameters().add(mapIDParam);
		actionPackage.getActions().add(action);

		return actionPackage;
	}

	public ActionPackage createJoinMapMessage(String mapID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action a = new Action();
		a.setCmd(LASADVocabulary.ACTION_CMD_JOIN);
		a.setCategory(LASADVocabulary.ACTION_CAT_MANAGEMENT);

		Parameter mapIDParam = new Parameter();
		mapIDParam.setName(LASADVocabulary.ACTION_PROP_MAPID);
		mapIDParam.setValue(mapID);
		a.getParameters().add(mapIDParam);

		actionPackage.getActions().add(a);
		return actionPackage;
	}

	public ActionPackage createPublishServiceMessage(String mapID,
			String agentID, String serviceID, boolean isAnalysisService) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCategory(LASADVocabulary.ACTION_CAT_MAP);
		action.setCmd(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT);

		Parameter typeParam = createParameter(LASADVocabulary.ACTION_PROP_TYPE,
				LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK_AGENT);
		action.getParameters().add(typeParam);

		Parameter mapIDParam = createParameter(
				LASADVocabulary.ACTION_PROP_MAPID, mapID);
		action.getParameters().add(mapIDParam);

		String agentType = isAnalysisService ? LASADVocabulary.ACTION_PROP_VALUE_ANALYSIS
				: LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK;
		Parameter agentTypeParam = createParameter(
				LASADVocabulary.ACTION_PROP_AGENT_TYPE, agentType);
		action.getParameters().add(agentTypeParam);

		Parameter agentIDParam = createParameter(
				LASADVocabulary.ACTION_PROP_AGENT_ID, agentID);
		action.getParameters().add(agentIDParam);

		Parameter serviceIDParam = createParameter(
				LASADVocabulary.ACTION_PROP_TYPE_ID, serviceID);
		action.getParameters().add(serviceIDParam);

		actionPackage.getActions().add(action);

		return actionPackage;
	}

	public ActionPackage createHeartbeatMessage() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action action = new Action();
		action.setCategory(LASADVocabulary.ACTION_CAT_SESSION);
		action.setCmd(LASADVocabulary.ACTION_CMD_HEARTBEAT);
		// action.getParameters().add(createParameter("DUMMY",
		// "PLEASE IGNORE"));
		actionPackage.getActions().add(action);
		return actionPackage;
	}

	public Action createFeedbackMessage(String mapID, String recipientID,
			String message, String longMessage,
			List<String> objectsToBeHighlighted,
			Map<String, String> additionalParameters) {

		Action action = new Action();

		// basic data
		action.setCategory(LASADVocabulary.ACTION_CAT_MAP);
		action.setCmd(LASADVocabulary.ACTION_CMD_CREATE_ELEMENT);

		Parameter typeParam = createParameter(LASADVocabulary.ACTION_PROP_TYPE,
				LASADVocabulary.ACTION_PROP_VALUE_FEEDBACK_CLUSTER);
		action.getParameters().add(typeParam);

		Parameter usernameParam = createParameter(
				LASADVocabulary.ACTION_PROP_FORUSER, recipientID);
		action.getParameters().add(usernameParam);

		Parameter mapIDParam = createParameter(
				LASADVocabulary.ACTION_PROP_MAPID, mapID);
		action.getParameters().add(mapIDParam);

		Parameter messageParam = createParameter(
				LASADVocabulary.ACTION_PROP_MESSAGE, message);
		action.getParameters().add(messageParam);

		if (longMessage != null) {
			Parameter longMessageParam = createParameter(
					LASADVocabulary.ACTION_PROP_LONGMESSAGE, longMessage);
			action.getParameters().add(longMessageParam);
		}

		for (String objectID : objectsToBeHighlighted) {
			Parameter highlightElemParam = createParameter(
					LASADVocabulary.ACTION_PROP_HIGHLIGHT_ELEMENT_ID, objectID);
			action.getParameters().add(highlightElemParam);
		}

		for (String paramName : additionalParameters.keySet()) {
			String paramValue = additionalParameters.get(paramName);

			Parameter additionalParam = createParameter(paramName, paramValue);
			action.getParameters().add(additionalParam);
		}

		return action;
	}

	public ActionPackage createActionPackage(List<Action> actions) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);
		for (Action action : actions) {
			actionPackage.getActions().add(action);
		}
		return actionPackage;
	}

	private Action createHighlightAction(String mapID, String eueID) {
		Action action = new Action();

		action.setCategory(LASADVocabulary.ACTION_CAT_FEEDBACK);
		action.setCmd(LASADVocabulary.ACTION_CMD_HIGHLIGHT);

		Parameter parentParam = createParameter(
				LASADVocabulary.ACTION_PROP_PARENT,
				LASADVocabulary.ACTION_PROP_VALUE_LAST_ID);
		action.getParameters().add(parentParam);

		Parameter mapIDParam = createParameter(
				LASADVocabulary.ACTION_PROP_MAPID, mapID);
		action.getParameters().add(mapIDParam);

		return action;
	}

	public ActionPackage createDeleteElementMessage(String mapID,
			String elementID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action deleteAction = new Action();

		// basic data
		deleteAction.setCategory(LASADVocabulary.ACTION_CAT_MAP);
		deleteAction.setCmd(LASADVocabulary.ACTION_CMD_DELETE_ELEMENT);

		Parameter mapIDParam = createParameter(
				LASADVocabulary.ACTION_PROP_MAPID, mapID);
		deleteAction.getParameters().add(mapIDParam);

		Parameter idParam = createParameter(LASADVocabulary.ACTION_PROP_ID,
				elementID);
		deleteAction.getParameters().add(idParam);

		actionPackage.getActions().add(deleteAction);

		return actionPackage;
	}

	public ActionPackage createLeaveMapMessage(String mapID) {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action leaveAction = new Action();

		// basic data
		leaveAction.setCategory(LASADVocabulary.ACTION_CAT_MANAGEMENT);
		leaveAction.setCmd(LASADVocabulary.ACTION_CMD_LEAVE);

		Parameter mapIDParam = createParameter(
				LASADVocabulary.ACTION_PROP_MAPID, mapID);
		leaveAction.getParameters().add(mapIDParam);

		actionPackage.getActions().add(leaveAction);
		return actionPackage;
	}

	public ActionPackage createLogoutMessage() {
		ActionPackage actionPackage = new ActionPackage();
		actionPackage.getParameters().add(sessionParam);

		Action logoutAction = new Action();

		// basic data
		logoutAction.setCategory(LASADVocabulary.ACTION_CAT_MANAGEMENT);
		logoutAction.setCmd(LASADVocabulary.ACTION_CMD_LOGOUT);

		logoutAction.getParameters().add(usernameParam);

		actionPackage.getActions().add(logoutAction);
		return actionPackage;
	}

	private Parameter createParameter(String name, String value) {
		Parameter param = new Parameter();
		param.setName(name);
		param.setValue(value);

		return param;
	}
	
	////Added by TD straight from ActionFactory, 18.04.2011
	
	public Action createMap(String useMapName, String useTemplate, String useRestriction) {
		Action a = new Action("CREATE-MAP", "AUTHORING");
		a.addParameter("MAPNAME", useMapName);
		a.addParameter("TEMPLATE", useTemplate);
		a.addParameter("RESTRICTED-TO", useRestriction);
		return a;
	}
	
	//ROLE: Standard, Developer, Guest
	public Action createUser(String useNickname, String usePassword, String useRole) {
		Action a = new Action("CREATE-USER", "AUTHORING");
		a.addParameter("USERNAME", useNickname);
		a.addParameter("PW", usePassword);
		a.addParameter("ROLE", useRole);
		return a;
	}

	public Action createUpdateTextElement(String elementId, String mapId, String text){
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", mapId);
		a.addParameter("ID", elementId);
		a.addParameter("TEXT", text);
		return a;
	}
	
	public Action createUpdateImageUrlElement(String elementId, String mapId, String newUrl){
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", mapId);
		a.addParameter("ID", elementId);
		a.addParameter("ImageURL", newUrl);
		return a;
	}
	
	public Action createUpdateUrlElement(String elementId, String mapId, String newUrl){
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", mapId);
		a.addParameter("ID", elementId);
		a.addParameter("LINK", newUrl);
		return a;
	}
	
	public List<Action> createUpdateReferenceObject(String mapId, String imageElementId, String imageUrl,
			String textElementId, String text, String referenceUrlElementId, String referenceUrl){
		List<Action> actions = new ArrayList<Action>();
		actions.add(createUpdateImageUrlElement(imageElementId, mapId, imageUrl));
		actions.add(createUpdateTextElement(textElementId, mapId, text));
		actions.add(createUpdateUrlElement(referenceUrlElementId, mapId, referenceUrl));
		return actions;
	}
	
//	public List<Action> createUpdateToolReferenceObject(String mapId, String imageElementId, String viewUrl,
//			String textElementId, String text, String referenceUrlElementId, String referenceUrl){
//		List<Action> actions = new ArrayList<Action>();
//		actions.add(createUpdateUrlElement(imageElementId, mapId, viewUrl));
//		actions.add(createUpdateTextElement(textElementId, mapId, text));
//		actions.add(createUpdateUrlElement(referenceUrlElementId, mapId, referenceUrl));
//		return actions;
//	}
	
	public List<Action> createUpdateMicroworldIssueObject(String mapId, String imageElementId, String viewUrl,
			String textElementId, String text, String referenceUrlElementId, String referenceUrl){
		List<Action> actions = new ArrayList<Action>();
		actions.add(createUpdateUrlElement(imageElementId, mapId, viewUrl));
		actions.add(createUpdateTextElement(textElementId, mapId, text));
		actions.add(createUpdateUrlElement(referenceUrlElementId, mapId, referenceUrl));
		return actions;
	}
	
	public List<Action> createUpdateMyMicroworldObject(String mapId, String modelViewId, String modelViewUrl,
			String ruleViewId, String ruleViewUrl, String textElementId, String text, String referenceUrlElementId, String referenceUrl){
		List<Action> actions = new ArrayList<Action>();
		actions.add(createUpdateUrlElement(modelViewId, mapId, modelViewUrl));
		actions.add(createUpdateUrlElement(ruleViewId, mapId, ruleViewUrl));
		actions.add(createUpdateTextElement(textElementId, mapId, text));
		actions.add(createUpdateUrlElement(referenceUrlElementId, mapId, referenceUrl));
		return actions;
	}
}
