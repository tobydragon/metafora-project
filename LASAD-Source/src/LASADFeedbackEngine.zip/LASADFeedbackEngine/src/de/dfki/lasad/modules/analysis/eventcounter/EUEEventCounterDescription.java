package de.dfki.lasad.modules.analysis.eventcounter;

import java.util.Locale;

import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.analysis.OntologyChecker;
import de.dfki.lasad.core.analysis.SimpleOntologyChecker;
import de.dfki.lasad.models.analysis.NumericalResult;

public class EUEEventCounterDescription extends AnalysisAgentDescription {

	private static final String agentName = "Event Counter";

	private static final String targetClass = EUEEventCounter.class.getName();

	// EUE_EVENT_COUNTER IDs
	public static final String COUNT_OBJECT_ACTIONS = "COUNT_OBJECT_ACTIONS";
	public static final String COUNT_CREATE_OBJECT = "COUNT_CREATE_OBJECT";
	public static final String COUNT_DELETE_OBJECT = "COUNT_DELETE_OBJECT";
	public static final String COUNT_UPDATE_OBJECT = "COUNT_UPDATE_OBJECT";
	public static final String COUNT_FEEDBACK_REQUESTS = "COUNT_FEEDBACK_REQUESTS";

	public EUEEventCounterDescription() {
		super(agentName, targetClass);
		addAnalysisTypes();
	}

	private final void addAnalysisTypes() {

		OntologyChecker checker = new SimpleOntologyChecker();

		AnalysisType countAll = new AnalysisType(NumericalResult.class,
				componentTypeID, COUNT_OBJECT_ACTIONS, true, checker);
		countAll.setDisplayName("Count-All-Actions");

		AnalysisType countCreate = new AnalysisType(NumericalResult.class,
				componentTypeID, COUNT_CREATE_OBJECT, true, checker);
		countCreate.setDisplayName("Count-Create-Actions");

		AnalysisType countDelete = new AnalysisType(NumericalResult.class,
				componentTypeID, COUNT_DELETE_OBJECT, true, checker);
		countDelete.setDisplayName("Count-Delete-Actions");

		AnalysisType countUpdate = new AnalysisType(NumericalResult.class,
				componentTypeID, COUNT_UPDATE_OBJECT, true, checker);
		countUpdate.setDisplayName("Count-Update-Actions");

		AnalysisType countFeedbackRequests = new AnalysisType(
				NumericalResult.class, componentTypeID,
				COUNT_FEEDBACK_REQUESTS, true, checker);
		countFeedbackRequests.setDisplayName(
				"Count-Feedback-Requests");

		addAnalysisType(countAll);
		addAnalysisType(countCreate);
		addAnalysisType(countDelete);
		addAnalysisType(countUpdate);
		addAnalysisType(countFeedbackRequests);
	}
}
