package de.dfki.lasad.models.action;

import de.uds.commonformat.CfAction;

public class XmppActionComponent implements ActionComponent{
	
	public CfAction action;

	public CfAction getAction() {
		return action;
	}

	public XmppActionComponent(CfAction action) {
		super();
		this.action = action;
	}

	public static XmppActionComponent getTestableInstance() {
		return new XmppActionComponent(CfAction.getTestableInstance());
	}

}
