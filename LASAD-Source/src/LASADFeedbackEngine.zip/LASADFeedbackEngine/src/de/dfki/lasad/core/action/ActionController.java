package de.dfki.lasad.core.action;

import java.util.List;
import java.util.Vector;
import java.util.concurrent.PriorityBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.DefaultEventPrioritizer;
import de.dfki.lasad.core.analysis.IAnalysisController;
import de.dfki.lasad.core.dataservice.IDataService;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.UserFeedbackRequestEvent;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackTypeID;
import de.dfki.lasad.modules.action.analysismirroring.AnalysisMirroringAgent;
import de.uds.util.ErrorUtil;

public class ActionController implements IActionController {

	Log logger = LogFactory.getLog(ActionController.class);

	private PriorityBlockingQueue<Event> queue = new PriorityBlockingQueue<Event>();
	private Thread workingThread;

	// default ActionAgent
	private AnalysisMirroringAgent mirroringAgent;

	private IAnalysisController analysisController;
	private IDataService dataService;
	private List<IActionAgent> actionAgents = new Vector<IActionAgent>();

	public ActionController() {
		mirroringAgent = new AnalysisMirroringAgent();
		mirroringAgent.doWire(this, null);
		startWorkingThread();
	}

	private final void startWorkingThread() {
		workingThread = new Thread(new Consumer());
		workingThread.start();
	}

	@Override
	public void doWire(IAnalysisController analysisController,
			IDataService dataService) {
		this.analysisController = analysisController;
		this.dataService = dataService;
	}

	@Override
	public void addActionAgent(IActionAgent agent) {
		actionAgents.add(agent);
	}

	@Override
	public void onEUEEvent(EUESessionEvent eueEvent) {
		addEventToQueue(eueEvent);
	}

	@Override
	public void onAnalysisRequestEvent(AnalysisRequestEvent analysisRequestEvent) {
		addEventToQueue(analysisRequestEvent);
	}

	@Override
	public void onAnalysisResultEvent(AnalysisResultEvent analysisResultEvent) {
		addEventToQueue(analysisResultEvent);
	}

	@Override
	public void onActionSpecEvent(ActionSpecEvent actionSpecEvent) {
		addEventToQueue(actionSpecEvent);
	}

	private void addEventToQueue(Event event) {
		DefaultEventPrioritizer.assignPriority(event);
		queue.put(event);
	}

	private void processFeedbackRequestEvent(
			UserFeedbackRequestEvent feedbackRequestEvent) {
		FeedbackTypeID feedbackTypeID = feedbackRequestEvent
				.getFeedbackRequestSpec().getFeedbackTypeID();
		if (feedbackTypeID.mirrorResults()) {
			mirroringAgent.onEUEEvent(feedbackRequestEvent);
			return;
		}
		for (IActionAgent actionAgent : actionAgents) {
			if (isAddressee(actionAgent, feedbackTypeID)) {
				actionAgent.onEUEEvent(feedbackRequestEvent);
			}
		}
	}

	private boolean isAddressee(IActionAgent actionAgent, FeedbackTypeID typeID) {
		String actionAgentID = actionAgent.getComponentDescription()
				.getComponentID();
		boolean isAddressee = typeID.getFeedbackProvider()
				.equals(actionAgentID);
		return isAddressee;
	}

	private void processEUEEvent(EUESessionEvent eueEvent) {
		for (IActionAgent actionAgent : actionAgents) {
			actionAgent.onEUEEvent(eueEvent);
		}
	}

	private void processAnalysisRequestEvent(
			AnalysisRequestEvent analyisRequestEvent) {
		analysisController.onAnalysisRequestEvent(analyisRequestEvent);
	}

	private void processActionSpecEvent(ActionSpecEvent actionSpecEvent) {
		for (IActionAgent actionAgent : actionAgents) {
			actionAgent.onActionSpecEvent(actionSpecEvent);
		}
		dataService.onActionSpecEvent(actionSpecEvent);
	}

	private void processAnalysisResultEvent(
			AnalysisResultEvent analysisResultEvent) {
		logger.debug("Event received: " + analysisResultEvent.toString());
		String addressee = analysisResultEvent.getTargetComponentID();
		String mirroringAgentID = mirroringAgent.getComponentDescription().getComponentID(); 
		if (addressee.equals(mirroringAgentID)) {
			mirroringAgent.onAnalysisResultEvent(analysisResultEvent);
			return;
		}
		for (IActionAgent actionAgent : actionAgents) {
			String actionAgentID = actionAgent.getComponentDescription()
					.getComponentID();
			if (addressee.equals(actionAgentID)) {
				actionAgent.onAnalysisResultEvent(analysisResultEvent);
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ActionController [actionSpecEventListener=");
		builder.append("analysisController=");
		builder.append(analysisController);
		builder.append(", dataService=");
		builder.append(dataService);
		builder.append(", actionAgents=");
		builder.append(actionAgents);
		builder.append("]");
		return builder.toString();
	}

	class Consumer implements Runnable {

		@Override
		public void run() {

			try {
				do {
					Event event = queue.take();
					if (event instanceof UserFeedbackRequestEvent) {
						processFeedbackRequestEvent((UserFeedbackRequestEvent) event);
					} else if (event instanceof EUESessionEvent) {
						processEUEEvent((EUESessionEvent) event);
					} else if (event instanceof ActionSpecEvent) {
						processActionSpecEvent((ActionSpecEvent) event);
					} else if (event instanceof AnalysisRequestEvent) {
						processAnalysisRequestEvent((AnalysisRequestEvent) event);
					} else if (event instanceof AnalysisResultEvent) {
						processAnalysisResultEvent((AnalysisResultEvent) event);
					}

				} while (true);

			} catch (Exception e) {
				logger.error("[Consumer.run] " + e.getClass() + ": " + e.getMessage());
				logger.debug("[Consumer.run] " + e.getClass() + ": " +ErrorUtil.getStackTrace(e));
			}

		}

	}

}
