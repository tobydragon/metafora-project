package de.dfki.lasad.modules.dataservice.lasad.rmi;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.action.IActionAgent;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.modules.dataservice.lasad.LASADDataServiceConfiguration;

/**
 * 
 * @author Anahuac Valero
 * 
 */

public class LASADDataServiceRMIConfiguration implements LASADDataServiceConfiguration{
	static Log logger = LogFactory.getLog(LASADDataServiceRMIConfiguration.class);

	private static String defaultConfFileName = "lasad_dataservice.rmi.conf.xml";

	private String username = "dfkiclient";
	private String password = "dfkiclientpw";

	private int heartBeatRate = 10; // in secs
	private boolean doDeploy = true;
	private boolean doJoinAllPossibleMapsOnStartup = false; // false;
	private Set<String> mapsToJoinOnStartup = new HashSet<String>();
	
	private String serverIP = "localhost";
	private int serverPort = 1099;
	private String serverName = "LASAD-1";
	private int serverRegistryPort = 1099;
	private String clientName = "LASADFeedbackEngineClient";
	private int clientRegistryPort = 1098;

	public static LASADDataServiceRMIConfiguration readConfig(File configFile) {
		return LASADDataServiceRMIConfigParser.loadConfig(configFile);
	}

	public static LASADDataServiceRMIConfiguration readDefaultConfig() {
		if (ServiceRegistry.getAppConfig() == null) {
			logger.error("ServiceRegistry.getAppConfig() == null");
		}
		File confDir = ServiceRegistry.getAppConfig().getConfDir();
		File lasadDSConf = new File(confDir, defaultConfFileName);
		return readConfig(lasadDSConf);
	}
	
	

	public LASADDataServiceRMIConfiguration(String username, String password,
			boolean doDeploy, int heartBeatRate, String serverIP,
			int serverPort, String serverName, int serverRegistryPort) {
		super();
		this.username = username;
		this.password = password;
		this.heartBeatRate = heartBeatRate;
		this.doDeploy = doDeploy;
		this.serverIP = serverIP;
		this.serverPort = serverPort;
		this.serverName = serverName;
		this.serverRegistryPort = serverRegistryPort;
	}

	public LASADDataServiceRMIConfiguration(boolean doDeploy, int heartBeatRate) {
		this(doDeploy);
		this.heartBeatRate = heartBeatRate;
	}

	public LASADDataServiceRMIConfiguration(boolean doDeploy) {
		this();
		this.doDeploy = doDeploy;
	}

	public LASADDataServiceRMIConfiguration() {
	}
	
	public String getActionListener(){
		return clientName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getHeartBeatRate() {
		return heartBeatRate;
	}

	public void setHeartBeatRate(int heartBeatRate) {
		this.heartBeatRate = heartBeatRate;
	}

	public boolean doDeploy() {
		return doDeploy;
	}

	public void setDoDeploy(boolean doDeploy) {
		this.doDeploy = doDeploy;
	}

	public Set<String> getMapsToJoinOnStartup() {
		return mapsToJoinOnStartup;
	}

	public void addMapToJoinOnStartup(String mapID) {
		mapsToJoinOnStartup.add(mapID);
	}

	public boolean doJoinAllPossibleMapsOnStartup() {
		return doJoinAllPossibleMapsOnStartup;
	}
	

	public String getServerIP() {
		return serverIP;
	}

	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}

	public int getServerPort() {
		return serverPort;
	}

	public void setServerPort(int serverPort) {
		this.serverPort = serverPort;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public int getServerRegistryPort() {
		return serverRegistryPort;
	}

	public void setServerRegistryPort(int serverRegistryPort) {
		this.serverRegistryPort = serverRegistryPort;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public int getClientRegistryPort() {
		return clientRegistryPort;
	}

	public void setClientRegistryPort(int clientRegistryPort) {
		this.clientRegistryPort = clientRegistryPort;
	}

	/**
	 * If true, the A&F service will check which {@link IAnalysisAgent}s and
	 * {@link IActionAgent}s are applicable, and join each map with at least one
	 * applicable {@link IAnalysisAgent} or {@link IActionAgent}.
	 * 
	 * @param joinAllPossibleMapsOnStartup
	 */
	public void setJoinAllPossibleMapsOnStartup(
			boolean joinAllPossibleMapsOnStartup) {
		this.doJoinAllPossibleMapsOnStartup = joinAllPossibleMapsOnStartup;
	}

	public boolean autoHeartBeat() {
		if (heartBeatRate > 0) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "LASADDataServiceRMIConfiguration [username=" + username
				+ ", password=" + password + ", heartBeatRate=" + heartBeatRate
				+ ", doDeploy=" + doDeploy
				+ ", doJoinAllPossibleMapsOnStartup="
				+ doJoinAllPossibleMapsOnStartup + ", mapsToJoinOnStartup="
				+ mapsToJoinOnStartup + ", serverName=" + serverName
				+ ", serverIP=" + serverIP + ", serverPort=" + serverPort
				+ ", serverRegistryPort=" + serverRegistryPort
				+ ", clientName=" + clientName + ", clientRegistryPort="
				+ clientRegistryPort + "]";
	}

	@Override
	public String getActionListenerWSDeploymentPath() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
