package de.dfki.lasad.modules.dataservice.lasad.translators.xmpp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import lasad.gwt.client.communication.objects.Action;
import de.dfki.lasad.modules.dataservice.lasad.ActionPackageFactory;
import de.dfki.lasad.modules.dataservice.lasad.xml.XmlLasadActionFactory;
import de.dfki.lasad.util.CommonFormatXmlHelper;
import de.uds.commonformat.CfAction;
import de.uds.commonformat.CfObject;
import de.uds.commonformat.CfUser;
import de.uds.metafora.MetaforaStrings;

public class XmppToActionPackage {
	private static Log logger = LogFactory.getLog(XmppToActionPackage.class);
	
	
	public static  synchronized List<Action> translate(CfAction cfAction, ActionPackageFactory packageFactory) {
		List<Action> actions = new ArrayList<Action>();
		
		String cfActionType = cfAction.getCfActionType().getType();	
		if (MetaforaStrings.CREATE_USER_STRING.equalsIgnoreCase(cfActionType)) {
			//TODO don't assume that there is only one object, and it is a user	
			CfObject userObject = cfAction.getCfObjects().get(0);
			String username = userObject.getPropertyValue(MetaforaStrings.PROPERTY_USERNAME_STRING);
			String password = userObject.getPropertyValue(MetaforaStrings.PROPERTY_PASSWORD_STRING);
			String role = userObject.getPropertyValue(MetaforaStrings.PROPERTY_ROLE_STRING);
			actions.add(packageFactory.createUser(username, password, role));
		}
		else if (MetaforaStrings.CREATE_MAP_STRING.equalsIgnoreCase(cfActionType)){
			CfObject mapObject = cfAction.getCfObjects().get(0);
			String mapName = mapObject.getPropertyValue(MetaforaStrings.PROPERTY_MAPNAME_STRING);
			String templateName = mapObject.getPropertyValue(MetaforaStrings.PROPERTY_TEMPLATE_STRING);
			actions.add(packageFactory.createMap(mapName, templateName, ""));
		}
		else if (MetaforaStrings.ACTION_TYPE_CREATE_ELEMENT_STRING.equalsIgnoreCase(cfActionType)) {
			CfObject elementObject = cfAction.getCfObjects().get(0);
			actions.addAll(buildCreateObjectActions(elementObject));
		}
		else if (MetaforaStrings.ACTION_TYPE_UPDATE_ELEMENT_STRING.equalsIgnoreCase(cfActionType)){
			CfObject elementObject = cfAction.getCfObjects().get(0);
			actions.addAll(buildUpdateObjectActions(elementObject, packageFactory));
		}
		else {
			logger.error("[tranlsate] No translation for actionType: " + cfActionType);
		}
		return actions;
	}
	
	public static synchronized List<Action> buildCreateObjectActions(CfObject objectToCreate){
		List<Action> actions = new ArrayList<Action>();
		String mapId = objectToCreate.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING);
		String username = objectToCreate.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_USERNAME_STRING);
		if (username == null || username == ""){
			username = "System";
		}
		
		String typeToCheck = objectToCreate.getPropertyValue(MetaforaStrings.OBJECT_TYPE_STRING);
		if (MetaforaStrings.OBJECT_TYPE_QUESTION_STRING.equalsIgnoreCase(typeToCheck)){
			actions.addAll ( XmlLasadActionFactory.createQuestionBoxActions(mapId));
		}

		else if (MetaforaStrings.OBJECT_TYPE_MICROWORLD_ISSUE_STRING.equalsIgnoreCase(typeToCheck)){
			actions.addAll(XmlLasadActionFactory.createMicroworldIssueObjectActions(mapId, username));
		}
		else if (MetaforaStrings.OBJECT_TYPE_MY_MICROWORLD_STRING.equalsIgnoreCase(typeToCheck)){
			actions.addAll(XmlLasadActionFactory.createMyMicroworldObjectActions(mapId, username));
		}
		else {
			logger.error("[tranlsate] Create on unknown element type - " + typeToCheck);
		}
		return actions;
	}
	
	public static synchronized List<Action> buildUpdateObjectActions(CfObject objectToUpdate, ActionPackageFactory packageFactory){
		List<Action> actions = new ArrayList<Action>();
		String mapId = objectToUpdate.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_MAP_ID_STRING);
		String elementId = objectToUpdate.getId();
		
		String typeToCheck = objectToUpdate.getPropertyValue(MetaforaStrings.OBJECT_TYPE_STRING);
		if (MetaforaStrings.OBJECT_TYPE_QUESTION_STRING.equalsIgnoreCase(typeToCheck)){
			String text = objectToUpdate.getPropertyValue(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING);
			actions.add(packageFactory.createUpdateTextElement(elementId, mapId, text));
		}
		else if (MetaforaStrings.OBJECT_TYPE_MICROWORLD_ISSUE_STRING.equalsIgnoreCase(typeToCheck)){
			
			String viewElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING).getId();
			String viewUrl = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_VIEW_URL_STRING).getValue();
			String textElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).getId();
			String text = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).getValue();
			String referenceUrlElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).getId();
			String referenceUrl = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).getValue();

			actions.addAll(packageFactory.createUpdateMicroworldIssueObject(mapId, viewElementId
							, viewUrl, textElementId, text, referenceUrlElementId, referenceUrl));				
		}
		else if (MetaforaStrings.OBJECT_TYPE_MY_MICROWORLD_STRING.equalsIgnoreCase(typeToCheck)){
			String modelViewId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_MODEL_VIEW_URL).getId();
			String modelViewUrl = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_MODEL_VIEW_URL).getValue();
			String ruleViewId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_RULE_VIEW_URL).getId();
			String ruleViewUrl = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_RULE_VIEW_URL).getValue();
			String textElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).getId();
			String text = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_TEXT_STRING).getValue();
			String referenceUrlElementId = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).getId();
			String referenceUrl = objectToUpdate.getProperty(MetaforaStrings.PROPERTY_TYPE_REFERENCE_URL_STRING).getValue();

			actions.addAll(packageFactory.createUpdateMyMicroworldObject(mapId, modelViewId, modelViewUrl
							, ruleViewId, ruleViewUrl, textElementId, text, referenceUrlElementId, referenceUrl));				
		}
		else {
			logger.error("[tranlsate] Update on unknown element type - " + typeToCheck);
			return null;
		}
		return actions;

	}
	
	public static boolean isImageUrl(String url){
		List<String> imageExtensions = Arrays.asList(".jpg", ".png", ".gif", ".jpeg", ".tif", ".tiff", ".pbm");
		for (String extension : imageExtensions){
			if (url.endsWith(extension)){
				return true;
			}
		}
		return false;
	}

}
