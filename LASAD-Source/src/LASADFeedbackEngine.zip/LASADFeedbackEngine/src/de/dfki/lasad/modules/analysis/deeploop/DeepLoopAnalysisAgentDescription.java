package de.dfki.lasad.modules.analysis.deeploop;

import java.util.Locale;

import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.analysis.OntologyChecker;
import de.dfki.lasad.models.analysis.BinaryResult;

public class DeepLoopAnalysisAgentDescription extends AnalysisAgentDescription {

	private static final String agentName = "DL";
	
	private static final String targetClass = DeepLoopAnalysisAgent.class
			.getName();

	// Classifier IDs
	public static final String CoR_en = "CoR_en";
	public static final String QA_en = "QA_en";
	public static final String CQ_en = "CQ_en";
	public static final String CSA_en = "CSA_en";
	public static final String CCA_en = "CCA_en";
	public static final String NonTF_en = "NonTF_en";

	//public static final String argEval1 = "argEval1";
	public static final String argEval2 = "argEval2";
	//public static final String clarif1 = "clarif1";
	public static final String clarif2 = "clarif2";
	//public static final String chainOpposition1 = "chainOpposition1";
	public static final String chainOpposition2 = "chainOpposition2";
	public static final String newPerspective1 = "newPerspective1";
	public static final String buildOn1 = "buildOn1";

	public DeepLoopAnalysisAgentDescription(
			DeepLoopAnalysisAgentConfiguration conf) {
		super(agentName, targetClass);
		this.configuration = conf;
		addAnalysisTypes();
	}

	@Override
	public DeepLoopAnalysisAgentConfiguration getConfiguration() {
		return (DeepLoopAnalysisAgentConfiguration) configuration;
	}

	private void addAnalysisTypes() {

		OntologyChecker checker = getConfiguration()
				.getOntologySupportChecker();

		AnalysisType analysisType_CoR_en = new AnalysisType(BinaryResult.class,
				componentTypeID, CoR_en, true, checker);
		analysisType_CoR_en.setDisplayName("Reasoned Claim");
		
		AnalysisType analysisType_QA_en = new AnalysisType(BinaryResult.class,
				componentTypeID, QA_en, true, checker);
		analysisType_QA_en.setDisplayName("Question-Answer");
		
		AnalysisType analysisType_CQ_en = new AnalysisType(BinaryResult.class,
				componentTypeID, CQ_en, true, checker);
		analysisType_CQ_en.setDisplayName("Contribution-Followed-By-Question");
		
		AnalysisType analysisType_CSA_en = new AnalysisType(BinaryResult.class,
				componentTypeID, CSA_en, true, checker);
		analysisType_CSA_en.setDisplayName("Contribution-SupportArgument");
		
		AnalysisType analysisType_CCA_en = new AnalysisType(BinaryResult.class,
				componentTypeID, CCA_en, true, checker);
		analysisType_CCA_en.setDisplayName("Contribution-CounterArgument");
		
		AnalysisType analysisType_NonTF_en = new AnalysisType(
				BinaryResult.class, componentTypeID, NonTF_en, true, checker);
		analysisType_NonTF_en.setDisplayName("Off-topic contribution");
		
		AnalysisType analysisType_argEval2 = new AnalysisType(
				BinaryResult.class, componentTypeID, argEval2, true, checker);
		analysisType_argEval2.setDisplayName("Argument + Evaluation");
		
		AnalysisType analysisType_clarif2 = new AnalysisType(
				BinaryResult.class, componentTypeID, clarif2, true, checker);
		analysisType_clarif2.setDisplayName("Clarification of opinion");
		
		AnalysisType analysisType_chainOpposition2 = new AnalysisType(
				BinaryResult.class, componentTypeID, chainOpposition2, true,
				checker);
		analysisType_chainOpposition2.setDisplayName("Chain of Opposition");
		
		AnalysisType analysisType_newPerspective1 = new AnalysisType(
				BinaryResult.class, componentTypeID, newPerspective1, true,
				checker);
		analysisType_newPerspective1.setDisplayName("New Perspective");
		
		AnalysisType analysisType_buildOn1 = new AnalysisType(
				BinaryResult.class, componentTypeID, buildOn1, true, checker);
		analysisType_buildOn1.setDisplayName("Build On");
		
		
		addAnalysisType(analysisType_CoR_en);
		addAnalysisType(analysisType_QA_en);
		addAnalysisType(analysisType_CQ_en);
		addAnalysisType(analysisType_CSA_en);
		addAnalysisType(analysisType_CCA_en);
		addAnalysisType(analysisType_NonTF_en);

		addAnalysisType(analysisType_argEval2);
		addAnalysisType(analysisType_clarif2);
		addAnalysisType(analysisType_chainOpposition2);
		addAnalysisType(analysisType_newPerspective1);
		addAnalysisType(analysisType_buildOn1);
	}

}
