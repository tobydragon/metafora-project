package de.dfki.lasad.models.eue.ontology.graph;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class LinkType extends ElementType {

	public LinkType(String linkTypeID) {
		super(linkTypeID);
	}
}
