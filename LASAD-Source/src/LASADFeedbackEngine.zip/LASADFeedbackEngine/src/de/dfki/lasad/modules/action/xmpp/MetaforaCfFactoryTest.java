package de.dfki.lasad.modules.action.xmpp;

import de.uds.commonformat.CfAction;
import junit.framework.TestCase;


public class MetaforaCfFactoryTest extends TestCase{
	
	public void testCreateDisplayStateUrlMessage2(){
		CfAction cfAction = MetaforaCfFactory.createDisplayStateUrlMessage2("1", "Toby", "http://web-expresser.appspot.com/?userKey=KwWWk0fzAClMUIX9XCnw78");
		System.out.println(cfAction.toXml());
	}

}
