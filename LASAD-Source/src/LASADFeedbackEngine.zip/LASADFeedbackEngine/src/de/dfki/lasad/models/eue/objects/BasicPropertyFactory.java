package de.dfki.lasad.models.eue.objects;

import java.util.HashSet;
import java.util.Set;

import de.dfki.lasad.core.dataservice.IDataService;

/**
 * Basic vocabulary for {@link ObjectProperty}s. Depending on the specific
 * {@link IDataService} a subset or superset of the here defined
 * {@link ObjectProperty}s might be supported.
 * 
 * @author Oliver Scheuer
 * 
 */
public class BasicPropertyFactory {

	// conceptual class and textual content
	public static final String ONTOLOGY_ELEMENT = "OBJECT_ONTOLOGY_ELEMENT";
	public static final String TITLE = "TITLE";
	public static final String TEXT = "TEXT";

	// object geometry and position
	public static final String SHAPE = "SHAPE";
	public static final String X = "X";
	public static final String Y = "Y";
	public static final String WIDTH = "WIDTH";
	public static final String HEIGHT = "HEIGHT";

	// other visual properties
	public static final String COLOR = "COLOR";
	public static final String TEXTCOLOR = "TEXTCOLOR";
	public static final String BORDERCOLOR = "BORDERCOLOR";
	public static final String BORDERWIDTH = "BORDERWIDTH";

	// process properties
	public static final String CREATOR = "CREATOR";
	public static final String FIRST_MODIFIER = "FIRST_MODIFIER";
	public static final String LAST_MODIFIER = "LAST_MODIFIER";
	public static final String CREATION_TS = "CREATION_TS";
	public static final String FIRST_MODIFICATION_TS = "FIRST_MODIFICATION_TS";
	public static final String LAST_MODIFICATION_TS = "LAST_MODIFICATION_TS";
	
	
	private static final Set<String> supportedSimpleProps = new HashSet<String>();

	static {
		supportedSimpleProps.add(ONTOLOGY_ELEMENT);
		supportedSimpleProps.add(TITLE);
		supportedSimpleProps.add(TEXT);
		supportedSimpleProps.add(SHAPE);
		supportedSimpleProps.add(X);
		supportedSimpleProps.add(Y);
		supportedSimpleProps.add(WIDTH);
		supportedSimpleProps.add(HEIGHT);
		supportedSimpleProps.add(COLOR);
		supportedSimpleProps.add(TEXTCOLOR);
		supportedSimpleProps.add(BORDERCOLOR);
		supportedSimpleProps.add(BORDERWIDTH);
		
		supportedSimpleProps.add(CREATOR);
		supportedSimpleProps.add(FIRST_MODIFIER);
		supportedSimpleProps.add(LAST_MODIFIER);
		supportedSimpleProps.add(CREATION_TS);
		supportedSimpleProps.add(FIRST_MODIFICATION_TS);
		supportedSimpleProps.add(LAST_MODIFICATION_TS);

	}

	public static SimpleProperty newSimpleProp(String key, String value)
			throws NonSupportedPropertyRequestedException {
		if (supportedSimpleProps.contains(key)) {
			SimpleProperty prop = new SimpleProperty(key, value);
			return prop;
		} else
			throw new NonSupportedPropertyRequestedException(
					BasicPropertyFactory.class.getName(), key);
	}

}
