package de.dfki.lasad.core.analysis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.models.analysis.AnalysisQuery;
import de.dfki.lasad.models.eue.SessionID;

/**
 * Keeps record of completeness state of currently processed
 * {@link AnalysisRequestEvent}s
 * 
 * @author Oliver Scheuer
 * 
 */
public class RequestManager {

	Log logger = LogFactory.getLog(RequestManager.class);

	private Map<RequestID, AnalysisResultEvent> requestIDs2Results = new HashMap<RequestID, AnalysisResultEvent>();
	private Map<RequestID, AnalysisQuery> requestIDs2Queries = new HashMap<RequestID, AnalysisQuery>();
	private List<AnalysisResultEvent> completedResults = new Vector<AnalysisResultEvent>();

	public void addAnalysisRequest(AnalysisRequestEvent analysisRequestEvent) {
		RequestID requestID = createRequestID(analysisRequestEvent);
		AnalysisResultEvent analysisResultTemplate = createAnalysisResultTemplate(analysisRequestEvent);
		AnalysisQuery query = analysisRequestEvent.getQuery();
		requestIDs2Results.put(requestID, analysisResultTemplate);
		requestIDs2Queries.put(requestID, query);
		addToCompletedResultsIfCompleted(query, analysisResultTemplate);
	}

	private RequestID createRequestID(AnalysisRequestEvent analysisRequestEvent) {
		String requestSourceComponent = analysisRequestEvent
				.getSourceComponentID();
		String transactionID = analysisRequestEvent.getTransactionID();
		RequestID requestID = new RequestID(requestSourceComponent,
				transactionID);
		return requestID;
	}

	private AnalysisResultEvent createAnalysisResultTemplate(
			AnalysisRequestEvent analysisRequestEvent) {
		String transactionID = analysisRequestEvent.getTransactionID();
		SessionID sessionID = analysisRequestEvent.getSessionID();
		String requestSourceComponent = analysisRequestEvent
				.getSourceComponentID();
		String resultSourceComponent = getClass().getName();
		AnalysisResultEvent analysisResultTemplate = new AnalysisResultEvent(
				transactionID, sessionID, resultSourceComponent,
				requestSourceComponent);
		return analysisResultTemplate;
	}

	public void updateAnalysisResults(AnalysisResultEvent newAnalysisResultEvent) {
		RequestID key = createRequestID(newAnalysisResultEvent);
		AnalysisResultEvent analysisResultTemplate = requestIDs2Results
				.get(key);
		if (analysisResultTemplate == null) {
			logger.warn("No open request for " + key.toString());
		}
		AnalysisQuery query = requestIDs2Queries.get(key);

		Set<AnalysisType> coveredAnalysisTypes = newAnalysisResultEvent
				.getCoveredAnalysisTypes();
		for (AnalysisType aType : coveredAnalysisTypes) {
			analysisResultTemplate.addCoveredResultType(aType);
		}
		analysisResultTemplate.addResults(newAnalysisResultEvent
				.getResultsAsList());
		addToCompletedResultsIfCompleted(query, analysisResultTemplate);
	}

	private RequestID createRequestID(AnalysisResultEvent analysisResultEvent) {
		String targetComponent = analysisResultEvent.getTargetComponentID();
		String transactionID = analysisResultEvent.getTransactionID();
		return new RequestID(targetComponent, transactionID);
	}

	private void addToCompletedResultsIfCompleted(AnalysisQuery query,
			AnalysisResultEvent analysisResultEvent) {
		if (isCompleted(query, analysisResultEvent)) {
			RequestID requestID = createRequestID(analysisResultEvent);
			requestIDs2Queries.remove(requestID);
			requestIDs2Results.remove(requestID);
			completedResults.add(analysisResultEvent);
		}
	}

	private boolean isCompleted(AnalysisQuery query,
			AnalysisResultEvent analysisResultEventToCheck) {

		Set<String> analysisAgentIDs = query.getAnalysisAgentIDs();
		for (String analysisAgentID : analysisAgentIDs) {
			Set<AnalysisType> analysisTypes = query
					.getAnalysisTypes(analysisAgentID);
			for (AnalysisType analysisType : analysisTypes) {
				if (!analysisResultEventToCheck.containsResult(analysisType)) {
					return false;
				}
			}
		}
		return true;
	}

	public List<AnalysisResultEvent> removeCompletedResults() {
		List<AnalysisResultEvent> completedResultsReturnValue = completedResults;
		completedResults = new Vector<AnalysisResultEvent>();
		return completedResultsReturnValue;
	}

	class RequestID {

		public String decisionAgentID;
		public String transactionID;

		public RequestID(String decisionAgentID, String transactionID) {
			this.decisionAgentID = decisionAgentID;
			this.transactionID = transactionID;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime
					* result
					+ ((decisionAgentID == null) ? 0 : decisionAgentID
							.hashCode());
			result = prime * result
					+ ((transactionID == null) ? 0 : transactionID.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (!(obj instanceof RequestID))
				return false;
			RequestID other = (RequestID) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (decisionAgentID == null) {
				if (other.decisionAgentID != null)
					return false;
			} else if (!decisionAgentID.equals(other.decisionAgentID))
				return false;
			if (transactionID == null) {
				if (other.transactionID != null)
					return false;
			} else if (!transactionID.equals(other.transactionID))
				return false;
			return true;
		}

		private RequestManager getOuterType() {
			return RequestManager.this;
		}

		@Override
		public String toString() {
			return "RequestID [decisionAgentID=" + decisionAgentID
					+ ", transactionID=" + transactionID + "]";
		}

	}
}
