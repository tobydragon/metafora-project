package de.dfki.lasad.events.eue.session.objectaction;

import java.util.List;

import de.dfki.lasad.events.eue.session.EUEEventID;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.objects.EUEObject;
import de.dfki.lasad.models.eue.objects.graph.Link;
import de.dfki.lasad.models.eue.objects.graph.Node;

/**
 * How to interpret modifications: <br/>
 * - {@link EUEObject} ID does never change <br/>
 * - A generic property is included in {@link EUEObject#getProps()} if and only
 * if it has changed - A type-specific property that has not changed will be
 * <code>null</code> (e.g., {@link EUEObject#getType()},
 * {@link Node#getParentID()} {@link Link#getSources()} and
 * {@link Link#getTargets()}). <br/>
 * 
 * @author Oliver Scheuer
 * 
 */
public class UserModifyObjectEvent extends UserObjectActionEvent {

	public UserModifyObjectEvent(SessionID sessionID, String srcCompId,
			EUEEventID eueEventID, UserID userID, List<EUEObject> eueObject) {
		super(sessionID, srcCompId, eueEventID, userID, eueObject);

	}

	public UserModifyObjectEvent(SessionID sessionID, EUEEventID eueEventId,
			String srcComponentId) {
		super(sessionID, srcComponentId, eueEventId);
	}

	public UserModifyObjectEvent cloneWithoutObjects() {
		UserModifyObjectEvent clone = new UserModifyObjectEvent(getSessionID(),
				getEueEventID(), getSourceComponentID());
		clone.setUserID(getUserID());
		return clone;
	}
}
