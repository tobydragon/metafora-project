package de.dfki.lasad.models.eue.objects.graph;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.models.eue.objects.EUEObject;
import de.dfki.lasad.models.eue.objects.EUEObjectID;
import de.dfki.lasad.models.eue.objects.EmptyID;

public class Node extends EUEObject {

	Log logger = LogFactory.getLog(Node.class);

	EUEObjectID parentID = null;

	@Override
	public boolean isTopLevelObject() {
		// top level elements don't have a parent
		return parentID instanceof EmptyID;
	}

	public EUEObjectID getParentID() {
		return parentID;
	}

	public void setParentID(EUEObjectID parentID) {
		this.parentID = parentID;
	}

	@Override
	public String toString() {
		return super.toString() + ", parentID=" + parentID;
	}
}
