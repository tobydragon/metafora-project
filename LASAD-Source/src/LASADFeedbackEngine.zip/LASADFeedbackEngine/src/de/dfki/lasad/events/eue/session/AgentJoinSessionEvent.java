package de.dfki.lasad.events.eue.session;

import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.models.eue.SessionID;

/**
 * Notification message to indicate that the A&F agent has joined a session.
 * (see also {@link AgentJoinSessionAnnounceEvent} and
 * {@link AgentJoinSessionConfirmEvent}).
 * 
 * @author Oliver Scheuer
 * 
 */
public class AgentJoinSessionEvent extends SessionEvent {

	public AgentJoinSessionEvent(SessionID sessionID, String srcComponent) {
		super(sessionID, srcComponent);
	}

}
