package de.dfki.lasad.modules.application.eventcounter;

import java.io.File;
import java.util.List;
import java.util.Vector;


import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.application.AbstractAppConfiguration;
import de.dfki.lasad.core.dataservice.DataServiceDescription;
import de.dfki.lasad.modules.analysis.eventcounter.EUEEventCounterDescription;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIConfiguration;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIDescription;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class EventCounterServicesForLASADConfiguration extends AbstractAppConfiguration {

	private LASADDataServiceRMIConfiguration dataServiceConf;
	private DataServiceDescription dataServiceDescription;

	private List<AnalysisAgentDescription> analysisAgentDescriptions = new Vector<AnalysisAgentDescription>();
	private List<ActionAgentDescription> actionAgentDescriptions = new Vector<ActionAgentDescription>();

	public EventCounterServicesForLASADConfiguration() {
		super();
		dataServiceConf = new LASADDataServiceRMIConfiguration(true);
		dataServiceConf.addMapToJoinOnStartup("58");
		dataServiceDescription = new LASADDataServiceRMIDescription(
				dataServiceConf);

		EUEEventCounterDescription eueEventCounterDescription = new EUEEventCounterDescription();
		analysisAgentDescriptions.add(eueEventCounterDescription);

	}

	@Override
	public File getAFHomeDir() {
		return afHome;
	}

	@Override
	public DataServiceDescription getDataServiceDescription() {
		return dataServiceDescription;
	}

	@Override
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions() {
		return analysisAgentDescriptions;
	}

	@Override
	public List<ActionAgentDescription> getActionAgentDescriptions() {
		return actionAgentDescriptions;
	}
}
