package de.dfki.lasad.modules.analysis.eventsummaryagent;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.analysis.AbstractAnalysisAgent;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.UserActionEvent;
import de.dfki.lasad.events.eue.session.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.session.UserLeaveSessionEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserCreateObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserDeleteObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserModifyObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.util.ErrorUtil;
import de.kuei.metafora.xmpp.XMPPBridge;
import de.uds.translator.EueStatementBuilder;
import de.uds.xml.XmlConfigParser;

public class EventSummaryAgent extends  AbstractAnalysisAgent{

	private static String connectionName = null;
	static {
		try {
			String connectionConfigFilepath = "conf/xmpp/xmpp-analysis-connect-settings.xml";
			XmlConfigParser connectionParser = new XmlConfigParser(connectionConfigFilepath);
			
			connectionName = connectionParser.getConfigValue("connection-name");

			String userName = connectionParser.getConfigValue("username");
			String password = connectionParser.getConfigValue("password");
			String chatroom = connectionParser.getConfigValue("chatroom");
			String alias = connectionParser.getConfigValue("alias");
			String device = connectionParser.getConfigValue("device");
			XMPPBridge.createConnection(connectionName, userName, password, chatroom, alias, device);
		}
		catch(Exception e){
			System.out.println("[CfXmppWriter] error creating connection - " + e.getMessage());
		}
	}
	
//	private Map<SessionID, EventHistory> sessionId2EventHistoryMap;
	
	Log logger = LogFactory.getLog(EventSummaryAgent.class);
	
	XMPPBridge xmppBridge;

	public EventSummaryAgent(){
//		sessionId2EventHistoryMap = new HashMap<SessionID, EventHistory>();
		
		try{
			xmppBridge = XMPPBridge.getConnection(connectionName);
			xmppBridge.connect(true);
			xmppBridge.sendMessage(connectionName + " connected at " + System.currentTimeMillis());
			logger.info(connectionName + " connected to xmppBridge at" + new Date());

		}
		catch(Exception e){
			logger.error("[constructor] " + ErrorUtil.getStackTrace(e) );
		}
	}
	
	@Override
	protected void processAnalysisRequestEvent(AnalysisRequestEvent request) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void processEUEEvent(EUESessionEvent eueEvent) {
		
//		if (isSignificant(eueEvent)){
//			SessionID sessionId = eueEvent.getSessionID();
////			EventHistory sessEventHistory = sessionId2EventHistoryMap.get(sessionId);
////			if (sessEventHistory == null){
////				sessEventHistory = new EventHistory(sessionId);
////				sessionId2EventHistoryMap.put(sessionId, sessEventHistory);
////			}
////			sessEventHistory.addEvent(eueEvent);
//			
//			//send cf message to report
//			
//			
//		}
		if (eueEvent instanceof UserActionEvent){
			String message = handleUserActionEvent((UserActionEvent)eueEvent);
			System.err.println( message );
			xmppBridge.sendMessage(message);
		}
		
	}
	
	private String handleUserActionEvent(UserActionEvent userActionEvent) {
		String message=null;
		
		if (userActionEvent instanceof UserObjectActionEvent){
			message = handleUserObjectActionEvent((UserObjectActionEvent) userActionEvent);
		}
		else if (userActionEvent instanceof UserJoinSessionEvent){
			message = EueStatementBuilder.buildUserJoinSessionEventStatement((UserJoinSessionEvent) userActionEvent );
		}
		else if (userActionEvent instanceof UserLeaveSessionEvent){
			message = EueStatementBuilder.buildUserLeaveSessionEventStatement((UserLeaveSessionEvent) userActionEvent );
		}
		return message;
	}

	private String handleUserObjectActionEvent( UserObjectActionEvent userActionEvent) {
		String message=null;

		if (userActionEvent instanceof UserCreateObjectEvent){
			message = EueStatementBuilder.buildUserCreateObjectEventStatement((UserCreateObjectEvent) userActionEvent );
		}
		else if (userActionEvent instanceof UserDeleteObjectEvent){
			message = EueStatementBuilder.buildUserDeleteObjectEventStatement((UserDeleteObjectEvent) userActionEvent );
		}
		return message;
	}

	public String toString(){
		String out = "";
//		for (EventHistory sessionEventHistory : sessionId2EventHistoryMap.values()){
//			out += sessionEventHistory;
//		}
		return out;
	}

}
