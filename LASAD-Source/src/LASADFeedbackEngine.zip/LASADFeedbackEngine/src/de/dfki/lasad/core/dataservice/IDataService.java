package de.dfki.lasad.core.dataservice;

import de.dfki.lasad.core.PluggableComponent;
import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.core.analysis.IAnalysisController;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.eue.session.AgentJoinSessionConfirmEvent;

/**
 * Provides connectivity to the end user environment (EUE). Typically a local
 * proxy for a remote data service
 * 
 * @author Oliver Scheuer
 * 
 */
public interface IDataService extends PluggableComponent {

	/**
	 * Establish runtime dependencies at system initialization time.
	 */
	public void doWire(IAnalysisController analysisController,
			IActionController actionController);

	/**
	 * Establish connections to remote service (if necessary), collect
	 * information about available sessions and prepare own services
	 * accordingly.
	 */
	public void prepareService();

	/**
	 * Join remote sessions and publish services to remote sessions.
	 */
	public void startService();

	// notification methods (execution time)
	public void onActionSpecEvent(ActionSpecEvent event);

	public void onAgentJoinSessionConfirmEvent(
			AgentJoinSessionConfirmEvent confirmEvent);

	@Override
	public DataServiceDescription getComponentDescription();
}
