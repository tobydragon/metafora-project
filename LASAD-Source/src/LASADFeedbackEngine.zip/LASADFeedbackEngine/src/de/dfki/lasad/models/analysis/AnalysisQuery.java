package de.dfki.lasad.models.analysis;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.analysis.AnalysisType;

public class AnalysisQuery {

	Log logger = LogFactory.getLog(AnalysisQuery.class);

	private Map<String, Set<AnalysisType>> agentID2typeIDs;

	public AnalysisQuery() {
		agentID2typeIDs = new HashMap<String, Set<AnalysisType>>();
	}

	public AnalysisQuery(String actionAgentId, Set<AnalysisType> analysisTypes) {
		this();
		agentID2typeIDs.put(actionAgentId, analysisTypes);
	}

	public void addAnalysisType(AnalysisType analysisType) {
		String analysisAgentID = analysisType.getAgentID();
		Set<AnalysisType> analysisTypeSet = agentID2typeIDs
				.get(analysisAgentID);
		if (analysisTypeSet == null) {
			analysisTypeSet = new HashSet<AnalysisType>();
			agentID2typeIDs.put(analysisAgentID, analysisTypeSet);
		}
		analysisTypeSet.add(analysisType);
	}

	public Set<String> getAnalysisAgentIDs() {
		return agentID2typeIDs.keySet();
	}

	public Set<String> getAnalysisTypeIDs(String analysisAgentID) {
		Set<AnalysisType> analysisTypeSet = agentID2typeIDs
				.get(analysisAgentID);
		if (analysisTypeSet == null) {
			logger.warn("No request for AnalysisAgentID " + analysisAgentID
					+ " contained in AnalysisQuery.");
			analysisTypeSet = new HashSet<AnalysisType>();
		}
		Set<String> analysisTypeIDSet = new HashSet<String>();
		for (AnalysisType analysisType : analysisTypeSet) {
			analysisTypeIDSet.add(analysisType.getTypeID());
		}
		return analysisTypeIDSet;
	}

	public Set<AnalysisType> getAnalysisTypes(String analysisAgentID) {
		Set<AnalysisType> analysisTypeSet = agentID2typeIDs
				.get(analysisAgentID);
		if (analysisTypeSet == null) {
			logger.warn("No request for AnalysisAgentID " + analysisAgentID
					+ " contained in AnalysisQuery.");
			analysisTypeSet = new HashSet<AnalysisType>();
		}
		return analysisTypeSet;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((agentID2typeIDs == null) ? 0 : agentID2typeIDs.hashCode());
		return result;
	}

	/**
	 * Two analysis queries are equal when they specify the same set of
	 * {@link AnalysisAgentIDs} with the same sets of AnalysisSets
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof AnalysisQuery))
			return false;
		AnalysisQuery other = (AnalysisQuery) obj;
		if (agentID2typeIDs == null) {
			if (other.agentID2typeIDs != null)
				return false;
		} else if (!agentID2typeIDs.equals(other.agentID2typeIDs))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AnalysisQuery [" + analysisTypeIDs2String() + "]";
	}

	private String analysisTypeIDs2String() {
		StringBuffer buf = new StringBuffer();
		Iterator<String> analysisAgentIDIter = agentID2typeIDs.keySet()
				.iterator();
		while (analysisAgentIDIter.hasNext()) {
			String analysisAgentID = analysisAgentIDIter.next();
			Set<AnalysisType> analysisTypeSet = agentID2typeIDs
					.get(analysisAgentID);
			buf.append(analysisAgentID);
			buf.append(" -> {");
			Iterator<AnalysisType> analysisTypeIter = analysisTypeSet
					.iterator();
			while (analysisTypeIter.hasNext()) {
				AnalysisType analysisType = analysisTypeIter.next();
				buf.append(analysisType.getTypeID());
				if (analysisTypeIter.hasNext()) {
					buf.append(", ");
				}
			}
			buf.append("}");
			if (analysisAgentIDIter.hasNext()) {
				buf.append(", ");
			}
		}

		return buf.toString();
	}

}
