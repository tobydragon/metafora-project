package de.dfki.lasad.models.eue.objects;

import de.dfki.lasad.models.eue.EUEID;

public class EUEObjectID extends EUEID {

	public EUEObjectID(String id) {
		super(id);
	}
}
