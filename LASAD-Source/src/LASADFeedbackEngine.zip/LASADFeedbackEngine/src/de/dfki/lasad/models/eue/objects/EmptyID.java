package de.dfki.lasad.models.eue.objects;

public class EmptyID extends EUEObjectID {

	public EmptyID() {
		super("");
	}
}
