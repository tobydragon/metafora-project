package de.dfki.lasad.modules.analysis.graphmodeler;

import de.dfki.lasad.core.analysis.AbstractAnalysisAgent;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessGraphModeler extends AbstractAnalysisAgent {

	public JessGraphModeler() {
	}

	@Override
	protected void processAnalysisRequestEvent(AnalysisRequestEvent request) {
		// nothing to do
	}

	/**
	 * Forward event to world model
	 */
	@Override
	protected void processEUEEvent(EUESessionEvent eueEvent) {
		worldModel.executeEUESessionEvent(eueEvent);
	}

}
