package de.dfki.lasad.modules.action.jess;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.action.ActionType;
import de.dfki.lasad.core.action.SimpleActionType;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.models.analysis.AnalysisResult;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class PhaseModeler {

	private static Log logger = LogFactory.getLog(PhaseModeler.class);

	/**
	 * The probability of a phase <i>X</i> is computed as follows:
	 * <ul>
	 * <li>rep_max(<i>X</i>) := maximum representativeness score of this phase
	 * := sum of representativeness values for this phase across all
	 * {@link ActionType}s</li>
	 * <li>rep_actual(<i>X</i>) := actual representativeness score of this phase
	 * := sum of representativeness values for this phase across
	 * {@link ActionType}s that have been detected</li>
	 * <li>rep_norm(<i>X</i>) := total representativeness score normalized by
	 * max representativeness score = rep_actual(<i>X</i>) / rep_max(<i>X</i>)</li>
	 * <li>P(<i>X</i>) := phase probability = rep_norm(<i>X</i>) /
	 * Sum(rep_norm(<i>Y</i>)) <i>[Y iterates over all phases]</i></li>
	 * </ul>
	 * 
	 * @param phaseIDs
	 * @param relevantActionTypes
	 * @param type2analysisResults
	 * @return
	 */
	public static Map<String, Double> getPhaseProbabilities(
			Set<String> phaseIDs, Set<ActionType> relevantActionTypes,
			Map<AnalysisType, List<AnalysisResult>> type2analysisResults) {

		Map<String, Double> phase2aggregateMax = new HashMap<String, Double>();
		for (String phaseID : phaseIDs) {
			phase2aggregateMax.put(phaseID, 0.0);
		}

		// computing for each phase the max possible value
		for (ActionType aType : relevantActionTypes) {
			if (aType instanceof SimpleActionType) {
				SimpleActionType simpleActionType = (SimpleActionType) aType;
				for (String phaseID : phaseIDs) {
					double representativeness = simpleActionType
							.getPriority(phaseID);
					double aggreageOld = phase2aggregateMax.get(phaseID);
					double aggreageNew = aggreageOld + representativeness;
					phase2aggregateMax.put(phaseID, aggreageNew);
				}
			}
		}

		Map<String, Double> phase2aggregateActual = new HashMap<String, Double>();
		for (String phaseID : phaseIDs) {
			phase2aggregateActual.put(phaseID, 0.0);
		}

		// computing for each phase the max possible value
		for (AnalysisType aType : type2analysisResults.keySet()) {
			if (aType instanceof SimpleActionType) {
				SimpleActionType simpleActionType = (SimpleActionType) aType;
				for (String phaseID : phaseIDs) {
					double representativeness = simpleActionType
							.getRepresentativeness(phaseID);
					double aggregateOld = phase2aggregateActual.get(phaseID);
					double aggregateNew = aggregateOld + representativeness;
					phase2aggregateActual.put(phaseID, aggregateNew);
				}
			}
		}

		// computing for each phase actual score by max score
		Map<String, Double> phase2NormalizedByMax = new HashMap<String, Double>();
		double sumNormalizedScoresAcrossPhases = 0.0;
		for (String phaseID : phaseIDs) {
			double max = phase2aggregateMax.get(phaseID);
			double actual = phase2aggregateActual.get(phaseID);
			double normalizedScore = actual / max;
			phase2NormalizedByMax.put(phaseID, normalizedScore);
			sumNormalizedScoresAcrossPhases += normalizedScore;
		}

		// normalizing each phase score such that the sum of all phase scores
		// equals 1 (proper probabilities)
		Map<String, Double> phase2Probability = new HashMap<String, Double>();
		for (String phaseID : phaseIDs) {
			double nonprobabilistic = phase2NormalizedByMax.get(phaseID);
			double probabilistic = nonprobabilistic
					/ sumNormalizedScoresAcrossPhases;
			phase2Probability.put(phaseID, probabilistic);
			logger.debug("Phase probability for '" + phaseID + "': "
					+ probabilistic);
		}

		return phase2Probability;
	}

}
