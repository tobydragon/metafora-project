package de.dfki.lasad.models.analysis;

import de.dfki.lasad.core.analysis.AnalysisType;

public class NoAnalysisResults extends AnalysisResult {

	public NoAnalysisResults(AnalysisType analysisType) {
		super(analysisType, new AnalyzableEntity());
	}

	@Override
	public String getValueAsString() {
		return "NO RESULTS";
	}

}
