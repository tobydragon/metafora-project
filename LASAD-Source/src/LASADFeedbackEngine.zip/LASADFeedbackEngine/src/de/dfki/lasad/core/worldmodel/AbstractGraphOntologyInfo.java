package de.dfki.lasad.core.worldmodel;

import java.util.List;
import java.util.Vector;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public abstract class AbstractGraphOntologyInfo implements IGraphOntologyInfo {

	protected static List<String> supportedSubElementDataTypes = new Vector<String>();
	static {
		supportedSubElementDataTypes.add("transcript-link");
		supportedSubElementDataTypes.add("rating");
		supportedSubElementDataTypes.add("awareness");
		supportedSubElementDataTypes.add("text");
	}
}
