package de.dfki.lasad.models.eue.objects;

import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;

import de.uds.xml.XmlFragment;

/**
 * Represents an object state (when used as part of a model), or state changes
 * (when used as part of an event), in the end-user environment.
 * 
 * @author Oliver Scheuer
 * 
 */
public abstract class EUEObject {

	protected EUEObjectID id;
	protected Hashtable<String, ObjectProperty> props = new Hashtable<String, ObjectProperty>();
	
	// Defines which properties can be expected
	protected String dataType; // xml=elementtype
	
	// the semantic type
	protected String type; // nodetype or xml=elementid
	

	public EUEObject() {
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public EUEObjectID getID() {
		return id;
	}

	public void setID(EUEObjectID id) {
		this.id = id;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public void addProperty(ObjectProperty prop) {
		props.put(prop.getName(), prop);
	}

	public ObjectProperty getPropValue(String propName) {
		return props.get(propName);
	}

	public void addProperties(Map<String, ObjectProperty> props) {
		this.props.putAll(props);
	}

	public Hashtable<String, ObjectProperty> getProps() {
		return props;
	}

	public boolean hasProp(String propName) {
		return props.containsKey(propName);
	}

	public boolean isTopLevelObject() {
		return true;
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + ": id=" + id + ", props="
				+ propsToString() + ", type=" + type + ", datatype=" + dataType;
	}

	private String propsToString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("{");
		TreeSet<ObjectProperty> sortedProps = new TreeSet<ObjectProperty>(
				new Comparator<ObjectProperty>() {
					public int compare(ObjectProperty o1, ObjectProperty o2) {
						return o1.getName().compareTo(o2.getName());
					}
				});
		sortedProps.addAll(props.values());
		return sortedProps.toString().replaceAll("\\s", " ");
	}

	public String toStringTesting() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("EUEObjectType=" + getClass().getSimpleName() + "\n"); // node,
																				// link,
																				// etc.
		buffer.append("dataType=" + dataType + "\n");
		buffer.append("EUEObjectID=" + id + "\n");
		buffer.append("type=" + type + "\n");
		buffer.append(propsToStringTesting());
		return buffer.toString();
	}

	private String propsToStringTesting() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[\n");

		Iterator<String> iter = props.keySet().iterator();

		while (iter.hasNext()) {
			String key = iter.next();
			ObjectProperty sp = props.get(key);
			String value = sp.getValueAsString();
			buffer.append(key + "=" + value + "\n");

		}
		buffer.append("]\n");
		return buffer.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EUEObject other = (EUEObject) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	public XmlFragment toXml() {
		XmlFragment xmlFragment= new XmlFragment("EueObject");
		xmlFragment.setAttribute("type", type);
		xmlFragment.setAttribute("datatype", type);
		xmlFragment.addContent(id.toXml());
		XmlFragment propertyFragment = new XmlFragment("properties");
		for (ObjectProperty objectProperty : props.values()){
			propertyFragment.addContent(objectProperty.toXml());
		}
		xmlFragment.addContent(propertyFragment);
		return xmlFragment;
	}

}
