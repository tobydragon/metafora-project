package de.dfki.lasad.modules.action.jess;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.action.ActionType;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessFeedbackAgentDescription extends ActionAgentDescription {

	private static Log logger = LogFactory.getLog(JessFeedbackAgentDescription.class);
	
	private static String className = JessFeedbackAgent.class.getName();

	public JessFeedbackAgentDescription(JessFeedbackAgentConfiguration conf) {
		super(className);
		this.configuration = conf;
		setComponentID(conf.getAgentID());
		setActionTypes();
	}
	
	private void setActionTypes() {
		JessFeedbackAgentConfiguration jessAgentConf = (JessFeedbackAgentConfiguration) configuration;
		for (ActionType aType : jessAgentConf.getRuleBaseActionTypes()) {
			addActionType(aType);
		}
		for (ActionType aType : jessAgentConf.getCompoundActionTypes()) {
			addActionType(aType);
		}
	}

}
