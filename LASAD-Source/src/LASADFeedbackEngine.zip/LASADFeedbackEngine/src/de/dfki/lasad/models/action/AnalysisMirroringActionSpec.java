package de.dfki.lasad.models.action;

import java.util.HashSet;
import java.util.Set;

import de.dfki.lasad.models.analysis.AnalysisResult;

/**
 * An {@link ActionSpec} consisting of 'raw,' uninterpreted
 * {@link AnalysisResult}s. {@link ActionComponent}s that resulted from a
 * tutorial strategy (i.e., from a pedagogical-oriented interpretation of
 * {@link AnalysisResult}s) are packaged in an {@link ActionComponentSpec}.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AnalysisMirroringActionSpec extends ActionSpec {

	private Set<AnalysisResult> actionComponents;

	public AnalysisMirroringActionSpec() {
		actionComponents = new HashSet<AnalysisResult>();
	}

	public AnalysisMirroringActionSpec(Set<AnalysisResult> actionComponent) {
		this.actionComponents = actionComponent;
	}

	public void addActionComponent(AnalysisResult actionComponent) {
		actionComponents.add(actionComponent);
	}

	public void setActionComponents(Set<AnalysisResult> actionComponents) {
		this.actionComponents = actionComponents;
	}

	@Override
	public Set<AnalysisResult> getActionComponents() {
		return actionComponents;
	}

	@Override
	public String toString() {
		return super.toString() + ", " + actionComponents + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((actionComponents == null) ? 0 : actionComponents.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		AnalysisMirroringActionSpec other = (AnalysisMirroringActionSpec) obj;
		if (actionComponents == null) {
			if (other.actionComponents != null)
				return false;
		} else if (!actionComponents.equals(other.actionComponents))
			return false;
		return true;
	}

}
