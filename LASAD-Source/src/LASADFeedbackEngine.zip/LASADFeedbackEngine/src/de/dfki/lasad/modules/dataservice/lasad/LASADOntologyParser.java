package de.dfki.lasad.modules.dataservice.lasad;

import java.io.BufferedReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import de.dfki.lasad.models.eue.ontology.EUEOntology;
import de.dfki.lasad.models.eue.ontology.graph.GraphOntology;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class LASADOntologyParser {

	private static Log logger = LogFactory.getLog(LASADOntologyParser.class);

	public static EUEOntology parseOntology(String ontologyXML) {
		try {
			// Namespace classifierNs = Namespace
			// .getNamespace(classifierDescriptionNS);
			SAXBuilder builder = new SAXBuilder();
			Reader ontologyReader = new StringReader(ontologyXML);
			BufferedReader bufOntologyReader = new BufferedReader(
					ontologyReader);
			Document doc = builder.build(bufOntologyReader);

			Attribute ontologyTypeAttr = doc.getRootElement().getAttribute(
					"type");
			String ontologyTypeText = ontologyTypeAttr.getValue();

			GraphOntology ontology = new GraphOntology(ontologyTypeText);

			/**
			 * TODO Parse ontology details
			 */
			return ontology;

		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}

	public static SortedSet<String> parseMapTemplateXMLAndExtractResourceIDs(
			String mapTemplateXML) {
		try {

			SortedSet<String> resourceIDs = new TreeSet<String>();

			// Namespace classifierNs = Namespace
			// .getNamespace(classifierDescriptionNS);
			SAXBuilder builder = new SAXBuilder();
			Reader transcriptReader = new StringReader(mapTemplateXML);
			BufferedReader bufTranscriptReader = new BufferedReader(
					transcriptReader);
			Document doc = builder.build(bufTranscriptReader);

			@SuppressWarnings("unchecked")
			List<Element> transcriptElems = doc.getRootElement().getChildren(
					"transcript");

			for (Element transcriptElem : transcriptElems) {
				Attribute transcriptIDAttr = transcriptElem.getAttribute("id");
				String transcriptID = transcriptIDAttr.getValue();
				resourceIDs.add(transcriptID);
			}

			return resourceIDs;

		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}

}
