package de.dfki.lasad.events.analysis;

import de.dfki.lasad.events.SessionEvent;
import de.dfki.lasad.models.eue.SessionID;

public class AnalysisEvent extends SessionEvent {

	private String transactionID;

	public AnalysisEvent(String transactionID, SessionID sessionID,
			String srcCompId) {
		super(sessionID, srcCompId);
		this.transactionID = transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String getTransactionID() {
		return transactionID;
	}

	@Override
	public String toString() {
		return super.toString() + ", transactionID=" + transactionID;
	}
	
	
	
}
