package de.dfki.lasad.models.eue;

public class UserID extends EUEID {

	public UserID(String id) {
		super(id);
	}

}
