package de.dfki.lasad.util;

public class TestXmlData {
	
	public static long timeFromXml = Long.valueOf("1302701470752");
	
	public static String createUserXmlString=
		"<action time=\"1302701470752\">" +
			"<actionType type=\"CREATE_USER\" classification=\"AUTHORING\"/>" +
			"<user role=\"controller\" id=\"METAFORA\"/>" +
			"<object type=\"user\" id=\"0\">" +
				"<properties>" +
					"<property name=\"USERNAME\" value=\"MetaforaUser1\"/>" +
					"<property name=\"PASSWORD\" value=\"1\"/>" +
					"<property name=\"ROLE\" value=\"Standard\"/>" +
				"</properties>" +
			"</object>" +
		"</action>";
	public static CommonFormatXmlHelper createUserXml= new CommonFormatXmlHelper(createUserXmlString);

//	<action time="1302701470752">
//	<actionType type="CREATE_USER" classification="AUTHORING"/>
//	<user role="controller" id="METAFORA"/>
//	<object type="user" id="0">
//		<properties>
//			<property name="USERNAME" value="MetaforaUser1"/>
//			<property name="PASSWORD" value="1"/> 
//			<property name="ROLE" value="Standard"/>
//		</properties>
//	</object>
//	</action>
	
	public static String createMapXmlString=
		"<action time=\"1302701470752\">" +
			"<actionType type=\"CREATE_MAP\" classification=\"AUTHORING\"/>" +
			"<user role=\"controller\" id=\"METAFORA\"/>" +
			"<object type=\"map\" id=\"0\">" +
				"<properties>" +
					"<property name=\"MAPNAME\" value=\"MetaforaMap1\"/>" +
					"<property name=\"TEMPLATE\" value=\"Metafora\"/>" +
				"</properties>" +
			"</object>" +
		"</action>";
	public static CommonFormatXmlHelper createMapXml= new CommonFormatXmlHelper(createMapXmlString);


//	<action time="1302701470752">
//	<actionType type="CREATE_MAP" classification="AUTHORING"/>
//	<user role="controller" id="METAFORA"/>
//	<object type="map" id="0">
//		<properties>
//			<property name="MAPNAME" value="MetaforaMap1"/>
//			<property name="TEMPLATE" value="Metafora"/> 
//		</properties>
//	</object>
//	</action>
	
	public static String notXmlMessageString = "xxxxx";
	public static CommonFormatXmlHelper notXml= new CommonFormatXmlHelper(notXmlMessageString);

	
	public static String notActionMesssageString=
		"<notAnAction time=\"1302701470752\">" +
			"<actionType type=\"CREATE_MAP\" classification=\"AUTHORING\"/>" +
			"<user role=\"controller\" id=\"METAFORA\"/>" +
			"<object type=\"map\" id=\"0\">" +
				"<properties>" +
					"<property name=\"MAPNAME\" value=\"MetaforaMap1\"/>" +
					"<property name=\"TEMPLATE\" value=\"Metafora\"/>" +
				"</properties>" +
			"</object>" +
		"</action>";
	public static CommonFormatXmlHelper notActionMesssage= new CommonFormatXmlHelper(notActionMesssageString);

	
}
