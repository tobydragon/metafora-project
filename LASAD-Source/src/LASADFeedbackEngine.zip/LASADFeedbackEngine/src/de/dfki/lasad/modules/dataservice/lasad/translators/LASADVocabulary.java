package de.dfki.lasad.modules.dataservice.lasad.translators;

/**
 * Vocabulary used to communicate with the LASAD-WS.
 * 
 * @author Oliver Scheuer
 * 
 */
public class LASADVocabulary {

	public static final String ACTIONPACKAGE_PROP_SESSIONID = "SESSION-ID";

	public static final String ACTION_METHOD_PUSH = "PUSH";
	public static final String ACTION_METHOD_RMI = "RMI";

	public static final String ACTION_CATEGORY = "CATEGORY";
	public static final String ACTION_CAT_MANAGEMENT = "MANAGEMENT";
	public static final String ACTION_CAT_MAP = "MAP";
	public static final String ACTION_CAT_SESSION = "SESSION";
	public static final String ACTION_CAT_USEREVENT = "USEREVENT"; // not used at all
	public static final String ACTION_CAT_FEEDBACK = "FEEDBACK";
	public static final String ACTION_CAT_AUTHORING = "AUTHORING";
	public static final String ACTION_CAT_NOTIFY = "NOTIFY";
	public static final String ACTION_CAT_INFO = "INFO";


	public static final String ACTION_COMMAND = "COMMAND";
	public static final String ACTION_CMD_LOGIN = "LOGIN";
	public static final String ACTION_CMD_LOGOUT = "LOGOUT";
	public static final String ACTION_CMD_JOIN = "JOIN";
	public static final String ACTION_CMD_LEAVE = "LEAVE";
	public static final String ACTION_CMD_LIST = "LIST";
	public static final String ACTION_CMD_GETONTOLOGY = "GETONTOLOGY";
	public static final String ACTION_CMD_MAPDETAILS = "MAPDETAILS";
	public static final String ACTION_CMD_ONTOLOGY = "ONTOLOGY";
	public static final String ACTION_CMD_USER_JOIN = "USERJOIN";
	public static final String ACTION_CMD_CREATE_ELEMENT = "CREATE-ELEMENT";
	public static final String ACTION_CMD_UPDATE_ELEMENT = "UPDATE-ELEMENT";
	public static final String ACTION_CMD_DELETE_ELEMENT = "DELETE-ELEMENT";
	public static final String ACTION_CMD_HIGHLIGHT = "HIGHLIGHT";
	public static final String ACTION_CMD_LISTMAP = "LISTMAP";
	public static final String ACTION_CMD_REQUEST = "REQUEST";
	public static final String ACTION_CMD_HEARTBEATREQUEST = "HEARTBEATREQUEST";
	public static final String ACTION_CMD_HEARTBEAT = "HEARTBEAT";
	public static final String ACTION_CMD_UPDATE_CURSOR_POSITION = "UPDATE-CURSOR-POSITION"; // not used at all
	public static final String ACTION_CMD_ADD_MAP_TO_LIST = "ADD-MAP-TO-LIST";
	public static final String ACTION_CMD_INFO = "INFO";
	public static final String ACTION_CMD_AUTHORING_FAILED = "AUTHORING-FAILED";
	public static final String ACTION_CMD_USER_CREATED = "USER-CREATED";
	public static final String ACTION_CMD_SESSION_CREATED = "SESSION-CREATED";
	

	public static final String ACTION_PROP_USERNAME = "USERNAME";
	public static final String ACTION_PROP_PW = "PW";
	public static final String ACTION_PROP_FORUSER = "FORUSER";
	public static final String ACTION_PROP_METHOD = "METHOD";
	public static final String ACTION_PROP_MAPID = "MAP-ID";
	public static final String ACTION_PROP_ID = "ID";
	public static final String ACTION_PROP_TYPE = "TYPE";
	public static final String ACTION_PROP_ELEMENT_ID = "ELEMENT-ID";
	public static final String ACTION_PROP_POS_X = "POS-X"; // not used at all
	public static final String ACTION_PROP_POS_Y = "POS-Y"; // not used at all
	public static final String ACTION_PROP_TO_REV = "TO-REV"; // not used at all
	public static final String ACTION_PROP_ROOT_ELEMENT_ID = "ROOTELEMENTID";
	public static final String ACTION_PROP_PARENT = "PARENT";
	public static final String ACTION_PROP_TEXT = "TEXT"; // not used at all
	public static final String ACTION_PROP_STATUS = "STATUS";
	public static final String ACTION_PROP_TIME = "TIME";
	public static final String ACTION_PROP_HIGHLIGHT_ELEMENT_ID = "HIGHLIGHT-ELEMENT-ID";
	public static final String ACTION_PROP_MESSAGE = "MESSAGE";
	public static final String ACTION_PROP_LONGMESSAGE = "DETAILS";
	public static final String ACTION_PROP_RESPONSEREQUIRED = "RESPONSEREQUIRED";
	public static final String ACTION_PROP_ONTOLOGYNAME = "ONTOLOGYNAME";
	public static final String ACTION_PROP_ONTOLOGY = "ONTOLOGY";
	public static final String ACTION_PROP_TEMPLATENAME = "TEMPLATENAME";
	public static final String ACTION_PROP_TEMPLATEXML = "TEMPLATEXML";
	public static final String ACTION_PROP_LOCK = "LOCK";
	public static final String ACTION_PROP_UNLOCK = "UNLOCK";
	public static final String ACTION_PROP_USERACTION_ID = "USERACTION-ID";
	public static final String ACTION_PROP_NUM_ACTIONS = "NUM-ACTIONS";
	public static final String ACTION_PROP_PERSISTENT = "PERSISTENT"; // not used at all
	public static final String ACTION_PROP_CREATIONDATE = "CREATIONDATE";
	public static final String ACTION_PROP_MODIFICATIONDATE = "MODIFICATIONDATE";
	public static final String ACTION_PROP_FIRSTMODIFICATIONDATE = "FIRSTMODIFICATIONDATE";
	public static final String ACTION_PROP_REPLAY = "REPLAY";
	public static final String ACTION_PROP_DIRECTION = "DIRECTION";
	public static final String ACTION_PROP_MAPNAME = "MAPNAME";
	public static final String ACTION_PROP_TEMPLATE = "TEMPLATE";
	public static final String ACTION_PROP_MAP_MAXID = "MAP-MAXID";
	

	public static final String ACTION_PROP_AGENT_TYPE = "AGENT-TYPE";
	public static final String ACTION_PROP_AGENT_ID = "AGENT-ID";
	public static final String ACTION_PROP_TYPE_ID = "TYPE-ID";

	// Parameters values
	public static final String ACTION_PROP_VALUE_LAST_ID = "LAST-ID";
	public static final String ACTION_PROP_VALUE_FEEDBACK_CLUSTER = "feedback-cluster";
	public static final String ACTION_PROP_VALUE_FEEDBACK_AGENT = "FEEDBACK-AGENT";
	public static final String ACTION_PROP_VALUE_FEEDBACK = "FEEDBACK";
	public static final String ACTION_PROP_VALUE_ANALYSIS = "ANALYSIS";
	public static final String ACTION_PROP_VALUE_AWARENESS = "awareness";
	public static final String ACTION_PROP_VALUE_AWARENESS_CURSOR = "awareness-cursor";
	public static final String ACTION_PROP_VALUE_GROUP_CURSOR = "group-cursor";
	public static final String ACTION_PROP_VALUE_CHANGED = "changed";

	public static final String ACTION_PROP_VALUE_RELATION = "relation";
	public static final String ACTION_PROP_VALUE_BOX = "box";
	public static final String ACTION_PROP_VALUE_GRAPH = "graph";
	
	public static final String ACTION_PROP_VALUE_REFERENCE_OBJECT = "Reference";


}
