package de.dfki.lasad.models.eue;

public class SessionID extends EUEID {

	public SessionID(String id) {
		super(id);
	}

}
