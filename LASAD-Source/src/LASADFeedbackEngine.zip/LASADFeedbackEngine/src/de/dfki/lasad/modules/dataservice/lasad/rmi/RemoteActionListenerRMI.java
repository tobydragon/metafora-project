package de.dfki.lasad.modules.dataservice.lasad.rmi;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.Vector;

import lasad.ClientInterface;
import lasad.gwt.client.communication.objects.ActionPackage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class RemoteActionListenerRMI implements ClientInterface, Serializable{
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3540130517125778734L;
	private LASADDataServiceRMI lasadDataService;
	private static Log logger = LogFactory.getLog(RemoteActionListenerRMI.class);
	
	private List<ActionPackage>apList = new Vector<ActionPackage>();
	private Object apListLock = new Object();
	
	public RemoteActionListenerRMI() {
		super();
		execute();
	}

	/*
	 * (non-Javadoc)
	 * @see de.dfki.lasad.modules.dataservice.lasad.rmi.ClientInterface#doActionPackagesOnClient(java.util.Vector)
	 * The server will use this method to push notifications
	 */
	@Override
	public void doActionPackagesOnClient(Vector<ActionPackage> vp)
			throws RemoteException {
		
		for (ActionPackage ap: vp){
			logger.debug("doActionPackagesOnClient(Vector<ActionPackage>): "
					+ LASADDataServiceRMI.actionPackage2String(ap));
		}
		synchronized(apListLock) {
			int apListSize = apList.size();
			boolean notifyFlag = false;
			if (apListSize == 0){
				notifyFlag = true;
			}
			
			apList.addAll(vp);
			if (notifyFlag && apList.size() >= 1){
				apListLock.notify();
			}
		}
		
	}
	
	private ActionPackage getAndRemoveFirstActionPackage(){
		ActionPackage ap = null;
		synchronized(apListLock) {
			while (apList.size() == 0){
				try {
					logger.debug("Waiting...size of ActionPackage list is 0 ");
					apListLock.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			//logger.debug("Here we go!!!");
			ap = apList.remove(0);
        }
		return ap;
	}
	
	private void execute(){
		new Thread() {
            @Override
            public void run() {
			  while(true){
				  ActionPackage ap = getAndRemoveFirstActionPackage();
				  if (ap != null){
					  logger.debug("About to process AP");
					  lasadDataService.processActionPackage(ap);
					  logger.debug("AP processed successfully");
				  }
			  }
            }
		}.start();
	}
	
	/*
	 * register to listen to notifications.
	 */
	public void register(LASADDataServiceRMI lasadDataService) {
		this.lasadDataService = lasadDataService;
	}
	
	/**
	 * Registering at Server Registry (i.e., establishing a connection)
	 */
	public void registerAtServerRegistry(String registryHostServer, int registryPortServer, int registryPortClient, String userName) {
		logger.debug("registerAtServerRegistry listening on registry port: " + registryPortClient);
		logger.debug("registerAtServerRegistry server registry address: " + registryHostServer + " and port: " + 
				registryPortServer + " userName: " + userName);
		Registry rmiReg;
		try {
			rmiReg = LocateRegistry.getRegistry(registryHostServer, registryPortServer);			
			ClientInterface stub = (ClientInterface) UnicastRemoteObject.exportObject(this, registryPortClient);
			
			rmiReg.rebind(userName, stub); // Your username, needs to be unique and should be the same as for the other login
		} catch (RemoteException e) {
			logger.error("Error registerAtServerRegistry: " + e.getClass()
					+ ": " + e.getMessage());
			e.printStackTrace();
		}
	}

}
