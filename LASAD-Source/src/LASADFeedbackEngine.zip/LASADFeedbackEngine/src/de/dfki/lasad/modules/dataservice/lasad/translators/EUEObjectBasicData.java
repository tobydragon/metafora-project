package de.dfki.lasad.modules.dataservice.lasad.translators;

import java.util.ArrayList;
import java.util.List;

import de.dfki.lasad.models.eue.objects.EUEObjectID;

/**
 * @author Anahuac
 * 
 */
public class EUEObjectBasicData {
	private String id; // ID
	private String dataType; // TYPE
	private String nodeType; // ELEMENT-ID
	private String userID; // USERNAME
	private boolean directionChanged = false; // link direction changed?
	private String parentID; // PARENT
	private List<EUEObjectID> sourceList = new ArrayList<EUEObjectID>();
	private List<EUEObjectID> targetList = new ArrayList<EUEObjectID>();

	public EUEObjectBasicData() {
	}

	public EUEObjectBasicData(String id, String dataType, String nodeType,
			String userID) {
		this.id = id;
		this.dataType = dataType;
		this.nodeType = nodeType;
		this.userID = userID;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getParentID() {
		return parentID;
	}

	public void setParentID(String parentID) {
		this.parentID = parentID;
	}

	public boolean isDirectionChanged() {
		return directionChanged;
	}

	public void setDirectionChanged(boolean directionChanged) {
		this.directionChanged = directionChanged;
	}

	public List<EUEObjectID> getSourceList() {
		return sourceList;
	}

	public void add2SourceList(EUEObjectID source) {
		sourceList.add(source);
	}

	public List<EUEObjectID> getTargetList() {
		return targetList;
	}

	public void add2TargetList(EUEObjectID target) {
		targetList.add(target);
	}
	
}
