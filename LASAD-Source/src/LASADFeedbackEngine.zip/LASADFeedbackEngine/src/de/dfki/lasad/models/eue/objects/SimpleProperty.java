package de.dfki.lasad.models.eue.objects;

/**
 * 
 * @author Oliver Scheuer
 *
 */
public class SimpleProperty extends ObjectProperty {

	private String value;

	public SimpleProperty(String name, String value) {
		super(name);
		this.value = value;
	}

	public String getValueAsString() {
		return value;
	}

	@Override
	public String toString() {
		return "(" + name + "->" + value + ")";
	}
	
}
