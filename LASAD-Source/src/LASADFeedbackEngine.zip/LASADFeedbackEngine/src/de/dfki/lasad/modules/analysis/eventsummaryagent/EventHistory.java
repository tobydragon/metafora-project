package de.dfki.lasad.modules.analysis.eventsummaryagent;

import java.util.ArrayList;
import java.util.List;

import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.models.eue.SessionID;

public class EventHistory {
	
	private SessionID sessionId;
	private List<EUESessionEvent> eventHistory;
	
	public EventHistory(SessionID sessionId){
		this.sessionId = sessionId;
		this.eventHistory = new ArrayList<EUESessionEvent>();
	}
	
	public SessionID getSessionId() {
		return sessionId;
	}
	
	public List<EUESessionEvent> getEventHistory() {
		return eventHistory;
	}
	
	public void addEvent(EUESessionEvent eventToAdd){
		eventHistory.add(eventToAdd);
	}
	
	public String toString(){
		return "SessionID:" + sessionId + " - " + eventHistory.size() + " events";
	}

}
