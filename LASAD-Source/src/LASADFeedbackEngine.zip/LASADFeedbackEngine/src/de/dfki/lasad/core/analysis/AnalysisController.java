package de.dfki.lasad.core.analysis;

import java.util.List;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.PriorityBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.DefaultEventPrioritizer;
import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;

public class AnalysisController implements IAnalysisController {

	Log logger = LogFactory.getLog(AnalysisController.class);

	private IActionController actionController;
	private List<IAnalysisAgent> analysisAgents = new Vector<IAnalysisAgent>();

	private PriorityBlockingQueue<Event> queue = new PriorityBlockingQueue<Event>();
	private Thread workingThread;

	// collecting the results for a request
	private RequestManager requestManager = new RequestManager();

	public AnalysisController() {
		startWorkingThread();
	}

	private final void startWorkingThread() {
		workingThread = new Thread(new Consumer());
		workingThread.start();
	}

	@Override
	public void doWire(IActionController actionController) {
		this.actionController = actionController;
	}
	
	@Override
	public void addAnalysisAgent(IAnalysisAgent analysisAgent) {
		analysisAgents.add(analysisAgent);	
	}

	@Override
	public void onEUEEvent(EUESessionEvent eueEvent) {
		addEventToQueue(eueEvent);
	}

	@Override
	public void onAnalysisRequestEvent(AnalysisRequestEvent analysisRequestEvent) {
		addEventToQueue(analysisRequestEvent);
	}

	@Override
	public void onAnalysisResultEvent(AnalysisResultEvent analysisResultEvent) {
		addEventToQueue(analysisResultEvent);
	}

	private void addEventToQueue(Event event) {
		DefaultEventPrioritizer.assignPriority(event);
		queue.put(event);
	}

	private void processEUEEvent(EUESessionEvent eueEvent) {
		for (IAnalysisAgent analysisAgent : analysisAgents) {
			analysisAgent.onEUEEvent(eueEvent);
		}
	}

	private void processAnalysisRequestEvent(
			AnalysisRequestEvent analysisRequestEvent) {

		requestManager.addAnalysisRequest(analysisRequestEvent);
		sendOutAnalysisResultIfCompleted();
		Set<String> analysisAgentIDs = analysisRequestEvent.getQuery()
				.getAnalysisAgentIDs();

		for (String analysisAgentID : analysisAgentIDs) {
			IAnalysisAgent analysisAgent = getAnalysisAgent(analysisAgentID);
			analysisAgent.onAnalysisRequestEvent(analysisRequestEvent);
		}
	}

	private IAnalysisAgent getAnalysisAgent(String requestedAnalysisAgentID) {
		for (IAnalysisAgent analysisAgent : analysisAgents) {
			String analysisAgentIDToTest = analysisAgent.getComponentDescription()
					.getComponentID();
			if (requestedAnalysisAgentID.equals(analysisAgentIDToTest)) {
				return analysisAgent;
			}
		}
		logger.error("AnalysisAgent with ID '" + requestedAnalysisAgentID
				+ "' not registered.");
		return null;
	}

	private void processAnalysisResults(AnalysisResultEvent analysisResultEvent) {
		requestManager.updateAnalysisResults(analysisResultEvent);
		sendOutAnalysisResultIfCompleted();
	}

	private void sendOutAnalysisResultIfCompleted() {
		List<AnalysisResultEvent> completedResults = requestManager
				.removeCompletedResults();
		for (AnalysisResultEvent completedResult : completedResults) {
			forwardToActionController(completedResult);
		}

	}

	private void forwardToActionController(
			AnalysisResultEvent analysisResultEvent) {
		actionController.onAnalysisResultEvent(analysisResultEvent);
	}

	class Consumer implements Runnable {

		@Override
		public void run() {

			try {
				do {
					Event event = queue.take();

					if (event instanceof EUESessionEvent) {
						processEUEEvent((EUESessionEvent) event);
					} else if (event instanceof AnalysisRequestEvent) {
						processAnalysisRequestEvent((AnalysisRequestEvent) event);
					} else if (event instanceof AnalysisResultEvent) {
						processAnalysisResults((AnalysisResultEvent) event);
					} else{
						logger.warn("Unexpected event type received: " + event.toString());
					}
				} while (true);
			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage());
			}

		}

	}
}
