package de.dfki.lasad.core.analysis;

import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public interface OntologyChecker {

	/**
	 * Checks whether a provided {@link EUEOntology} is supported.
	 * 
	 * @param ontology
	 * @return
	 */
	public boolean isOntologySupported(EUEOntology ontology);
	
	public boolean allOntologiesSupported();
}
