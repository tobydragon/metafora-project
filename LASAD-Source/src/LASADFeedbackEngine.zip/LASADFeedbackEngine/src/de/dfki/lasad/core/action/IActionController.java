package de.dfki.lasad.core.action;

import de.dfki.lasad.core.analysis.IAnalysisController;
import de.dfki.lasad.core.dataservice.IDataService;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;

/**
 * Registration of {@link IActionAgent}s (system initialization time),
 * {@link Event}-distributing hub (execution time)
 * 
 * @author Oliver Scheuer
 * 
 */
public interface IActionController {

	/**
	 *  Establish runtime dependencies at system initialization time.
	 */
	public void doWire(IAnalysisController analysisController,
			IDataService dataService);

	public void addActionAgent(IActionAgent agent);

	// notification methods (execution time)
	public void onEUEEvent(EUESessionEvent eueEvent);

	public void onAnalysisRequestEvent(AnalysisRequestEvent analysisRequestEvent);

	public void onAnalysisResultEvent(AnalysisResultEvent analysisResultEvent);

	public void onActionSpecEvent(ActionSpecEvent actionSpecEvent);

}
