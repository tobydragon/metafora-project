package de.dfki.lasad.core.analysis;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.DefaultEventPrioritizer;
import de.dfki.lasad.core.PluggableComponentDescription;
import de.dfki.lasad.core.worldmodel.IModelController;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

public abstract class AbstractAnalysisAgent implements IAnalysisAgent {

	private Log logger = LogFactory.getLog(AbstractAnalysisAgent.class);

	protected AnalysisAgentDescription description;

	protected IAnalysisController analysisController;
	protected IModelController worldModel;

	private Set<SessionID> supportedSessions = new HashSet<SessionID>();

	private PriorityBlockingQueue<Event> queue = new PriorityBlockingQueue<Event>();
	private Thread workingThread;

	public AbstractAnalysisAgent() {
		startWorkingThread();
	}

	private final void startWorkingThread() {
		workingThread = new Thread(new Consumer());
		workingThread.start();
	}

	@Override
	public void configure(PluggableComponentDescription description)
			throws ComponentInitException {
		this.description = (AnalysisAgentDescription) description;
	}

	@Override
	public void doWire(IAnalysisController analysisController,
			IModelController worldModel) {
		this.analysisController = analysisController;
		this.worldModel = worldModel;
	}

	/**
	 * An invocation of this method is required to enable support for the
	 * provided {@link SessionID}.
	 */
	@Override
	public void requestSupportSession(SessionID sessionID, EUEOntology ontology) {
		if (this.description.getConfiguration().getOntologySupportChecker().isOntologySupported(ontology)) {
			supportedSessions.add(sessionID);
		}
	}

	@Override
	public AnalysisAgentDescription getComponentDescription() {
		return description;
	}

	@Override
	public void onAnalysisRequestEvent(AnalysisRequestEvent analysisRequestEvent) {
		addEventToQueue(analysisRequestEvent);
	}

	@Override
	public void onEUEEvent(EUESessionEvent eueEvent) {
		boolean supportSession = isSessionSupported(eueEvent.getSessionID());
		if (supportSession) {
			addEventToQueue(eueEvent);
		}
	}

	private boolean isSessionSupported(SessionID sessionID) {
		return supportedSessions.contains(sessionID);
	}

	private void addEventToQueue(Event event) {
		DefaultEventPrioritizer.assignPriority(event);
		queue.put(event);
	}

	protected abstract void processAnalysisRequestEvent(
			AnalysisRequestEvent request);

	protected abstract void processEUEEvent(EUESessionEvent eueEvent);

	class Consumer implements Runnable {

		@Override
		public void run() {

			try {
				do {
					Event event = queue.take();

					if (event instanceof EUESessionEvent) {
						processEUEEvent((EUESessionEvent) event);
					} else if (event instanceof AnalysisRequestEvent) {
						processAnalysisRequestEvent((AnalysisRequestEvent) event);
					} else {
						logger.warn("Unexpected event type received: "
								+ event.toString());
					}
				} while (true);
			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}

		}

	}

}
