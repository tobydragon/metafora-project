package de.dfki.lasad.core.analysis;

import java.util.HashSet;
import java.util.Set;

import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class SimpleOntologyChecker implements OntologyChecker {

	private Set<String> supportedOntologyIDs = new HashSet<String>();
	private boolean supportAll = true;

	/**
	 * All ontologies will be supported.
	 */
	public SimpleOntologyChecker() {
	}

	public SimpleOntologyChecker(Set<String> supportedOntologyIDs) {
		this.supportedOntologyIDs = supportedOntologyIDs;
		supportAll = false;
	}

	@Override
	public boolean isOntologySupported(EUEOntology ontology) {
		if (supportAll) {
			return true;
		}
		String ontologyID = ontology.getOntologyID();
		return supportedOntologyIDs.contains(ontologyID);
	}

	@Override
	public boolean allOntologiesSupported() {
		return supportAll;
	}
}
