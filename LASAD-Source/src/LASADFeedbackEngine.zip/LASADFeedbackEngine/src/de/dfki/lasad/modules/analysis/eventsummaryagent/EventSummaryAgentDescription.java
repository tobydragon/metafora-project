package de.dfki.lasad.modules.analysis.eventsummaryagent;

import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.analysis.IAnalysisAgentConfiguration;
import de.dfki.lasad.models.analysis.NumericalResult;
import de.dfki.lasad.models.analysis.StringResult;

public class EventSummaryAgentDescription extends AnalysisAgentDescription{
	
	private static final String agentName = "Event Summary";
	private static final String targetClass = EventSummaryAgent.class.getName();
	
	//does not join any maps
	public EventSummaryAgentDescription(){
		super(agentName, targetClass);
		
	}
	
	public EventSummaryAgentDescription(IAnalysisAgentConfiguration analysisConfig){
		super(agentName, targetClass, analysisConfig);
		addAnalysisTypes();
		
	}
	
	public void addAnalysisTypes(){
		AnalysisType indicator = new AnalysisType(StringResult.class, componentTypeID, "INDICATOR", true, getConfiguration().getOntologySupportChecker());
		indicator.setDisplayName("ImportantEvents");
		addAnalysisType(indicator);

	}

}
