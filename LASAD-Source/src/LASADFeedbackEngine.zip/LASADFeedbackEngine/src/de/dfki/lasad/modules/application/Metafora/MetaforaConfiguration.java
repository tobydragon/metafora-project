package de.dfki.lasad.modules.application.Metafora;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.SimpleAnalysisAgentConfiguration;
import de.dfki.lasad.core.application.AbstractAppConfiguration;
import de.dfki.lasad.core.dataservice.DataServiceDescription;
import de.dfki.lasad.core.worldmodel.JessModelControllerDescription;
import de.dfki.lasad.core.worldmodel.ModelControllerConfiguration;
import de.dfki.lasad.modules.action.xmpp.XmppActionAgentDescription;
import de.dfki.lasad.modules.analysis.eventsummaryagent.EventSummaryAgentDescription;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIConfiguration;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIDescription;

public class MetaforaConfiguration extends AbstractAppConfiguration{
	
	private LASADDataServiceRMIDescription dataServiceDescription;

	private List<AnalysisAgentDescription> analysisAgentDescriptions = new Vector<AnalysisAgentDescription>();
	private List<ActionAgentDescription> actionAgentDescriptions = new Vector<ActionAgentDescription>();

	public MetaforaConfiguration() {
		super();
		
		// create {@link LASADDataServiceDescription}
		LASADDataServiceRMIConfiguration dataServiceConf = LASADDataServiceRMIConfiguration.readDefaultConfig();
		dataServiceDescription = new LASADDataServiceRMIDescription(dataServiceConf);

		Set<String> metaforaOntologies = new HashSet<String>();
		metaforaOntologies.add("DiscussingMicroworlds-1");
		metaforaOntologies.add("ComparingMicroworlds-1");
		SimpleAnalysisAgentConfiguration metaforaConfiguration = new SimpleAnalysisAgentConfiguration(metaforaOntologies);
		analysisAgentDescriptions.add(new EventSummaryAgentDescription(metaforaConfiguration));
		
		
		actionAgentDescriptions.add(new XmppActionAgentDescription());
		
		Set<String> worldModelSupportedOntologies = new HashSet<String>();
		worldModelSupportedOntologies.add("DISABLE");
		this.modelControllerDescr = new JessModelControllerDescription( new ModelControllerConfiguration(worldModelSupportedOntologies));
	}

	@Override
	public DataServiceDescription getDataServiceDescription() {
		return dataServiceDescription;
	}

	@Override
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions() {
		return analysisAgentDescriptions;
	}

	@Override
	public List<ActionAgentDescription> getActionAgentDescriptions() {
		return actionAgentDescriptions;
	}

}
