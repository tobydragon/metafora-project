package de.dfki.lasad.modules.action.jess;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.PluggableComponentDescription;
import de.dfki.lasad.core.action.AbstractActionAgent;
import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.action.ActionType;
import de.dfki.lasad.core.action.CompoundActionType;
import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.core.action.RuleBasedActionType;
import de.dfki.lasad.core.action.SimpleActionType;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.core.worldmodel.IModelController;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.UserFeedbackRequestEvent;
import de.dfki.lasad.models.action.ActionComponent;
import de.dfki.lasad.models.action.ActionComponentSpec;
import de.dfki.lasad.models.action.AnalysisMirroringActionSpec;
import de.dfki.lasad.models.action.MessageWithHighlighting;
import de.dfki.lasad.models.action.Message;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.analysis.AnalyzableEntity;
import de.dfki.lasad.models.analysis.NoAnalysisResults;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackRequestSpec;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackTypeID;

public class JessFeedbackAgent extends AbstractActionAgent {

	private Log logger = LogFactory.getLog(JessFeedbackAgent.class);

	public static final int ALL_RESULTS = -1;

	private JessFeedbackAgentConfiguration jessAgentConf;

	private Comparator<ActionTypeUtilityPair> actionTypeUtilityPairComparator = new Comparator<ActionTypeUtilityPair>() {
		@Override
		public int compare(ActionTypeUtilityPair o1, ActionTypeUtilityPair o2) {
			double utilityDiff = o2.utility - o1.utility;
			if (utilityDiff == 0) {
				return 0;
			}
			return (utilityDiff > 0) ? 1 : -1;
		}
	};

	private Comparator<PhaseIDProbabilityPair> phaseIDProbabilityPairComparator = new Comparator<PhaseIDProbabilityPair>() {
		@Override
		public int compare(PhaseIDProbabilityPair o1, PhaseIDProbabilityPair o2) {
			double utilityDiff = o2.probability - o1.probability;
			if (utilityDiff == 0) {
				return 0;
			}
			return (utilityDiff > 0) ? 1 : -1;
		}
	};

	public JessFeedbackAgent() {
		super();
	}

	@Override
	public void configure(PluggableComponentDescription description) {
		super.configure(description);
	}

	@Override
	public ActionAgentDescription getComponentDescription() {
		return (JessFeedbackAgentDescription) description;
	}

	@Override
	public void onAnalysisResultEvent(AnalysisResultEvent analysisResultEvent) {
		// ignore
	}

	@Override
	public void onActionSpecEvent(ActionSpecEvent actionSpecEvent) {
		// ignore
	}

	@Override
	public void onEUEEvent(EUESessionEvent eueEvent) {
		if (eueEvent instanceof UserFeedbackRequestEvent) {
			logger.debug("Add event to queue: " + eueEvent.toString());
			addEventToQueue(eueEvent);
		} else {
			// ignore all EUEEvents except feedback requests
		}
	}

	@Override
	public void processActionSpecEvent(ActionSpecEvent actionSpecEvent) {
		// ignore
	}

	@Override
	public void processAnalysisResultEvent(
			AnalysisResultEvent analysisResultEvent) {
		// ignore
	}

	@Override
	public void processEUEEvent(EUESessionEvent eueEvent) {
		// ignore
	}

	@Override
	public void processUserFeedbackRequestEvent(
			UserFeedbackRequestEvent feedbackRequestEvent) {
		try {
			logger.debug("Start processing event: " + feedbackRequestEvent
					+ " ...");
			SessionID sessionID = feedbackRequestEvent.getSessionID();

			// Request {@link AnalysisResult}s
			FeedbackRequestSpec feedbackReqSpec = feedbackRequestEvent
					.getFeedbackRequestSpec();
			FeedbackTypeID fType = feedbackReqSpec.getFeedbackTypeID();
			ActionType aType = ServiceRegistry.getActionType(fType
					.getFeedbackProvider(), fType.getFeedbackType());
			Map<AnalysisType, List<AnalysisResult>> type2results = worldModel
					.getAnalysisResults(sessionID, aType);
			logRetrievedAnalysisResults(type2results);

			// Sort and filter results, if necessary
			List<AnalysisResult> orderedResultList;
			Map<String, Double> phaseProbabilities = null;
			if (aType instanceof CompoundActionType) {
				CompoundActionType compoundActionType = (CompoundActionType) aType;

				// determine phase probabilities
				Set<String> phaseIDs = jessAgentConf.getPhaseIDs();
				Set<ActionType> requestedActionTypes = compoundActionType
						.getSubActionTypes();
				phaseProbabilities = PhaseModeler.getPhaseProbabilities(
						phaseIDs, requestedActionTypes, type2results);

				// sort and filter results
				int maxNumResults = feedbackReqSpec.getNumResults();
				if (maxNumResults == FeedbackRequestSpec.NOT_SPECIFIED) {
					maxNumResults = compoundActionType.getMaxNumResults();
					if (maxNumResults == CompoundActionType.ALL_RESULTS) {
						maxNumResults = JessFeedbackAgent.ALL_RESULTS;
					}
				} else if (maxNumResults == FeedbackRequestSpec.ALL_RESULTS) {
					maxNumResults = JessFeedbackAgent.ALL_RESULTS;
				}
				orderedResultList = sortAndFilter(phaseProbabilities,
						compoundActionType, type2results, maxNumResults);
			} else {
				orderedResultList = new Vector<AnalysisResult>();
				for (AnalysisType type : type2results.keySet()) {
					for (AnalysisResult result : type2results.get(type)) {
						orderedResultList.add(result);
					}
				}
			}

			UserID originalRequestorID = feedbackRequestEvent.getUserID();

			// Compose and send {@link ActionSpecEvent}
			ActionSpecEvent incompleteSpecEvent = new ActionSpecEvent(
					sessionID, getComponentDescription().getComponentID());
			if (jessAgentConf.provideRawResults()
					|| feedbackReqSpec.isRequestRawResults()) {
				generateAndSendRawResults(incompleteSpecEvent, aType,
						orderedResultList, originalRequestorID);
			} else {
				generateAndSendFeedback(incompleteSpecEvent, aType,
						orderedResultList, phaseProbabilities,
						originalRequestorID);
			}
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}

	/**
	 * 
	 * <p>
	 * Generates an {@link ActionComponentSpec} for each provided
	 * {@link AnalysisResult}, adds these {@link ActionComponentSpec}s to the
	 * provided {@link ActionSpecEvent} and sends out this
	 * {@link ActionSpecEvent}.
	 * </p>
	 * 
	 * <p>
	 * {@link ActionComponentSpec}s contain {@link ActionComponent}s as
	 * specified by the corresponding {@link ActionType} ({@link Message} and
	 * {@link MessageWithHighlighting} commands).
	 * </p>
	 * 
	 * @param incompleteSpecEvent
	 * @param orderedResultList
	 */
	private void generateAndSendFeedback(ActionSpecEvent incompleteSpecEvent,
			ActionType aType, List<AnalysisResult> orderedResultList,
			Map<String, Double> phaseProbabilities, UserID originalRequestorID) {

		// sort phase IDs according probability
		List<PhaseIDProbabilityPair> phaseIDsOrdered = null;
		if (phaseProbabilities != null) {
			phaseIDsOrdered = new Vector<PhaseIDProbabilityPair>();
			for (String phaseID : phaseProbabilities.keySet()) {
				double probability = phaseProbabilities.get(phaseID);
				PhaseIDProbabilityPair pair = new PhaseIDProbabilityPair(
						phaseID, probability);
				phaseIDsOrdered.add(pair);
			}
			Collections.sort(phaseIDsOrdered, phaseIDProbabilityPairComparator);
		}

		if (orderedResultList.size() == 0) {
			sendNoFeedbackAvailableMessage(incompleteSpecEvent,
					originalRequestorID);
			return;
		}

		for (AnalysisResult result : orderedResultList) {
			if (result.getAnalysisType() instanceof SimpleActionType) {
				SimpleActionType actionType = (SimpleActionType) result
						.getAnalysisType();
				ActionComponentSpec componentSpec = new ActionComponentSpec();
				componentSpec.setActionRecipient(originalRequestorID);

				// get text and highlighting
				String feedbackShort = null;
				String feedbackLong = null;
				Boolean doHighlighting = null;

				Map<String, String> additionalParams = null;
				if (phaseIDsOrdered != null) {
					for (PhaseIDProbabilityPair phaseIDProbPair : phaseIDsOrdered) {
						feedbackShort = actionType
								.getFeedbackShort(phaseIDProbPair.phaseID);

						if (feedbackShort != null) {
							// minimal requirement: short feedback available

							if (feedbackShort.contains("##")) {
								feedbackShort = fillInProperties(feedbackShort,
										result.getProperties());
							}

							feedbackLong = actionType
									.getFeedbackLong(phaseIDProbPair.phaseID);

							if (feedbackLong != null
									&& feedbackLong.contains("##")) {
								feedbackLong = fillInProperties(feedbackLong,
										result.getProperties());
							}

							doHighlighting = actionType
									.doHighlighting(phaseIDProbPair.phaseID);

							additionalParams = new HashMap<String, String>();
							Set<String> dynamicParams = actionType
									.getDynamicParamNames(phaseIDProbPair.phaseID);
							if (dynamicParams != null) {
								for (String paramName : dynamicParams) {
									String paramValue = result.getProperties()
											.get(paramName);
									if (paramValue != null) {
										additionalParams.put(paramName,
												paramValue);
									} else {
										logger
												.warn("No value available for (dynamic) param '"
														+ paramName
														+ "' from result: "
														+ result.toString());
									}
								}
							}
							Set<String> staticParams = actionType
									.getParamNames(phaseIDProbPair.phaseID);
							if (staticParams != null) {
								for (String paramName : staticParams) {
									String paramValue = actionType
											.getParamValue(
													phaseIDProbPair.phaseID,
													paramName);
									if (paramValue != null) {
										additionalParams.put(paramName,
												paramValue);
									} else {
										logger
												.warn("No value available for (static) param '"
														+ paramName + "'");
									}
								}
							}
							break;
						}
					}
				}
				if (feedbackShort == null) {
					// no feedback found
					feedbackShort = actionType.getFeedbackShort();
					if (feedbackShort != null && feedbackShort.contains("##")) {
						feedbackShort = fillInProperties(feedbackShort, result
								.getProperties());
					}
				}

				if (feedbackLong == null) {
					// no feedback found
					feedbackLong = actionType.getFeedbackLong();
					if (feedbackLong != null && feedbackLong.contains("##"))
						feedbackLong = fillInProperties(feedbackLong, result
								.getProperties());
				}

				if (doHighlighting == null) {
					// no highlighting found
					doHighlighting = actionType.doHighlighting();
				}

				if (additionalParams == null) {
					// no add params found
					additionalParams = new HashMap<String, String>();
					Set<String> dynamicParams = actionType
							.getDynamicParamNames();
					if (dynamicParams != null) {
						for (String paramName : dynamicParams) {
							String paramValue = result.getProperties().get(
									paramName);
							if (paramValue != null) {
								additionalParams.put(paramName, paramValue);
							} else {
								logger
										.warn("No value available for (dynamic) param '"
												+ paramName
												+ "' from result: "
												+ result.toString());
							}
						}
					}
					Set<String> staticParams = actionType.getParamNames();
					if (staticParams != null) {
						for (String paramName : actionType.getParamNames()) {
							String paramValue = actionType
									.getParamValue(paramName);
							if (paramValue != null) {
								additionalParams.put(paramName, paramValue);
							} else {
								logger
										.warn("No value available for (static) param '"
												+ paramName + "'");
							}
						}
					}
				}

				AnalyzableEntity entity = result.getAnalyzableEntity();
				if (doHighlighting && !(entity.getEntityComponents().isEmpty())) {
					MessageWithHighlighting highlighting;
					if (feedbackLong != null) {
						highlighting = new MessageWithHighlighting(
								feedbackShort, feedbackLong, entity);
					} else {
						highlighting = new MessageWithHighlighting(
								feedbackShort, entity);
					}
					highlighting.setParameters(additionalParams);
					componentSpec.addActionComponent(highlighting);
				} else {
					// create text message without highlighting
					Message message;
					if (feedbackLong != null) {
						message = new Message(feedbackShort, feedbackLong);
					} else {
						message = new Message(feedbackShort);
					}
					message.setParameters(additionalParams);
					componentSpec.addActionComponent(message);
				}
				incompleteSpecEvent.addActionSpec(componentSpec);
			}
		}
		forwardToActionController(incompleteSpecEvent);
		logger.debug("Generated feedback: " + incompleteSpecEvent.toString());
	}

	private void sendNoFeedbackAvailableMessage(
			ActionSpecEvent incompleteSpecEvent, UserID originalRequestorID) {
		ActionComponentSpec componentSpec = new ActionComponentSpec();
		componentSpec.setActionRecipient(originalRequestorID);
		String messageString = "No feedback available";
		Message message = new Message(messageString);
		componentSpec.addActionComponent(message);
		incompleteSpecEvent.addActionSpec(componentSpec);
		forwardToActionController(incompleteSpecEvent);
	}

	/**
	 * 
	 * Generates an {@link AnalysisMirroringActionSpec} that contains all
	 * provided {@link AnalysisResult}s, adds this
	 * {@link AnalysisMirroringActionSpec} to the provided
	 * {@link ActionSpecEvent} and sends out this {@link ActionSpecEvent}.
	 * 
	 * @param incompleteSpecEvent
	 * @param orderedResultList
	 */
	private void generateAndSendRawResults(ActionSpecEvent incompleteSpecEvent,
			ActionType aType, List<AnalysisResult> orderedResultList,
			UserID originalRequestorID) {
		AnalysisMirroringActionSpec resultMirroringSpec = new AnalysisMirroringActionSpec();
		resultMirroringSpec.setActionRecipient(originalRequestorID);
		if (orderedResultList.size() == 0) {
			/**
			 * sendNoFeedbackAvailableMessage(incompleteSpecEvent,
			 * originalRequestorID); return;
			 */
			// add indicator for no result
			NoAnalysisResults noResults = new NoAnalysisResults(aType);
			orderedResultList.add(noResults);
		}
		for (AnalysisResult result : orderedResultList) {
			resultMirroringSpec.addActionComponent(result);
		}
		incompleteSpecEvent.addActionSpec(resultMirroringSpec);
		forwardToActionController(incompleteSpecEvent);
		logger
				.debug("Generated raw results: "
						+ incompleteSpecEvent.toString());
	}

	/**
	 * Sorts and filters the provided {@link AnalysisResult}s.
	 * {@link AnalysisResult}s are sorted accorded to their expected utility
	 * (sum of priority values weighted by phase probability). Only one result
	 * for each {@link AnalysisType} is provided. The sorted result list is cut
	 * off according to the maximum number of results indicated by the
	 * {@link CompoundActionType}.
	 * 
	 * @param compoundActionType
	 * @param actualResults
	 * @return
	 */
	private List<AnalysisResult> sortAndFilter(
			Map<String, Double> phaseProbabilities,
			CompoundActionType compoundActionType,
			Map<AnalysisType, List<AnalysisResult>> actualResults,
			int maxNumResults) {
		Set<String> phaseIDs = phaseProbabilities.keySet();

		List<ActionTypeUtilityPair> orderedActionTypes = new Vector<ActionTypeUtilityPair>();
		for (AnalysisType foundAnalysisType : actualResults.keySet()) {
			if (foundAnalysisType instanceof SimpleActionType) {
				SimpleActionType foundSimpleActionType = (SimpleActionType) foundAnalysisType;
				double weightedPriority = 0;
				for (String phaseID : phaseIDs) {
					double phaseProb = phaseProbabilities.get(phaseID);
					double priority = foundSimpleActionType
							.getPriority(phaseID);
					weightedPriority += (phaseProb * priority);
				}
				ActionTypeUtilityPair actionUtilityPair = new ActionTypeUtilityPair(
						foundSimpleActionType, weightedPriority);

				orderedActionTypes.add(actionUtilityPair);
			}
		}

		Collections.sort(orderedActionTypes, actionTypeUtilityPairComparator);

		List<AnalysisResult> orderedAnalysisResults = new Vector<AnalysisResult>();

		int count = 0;
		logger.debug("Utility for best-" + maxNumResults + " action types:");

		boolean one_per_type = compoundActionType.getCriteria().contains(
				CompoundActionType.ONE_PER_TYPE);
		for (ActionTypeUtilityPair actionTypeUtilityPair : orderedActionTypes) {

			String typeID = actionTypeUtilityPair.actionType.getTypeID();
			logger.debug("Expected utility for '" + typeID + "': "
					+ actionTypeUtilityPair.utility);
			List<AnalysisResult> resultsForType = actualResults
					.get(actionTypeUtilityPair.actionType);
			for (AnalysisResult result : resultsForType) {
				orderedAnalysisResults.add(result);
				if (one_per_type) {
					break;
				}
			}

			++count;
			if (count == maxNumResults) {
				break;
			}
		}

		logger.debug("Filtered and sorted results:");
		int i = 1;
		for (AnalysisResult result : orderedAnalysisResults) {
			logger.debug("(" + i + "): " + result);
			++i;
		}

		return orderedAnalysisResults;
	}

	private void logRetrievedAnalysisResults(
			Map<AnalysisType, List<AnalysisResult>> type2results) {
		logger.debug("Analysis results: " + type2results.keySet().size()
				+ " different result types.");
		for (AnalysisType type : type2results.keySet()) {
			logger.debug(type.getAgentID() + ", " + type.getTypeID() + ": "
					+ type2results.get(type));
		}
	}

	@Override
	public void doWire(IActionController actionController,
			IModelController worldModel) {
		super.doWire(actionController, worldModel);
		jessAgentConf = (JessFeedbackAgentConfiguration) description
				.getConfiguration();
		for (RuleBasedActionType actionType : jessAgentConf
				.getRuleBaseActionTypes()) {
			worldModel
					.registerAnalysisPattern(actionType, actionType.getRule());
		}
	}

	private String fillInProperties(String text,
			Map<String, String> propName2Value) {
		for (String propName : propName2Value.keySet()) {
			String propValue = propName2Value.get(propName);
			text = text.replace("[##" + propName + "##]", propValue);
		}
		return text;
	}

	private class ActionTypeUtilityPair {
		ActionType actionType;
		double utility;

		public ActionTypeUtilityPair(ActionType actionType, double utility) {
			this.actionType = actionType;
			this.utility = utility;
		}

		@Override
		public String toString() {
			return "[" + actionType.getAgentID() + ", "
					+ actionType.getTypeID() + ": " + utility + "]";
		}
	}

	private class PhaseIDProbabilityPair {
		String phaseID;
		double probability;

		public PhaseIDProbabilityPair(String phaseID, double probability) {
			this.phaseID = phaseID;
			this.probability = probability;
		}

		@Override
		public String toString() {
			return "[" + phaseID + ": " + probability + "]";
		}
	}
}
