package de.dfki.lasad.modules.action.xmpp;

import de.dfki.lasad.core.action.ActionAgentDescription;

public class XmppActionAgentDescription extends ActionAgentDescription{
		
	private static String className = XmppActionAgent.class.getName();

	public XmppActionAgentDescription() {
		super(className);
		setComponentID("XMPP");
		
		//don't think we need these because they are for user-end menu
		//setActionTypes();
	}

}
