package de.dfki.lasad.modules.analysis.deeploop;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.graphdrawing.graphml.xmlns.x1.GraphmlDocument;

import de.dfki.argunaut.deeploop.api.ClassifierDescription;
import de.dfki.argunaut.deeploop.api.datamodel.Classification;
import de.dfki.argunaut.deeploop.api.datamodel.Classifications;
import de.dfki.argunaut.deeploop.api.exceptions.WSException;
import de.dfki.argunaut.deeploop.service.wsclient.ClassifierProxy;
import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.PluggableComponentDescription;
import de.dfki.lasad.core.analysis.AbstractAnalysisAgent;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.analysis.AnalyzableEntity;
import de.dfki.lasad.models.analysis.BinaryResult;
import de.dfki.lasad.models.eue.EUEID;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.objects.EUEObjectID;
import de.dfki.lasad.modules.analysis.FlatGraphModeler;
import de.dfki.lasad.modules.analysis.deeploop.graphml.GraphMLDocumentFactory;

public class DeepLoopAnalysisAgent extends AbstractAnalysisAgent {

	Log logger = LogFactory.getLog(DeepLoopAnalysisAgent.class);

	String componentID;

	private DeepLoopAnalysisAgentConfiguration conf;

	private ClassifierProxy classifierService;

	private Map<SessionID, FlatGraphModeler> sessions;

	public DeepLoopAnalysisAgent() {
		// We initialize the discussion graphs
		sessions = new HashMap<SessionID, FlatGraphModeler>();
	}

	@Override
	public void configure(PluggableComponentDescription description)
			throws ComponentInitException {
		super.configure(description);

		conf = (DeepLoopAnalysisAgentConfiguration) description
				.getConfiguration();
		componentID = description.getComponentID();
		try {
			String serviceAddress = conf.getWsAddress();
			classifierService = new ClassifierProxy(serviceAddress);

			Collection<ClassifierDescription> classifierDescriptions = classifierService
					.getClassifiers(Locale.getDefault(), Locale.getDefault());

			for (ClassifierDescription classifierDescription : classifierDescriptions) {
				logger.debug("Available classifiers"
						+ classifierDescription.getId());
			}

		} catch (WSException e) {
			throw new ComponentInitException("Error while initiating "
					+ getClass(), e);
		}

	}

	@Override
	public DeepLoopAnalysisAgentDescription getComponentDescription() {
		return (DeepLoopAnalysisAgentDescription) description;
	}

	@Override
	public void processEUEEvent(EUESessionEvent eueEvent) {
		if (eueEvent instanceof UserObjectActionEvent) {
			UserObjectActionEvent objectActionEvent = (UserObjectActionEvent) eueEvent;

			SessionID sessionID = eueEvent.getSessionID();
			FlatGraphModeler graphModeler = sessions.get(sessionID);
			if (graphModeler == null) {
				// new session
				graphModeler = new FlatGraphModeler(conf
						.getMappingConfiguration());
				sessions.put(sessionID, graphModeler);
			}
			graphModeler.executeEvent(objectActionEvent);
		}
	}

	/**
	 * TODO: Build in caching for classifications
	 */
	@Override
	public void processAnalysisRequestEvent(
			AnalysisRequestEvent analysisRequestEvent) {

		SessionID sessionID = analysisRequestEvent.getSessionID();
		FlatGraphModeler graphModeler = sessions.get(sessionID);
		if (graphModeler == null) {
			// TODO throw exception
			logger.warn("Analysis Request without any previous "
					+ "UserObjectActionEvent in session " + sessionID);
			// new session
			graphModeler = new FlatGraphModeler(conf.getMappingConfiguration());
			sessions.put(sessionID, graphModeler);
		}

		graphModeler.updateFlatRepresentations();
		GraphmlDocument graphMLDoc = GraphMLDocumentFactory.fillGML(sessionID,
				graphModeler);

		Set<String> analysisIDs = analysisRequestEvent.getQuery()
				.getAnalysisTypeIDs(componentID);

		Vector<AnalysisResult> allResults = new Vector<AnalysisResult>();
		for (String analysisID : analysisIDs) {
			Vector<BinaryResult> resultsOfOneClassifier = requestAnalysisResults(
					analysisID, graphMLDoc);
			allResults.addAll(resultsOfOneClassifier);
		}
		createAndIssueAnalysisResultEvent(analysisRequestEvent, allResults);
	}

	private void createAndIssueAnalysisResultEvent(
			AnalysisRequestEvent analysisRequestEvent,
			List<AnalysisResult> allResults) {

		AnalysisResultEvent resultEvent = new AnalysisResultEvent(
				analysisRequestEvent.getTransactionID(), analysisRequestEvent
						.getSessionID(), componentID, analysisRequestEvent
						.getSourceComponentID(), allResults);

		// to ensure coverage of empty result sets
		Set<AnalysisType> coveredAnalysisTypes = analysisRequestEvent
				.getQuery().getAnalysisTypes(componentID);
		for (AnalysisType aType : coveredAnalysisTypes) {
			resultEvent.addCoveredResultType(aType);
		}
		analysisController.onAnalysisResultEvent(resultEvent);
	}

	private Vector<BinaryResult> requestAnalysisResults(String analysisID,
			GraphmlDocument graphMLDoc) {
		AnalysisType analysisType = getComponentDescription().getAnalysisType(
				analysisID);
		Vector<BinaryResult> results = new Vector<BinaryResult>();
		try {
			Classifications classifications = classifierService
					.applyClassifier(analysisID, graphMLDoc);

			for (Classification classification : classifications
					.getClassifications()) {
				BinaryResult result = createAnalysisResult(analysisType,
						classification);
				results.add(result);
			}
		} catch (Exception e) {
			logger.error("Applying classifier '" + analysisID + "' failed.", e);
		}
		return results;
	}

	private BinaryResult createAnalysisResult(AnalysisType analysisType,
			Classification classification) {
		Boolean classificationResult = Classification.POSITIVE
				.equals(classification.getClassification());
		AnalyzableEntity analyzedEntity = createAnalyzableEntity(classification);

		BinaryResult result = new BinaryResult(analysisType, analyzedEntity,
				classificationResult);
		return result;
	}

	private AnalyzableEntity createAnalyzableEntity(
			Classification classification) {
		Collection<String> objectIDs = classification.getInstance()
				.getObjectIds();
		List<EUEID> eueIDList = new Vector<EUEID>();
		for (String id : objectIDs) {
			eueIDList.add(new EUEObjectID(id));
		}
		AnalyzableEntity analyzableEntity = new AnalyzableEntity(eueIDList);
		return analyzableEntity;
	}

}
