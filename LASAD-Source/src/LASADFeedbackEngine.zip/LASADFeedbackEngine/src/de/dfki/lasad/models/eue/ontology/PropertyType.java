package de.dfki.lasad.models.eue.ontology;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class PropertyType {

	public static final String SINGLE = "SINGLE";
	public static final String MULTI = "MULTI";

	// Value cardinality constants
	private String propertyTypeID;
	private String valueCardinality;

	public PropertyType(String propertyTypeID, String valueCardinality) {
		this.propertyTypeID = propertyTypeID;
		this.valueCardinality = valueCardinality;
	}

	public String getPropertyTypeID() {
		return propertyTypeID;
	}

	public void setPropertyTypeID(String propertyTypeID) {
		this.propertyTypeID = propertyTypeID;
	}

	public String getValueCardinality() {
		return valueCardinality;
	}

	public void setValueCardinality(String valueCardinality) {
		this.valueCardinality = valueCardinality;
	}

}
