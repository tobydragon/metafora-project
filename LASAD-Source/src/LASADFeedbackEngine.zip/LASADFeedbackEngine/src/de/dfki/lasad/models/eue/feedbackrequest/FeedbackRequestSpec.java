package de.dfki.lasad.models.eue.feedbackrequest;

import de.dfki.lasad.core.action.IActionAgent;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.models.action.ActionComponentSpec;
import de.dfki.lasad.models.action.AnalysisMirroringActionSpec;
import de.dfki.lasad.models.analysis.AnalysisResult;

public class FeedbackRequestSpec {

	public static final int NOT_SPECIFIED = -2;
	public static final int ALL_RESULTS = -1;
	

	private FeedbackTypeID feedbackTypeID;
	private int numResults = NOT_SPECIFIED;
	private boolean requestRawResults = false;

	public FeedbackRequestSpec(FeedbackTypeID feedbackTypeID) {
		this.feedbackTypeID = feedbackTypeID;
	}

	public FeedbackTypeID getFeedbackTypeID() {
		return feedbackTypeID;
	}

	public void setNumResults(int numResults) {
		this.numResults = numResults;
	}

	public int getNumResults() {
		return numResults;
	}

	/**
	 * Indicates whether 'raw' {@link AnalysisResult}s (packaged in an
	 * {@link AnalysisMirroringActionSpec}) should be provided instead of
	 * end-user feedback (or other agent actions) that resulted from a feedback
	 * strategy (packaged in an {@link ActionComponentSpec}s). Option 1 is
	 * particularly useful for debugging of analyses carried out by
	 * {@link IActionAgent}s ( {@link AnalysisResult}s produced by
	 * {@link IAnalysisAgent}s can be accessed by querying the
	 * {@link IAnalysisAgent}s directly (to do so analysis mirroring in
	 * {@link FeedbackTypeID} must be enabled).
	 * 
	 * @return
	 */
	public boolean isRequestRawResults() {
		return requestRawResults;
	}

	public void setRequestRawResults(boolean requestRawResults) {
		this.requestRawResults = requestRawResults;
	}

	@Override
	public String toString() {
		return "FeedbackRequestSpec [feedbackTypeID=" + feedbackTypeID
				+ ", numResults=" + numResults + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((feedbackTypeID == null) ? 0 : feedbackTypeID.hashCode());
		result = prime * result + numResults;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FeedbackRequestSpec other = (FeedbackRequestSpec) obj;
		if (feedbackTypeID == null) {
			if (other.feedbackTypeID != null)
				return false;
		} else if (!feedbackTypeID.equals(other.feedbackTypeID))
			return false;
		if (numResults != other.numResults)
			return false;
		return true;
	}

}
