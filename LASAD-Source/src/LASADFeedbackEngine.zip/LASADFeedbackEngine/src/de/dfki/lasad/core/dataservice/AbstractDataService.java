package de.dfki.lasad.core.dataservice;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.DefaultEventPrioritizer;
import de.dfki.lasad.core.PluggableComponentDescription;
import de.dfki.lasad.core.action.ActionType;
import de.dfki.lasad.core.action.IActionAgent;
import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.core.analysis.IAnalysisController;
import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.session.AgentJoinSessionConfirmEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * Provides default implementations for most methods, most notably an
 * {@link PriorityBlockingQueue<Event>} to keep received {@link Event}s and a
 * {@link Thread} that dequeues and processes {@link Event}s.
 * 
 * @author Oliver Scheuer
 * 
 */
public abstract class AbstractDataService implements IDataService {

	protected DataServiceDescription description;

	Log logger = LogFactory.getLog(AbstractDataService.class);

	protected IAnalysisController analysisController;
	protected IActionController actionController;

	protected Map<SessionID, Set<AnalysisType>> session2analysisServices = new HashMap<SessionID, Set<AnalysisType>>();
	protected Map<SessionID, Set<ActionType>> session2actionServices = new HashMap<SessionID, Set<ActionType>>();
	protected Set<SessionID> sessionsThatCanBeSupportedWithServices = new HashSet<SessionID>();

	private PriorityBlockingQueue<Event> queue = new PriorityBlockingQueue<Event>();
	private Thread workingThread;

	public AbstractDataService() {
		startWorkingThread();
	}

	private final void startWorkingThread() {
		workingThread = new Thread(new Consumer());
		workingThread.start();
	}

	@Override
	public abstract void startService();

	@Override
	public abstract void prepareService();

	@Override
	public void doWire(IAnalysisController analysisController,
			IActionController actionController) {
		this.analysisController = analysisController;
		this.actionController = actionController;
	}

	protected void clearServiceLists() {
		session2analysisServices = new HashMap<SessionID, Set<AnalysisType>>();
		session2actionServices = new HashMap<SessionID, Set<ActionType>>();
	}

	protected void addServicesForSession(SessionID sessionID, EUEOntology sessionOntology) {
		addAnalysisServicesForSession(sessionID, sessionOntology);

		logger
				.info("The following analysis services can be provided for session "
						+ sessionID
						+ ": "
						+ session2analysisServices.get(sessionID));
		addActionServicesForSession(sessionID, sessionOntology);
		logger
				.info("The following action services can be provided for session "
						+ sessionID
						+ ": "
						+ session2actionServices.get(sessionID));
	}

	private void addAnalysisServicesForSession(SessionID sessionID,EUEOntology sessionOntology) {
		
		for (String analysisAgentID : ServiceRegistry.getAnalysisAgentIDs()) {
			IAnalysisAgent agent = ServiceRegistry.getAnalysisAgent(analysisAgentID);
			agent.requestSupportSession(sessionID, sessionOntology);
			
			AnalysisAgentDescription agentDescription = agent.getComponentDescription();
			for (AnalysisType analysisType : agentDescription.getAllAnalysisTypes()) {
				if (analysisType.doPublishToEndUser() && analysisType.isOntologySupported(sessionOntology)) {
					addAnalysisService(sessionID, analysisType);
				}
			}
		}
	}

	private void addAnalysisService(SessionID sessionID, AnalysisType analysisType) {
		Set<AnalysisType> analysisTypesForSession = session2analysisServices.get(sessionID);
		if (analysisTypesForSession == null) {
			analysisTypesForSession = new HashSet<AnalysisType>();
			session2analysisServices.put(sessionID, analysisTypesForSession);
		}
		analysisTypesForSession.add(analysisType);
		sessionsThatCanBeSupportedWithServices.add(sessionID);
	}

	private void addActionServicesForSession(SessionID sessionID,
			EUEOntology sessionOntology) {
		for (String actionAgentID : ServiceRegistry.getActionAgentIDs()) {
			IActionAgent agent = ServiceRegistry.getActionAgent(actionAgentID);
			for (ActionType actionType : agent.getComponentDescription()
					.getAllActionTypes()) {
				if (actionType.doPublishToEndUser()
						&& actionType.isOntologySupported(sessionOntology)) {
					addActionService(sessionID, actionType);
				}
			}
		}
	}

	private void addActionService(SessionID sessionID, ActionType actionType) {
		Set<ActionType> actionTypesForSession = session2actionServices
				.get(sessionID);
		if (actionTypesForSession == null) {
			actionTypesForSession = new HashSet<ActionType>();
			session2actionServices.put(sessionID, actionTypesForSession);
		}
		actionTypesForSession.add(actionType);
		sessionsThatCanBeSupportedWithServices.add(sessionID);
	}

	@Override
	public void configure(PluggableComponentDescription description) {
		this.description = (DataServiceDescription) description;

	}

	@Override
	public DataServiceDescription getComponentDescription() {
		return description;
	}

	@Override
	public void onActionSpecEvent(ActionSpecEvent event) {
		addEventToQueue(event);
	}

	public void onAgentJoinSessionConfirmEvent(
			AgentJoinSessionConfirmEvent confirmEvent) {
		addEventToQueue(confirmEvent);
	}

	protected abstract void processActionSpecEvent(ActionSpecEvent event);

	protected abstract void processAgentJoinSessionConfirmEvent(
			AgentJoinSessionConfirmEvent event);

	protected void processEUEEvent(EUEEvent eueEvent) {
		logger.debug("Start processing event: " + eueEvent.toString());
		if (eueEvent instanceof EUESessionEvent) {
			analysisController.onEUEEvent((EUESessionEvent) eueEvent);
			actionController.onEUEEvent((EUESessionEvent) eueEvent);
		}
	}

	protected void addEventToQueue(Event event) {
		DefaultEventPrioritizer.assignPriority(event);
		queue.put(event);
		logger.debug("[addEventToQueue]Added event - " + event.toString());
	}

	protected IAnalysisController getAnalysisController() {
		return analysisController;
	}

	protected IActionController getActionController() {
		return actionController;
	}

	class Consumer implements Runnable {

		@Override
		public void run() {

			try {
				do {
					Event event = queue.take();
					logger.debug("[run]Removed from queue, event - " + event.toString());
					if (event instanceof EUEEvent) {
						processEUEEvent((EUEEvent) event);
					} else if (event instanceof ActionSpecEvent) {
						processActionSpecEvent((ActionSpecEvent) event);
					} else if (event instanceof AgentJoinSessionConfirmEvent) {
						processAgentJoinSessionConfirmEvent((AgentJoinSessionConfirmEvent) event);
					} else {
						logger.warn("Unexpected event type received: " + event.toString());
					}

				} while (true);

			} catch (Exception e) {
				logger.error(e.getClass() + ": " + e.getMessage(), e);
			}

		}

	}

}
