package de.dfki.lasad.modules.analysis.deeploop.graphml;


/**
 * The vocabulary used to represented ARGUNAUT graphs using the GraphML format.
 * Needed by Deep Loop.
 * 
 * @author Oliver Scheuer
 * 
 */
public class GraphMLVocabulary {

	// node process
	public static final String NODE_CREATOR = "nodecreator";
	public static final String NODE_FIRST_MODIFICATOR = "nodefirstmodificator";
	public static final String NODE_LAST_MODIFICATOR = "nodelastmodificator";
	public static final String NODE_CREATIONDATE = "nodecreationdate";
	public static final String NODE_FIRST_MODIFICATIONDATE = "nodefirstmodificationdate";
	public static final String NODE_LAST_MODIFICATIONDATE = "nodemodificationdate"; // "nodelastmodificationdate";

	// node visual appearance
	public static final String NODE_SHAPE = "nodeshape";
	public static final String NODE_Y = "nodecoordy";
	public static final String NODE_X = "nodecoordx";
	public static final String NODE_HEIGHT = "nodeheight";
	public static final String NODE_WIDTH = "nodewidth";
	public static final String NODE_BORDERWIDTH = "nodeborderwidth";
	public static final String NODE_COLOR = "nodecolor";
	public static final String NODE_BORDERCOLOR = "nodebordercolor";
	public static final String NODE_TEXTCOLOR = "nodetextcolor";
	public static final String NODE_LAYER = "nodelayer";

	// node semantics and content
	public static final String NODE_TYPE = "nodetype";
	public static final String NODE_TITLE = "nodetitle";
	public static final String NODE_CONTENT = "nodecontent";

	// link process
	public static final String LINK_CREATOR = "edgecreator";
	public static final String LINK_CREATIONDATE = "edgecreationdate";
	public static final String LINK_LAST_MODIFICATIONDATE = "edgelastmodificationdate";

	// link visual appearance
	public static final String LINK_SHAPE = "edgeshape";
	public static final String LINK_COLOR = "edgecolor";

	// link semantics and content
	public static final String LINK_TYPE = "edgetype";
	public static final String LINK_SOURCE = "edgesource";
	public static final String LINK_TARGET = "edgetarget";

}
