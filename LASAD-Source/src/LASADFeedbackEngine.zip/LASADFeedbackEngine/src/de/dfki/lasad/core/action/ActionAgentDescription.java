package de.dfki.lasad.core.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.PluggableComponentConfiguration;
import de.dfki.lasad.core.PluggableComponentDescription;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class ActionAgentDescription extends PluggableComponentDescription {

	// tpyeID 2 ActionType
	private Map<String, ActionType> actionTypes = new HashMap<String, ActionType>();

	public ActionAgentDescription(String className) {
		super(className);
	}

	public ActionAgentDescription(String className,
			PluggableComponentConfiguration configuration) {
		super(className, configuration);
	}

	public IActionAgent createInstance() throws ComponentInitException {
		IActionAgent actionAgent = (IActionAgent) super.createInstance();
		return actionAgent;
	}

	public void addActionType(ActionType aType) {
		actionTypes.put(aType.getTypeID(), aType);
	}

	public List<ActionType> getAllActionTypes() {
		return new Vector<ActionType>(actionTypes.values());
	}

	public List<String> getAllActionTypeIds() {
		return new Vector<String>(actionTypes.keySet());
	}

	public ActionType getActionType(String actionTypeId) {
		return actionTypes.get(actionTypeId);
	}
}
