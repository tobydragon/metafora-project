package de.dfki.lasad.models.action;

import java.util.HashSet;
import java.util.Set;

import de.dfki.lasad.models.analysis.AnalysisResult;

/**
 * An {@link ActionSpec} consisting of {@link ActionComponent}s that resulted
 * from a tutorial strategy, i.e., from the (pedagogical-oriented)
 * interpretation of {@link AnalysisResult}s. ('Raw' uninterpreted
 * {@link AnalysisResult}s are packaged in a {@link AnalysisMirroringActionSpec}
 * ).
 * 
 * @author Oliver Scheuer
 * 
 */
public class ActionComponentSpec extends ActionSpec {

	private Set<ActionComponent> actionComponents;

	public ActionComponentSpec() {
		actionComponents = new HashSet<ActionComponent>();
	}

	public ActionComponentSpec(Set<ActionComponent> actionComponent) {
		this.actionComponents = actionComponent;
	}

	public void addActionComponent(ActionComponent actionComponent) {
		actionComponents.add(actionComponent);
	}

	public void setActionComponents(Set<ActionComponent> actionComponents) {
		this.actionComponents = actionComponents;
	}

	@Override
	public Set<ActionComponent> getActionComponents() {
		return actionComponents;
	}

	@Override
	public String toString() {
		return super.toString() + ", " + actionComponents + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((actionComponents == null) ? 0 : actionComponents.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ActionComponentSpec other = (ActionComponentSpec) obj;
		if (actionComponents == null) {
			if (other.actionComponents != null)
				return false;
		} else if (!actionComponents.equals(other.actionComponents))
			return false;
		return true;
	}

}
