package de.dfki.lasad.modules.application.argunaut;

import de.dfki.lasad.core.application.AppBuilder;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class DeepLoopServicesForLASADApp {

	AppBuilder appBuilder;

	public DeepLoopServicesForLASADApp() {
		DeepLoopServicesForLASADConfiguration configuration = new DeepLoopServicesForLASADConfiguration();
		appBuilder = new AppBuilder(configuration);
		appBuilder.doWireAndStart();
	}

	public static void main(String[] args) {
		new DeepLoopServicesForLASADApp();
	}

}
