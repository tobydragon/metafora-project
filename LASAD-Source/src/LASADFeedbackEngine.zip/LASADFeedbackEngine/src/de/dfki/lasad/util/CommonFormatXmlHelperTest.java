package de.dfki.lasad.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import junit.framework.TestCase;

public class CommonFormatXmlHelperTest extends TestCase {
	
Log logger = LogFactory.getLog(CommonFormatXmlHelperTest.class);
	
	String simpleXml;
	CommonFormatXmlHelper xmlHelper;
	
	public void setUp(){
		simpleXml=TestXmlData.createUserXmlString;
		xmlHelper = new CommonFormatXmlHelper(simpleXml);
	}
	
	public void testCommonFormatSimpleXml(){
		assertEquals("MetaforaUser1", xmlHelper.getObjectPropetyString("user", "USERNAME"));
	}
	
	public void testGetRootname(){
		assertEquals("action", xmlHelper.getRootName());
	}
	
	public void testGetTime(){
		
		
		logger.error("Expect [getTime] error next");
		assertEquals(0, new CommonFormatXmlHelper("xxx").getTime());
		assertEquals(TestXmlData.timeFromXml, xmlHelper.getTime());
	}

}
