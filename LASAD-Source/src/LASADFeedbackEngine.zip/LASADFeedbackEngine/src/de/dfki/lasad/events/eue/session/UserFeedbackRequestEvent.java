package de.dfki.lasad.events.eue.session;

import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackRequestSpec;

public class UserFeedbackRequestEvent extends UserActionEvent {

	private FeedbackRequestSpec feedbackRequestSpec;

	public UserFeedbackRequestEvent(FeedbackRequestSpec feedbackRequestSpec,
			SessionID sessionID, String srcCompId, EUEEventID eueEventID,
			UserID userID) {
		super(sessionID, srcCompId, eueEventID, userID);
		this.feedbackRequestSpec = feedbackRequestSpec;
	}

	public FeedbackRequestSpec getFeedbackRequestSpec() {
		return feedbackRequestSpec;
	}

	@Override
	public String toString() {
		return super.toString() + ", feedbackRequestSpec="
				+ feedbackRequestSpec;
	}
	
	
}
