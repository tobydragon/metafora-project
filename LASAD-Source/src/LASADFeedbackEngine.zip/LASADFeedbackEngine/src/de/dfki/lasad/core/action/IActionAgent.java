package de.dfki.lasad.core.action;

import de.dfki.lasad.core.PluggableComponent;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.core.worldmodel.IModelController;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.UserFeedbackRequestEvent;

/**
 * Decides how the system interacts with the user. Generates
 * {@link ActionSpecEvent}s that trigger system actions in the end user
 * environment (EUE). Might act directly in response to user actions in the EUE
 * (when notified via {@link EUEEvent)s, in response to explicit feedback
 * requests by the user ({@link UserFeedbackRequestEvent}s), or proactively
 * (e.g., internal timer). Complex interpretations of user actions are delegated
 * to {@link IAnalysisAgent}s via {@link AnalysisRequestEvent}s. Control logic
 * might be specified directly by this class or delegated to a local / remote
 * service component.
 * 
 * @author Oliver Scheuer
 * 
 */
public interface IActionAgent  extends PluggableComponent{

	/**
	 *  Establish runtime dependencies at system initialization time.
	 */
	public void doWire(IActionController actionController, IModelController worldModel);

	public void stopWorkingThread();
	
	// notification methods (execution time)
	public void onEUEEvent(EUESessionEvent eueEvent);

	public void onActionSpecEvent(ActionSpecEvent actionSpecEvent);

	public void onAnalysisResultEvent(AnalysisResultEvent analysisResultEvent);

	@Override
	public ActionAgentDescription getComponentDescription();
}
