package de.dfki.lasad.modules.dataservice.lasad;

import lasad.gwt.client.communication.objects.ActionPackage;


public interface ActionPackageListener {

	public static final String DIRECTION_IN = "IN";
	
	public void onActionPackage(ActionPackage actionPackage, Direction direction);
	
	public enum Direction {
	    IN, OUT 
	}
}
