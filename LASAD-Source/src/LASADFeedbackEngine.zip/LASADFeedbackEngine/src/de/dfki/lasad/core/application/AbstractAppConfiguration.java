package de.dfki.lasad.core.application;

import java.io.File;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.action.ActionController;
import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.core.analysis.AnalysisController;
import de.dfki.lasad.core.analysis.IAnalysisController;
import de.dfki.lasad.core.worldmodel.IModelController;
import de.dfki.lasad.core.worldmodel.JessModelControllerDescription;

public abstract class AbstractAppConfiguration implements IConfiguration {

	private Log logger = LogFactory.getLog(AbstractAppConfiguration.class);

	private IAnalysisController analysisController = new AnalysisController();
	private IActionController actionController = new ActionController();

	/**
	 * the default {@link IModelController}
	 */
	protected JessModelControllerDescription modelControllerDescr = new JessModelControllerDescription();

	protected File afHome;
	protected File confDir;

	public AbstractAppConfiguration() {
		String afHomeString = System.getProperty("lasad.af.home");
		if (afHomeString == null) {
			afHomeString = ".";
			logger
					.warn("System property 'lasad.af.home' not set. Using current directory: "
							+ (new File(afHomeString)).getAbsolutePath());

		}
		this.afHome = new File(afHomeString);
		this.confDir = new File(this.afHome, "conf");
		logger.info("LASAD A&F home directory: "
				+ this.afHome.getAbsolutePath());
		logger.info("LASAD A&F configuration home: "
				+ this.confDir.getAbsolutePath());

		ServiceRegistry.registerAppConfig(this);
	}

	@Override
	public File getAFHomeDir() {
		return afHome;
	}

	@Override
	public File getConfDir() {
		return confDir;
	}

	@Override
	public IAnalysisController getAnalysisController() {
		return analysisController;
	}

	@Override
	public IActionController getActionController() {
		return actionController;
	}

	@Override
	public JessModelControllerDescription getModelControllerDescription() {
		return modelControllerDescr;
	}

}
