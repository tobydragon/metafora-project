package de.dfki.lasad.core.analysis;

import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.models.analysis.AnalysisResult;

/**
 * Registration of {@link IAnalysisAgent}s (system initialization time) and
 * {@link Event}-distributing hub (execution time). Instances of this class
 * should ensure transactionality: {@link AnalysisResult}s, provided in
 * response to an {@link AnalysisRequestEvent}, should be complete and provided 
 * in one transaction (i.e., packaged in exactly on {@link AnalysisResultEvent). 
 * 
 * @author Oliver Scheuer
 * 
 */
public interface IAnalysisController {

	/**
	 *  Establish runtime dependencies at system initialization time.
	 */
	public void doWire(IActionController actionController);

	public void addAnalysisAgent(IAnalysisAgent analysisAgent);

	// notification methods (execution time)
	public void onEUEEvent(EUESessionEvent eueEvent);

	public void onAnalysisRequestEvent(AnalysisRequestEvent analysisRequestEvent);

	public void onAnalysisResultEvent(AnalysisResultEvent analysisResultEvent);
}
