package de.dfki.lasad.core;

/**
 * Describes a {@link PluggableComponent} in terms of important metadata, e.g.,
 * its {@link PluggableComponentConfiguration}. Serves also as a factory that
 * allows to initialize and configure a new instance of the referenced
 * {@link PluggableComponent} according to the provided
 * {@link PluggableComponentConfiguration}.
 * 
 * @author Oliver Scheuer
 */
public abstract class PluggableComponentDescription {

	protected String componentTypeID;
	protected String className;
	protected PluggableComponentConfiguration configuration = new EmptyComponentConfiguration();

	public PluggableComponentDescription(String className) {
		this.className = className;
	}

	public PluggableComponentDescription(String className, PluggableComponentConfiguration configuration) {
		this(className);
		this.configuration = configuration;
	}

	/**
	 * Initialize and configure a new instance of the references
	 * {@link PluggableComponent}.
	 */
	public PluggableComponent createInstance() throws ComponentInitException {
		PluggableComponent component = null;
		try {
			component = (PluggableComponent) Class.forName(className)
					.newInstance();
			component.configure(this);

		} catch (Exception e) {
			System.out.println("Error: " + ": " + e.getMessage());
			e.printStackTrace();
			throw new ComponentInitException(
					"Error while trying to instantiate " + className, e);
		}
		return component;
	}

	public void setComponentID(String componentID){
		this.componentTypeID = componentID;
	}
	
	public String getComponentID() {
		return componentTypeID;
	}

	public PluggableComponentConfiguration getConfiguration() {
		return configuration;
	}

}
