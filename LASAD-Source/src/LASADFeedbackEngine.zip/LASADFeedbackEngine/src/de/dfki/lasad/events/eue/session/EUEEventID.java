package de.dfki.lasad.events.eue.session;

import de.dfki.lasad.models.eue.EUEID;

public class EUEEventID extends EUEID {

	public EUEEventID(String id) {
		super(id);
	}
	
}
