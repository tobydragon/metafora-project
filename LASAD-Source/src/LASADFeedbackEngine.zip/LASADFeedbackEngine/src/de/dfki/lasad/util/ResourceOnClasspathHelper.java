package de.dfki.lasad.util;

import java.net.URL;

/**
 * 
 * @author Oliver Scheuer
 */
public class ResourceOnClasspathHelper {

	/**
	 * @param baseClass
	 *            the invoker class. The resource path will be resolved relative
	 *            to the location of the class.
	 * @param resourcePath
	 *            absolute or relative path of the resource. Absolute paths
	 *            start with a '/', relative paths are relative to the location
	 *            of the base class.
	 * @return an URL.
	 */
	public static URL getURLFromResourceOnClasspath(Class baseClass,
			String classpathPath) {
		URL url = baseClass.getResource(classpathPath);
		return url;
	}

	public static String getAbsoluteFilepathFromResourceOnClasspath(
			Class baseClass, String classpathPath) {
		URL url = getURLFromResourceOnClasspath(baseClass, classpathPath);
		// Blanks in URLs are encoded with the string "%20" (cf. RFC 1738), 
		//which cannot be handled by class java.io.File.
		return url.getPath().replace("%20", " ");
	}

}
