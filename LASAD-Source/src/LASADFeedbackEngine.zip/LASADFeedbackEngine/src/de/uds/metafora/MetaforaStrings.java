package de.uds.metafora;

public class MetaforaStrings {
	
	//user ids
	public static final String METAFORA_USER_ID_STRING = "METAFORA";
	public static final String EXPRESSER_USER_ID_STRING = "EXPRESSER";
	public static final String LASAD_AGENT_USER_ID_STRING = "LASAD_AGENT";

	
	//action types
	public static final String ACTION_TYPE_CREATE_USER_STRING = "CREATE_USER";
	public static final String ACTION_TYPE_CREATE_MAP_STRING = "CREATE_MAP";
	
	public static final String ACTION_TYPE_CREATE_ELEMENT_STRING = "CREATE_ELEMENT";
	public static final String ACTION_TYPE_UPDATE_ELEMENT_STRING = "UPDATE_ELEMENT";
	public static final String ACTION_TYPE_DISPLAY_STATE_URL_STRING = "DISPLAY_STATE_URL";
	
	//action classification types
	public static final String CLASSIFICATION_OTHER_STRING = "other";
		//associated action types
		public static final String CREATE_USER_STRING = "CREATE_USER";
			//associated properties
			public static final String PROPERTY_USERNAME_STRING = "USERNAME";
			public static final String PROPERTY_PASSWORD_STRING = "PASSWORD";
			public static final String PROPERTY_ROLE_STRING = "ROLE";
		
		public static final String CREATE_MAP_STRING = "CREATE_MAP";
			public static final String PROPERTY_MAPNAME_STRING = "MAPNAME";
			public static final String PROPERTY_TEMPLATE_STRING = "TEMPLATE";


	//object types
	public static final String OBJECT_TYPE_STRING = "ELEMENT_TYPE";
	public static final String OBJECT_TYPE_QUESTION_STRING = "Question";
	public static final String OBJECT_TYPE_IMAGE_STRING = "Image";
	public static final String OBJECT_TYPE_MICROWORLD_ISSUE_STRING = "Reference";
	public static final String OBJECT_TYPE_MY_MICROWORLD_STRING = "My Microworld";
//	public static final String OBJECT_TYPE_TOOL_REFERENCE_STRING = "ToolReference";
//	public static final String OBJECT_TYPE_METAFORA_TOOL_REFERENCE_STRING = "MetaforaToolReference";
	
	
	public static final String REFERABLE_OBJECT_STRING = "REFERABLE_OBJECT";
	
	//property types
	public static final String PROPERTY_TYPE_MAPNAME_STRING = "MAPNAME";
	public static final String PROPERTY_TYPE_TEMPLATE_STRING = "TEMPLATE";

	public static final String PROPERTY_TYPE_MAP_ID_STRING = "MAP_ID";
	public static final String PROPERTY_TYPE_TEXT_STRING = "TEXT";
	public static final String PROPERTY_TYPE_VIEW_URL_STRING = "IMAGE_URL";
	public static final String PROPERTY_TYPE_REFERENCE_URL_STRING = "REFERENCE_URL";
	public static final String PROPERTY_TYPE_USERNAME_STRING = "USERNAME";
	public static final String PROPERTY_TYPE_PASSWORD_STRING = "PASSWORD";
	public static final String PROPERTY_TYPE_ROLE_STRING = "ROLE";
	
	public static final String PROPERTY_TYPE_MODEL_VIEW_URL="MODEL_VIEW_URL";
	public static final String PROPERTY_TYPE_RULE_VIEW_URL="RULE_VIEW_URL";
	
	public static final String ACTION_TYPE_SUCCEEDED_UNKNOWN_STRING = "UNKOWN";
	
	public static final String USER_ROLE_ORIGINATOR_STRING = "controller";
	

}
