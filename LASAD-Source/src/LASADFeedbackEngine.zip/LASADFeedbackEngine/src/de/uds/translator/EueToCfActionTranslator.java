package de.uds.translator;

import de.dfki.lasad.events.eue.EUEEvent;
import de.uds.commonformat.CfAction;

public class EueToCfActionTranslator {
	
	public static CfAction translateEueEventToCfAction(EUEEvent event) {
		return null;
	}

}
