package de.uds.translator;

import de.dfki.lasad.events.eue.session.UserJoinSessionEvent;
import de.dfki.lasad.events.eue.session.UserLeaveSessionEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserCreateObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserDeleteObjectEvent;

public class EueStatementBuilder {
	
	
	public static String buildUserJoinSessionEventStatement(UserJoinSessionEvent event) {
		String translation = "";
		translation += event.getUserID().getIdAsString() + " has joined LASAD map " + event.getSessionID();
		return translation;
	}
	
	public static String buildUserLeaveSessionEventStatement(UserLeaveSessionEvent event) {
		String translation = "";
		translation += event.getUserID().getIdAsString() + " has left LASAD map " + event.getSessionID();
		return translation;
	}
	
	public static String buildUserCreateObjectEventStatement(UserCreateObjectEvent event) {
		String translation = "";
		String type = event.getEueObjectList().get(0).getType();
		String object = "node";
		if (type.equalsIgnoreCase("supports") || type.equalsIgnoreCase("opposes") || type.equalsIgnoreCase("Link")){
			object = "link";
		}
		translation += event.getUserID().getIdAsString() + " has created a " + object + " of type " + type;
		return translation;
	}
	
	public static String buildUserDeleteObjectEventStatement(UserDeleteObjectEvent event) {
		String translation = "";
		translation += event.getUserID().getIdAsString() + " has deleted a node of type " + event.getEueObjectList().get(0).getType();
		return translation;
	}

}
