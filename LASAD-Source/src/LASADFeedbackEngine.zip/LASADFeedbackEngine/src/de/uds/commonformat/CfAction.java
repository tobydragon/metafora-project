package de.uds.commonformat;

import java.util.ArrayList;
import java.util.List;

import de.uds.xml.XmlFragment;

public class CfAction {
	
	long time;
	
	CfActionType cfActionType;
	List<CfUser> cfUsers;
	List<CfObject> cfObjects;
	
	
	public CfAction(long time, CfActionType cfActionType) {
		super();
		this.time = time;
		this.cfActionType = cfActionType;
		this.cfUsers = new ArrayList<CfUser>();
		this.cfObjects = new ArrayList<CfObject>();
	}
	
	public CfAction(long time, CfActionType cfActionType, List<CfUser> cfUsers,
			List<CfObject> cfObjects) {
		super();
		this.time = time;
		this.cfActionType = cfActionType;
		this.cfUsers = cfUsers;
		this.cfObjects = cfObjects;
	}
	
	public void addUser(CfUser cfUser){
		cfUsers.add(cfUser);
	}

	public void addObject(CfObject cfObject){
		cfObjects.add(cfObject);
	}
	
	public void setTime(long time) {
		this.time = time;
	}

	public long getTime() {
		return time;
	}

	public CfActionType getCfActionType() {
		return cfActionType;
	}



	public List<CfUser> getCfUsers() {
		return cfUsers;
	}
	
	public CfUser getUserWithRole(String role){
		for (CfUser user : cfUsers){
			if (user.getrole().equalsIgnoreCase(role)){
				return user;
			}
		}
		return null;
	}



	public List<CfObject> getCfObjects() {
		return cfObjects;
	}



	public XmlFragment toXml(){
		XmlFragment xmlFragment= new XmlFragment(CommonFormatStrings.ACTION_STRING);
		xmlFragment.setAttribute(CommonFormatStrings.TIME_STRING, Long.toString(time));
		
		xmlFragment.addContent(cfActionType.toXml());
//		XmlFragment usersFragment = new XmlFragment(CommonFormatStrings.USERS_STRING);
		for (CfUser cfUser : cfUsers){
			xmlFragment.addContent(cfUser.toXml());
		}
//		xmlFragment.addContent(usersFragment);
		
//		XmlFragment objectsFragment = new XmlFragment(CommonFormatStrings.OBJECTS_STRING);
		for (CfObject cfObject : cfObjects){
			xmlFragment.addContent(cfObject.toXml());
		}
//		xmlFragment.addContent(objectsFragment);
		
		return xmlFragment;	
	}
	
	public static CfAction fromXml(XmlFragment xmlFragment){
		String timeStr = xmlFragment.getAttributeValue(CommonFormatStrings.TIME_STRING);
		long time = CommonFormatUtil.getTime(timeStr);
		
		CfActionType cfActionType = CfActionType.fromXml(xmlFragment.getChild(CommonFormatStrings.ACTION_TYPE_STRING));
		
//		XmlFragment userFragment = xmlFragment.getChild(CommonFormatStrings.USERS_STRING);
		List<CfUser> cfUsers = new ArrayList<CfUser>();
		for (XmlFragment cfUserElement : xmlFragment.getChildren(CommonFormatStrings.USER_STRING)){
			cfUsers.add(CfUser.fromXml(cfUserElement));
		}
		
//		XmlFragment objectFragment = xmlFragment.getChild(CommonFormatStrings.OBJECTS_STRING);
		List<CfObject> cfObjects = new ArrayList<CfObject>();
		for (XmlFragment cfObjectElement : xmlFragment.getChildren(CommonFormatStrings.OBJECT_STRING)){
			cfObjects.add(CfObject.fromXml(cfObjectElement));
		}
		return new CfAction (time, cfActionType, cfUsers, cfObjects);
	}
	
	public static CfAction getTestableInstance(){
		return CfAction.fromXml(XmlFragment.getFragmentFromFile("resources/xml/CfCreateUser.xml"));
	}

}
