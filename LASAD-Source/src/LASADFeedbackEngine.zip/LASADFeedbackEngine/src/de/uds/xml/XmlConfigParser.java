package de.uds.xml;

public class XmlConfigParser {
	
	XmlFragment configFragment;
	
 
	public XmlConfigParser(String filename){
		configFragment = XmlFragment.getFragmentFromFile(filename);
	}
	
	public String getConfigValue(String name){
		try {
			return configFragment.getChild(name).getRootElement().getText();
		}
		catch (Exception e){
			return null;
		}
	}

}
