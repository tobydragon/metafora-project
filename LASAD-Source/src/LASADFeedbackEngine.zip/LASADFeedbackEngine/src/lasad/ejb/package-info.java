@javax.xml.bind.annotation.XmlSchema(namespace = "http://ejb.lasad/")
package lasad.ejb;
