package lasad.gwt.client.communication.objects;

import java.io.Serializable;
import java.util.Vector;

/**
 * An ActionPackage holds a set of Actions. Each Actionpackage will get a
 * SESSION-ID as parameter.
 * 
 * @author Frank Loll
 * 
 */
public class ActionPackage implements Serializable {

	private static final long serialVersionUID = 7837877603551418909L;

	private Vector<Action> actions;
	private Vector<Parameter> parameters;

	public ActionPackage() {
		actions = new Vector<Action>();
		parameters = new Vector<Parameter>();
	}

	public ActionPackage addAction(Action a) {
		if (a != null) this.actions.add(a);
		return this;
	}

	/**
	 * Add parameter to action
	 * 
	 * @param name
	 * @param value
	 */
	public void addParameter(String name, String value) {
		parameters.add(new Parameter(name, value));
	}

	/**
	 * Add parameter vector to action
	 * 
	 * @param name
	 * @param values
	 */
	public void addParameterVector(String name, Vector<String> values) {
		for (String value : values) {
			parameters.add(new Parameter(name, value));
		}
	}

	/**
	 * Remove parameters by name
	 * 
	 * @param name
	 */
	public void removeParameter(String name) {
		for (Parameter param : parameters) {
			if (param.getName().equals(name)) {
				parameters.remove(param);
			}
		}
	}

	/**
	 * Remove parameter by name and value
	 * 
	 * @param name
	 * @param value
	 */
	public void removeParameter(String name, String value) {
		for (Parameter param : parameters) {
			if (param.getName().equals(name) && param.getValue().equals(value)) {
				parameters.remove(param);
			}
		}
	}

	/**
	 * Get the first value of a parameter
	 * 
	 * @param name
	 * @return value
	 */
	public String getParameter(String name) {
		for (Parameter param : parameters) {
			if (param.getName().equals(name)) {
				return param.getValue();
			}
		}
		return null;
	}

	/**
	 * Get the values of a parameter vector
	 * 
	 * @param name
	 * @return value vector
	 */
	public Vector<String> getParameterVector(String name) {
		Vector<String> returnVector = new Vector<String>();

		for (Parameter param : parameters) {
			if (param.getName().equals(name)) {
				returnVector.add(param.getValue());
			}
		}
		if (returnVector.size() == 0) return null;

		return returnVector;
	}

	public void replaceParameter(String valueName, String newValue) {
		for (Parameter param : parameters) {
			if (param.getName().equals(valueName)) {
				param.setValue(newValue);
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder action = new StringBuilder();
		action.append("ACTIONPACKAGE: ");
		for (Parameter param : parameters) {
			action.append("\n\tParameter: " + param.getName() + " : " + param.getValue());
		}

		for (Action a : actions) {
			action.append("\n" + a.toString());
		}

		return action.toString();
	}

	public Vector<Parameter> getParameters() {
		return parameters;
	}

	public void setParameters(Vector<Parameter> parameters) {
		this.parameters = parameters;
	}

	public Vector<Action> getActions() {
		return actions;
	}

	public void setActions(Vector<Action> actions) {
		this.actions = actions;
	}

	public static ActionPackage wrapAction(Action a) {
		ActionPackage p = new ActionPackage();
		p.addAction(a);
		
		return p;
	}
}