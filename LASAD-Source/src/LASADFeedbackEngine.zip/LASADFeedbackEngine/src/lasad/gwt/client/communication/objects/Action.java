package lasad.gwt.client.communication.objects;

import java.io.Serializable;
import java.util.Vector;

/**
 * Exchange object which contains a specific LASAD action Each action
 * has a command (cmd), a category and a set of parameters
 *         
 * @author Frank Loll        
 */
public class Action implements Serializable {

	private static final long serialVersionUID = 2636683835916757245L;

	private String cmd;
	private String category;
	private Vector<Parameter> parameters;

	/**
	 * Creates a general action
	 */
	public Action() {
		cmd = new String();
		category = new String();
		parameters = new Vector<Parameter>();
	}

	/**
	 * Creates a specified action
	 * 
	 * @param command
	 */
	public Action(String command) {
		cmd = command;
		category = new String();
		parameters = new Vector<Parameter>();
	}

	/**
	 * Creates a specified action defined by command and category
	 * 
	 * @param command
	 * @param category
	 */
	public Action(String command, String category) {
		this(command);
		this.category = category;
		parameters = new Vector<Parameter>();
	}

	/**
	 * Add parameter to action
	 * 
	 * @param name
	 * @param value
	 */
	public void addParameter(String name, String value) {
		parameters.add(new Parameter(name, value));
	}

	/**
	 * Add parameter vector to action
	 * 
	 * @param name
	 * @param values
	 */
	public void addParameterVector(String name, Vector<String> values) {
		for (String value : values) {
			parameters.add(new Parameter(name, value));
		}
	}

	/**
	 * Create a new Action which is equal to the old one, but does not has the
	 * parameter in it.
	 */
	public static Action removeParameter(Action a, String name) {

		Action b = new Action(a.getCmd(), a.getCategory());

		for (Parameter param : a.parameters) {
			if (!param.getName().equals(name)) {
				b.getParameters().add(param);
			}
		}

		return b;
	}

	/**
	 * Get the first value of a parameter
	 * 
	 * @param name
	 * @return value
	 */
	public String getParameter(String name) {
		for (Parameter param : parameters) {
			if (param.getName().equals(name)) {
				return param.getValue();
			}
		}
		return null;
	}

	/**
	 * Get the values of a parameter vector
	 * 
	 * @param name
	 * @return value vector
	 */
	public Vector<String> getParameterVector(String name) {
		Vector<String> returnVector = new Vector<String>();

		for (Parameter param : parameters) {
			if (param.getName().equals(name)) {
				returnVector.add(param.getValue());
			}
		}
		if (returnVector.size() == 0) return null;

		return returnVector;
	}

	public void replaceParameter(String valueName, String newValue) {
		for (Parameter param : parameters) {
			if (param.getName().equals(valueName)) {
				param.setValue(newValue);
			}
		}
	}
	
	/**
	 * Sorts vector so that Parameter USERNAME is at position 0
	 * @return
	 */
	public void sortParameterUsername(){
		// Check if USERNAME already on position 0
		if (!parameters.get(0).getName().equalsIgnoreCase("USERNAME")) {
			// not at position 0
			int index = -1;
			// search for USERNAME value, if found save index
			for (Parameter param : parameters) {
				if(param.getName().equals("USERNAME")){
					//DELETE USERNAME from values
					index = parameters.indexOf(param);
					break;
				}
			}
			
			// if USERNAME was found bring it to position 0
			if(index != -1){
				Parameter tmpUsername = parameters.get(index);
				parameters.remove(index);
				parameters.insertElementAt(tmpUsername, 0);
			}
		}
		
	}
	
	@Override
	public String toString() {
		StringBuilder action = new StringBuilder();
		action.append("ACTION: ");
		action.append("\n\tCategory: " + this.category);
		action.append("\n\tCommand: " + this.cmd);
		for (Parameter param : parameters) {
			action.append("\n\tParameter: " + param.getName() + " : " + param.getValue());
		}
		return action.toString();
	}

	/**
	 * Print out the complete action
	 */
	public void printAction() {
		printCommand();
		printCategory();
		printParameters();
	}

	/**
	 * Print out the action's category
	 */
	public void printCategory() {
		System.out.println("Category: " + category);
	}

	/**
	 * Print out the action's command
	 */
	public void printCommand() {
		System.out.println("Command: " + cmd);
	}

	/**
	 * Print out all parameters to console
	 */
	private void printParameters() {
		for (Parameter param : parameters) {
			System.out.println("Parameter: " + param.getName() + " : " + param.getValue());
		}
	}

	public String getCmd() {
		return cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Vector<Parameter> getParameters() {
		return parameters;
	}

	public void setParameters(Vector<Parameter> parameters) {
		this.parameters = parameters;
	}
}