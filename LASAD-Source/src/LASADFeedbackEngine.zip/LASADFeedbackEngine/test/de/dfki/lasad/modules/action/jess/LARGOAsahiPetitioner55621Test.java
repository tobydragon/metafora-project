package de.dfki.lasad.modules.action.jess;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import de.dfki.lasad.core.dataservice.largoxml.dataprovider.LargoDataProvider55621;
import de.dfki.lasad.modules.analysisactioncycle.TestFramework;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class LARGOAsahiPetitioner55621Test extends TestFramework {

	private Log logger = LogFactory.getLog(LARGOAsahiPetitioner55621Test.class);

	private String FEEDBACKAGENT_CONF_FILENAME = "LARGO_FEEDBACK_TEST.conf.xml";
	private JessFeedbackAgentConfiguration conf = new JessFeedbackAgentConfiguration(
			FEEDBACKAGENT_CONF_FILENAME);

	private LargoDataProvider55621 dataProvider = new LargoDataProvider55621();

	/**
	 * Test GraphGrammar
	 */
	@Test
	public void testGraphGrammar() {
		try {
			LARGOGraphGrammarTestParameters params = new LARGOGraphGrammarTestParameters(
					dataProvider, conf);

			params.addFeedbackRequest("best-5");

			// "no_elements" - no results
			// "no_relations" - no results
			// "test_without_condition" - no results
			// "linked_test_without_text" - no results

			params.addExpectedResult("unlinked_test", params
					.constructEntity(new String[] { "43" }));
			params.addExpectedResult("unlinked_test", params
					.constructEntity(new String[] { "47" }));

			// "distinguish_without_text" - no results

			params.addExpectedResult("missed_test", params
					.constructEntity(new String[] {}));

			params.addExpectedResult("missed_hypo", params
					.constructEntity(new String[] {}));

			// "test_isolated_from_hypos" - no results
			// "test_isolated_hypo" - no results
			// "test_facts_without_hypos" - no results
			// "test_relation_not_modify" - no results
			// "hypo_facts_relation_general" - no results
			// "hypo_relation_general" - no results
			// "test_modified_without_reason" - no results

			params.addExpectedResult("ambiguous_hypo_relation", params
					.constructEntity(new String[] { "35", "53", "31" }));

			params.addExpectedResult("no_response_to_hypo", params
					.constructEntity(new String[] { "55", "38", "23" }));

			// "test_facts_relation_specific" - no results
			// "test_hypo_relation_modified" - no results

			params.addExpectedResult("hypo_facts_relation_causes", params
					.constructEntity(new String[] { "65", "27", "35" }));
			params.addExpectedResult("hypo_facts_relation_causes", params
					.constructEntity(new String[] { "35", "59", "23" }));

			// "facts_relations" - no results
			// "hypo_multiple_leadsto" - no results
			// "cyclic_references" - no results
			// "test_as_hypo" - no results

			params.addExpectedResult("hypo_as_test", params
					.constructEntity(new String[] { "38" }));

			// "irrelevant_as_test" - no results

			params.addExpectedResult("hypo_hypo_relation_no_response", params
					.constructEntity(new String[] { "57", "27", "23" }));
			params.addExpectedResult("hypo_hypo_relation_no_response", params
					.constructEntity(new String[] { "57", "27", "23" }));

			params.addExpectedResult("unrelated_tests", params
					.constructEntity(new String[] { "43", "47" }));
			params.addExpectedResult("unrelated_tests", params
					.constructEntity(new String[] { "43", "38" }));

			params.addExpectedResult("discuss_hypo_multiple_tests", params
					.constructEntity(new String[] { "55", "35", "59", "38",
							"23" }));

			// "discuss_hypo_one_tests" - no results
			// "multiple_impact_of_hypo" - no results

			setTestParameters(params);
			runTestAndCheckResults();
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}
}
