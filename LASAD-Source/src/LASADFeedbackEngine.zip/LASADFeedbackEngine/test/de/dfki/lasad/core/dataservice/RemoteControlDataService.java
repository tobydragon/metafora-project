package de.dfki.lasad.core.dataservice;

import java.util.List;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.dataservice.AbstractDataService;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.action.ActionSpecEventListener;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.EUEEventListener;
import de.dfki.lasad.events.eue.EUEEventPublisher;
import de.dfki.lasad.events.eue.session.AgentJoinSessionConfirmEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;

/**
 * Data Service implementation that can be externally controlled via
 * {@link EUESessionEvent}s and that writes results to a Logger instance
 * 
 * @author Oliver Scheuer
 * 
 */
public class RemoteControlDataService extends AbstractDataService implements
		EUEEventListener, EUEEventPublisher {

	Log logger = LogFactory.getLog(RemoteControlDataService.class);

	List<EUEEventListener> eueEventListenerList = new Vector<EUEEventListener>();
	List<ActionSpecEventListener> actionSpecEventListenerList = new Vector<ActionSpecEventListener>();

	@Override
	public void prepareService() {
		// nothing to do
	}

	@Override
	public void startService() {
		// nothing to do
	}

	@Override
	public void onEUEEvent(EUEEvent eueEvent) {
		if (eueEvent instanceof Event) {
			addEventToQueue((Event) eueEvent);
		} else {
			logger.warn("EUEEvent " + eueEvent
					+ " does not extend Event. Ignore.");
		}
	}

	@Override
	public void onActionSpecEvent(ActionSpecEvent actionSpecEvent) {
		addEventToQueue(actionSpecEvent);
	}

	@Override
	protected void processEUEEvent(EUEEvent eueEvent) {
		super.processEUEEvent(eueEvent);
		for (EUEEventListener listener : eueEventListenerList) {
			listener.onEUEEvent(eueEvent);
		}
	}

	@Override
	protected void processActionSpecEvent(ActionSpecEvent actionSpecEvent) {
		logger.info("ActionSpec received: " + actionSpecEvent.toString());
		for (ActionSpecEventListener listener : actionSpecEventListenerList) {
			listener.onActionSpecEvent(actionSpecEvent);
		}
	}

	@Override
	protected void processAgentJoinSessionConfirmEvent(
			AgentJoinSessionConfirmEvent event) {
		// ignore
	}

	public void subscribeActionSpecEventListener(
			ActionSpecEventListener listener) {
		actionSpecEventListenerList.add(listener);
	}

	@Override
	public void subscribe(EUEEventListener listener) {
		eueEventListenerList.add(listener);
	}

}
