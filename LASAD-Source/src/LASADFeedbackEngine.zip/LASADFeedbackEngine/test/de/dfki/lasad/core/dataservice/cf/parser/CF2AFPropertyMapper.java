package de.dfki.lasad.core.dataservice.cf.parser;

import java.util.HashMap;
import java.util.Map;

import de.dfki.lasad.models.eue.objects.BasicPropertyFactory;
import de.dfki.lasad.models.eue.objects.NonSupportedPropertyRequestedException;
import de.dfki.lasad.models.eue.objects.SimpleProperty;

public class CF2AFPropertyMapper {

	private Map<String, String> mappings = new HashMap<String, String>();

	public CF2AFPropertyMapper() {
		mappings.put("title", BasicPropertyFactory.TITLE);
		mappings.put("note", BasicPropertyFactory.TEXT);
		mappings.put("x", BasicPropertyFactory.X);
		mappings.put("y", BasicPropertyFactory.Y);
		mappings.put("height", BasicPropertyFactory.HEIGHT);
		mappings.put("width", BasicPropertyFactory.WIDTH);

		mappings.put(BasicPropertyFactory.SHAPE, BasicPropertyFactory.SHAPE);
		mappings.put(BasicPropertyFactory.ONTOLOGY_ELEMENT,
				BasicPropertyFactory.ONTOLOGY_ELEMENT);
	}

	public boolean propTypeSupported(String prop) {
		return mappings.containsKey(prop);
	}

	public SimpleProperty createSimpleProp(String oldName, String value)
			throws NonSupportedPropertyRequestedException {
		String newName = mappings.get(oldName);
		if (newName == null) {
			throw new NonSupportedPropertyRequestedException(
					CF2AFPropertyMapper.class.getName(), oldName);
		}
		SimpleProperty prop = BasicPropertyFactory
				.newSimpleProp(newName, value);
		return prop;
	}
}
