package de.dfki.lasad.core.dataservice.cf.dataprovider;

import org.graphdrawing.graphml.xmlns.x1.GraphmlDocument;

import de.dfki.lasad.core.dataservice.cf.data.CFInputSourceProvider;
import de.dfki.lasad.models.eue.SessionID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class MockDataProvider extends CFDataProvider {

	SessionID sessionID = new SessionID(CFInputSourceProvider.mockDataFile);
	
	public MockDataProvider() {
		super();
		parser.parse(CFInputSourceProvider.getMockDataSource(), sessionID);
	}

	@Override
	public GraphmlDocument getGraphML() {
		return super.getGraphMLFromCF(CFInputSourceProvider
				.getAbsoluteFilePathMockData());
	}
	
	@Override
	public SessionID getSessionID() {
		return sessionID;
	}


}
