package de.dfki.lasad.modules.analysis.eventcounter;

import org.junit.Test;

import de.dfki.lasad.core.dataservice.cf.dataprovider.MockDataProvider;
import de.dfki.lasad.modules.analysisactioncycle.TestFramework;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class MockDataTests extends TestFramework {

	public MockDataTests() {
		super();
	}

	@Test
	public void testCountAll() {
		EventCounterTestParameters params = new EventCounterTestParameters(
				new MockDataProvider(),
				EUEEventCounterDescription.COUNT_OBJECT_ACTIONS, 8);
		setTestParameters(params);
		runTestAndCheckResults();
	}
}
