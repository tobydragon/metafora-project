package de.dfki.lasad.core.dataservice.lasad;

import java.util.Map;

public class LASADActionDescription {
	private String categoryValue;
	private String commandValue;
	private Map<String, String> actionParams;
	
	
	
	public LASADActionDescription(String categoryValue, String commandValue,
			Map<String, String> actionParams) {
		super();
		this.categoryValue = categoryValue;
		this.commandValue = commandValue;
		this.actionParams = actionParams;
	}
	public String getCategoryValue() {
		return categoryValue;
	}
	public void setCategoryValue(String categoryValue) {
		this.categoryValue = categoryValue;
	}
	public String getCommandValue() {
		return commandValue;
	}
	public void setCommandValue(String commandValue) {
		this.commandValue = commandValue;
	}
	public Map<String, String> getActionParams() {
		return actionParams;
	}
	public void setActionParams(Map<String, String> actionParams) {
		this.actionParams = actionParams;
	}
	
	
}
