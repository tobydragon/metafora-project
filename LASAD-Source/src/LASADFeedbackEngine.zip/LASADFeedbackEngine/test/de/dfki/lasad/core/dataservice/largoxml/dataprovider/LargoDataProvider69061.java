package de.dfki.lasad.core.dataservice.largoxml.dataprovider;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.dataservice.largoxml.data.LargoXMLSourceProvider;

public class LargoDataProvider69061 extends LargoDataProviderAsahiPetitioner {

	private Log logger = LogFactory.getLog(LargoDataProvider69061.class);

	public LargoDataProvider69061() {
		super();
		initDataService(LargoXMLSourceProvider.largotestfilePath,
				LargoXMLSourceProvider.largoXML1);
	}

	public static void main(String[] args) {
		LargoDataProvider largoDataProvider = new LargoDataProvider69061();
		largoDataProvider.printDataToLogger();
	}
}
