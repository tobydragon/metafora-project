package de.dfki.lasad.modules.analysis;

import java.util.Collection;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import junit.framework.TestCase;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.graphdrawing.graphml.xmlns.x1.GraphmlDocument;
import org.junit.Test;

import de.dfki.lasad.core.dataservice.cf.dataprovider.CFDataProvider;
import de.dfki.lasad.core.dataservice.cf.dataprovider.HUJIDataProvider;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.session.EUEEventID;
import de.dfki.lasad.events.eue.session.objectaction.UserCreateObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.objects.BasicPropertyFactory;
import de.dfki.lasad.models.eue.objects.EUEObject;
import de.dfki.lasad.models.eue.objects.EUEObjectID;
import de.dfki.lasad.models.eue.objects.EmptyID;
import de.dfki.lasad.models.eue.objects.ListProperty;
import de.dfki.lasad.models.eue.objects.ObjectProperty;
import de.dfki.lasad.models.eue.objects.SimpleProperty;
import de.dfki.lasad.models.eue.objects.graph.Link;
import de.dfki.lasad.models.eue.objects.graph.Node;
import de.dfki.lasad.modules.analysis.deeploop.graphml.GraphMLReader;
import de.dfki.lasad.modules.analysis.deeploop.graphml.GraphMLVocabulary;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class FlatGraphModelerTest extends TestCase {

	Log logger = LogFactory.getLog(FlatGraphModelerTest.class);

	CFDataProvider dataProvider;

	String KEEP = "KEEP";
	String OLD = "OLD";
	String NEW = "NEW";

	public FlatGraphModelerTest() {
		dataProvider = new HUJIDataProvider();
		dataProvider.startPublishingEUESessionEvents();
	}

	public static void main(String[] args) {
		FlatGraphModelerTest test = new FlatGraphModelerTest();
		test.testEventSequenceProcessAggregation();
	}

	/**
	 * Checks for each input node whether (a) exactly one output node exists
	 * that (b) has the correct type and (b) contains a property with the
	 * correct name with (c) and value.
	 */
	@Test
	public void testSimplePropertyMappings() {
		logger.info("Test node type and property mappings");
		FlatGraphModeler modeler = new FlatGraphModeler(createConfiguration());
		List<EUEObject> inNodeList = createTestNodes();
		UserCreateObjectEvent event = createTestEvent(inNodeList);

		modeler.executeEvent(event);
		modeler.updateFlatRepresentations();
		Collection<Node> outNodeList = modeler.getNodes();

		for (EUEObject inNode : inNodeList) {
			logger.info("Input node: " + inNode);
			int numCorrespondingNodes = 0;
			for (Node outNode : outNodeList) {
				if (inNode.equals(outNode)) {
					logger.info("Corresponding output node found: " + outNode);
					logger.info("Check for consistency with input node ...");
					// mapping target has been found
					checkWhetherPotentiallyCorrectMappingExists((Node) inNode,
							outNode);
					logger.info(" ... OK");
					++numCorrespondingNodes;
				}
			}
			// per test data design (list that only contains root nodes):
			// exactly 1 output node per input node
			String message = "Number of Output Nodes that correspond to an Input Node != 1.";
			assertTrue(message, numCorrespondingNodes == 1);
			numCorrespondingNodes = 0;
		}
		logger.info("------------------");
	}

	@Test
	public void testHierarchyMappings() {
		logger.info("Test hierarchical object mappings");
		SimplePropertyMappingsConfiguration conf = createConfiguration();
		FlatGraphModeler modeler = new FlatGraphModeler(conf);

		conf.addPropType(KEEP, KEEP, true);
		conf.addPropType(KEEP, NEW, true);
		conf.addPropType(NEW, KEEP, true);
		conf.addPropType(NEW, NEW, true);

		List<EUEObject> inNodeList = createTestNodes();
		interlinkNodesHierarchically(inNodeList);
		UserCreateObjectEvent event = createTestEvent(inNodeList);

		modeler.executeEvent(event);
		modeler.updateFlatRepresentations();
		Collection<Node> outNodeList = modeler.getNodes();

		// exactly 1 output node overall
		String message = "Total number of Output Nodes != 1.";
		assertTrue(message, outNodeList.size() == 1);
		Node outNode = outNodeList.iterator().next();
		logger.info("Output node: " + outNode);
		for (EUEObject inNode : inNodeList) {
			logger.info("Check input node: " + inNode + " ...");
			checkWhetherPotentiallyCorrectMappingExists((Node) inNode, outNode);
			logger.info(" ... OK");
		}
		logger.info("-----------------------------");
	}

	@Test
	public void testEventSequenceStateAggregation() {
		logger.info("Test Event sequence aggregration ... state properties");

		// no mappings
		SimplePropertyMappingsConfiguration conf = new SimplePropertyMappingsConfiguration();

		FlatGraphModeler modeler = new FlatGraphModeler(conf);

		GraphmlDocument graphML = dataProvider.getGraphML();
		GraphMLReader graphMLReader = new GraphMLReader(graphML);

		for (EUEEvent event : dataProvider) {
			if (event instanceof UserObjectActionEvent) {
				modeler.executeEvent((UserObjectActionEvent) event);
			}
		}
		modeler.updateFlatRepresentations();

		checkStatePropsForNode(modeler, graphMLReader);
		checkStatePropsForLink(modeler, graphMLReader);
	}

	@Test
	public void testEventSequenceProcessAggregation() {
		logger.info("Test Event sequence aggregration ... process properties");

		// no mappings
		SimplePropertyMappingsConfiguration conf = new SimplePropertyMappingsConfiguration();

		FlatGraphModeler modeler = new FlatGraphModeler(conf);

		GraphmlDocument graphML = dataProvider.getGraphML();
		GraphMLReader graphMLReader = new GraphMLReader(graphML);

		for (EUEEvent event : dataProvider) {
			if (event instanceof UserObjectActionEvent) {
				modeler.executeEvent((UserObjectActionEvent) event);
			}
		}
		modeler.updateFlatRepresentations();

		checkProcessPropsForNode(modeler, graphMLReader);
		checkProcessPropsForLink(modeler, graphMLReader);
	}

	private void checkProcessPropsForNode(FlatGraphModeler modeler,
			GraphMLReader graphMLReader) {
		Collection<Node> actualNodes = modeler.getNodes();
		List<String> criterionNodeIDList = graphMLReader.getNodeIDs();

		logger
				.info("Checking number of nodes in produced model against graphml ...");
		String message = "Number of nodes differs from number of nodes in control set.";
		assertTrue(message, actualNodes.size() == criterionNodeIDList.size());
		logger.info("... Ok");

		for (String criterionNodeID : criterionNodeIDList) {
			Node actualNode = modeler.getNode(new EUEObjectID(criterionNodeID));

			logger.info("Searching for node '" + criterionNodeID
					+ "' in produced model ...");
			message = "";
			assertNotNull(message, actualNode);
			logger.info("... Ok");

			logger.info("Comparing creator ...");
			String creatorCriterion = graphMLReader.getNodeProperty(
					criterionNodeID, GraphMLVocabulary.NODE_CREATOR);
			ObjectProperty creatorActual = actualNode
					.getPropValue(BasicPropertyFactory.CREATOR);
			checkProperty(BasicPropertyFactory.CREATOR, creatorCriterion,
					creatorActual);
			logger.info("... Ok");

			logger.info("Comparing first modifier ...");
			String firstModifierCriterion = graphMLReader.getNodeProperty(
					criterionNodeID, GraphMLVocabulary.NODE_FIRST_MODIFICATOR);
			ObjectProperty firstModifierActual = actualNode
					.getPropValue(BasicPropertyFactory.FIRST_MODIFIER);
			checkProperty(BasicPropertyFactory.FIRST_MODIFIER,
					firstModifierCriterion, firstModifierActual);
			logger.info("... Ok");

			logger.info("Comparing last modifier ...");
			String lastModifierCriterion = graphMLReader.getNodeProperty(
					criterionNodeID, GraphMLVocabulary.NODE_LAST_MODIFICATOR);
			ObjectProperty lastModifierActual = actualNode
					.getPropValue(BasicPropertyFactory.LAST_MODIFIER);
			checkProperty(BasicPropertyFactory.LAST_MODIFIER,
					lastModifierCriterion, lastModifierActual);
			logger.info("... Ok");

			logger.info("Comparing creation ts ...");
			String creationTsCriterion = graphMLReader.getNodeProperty(
					criterionNodeID, GraphMLVocabulary.NODE_CREATIONDATE);
			ObjectProperty creationTsActual = actualNode
					.getPropValue(BasicPropertyFactory.CREATION_TS);
			checkProperty(BasicPropertyFactory.CREATION_TS,
					creationTsCriterion, creationTsActual);
			logger.info("... Ok");

			logger.info("Comparing first modification ts ...");
			String firstModificationTsCriterion = graphMLReader
					.getNodeProperty(criterionNodeID,
							GraphMLVocabulary.NODE_FIRST_MODIFICATIONDATE);
			ObjectProperty firstModificationActual = actualNode
					.getPropValue(BasicPropertyFactory.FIRST_MODIFICATION_TS);
			checkProperty(BasicPropertyFactory.FIRST_MODIFICATION_TS,
					firstModificationTsCriterion, firstModificationActual);
			logger.info("... Ok");

			logger.info("Comparing last modification ts ...");
			String lastModificationTsCriterion = graphMLReader.getNodeProperty(
					criterionNodeID,
					GraphMLVocabulary.NODE_LAST_MODIFICATIONDATE);
			ObjectProperty lastModificationActual = actualNode
					.getPropValue(BasicPropertyFactory.LAST_MODIFICATION_TS);
			checkProperty(BasicPropertyFactory.LAST_MODIFICATION_TS,
					lastModificationTsCriterion, lastModificationActual);
			logger.info("... Ok");
		}
	}

	
	private void checkStatePropsForNode(FlatGraphModeler modeler,
			GraphMLReader graphMLReader) {
		Collection<Node> actualNodes = modeler.getNodes();
		List<String> criterionNodeIDList = graphMLReader.getNodeIDs();

		logger
				.info("Checking number of nodes in produced model against graphml ...");
		String message = "Number of nodes differs from number of nodes in control set.";
		assertTrue(message, actualNodes.size() == criterionNodeIDList.size());
		logger.info("... Ok");

		for (String criterionNodeID : criterionNodeIDList) {
			Node actualNode = modeler.getNode(new EUEObjectID(criterionNodeID));

			logger.info("Searching for node '" + criterionNodeID
					+ "' in produced model ...");
			message = "";
			assertNotNull(message, actualNode);
			logger.info("... Ok");

			logger.info("Comparing types ...");
			String typeCriterion = graphMLReader.getNodeProperty(
					criterionNodeID, GraphMLVocabulary.NODE_TYPE);
			String typeActual = actualNode.getType();
			assertEquals(typeCriterion, typeActual);
			logger.info("... Ok");

			logger.info("Comparing titles ...");
			String titleCriterion = graphMLReader.getNodeProperty(
					criterionNodeID, GraphMLVocabulary.NODE_TITLE);
			ObjectProperty titleActual = actualNode
					.getPropValue(BasicPropertyFactory.TITLE);
			checkProperty(BasicPropertyFactory.TITLE, titleCriterion,
					titleActual);
			logger.info("... Ok");

			logger.info("Comparing content/text ...");
			String contentCriterion = graphMLReader.getNodeProperty(
					criterionNodeID, GraphMLVocabulary.NODE_CONTENT);
			ObjectProperty contentActual = actualNode
					.getPropValue(BasicPropertyFactory.TEXT);
			checkProperty(BasicPropertyFactory.TEXT, contentCriterion,
					contentActual);
			logger.info("... Ok");

			logger.info("Comparing shapes ...");
			String shapeCriterion = graphMLReader.getNodeProperty(
					criterionNodeID, GraphMLVocabulary.NODE_SHAPE);
			ObjectProperty shapeActual = actualNode
					.getPropValue(BasicPropertyFactory.SHAPE);
			checkProperty(BasicPropertyFactory.SHAPE, shapeCriterion,
					shapeActual);
			logger.info("... Ok");

			logger.info("Comparing height ...");
			String heightCriterion = graphMLReader.getNodeProperty(
					criterionNodeID, GraphMLVocabulary.NODE_HEIGHT);
			ObjectProperty heightActual = actualNode
					.getPropValue(BasicPropertyFactory.HEIGHT);
			checkProperty(BasicPropertyFactory.HEIGHT, heightCriterion,
					heightActual);
			logger.info("... Ok");

			logger.info("Comparing width ...");
			String widthCriterion = graphMLReader.getNodeProperty(
					criterionNodeID, GraphMLVocabulary.NODE_WIDTH);
			ObjectProperty widthActual = actualNode
					.getPropValue(BasicPropertyFactory.WIDTH);
			checkProperty(BasicPropertyFactory.WIDTH, widthCriterion,
					widthActual);
			logger.info("... Ok");
		}
	}

	private void checkProcessPropsForLink(FlatGraphModeler modeler,
			GraphMLReader graphMLReader) {
		Collection<Link> actualLinks = modeler.getLinks();
		List<String> criterionLinkIDList = graphMLReader.getLinkIDs();

		logger
				.info("Checking number of links in produced model against graphml ...");
		String message = "Number of links differs from number of links in control set.";
		assertTrue(message, actualLinks.size() == criterionLinkIDList.size());
		logger.info("... Ok");

		for (String criterionLinkID : criterionLinkIDList) {
			Link actualLink = modeler.getLink(new EUEObjectID(criterionLinkID));

			logger.info("Searching for link '" + criterionLinkID
					+ "' in produced model ...");
			message = "";
			assertNotNull(message, actualLink);
			logger.info("... Ok");

			logger.info("Comparing creator ...");
			String creatorCriterion = graphMLReader.getLinkProperty(
					criterionLinkID, GraphMLVocabulary.LINK_CREATOR);
			ObjectProperty creatorActual = actualLink
					.getPropValue(BasicPropertyFactory.CREATOR);
			checkProperty(BasicPropertyFactory.CREATOR, creatorCriterion,
					creatorActual);
			logger.info("... Ok");

			logger.info("Comparing creation ts ...");
			String creationTsCriterion = graphMLReader.getLinkProperty(
					criterionLinkID, GraphMLVocabulary.LINK_CREATIONDATE);
			ObjectProperty creationTsActual = actualLink
					.getPropValue(BasicPropertyFactory.CREATION_TS);
			checkProperty(BasicPropertyFactory.CREATION_TS,
					creationTsCriterion, creationTsActual);
			logger.info("... Ok");
		}
	}

	private void checkStatePropsForLink(FlatGraphModeler modeler,
			GraphMLReader graphMLReader) {
		Collection<Link> actualLinks = modeler.getLinks();
		List<String> criterionLinkIDList = graphMLReader.getLinkIDs();

		logger
				.info("Checking number of links in produced model against graphml ...");
		String message = "Number of links differs from number of links in control set.";
		assertTrue(message, actualLinks.size() == criterionLinkIDList.size());
		logger.info("... Ok");

		for (String criterionLinkID : criterionLinkIDList) {
			Link actualLink = modeler.getLink(new EUEObjectID(criterionLinkID));

			logger.info("Searching for link '" + criterionLinkID
					+ "' in produced model ...");
			message = "";
			assertNotNull(message, actualLink);
			logger.info("... Ok");

			logger.info("Comparing types ...");
			String typeCriterion = graphMLReader.getLinkProperty(
					criterionLinkID, GraphMLVocabulary.LINK_TYPE);
			String typeActual = actualLink.getType();
			assertEquals(typeCriterion, typeActual);
			logger.info("... Ok");

			logger.info("Comparing sources ...");
			String sourceCriterion = graphMLReader.getLinkProperty(
					criterionLinkID, GraphMLVocabulary.LINK_SOURCE);
			List<EUEObjectID> actualSources = actualLink.getSources();
			assertTrue(actualSources.size() == 1);
			EUEObjectID actualSourceID = actualSources.get(0);
			assertEquals(new EUEObjectID(sourceCriterion), actualSourceID);
			logger.info("... Ok");

			logger.info("Comparing targets ...");
			String targetCriterion = graphMLReader.getLinkProperty(
					criterionLinkID, GraphMLVocabulary.LINK_TARGET);
			List<EUEObjectID> actualTargets = actualLink.getTargets();
			assertTrue(actualTargets.size() == 1);
			EUEObjectID actualTargetID = actualTargets.get(0);
			assertEquals(new EUEObjectID(targetCriterion), actualTargetID);
			logger.info("... Ok");

			logger.info("Comparing shapes ...");
			String shapeCriterion = graphMLReader.getLinkProperty(
					criterionLinkID, GraphMLVocabulary.LINK_SHAPE);
			ObjectProperty shapeActual = actualLink
					.getPropValue(BasicPropertyFactory.SHAPE);
			checkProperty(BasicPropertyFactory.SHAPE, shapeCriterion,
					shapeActual);
			logger.info("... Ok");

		}
	}

	private void checkProperty(String propName, String criterionValue,
			ObjectProperty actualProp) {
		if (actualProp == null) {
			assertNull(criterionValue);
			logger
					.info("Property '"
							+ propName
							+ "' exists neither in actual model nor in criterion model (graphml).");
		} else {
			String actualValue = actualProp.getValueAsString();
			assertEquals(criterionValue, actualValue);

		}
	}

	// arrange objects in a binary tree
	private void interlinkNodesHierarchically(List<EUEObject> eueObjects) {

		int i = 1;
		int max = eueObjects.size();
		for (; i < max; ++i) {
			if (eueObjects.get(i) instanceof Node) {
				Node node = (Node) eueObjects.get(i);
				int parentIndex = (int) (Math.floor((i - 1) / 2));
				EUEObject parent = eueObjects.get(parentIndex);
				node.setParentID(parent.getID());
			}
		}
	}

	// "OLD" will always be mapped to "NEW", "KEEP" will be kept
	private SimplePropertyMappingsConfiguration createConfiguration() {
		SimplePropertyMappingsConfiguration conf = new SimplePropertyMappingsConfiguration();
		conf.addElemTypeMapping(OLD, NEW);

		conf.addPropMapping(OLD, OLD, NEW);
		conf.addPropMapping(KEEP, OLD, NEW);

		conf.addValMapping(OLD, OLD, OLD, NEW);
		conf.addValMapping(OLD, KEEP, OLD, NEW);
		conf.addValMapping(KEEP, OLD, OLD, NEW);
		conf.addValMapping(KEEP, KEEP, OLD, NEW);

		return conf;
	}

	private List<EUEObject> createTestNodes() {

		ObjectProperty prop_OLD_OLD = new SimpleProperty(OLD, OLD);
		ObjectProperty prop_KEEP_OLD = new SimpleProperty(KEEP, OLD);
		ObjectProperty prop_OLD_KEEP = new SimpleProperty(OLD, KEEP);
		ObjectProperty prop_KEEP_KEEP = new SimpleProperty(KEEP, KEEP);

		// type: "OLD", props: OLD->OLD, KEEP->OLD
		Node n1 = new Node();
		n1.setID(new EUEObjectID("n1"));
		n1.setParentID(new EmptyID());
		n1.setType(OLD);
		n1.addProperty(prop_OLD_OLD);
		n1.addProperty(prop_KEEP_OLD);

		// type: "OLD", props: OLD->KEEP, KEEP->KEEP
		Node n2 = new Node();
		n2.setID(new EUEObjectID("n2"));
		n2.setParentID(new EmptyID());
		n2.setType(OLD);
		n2.addProperty(prop_OLD_KEEP);
		n2.addProperty(prop_KEEP_KEEP);

		// type: "KEEP", props: OLD->OLD, KEEP->OLD
		Node n3 = new Node();
		n3.setID(new EUEObjectID("n3"));
		n3.setParentID(new EmptyID());
		n3.setType(KEEP);
		n3.addProperty(prop_OLD_OLD);
		n3.addProperty(prop_KEEP_OLD);

		// type: "KEEP", props: OLD->OLD, KEEP->OLD
		Node n4 = new Node();
		n4.setID(new EUEObjectID("n4"));
		n4.setParentID(new EmptyID());
		n4.setType(KEEP);
		n4.addProperty(prop_OLD_KEEP);
		n4.addProperty(prop_KEEP_KEEP);

		List<EUEObject> testNodeList = new Vector<EUEObject>();
		testNodeList.add(n1);
		testNodeList.add(n2);
		testNodeList.add(n3);
		testNodeList.add(n4);

		return testNodeList;
	}

	public UserCreateObjectEvent createTestEvent(List<EUEObject> objectsToAdd) {
		SessionID sessionID = new SessionID("TEST SESSION");
		EUEEventID eventID = new EUEEventID("1");
		String srcComponent = "FlatGraphModelerTest";
		UserID userID = new UserID("TEST USER");

		UserCreateObjectEvent event = new UserCreateObjectEvent(sessionID,
				srcComponent, eventID, userID, objectsToAdd);

		return event;
	}

	private void checkWhetherPotentiallyCorrectMappingExists(Node inputNode,
			Node outputNode) {
		List<String> outValueCandidates = new Vector<String>();
		outValueCandidates.add(outputNode.getType());

		String message;
		if (inputNode.isTopLevelObject()) {
			// type mappings only for top-level nodes
			message = "InputNode type not correctly mapped to OutputNode type.";
			assertTrue(message, isPotentiallyCorrectMappingExistent(inputNode
					.getType(), outValueCandidates));
		}
		Hashtable<String, ObjectProperty> inputProps = inputNode.getProps();
		Hashtable<String, ObjectProperty> outputProps = outputNode.getProps();

		for (String inPropName : inputProps.keySet()) {
			ObjectProperty inProp = inputProps.get(inPropName);
			List<String> inPropValues = getValues(inProp);

			if (KEEP.equals(inPropName)) {
				ObjectProperty outProp = outputProps.get(KEEP);
				message = "'KEEP' property has not been maintained.";
				assertTrue(message, outProp != null);

				for (String inPropVal : inPropValues) {
					outValueCandidates = getValues(outProp);
					message = "InputNode propertyValue not correctly mapped to OutputNode propertyValue.";
					assertTrue(message, isPotentiallyCorrectMappingExistent(
							inPropVal, outValueCandidates));
				}
			} else {
				// assume "OLD" as prop name
				ObjectProperty outProp = outputProps.get(NEW);
				message = "'OLD' property has not been mapped to 'NEW' property";
				assertTrue(message, outProp != null);

				for (String inPropVal : inPropValues) {
					outValueCandidates = getValues(outProp);
					message = "InputNode propertyValue not correctly mapped to OutputNode propertyValue.";
					assertTrue(message, isPotentiallyCorrectMappingExistent(
							inPropVal, outValueCandidates));
				}
			}
		}
	}

	private List<String> getValues(ObjectProperty prop) {
		List<String> values = new Vector<String>();
		if (prop instanceof SimpleProperty) {
			String val = ((SimpleProperty) prop).getValueAsString();
			values.add(val);
		} else {
			// assume ListProperty
			values = ((ListProperty) prop).getValues();
		}
		return values;
	}

	// checks necessary (but not sufficient) condition for correcteness: a
	// "KEEP" input requires at least one "KEEP" output, an "OLD" input
	// requires at least one "NEW" output.
	private boolean isPotentiallyCorrectMappingExistent(String inValue,
			List<String> outValueCandidates) {
		if (KEEP.equals(inValue) && !outValueCandidates.contains(KEEP)) {
			return false;
		}
		if (OLD.equals(inValue) && !outValueCandidates.contains(NEW)) {
			return false;
		}
		return true;
	}
}
