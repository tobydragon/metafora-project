package de.dfki.lasad.modules.analysis.eventsummaryagent;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.dataservice.cf.dataprovider.MockDataProvider;
import de.dfki.lasad.core.dataservice.largoxml.dataprovider.LargoDataProvider55621;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;
import de.dfki.lasad.modules.analysis.eventsummaryagent.EventSummaryAgentDescription;
import de.dfki.lasad.modules.analysisactioncycle.FeedbackRequestExpectedResultPair;
import de.dfki.lasad.modules.analysisactioncycle.TestParameters;

public class EventSummaryAgentTestParameters implements TestParameters{

	private static final AnalysisAgentDescription analysisAgentDescription = new EventSummaryAgentDescription();
	private ControllableEUEEventPublisher eventPublisher = new LargoDataProvider55621();	
	
	@Override
	public ControllableEUEEventPublisher getInputDataProvider() {
		return eventPublisher;
	}
	
	@Override
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions() {
		List<AnalysisAgentDescription> descriptions = new Vector<AnalysisAgentDescription>();
		descriptions.add(analysisAgentDescription);
		return descriptions;
	}

	@Override
	public List<ActionAgentDescription> getActionAgentDescriptions() {
		return new Vector<ActionAgentDescription>();
	}

	@Override
	public FeedbackRequestExpectedResultPair getRequestResultPair() {
		return null;
	}

}
