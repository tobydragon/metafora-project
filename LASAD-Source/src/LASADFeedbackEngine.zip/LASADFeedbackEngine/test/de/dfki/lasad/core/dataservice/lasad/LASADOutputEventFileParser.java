package de.dfki.lasad.core.dataservice.lasad;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Vector;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;


public class LASADOutputEventFileParser {
	private String fileName;
	private String filePath;
	private List<ActionPackage> actionPackageList = new Vector<ActionPackage>();
	private int actionCounter = 0;
	
	public LASADOutputEventFileParser(String filePath, String fileName) {
		try {
			this.filePath = filePath;
			this.fileName = fileName;
			if((null != filePath) && (null != fileName)){
				loadFile();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void  loadFile()throws IOException {
		
		// Get all files in directory
		File file = new File(filePath + fileName);
//		File[] files = directory.listFiles();
		if ( file != null){
			System.out.println("About to Load Ouput Event Test Data...");
				Scanner s = new Scanner( new FileReader( file ) );
				if (file.exists()){
					try{
						while(s.hasNext()){
							String categoryValue = null;
							String commandValue = null;
							String line = null;
							Map<String, String> actionParams = new HashMap<String, String>();
							int index = 0;

							//Get event type
							line = nextLine(s);
							int pos = line.indexOf(':');
							String objectEventType = line.substring(0, pos);
							
							//Get sourceComponentID     sourceComponentID=class de.dfki.lasad.modules.dataservice.lasad.LASADDataService,
							index = pos + 2 ; //skip ", "
							line = line.substring(index, line.length()); //remove string's parsed section
							pos = line.indexOf(',');
							String[] nameValueArray = line.substring(0, pos).split("=");
							String sourceComponentIDValue = nameValueArray[1];
							
							//get timestamp    ts=1146731336965,
							index = pos + 2 ; //skip ", "
							line = line.substring(index, line.length()); //remove string's parsed section
							pos = line.indexOf(',');
							nameValueArray = line.substring(0, pos).split("=");
							String ts = nameValueArray[1];
							
							//get sessionID    sessionID=[SessionID: 58],
							index = pos + 2 ; //skip ", "
							line = line.substring(index, line.length()); //remove string's parsed section
							pos = line.indexOf(',');
							nameValueArray = line.substring(0, pos).split("="); //[0]="sessionID" [1]="[SessionID: 58]"
							String tmp = nameValueArray[1].replace(']', ' ');  //"[SessionID: 58 "
							nameValueArray = tmp.split(":");   //[0]="[SessionID"  [1]=" 58 "
							String sessionID =  nameValueArray[1].trim();
							
							//get eueEventID    eueEventID=[EUEEventID: 13],
							index = pos + 2 ; //skip ", "
							line = line.substring(index, line.length()); //remove string's parsed section
							pos = line.indexOf(',');
							nameValueArray = line.substring(0, pos).split("="); 
							tmp = nameValueArray[1].replace(']', ' ');  
							nameValueArray = tmp.split(":");   
							String eueEventID =  nameValueArray[1].trim();
							
							//time for the eueObjectList
							index = pos + 2 ; //skip ", "
							line = line.substring(index, line.length()); //remove string's parsed section
							pos = line.indexOf('[');
							pos++;
							int posEnd =  line.indexOf(':', pos);
							String type = line.substring(pos, posEnd);
							
							nameValueArray = line.substring(0, pos).split("="); 
							tmp = nameValueArray[1].replace(']', ' ');  
							nameValueArray = tmp.split(":");   
							String userID =  nameValueArray[1].trim();
							
							
							ActionPackage actionPackage = new ActionPackage();
							line = nextLine(s);
							while(!line.equals("}")){
								if(!"[".equals(line)){
									line = nextLine(s);
									continue;
								}
								String action = nextLine(s);
								line = nextLine(s);
								String[] nameValue = line.split(":");
								categoryValue = nameValue[1].trim();
								line = nextLine(s);
								nameValue = line.split(":");
								commandValue = nameValue[1].trim();
								line = nextLine(s);
								if (line.startsWith("PARAMETERS")){
									line = nextLine(s);
									while(!line.equals("]")){
										int pos1 = line.indexOf(':');
										//System.out.println("Name -" + line.substring(0, pos) + "-");
										//System.out.println("Value -" + line.substring(pos+1, line.length()) + "-");
										String paramName = line.substring(0, pos1);
										String paramValue = line.substring(pos1+1, line.length());
										actionParams.put(paramName, paramValue);
										line = nextLine(s);
									}
									Action act = LASADUserActionSimulator.createNewAction(categoryValue, commandValue, actionParams);
									actionPackage.getActions().add(act);
									
								}else{
									continue;
								}
							}
							if (actionPackage.getActions().size() > 0){
								actionPackageList.add(actionPackage);
							}
							
						}
						
					}catch(NoSuchElementException e){
						System.out.println("Catch- Test Data Load done...");
					}
				}
				

				s.close();		
		}
			    
			// Get all files in directory
			System.out.println("Test Data Load done..");
	}
	
	private String nextLine(Scanner s) throws NoSuchElementException{
		String line = null;
		do{
			line = s.nextLine().trim();
//			System.out.println("#" + line);
		}while((null == line) || (line.trim().equals("")));
		return line;
	}
}
