package de.dfki.lasad.core.dataservice.cf.parser;

import java.util.List;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.EUEEventListener;
import de.dfki.lasad.events.eue.EUEEventPublisher;
import de.dfki.lasad.models.eue.SessionID;

public class CFParser implements EUEEventListener, EUEEventPublisher {

	Log logger = LogFactory.getLog(CFParser.class);

	private XMLReader xmlReader;
	private CFSaxHandler cfhandler;

	private List<EUEEventListener> listeners = new Vector<EUEEventListener>();

	public CFParser() {
		this(0);
	}

	public CFParser(long delayMillis) {
		try {
			cfhandler = new CFSaxHandler(this, delayMillis);

			xmlReader = XMLReaderFactory.createXMLReader();
			// .createXMLReader("org.apache.xerces.parsers.SAXParser");
			xmlReader.setFeature("http://xml.org/sax/features/validation",
					false);
			xmlReader.setContentHandler(cfhandler);
			xmlReader.setErrorHandler(cfhandler);
		} catch (Exception e) {
			throw new ParsingCFException(e);
		}
	}

	@Override
	public void subscribe(EUEEventListener listener) {
		listeners.add(listener);
	}

	@Override
	public void onEUEEvent(EUEEvent eueEvent) {
		for (EUEEventListener listener : listeners) {
			listener.onEUEEvent(eueEvent);
		}
	}

	public void parse(InputSource source, SessionID sessionID) {
		try {
			cfhandler.prepareNewParse(sessionID);
			xmlReader.parse(source);
		} catch (Exception e) {
			// logger.error(e.getMessage(), e);
			throw new ParsingCFException(e);
		}
	}
}
