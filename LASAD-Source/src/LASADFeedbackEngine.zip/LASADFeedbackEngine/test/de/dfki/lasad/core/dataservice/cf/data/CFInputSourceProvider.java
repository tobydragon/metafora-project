package de.dfki.lasad.core.dataservice.cf.data;

import java.io.InputStream;
import java.net.URL;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.InputSource;

import de.dfki.lasad.util.ResourceOnClasspathHelper;

public class CFInputSourceProvider {

	static Log logger = LogFactory.getLog(CFInputSourceProvider.class);

	public static final String packagePath = "/"
			+ CFInputSourceProvider.class.getPackage().getName().replace(".",
					"/");
	public static final String mockDataFile = "simple_handmade.xml";
	public static final String hujiDataFile = "biology_experiments2.xml";
	public static final String ukDataFile = "group10_week5.xml";

	public static String getAbsoluteFilePathUK() {
		return getAbsoluteFilepath(ukDataFile);
	}

	public static String getAbsoluteFilePathHUJI() {
		return getAbsoluteFilepath(hujiDataFile);
	}

	public static String getAbsoluteFilePathMockData() {
		return getAbsoluteFilepath(mockDataFile);
	}

	public static InputSource getMockDataSource() {
		String mockDataPath = getClasspathPath(mockDataFile);
		InputSource inputSource = getInputSource(mockDataPath);
		return inputSource;
	}

	public static InputSource getHUJIDataSource() {
		String hujiDataPath = getClasspathPath(hujiDataFile);
		InputSource inputSource = getInputSource(hujiDataPath);
		return inputSource;
	}

	public static InputSource getUKDataSource() {
		String ukDataPath = getClasspathPath(ukDataFile);
		InputSource inputSource = getInputSource(ukDataPath);
		return inputSource;
	}

	private static String getAbsoluteFilepath(String localFilename) {
		String classpathPath = getClasspathPath(localFilename);
		String absoluteFilePath = ResourceOnClasspathHelper
				.getAbsoluteFilepathFromResourceOnClasspath(
						CFInputSourceProvider.class, classpathPath);
		return absoluteFilePath;
	}

	private static String getClasspathPath(String localFilename) {
		String pathRelativeToClasspath = packagePath + "/" + localFilename;
		return pathRelativeToClasspath;
	}

	private static InputSource getInputSource(String classpathPath) {
		try {
			URL url = ResourceOnClasspathHelper.getURLFromResourceOnClasspath(
					CFInputSourceProvider.class, classpathPath);
			InputStream cfStream = url.openStream();
			InputSource inputSource = new InputSource(cfStream);
			return inputSource;
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}
}
