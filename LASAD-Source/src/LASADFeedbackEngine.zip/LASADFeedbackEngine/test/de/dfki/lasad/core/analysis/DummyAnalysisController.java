package de.dfki.lasad.core.analysis;

import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.analysis.AnalysisRequestEvent;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.events.eue.session.EUESessionEvent;

/**
 * Dummy class. Ignores every incoming {@link Event}.
 * 
 * @author Oliver Scheuer
 * 
 */
public class DummyAnalysisController implements IAnalysisController {

	@Override
	public void addAnalysisAgent(IAnalysisAgent analysisAgent) {
		// TODO Auto-generated method stub

	}

	@Override
	public void doWire(IActionController actionController) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onAnalysisRequestEvent(AnalysisRequestEvent analysisRequestEvent) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onAnalysisResultEvent(AnalysisResultEvent analysisResultEvent) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onEUEEvent(EUESessionEvent eueEvent) {
		// TODO Auto-generated method stub

	}

}
