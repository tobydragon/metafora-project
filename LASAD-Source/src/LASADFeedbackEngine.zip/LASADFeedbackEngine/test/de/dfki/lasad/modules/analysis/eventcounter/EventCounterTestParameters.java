package de.dfki.lasad.modules.analysis.eventcounter;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;
import de.dfki.lasad.models.action.ActionComponentSpec;
import de.dfki.lasad.models.analysis.AnalyzableEntity;
import de.dfki.lasad.models.analysis.NumericalResult;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackRequestSpec;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackTypeID;
import de.dfki.lasad.modules.analysisactioncycle.FeedbackRequestExpectedResultPair;
import de.dfki.lasad.modules.analysisactioncycle.TestParameters;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class EventCounterTestParameters implements TestParameters {

	private static final AnalysisAgentDescription analysisAgentDescription = new EUEEventCounterDescription();
	private ControllableEUEEventPublisher eventPublisher;
	private FeedbackRequestExpectedResultPair requestResultPair;

	public EventCounterTestParameters(
			ControllableEUEEventPublisher eventPublisher, String analysisID,
			double expectedValue) {
		this.eventPublisher = eventPublisher;

		initRequestResultPair(analysisID, expectedValue);
	}

	@Override
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions() {
		List<AnalysisAgentDescription> descriptions = new Vector<AnalysisAgentDescription>();
		descriptions.add(analysisAgentDescription);
		return descriptions;
	}

	@Override
	public List<ActionAgentDescription> getActionAgentDescriptions() {
		return new Vector<ActionAgentDescription>();
	}

	@Override
	public ControllableEUEEventPublisher getInputDataProvider() {
		return eventPublisher;
	}

	@Override
	public FeedbackRequestExpectedResultPair getRequestResultPair() {
		return requestResultPair;
	}

	private final void initRequestResultPair(String analysisTypeID,
			double expectedValue) {
		requestResultPair = new FeedbackRequestExpectedResultPair();
		FeedbackTypeID feedbackTypeID = new FeedbackTypeID(
				analysisAgentDescription.getComponentID(), analysisTypeID, true);
		FeedbackRequestSpec feedbackRequestSpec = new FeedbackRequestSpec(
				feedbackTypeID);
		feedbackRequestSpec.setNumResults(FeedbackRequestSpec.ALL_RESULTS);
		requestResultPair.setFeedbackRequestSpec(feedbackRequestSpec);

		ActionComponentSpec expectedResultActionSpec = new ActionComponentSpec();
		AnalysisType analysisType = new AnalysisType(analysisAgentDescription
				.getComponentID(), analysisTypeID);
		AnalyzableEntity entity = new AnalyzableEntity();
		entity.addEntityComponent(eventPublisher.getSessionID());
		NumericalResult expectedAnalysisResult = new NumericalResult(
				analysisType, entity, expectedValue);
		expectedResultActionSpec.addActionComponent(expectedAnalysisResult);
		requestResultPair.addExpectedResultActionSpec(expectedResultActionSpec);
	}
}
