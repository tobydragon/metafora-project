package de.dfki.lasad.core.dataservice.cf.parser.preamble;

import java.util.HashMap;
import java.util.Map;


public class CFPreamble {

	public Map<String, UserDef> users = new HashMap<String, UserDef>();
	public Map<String, ObjectDef> objects = new HashMap<String, ObjectDef>();

}
