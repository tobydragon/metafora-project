package de.dfki.lasad.modules.dataservice.lasad;

//import lasad.ejb.ActionPackage;
import lasad.gwt.client.communication.objects.ActionPackage;
import de.dfki.lasad.core.action.DummyActionController;
import de.dfki.lasad.core.analysis.DummyAnalysisController;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMI;
//import de.dfki.lasad.modules.dataservice.lasad.ws.LASADDataServiceWS;

/**
 * For testing purposes: Allows to register for incoming and outgoing
 * ActionPackages (which are otherwise hidden by the {@link LASADDataServiceRMI}).
 * 
 * @author Oliver Scheuer
 * 
 */
public class AccessibleLASADDataService extends LASADDataServiceRMI {

	public AccessibleLASADDataService() {
		super();
		analysisController = new DummyAnalysisController();
		actionController = new DummyActionController();
	}

	public ActionPackageFactory getActionPackageFactory() {
		return actionPackageFactory;
	}

	@Override
	public void sendActionPackage(ActionPackage outPackage){
		super.sendActionPackage(outPackage);
		//return super.sendActionPackage(outPackage);
	}
	
	public void registerForIncomingActionPackages(
			ActionPackageListener inListener) {
		incomingActionPackListeners.add(inListener);
	}

	public void registerForOutgoingActionPackages(
			ActionPackageListener outListener) {
		outgoingActionPackListeners.add(outListener);
	}
}
