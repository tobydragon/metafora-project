package de.dfki.lasad.core.dataservice.cf.parser.preamble;

import java.util.HashMap;
import java.util.Map;

public class ObjectDef {

	public String id;
	public String type;
	public Map<String, String> props = new HashMap<String, String>();

}
