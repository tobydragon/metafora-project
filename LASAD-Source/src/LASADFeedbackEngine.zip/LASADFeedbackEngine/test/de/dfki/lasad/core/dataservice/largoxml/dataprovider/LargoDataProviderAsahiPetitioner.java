package de.dfki.lasad.core.dataservice.largoxml.dataprovider;

/**
 * 
 * @author Oliver Scheuer
 *
 */
public class LargoDataProviderAsahiPetitioner extends LargoDataProvider {

	public LargoDataProviderAsahiPetitioner() {
		// Data uses this specific transcript
		ontology.addExternalResourceID("largo_asahi_petitioner");
	}

}
