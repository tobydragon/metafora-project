package de.dfki.lasad.modules.analysis.deeploop;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import de.dfki.lasad.core.dataservice.cf.dataprovider.CFDataProvider;
import de.dfki.lasad.core.dataservice.cf.dataprovider.HUJIDataProvider;
import de.dfki.lasad.models.analysis.AnalyzableEntity;
import de.dfki.lasad.modules.analysisactioncycle.TestFramework;

/**
 * Expected results are based on the results provided through another Deep Loop
 * client (the "Moderator's Interface"), whose behavior is mimicked by the
 * {@link DeepLoopAnalysisAgent}.
 * 
 * @author Oliver Scheuer
 * 
 */
public class HUJIDataTests extends TestFramework {

	private Log logger = LogFactory.getLog(HUJIDataTests.class);

	CFDataProvider dataProvider = new HUJIDataProvider();

	String[] nodeTypes = new String[] { "claim", "Information", "argument",
			"question", "Comment", "Idea", "task" };
	String[] linkTypes = new String[] { "support", "oppose", "Link" };

	DeepLoopAnalysisAgentConfiguration conf;

	public HUJIDataTests() {
		super();
		conf = new Basic2DeepLoopPropMappingConfiguration(nodeTypes, linkTypes);
	}

	@Override
	protected void initSessionInWorldModel() {
		// do nothing == switching off the World Model
	};
	
	/**
	 * Test shape-level classifications.
	 */
	@Test
	public void testCoR() {

		Map<AnalyzableEntity, Boolean> entityIDs2Classification = new HashMap<AnalyzableEntity, Boolean>();

		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V1" }, true);

		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V19" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V8" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V14" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V12" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V17" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V15" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V7" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V9" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V18" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V11" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V2" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V5" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V3" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V13" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V10" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V16" }, false);

		DeepLoopTestParameters params = new DeepLoopTestParameters(
				dataProvider, conf, DeepLoopAnalysisAgentDescription.CoR_en,
				entityIDs2Classification);

		setTestParameters(params);
		runTestAndCheckResults();
	}

	/**
	 * Test shape-level classifications.
	 */
	@Test
	public void testNonTF() {

		Map<AnalyzableEntity, Boolean> entityIDs2Classification = new HashMap<AnalyzableEntity, Boolean>();

		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V1" }, false);

		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V19" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V8" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V14" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V12" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V17" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V15" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V7" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V9" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V18" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V11" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V2" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V5" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V3" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V13" }, true);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V10" }, false);
		fillinExpectedClassification(entityIDs2Classification,
				new String[] { "V16" }, false);

		DeepLoopTestParameters params = new DeepLoopTestParameters(
				dataProvider, conf, DeepLoopAnalysisAgentDescription.NonTF_en,
				entityIDs2Classification);

		setTestParameters(params);
		runTestAndCheckResults();
	}

	/**
	 * Test paired-shape-level classifications.
	 */
	@Test
	public void testCCA() {

		Map<AnalyzableEntity, Boolean> entityIDs2Classification = new HashMap<AnalyzableEntity, Boolean>();

		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V12", "V10" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V10", "V9" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V11", "V7" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V16", "V17" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V7", "V2" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V18", "V16" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V9", "V3" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V15", "V11" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V8", "V5" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V17", "V15" }, true);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V5", "V2" }, true);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V14", "V13" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V10", "V13" }, false);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V2", "V3" }, false);

		DeepLoopTestParameters params = new DeepLoopTestParameters(
				dataProvider, conf, DeepLoopAnalysisAgentDescription.CCA_en,
				entityIDs2Classification);

		setTestParameters(params);
		runTestAndCheckResults();
	}

	/**
	 * Test cluster-level classifications.
	 */
	@Test
	public void testNewPerspective() {

		Map<AnalyzableEntity, Boolean> entityIDs2Classification = new HashMap<AnalyzableEntity, Boolean>();

		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V16", "V17", "V18" }, true);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V2", "V3", "V9" }, true);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V11", "V2", "V7" }, true);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V11", "V15", "V7" }, true);
		fillinExpectedClassification(entityIDs2Classification, new String[] {
				"V2", "V3", "V7" }, true);
		DeepLoopTestParameters params = new DeepLoopTestParameters(
				dataProvider, conf,
				DeepLoopAnalysisAgentDescription.newPerspective1,
				entityIDs2Classification);

		setTestParameters(params);
		runTestAndCheckResults();
	}

	private void fillinExpectedClassification(
			Map<AnalyzableEntity, Boolean> entityIDs2Classification,
			String[] entityIDs, boolean expectedValue) {
		entityIDs2Classification.put(DeepLoopTestParameters
				.constructEntity(entityIDs), expectedValue);
	}
}
