package de.dfki.lasad.core.dataservice.cf.dataprovider;

import org.graphdrawing.graphml.xmlns.x1.GraphmlDocument;

import de.dfki.lasad.core.dataservice.cf.data.CFInputSourceProvider;
import de.dfki.lasad.models.eue.SessionID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class UKDataProvider extends CFDataProvider {

	SessionID sessionID = new SessionID(CFInputSourceProvider.ukDataFile);
	
	public UKDataProvider() {
		super();
		parser.parse(CFInputSourceProvider.getUKDataSource(), sessionID);
	}

	@Override
	public GraphmlDocument getGraphML() {
		return super.getGraphMLFromCF(CFInputSourceProvider
				.getAbsoluteFilePathUK());
	}

	@Override
	public SessionID getSessionID() {
		return sessionID;
	}

}
