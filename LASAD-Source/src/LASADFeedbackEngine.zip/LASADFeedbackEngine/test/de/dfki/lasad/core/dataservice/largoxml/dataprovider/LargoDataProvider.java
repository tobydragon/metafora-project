package de.dfki.lasad.core.dataservice.largoxml.dataprovider;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import lasad.gwt.client.communication.objects.ActionPackage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.core.dataservice.lasad.LASADUserSessionSimulator;
import de.dfki.lasad.core.worldmodel.IModelController;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.EUEEventListener;
import de.dfki.lasad.events.eue.admin.EUESessionListEvent;
import de.dfki.lasad.events.eue.session.AgentJoinSessionAnnounceEvent;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.ontology.EUEOntology;
import de.dfki.lasad.models.eue.ontology.graph.GraphOntology;
import de.dfki.lasad.modules.dataservice.lasad.ActionPackageListener;
import de.dfki.lasad.modules.dataservice.lasad.ActionPackageListener.Direction;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMI;
import de.dfki.lasad.modules.dataservice.lasad.translators.EventTranslatorLASAD2AF;

public abstract class LargoDataProvider implements
		ControllableEUEEventPublisher, ActionPackagePublisher {

	private Log logger = LogFactory.getLog(LargoDataProvider.class);

	private EventTranslatorLASAD2AF pack2Event = new EventTranslatorLASAD2AF();
	private LASADUserSessionSimulator userSessionSimulator;
	private String contextPath = "de.dfki.lasad.modules.dataservice.lasad.outws";

	private List<EUEEventListener> eventListeners = new Vector<EUEEventListener>();
	private List<ActionPackageListener> actionPackageListeners = new Vector<ActionPackageListener>();

	private Vector<EUEEvent> eventList = new Vector<EUEEvent>();
	private Vector<ActionPackage> actionPackageList = new Vector<ActionPackage>();

	// default: 51
	protected SessionID sessionID = new SessionID("51");
	protected GraphOntology ontology = new GraphOntology("LARGO");

	public LargoDataProvider() {
	}

	public SessionID getSessionID() {
		return sessionID;
	}

	public void setSessionID(SessionID sessionID) {
		this.sessionID = sessionID;
	}

	@Override
	public EUEOntology getOntology() {
		return ontology;
	}

	public void initDataService(String filePath, String fileName) {
		userSessionSimulator = new LASADUserSessionSimulator(contextPath,
				filePath, fileName);
		parseActionPackages();
	}

	/**
	 * Reads ActionPackages from file, translates ActionPackages to Events, and
	 * stores ActionPackages and Events in internal data structures.
	 */
	private void parseActionPackages() {
		ActionPackage actionPackage = userSessionSimulator
				.simulateNextUserAction();
		while (actionPackage != null) {
			actionPackageList.add(actionPackage);
			List<EUESessionEvent> events = pack2Event.translate(actionPackage);
			eventList.addAll(events);
			actionPackage = userSessionSimulator.simulateNextUserAction();
		}
	}

	@Override
	public void subscribe(EUEEventListener listener) {
		getEventListeners().add(listener);
	}

	@Override
	public void subscribe(ActionPackageListener listener) {
		getActionPackageListeners().add(listener);

	}

	private synchronized List<EUEEventListener> getEventListeners() {
		return eventListeners;
	}

	private synchronized List<ActionPackageListener> getActionPackageListeners() {
		return actionPackageListeners;
	}

	/**
	 * If a {@link IModelController} is available initialize this session
	 */
	@Override
	public void initSessionInWorldModel() {
		if (ServiceRegistry.getModelController() != null) {
			String srcCompID = this.getClass().toString();
			EUESessionListEvent sessionListEvent = new EUESessionListEvent(
					srcCompID);
			sessionListEvent.addOntology(getSessionID(), getOntology());

			ServiceRegistry.getModelController().executeSessionListEvent(
					sessionListEvent);
			AgentJoinSessionAnnounceEvent joinSessionAnnounceEvent = new AgentJoinSessionAnnounceEvent(
					getSessionID(), srcCompID);
			ServiceRegistry.getModelController()
					.executeAgentJoinSessionAnnounceEvent(
							joinSessionAnnounceEvent);
		}
	}

	@Override
	public void startPublishingEUESessionEvents() {
		for (EUEEvent eueEvent : eventList) {
			for (EUEEventListener listener : eventListeners) {
				listener.onEUEEvent(eueEvent);
			}
		}
	}

	public void startAP() {
		for (ActionPackage ap : actionPackageList) {
			for (ActionPackageListener listener : actionPackageListeners) {
				listener.onActionPackage(ap, Direction.IN);
			}
		}
	}

	@Override
	public boolean isFinishedPublishingEUEEvents() {
		// component works synchronously.
		return true;
	}

	public Iterator<EUEEvent> iterator() {
		return eventList.iterator();
	}

	public Iterator<ActionPackage> iteratorAP() {
		return actionPackageList.iterator();
	}

	protected void printDataToLogger() {
		Iterator<ActionPackage> apIter = iteratorAP();
		Iterator<EUEEvent> eIter = iterator();

		logger
				.debug("############# A C T I O N  P A C K A G E S ###################");
		while (apIter.hasNext()) {
			ActionPackage actionPack = apIter.next();
			String actionPackageAsString = LASADDataServiceRMI
					.actionPackage2String(actionPack);
			logger.debug(actionPackageAsString);
		}
		logger.debug("############# E V E N T S ###################");
		while (eIter.hasNext()) {
			EUEEvent event = eIter.next();
			String eventAsString = event.toString();
			logger.debug("... Translation: " + eventAsString);
		}
	}
}
