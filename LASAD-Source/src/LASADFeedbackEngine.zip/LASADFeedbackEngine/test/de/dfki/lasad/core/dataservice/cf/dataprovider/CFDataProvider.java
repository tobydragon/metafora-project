package de.dfki.lasad.core.dataservice.cf.dataprovider;

import info.collide.analysis.commonformat.converter.GraphMLConverter;

import java.util.Iterator;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.graphdrawing.graphml.xmlns.x1.GraphmlDocument;

import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.core.dataservice.cf.parser.CFParser;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.EUEEventListener;
import de.dfki.lasad.events.eue.admin.EUESessionListEvent;
import de.dfki.lasad.events.eue.session.AgentJoinSessionAnnounceEvent;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;
import de.dfki.lasad.models.eue.ontology.EUEOntology;
import de.dfki.lasad.models.eue.ontology.graph.GraphOntology;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public abstract class CFDataProvider implements EUEEventListener,
		ControllableEUEEventPublisher {

	private Log logger = LogFactory.getLog(CFDataProvider.class);

	protected CFParser parser = new CFParser();
	protected Vector<EUEEvent> eventList = new Vector<EUEEvent>();
	protected Vector<EUEEventListener> listeners = new Vector<EUEEventListener>();

	protected GraphOntology ontology = new GraphOntology("Argunaut");

	public CFDataProvider() {
		parser.subscribe(this);
	}

	@Override
	public EUEOntology getOntology() {
		return ontology;
	}

	/**
	 * If a {@link IModelController} is available initialize this session
	 */
	@Override
	public void initSessionInWorldModel() {
		if (ServiceRegistry.getModelController() != null) {
			String srcCompID = this.getClass().toString();
			EUESessionListEvent sessionListEvent = new EUESessionListEvent(
					srcCompID);
			sessionListEvent.addOntology(getSessionID(), getOntology());

			ServiceRegistry.getModelController().executeSessionListEvent(
					sessionListEvent);
			AgentJoinSessionAnnounceEvent joinSessionAnnounceEvent = new AgentJoinSessionAnnounceEvent(
					getSessionID(), srcCompID);

			ServiceRegistry.getModelController()
					.executeAgentJoinSessionAnnounceEvent(
							joinSessionAnnounceEvent);
		}
	}

	@Override
	public void startPublishingEUESessionEvents() {
		for (EUEEvent eueEvent : this) {
			for (EUEEventListener listener : listeners) {
				listener.onEUEEvent(eueEvent);
			}
		}
	}

	@Override
	public boolean isFinishedPublishingEUEEvents() {
		// component works synchronously.
		return true;
	}

	@Override
	public void subscribe(EUEEventListener listener) {
		listeners.add(listener);
	}

	public abstract GraphmlDocument getGraphML();

	public Iterator<EUEEvent> iterator() {
		return eventList.iterator();
	}

	@Override
	public void onEUEEvent(EUEEvent event) {
		eventList.add(event);
	}

	public static GraphmlDocument getGraphMLFromCF(String absoluteCFFilePath) {
		GraphMLConverter converter = new GraphMLConverter();
		GraphmlDocument doc = converter.convert(absoluteCFFilePath);
		return doc;
	}

	public static void main(String[] args) {
		System.out.println(CFDataProvider.getGraphMLFromCF(args[0]));
	}

}
