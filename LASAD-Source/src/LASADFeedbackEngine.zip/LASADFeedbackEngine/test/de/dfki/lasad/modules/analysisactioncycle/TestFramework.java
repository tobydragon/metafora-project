package de.dfki.lasad.modules.analysisactioncycle;

import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.action.IActionAgent;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.core.application.AccessibleAppBuilder;
import de.dfki.lasad.core.dataservice.RemoteControlDataService;
import de.dfki.lasad.events.action.ActionSpecEvent;
import de.dfki.lasad.events.action.ActionSpecEventListener;
import de.dfki.lasad.events.eue.session.EUEEventID;
import de.dfki.lasad.events.eue.session.UserFeedbackRequestEvent;
import de.dfki.lasad.models.action.ActionComponent;
import de.dfki.lasad.models.action.ActionSpec;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackRequestSpec;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * Provides basic functionality to test a complete cycle (i.e., data provision,
 * analysis and action generation) based on a set of input data, a feedback
 * request and a corresponding set of expected results (i.e., actions to be
 * produced). The test framework has to be initialized with
 * {@link TestParameters}.
 * 
 * @author Oliver Scheuer
 * 
 */
public class TestFramework extends TestCase implements ActionSpecEventListener {

	private Log logger = LogFactory.getLog(TestFramework.class);

	private TestParameters params;

	protected AccessibleAppBuilder appBuilder;
	private RemoteControlDataService dataService;

	private ActionSpecEvent actionSpecEvent = null;

	private int feedbackRequestEventCounter = 1;

	public TestFramework() {
		super();
	}

	public void setTestParameters(TestParameters params) {
		this.params = params;
	}

	@Override
	public void onActionSpecEvent(ActionSpecEvent event) {
		if (actionSpecEvent != null) {
			logger.warn("More than 1 ActionSpecEvent received. Overwrite.");
		}
		actionSpecEvent = event;
	}

	protected void runTestAndCheckResults() {
		prepareBasicApp();
		startTestAndCreateEvents();
		issueFeedbackRequestAndCheckResults();
	}
	
	protected void startTestAndCreateEvents(){
		prepareBasicApp();
		initSessionInWorldModel();
		params.getInputDataProvider().startPublishingEUESessionEvents();
		while (!params.getInputDataProvider().isFinishedPublishingEUEEvents()) {
			// wait
		}
		try {
			// wait a second to be sure that all input data reached the analysis
			// agent before a feedback request
			Thread.sleep(1000);
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage());
		}
	}

	private void prepareBasicApp() {
		TestConfiguration configuration = new TestConfiguration();
		configuration.setAnalysisAgentDesciptions(params
				.getAnalysisAgentDescriptions());
		configuration.setActionAgentDesciptions(params
				.getActionAgentDescriptions());
		appBuilder = new AccessibleAppBuilder(configuration);
		
		SessionID sessionID = params.getInputDataProvider().getSessionID();
		EUEOntology ontology = params.getInputDataProvider().getOntology();
		
		for (IAnalysisAgent analysisAgent: appBuilder.getAnalysisAgents()){
			analysisAgent.requestSupportSession(sessionID, ontology);
		}
		
		appBuilder.doWireAndStart();
		dataService = (RemoteControlDataService) appBuilder.getDataService();
		dataService.subscribeActionSpecEventListener(this);
		params.getInputDataProvider().subscribe(dataService);
	}

	protected void initSessionInWorldModel(){
		params.getInputDataProvider().initSessionInWorldModel();
	}
	
	private void issueFeedbackRequestAndCheckResults() {
		FeedbackRequestExpectedResultPair requestResultPair = params
				.getRequestResultPair();
		FeedbackRequestSpec feedbackRequestSpec = requestResultPair
				.getFeedbackRequestSpec();
		issueFeedbackRequest(feedbackRequestSpec);
		while (actionSpecEvent == null) {
			// wait
		}

		List<ActionSpec> expectedActionSpecs = requestResultPair
				.getExpectedResultActionSpecs();
		checkResults(expectedActionSpecs);
		actionSpecEvent = null;
	}

	private void issueFeedbackRequest(FeedbackRequestSpec feedbackRequestSpec) {
		SessionID sessionID = params.getInputDataProvider().getSessionID();
		String srcComponentID = getClass().getName();
		EUEEventID eventID = new EUEEventID("test feedback request event "
				+ feedbackRequestEventCounter);
		++feedbackRequestEventCounter;
		UserID userID = new UserID("test user");

		UserFeedbackRequestEvent feedbackRequestEvent = new UserFeedbackRequestEvent(
				feedbackRequestSpec, sessionID, srcComponentID, eventID, userID);
		logger.info("Issue feedbackRequest: " + feedbackRequestEvent);
		dataService.onEUEEvent(feedbackRequestEvent);
	}

	private void checkResults(List<ActionSpec> expectedActionSpecs) {
		try {
			Set<ActionSpec> actualResults = actionSpecEvent.getActionSpecs();
			logger.info("Check number of ActionSpecs ...");
			assertEquals(expectedActionSpecs.size(), actualResults.size());
			logger.info("... Ok");

			if (expectedActionSpecs.size() == 1) {
				// fine grained test
				ActionSpec expectedActionSpec = expectedActionSpecs.get(0);
				ActionSpec actualActionSpec = actualResults.iterator().next();

				Set<? extends ActionComponent> expectedComponents = expectedActionSpec
						.getActionComponents();
				Set<? extends ActionComponent> actualComponents = actualActionSpec
						.getActionComponents();

				logger.info("Check number of ActionComponents ...");
				assertEquals(expectedComponents.size(), actualComponents.size());
				logger.info("... Ok");

				for (ActionComponent expectedComponent : expectedComponents) {
					logger.info("Check for " + expectedComponent + " ...");
					boolean checkResult = actualComponents
							.contains(expectedComponent);
					assertTrue(
							"Computed ActionComponent not contained in test set: "
									+ expectedComponent.toString(), checkResult);
					logger.info("... Ok");
				}

			} else {
				// coarse grained test
				for (ActionSpec expectedActionSpec : expectedActionSpecs) {
					logger.info("Check for " + expectedActionSpec
							+ " in results ...");
					assertTrue(actualResults.contains(expectedActionSpec));
					logger.info("... OK.");

				}

			}
		} catch (AssertionError e) {
			logger.error(e.getClass() + ": " + e.getMessage());
		}
	}
}
