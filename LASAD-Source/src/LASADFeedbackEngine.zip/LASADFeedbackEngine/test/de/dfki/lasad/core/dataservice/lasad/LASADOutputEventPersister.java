package de.dfki.lasad.core.dataservice.lasad;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;

public class LASADOutputEventPersister {
	
	private String filePath; 
	private String fileName;
	private FileOutputStream fos = null;
	private ObjectOutputStream out = null;
	
	public LASADOutputEventPersister(String filePath, String fileName) {
		this.filePath = filePath;
		this.fileName = fileName;
		init();
	}
	
	private void init(){
		try
		{
			fos = new FileOutputStream(filePath + fileName);
			out = new ObjectOutputStream(fos);
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	public void writeObject(UserObjectActionEvent ouputEvent){
		try {
			out.writeObject(ouputEvent);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void closeFile(){
		if (null != out){
			try {
				out.close();
				out = null;
			} catch (IOException e) {
				e.printStackTrace();
			}
		 }
	}
	
	
	
}
