package de.dfki.lasad.core.dataservice.lasad;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;

public class LASADOutputEventLoader {

	private String filePath; 
	private String fileName;
	private FileInputStream fis = null;
	private ObjectInputStream in = null;
	
	
	public LASADOutputEventLoader(String filePath, String fileName) {
		super();
		this.filePath = filePath;
		this.fileName = fileName;
		init();
	}
	
	private void init(){
		try
		{
			fis = new FileInputStream(filePath + fileName);
			in = new ObjectInputStream(fis);
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	public UserObjectActionEvent readObject(){
		UserObjectActionEvent obj = null;
		try {
			obj = (UserObjectActionEvent)in.readObject();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	public void closeFile(){
		if (null != in){
			try {
				in.close();
				in = null;
			} catch (IOException e) {
				e.printStackTrace();
			}
		 }
	}
	
}
