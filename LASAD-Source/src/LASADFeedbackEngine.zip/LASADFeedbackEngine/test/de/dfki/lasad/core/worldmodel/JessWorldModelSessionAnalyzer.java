package de.dfki.lasad.core.worldmodel;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.action.ActionType;
import de.dfki.lasad.core.action.CompoundActionType;
import de.dfki.lasad.core.action.RuleBasedActionType;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.eue.SessionID;

/**
 * Feeds a sequence of {@link EUEEvent}s into the {@link JessModelController},
 * applies a set of analysis rules (cf. {@link RuleBasedActionType}) and
 * retrieves the corresponding {@link AnalysisResult}s.
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessWorldModelSessionAnalyzer {

	private static Log logger = LogFactory
			.getLog(JessWorldModelSessionAnalyzer.class);

	private static JessWorldModelAccessPoint jessAccessPoint = new JessWorldModelAccessPoint();

	public static Map<AnalysisType, List<AnalysisResult>> getAnalysisResults(
			ControllableEUEEventPublisher eventProvider, SessionID sessionID,
			CompoundActionType compoundActionType) {

		// registering rules
		for (ActionType actionType : compoundActionType.getSubActionTypes()) {
			if (actionType instanceof RuleBasedActionType) {
				String rule = ((RuleBasedActionType) actionType).getRule();
				jessAccessPoint.registerAnalysisPattern(actionType, rule);
			} else {
				logger.warn("Ignore ActionType: " + actionType
						+ " (not of type '"
						+ RuleBasedActionType.class.getName() + ")");
			}
		}

		// replaying session events
		jessAccessPoint.pushEventsIntoJessModelController(eventProvider,
				sessionID, eventProvider.getOntology());

		jessAccessPoint.printWorkingMemoryFacts(sessionID);
		jessAccessPoint.printWorkingMemoryRules(sessionID);
		
		// retrieving results
		Map<AnalysisType, List<AnalysisResult>> type2results = jessAccessPoint
				.getAnalysisResults(sessionID, compoundActionType);
		return type2results;
	}

}
