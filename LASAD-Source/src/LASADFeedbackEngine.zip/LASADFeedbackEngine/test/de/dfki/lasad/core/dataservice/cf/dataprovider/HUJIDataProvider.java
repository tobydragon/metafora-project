package de.dfki.lasad.core.dataservice.cf.dataprovider;

import org.graphdrawing.graphml.xmlns.x1.GraphmlDocument;

import de.dfki.lasad.core.dataservice.cf.data.CFInputSourceProvider;
import de.dfki.lasad.models.eue.SessionID;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class HUJIDataProvider extends CFDataProvider {

	SessionID sessionID = new SessionID(CFInputSourceProvider.hujiDataFile);

	public HUJIDataProvider() {
		super();
		parser.parse(CFInputSourceProvider.getHUJIDataSource(), sessionID);
	}

	@Override
	public GraphmlDocument getGraphML() {
		return super.getGraphMLFromCF(CFInputSourceProvider
				.getAbsoluteFilePathHUJI());
	}

	@Override
	public SessionID getSessionID() {
		return sessionID;
	}
	
	public static void main(String[] args) {
		System.out.println((new HUJIDataProvider()).getGraphML());
	}

}
