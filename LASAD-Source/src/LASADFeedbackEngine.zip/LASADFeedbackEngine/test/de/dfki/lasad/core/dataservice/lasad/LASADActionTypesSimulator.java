package de.dfki.lasad.core.dataservice.lasad;

public class LASADActionTypesSimulator {
	public static final String ACTION_CREATE_FACT = "##createFact";
	public static final String ACTION_CREATE_TEST = "##createTest";
	public static final String ACTION_CREATE_HYPOTHETICAL = "##createHypothetical";
	
	
	public static final String ACTION_CREATE_BOX = "#box";
	public static final String ACTION_CREATE_TEXT = "#text";
	public static final String ACTION_CREATE_DATE = "#date";
	public static final String ACTION_CREATE_IF = "#if";
	public static final String ACTION_CREATE_THEN = "#then";	
	
}

