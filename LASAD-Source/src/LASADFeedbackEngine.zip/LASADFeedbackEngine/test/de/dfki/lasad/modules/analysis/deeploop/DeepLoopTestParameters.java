package de.dfki.lasad.modules.analysis.deeploop;

import java.util.List;
import java.util.Map;
import java.util.Vector;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;
import de.dfki.lasad.models.action.AnalysisMirroringActionSpec;
import de.dfki.lasad.models.analysis.AnalyzableEntity;
import de.dfki.lasad.models.analysis.BinaryResult;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackRequestSpec;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackTypeID;
import de.dfki.lasad.models.eue.objects.EUEObjectID;
import de.dfki.lasad.modules.analysisactioncycle.FeedbackRequestExpectedResultPair;
import de.dfki.lasad.modules.analysisactioncycle.TestParameters;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class DeepLoopTestParameters implements TestParameters {

	private AnalysisAgentDescription analysisAgentDescription;
	private ControllableEUEEventPublisher eventPublisher;
	private FeedbackRequestExpectedResultPair requestResultPair;

	public static AnalyzableEntity constructEntity(String[] objectIDs) {
		AnalyzableEntity entity = new AnalyzableEntity();
		for (String objectIDString : objectIDs) {
			EUEObjectID objectID = new EUEObjectID(objectIDString);
			entity.addEntityComponent(objectID);
		}
		return entity;
	}

	public DeepLoopTestParameters(ControllableEUEEventPublisher eventPublisher,
			DeepLoopAnalysisAgentConfiguration conf, String analysisID,
			Map<AnalyzableEntity, Boolean> entityIDs2Classification) {
		this.eventPublisher = eventPublisher;
		this.analysisAgentDescription = new DeepLoopAnalysisAgentDescription(
				conf);
		initRequestResultPair(analysisID, entityIDs2Classification);
	}

	@Override
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions() {
		List<AnalysisAgentDescription> descriptions = new Vector<AnalysisAgentDescription>();
		descriptions.add(analysisAgentDescription);
		return descriptions;
	}

	@Override
	public List<ActionAgentDescription> getActionAgentDescriptions() {
		return new Vector<ActionAgentDescription>();
	}

	@Override
	public ControllableEUEEventPublisher getInputDataProvider() {
		return eventPublisher;
	}

	@Override
	public FeedbackRequestExpectedResultPair getRequestResultPair() {
		return requestResultPair;
	}

	private final void initRequestResultPair(String analysisID,
			Map<AnalyzableEntity, Boolean> entityIDs2Classification) {
		requestResultPair = new FeedbackRequestExpectedResultPair();

		FeedbackTypeID feedbackTypeID = new FeedbackTypeID(
				analysisAgentDescription.getComponentID(), analysisID, true);
		FeedbackRequestSpec feedbackRequestSpec = new FeedbackRequestSpec(
				feedbackTypeID);
		feedbackRequestSpec.setNumResults(FeedbackRequestSpec.ALL_RESULTS);
		requestResultPair.setFeedbackRequestSpec(feedbackRequestSpec);

		AnalysisMirroringActionSpec expectedResultActionSpec = new AnalysisMirroringActionSpec();
		AnalysisType analysisType = new AnalysisType(analysisAgentDescription
				.getComponentID(), analysisID);

		for (AnalyzableEntity entity : entityIDs2Classification.keySet()) {
			Boolean expectedValue = entityIDs2Classification.get(entity);
			BinaryResult expectedAnalysisResult = new BinaryResult(
					analysisType, entity, expectedValue);
			expectedResultActionSpec.addActionComponent(expectedAnalysisResult);
		}
		requestResultPair.addExpectedResultActionSpec(expectedResultActionSpec);
	}
}
