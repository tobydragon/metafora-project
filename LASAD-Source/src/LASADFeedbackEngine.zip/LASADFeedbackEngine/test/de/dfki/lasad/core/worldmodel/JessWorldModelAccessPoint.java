package de.dfki.lasad.core.worldmodel;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import jess.Fact;
import jess.HasLHS;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.admin.EUESessionListEvent;
import de.dfki.lasad.events.eue.session.AgentJoinSessionAnnounceEvent;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.ontology.EUEOntology;

/**
 * 
 * @author Anahuac Valero, Oliver Scheuer
 * 
 */
public class JessWorldModelAccessPoint {

	private Log logger = LogFactory.getLog(JessWorldModelAccessPoint.class);

	private static final EUEOntology TEST_ONTOLOGY = new EUEOntology(
			"TEST_ONTOLOGY");
	private JessModelController jessController = new JessModelController();

	public JessWorldModelAccessPoint() {
		initJessModelController();
	}

	private final void initJessModelController() {
		try {
			jessController.configure(null);
		} catch (ComponentInitException e) {
			logger.error(e.getClass(), e);
		}
	}

	public void initSession(SessionID sessionID, EUEOntology ontology) {
		String srcCompID = JessWorldModelAccessPoint.class.toString();
		EUESessionListEvent sessionListEvent = new EUESessionListEvent(
				srcCompID);
		sessionListEvent.addOntology(sessionID, ontology);
		jessController.executeSessionListEvent(sessionListEvent);

		AgentJoinSessionAnnounceEvent joinSessionAnnounceEvent = new AgentJoinSessionAnnounceEvent(
				sessionID, srcCompID);
		jessController
				.executeAgentJoinSessionAnnounceEvent(joinSessionAnnounceEvent);
	}

	public void executeJessBatch(SessionID sessionID, String jessBatch) {
		try {
			jessController.executeJessBatch(sessionID, jessBatch);
		} catch (Exception e) {
			logger.error("executeJessBatch :" + e.getClass(), e);
		}
	}

	public void registerAnalysisPattern(AnalysisType analysisType,
			String patternSpec) {
		try {
			jessController.registerAnalysisPattern(analysisType, patternSpec);
		} catch (Exception e) {
			logger.error("executeJessBatch :" + e.getClass(), e);
		}
	}

	public Map<AnalysisType, List<AnalysisResult>> getAnalysisResults(SessionID sessionID,
			AnalysisType analysisType) {
		try {
			return jessController.getAnalysisResults(sessionID, analysisType);
		} catch (Exception e) {
			logger.error("executeJessBatch :" + e.getClass(), e);
			return new HashMap<AnalysisType, List<AnalysisResult>>();
		}
	}

	public void pushEventsIntoJessModelController(
			ControllableEUEEventPublisher eventProvider) {
		pushEventsIntoJessModelController(eventProvider, eventProvider
				.getSessionID(), eventProvider.getOntology());
	}

	/**
	 * Uses the provided {@link SessionID} in place of the original
	 * {@link SessionID} of the {@link ControllableEUEEventPublisher}.
	 * 
	 * @param eventProvider
	 * @param sessionID
	 */
	public void pushEventsIntoJessModelController(
			ControllableEUEEventPublisher eventProvider, SessionID sessionID,
			EUEOntology ontology) {
		if (!jessController.doesSessionExist(sessionID)) {
			logger.debug("Initialize new session '" + sessionID.getIdAsString()
					+ "' in Jess Working Memory");
			initSession(sessionID, ontology);
		} else {
			logger
					.debug("Session '"
							+ sessionID.getIdAsString()
							+ "' does already exist in Jess Working Memory. Will use existing session. No need for initialization.");
		}

		Iterator<EUEEvent> eventIter = eventProvider.iterator();
		while (eventIter.hasNext()) {
			EUESessionEvent sessionEvent = (EUESessionEvent) eventIter.next();
			sessionEvent.setSessionID(sessionID);
			if (sessionEvent instanceof UserObjectActionEvent) {
				jessController.executeEUESessionEvent(sessionEvent);
			}
		}
	}

	public void printWorkingMemoryFacts(SessionID sessionID) {
		logger.debug("############### JESS FACTS (session: "
				+ sessionID.getIdAsString() + ") ###############");
		Iterator<Fact> iter = jessController.getWorkingMemoryFacts(sessionID);
		while (iter.hasNext()) {
			Fact fact = iter.next();
			logger.debug(fact.toString());
		}
	}

	public void printWorkingMemoryRules(SessionID sessionID) {
		logger.debug("############### JESS RULES (session: "
				+ sessionID.getIdAsString() + ") ###############");
		Iterator<HasLHS> iter = jessController.getWorkingMemoryRules(sessionID);
		while (iter.hasNext()) {
			HasLHS hasLHS = iter.next();
			logger.debug(hasLHS.toString());
		}
	}

}
