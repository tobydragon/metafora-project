package de.dfki.lasad.modules.action.jess;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.action.RuleBasedActionType;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;
import de.dfki.lasad.models.action.AnalysisMirroringActionSpec;
import de.dfki.lasad.models.analysis.AnalyzableEntity;
import de.dfki.lasad.models.analysis.BinaryResult;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackRequestSpec;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackTypeID;
import de.dfki.lasad.models.eue.objects.EUEObjectID;
import de.dfki.lasad.modules.analysis.graphmodeler.JessGraphModelerDescription;
import de.dfki.lasad.modules.analysisactioncycle.FeedbackRequestExpectedResultPair;
import de.dfki.lasad.modules.analysisactioncycle.TestParameters;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class LARGOGraphGrammarTestParameters implements TestParameters {

	private AnalysisAgentDescription analysisAgentDescription;
	private ActionAgentDescription actionAgentDescription;
	private ControllableEUEEventPublisher eventPublisher;
	private FeedbackRequestExpectedResultPair requestResultPair = new FeedbackRequestExpectedResultPair();
	private AnalysisMirroringActionSpec expectedResultActionSpec = new AnalysisMirroringActionSpec();

	public LARGOGraphGrammarTestParameters(
			ControllableEUEEventPublisher eventPublisher,
			JessFeedbackAgentConfiguration conf) {
		this.eventPublisher = eventPublisher;
		this.analysisAgentDescription = new JessGraphModelerDescription();
		
		this.actionAgentDescription = new JessFeedbackAgentDescription(conf);

		// initialize AnalysisMirroringActionSpec
		requestResultPair.getExpectedResultActionSpecs().add(
				expectedResultActionSpec);
	}

	@Override
	public List<ActionAgentDescription> getActionAgentDescriptions() {
		List<ActionAgentDescription> descriptions = new Vector<ActionAgentDescription>();
		descriptions.add(actionAgentDescription);
		return descriptions;
	}

	@Override
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions() {
		List<AnalysisAgentDescription> analysisAgentDescriptions = new Vector<AnalysisAgentDescription>();
		analysisAgentDescriptions.add(analysisAgentDescription);
		return analysisAgentDescriptions;
	}

	@Override
	public ControllableEUEEventPublisher getInputDataProvider() {
		return eventPublisher;
	}

	@Override
	public FeedbackRequestExpectedResultPair getRequestResultPair() {
		return requestResultPair;
	}

	public void addFeedbackRequest(String actionTypeID) {
		FeedbackTypeID feedbackTypeID = new FeedbackTypeID(
				actionAgentDescription.getComponentID(), actionTypeID, false);
		FeedbackRequestSpec feedbackRequestSpec = new FeedbackRequestSpec(
				feedbackTypeID);
		feedbackRequestSpec.setNumResults(FeedbackRequestSpec.ALL_RESULTS);
		//feedbackRequestSpec.setRequestRawResults(true);

		requestResultPair.setFeedbackRequestSpec(feedbackRequestSpec);
	}

	public void addExpectedResult(String actionTypeID,
			AnalyzableEntity foundEntitity) {
		RuleBasedActionType actionType = new RuleBasedActionType(
				actionAgentDescription.getComponentID(), actionTypeID);
		BinaryResult expectedAnalysisResult = new BinaryResult(actionType,
				foundEntitity, true);
		expectedResultActionSpec.addActionComponent(expectedAnalysisResult);
	}

	public AnalyzableEntity constructEntity(String[] objectIDs) {
		AnalyzableEntity entity = new AnalyzableEntity();
		for (String objectIDString : objectIDs) {
			EUEObjectID objectID = new EUEObjectID(objectIDString);
			entity.addEntityComponent(objectID);
		}
		return entity;
	}
}
