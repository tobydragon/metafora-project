package de.dfki.lasad.core.dataservice.largoxml.dataprovider;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ProviderTesting  extends LargoDataProviderAsahiPetitioner {
	private Log logger = LogFactory.getLog(ProviderTesting.class);
	public static final String testFileName = "testfile7.xml";
	public static final String testFilePath = "test/de/dfki/lasad/core/dataservice/lasad/testfiles/usersessions/";
	String contextPath = "de.dfki.lasad.modules.dataservice.lasad.outws";
	
	
	//public static final String largotestfilePath = "test/de/dfki/lasad/core/dataservice/largoxml/data/";
	

	public ProviderTesting() {
		super();
		initDataService(testFilePath, testFileName);

	}

	public static void main(String[] args) {
		LargoDataProvider largoDataProvider = new ProviderTesting();
		largoDataProvider.printDataToLogger();
	}
}
