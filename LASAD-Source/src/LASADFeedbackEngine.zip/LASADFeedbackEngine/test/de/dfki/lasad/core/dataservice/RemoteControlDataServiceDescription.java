package de.dfki.lasad.core.dataservice;

public class RemoteControlDataServiceDescription extends DataServiceDescription {

	private static final String targetClass = RemoteControlDataService.class
			.getName();

	public RemoteControlDataServiceDescription() {
		super(targetClass, targetClass);
	}
}
