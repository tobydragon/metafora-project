package de.dfki.lasad.core.dataservice.lasad;

import lasad.gwt.client.communication.objects.ActionPackage;

//import de.dfki.lasad.modules.dataservice.lasad.ws.outws.ActionPackage;

public class LASADUserSessionSimulator {

	private MyUnmarshaller apUnmarshaler;

	public LASADUserSessionSimulator(String contextPath, String filePath,
			String fileName) {
		if ((null != contextPath) && (null != filePath) && (null != fileName)) {
			apUnmarshaler = new MyUnmarshaller(contextPath, filePath, fileName);
		}

	}

	public ActionPackage simulateNextUserAction() {
		ActionPackage actionPackage = null;

		actionPackage = (ActionPackage) apUnmarshaler.doUnMarshal(apUnmarshaler
				.readNextAction());
		if (null == actionPackage) {
			System.out.println("Closing File");
			apUnmarshaler.closeFile();
		}

		return actionPackage;
	}
}
