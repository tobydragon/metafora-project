package de.dfki.lasad.core.dataservice.lasad;

import java.io.Serializable;

import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;

public class LASADOutputEventSerializable implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2145738180741875118L;
	UserObjectActionEvent ouputEvent;

	public LASADOutputEventSerializable(UserObjectActionEvent ouputEvent) {
		this.ouputEvent = ouputEvent;
	}

	public UserObjectActionEvent getOuputEvent() {
		return ouputEvent;
	}
	
}
