package de.dfki.lasad.core.dataservice.lasad;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import lasad.gwt.client.communication.objects.ActionPackage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.modules.dataservice.lasad.AccessibleLASADDataServiceRMI;
import de.dfki.lasad.modules.dataservice.lasad.ActionPackageListener;
import de.dfki.lasad.modules.dataservice.lasad.LASADDataServiceConfiguration;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIConfiguration;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIDescription;
import de.dfki.lasad.modules.dataservice.lasad.translators.EventTranslatorLASAD2AF;

public class MockLASADDataService implements ActionPackageListener{
	
	JFrame frame;
	private EventTranslatorLASAD2AF pack2Event = new EventTranslatorLASAD2AF();
	Log logger = LogFactory.getLog(MockLASADDataService.class);
	LASADUserSessionSimulator userSessionSimulator;
	
	// Configuration
	private String username = "dfkiclient";
	private String password = "dfkiclientpw";
	private boolean doDeploy = true;
	private int heartBeatRate = 10;
	private JLabel msgLabel;
	private boolean readAllFilesInDir;
	private String contextPath, filePath, fileName;
	
	private String serverIP = "localhost";
	private int serverPort = 1099;
	private String serverName = "LASAD-1";
	private int serverRegistryPort = 1099;

	private AccessibleLASADDataServiceRMI dataService;
	
	public MockLASADDataService(String contextPath, String filePath, String fileName) {
		this.contextPath = contextPath;
		this.filePath = filePath;
		this.fileName = fileName;
		
		userSessionSimulator = new LASADUserSessionSimulator(contextPath, filePath, fileName);
		initDataServiceRMI();
	}
	
	public MockLASADDataService(String contextPath, String filePath) {
		this.contextPath = contextPath;
		this.filePath = filePath;
		initDataServiceRMI();
	}
	
	public MockLASADDataService(String contextPath, String filePath, String fileName, Boolean initGUI) {
		userSessionSimulator = new LASADUserSessionSimulator(contextPath, filePath, fileName);
		initDataServiceRMI();
		if (initGUI)
			initGUI();
	}
	
	private boolean startTesting(){
		boolean returnVal = false; 
		
		if(null == fileName || (fileName.equals("")))
		{
			readAllFilesInDir = true;
		}
		
		if (readAllFilesInDir){
			File directory = new File(filePath);
			File[] files = directory.listFiles();
			if ( files != null){
				System.out.println("Loading files...");
				for (File file : files) {
					fileName = file.getName();
					if(!fileName.endsWith(".xml")){
						continue;
					}
					System.out.println("About to Marshal " + fileName);
					LASADUserSessionSimulator userSessionSim = new LASADUserSessionSimulator(contextPath, filePath, fileName);
					ActionPackage actionPackage = userSessionSim.simulateNextUserAction();
					
					while(null != actionPackage){
						processActionPackage(actionPackage);
						actionPackage = userSessionSim.simulateNextUserAction();
					}
					System.out.println(fileName + " Marshaled.");
				}
			}
			returnVal = true;
		}
		
		return returnVal;
	}
	
	public boolean simulateNextUserAction(){
		boolean flag = false;
		ActionPackage actionPackage = userSessionSimulator.simulateNextUserAction();
		if(null != actionPackage){
			processActionPackage(actionPackage);
			flag = true;
		}
		return flag;
	}
	
	private void initDataServiceRMI() {
		LASADDataServiceConfiguration configuration = new LASADDataServiceRMIConfiguration(
				username, password, doDeploy, heartBeatRate, 
				serverIP, serverPort, serverName, serverRegistryPort);

		LASADDataServiceRMIDescription description = new LASADDataServiceRMIDescription(
				AccessibleLASADDataServiceRMI.class.getName(), configuration);
		try {
			dataService = (AccessibleLASADDataServiceRMI) description.createInstance();
			dataService.registerForIncomingActionPackages(this);
			dataService.registerForOutgoingActionPackages(this);
			dataService.prepareService();
			dataService.startService();
		} catch (ComponentInitException e) {
			logger.error(e.getClass() + ": " + e.getMessage());
		}
	}

	public void processActionPackage(ActionPackage actionPackage) {
		dataService.processActionPackage(actionPackage);
	}
	
	@Override
	public void onActionPackage(ActionPackage actionPackage, Direction direction) {
//		String actionPackageString = LASADDataServiceWS.actionPackage2String(actionPackage);
//		String actionPackageString = LASADDataServiceWS.actionPackage2StringForTesting(actionPackage);
		if (direction.equals(Direction.OUT)) {
//			outgoingActionPackageDisplay.append(actionPackageString + "\n");
		} else if (direction.equals(Direction.IN)) {
//			incomingActionPackageDisplay.append(actionPackageString + "\n");
			List<EUESessionEvent> events = pack2Event.translate(actionPackage);
			for (EUESessionEvent event : events) {
//				incomingEventsDisplay.append(event + "\n");
			}
		}
	}
		
	
	private void initGUI() {
		frame = new JFrame("MockLASADDataService Test GUI");
		frame.setSize(640, 480);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel content = new JPanel();
		content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
		frame.setContentPane(content);
		
		frame.getContentPane().add(createButton());
		msgLabel = new JLabel("End of file reached.");
		msgLabel.setVisible(false);
		frame.getContentPane().add(msgLabel);

		frame.setVisible(true);
	}
	
	private JPanel createButton(){
		JPanel mapIDsRequestPanel = new JPanel();
		mapIDsRequestPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		JButton mapIDsRequestButton = new JButton("Next ActionPackage");
		mapIDsRequestButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (false == simulateNextUserAction())
				{
					msgLabel.setVisible(true);
					msgLabel.invalidate();
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.exit(1);
				}
			}

		});
		mapIDsRequestPanel.add(mapIDsRequestButton);
		return mapIDsRequestPanel;
	}
	
	
	public static void main(String args[]){
		boolean flag = true;
		boolean initGUI = true;
		
		String contextPath = "de.dfki.lasad.modules.dataservice.lasad.ws.outws";
		String filePath = "test/de/dfki/lasad/core/dataservice/lasad/testfiles/usersessions/";
		String fileName = "test_default.xml";
		
//		MockLASADDataService mockLASADDataService = new MockLASADDataService(contextPath, filePath, fileName, initGUI);
		MockLASADDataService mockLASADDataService = new MockLASADDataService(contextPath, filePath, fileName);
		mockLASADDataService.startTesting();
		
		if (flag){
			while(mockLASADDataService.simulateNextUserAction()){
			}
		}
	}

	

}
