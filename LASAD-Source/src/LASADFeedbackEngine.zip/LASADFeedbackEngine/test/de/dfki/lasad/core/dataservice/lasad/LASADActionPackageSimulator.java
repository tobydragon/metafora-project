/**
 * 
 */
package de.dfki.lasad.core.dataservice.lasad;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.Parameter;

/**
import lasad.ejb.Action;
import lasad.ejb.ActionPackage;
import lasad.ejb.Parameter;
*/

/**
 * @author Anahuac
 *
 */
public class LASADActionPackageSimulator extends ActionPackage {

	/**
	 * 
	 */
	public LASADActionPackageSimulator() {
		super();
	}
	
//	public void addAction(Action action) {
//		getActions().add(action);
//	}
	
	public void addParameter(Parameter parameter) {
		getParameters().add(parameter);
	}

}
