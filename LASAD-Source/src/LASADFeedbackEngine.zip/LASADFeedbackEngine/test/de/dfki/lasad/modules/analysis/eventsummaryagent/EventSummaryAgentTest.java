package de.dfki.lasad.modules.analysis.eventsummaryagent;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.modules.analysis.eventsummaryagent.EventSummaryAgent;
import de.dfki.lasad.modules.analysisactioncycle.TestFramework;

public class EventSummaryAgentTest extends TestFramework{
	
	private Log logger = LogFactory.getLog(EventSummaryAgentTest.class);
	
//	public void testHistoryRecord() {
//		EventSummaryAgentTestParameters params = new EventSummaryAgentTestParameters();
//		setTestParameters(params);
//		startTestAndCreateEvents();
//		EventSummaryAgent myEventSummaryAgent = (EventSummaryAgent) appBuilder.getAnalysisAgents().get(0);
//		
//		logger.debug(myEventSummaryAgent);
//	}
	
	

}
