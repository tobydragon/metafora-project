package de.dfki.lasad.core.worldmodel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.dataservice.largoxml.dataprovider.LargoDataProvider55621;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.models.eue.SessionID;

/**
 * * Allows for manual testing (verifying console output) of the
 * {@link EUESessionEvent}-based update mechanism of class
 * {@link JessModelController}. {@link EUESessionEvent}s are provided by an
 * instance of {@link ControllableEUEEventPublisher}. The result of the model
 * update (i.e., the Jess facts resulting from the model update operations) can
 * be checked on the console ({@link #printWorkingMemoryFacts(SessionID)}).
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessImportLARGOMapTest {

	private static Log logger = LogFactory.getLog(JessImportLARGOMapTest.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JessWorldModelAccessPoint jessAccessPoint = new JessWorldModelAccessPoint();
		ControllableEUEEventPublisher eventProvider = new LargoDataProvider55621();
		jessAccessPoint.pushEventsIntoJessModelController(eventProvider);
		
		jessAccessPoint.printWorkingMemoryFacts(eventProvider.getSessionID());
		jessAccessPoint.printWorkingMemoryRules(eventProvider.getSessionID());
		
	}

}
