package de.dfki.lasad.modules.analysis.deeploop;

import de.dfki.lasad.models.eue.objects.BasicPropertyFactory;
import de.dfki.lasad.modules.analysis.SimplePropertyMappingsConfiguration;
import de.dfki.lasad.modules.analysis.deeploop.graphml.GraphMLVocabulary;

public class Basic2DeepLoopPropMappingConfiguration extends
		DeepLoopAnalysisAgentConfiguration {

	public Basic2DeepLoopPropMappingConfiguration(String[] nodeTypes,
			String linkTypes[]) {
		super();
		SimplePropertyMappingsConfiguration propMappingConf = new SimplePropertyMappingsConfiguration();
		mappingConfiguration = propMappingConf;

		for (String nodeType : nodeTypes) {
			addNodePropMappings(nodeType);
		}
		for (String linkType : linkTypes) {
			addLinkPropMappings(linkType);
		}
	}

	public final void addNodePropMappings(String nodeType) {
		mappingConfiguration.addPropMapping(nodeType,
				BasicPropertyFactory.SHAPE, GraphMLVocabulary.NODE_SHAPE);
		mappingConfiguration.addPropMapping(nodeType,
				BasicPropertyFactory.TITLE, GraphMLVocabulary.NODE_TITLE);
		mappingConfiguration.addPropMapping(nodeType,
				BasicPropertyFactory.TEXT, GraphMLVocabulary.NODE_CONTENT);
		mappingConfiguration.addPropMapping(nodeType,
				BasicPropertyFactory.CREATOR, GraphMLVocabulary.NODE_CREATOR);
		mappingConfiguration.addPropMapping(nodeType,
				BasicPropertyFactory.CREATION_TS,
				GraphMLVocabulary.NODE_CREATIONDATE);
		mappingConfiguration.addPropMapping(nodeType,
				BasicPropertyFactory.FIRST_MODIFIER,
				GraphMLVocabulary.NODE_FIRST_MODIFICATOR);
		mappingConfiguration.addPropMapping(nodeType,
				BasicPropertyFactory.FIRST_MODIFICATION_TS,
				GraphMLVocabulary.NODE_FIRST_MODIFICATIONDATE);
		mappingConfiguration.addPropMapping(nodeType,
				BasicPropertyFactory.LAST_MODIFIER,
				GraphMLVocabulary.NODE_LAST_MODIFICATOR);
		mappingConfiguration.addPropMapping(nodeType,
				BasicPropertyFactory.LAST_MODIFICATION_TS,
				GraphMLVocabulary.NODE_LAST_MODIFICATIONDATE);
	}

	public final void addLinkPropMappings(String linkType) {
		mappingConfiguration.addPropMapping(linkType,
				BasicPropertyFactory.CREATOR, GraphMLVocabulary.LINK_CREATOR);
		mappingConfiguration.addPropMapping(linkType,
				BasicPropertyFactory.CREATION_TS,
				GraphMLVocabulary.LINK_CREATIONDATE);
		mappingConfiguration.addPropMapping(linkType,
				BasicPropertyFactory.LAST_MODIFICATION_TS,
				GraphMLVocabulary.LINK_LAST_MODIFICATIONDATE);
		mappingConfiguration.addPropMapping(linkType,
				BasicPropertyFactory.SHAPE, GraphMLVocabulary.LINK_SHAPE);

	}
}
