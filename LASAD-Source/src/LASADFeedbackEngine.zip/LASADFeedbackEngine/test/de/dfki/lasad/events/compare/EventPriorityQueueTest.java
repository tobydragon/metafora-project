package de.dfki.lasad.events.compare;

import java.util.concurrent.PriorityBlockingQueue;

import junit.framework.TestCase;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.analysis.AnalysisResultEvent;
import de.dfki.lasad.models.eue.SessionID;

public class EventPriorityQueueTest extends TestCase {

	Log logger = LogFactory.getLog(EventPriorityQueueTest.class);

	@Test
	public void testTimeSequence() {
		Event early = createEvent(0, 1);
		Event late = createEvent(0, 2);

		PriorityBlockingQueue<Event> queue = new PriorityBlockingQueue<Event>();

		queue.add(late);
		queue.add(early);

		try {
			Event first = queue.take();
			Event second = queue.take();

			assertEquals(first, early);
			assertEquals(second, late);
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage());
		}

	}

	@Test
	public void testPrioritySequence() {

		int lowPriority = 0;
		int highPriority = 1;

		Event lowPriorityEvent = createEvent(lowPriority, 0);
		Event highPriorityEvent = createEvent(highPriority, 0);

		PriorityBlockingQueue<Event> queue = new PriorityBlockingQueue<Event>();

		queue.add(highPriorityEvent);
		queue.add(lowPriorityEvent);

		try {
			Event first = queue.take();
			Event second = queue.take();

			assertEquals(first, highPriorityEvent);
			assertEquals(second, lowPriorityEvent);
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage());
		}

	}

	private Event createEvent(int priority, long ts) {
		AnalysisResultEvent event = new AnalysisResultEvent("transactionID",
				new SessionID("sessionID"), "srcComponentID",
				"targetComponentID");

		event.setTs(ts);
		event.setEventPriority(priority);
		return event;
	}
}
