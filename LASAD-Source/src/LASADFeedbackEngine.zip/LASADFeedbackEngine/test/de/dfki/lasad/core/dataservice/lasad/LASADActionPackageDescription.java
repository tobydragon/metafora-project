package de.dfki.lasad.core.dataservice.lasad;

import java.util.List;
import java.util.Vector;

public class LASADActionPackageDescription {
	private List<LASADActionDescription> actions;
	
	public LASADActionPackageDescription() {
		super();
		actions = new Vector<LASADActionDescription>();
	}

	public void addAction(LASADActionDescription action) {
		actions.add(action);
	}
	
	public List<LASADActionDescription> getActions() {
		return actions;
	}

	public void setActions(List<LASADActionDescription> actions) {
		this.actions = actions;
	}
	
}
