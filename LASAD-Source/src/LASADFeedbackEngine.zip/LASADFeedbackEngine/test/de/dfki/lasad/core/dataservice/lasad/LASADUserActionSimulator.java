package de.dfki.lasad.core.dataservice.lasad;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.Parameter;


/**
import lasad.ejb.Action;
import lasad.ejb.ActionPackage;
import lasad.ejb.Parameter;
*/

public class LASADUserActionSimulator {
	
	/*****************************************************************/
	/* CREATE ACTIONS */
	/*****************************************************************/
	
	public static ActionPackage createNewAction(LASADActionPackageDescription actionPackageDescription){
		LASADActionPackageSimulator actionPackage = null;
		
		if (null != actionPackageDescription){
			List<LASADActionDescription> actions = actionPackageDescription.getActions();
			if (null != actions){
				actionPackage = new LASADActionPackageSimulator();
				List<Action> actionsList = new Vector<Action>();
				for (int i = 0; i < actions.size(); i++){
					LASADActionDescription actionDescription = actions.get(i);
					String categoryValue = actionDescription.getCategoryValue();
					String commandValue = actionDescription.getCommandValue();
					Map<String, String> nodeParams = actionDescription.getActionParams();
					LASADActionSimulator node = newCategoryCommandAction(categoryValue, commandValue);
					addParameters(node, nodeParams);
					actionsList.add(node);
				}
				actionPackage.getActions().addAll(actionsList);
			}
		}
		
		return actionPackage;
	}
	
	public static Action createNewAction(String categoryValue, String commandValue, Map<String, String> nodeParams){
		LASADActionSimulator action = new LASADActionSimulator();
		action.setCategory(categoryValue);
		action.setCmd(commandValue);
		if (null != nodeParams){
			Iterator<String> keyIterator = nodeParams.keySet().iterator();
			while(keyIterator.hasNext()){
				String name = keyIterator.next();
				String value = nodeParams.get(name);
				Parameter param = new Parameter();
				param.setName(name);
				param.setValue(value);
				action.addParameter(param);
			}
		}
		return action;
	}

	/*****************************************************************/
	/* PARAMETERS */
	/*****************************************************************/
	
	private static boolean addParameter(LASADActionSimulator box, String name, String value){
		boolean flag = false;
		
		if ((null != name) && (null != value)){
			Parameter param = new Parameter();
			param.setName(name);
			param.setValue(value);
			box.addParameter(param);
			flag = true;
		}
		return flag;
	}
	
	private static boolean addParameters(LASADActionSimulator box, Map<String, String> parameters){
		boolean flag = false;
		
		if (null != parameters){
			Iterator<String> keyIterator = parameters.keySet().iterator();
			while(keyIterator.hasNext()){
				String name = keyIterator.next();
				String value = parameters.get(name);
				Parameter param = new Parameter();
				param.setName(name);
				param.setValue(value);
				box.addParameter(param);
			}
			flag = true;
		}
		return flag;
	}
	
	/*****************************************************************/
	/* CATEGORY, COMMAND */
	/*****************************************************************/
	
	private static LASADActionSimulator newCategoryCommandAction(String category, String command){
		LASADActionSimulator action = createAction();
		String actionCategory = category;
		String actionCommand = command;
		
		action.setCategory(actionCategory);
		action.setCmd(actionCommand);
		
		return action;
	}
	
	/*****************************************************************/
	/* ACTION */
	/*****************************************************************/
	
	private static LASADActionSimulator createAction(){
		LASADActionSimulator action = new LASADActionSimulator();
		return action;
	}
	
}
