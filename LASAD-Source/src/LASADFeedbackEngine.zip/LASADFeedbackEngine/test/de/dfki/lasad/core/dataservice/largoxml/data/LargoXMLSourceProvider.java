package de.dfki.lasad.core.dataservice.largoxml.data;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.InputSource;

import de.dfki.lasad.core.dataservice.cf.data.CFInputSourceProvider;
import de.dfki.lasad.util.ResourceOnClasspathHelper;

public class LargoXMLSourceProvider {
	static Log logger = LogFactory.getLog(LargoXMLSourceProvider.class);
	
	public static final String packagePath = "/"
		+ LargoXMLSourceProvider.class.getPackage().getName().replace(".",
				"/");
	public static final String largoXML1 = "55621_1189802223881_asahi_petitioner_parsed.xml";
	public static final String largoXML2 = "60231_1190405523659_asahi_petitioner_parsed.xml";
	public static final String largoXML3 = "68401_1189629326019_asahi_petitioner_parsed.xml";
	public static final String largoXML4 = "69011_1189799173262_asahi_petitioner_parsed.xml";
	public static final String largoXML5 = "69061_1190666548601_asahi_petitioner_parsed.xml";
	public static final String largoXML6 = "81731_1190233739307_asahi_petitioner_parsed.xml";
	public static final String largoXML7 = "91281_1189456630757_asahi_petitioner_parsed.xml";
	public static final String largoXML8 = "96121_1190234862736_asahi_petitioner_parsed.xml";
	public static final String largoXML9 = "96701_1189629347862_asahi_petitioner_parsed.xml";
	
	public static final String largotestfilePath = "test/de/dfki/lasad/core/dataservice/largoxml/data/";
	
	public static final HashMap<Integer, String> largoXMLFiles = 
        new HashMap<Integer, String>() {{
        	put(1, largoXML1);
    		put(2, largoXML2);
    		put(3, largoXML3);
    		put(4, largoXML4);
    		put(5, largoXML5);
    		put(6, largoXML6);
    		put(7, largoXML7);
    		put(8, largoXML8);
    		put(9, largoXML9);
	}};
	
//	private HashMap<Integer, String> largoXMLFiles = new HashMap<Integer, String>();
//	static {
//		largoXMLFiles.put(1, largoXML1);
//		largoXMLFiles.put(2, largoXML2);
//		largoXMLFiles.put(3, largoXML3);
//		largoXMLFiles.put(4, largoXML4);
//		largoXMLFiles.put(5, largoXML5);
//		largoXMLFiles.put(6, largoXML6);
//		largoXMLFiles.put(7, largoXML7);
//		largoXMLFiles.put(8, largoXML8);
//		largoXMLFiles.put(9, largoXML9);
//	}
	
	public static String getFileName(int largoXMLNumber) {
		return largoXMLFiles.get(largoXMLNumber);
	}
	
	public static String getAbsoluteFilePath(int largoXMLNumber) {
		String fileName = largoXMLFiles.get(largoXMLNumber);
		if (null == fileName){
			return null;
		}
		else{
			return getAbsoluteFilepath(fileName);
		}
	}
	
	public static InputSource getLargoXMLDataSource(int largoXMLNumber) {
		String fileName = largoXMLFiles.get(largoXMLNumber);
		if (null == fileName){
			return null;
		}
		else{
			String mockDataPath = getClasspathPath(fileName);
			InputSource inputSource = getInputSource(mockDataPath);
			return inputSource;
		}
	}

//	public static InputSource getMockDataSource() {
//		String mockDataPath = getClasspathPath(mockDataFile);
//		InputSource inputSource = getInputSource(mockDataPath);
//		return inputSource;
//	}

	private static String getAbsoluteFilepath(String localFilename) {
		String classpathPath = getClasspathPath(localFilename);
		String absoluteFilePath = ResourceOnClasspathHelper
				.getAbsoluteFilepathFromResourceOnClasspath(
						LargoXMLSourceProvider.class, classpathPath);
		return absoluteFilePath;
	}

	private static String getClasspathPath(String localFilename) {
		String pathRelativeToClasspath = packagePath + "/" + localFilename;
		return pathRelativeToClasspath;
	}

	private static InputSource getInputSource(String classpathPath) {
		try {
			URL url = ResourceOnClasspathHelper.getURLFromResourceOnClasspath(
					LargoXMLSourceProvider.class, classpathPath);
			InputStream cfStream = url.openStream();
			InputSource inputSource = new InputSource(cfStream);
			return inputSource;
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
			return null;
		}
	}
}
