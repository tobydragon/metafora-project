package de.dfki.lasad.core.dataservice.largoxml.dataprovider;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.dataservice.largoxml.data.LargoXMLSourceProvider;

public class LargoDataProvider69011 extends LargoDataProviderAsahiPetitioner {

	private Log logger = LogFactory.getLog(LargoDataProvider69011.class);

	public LargoDataProvider69011() {
		super();
		initDataService(LargoXMLSourceProvider.largotestfilePath,
				LargoXMLSourceProvider.largoXML1);

	}

	public static void main(String[] args) {
		LargoDataProvider largoDataProvider = new LargoDataProvider69011();
		largoDataProvider.printDataToLogger();
	}
}
