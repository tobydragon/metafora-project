package de.dfki.lasad.modules.analysisactioncycle;

import java.util.List;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;

/**
 * Parametrization of test:
 * <ul>
 * <li>Input data to be analyzed ({@link #getInputDataProvider()})</li>
 * <li>Data analyzers ({@link #getAnalysisAgentDescriptions()})</li>
 * <li>Action generators ({@link #getActionAgentDescriptions()})</li>
 * <li>Pairing of a feedback request and corresponding expected results (
 * {@link #getRequestResultPair()})</li>
 * </ul>
 * 
 * @author Oliver Scheuer
 * 
 */
public interface TestParameters {

	public ControllableEUEEventPublisher getInputDataProvider();

	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions();

	public List<ActionAgentDescription> getActionAgentDescriptions();

	public FeedbackRequestExpectedResultPair getRequestResultPair();

}
