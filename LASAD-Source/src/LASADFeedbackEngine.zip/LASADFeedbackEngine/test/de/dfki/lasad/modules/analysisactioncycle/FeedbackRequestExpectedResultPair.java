package de.dfki.lasad.modules.analysisactioncycle;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.models.action.ActionSpec;
import de.dfki.lasad.models.eue.feedbackrequest.FeedbackRequestSpec;

/**
 * Data structure representing a feedback request and the corresponding set of
 * expected results.
 * 
 * @author Oliver Scheuer
 * 
 */
public class FeedbackRequestExpectedResultPair {

	private FeedbackRequestSpec feedbackRequestSpec;
	private Vector<ActionSpec> expectedResultActionSpecs = new Vector<ActionSpec>();

	public void setFeedbackRequestSpec(FeedbackRequestSpec feedbackRequestSpec) {
		this.feedbackRequestSpec = feedbackRequestSpec;
	}

	public FeedbackRequestSpec getFeedbackRequestSpec() {
		return feedbackRequestSpec;
	}

	public void addExpectedResultActionSpec(
			ActionSpec expectedResultActionSpec) {
		expectedResultActionSpecs.add(expectedResultActionSpec);
	}

	public List<ActionSpec> getExpectedResultActionSpecs() {
		return expectedResultActionSpecs;
	}

}
