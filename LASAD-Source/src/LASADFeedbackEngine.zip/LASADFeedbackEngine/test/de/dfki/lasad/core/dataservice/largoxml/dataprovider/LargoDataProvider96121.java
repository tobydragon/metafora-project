package de.dfki.lasad.core.dataservice.largoxml.dataprovider;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.dataservice.largoxml.data.LargoXMLSourceProvider;

public class LargoDataProvider96121 extends LargoDataProviderAsahiPetitioner {

	private Log logger = LogFactory.getLog(LargoDataProvider96121.class);

	public LargoDataProvider96121() {
		super();
		initDataService(LargoXMLSourceProvider.largotestfilePath,
				LargoXMLSourceProvider.largoXML1);
	}

	public static void main(String[] args) {
		LargoDataProvider largoDataProvider = new LargoDataProvider96121();
		largoDataProvider.printDataToLogger();
	}
}
