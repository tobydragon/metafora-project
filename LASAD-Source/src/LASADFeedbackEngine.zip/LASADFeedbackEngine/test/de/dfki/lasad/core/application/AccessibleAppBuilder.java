package de.dfki.lasad.core.application;

import java.util.List;

import de.dfki.lasad.core.action.IActionAgent;
import de.dfki.lasad.core.action.IActionController;
import de.dfki.lasad.core.analysis.IAnalysisAgent;
import de.dfki.lasad.core.analysis.IAnalysisController;
import de.dfki.lasad.core.dataservice.IDataService;

/**
 * Only for testing purposes: Internal components accessible.
 * 
 * @author Oliver Scheuer
 * 
 */
public class AccessibleAppBuilder extends AppBuilder {

	public AccessibleAppBuilder(IConfiguration configuration) {
		super(configuration);
	}

	public IDataService getDataService() {
		return dataService;
	}

	public void setDataService(IDataService dataService) {
		this.dataService = dataService;
	}

	public IAnalysisController getAnalysisController() {
		return analysisController;
	}

	public void setAnalysisController(IAnalysisController analysisController) {
		this.analysisController = analysisController;
	}

	public IActionController getActionController() {
		return actionController;
	}

	public void setActionController(IActionController actionController) {
		this.actionController = actionController;
	}

	public List<IAnalysisAgent> getAnalysisAgents() {
		return analysisAgents;
	}

	public void setAnalysisAgents(List<IAnalysisAgent> analysisAgents) {
		this.analysisAgents = analysisAgents;
	}

	public List<IActionAgent> getActionAgents() {
		return actionAgents;
	}

	public void setActionAgents(List<IActionAgent> actionAgents) {
		this.actionAgents = actionAgents;
	}

}
