/**
 * 
 */
package de.dfki.lasad.core.dataservice.lasad;

import java.util.List;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.Parameter;


//import lasad.ejb.Action;
//import lasad.ejb.Parameter;

/**
 * @author Anahuac
 *
 */
public class LASADActionSimulator extends Action {
	/**
	 * 
	 */
	public LASADActionSimulator() {
		super();
	}
	
	public void setParameters(List<Parameter> parameters) {
		//this.parameters = parameters;
	}
	
	public void addParameter(Parameter parameter) {
		getParameters().add(parameter);
	}
	
	

}
