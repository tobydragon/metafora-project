package de.dfki.lasad.core.dataservice.cf.parser;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.InputSource;

import de.dfki.lasad.core.dataservice.cf.data.CFInputSourceProvider;
import de.dfki.lasad.events.Event;
import de.dfki.lasad.events.eue.EUEEvent;
import de.dfki.lasad.events.eue.EUEEventListener;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.objects.EUEObject;
import de.dfki.lasad.models.eue.objects.ObjectProperty;

public class CFParserTest implements EUEEventListener {

	Log logger = LogFactory.getLog(CFParserTest.class);

	InputSource cfToParse;
	SessionID sessionID = new SessionID("not set");

	List<EUESessionEvent> eventsFromParse = new Vector<EUESessionEvent>();

	public static void main(String[] args) {
		CFParserTest parserTest = new CFParserTest();
		parserTest.testMockDataset();
		//parserTest.testHUJIDataset();
		//parserTest.testUKDataset();
	}
	
	@Override
	public void onEUEEvent(EUEEvent eueEvent) {
		//eventsFromParse.add(eueEvent);
		logger.info(eueEvent);
	}

	public void testMockDataset() {
		try {
			this.cfToParse = CFInputSourceProvider.getMockDataSource();
			sessionID = new SessionID(CFInputSourceProvider.mockDataFile);
			exerciseParse();
			//printEventsParsed();

		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}

	public void testHUJIDataset() {
		try {
			this.cfToParse = CFInputSourceProvider.getHUJIDataSource();
			sessionID = new SessionID(CFInputSourceProvider.hujiDataFile);
			exerciseParse();
			//printEventsParsed();
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}

	public void testUKDataset() {
		try {
			this.cfToParse = CFInputSourceProvider.getUKDataSource();
			sessionID = new SessionID(CFInputSourceProvider.ukDataFile);
			exerciseParse();
			//printEventsParsed();
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}

	private void exerciseParse() {
		try {
			CFParser parser = new CFParser(1000);
			parser.subscribe(this);
			parser.parse(cfToParse, sessionID);
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}

	private void printEventsParsed() {
		int i = 1;
		for (Event e : eventsFromParse) {
			logger.info(i + ") " + e.toString());
			++i;
		}
	}

	// Remove some props we do not want to see
	private void filterObjectProps(EUEObject o) {

		Map<String, ObjectProperty> currentProps = o.getProps();
		currentProps.remove("sourcetype");
		currentProps.remove("targettype");
		currentProps.remove("name");
		currentProps.remove("layer");
		currentProps.remove("active");
		currentProps.remove("bordercolor");
		currentProps.remove("borderwidth");
		currentProps.remove("color");
		currentProps.remove("textcolor");
		currentProps.remove("linestyle");
		currentProps.remove("sourcestyle");
		currentProps.remove("targetstyle");
	}

	private void printInputSource() {
		try {
			if (cfToParse == null) {
				logger.info("InputSource is null");
				return;
			}

			// Try character stream
			Reader r = cfToParse.getCharacterStream();
			if (r == null) {
				// Try byte stream
				InputStream stream = cfToParse.getByteStream();
				if (stream != null) {
					r = new InputStreamReader(stream);
				}
			}
			if (r == null) {
				// Output system id
				logger.info("No byte or character stream, system Id: "
						+ cfToParse.getSystemId());
				return;
			}
			BufferedReader bufReader = new BufferedReader(r);
			StringBuffer buf = new StringBuffer();
			String line;
			while ((line = bufReader.readLine()) != null) {
				buf.append(line).append("\n");
			}
			System.out.println(buf.toString());
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}
}
