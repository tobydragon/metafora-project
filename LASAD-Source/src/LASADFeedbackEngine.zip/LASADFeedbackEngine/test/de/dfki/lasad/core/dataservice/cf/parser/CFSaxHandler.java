package de.dfki.lasad.core.dataservice.cf.parser;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import de.dfki.lasad.core.dataservice.cf.parser.preamble.CFPreamble;
import de.dfki.lasad.core.dataservice.cf.parser.preamble.ObjectDef;
import de.dfki.lasad.core.dataservice.cf.parser.preamble.UserDef;
import de.dfki.lasad.events.eue.session.EUEEventID;
import de.dfki.lasad.events.eue.session.objectaction.UserCreateObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserDeleteObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserModifyObjectEvent;
import de.dfki.lasad.events.eue.session.objectaction.UserObjectActionEvent;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.models.eue.UserID;
import de.dfki.lasad.models.eue.objects.BasicPropertyFactory;
import de.dfki.lasad.models.eue.objects.EUEObject;
import de.dfki.lasad.models.eue.objects.EUEObjectID;
import de.dfki.lasad.models.eue.objects.EmptyID;
import de.dfki.lasad.models.eue.objects.NonSupportedPropertyRequestedException;
import de.dfki.lasad.models.eue.objects.SimpleProperty;
import de.dfki.lasad.models.eue.objects.graph.Link;
import de.dfki.lasad.models.eue.objects.graph.Node;

public class CFSaxHandler extends DefaultHandler {

	Log logger = LogFactory.getLog(CFSaxHandler.class);

	private String componentID = CFSaxHandler.class.getName();

	private CF2AFPropertyMapper propMapper = new CF2AFPropertyMapper();

	private boolean inObjectDefElem = false;
	private boolean inObjectElem = false;
	private boolean inActionElem = false;

	private CFPreamble currentPreamble;
	private UserDef currentUserDef;
	private ObjectDef currentObjectDef;

	private long currentTs;
	private UserObjectActionEvent currentEvent;

	private EUEObject currentObject;

	private String currentUserId;
	private Map<String, String> currentProps;

	private CFParser cfparser;

	// context of current parse
	private SessionID sessionID;
	private int eventCounter = 0;

	// controlling parse speed
	private long millisDelay = 0;

	public CFSaxHandler(CFParser cfparser, long millisDelay) {
		this.cfparser = cfparser;
		this.millisDelay = millisDelay;
	}

	public CFSaxHandler(CFParser cfparser) {
		this.cfparser = cfparser;
	}

	public void prepareNewParse(SessionID sessionID) {
		this.sessionID = sessionID;
		eventCounter = 0;
	}

	@Override
	public void startElement(String uri, String localName, String name,
			Attributes attributes) throws SAXException {

		startElementsPreamble(uri, localName, name, attributes);
		startElementsActions(uri, localName, name, attributes);
		startElementsUser(uri, localName, name, attributes);
		startElementsObject(uri, localName, name, attributes);
		startElementsProperties(uri, localName, name, attributes);
	}

	private void startElementsPreamble(String uri, String localName,
			String name, Attributes attributes) throws SAXException {

		if ("preamble".equals(localName)) {
			currentPreamble = new CFPreamble();
		}

		if ("user_def".equals(localName)) {
			currentUserDef = new UserDef();
			currentUserDef.id = attributes.getValue("id");
			currentUserDef.firstname = attributes.getValue("firstname");
			currentUserDef.role = attributes.getValue("role");
		}

		if ("object_def".equals(localName)) {
			inObjectDefElem = true;
			currentProps = new HashMap<String, String>();
			currentObjectDef = new ObjectDef();
			currentObjectDef.id = attributes.getValue("id");
			currentObjectDef.type = attributes.getValue("type");
		}
	}

	private void startElementsActions(String uri, String localName,
			String name, Attributes attributes) throws SAXException {
		if ("action".equals(localName)) {
			inActionElem = true;
			currentTs = new Long(attributes.getValue("time"));
			// creation deferred until type is known (-> actiontype)
		}

		if ("actiontype".equals(localName)) {
			String classification = attributes.getValue("classification");

			EUEEventID eventID = new EUEEventID(String.valueOf(eventCounter));
			++eventCounter;

			if ("create".equals(classification)) {
				currentEvent = new UserCreateObjectEvent(sessionID, eventID,
						componentID);
			} else if ("delete".equals(classification)) {
				currentEvent = new UserDeleteObjectEvent(sessionID, eventID,
						componentID);
			} else if ("modify".equals(classification)) {
				currentEvent = new UserModifyObjectEvent(sessionID, eventID,
						componentID);
			} else {

			}
			currentEvent.setTs(currentTs);
		}
	}

	private void startElementsUser(String uri, String localName, String name,
			Attributes attributes) throws SAXException {
		if ("user".equals(localName)) {
			currentUserId = attributes.getValue("id");
		}
	}

	private void startElementsObject(String uri, String localName, String name,
			Attributes attributes) throws SAXException {
		if ("object".equals(localName)) {
			inObjectElem = true;
			currentProps = new HashMap<String, String>();

			String currentObjectTypeId = attributes.getValue("type");

			if (!currentPreamble.objects.containsKey(currentObjectTypeId)) {
				throw new ParsingCFException("Object type id'"
						+ currentObjectTypeId + "' not defined in preamble");
			}
			ObjectDef objectDef = currentPreamble.objects
					.get(currentObjectTypeId);

			// currentProps.putAll(objectDef.props);

			// object shapes == type ids
			currentProps.put(BasicPropertyFactory.SHAPE, currentObjectTypeId);

			if (objectDef.props.containsKey("name")) {
				String ontologyElem = objectDef.props.get("name");
				currentProps.put(BasicPropertyFactory.ONTOLOGY_ELEMENT,
						ontologyElem);
			}

			if ("link".equals(objectDef.type)) {
				Link link = new Link();
				currentObject = link;

			} else if ("vertex".equals(objectDef.type)) {
				Node node = new Node();
				// all nodes are root elements
				node.setParentID(new EmptyID());
				currentObject = node;

			} else {
				throw new ParsingCFException("Unknown object type: "
						+ objectDef.type);
			}
			EUEObjectID id = new EUEObjectID(attributes.getValue("id"));
			currentObject.setID(id);
		}
	}

	private void startElementsProperties(String uri, String localName,
			String name, Attributes attributes) throws SAXException {
		if ("property".equals(localName)) {
			String propName = attributes.getValue("name");
			String propValue = attributes.getValue("value");
			currentProps.put(propName, propValue);
		}

	}

	@Override
	public void endElement(String uri, String localName, String name)
			throws SAXException {
		if ("user_def".equals(localName)) {
			currentPreamble.users.put(currentUserDef.id, currentUserDef);
			currentUserDef = null;
		}
		if ("object_def".equals(localName)) {
			inObjectDefElem = false;
			currentPreamble.objects.put(currentObjectDef.id, currentObjectDef);
			currentProps = null;
			currentObjectDef = null;
		}

		if ("action".equals(localName)) {
			inActionElem = false;
			
			// For testing purposes we use the real name not the id
			//currentEvent.setUserID(new UserID(currentUserId));
			UserDef userDef = currentPreamble.users.get(currentUserId);
			currentEvent.setUserID(new UserID(userDef.firstname));
			
			cfparser.onEUEEvent(currentEvent);
			currentUserId = null;
			currentEvent = null;
			currentTs = -1;
			pause();
		}
		if ("object".equals(localName)) {
			inObjectElem = false;
			currentProps = null;
			if (inActionElem) {
				List<EUEObject> objectList = new LinkedList<EUEObject>();
				objectList.add(currentObject);
				currentEvent.setEueObjectList(objectList);
			}
			currentObject = null;
		}
		if ("properties".equals(localName)) {
			if (inObjectDefElem) {
				currentObjectDef.props.putAll(currentProps);
			}
			if (inObjectElem) {
				String value;
				
				
				
				for (String oldPropName : currentProps.keySet()) {
					value = currentProps.get(oldPropName);
					try {
						SimpleProperty prop = propMapper.createSimpleProp(
								oldPropName, value);
						String ontologyElem = currentProps.get(BasicPropertyFactory.ONTOLOGY_ELEMENT);
						if(ontologyElem != null){
							currentObject.setType(ontologyElem);
						}
						if(BasicPropertyFactory.ONTOLOGY_ELEMENT.equals(prop.getName())){
							// special property: ontology type
							currentObject.setType(prop.getValueAsString());
						} else{
						currentObject.addProperty(prop);
						}
						
					} catch (NonSupportedPropertyRequestedException e) {
						// ignore unsupported properties
						logger.warn(e.getMessage());
					}
				}
				if (currentObject instanceof Link) {
					Link currentLink = (Link) currentObject;
					String sourceId = currentProps.remove("sourceid");
					String targetId = currentProps.remove("targetid");
					currentLink.addSource(new EUEObjectID(sourceId));
					currentLink.addTarget(new EUEObjectID(targetId));
				}
				
				
			}
			currentProps = null;
		}
	}

	private void pause() {
		try {
			Thread.sleep(millisDelay);
		} catch (Exception ex) {
			logger.error(ex.getClass() + ": " + ex.getMessage());
		}
	}
}
