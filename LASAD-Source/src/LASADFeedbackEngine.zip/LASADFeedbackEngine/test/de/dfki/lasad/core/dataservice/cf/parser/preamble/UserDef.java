package de.dfki.lasad.core.dataservice.cf.parser.preamble;

public class UserDef {

	public String id;
	public String firstname;
	public String role;
}
