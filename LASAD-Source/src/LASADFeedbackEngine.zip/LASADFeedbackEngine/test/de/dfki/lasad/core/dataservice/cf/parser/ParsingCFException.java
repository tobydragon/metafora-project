package de.dfki.lasad.core.dataservice.cf.parser;

public class ParsingCFException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ParsingCFException(Throwable t) {
		super(t);
	}

	public ParsingCFException(String message) {
		super(message);
	}

	public ParsingCFException(String message, Throwable t) {
		super(message, t);
	}
}
