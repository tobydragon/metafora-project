package de.dfki.lasad.core.dataservice.largoxml.dataprovider;

import de.dfki.lasad.modules.dataservice.lasad.ActionPackageListener;


public interface ActionPackagePublisher {
	public void subscribe(ActionPackageListener listener);
}
