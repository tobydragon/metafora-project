package de.dfki.lasad.modules.analysisactioncycle;

import java.util.List;
import java.util.Vector;

import de.dfki.lasad.core.action.ActionAgentDescription;
import de.dfki.lasad.core.analysis.AnalysisAgentDescription;
import de.dfki.lasad.core.application.AbstractAppConfiguration;
import de.dfki.lasad.core.dataservice.DataServiceDescription;
import de.dfki.lasad.core.dataservice.RemoteControlDataServiceDescription;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class TestConfiguration extends AbstractAppConfiguration {

	private DataServiceDescription dataServiceDescription = new RemoteControlDataServiceDescription();

	private List<AnalysisAgentDescription> analysisAgentDescriptions = new Vector<AnalysisAgentDescription>();
	private List<ActionAgentDescription> actionAgentDescriptions = new Vector<ActionAgentDescription>();

	public TestConfiguration() {
		super();
		
	}

	public void setAnalysisAgentDesciptions(
			List<AnalysisAgentDescription> descriptions) {
		analysisAgentDescriptions = descriptions;
	}

	public void setActionAgentDesciptions(
			List<ActionAgentDescription> descriptions) {
		actionAgentDescriptions = descriptions;
	}

	@Override
	public DataServiceDescription getDataServiceDescription() {
		return dataServiceDescription;
	}

	@Override
	public List<AnalysisAgentDescription> getAnalysisAgentDescriptions() {
		return analysisAgentDescriptions;
	}

	@Override
	public List<ActionAgentDescription> getActionAgentDescriptions() {
		return actionAgentDescriptions;
	}
}
