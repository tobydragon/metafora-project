package de.dfki.lasad.modules.dataservice.lasad;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.ComponentInitException;
import de.dfki.lasad.core.dataservice.lasad.MyMarshaller;
import de.dfki.lasad.events.eue.session.EUESessionEvent;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMI;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIConfiguration;
import de.dfki.lasad.modules.dataservice.lasad.rmi.LASADDataServiceRMIDescription;
import de.dfki.lasad.modules.dataservice.lasad.translators.EventTranslatorLASAD2AF;


/**
 * 
 * @author Oliver Scheuer, Frank Loll
 * 
 */
public class LASADDataServiceGUI extends JFrame implements
		ActionPackageListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Log logger = LogFactory.getLog(LASADDataServiceGUI.class);

	private AccessibleLASADDataServiceRMI dataService;
	private ActionPackageFactory actionPackageFactory;
	private EventTranslatorLASAD2AF pack2Event = new EventTranslatorLASAD2AF();

	private MyMarshaller myMarshaller;

	private JTextArea incomingActionPackageDisplay;
	private JTextArea incomingEventsDisplay;
	private JTextArea outgoingActionPackageDisplay;

	private String currentMapID = null;

	private static final String CREATE_OUT_PACKAGE_PANEL = "OUT-PACKAGES";
	private static final String CREATE_IN_PACKAGE_PANEL = "IN-PACKAGES";
	private static final String CREATE_IN_EVENT_PANEL = "IN-EVENT";

	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new LASADDataServiceGUI();
			}
		});
	}

	public LASADDataServiceGUI() {
		initGUI();
		initDataService();
	}

	private void initDataService() {
		LASADDataServiceRMIConfiguration configuration = LASADDataServiceRMIConfiguration
				.readDefaultConfig();

		LASADDataServiceRMIDescription description = new LASADDataServiceRMIDescription(
				AccessibleLASADDataServiceRMI.class.getName(), configuration);
		try {
			dataService = (AccessibleLASADDataServiceRMI) description
					.createInstance();
			dataService.registerForIncomingActionPackages(this);
			dataService.registerForOutgoingActionPackages(this);
			dataService.prepareService();
			dataService.startService();
			actionPackageFactory = dataService.getActionPackageFactory();
		} catch (ComponentInitException e) {
			logger.error(e.getClass() + ": " + e.getMessage());
			displayErrorMessage(e.getClass().getSimpleName(), e.getMessage());
		}
	}

	private void initGUI() {
		setTitle("LASADDataServiceWS Test GUI");
		setSize(1200, 800);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		JPanel content = new JPanel();
		content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
		setContentPane(content);

		getContentPane().add(createMapIDsRequestPanel());
		getContentPane().add(createJoinMapPanel());
		getContentPane().add(createSendFeedbackMessagePanel());
		getContentPane().add(createSaveActionPackagesPanel());
		getContentPane().add(createAnnounceServicePanel());
		getContentPane().add(
				createPackageDisplayPanel(CREATE_OUT_PACKAGE_PANEL));
		getContentPane()
				.add(createPackageDisplayPanel(CREATE_IN_PACKAGE_PANEL));
		getContentPane().add(createPackageDisplayPanel(CREATE_IN_EVENT_PANEL));

		setVisible(true);
	}

	private JPanel createMapIDsRequestPanel() {
		JPanel mapIDsRequestPanel = new JPanel();
		mapIDsRequestPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		JButton mapIDsRequestButton = new JButton("Request MapIDs");
		mapIDsRequestButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				dataService.getMapInfosFromRemoteServer();
			}

		});
		mapIDsRequestPanel.add(mapIDsRequestButton);
		return mapIDsRequestPanel;
	}

	private JPanel createJoinMapPanel() {
		JPanel joinPanel = new JPanel();
		joinPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		final JTextField mapIDInputField = new JTextField(10);

		JButton joinButton = new JButton("Join Map (enter mapID)");
		joinButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				String mapID = mapIDInputField.getText();
				dataService.joinMapAtRemoteServer(mapID);
				currentMapID = mapID;
			}
		});

		joinPanel.add(mapIDInputField);
		joinPanel.add(joinButton);
		return joinPanel;
	}

	private JPanel createPackageDisplayPanel(String command) {
		JPanel packageDisplayPanel = new JPanel();
		BoxLayout layout = new BoxLayout(packageDisplayPanel, BoxLayout.Y_AXIS);
		packageDisplayPanel.setLayout(layout);
		JTextArea textArea = new JTextArea(1200, 350);
		JScrollPane scrollPane = new JScrollPane(textArea);
		textArea.setEditable(false);
		JLabel label;
		if (CREATE_OUT_PACKAGE_PANEL.equals(command)) {
			outgoingActionPackageDisplay = textArea;
			label = new JLabel("Outgoing ActionPackages");
		} else if (CREATE_IN_PACKAGE_PANEL.equals(command)) {
			incomingActionPackageDisplay = textArea;
			label = new JLabel("Incoming ActionPackages");

		} else {
			// assume {@link CREATE_IN_EVENT_PANEL}
			incomingEventsDisplay = textArea;
			label = new JLabel("Incoming Events (ActionPackage translations)");
		}

		packageDisplayPanel.add(label);
		packageDisplayPanel.add(scrollPane);
		return packageDisplayPanel;
	}

	private JPanel createAnnounceServicePanel() {
		JPanel announceServicePanel = new JPanel();
		announceServicePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		final JLabel agentIDLabel = new JLabel("Service Providing Agent: ");
		final JTextField agentIDInputField = new JTextField(10);
		final JLabel serviceIDLabel = new JLabel("Service ID: ");
		final JTextField serviceIDInputField = new JTextField(10);
		final JLabel isAnalysisAgentLabel = new JLabel(
				"Is AnalysisAgent (and not FeedbackAgent)?: ");
		final JCheckBox isAnalysisAgentCheckBox = new JCheckBox();

		JButton sendButton = new JButton("Send Message");
		sendButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				String agentID = agentIDInputField.getText();
				String serviceID = serviceIDInputField.getText();
				boolean isAnalysisAgent = isAnalysisAgentCheckBox.isSelected();

				dataService.announceServiceToRemoteServer(currentMapID, agentID,
						serviceID, isAnalysisAgent);
			}
		});

		announceServicePanel.add(agentIDLabel);
		announceServicePanel.add(agentIDInputField);
		announceServicePanel.add(serviceIDLabel);
		announceServicePanel.add(serviceIDInputField);
		announceServicePanel.add(isAnalysisAgentLabel);
		announceServicePanel.add(isAnalysisAgentCheckBox);

		announceServicePanel.add(sendButton);
		return announceServicePanel;
	}

	private JPanel createSendFeedbackMessagePanel() {
		JPanel sendFeedbackMessagePanel = new JPanel();
		sendFeedbackMessagePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		final JLabel objectIDLabel = new JLabel(
				"Object IDs (separated by blanks): ");
		final JTextField objectIDInputField = new JTextField(10);
		final JLabel messageLabel = new JLabel("Message: ");
		final JTextField messageInputField = new JTextField(10);

		JButton sendButton = new JButton("Send Message");
		sendButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				String objectIDsAsText = objectIDInputField.getText();
				StringTokenizer tokenizer = new StringTokenizer(objectIDsAsText);

				List<String> objectIDs = new Vector<String>();
				while (tokenizer.hasMoreTokens()) {
					String id = tokenizer.nextToken();
					objectIDs.add(id);
				}
				String message = messageInputField.getText();
				String longMessage = "More detailed feedback messages can be displayed HERE!";
				String recipientID = ""; // all

				Action outAction = actionPackageFactory.createFeedbackMessage(
						currentMapID, recipientID, message, longMessage,
						objectIDs, new HashMap<String, String>());
				List<Action> actions = new Vector<Action>();
				actions.add(outAction);
				ActionPackage outPackage = actionPackageFactory
						.createActionPackage(actions);

				dataService.sendActionPackage(outPackage);
			}
		});

		sendFeedbackMessagePanel.add(objectIDLabel);
		sendFeedbackMessagePanel.add(objectIDInputField);
		sendFeedbackMessagePanel.add(messageLabel);
		sendFeedbackMessagePanel.add(messageInputField);

		sendFeedbackMessagePanel.add(sendButton);
		return sendFeedbackMessagePanel;
	}

	private JPanel createSaveActionPackagesPanel() {
		JPanel saveActionPackagesPanel = new JPanel();
		saveActionPackagesPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		final JLabel fileNameLabel = new JLabel("File Name: ");
		final JTextField fileNameInputField = new JTextField(30);

		JButton startRecButton = new JButton("Start Recording");
		JButton endRecButton = new JButton("End Recording");

		startRecButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String contextPath = "de.dfki.lasad.modules.dataservice.lasad.outws";
				// String filePath =
				// "test/de/dfki/lasad/core/dataservice/lasad/testfiles/usersessions/";
				String filePath = null;
				String fileName = fileNameInputField.getText();
				if (!fileName.endsWith(".xml")) {
					fileName += ".xml";
				}
				synchronized (lock1) {
					myMarshaller = new MyMarshaller(contextPath, filePath,
							fileName);
				}
			}
		});

		endRecButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				synchronized (lock1) {
					if (null != myMarshaller) {
						myMarshaller.closeFile();
						myMarshaller = null;
					}
				}
				fileNameInputField.setText("");
			}
		});

		saveActionPackagesPanel.add(fileNameLabel);
		saveActionPackagesPanel.add(fileNameInputField);
		saveActionPackagesPanel.add(startRecButton);
		saveActionPackagesPanel.add(endRecButton);

		return saveActionPackagesPanel;
	}

	private Object lock1 = new Object();

	@Override
	public void onActionPackage(ActionPackage actionPackage, Direction direction) {
		// String actionPackageString = LASADDataServiceWS
		// .actionPackage2String(actionPackage);
		String actionPackageString = LASADDataServiceRMI
				.actionPackage2StringForTesting(actionPackage);

		synchronized (lock1) {
			if (null != myMarshaller) {
				// myMarshaller.writeToFile(myMarshaller.doMarshal(actionPackage));
				myMarshaller.doMarshal(actionPackage);
			}
		}

		if (direction.equals(Direction.OUT)) {
			outgoingActionPackageDisplay.append(actionPackageString + "\n");
		} else if (direction.equals(Direction.IN)) {
			incomingActionPackageDisplay.append(actionPackageString + "\n");
			List<EUESessionEvent> events = pack2Event.translate(actionPackage);
			for (EUESessionEvent event : events) {
				incomingEventsDisplay.append(event + "\n");
			}
		}
		repaint();
	}

	private void displayErrorMessage(String title, String message) {
		JOptionPane.showMessageDialog(this, message, title,
				JOptionPane.ERROR_MESSAGE);
	}

}