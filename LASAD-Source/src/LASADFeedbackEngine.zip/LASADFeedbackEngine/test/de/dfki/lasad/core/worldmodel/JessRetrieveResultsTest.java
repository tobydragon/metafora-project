package de.dfki.lasad.core.worldmodel;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import de.dfki.lasad.core.action.CompoundActionType;
import de.dfki.lasad.core.action.IActionAgent;
import de.dfki.lasad.core.analysis.AnalysisType;
import de.dfki.lasad.core.application.ServiceRegistry;
import de.dfki.lasad.core.dataservice.largoxml.dataprovider.LargoDataProvider55621;
import de.dfki.lasad.events.eue.session.ControllableEUEEventPublisher;
import de.dfki.lasad.models.analysis.AnalysisResult;
import de.dfki.lasad.models.eue.SessionID;
import de.dfki.lasad.modules.action.jess.JessFeedbackAgentConfiguration;
import de.dfki.lasad.modules.action.jess.JessFeedbackAgentDescription;

/**
 * 
 * @author Oliver Scheuer
 * 
 */
public class JessRetrieveResultsTest {

	private static Log logger = LogFactory
			.getLog(JessRetrieveResultsTest.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			ControllableEUEEventPublisher eventProvider = new LargoDataProvider55621();
			SessionID sessionID = new SessionID("LARGO-55621");

			JessFeedbackAgentConfiguration conf = new JessFeedbackAgentConfiguration(
					"rulebased_feedback_TEST.conf.xml");

			JessFeedbackAgentDescription agentDescription = new JessFeedbackAgentDescription(
					conf);
			IActionAgent actionAgent = agentDescription.createInstance();

			ServiceRegistry.registerActionModule(actionAgent);

			CompoundActionType compoundActionType = conf
					.getCompoundActionTypes().get(0);

			Map<AnalysisType, List<AnalysisResult>> type2Results = JessWorldModelSessionAnalyzer
					.getAnalysisResults(eventProvider, sessionID,
							compoundActionType);

			for (AnalysisType analysisType : type2Results.keySet()) {
				for (AnalysisResult analysisResult : type2Results
						.get(analysisType)) {
					logger.info(analysisResult);
				}
			}
			actionAgent.stopWorkingThread();
		} catch (Exception e) {
			logger.error(e.getClass() + ": " + e.getMessage(), e);
		}
	}
}
