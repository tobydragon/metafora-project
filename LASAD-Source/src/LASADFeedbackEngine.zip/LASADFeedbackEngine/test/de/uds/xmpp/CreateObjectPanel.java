package de.uds.xmpp;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

import de.dfki.lasad.modules.action.xmpp.MetaforaCfFactory;
import de.uds.commonformat.CfAction;

public class CreateObjectPanel extends JPanel implements CreatePanel{
	
	
	 JTextArea mapIdTextArea = new JTextArea("1", 1, 65);
	 JTextArea senderNameTextArea = new JTextArea("Metafora-test", 1, 65);
	 JTextArea viewUrlTextArea = new JTextArea("http://web-expresser.appspot.com/?userKey=3CykTKeEMd7VVmxJ19PF55&thumbnail=150", 1, 65);
	 JTextArea textTextArea = new JTextArea("Here is my model", 1, 65);
	 JTextArea referenceUrlTextArea = new JTextArea("http://web-expresser.appspot.com/?userKey=3CykTKeEMd7VVmxJ19PF55", 1, 65);
	 JTextArea usernameTextArea = new JTextArea("XMPP GUI", 1, 65);
	 
	 JRadioButton myModelButton;
	 JRadioButton questionButton;
	 JRadioButton microworldIssueButton;

	 JPanel messageTypeChooserPanel = new JPanel();
	  
	 public CreateObjectPanel(){
		 
		 ButtonGroup buttonGroup = new ButtonGroup();
		 
		 myModelButton = new JRadioButton("'my-model' Message");
		  buttonGroup.add(myModelButton);
		  messageTypeChooserPanel.add(myModelButton);
		  
		  microworldIssueButton = new JRadioButton("'Microworld Issue' Message");
		  buttonGroup.add(microworldIssueButton);
		  messageTypeChooserPanel.add(microworldIssueButton);
		  
		  questionButton = new JRadioButton("'Question' Message");
		  buttonGroup.add(questionButton);
		  messageTypeChooserPanel.add(questionButton);
		  microworldIssueButton.setSelected(true);
		  
		    this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		    this.add(messageTypeChooserPanel);
		    this.add(createLabeledTextArea("MapId", mapIdTextArea));
		    this.add(createLabeledTextArea("Sender", senderNameTextArea));
		    this.add(createLabeledTextArea("View URL", viewUrlTextArea));
		    this.add(createLabeledTextArea("Message", textTextArea));
		    this.add(createLabeledTextArea("Reference URL", referenceUrlTextArea));
		    this.add(createLabeledTextArea("Username", usernameTextArea));
	 }
	 
	 public JPanel createLabeledTextArea(String labelString, JTextArea textArea){
		 JPanel labeledTextPanel = new JPanel();
		 labeledTextPanel.setLayout(new FlowLayout());
		 labeledTextPanel.add(new JLabel(labelString));
		 labeledTextPanel.add( textArea);
		 labeledTextPanel.setPreferredSize(new Dimension(500, 100));
		 return labeledTextPanel;
	 }
	 
	 public String getMapIdTextArea(){
		 return mapIdTextArea.getText();
	 }
	 
	 public String getViewUrlTextArea(){
		 return viewUrlTextArea.getText();
	 }
	 
	 public String getReferenceUrlTextArea(){
		 return referenceUrlTextArea.getText();
	 }
	 
	 public String getSenderNameTextArea(){
		 return senderNameTextArea.getText();
	 }
	 
	 public String getUsernameTextArea(){
		 return usernameTextArea.getText();
	 }
	 
	 public String getText(){
		 return textTextArea.getText();
	 }
	 
	 public CfAction getMessage(){
    	CfAction cfAction=null;;
    	if (myModelButton.isSelected()){
			 cfAction = MetaforaCfFactory.createMyModelObjectMessage(this.getMapIdTextArea(),
					 this.getSenderNameTextArea(), this.getReferenceUrlTextArea(), 
					 this.getText(),  this.getUsernameTextArea());
		}
    	else if (microworldIssueButton.isSelected()){
			 cfAction = MetaforaCfFactory.createObjectMessage2(this.getMapIdTextArea(),
					 this.getSenderNameTextArea(), this.getViewUrlTextArea(), 
					 this.getText(), this.getReferenceUrlTextArea(), 
					 this.getUsernameTextArea());
		}
		else if (questionButton.isSelected()){
			cfAction = MetaforaCfFactory.createQuestionMessage2(this.getMapIdTextArea(),
					this.getUsernameTextArea(), this.getText());
		}
		return cfAction;
	 }
}
