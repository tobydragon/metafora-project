package de.uds.xmpp;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class CreateObjectPanel extends JPanel {
	 JTextArea mapIdTextArea = new JTextArea("1", 1, 65);
	 JTextArea senderNameTextArea = new JTextArea("Metafora-test", 1, 65);
	 JTextArea viewUrlTextArea = new JTextArea("http://web-expresser.appspot.com/?userKey=3CykTKeEMd7VVmxJ19PF55&thumbnail=150", 1, 65);
	 JTextArea textTextArea = new JTextArea("Here is my model", 1, 65);
	 JTextArea referenceUrlTextArea = new JTextArea("http://web-expresser.appspot.com/?userKey=3CykTKeEMd7VVmxJ19PF55", 1, 65);
	 JTextArea usernameTextArea = new JTextArea("XMPP GUI", 1, 65);
	 

	 public CreateObjectPanel(){
		    this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		    this.add(createLabeledTextArea("MapId", mapIdTextArea));
		    this.add(createLabeledTextArea("Sender", senderNameTextArea));
		    this.add(createLabeledTextArea("View URL", viewUrlTextArea));
		    this.add(createLabeledTextArea("Message", textTextArea));
		    this.add(createLabeledTextArea("Reference URL", referenceUrlTextArea));
		    this.add(createLabeledTextArea("Username", usernameTextArea));
	 }
	 
	 public JPanel createLabeledTextArea(String labelString, JTextArea textArea){
		 JPanel labeledTextPanel = new JPanel();
		 labeledTextPanel.setLayout(new FlowLayout());
		 labeledTextPanel.add(new JLabel(labelString));
		 labeledTextPanel.add( textArea);
		 labeledTextPanel.setPreferredSize(new Dimension(500, 100));
		 return labeledTextPanel;
	 }
	 
	 public String getMapIdTextArea(){
		 return mapIdTextArea.getText();
	 }
	 
	 public String getViewUrlTextArea(){
		 return viewUrlTextArea.getText();
	 }
	 
	 public String getReferenceUrlTextArea(){
		 return referenceUrlTextArea.getText();
	 }
	 
	 public String getSenderNameTextArea(){
		 return senderNameTextArea.getText();
	 }
	 
	 public String getUsernameTextArea(){
		 return usernameTextArea.getText();
	 }
	 
	 public String getText(){
		 return textTextArea.getText();
	 }
}
