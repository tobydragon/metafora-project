package de.uds.xmpp;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

import de.dfki.lasad.modules.action.xmpp.MetaforaCfFactory;
import de.kuei.metafora.xmpp.XMPPBridge;
import de.uds.commonformat.CfAction;
 

public class XmppGui extends JFrame implements ActionListener
{
  
	static {
		try {
			XMPPBridge.createConnection("XmppGuiTest", "XmppGuiTest", "XmppGuiTest", "command@conference.metafora.ku-eichstaett.de", "XmppGuiTest", "GuiTest");
		}
		catch(Exception e){
			System.out.println("[CfXmppWriter] error creating connection - " + e.getMessage());
		}
	}
	
	/**
   * The button.
   */ 
  JButton myButton = new JButton("Send message");
 
  JPanel messageTypeChooserPanel = new JPanel();
   
  /**
   * The bottom panel which holds button.
   */ 
  JPanel bottomPanel = new JPanel();
 
  /**
   * The top level panel which holds all.
   */
  JPanel holdAll = new JPanel();
  
  CreateObjectPanel createObjectPanel = new CreateObjectPanel(); 
  JTextArea messageText;
  XMPPBridge xmppBridge;
  
  JRadioButton createButton;
  JRadioButton myModelButton;
  JRadioButton questionButton;

  
  /**
   * The constructor.
   */
  public XmppGui()
  {
	  ButtonGroup buttonGroup = new ButtonGroup();
	  
	  myModelButton = new JRadioButton("'my-model' Message");
	  buttonGroup.add(myModelButton);
	  messageTypeChooserPanel.add(myModelButton);
	  
	  createButton = new JRadioButton("'Reference' Message");
	  buttonGroup.add(createButton);
	  messageTypeChooserPanel.add(createButton);
	  
	  questionButton = new JRadioButton("'Question' Message");
	  buttonGroup.add(questionButton);
	  messageTypeChooserPanel.add(questionButton);
	  createButton.setSelected(true);
	  
	  bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
	  bottomPanel.add(myButton);
	  messageText = new JTextArea("", 20, 80);
	  messageText.setEditable(false);
	  bottomPanel.add(messageText);
 
    holdAll.setLayout(new BorderLayout());
    holdAll.add(messageTypeChooserPanel, BorderLayout.NORTH);
    holdAll.add(bottomPanel, BorderLayout.SOUTH);
    holdAll.add(createObjectPanel, BorderLayout.CENTER);
 
    getContentPane().add(holdAll, BorderLayout.CENTER);
 
    myButton.addActionListener(this);
 
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    
    xmppBridge = XMPPBridge.getConnection("XmppGuiTest");
	xmppBridge.connect(true);
	xmppBridge.sendMessage("XmppGuiTest connected at " + System.currentTimeMillis());
  }
 
  /**
   * The program    * @param args the program start up parameters, not used.
   */
  public static void main(String[] args)
  {
	  XmppGui myApplication = new XmppGui();
 
    // Specify where will it appear on the screen:
    myApplication.setLocation(10, 10);
    myApplication.setSize(900, 600);
 
    // Show it!
    myApplication.setVisible(true);
  }
 
  /**
   * Each non abstract class that implements the ActionListener
   * must have this method.
   * 
   * @param e the action event.
   */
  public void actionPerformed(ActionEvent e)
  {
    if (e.getSource() == myButton){
    	CfAction cfAction=null;;
    	if (myModelButton.isSelected()){
			 cfAction = MetaforaCfFactory.createMyModelObjectMessage(createObjectPanel.getMapIdTextArea(),
				createObjectPanel.getSenderNameTextArea(), createObjectPanel.getReferenceUrlTextArea(), 
				createObjectPanel.getText(),  createObjectPanel.getUsernameTextArea());
		}
    	else if (createButton.isSelected()){
			 cfAction = MetaforaCfFactory.createObjectMessage2(createObjectPanel.getMapIdTextArea(),
				createObjectPanel.getSenderNameTextArea(), createObjectPanel.getViewUrlTextArea(), 
				createObjectPanel.getText(), createObjectPanel.getReferenceUrlTextArea(), 
				createObjectPanel.getUsernameTextArea());
		}
		else if (questionButton.isSelected()){
			cfAction = MetaforaCfFactory.createQuestionMessage2(createObjectPanel.getMapIdTextArea(),
				createObjectPanel.getUsernameTextArea(), createObjectPanel.getText());
		}
		System.out.println("Sending action:\n" + cfAction.toXml());
		messageText.setText("Sending action:\n" + cfAction.toXml());
		xmppBridge.sendMessage(cfAction.toXml().toString());
    }
  }
}