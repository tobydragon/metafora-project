package de.uds.xmpp;

import de.uds.commonformat.CfAction;

public interface CreatePanel {
	
	public CfAction getMessage();

}
