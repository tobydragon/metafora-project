package de.uds.xmpp;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import de.dfki.lasad.modules.action.xmpp.MetaforaCfFactory;
import de.uds.commonformat.CfAction;

public class CreateMapPanel extends JPanel implements CreatePanel{
	 JTextArea senderNameTextArea = new JTextArea("Metafora-test", 1, 65);
	 JTextArea mapnameTextArea = new JTextArea("testMap", 1, 65);
	 JTextArea templateTextArea = new JTextArea("DiscussingMicroworlds-1", 1, 65);

	 public CreateMapPanel(){
		    this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		    this.add(createLabeledTextArea("Sender", senderNameTextArea));
		    this.add(createLabeledTextArea("Map Name", mapnameTextArea));
		    this.add(createLabeledTextArea("Template", templateTextArea));
	 }
	 
	 public JPanel createLabeledTextArea(String labelString, JTextArea textArea){
		 JPanel labeledTextPanel = new JPanel();
		 labeledTextPanel.setLayout(new FlowLayout());
		 labeledTextPanel.add(new JLabel(labelString));
		 labeledTextPanel.add( textArea);
		 labeledTextPanel.setPreferredSize(new Dimension(500, 100));
		 return labeledTextPanel;
	 }
	 
	 public String getTemplateTextArea(){
		 return templateTextArea.getText();
	 }
	 
	 public String getSenderNameTextArea(){
		 return senderNameTextArea.getText();
	 }
	 
	 public String getMapnameTextArea(){
		 return mapnameTextArea.getText();
	 }
	 
	 public CfAction getMessage(){
    	CfAction cfAction = MetaforaCfFactory.createMapMessage(getSenderNameTextArea(), getMapnameTextArea(), getTemplateTextArea());
    	return cfAction;
	 }
}
