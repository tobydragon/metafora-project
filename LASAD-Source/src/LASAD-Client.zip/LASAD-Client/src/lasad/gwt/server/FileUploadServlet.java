package lasad.gwt.server;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lasad.gwt.client.importer.ImportFileChecker;
import lasad.gwt.client.logger.Logger;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@SuppressWarnings("serial")
public class FileUploadServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletFileUpload upload = new ServletFileUpload();
		request.setCharacterEncoding("UTF-8");
		try {
			FileItemIterator iter = upload.getItemIterator(request);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			String outputString = "";
			
			FileItemStream item = null;
			boolean validFileType = true;
			
			if (!iter.hasNext()) Logger.log("FileUploadWidget: No iter.hasnext :(", Logger.DEBUG_ERRORS);
			while (iter.hasNext()) {
				item = iter.next();
				
				if (validFileType = ImportFileChecker.checkValidFileType(item.getName())){
					//In case the user chose an argunaut file
					if (ImportFileChecker.checkArgunaut(item.getName())) {
						outputString = "GML-FILE";
					}

					String name = item.getFieldName();
					InputStream stream = item.openStream();

					// Process the input stream
					int len;
					byte[] buffer = new byte[1000000];
					while ((len = stream.read(buffer, 0, buffer.length)) != -1) {
						out.write(buffer, 0, len);
					}
				}
				else {
					validFileType = false;
				}
			}
			
			if (validFileType) {
				outputString += out.toString("UTF-8");

				//In case the user chose a largo file
				if (ImportFileChecker.checkLargo(outputString)) { 
					outputString = "LARGO-FILE;;" + item.getName() + ";;" + outputString;
				}

				outputString = outputString.replaceAll("<", "THISISABRACKETSUBSTITUTE1");
				outputString = outputString.replaceAll(">", "THISISABRACKETSUBSTITUTE2");
				
				response.setContentType("text/html; charset=UTF-8");
			    PrintWriter output = new PrintWriter(new OutputStreamWriter(response.getOutputStream(), "UTF8"), true);
			    output.print(outputString);
			    output.flush();
			    
			    //Does NOT send the response utf-encoded
//				response.setCharacterEncoding("UTF-8");
//				response.getOutputStream().print(outputString);
//				response.getOutputStream().flush();
				
			}
			else {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "file type invalid");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}