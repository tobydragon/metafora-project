package lasad.gwt.client.urlparameter;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.parameters.ParameterTypes;
import lasad.gwt.client.logger.Logger;

public class UrlParameterConfig {
	
	private boolean autoLogin=false;
	private String username;
	private String password;
	private boolean isPasswordEncrypted;
	private String mapId;
	private String groupId;
	private String challengeId;
	

	public UrlParameterConfig(){
		String autoLoginStr = com.google.gwt.user.client.Window.Location.getParameter("autologin");
		autoLogin = Boolean.parseBoolean(autoLoginStr);
		if (autoLogin){
			username = com.google.gwt.user.client.Window.Location.getParameter("user");
			password = com.google.gwt.user.client.Window.Location.getParameter("pw");
			mapId = com.google.gwt.user.client.Window.Location.getParameter("mapid");
			groupId = com.google.gwt.user.client.Window.Location.getParameter("groupid");
			challengeId = com.google.gwt.user.client.Window.Location.getParameter("challengeid");
			String isPasswordEncryptedStr = com.google.gwt.user.client.Window.Location.getParameter("pwencrypted");
			isPasswordEncrypted = Boolean.parseBoolean(isPasswordEncryptedStr);			

		}
		Logger.log("[lasad.gwt.client.LASAD_CLient][checkAndParseUrlParams] username=" + username + 
				" - Password=" + password  + " - MapId=" + mapId + " - groupId=" +groupId 
				+ " - challengeId=" + challengeId + " - isPasswordEncrypted=" + isPasswordEncrypted, Logger.DEBUG);
	}
	
	//mutator
	public void addParamsToActionPackage(ActionPackage ap) {
		if (groupId != null || challengeId != null){
			for (Action action : ap.getActions()){
				if (groupId != null){
					action.addParameter(ParameterTypes.groupId, groupId);
				}
				if (challengeId != null){
					action.addParameter(ParameterTypes.challengeId, challengeId);
				}
			}
		}
	}


	public boolean isAutoLogin() {
		return autoLogin;
	}


	public String getUsername() {
		return username;
	}


	public String getPassword() {
		return password;
	}


	public String getMapId() {
		return mapId;
	}


	public String getGroupId() {
		return groupId;
	}


	public String getChallengeId() {
		return challengeId;
	}

	public boolean isPasswordEncrypted() {
		return isPasswordEncrypted;
	}

}
