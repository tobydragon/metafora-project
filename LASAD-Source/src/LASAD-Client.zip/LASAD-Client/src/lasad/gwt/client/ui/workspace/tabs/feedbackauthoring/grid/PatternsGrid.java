package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid;

import java.util.List;

import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.ElementModel;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.PatternFA;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.TestData;
import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;

public class PatternsGrid extends CustomizedGrid {
	
	private static PatternsGrid instance = null;
//	private DatabaseFA db;
	private AgentDescriptionFE agent;
	
	
	public static PatternsGrid getInstance(GridConf gridConf, AgentDescriptionFE agent) {
		if (instance == null) {
			instance = new PatternsGrid(gridConf, agent);
		}
		return instance;
	}
	
	private PatternsGrid(GridConf gridConf, AgentDescriptionFE agent) {
		super(gridConf);
		this.agent = agent;
		this.setHeaderVisible(false);
	    this.setBodyBorder(false);
	    populateGridForTesting();
	}

	@Override
	void viewElement(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void editElement(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void deleteElement(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void duplicateElement(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void addElement() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void markReadyElement(String name) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	void populateGridForTesting() {
		List<PatternFA> patterns = TestData.getPatterns();
		for(PatternFA pattern : patterns){
			ElementModel m = new ElementModel(pattern.getName(), pattern.getType(), pattern.getInfo());
			getGridStore().add(m);
		}	
	}
	
//	public void populateGridForTestingaa(){
//		Map<String, String> agents = TestData.getAgents();
//		
//		for(String a : agents.keySet()){
//			ElementModel m = new ElementModel();
//			m.set("name", a);
//			m.set("status", agents.get(a));
//			
//			gridStore.add(m);
//		}		
//	}
	
//	private void populateGridss(){
//		List<PatternFA> patterns = TestData.getPatterns();
//		
//		for(PatternFA pattern : patterns){
//			ElementModel m = new ElementModel(pattern.getName(), pattern.getType(), pattern.getInfo());
//			gridStore.add(m);
//		}		
//	}

	

}
