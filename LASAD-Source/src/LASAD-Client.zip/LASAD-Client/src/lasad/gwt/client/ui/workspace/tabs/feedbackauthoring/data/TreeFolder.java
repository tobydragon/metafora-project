package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;

import com.extjs.gxt.ui.client.data.BaseTreeModel;

public class TreeFolder extends BaseTreeModel implements Serializable, Comparable<TreeFolder>  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2494870527406041792L;
	private static int ID = 0;
	
	public TreeFolder() {
	}

	public TreeFolder(Map<String, String> map) {
		this();
		Set<String> keys = map.keySet();
		for(String key:keys){
			String value = map.get(key);
			set(key, value);
		}
	}
	public TreeFolder(Map<String, String> map, BaseTreeModel[] children) {
		this(map);
		for (int i = 0; i < children.length; i++) {
			add(children[i]);
		}
	}
	public String getValue(String key){
		return (String) get(key);
	}
	
	public TreeFolder(String name, String status, String labelTwo) {
		this();
		set("id", ID++);
	    set("name", name);
	    set("status", status);
	    set("labelTwo", labelTwo);
	}
	
	public TreeFolder(String name, String labelOne, String labelTwo, BaseTreeModel[] children) {
		this(name, labelOne, labelTwo);
		for (int i = 0; i < children.length; i++) {
			add(children[i]);
	    }
	}

	public String getName() {
		return (String) get("name");
	}
	
	public String toString() {
		return getName();
	}
	
	@Override
	public int compareTo(TreeFolder o) {
		return this.getValue("name").compareTo(o.getValue("name"));
		//return this.getName().compareTo(o.getName());
	}
	
}
