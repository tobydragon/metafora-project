package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data;

import java.util.List;

public class AgentFA{
	
	private OntologyFA ontology;
	private boolean read;
	private boolean write;
	private int status;
	private int statusReason;
	
	/*
	 * General Agent Settings
	 */
	//Basic
	private String agentName; //Referred in GUI as Agent ID
	private String supportedOnt;
	private String agentDescription;
	//Phases
	/*
	 * Patterns
	 */
	
	/*
	 * Rules
	 */
	//Rule(pattern rule)
	//Basic
	private String ruleName; ////Referred in GUI as Rule ID
	private String ruleDisplayName;
	private String ruleDescription;
	private int ruleProvision;
	private String ruleProvSec;
	private int ruleRecipient;
	private String rulePattern;
	//Filter
	//Message
	//Phases
	//Rule(filter rule)
	//Basic
	//Components
	//Priority
	//
	
	private List<PatternFA> patternList;
	
	public AgentFA(){
		
	}
	
	public AgentFA(String name, OntologyFA ontology, boolean read, boolean write,
			int status) {
		super();
		this.agentName = name;
		this.ontology = ontology;
		this.read = read;
		this.write = write;
		this.status = status;
	}
	
	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public OntologyFA getOntology() {
		return ontology;
	}

	public void setOntology(OntologyFA ontology) {
		this.ontology = ontology;
	}

	public boolean isRead() {
		return read;
	}

	public void setRead(boolean read) {
		this.read = read;
	}

	public boolean isWrite() {
		return write;
	}

	public void setWrite(boolean write) {
		this.write = write;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getSupportedOnt() {
		return supportedOnt;
	}

	public void setSupportedOnt(String supportedOnt) {
		this.supportedOnt = supportedOnt;
	}

	public String getAgentDescription() {
		return agentDescription;
	}

	public void setAgentDescription(String description) {
		this.agentDescription = description;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRuleDisplayName() {
		return ruleDisplayName;
	}

	public void setRuleDisplayName(String ruleDisplayName) {
		this.ruleDisplayName = ruleDisplayName;
	}

	public String getRuleDescription() {
		return ruleDescription;
	}

	public void setRuleDescription(String ruleDescription) {
		this.ruleDescription = ruleDescription;
	}

	public int getRuleProvision() {
		return ruleProvision;
	}
	public void setRuleProvision(int ruleProvision) {
		this.ruleProvision = ruleProvision;
	}

	public int getRuleRecipient() {
		return ruleRecipient;
	}
	public void setRuleRecipient(int ruleRecipient) {
		this.ruleRecipient = ruleRecipient;
	}

	public String getRulePattern() {
		return rulePattern;
	}
	public void setRulePattern(String rulePattern) {
		this.rulePattern = rulePattern;
	}

	public String getRuleProvSec() {
		return ruleProvSec;
	}
	public void setRuleProvSec(String ruleProvSec) {
		this.ruleProvSec = ruleProvSec;
	}

	public int getStatusReason() {
		return statusReason;
	}

	public void setStatusReason(int statusReason) {
		this.statusReason = statusReason;
	}
	
	

}
