package lasad.gwt.client.model;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;


public class ElementInfo {

	public Map<String, String> getUiOptions() {
		return uiOptions;
	}

	public Map<String, String> getElementOptions() {
		return elementOptions;
	}

	String elementType;

	public String getElementType() {
		return elementType;
	}

	public void setElementType(String elementType) {
		this.elementType = elementType;
	}

	String elementID;

	public String getElementID() {
		return elementID;
	}

	public void setElementID(String type) {
		this.elementID = type;
	}

	int quantity;

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	int minQuantity;

	public int getMinQuantity() {
		return minQuantity;
	}

	public void setMinQuantity(int quantity) {
		this.minQuantity = quantity;
	}

	int maxQuantity;

	public int getMaxQuantity() {
		return maxQuantity;
	}

	public void setMaxQuantity(int quantity) {
		this.maxQuantity = quantity;
	}

	// General Option

	Map<String, String> uiOptions = new HashMap<String, String>();

	public void addUiOption(String vName, String value) {
		uiOptions.put(vName, value);
	}

	public String getUiOption(String vName) {
		return uiOptions.get(vName);
	}

	Map<String, String> elementOptions = new HashMap<String, String>();

	public void addElementOption(String vName, String value) {
		elementOptions.put(vName, value);
	}

	public String getElementOption(String vName) {
		return elementOptions.get(vName);
	}
	
	ArrayList <Map<String, String>> radiobuttons= new ArrayList <Map<String, String>>();

	public void addRadioElementOption(ArrayList <Map<String, String>> myradiobuttons ) {
	radiobuttons=myradiobuttons;

	}

	public ArrayList <Map<String, String>> getRadioButtonElements() {
		return radiobuttons;
	}

	Map<String, ElementInfo> childElements = new LinkedHashMap<String, ElementInfo>();

	public void addChildElement(ElementInfo info) {
		childElements.put(info.getElementID(), info);
	}

	public Map<String, ElementInfo> getChildElements() {
		return childElements;
	}

	public void setChildElements(Map<String, ElementInfo> newOrder) {
		this.childElements = newOrder;
		
	}
}
