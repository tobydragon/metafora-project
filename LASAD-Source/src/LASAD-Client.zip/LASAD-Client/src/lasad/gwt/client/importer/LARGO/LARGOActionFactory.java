package lasad.gwt.client.importer.LARGO;

import java.util.Date;
import java.util.HashMap;
import java.util.Vector;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.model.ElementInfo;

public class LARGOActionFactory {

	private static LARGOActionFactory instance = null;

	private LARGOActionFactory() {}

	public static LARGOActionFactory getInstance() {
		if (instance == null) {
			instance = new LARGOActionFactory();
		}
		return instance;
	}

	private ActionPackage createActionPackage() {
		return new ActionPackage();
	}

	private Action createBox(int mapID, ElementInfo config, HashMap<String, String> parsedBoxValues) {
		Action a = createSpecificAction("CREATE-ELEMENT", "MAP");
		a.addParameter("TYPE", "box");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ELEMENT-ID", config.getElementID());
		a.addParameter("OBJECTID", parsedBoxValues.get("ID"));
		a.addParameter("POS-X", parsedBoxValues.get("posx"));
		a.addParameter("POS-Y", parsedBoxValues.get("posy"));
		return a;
	}

	private Action createSpecificAction(String cmd, String category) {
		return new Action(cmd, category);
	}

	private Vector<Action> createBoxElementsAction(ElementInfo currentElement, int mapID, HashMap<String, String> parsedValues) {
		Vector<Action> allActions = new Vector<Action>();

		for (ElementInfo childElement : currentElement.getChildElements().values()) {

			if (!(parsedValues.get("andQnt") == null) && childElement.getElementID().equals("and")) {

				String s = parsedValues.get("andQnt");
				int quantity = Integer.parseInt(s);
				childElement.setQuantity(quantity);
			} else if ((parsedValues.get("and") == null) && childElement.getElementID().equals("and")) {
				childElement.setQuantity(0);
			}

			if (!(parsedValues.get("even") == null) && childElement.getElementID().equals("even")) {
				childElement.setQuantity(1);
			} else if ((parsedValues.get("even") == null) && childElement.getElementID().equals("even")) {
				childElement.setQuantity(0);
			}

			if (!(parsedValues.get("except") == null) && childElement.getElementID().equals("except")) {
				childElement.setQuantity(1);
			} else if ((parsedValues.get("except") == null) && childElement.getElementID().equals("except")) {
				childElement.setQuantity(0);
			}

			if (!(parsedValues.get("outcome") == null) && childElement.getElementID().equals("outcome")) {
				childElement.setQuantity(1);
			} else if ((parsedValues.get("outcome") == null) && childElement.getElementID().equals("outcome")) {
				childElement.setQuantity(0);
			}

			if (!(parsedValues.get("transcript") == null) && childElement.getElementID().equals("transcriptlink")) {
				childElement.setQuantity(1);
			} else if ((parsedValues.get("transcript") == null) && childElement.getElementID().equals("transcriptlink")) {
				childElement.setQuantity(0);
			}

			for (int i = 0; i < childElement.getQuantity(); i++) {
				Action b = null;

				if (childElement.getElementType().equals("text")) {
					b = createSpecificAction("CREATE-ELEMENT", "MAP");

					b.addParameter("ELEMENT-ID", childElement.getElementID());

					if (childElement.getElementID().equals("text")) {
						b.addParameter("TEXT", parsedValues.get("text"));
					} else if (childElement.getElementID().equals("outcome")) {
						b.addParameter("TEXT", parsedValues.get("outcome"));
					} else if (childElement.getElementID().equals("if")) {
						b.addParameter("TEXT", parsedValues.get("if"));
					} else if (childElement.getElementID().equals("and")) {
						b.addParameter("TEXT", parsedValues.get("and" + i));
					} else if (childElement.getElementID().equals("even")) {
						b.addParameter("TEXT", parsedValues.get("even"));
					} else if (childElement.getElementID().equals("then")) {
						b.addParameter("TEXT", parsedValues.get("then"));
					} else if (childElement.getElementID().equals("except")) {
						b.addParameter("TEXT", parsedValues.get("except"));
					}
				}

				else if (childElement.getElementType().equals("transcript-link")) {

					int startRow = Integer.parseInt(parsedValues.get("startRow"));
					int startPoint = Integer.parseInt(parsedValues.get("startPoint"));
					int endRow = Integer.parseInt(parsedValues.get("endRow"));
					int endPoint = Integer.parseInt(parsedValues.get("endPoint"));

					b = createSpecificAction("CREATE-ELEMENT", "MAP");

					b.addParameter("ELEMENT-ID", "transcriptlink");

					b.addParameter("STARTROW", startRow + "");
					b.addParameter("STARTPOINT", startPoint + "");
					b.addParameter("ENDROW", endRow + "");
					b.addParameter("ENDPOINT", endPoint + "");
				} else if (childElement.getElementType().equals("awareness")) {
					b = createSpecificAction("CREATE-ELEMENT", "MAP");

					b.addParameter("ELEMENT-ID", String.valueOf(childElement.getElementID()));

					long millis = Long.parseLong(parsedValues.get("date"));
					Date tmpDate = new Date(millis);
					String date = tmpDate.toString();
					date = date.substring(4, 16);
					b.addParameter("TEXT", parsedValues.get("author") + ", " + date);
				}

				if (b != null) {
					b.addParameter("TYPE", childElement.getElementType());
					b.addParameter("PARENT", "LAST-ID");
					b.addParameter("MAP-ID", mapID + "");
					b.addParameter("TIME", parsedValues.get("date"));
					allActions.add(b);
				}
			}
		}
		return allActions;
	}

	public ActionPackage createBoxWithElements(int mapID, ElementInfo currentElement, HashMap<String, String> parsedBoxValues) {
		ActionPackage p = createActionPackage();
		Action a = createBox(mapID, currentElement, parsedBoxValues);
		p.addAction(a);

		Vector<Action> b = createBoxElementsAction(currentElement, mapID, parsedBoxValues);
		if (b.size() > 0) {
			for (Action c : b) {
				p.addAction(c);
			}
		}
		return p;
	}

	public ActionPackage createLink(int id, ElementInfo elementInfo, HashMap<String, Object> edgeValues) {
		ActionPackage p = createActionPackage();

		Action a = createSpecificAction("CREATE-ELEMENT", "MAP");
		a.addParameter("TYPE", elementInfo.getElementType());
		a.addParameter("MAP-ID", String.valueOf(id));
		a.addParameter("ELEMENT-ID", String.valueOf(elementInfo.getElementID()));
		a.addParameter("PARENT", ((Integer) edgeValues.get("source")) + "");
		a.addParameter("PARENT", ((Integer) edgeValues.get("target")) + "");

		p.addAction(a);

		// Now walk through the possible Elements
		for (ElementInfo childElement : elementInfo.getChildElements().values()) {
			for (int i = 0; i < childElement.getQuantity(); i++) {
				Action b = null;

				if (childElement.getElementType().equals("text")) {
					b = createSpecificAction("CREATE-ELEMENT", "MAP");

					b.addParameter("TYPE", childElement.getElementType());
					b.addParameter("MAP-ID", id + "");
					b.addParameter("PARENT", "LAST-ID");
					b.addParameter("ELEMENT-ID", childElement.getElementID());

					if (childElement.getElementID().equals("text")) {
						b.addParameter("TEXT", (String) edgeValues.get("text"));
					}
				}
				if (b != null) p.addAction(b);
			}
		}
		return p;
	}
	
	public ActionPackage parsingFinished(String importType) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("IMPORT-FINISHED", "FILE");
		a.addParameter("IMPORT-TYPE", importType);
		p.addAction(a);
		return p;
	}
}