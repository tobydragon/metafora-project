/**
 * 
 */
package lasad.gwt.client.ui.workspace.feedback.lklfeedback;

import java.util.ArrayList;

import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Widget;


/**
 * Loosely based upon uk.ac.lkl.common.ui.jft.Callout
 * 
 * @author Ken Kahn
 *
 */
public class CallOut extends AbsolutePanel {
    
    private ArrayList<Widget> targets = new ArrayList<Widget>();
    
    public CallOut() {
    }
    
    public void addTarget(Widget target) {
        targets.add(target);
    }
    
    public void removeTarget(Widget target) {
        targets.remove(target);
    }
    
    public ArrayList<Widget> getTargets() {
        return targets;
    }
    
    //  Layout algorithm
    
    protected class Point {

        protected int x;
        protected int y;

        public Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
        
    }
    
    protected class Dimension {
        
        protected int width;
        protected int height;

        public Dimension(int width, int height) {
            this.width = width;
            this.height = height;
        }
    }
    
    protected class Rectangle {
        
        protected int x;
        protected int y;        
        protected int width;
        protected int height;
        
        public Rectangle(int x, int y, int width, int height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }

        public Rectangle(Widget widget) {
            this(widget.getAbsoluteLeft(), widget.getAbsoluteTop(), widget.getOffsetWidth(), widget.getOffsetHeight());
        }

        public double getCenterX() {
            return x+width/2;
        }

        public double getCenterY() {
            return y+height/2;
        }

        public int getWidth() {
            return width;
        }

        public int getHeight() {
            return height;
        }
    }
    
    private class WeightedPoint {
        public int x, y;
        public double weightX, weightY;
        public WeightedPoint() {
            x = 0;
            y = 0;
            weightX = 0.0;
            weightY = 0.0;
        }
    }
    
    /**
     * Find a place for this CallOut that does not conflict with the targets.
     *
     * @return new location for the CallOut
     */
    protected Point findPlaceFor() {
        Dimension size = new Dimension(getOffsetWidth(), getOffsetHeight());
        Point position = new Point(0, 0);
        Rectangle place = new Rectangle(this);
        WeightedPoint magnet;
        double x = 0.0, y = 0.0, totalWeigthX = 0.0, totalWeigthY = 0.0;
        for (Widget target : targets) {
            Rectangle targetPlace = new Rectangle(target);
            magnet = awayFrom(targetPlace, place, size);
            x += magnet.x;
            y += magnet.y;
            totalWeigthX += magnet.weightX;
            totalWeigthY += magnet.weightY;
        }
        
        if (totalWeigthX < 1.0) {
            x += place.x + place.width /2;
            totalWeigthX += 1.0;
        }
        if (totalWeigthY < 1.0) {
            y += place.y + place.height/2;
            totalWeigthY += 1.0;
        }
        x /= totalWeigthX;
        y /= totalWeigthY;
        
        position.x = (int) x - size.width /2;
        position.y = (int) y - size.height/2;
        
        int margin = 8;
        place.x += margin;
        place.y += margin;
        place.width  -= 2*margin;
        place.height -= 2*margin;
        
        if (position.x < place.x) {
            position.x = place.x;
        } else if (position.x + size.width > place.x + place.width) {
            position.x = place.x + place.width - size.width;
        }
        if (position.y < place.y) {
            position.y = place.y;
        } else if (position.y + size.height > place.y + place.height) {
            position.y = place.y + place.height - size.height;
        }
        return position;
    }
    
    private WeightedPoint awayFrom(Rectangle target, Rectangle place, Dimension size) {
        WeightedPoint magnet = new WeightedPoint();
        double targetCenterX, targetCenterY, centerX, centerY;
        centerX = place.getCenterX();
        centerY = place.getCenterY();
        targetCenterX = target.getCenterX();
        targetCenterY = target.getCenterY();
        int separationX = size.width, separationY = size.height;
        if (Math.abs(targetCenterX - centerX) / place.getWidth() > 
            Math.abs(targetCenterY - centerY) / place.getHeight()) {
            if (targetCenterX > centerX) {
                magnet.x = target.x - separationX - size.width/2;
            } else {
                magnet.x = target.x + target.width + separationX + size.width/2;
            }
            magnet.weightX = 1.0;
            magnet.weightY = 0.0;
        } else {
            if (targetCenterY > centerY) {
                magnet.y = target.y - separationY - size.height/2;
            } else {
                magnet.y = target.y + target.height + separationY + size.height/2;
            }
            magnet.weightX = 0.0;
            magnet.weightY = 1.0;
        }
        return magnet;
    }

}
