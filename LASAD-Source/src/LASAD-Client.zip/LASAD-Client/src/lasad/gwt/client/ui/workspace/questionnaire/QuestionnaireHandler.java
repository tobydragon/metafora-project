package lasad.gwt.client.ui.workspace.questionnaire;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class QuestionnaireHandler {

	private Map<String, QuestionnaireWindow> question2Window = new HashMap<String, QuestionnaireWindow>();
	private Map<QuestionnaireWindow, Vector<String>> window2Question = new HashMap<QuestionnaireWindow, Vector<String>>();

	public void registerQuestionWindow(QuestionnaireWindow window, QuestionnaireStepConfig stepConfig) {
		window2Question.put(window, new Vector<String>());
		for (QuestionConfig question : stepConfig.getQuestionnaireQuestions()) {
			question2Window.put(question.getId(), window);
			window2Question.get(window).add(question.getId());
		}

	}

	public void removeQuestionWindow(QuestionnaireWindow window) {
		for (String id : window2Question.get(window)) {
			question2Window.remove(id);
		}
		window2Question.remove(window);
	}

	public void publishQuestionnaireAnswer(String id, String answer) {
		question2Window.get(id).addQuestionAnswer(id, answer);
	}

}
