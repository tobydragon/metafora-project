package lasad.gwt.client.ui.common.elements;

import java.util.Vector;

import lasad.gwt.client.LASAD_Client;
import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.ui.common.ExtendedElement;
import lasad.gwt.client.ui.common.ExtendedElementContainerInterface;

import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.util.Size;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;

public class ExtendedXmppMessageButtonElement extends ExtendedElement {

	String link = "http://web-expresser.appspot.com/?userKey=x5Spdu9XABVAVTSKxzQl67";
	
	public ExtendedXmppMessageButtonElement(ExtendedElementContainerInterface container, ElementInfo config) {
		super(container, config);

		// Set possible Element Vars
		// Only this Elements would be updates to the model
		
		this.elementVars.add("LINK");
		this.setVarValue("LINK", link, LASAD_Client.getInstance().getUsername());
	}

	Element elementContent = null;

	protected void buildElement() {
		if (elementContent != null) {
			// Already builded
			return;
		}

		EventListener listener = new EventListener() {
			public void onBrowserEvent(Event be) {
				int code = be.getTypeInt();
				if (code == Events.OnClick.getEventCode()) {
					if (ExtendedXmppMessageButtonElement.this.isActiveViewMode()) {
						// Ask for Focus and release it to trigger update
						Vector<String[]> values = new Vector<String[]>();
						String[] tmp = {"LINK", getVarValue("LINK")};
						values.add(tmp);
						communicator.sendActionPackage(actionBuilder.updateElementWithMultipleValues(
								ExtendedXmppMessageButtonElement.this.getContainer().getMVCViewSession().getController().getMapID(), 
								getConnectedModel().getId(), values));
					}
				}
				be.stopPropagation();
			}
		};

		elementContent = DOM.createButton();
		elementContent.setClassName("extendedXmppMessageElement");
		elementContent.setPropertyString("name", "Go To Microworld");
		elementContent.setPropertyString("value", "Go to Microworld");
		elementContent.setInnerText("Go to Microworld");

		DOM.sinkEvents(this.elementContent, Events.OnClick.getEventCode());
		DOM.setEventListener(this.elementContent, listener);
		//setElementSize(new Size(getActualViewModeWidth(), getActualViewModeHeight()));
		setElementSize(new Size(100, 50));
	}
	
	protected void switchToEditMode(Element contentFrame) {
		buildElement();
		if (contentFrame != null){
			if (elementContent!= null && !contentFrame.hasChildNodes()) {
				DOM.appendChild(contentFrame, elementContent);
			}
		}
	}

	protected void switchToViewMode(Element contentFrame) {
		buildElement();
		if (contentFrame != null){
			if (elementContent!= null && !contentFrame.hasChildNodes()) {
				DOM.appendChild(contentFrame, elementContent);
			}
		}
	}

	protected String getVarValue(String name) {
		if (name.equals("LINK")) {
			return link;
		}
		return null;
	}

	protected void setVarValue(String name, String value, String username) {
		if (name.equals("LINK")) {
			link = value;
		}
	}

	@Override
	protected void setElementHighlight(boolean highlight) {
	}

	@Override
	protected void onEstablishModelConnection() {
	}

	@Override
	protected void onRemoveModelConnection() {
	}

	protected void setElementSize(Size size) {
		int balanceWidth = 4, balanceHeight = 4; // 1px distance to the frameborder, 1 px padding in each direction
		if (elementContent!= null ){
			DOM.setStyleAttribute(elementContent, "width", Math.max(0, size.width - balanceWidth) + "px");
			DOM.setStyleAttribute(elementContent, "height", Math.max(0, size.height - balanceHeight) + "px");
		}
	}
}