package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid;

import com.extjs.gxt.ui.client.widget.grid.GridView;
import com.google.gwt.dom.client.Element;
import com.google.gwt.user.client.ui.Widget;

public class CustomizedGridView extends GridView {
	
	public CustomizedGridView(){
		//these lines are used to keep the row highlighted even when the mouse is over a Widget
		this.setRowSelectorDepth(20);
		this.setCellSelectorDepth(10);
	}
	
//	@Override
//	protected void onRowOver(Element row) {
//		super.onRowOver(row);
////        System.out.println("onRowOver");
//	}
//	
//    @Override
//    protected void onRowOut(Element row) {
//        super.onRowOut(row);
////        System.out.println("onRowOut");
//    }
	
}
