package lasad.gwt.client.model.events;

public interface LASADEventListenerInterface {
	public void fireLasadEvent(LasadEvent event);
}