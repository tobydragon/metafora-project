package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;

import com.extjs.gxt.ui.client.data.BaseTreeModel;

public class TreeFolderChild extends BaseTreeModel implements Serializable, Comparable<TreeFolderChild> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8093171177003553908L;
	
	public TreeFolderChild(){
	}
	
	public TreeFolderChild(Map<String, String> map) {
		this();
		Set<String> keys = map.keySet();
		for(String key:keys){
			String value = map.get(key);
			set(key, value);
		}
	}
	public String getValue(String key){
		return (String) get(key);
	}
	
	public TreeFolderChild(String name, String status){
		set("name", name);
		set("status", status);
	}
	
	public TreeFolderChild(String name, String status, String aux){
		set("name", name);
		set("status", status);
		set("aux", aux);
	}
	
	public String getName() {
		return (String) get("name");
	}
	public String getAux() {
		return (String) get("aux");
	}

	public String toString() {
		return getValue("name");
	}
	
	@Override
	public int compareTo(TreeFolderChild o) {
		return this.getValue("name").compareTo(o.getValue("name"));
		//return this.getName().compareTo(o.getName());
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TreeFolderChild other = (TreeFolderChild) obj;
		if (this.getValue("name") == null) {
			if (other.getValue("name") != null)
				return false;
		} else if (!this.getValue("name").equals(other.getValue("name")))
			return false;
		return true;
	}
}
