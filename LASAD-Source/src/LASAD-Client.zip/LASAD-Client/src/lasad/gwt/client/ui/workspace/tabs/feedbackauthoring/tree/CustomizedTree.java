package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.tree;

public class CustomizedTree {

}
