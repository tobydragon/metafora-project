package lasad.gwt.client.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import lasad.gwt.client.communication.objects.Parameter;
import lasad.gwt.client.logger.Logger;
import lasad.gwt.client.model.events.LasadEvent;

public class MVController {

	private MapInfo mapInfo;
	private int actualRevision = 0;

	private Map<Integer, UnspecifiedElementModel> elementModelMapping = new HashMap<Integer, UnspecifiedElementModel>();
	private Map<UnspecifiedElementModel, Vector<MVCViewSession>> modelMapped2ViewSession = new HashMap<UnspecifiedElementModel, Vector<MVCViewSession>>();
	private Vector<MVCViewSession> registeredViewSessions = new Vector<MVCViewSession>();

	public MVController(MapInfo mapInfo) {
		this.mapInfo = mapInfo;
	}

	public MVController addElementModel(UnspecifiedElementModel model) {
		if (!modelMapped2ViewSession.containsKey(model)) {

			modelMapped2ViewSession.put(model, new Vector<MVCViewSession>());
			elementModelMapping.put(model.getId(), model);
		}

		// Publish the new Model to the sessions
		for (MVCViewSession session : registeredViewSessions) {
			if (session.registerNewModel(model)) {
				// The Session subscribed the Element
				modelMapped2ViewSession.get(model).add(session);
			}
		}

		// Send all modeldata to the sessions
		return this;
	}

	public UnspecifiedElementModel createElement(int id, String type) {
		UnspecifiedElementModel model = new UnspecifiedElementModel(id, type);
		this.addElementModel(model);
		return model;
	}
	
	/**
	 * Updates values on the model and via MVCViewSession on a concrete view
	 * 
	 * Note: To ensure proper highlighting its necessary to make sure that the USERNAME parameter is processed first
	 * 		 This is realised in the LASADActionReceiver when iterating over the actions.
	 * 
	 * @param id
	 * @param values
	 * @return Boolean
	 */
	public boolean updateElement(int id, Vector<Parameter> values) {
		// Check if Model exists
		if (elementModelMapping.containsKey(id)) {
			// Model exists
			UnspecifiedElementModel model = elementModelMapping.get(id);
			
			// normal parameter update
			for (Parameter param : values) {

				if (model.setValue(param.getName(), param.getValue())) {
					// returns true if the model has been changed
					// Value has changed, updated subscribed Sessions
					for (MVCViewSession session : modelMapped2ViewSession.get(model)) {
						session.changeValue(model, param.getName());
					}
				}
				// Else, nothing to do
			}
			return true;
			
		} else {
			Logger.log("Tried to update non existing element with ID "+id, Logger.DEBUG_ERRORS);
			return false;
		}
	}
	
	public void deleteElement(int id, String username) {
		// Get Model
		UnspecifiedElementModel model = elementModelMapping.get(id);
		
		// Update username in model to realize highlighting of extend elements
		if(username != null){
			model.setValue("USERNAME", username);
		}
		
		deleteElement(model);
	}

	public void deleteElement(UnspecifiedElementModel model) {

		Logger.log("[MVCController]deleteElement: elementID: " + model.getId(), Logger.DEBUG);
		if (modelMapped2ViewSession.containsKey(model)) {

			// Delete Model from Sessions
			for (MVCViewSession session : modelMapped2ViewSession.get(model)) {
				session.unregisterModel(model);
			}

			// Remove from Childs
			while (model.getChildren().size() > 0) {
				// deleteElement(model.getChilds().firstElement());
				removeParent(model, model.getChildren().firstElement());

			}
			// Remove from Parents
			while (model.getParents().size() > 0) {
				model.getParents().firstElement().removeChild(model);
			}

			elementModelMapping.remove(model.getId());
			// Delete the model
			modelMapped2ViewSession.remove(model);

			model = null;
		} else {
			// Nothing to Do, the model was already deleted in the past
		}
	}

	public UnspecifiedElementModel getElement(int id) {
		return elementModelMapping.get(id);
	}
	
	public Collection<UnspecifiedElementModel> getAllElements() {
		return elementModelMapping.values();
	}

	public void registerViewSession(MVCViewSession session) {
		// Add Session
		this.registeredViewSessions.add(session);
		// Publish the managed Model to the Session
		Vector<UnspecifiedElementModel> workingModels = new Vector<UnspecifiedElementModel>();
		for (UnspecifiedElementModel model : modelMapped2ViewSession.keySet()) {
			if (session.registerNewModel(model)) {
				// Session wants to be a subscriber
				workingModels.add(model);
			}
		}
		// Subscribes the Session to the ModelElement
		for (UnspecifiedElementModel model : workingModels) {
			modelMapped2ViewSession.get(model).add(session);
		}
	}

	public void setParent(UnspecifiedElementModel child, UnspecifiedElementModel parent) {
		
		parent.addChild(child);
		
//		if (modelMapped2ViewSession.containsKey(child) && modelMapped2ViewSession.containsKey(parent)) {
//			parent.addChild(child);
//
//			// Publish the new Relations to all Sessions
//			for (MVCViewSession session : registeredViewSessions) {
//				if (session.registerNewModel(parent) && !modelMapped2ViewSession.get(parent).contains(session)) {
//					// The Session subscribed the Element
//					modelMapped2ViewSession.get(parent).add(session);
//				}
//				if (session.registerNewModel(child) && !modelMapped2ViewSession.get(child).contains(session)) {
//					// The Session subscribed the Element
//					modelMapped2ViewSession.get(child).add(session);
//				}
//			}
//		}
	}

	public void removeParent(UnspecifiedElementModel parent, UnspecifiedElementModel child) {
		// Publish this action to the sessions
		for (MVCViewSession session : registeredViewSessions) {
			Vector<UnspecifiedElementModel> unsubscribedModels = session.unregisterParent(parent, child);
			if (unsubscribedModels.size() > 0) {
				for (UnspecifiedElementModel model : unsubscribedModels) {
					modelMapped2ViewSession.get(model).remove(session);
				}
			}
		}
		parent.removeChild(child);
	}

	public int getMapID() {
		return mapInfo.getMapID();
	}

	public MapInfo getMapInfo() {
		return mapInfo;
	}

	public void setMapInfo(MapInfo mapInfo) {
		this.mapInfo = mapInfo;
	}

	public int getActualRevision() {
		return actualRevision;
	}

	public void setActualRevision(int actualRevision) {
		this.actualRevision = actualRevision;
	}

	// Event Handler/Listener Management

	public void fireLasadEvent(LasadEvent event) {
		// Publish LasadEvent to Sessions
		for (MVCViewSession session : registeredViewSessions) {
			session.fireLasadEvent(event);
		}
	}
}