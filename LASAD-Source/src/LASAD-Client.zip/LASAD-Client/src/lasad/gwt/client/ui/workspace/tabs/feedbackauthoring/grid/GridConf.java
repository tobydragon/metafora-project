package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid;

import java.util.Vector;

public class GridConf {
	
	private String Header;
	private boolean markReadyButtonFlag;
	private int markReadyStatus;
	private boolean viewButtonFlag;
	private boolean editButtonFlag;
	private boolean deleteButtonFlag;
	private boolean duplicateButtonFlag;
	private boolean addButtonFlag; //if == true, then create a tool bar with an add button having as label addButtonLabel 
	private String commonLabel;
	
	private Vector<ColumnConf> colConfigList = new Vector<ColumnConf>();
	
	public String getHeader() {
		return Header;
	}
	public void setHeader(String header) {
		Header = header;
	}
	public boolean isMarkReadyButtonFlag() {
		return markReadyButtonFlag;
	}
	public void setMarkReadyButtonFlag(boolean markReadyButtonFlag) {
		this.markReadyButtonFlag = markReadyButtonFlag;
	}
	public int getMarkReadyStatus() {
		return markReadyStatus;
	}
	public void setMarkReadyStatus(int markReadyStatus) {
		this.markReadyStatus = markReadyStatus;
	}
	public boolean isViewButtonFlag() {
		return viewButtonFlag;
	}
	public void setViewButtonFlag(boolean viewButtonFlag) {
		this.viewButtonFlag = viewButtonFlag;
	}
	public boolean isEditButtonFlag() {
		return editButtonFlag;
	}
	public void setEditButtonFlag(boolean editButtonFlag) {
		this.editButtonFlag = editButtonFlag;
	}
	public boolean isDeleteButtonFlag() {
		return deleteButtonFlag;
	}
	public void setDeleteButtonFlag(boolean deleteButtonFlag) {
		this.deleteButtonFlag = deleteButtonFlag;
	}
	public boolean isDuplicateButtonFlag() {
		return duplicateButtonFlag;
	}
	public void setDuplicateButtonFlag(boolean duplicateButtonFlag) {
		this.duplicateButtonFlag = duplicateButtonFlag;
	}
	public boolean isAddButtonFlag() {
		return addButtonFlag;
	}
	public void setAddButtonFlag(boolean addButtonFlag) {
		this.addButtonFlag = addButtonFlag;
	}
	public String getCommonLabel() {
		return commonLabel;
	}
	public void setCommonLabel(String commonLabel) {
		this.commonLabel = commonLabel;
	}
	
	public Vector<ColumnConf> getColConfigList() {
		return colConfigList;
	}
	public void setColConfigList(Vector<ColumnConf> colConfigList) {
		this.colConfigList = colConfigList;
	}
	public void addColConfig(ColumnConf colConfig) {
		if(colConfig != null)
			this.colConfigList.add(colConfig);
	}
	
	

}
