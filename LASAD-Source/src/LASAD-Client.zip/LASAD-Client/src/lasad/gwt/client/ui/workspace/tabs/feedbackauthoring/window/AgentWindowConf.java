package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.window;

import java.util.List;

import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.OntologyFA;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.FeedbackAuthoringStrings;


public class AgentWindowConf {
	private String title = FeedbackAuthoringStrings.HEADING_ADD_NEW_AGENT;
	private int mode = AgentWindow.ADD_MODE;
	private List<OntologyFA> ontologyList;
	
	public AgentWindowConf(String title, int mode, List<OntologyFA> ontologyList) {
		super();
		this.title = title;
		this.mode = mode;
		this.ontologyList = ontologyList;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getMode() {
		return mode;
	}

	public void setMode(int mode) {
		this.mode = mode;
	}

	public List<OntologyFA> getOntologyList() {
		return ontologyList;
	}

	public void setOntologyList(List<OntologyFA> ontologyList) {
		this.ontologyList = ontologyList;
	}
	
}
