package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public class SessionUserActionEventImpl extends UserActionEventImpl {
	
	public SessionUserActionEventImpl(String session, String agent) {
		addProperty(ActionUserEventProperty.session, session);
		addProperty(ActionUserEventProperty.agent, agent);
	}

}
