package lasad.gwt.client.ui.common;

public interface FocusableInterface {
	
	public void setElementFocus(boolean focus);
	
	public FocusableInterface getFocusParent();
	
}
