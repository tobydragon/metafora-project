package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.window;

import java.util.List;

import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.FeedbackAuthoringTabContent;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.AddAgentToOntologyEvent;


public class AddAgent2Ontology extends SelectAgentWindow {

	public AddAgent2Ontology(List<String> agentList, String helper, FeedbackAuthoringTabContent td) {
		super(agentList, helper, td);
	}

	@Override
	public void doAction(String agentName, String helper) {
		//getFATabRef().handleAddAgentToOntologyEvent(agentName, helper);
		getFATabRef().handleUserActionEvent(new AddAgentToOntologyEvent(helper, agentName));
	}

}
