package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid;

import java.util.Vector;

import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.ElementModel;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.FATConstants;

import com.extjs.gxt.ui.client.Style.HorizontalAlignment;
import com.extjs.gxt.ui.client.Style.Orientation;
import com.extjs.gxt.ui.client.Style.Scroll;
import com.extjs.gxt.ui.client.data.ModelData;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.ComponentEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.store.ListStore;
import com.extjs.gxt.ui.client.util.Margins;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.Info;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.button.ToolButton;
import com.extjs.gxt.ui.client.widget.form.TextField;
import com.extjs.gxt.ui.client.widget.grid.CellEditor;
import com.extjs.gxt.ui.client.widget.grid.ColumnConfig;
import com.extjs.gxt.ui.client.widget.grid.ColumnModel;
import com.extjs.gxt.ui.client.widget.grid.Grid;
import com.extjs.gxt.ui.client.widget.grid.GridCellRenderer;
import com.extjs.gxt.ui.client.widget.grid.RowEditor;
import com.extjs.gxt.ui.client.widget.layout.FillLayout;
import com.extjs.gxt.ui.client.widget.layout.RowData;
import com.extjs.gxt.ui.client.widget.toolbar.ToolBar;
import com.google.gwt.user.client.ui.Widget;

public class RowEditorGrid {
	
//	private ContentPanel panel;
	private GridConf gridConf;
	private ListStore<ElementModel> gridStore = new ListStore<ElementModel>();
	
	public RowEditorGrid(GridConf gridConf){
//		super(new FitLayout());
//		this.setBodyBorder(false);
//	    setHeaderVisible(false);
		//setBorders(false);
//		setFrame(true);
//	    setAutoHeight(true);
	    //setAutoWidth(true);
	    this.gridConf = gridConf;
	}

//	@Override  
//	  protected void onRender(Element parent, int index) {  
//	    super.onRender(parent, index);
//	    //this.add(createGridPanel());
//	    
//	    layout();
//	    
//	    
//		
////	    createGridPanel();
//	    add(createGridPanel());//, new FitData());
//		layout();
//	    
//	}
	
	
	private void addElement(String name, String description){
		ElementModel elem = new ElementModel();
		elem.set("name", name);
		elem.set("status", description);
		gridStore	.insert(elem, 0);
	}
	
	public ContentPanel createGridPanel(){
		
		ContentPanel panel = new ContentPanel();
//		panel.setLayout(new FitLayout());
		panel.setHeading(gridConf.getHeader());
		panel.setScrollMode(Scroll.AUTOY);
//	    panel.setSize("100%", "100%");
//	    panel.setAutoHeight(true);
//	    panel.setHeight(400);
//	    panel.setAutoWidth(true);;
//		panel.setBodyBorder(false);
//		panel.setBorders(false);
		panel.getHeader().addTool(new ToolButton("x-tool-close"));
		
		final RowEditor<ElementModel> rowEditor = new RowEditor<ElementModel>();
		
		if (gridConf.isAddButtonFlag()){
			Button buttonAdd = new Button("ADD" + " " + gridConf.getCommonLabel()){
				@Override
				public void onClick(ComponentEvent ce) {
					Info.display("Add button", "pressed");
					System.out.println("ADD" + " " + gridConf.getCommonLabel() + " Button pressed");
					rowEditor.stopEditing(false);
					ElementModel elem = new ElementModel();
					elem.set("name", "12");
					elem.set("status", "Orientation");
					gridStore.insert(elem, 0);
					rowEditor.startEditing(gridStore.indexOf(elem), true);
					
				}
			};
			
			buttonAdd.setIconStyle("icon-plus-circle");//## icon-round-add
			ToolBar toolBar = new ToolBar();
			toolBar.setAlignment(HorizontalAlignment.RIGHT);
			toolBar.add(buttonAdd);
			panel.setTopComponent(toolBar);
		}
		
		
		final Vector<ColumnConf> colConfigList = gridConf.getColConfigList();
		Vector<ColumnConfig> colList = new Vector<ColumnConfig>();
		
		int colWidthSum = 0;
		for(ColumnConf colConf: colConfigList){
			ColumnConfig tmpCol = new ColumnConfig(colConf.getId(), "<div style=\"color:#000000;\">" + 
									colConf.getLabel() + "</div>", colConf.getWidth());
			colWidthSum += colConf.getWidth();
			if (colConf.getType() == FATConstants.TEXT_TYPE){
				TextField<String> text = new TextField<String>();  
			    text.setAllowBlank(false);  
			    tmpCol.setEditor(new CellEditor(text));
			}
			colList.add(tmpCol);
		}
		
		ColumnConfig actionsCol = colList.lastElement();
		actionsCol.setRenderer(new GridCellRenderer(){
			
			@Override
			public Widget render(ModelData model, String property,
					com.extjs.gxt.ui.client.widget.grid.ColumnData config,
					int rowIndex, int colIndex, ListStore store, Grid grid) {
				
				return getActionButtonsPanel(model, property, config, rowIndex, colIndex, store, grid);
			}
			
			private ContentPanel getActionButtonsPanel(final ModelData model, String property,
					com.extjs.gxt.ui.client.widget.grid.ColumnData config,
					final int rowIndex, int colIndex, final ListStore store, Grid grid){
				ContentPanel panelButtons = new ContentPanel();
				panelButtons.setLayout(new FillLayout(Orientation.HORIZONTAL));
				panelButtons.setHeaderVisible(false);
				panelButtons.setBodyBorder(false);
				panelButtons.setLayoutOnChange(true);
				panelButtons.setBodyStyle("backgroundColor: transparent;");
				
				Button deleteButton = new Button();
				
				deleteButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
//				    	  String id = (String) model.get(colConfigList.get(0).getId());
//				    	  String desc = (String) model.get(colConfigList.get(1).getId());
//				    	  ElementModel tmp = (ElementModel) store.getAt(rowIndex);
//				    	  ElementModel elem = new ElementModel();
//				    	  elem.set("name", id);
//				    	  elem.set("status", desc);
				    	  store.remove(rowIndex);
				    	  //ElementModel bm = agentsGrid.getStore().findModel("name", element);
				    	  //agentsGrid.getStore().remove(bm);
				    	  //deleteElement(element);
				    	  
				    	  //Info.display((String) model.get(colConfigList.get(0).getId()), "<ul><li>" + model.get(colConfigList.get(0).getLabel()) + "</li></ul>");
				    	  Info.display("Delete button", "pressed");
				      }
				});
				
				deleteButton.setStyleName("xfa-btn");
				deleteButton.setStyleName("x-btn-text", true);
				deleteButton.setStyleName("x-btn", true);
				deleteButton.setStylePrimaryName("xfa-btn");
				deleteButton.setIconStyle("icon-delete-circle");
				deleteButton.setWidth(16);
				deleteButton.setHeight(16);
				deleteButton.setMinWidth(16);
				deleteButton.setToolTip("Delete " + gridConf.getCommonLabel());
				
				//display buttons.
				if(gridConf.isDeleteButtonFlag()){
					panelButtons.add(deleteButton, new RowData(0.25, 0.25, new Margins(0)));
				}

				return panelButtons;
			}

		});
		
		ColumnModel activeSessionsCM = new ColumnModel(colList);
		Grid<ElementModel> grid = new Grid<ElementModel>(gridStore, activeSessionsCM);
		
		CustomizedGridView agetsGridView = new CustomizedGridView();
		grid.setView(agetsGridView);
		grid.setLazyRowRender(0);
		
		//grid.setAutoExpandColumn("name");
		grid.setHideHeaders(true);
	    grid.setBorders(false);
	    grid.setAutoExpandColumn("name");//colConfigList.get(1).getId()
	    grid.setAutoExpandMax(500);
	    grid.setAutoWidth(true);
	    grid.setHeight(400);
	    grid.addPlugin(rowEditor);
//	    grid.setSize("100%", "100%");
//	    grid.setAutoHeight(true);
//	    grid.setAutoWidth(true);
//	    grid.getAriaSupport().setLabelledBy(panel.getHeader().getId() + "-label");
	    grid.setTrackMouseOver(true);
	    grid.getSelectionModel().setLocked(true);
	    grid.setStripeRows(true);
	    
	    panel.add(grid);//, new FitData()
		
		return panel;
	}
	
}
