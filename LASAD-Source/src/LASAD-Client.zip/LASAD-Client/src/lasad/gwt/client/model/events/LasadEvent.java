package lasad.gwt.client.model.events;

import lasad.gwt.client.model.MVCViewSession;

public class LasadEvent {

	private MVCViewSession session = null;
	private String type;
	private Object data = null;

	public LasadEvent() {};

	public LasadEvent(MVCViewSession session) {
		this.session = session;
	}

	public MVCViewSession getSession() {
		return session;
	}

	public void setSession(MVCViewSession session) {
		this.session = session;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
}