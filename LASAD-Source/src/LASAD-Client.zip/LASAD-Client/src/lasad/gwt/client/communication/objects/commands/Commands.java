package lasad.gwt.client.communication.objects.commands;

public enum Commands{
	AddMapToList, AddTemplateToList, AddUserToList, AuthoringFailed, ConfirmationRequest, DeleteElement, DeleteMapFromList, DeleteOntologyFromList, DeleteTemplateFromList, DeleteUserFromList, EmptyMap, Error, ErrorInfo, ForcedLogout, HeartbeatRequest, Info, InitEnd, InitStart, Join, Leave, ListMap, ListOntologies, ListUsers, Login, LoginFailed, Logout, MapDetails, NoMap, NoUser, Ontology, OntologyCreated, OntologyDetails, Ready, SessionCreated, TemplateCreated, TemplateDetails, TemplateListElement, UpdateElement, UserCreated, UserJoin, UserLeave, UserList, None,
	CreateElement, ImportFinished, ChatMsg, GetTemplates, CreateTemplate, DeleteTemplate, GetOntologies, GetOntologyDetails, CreateOntology, DeleteOntology, UpdateOntology, GetMapsAndTemplates, CreateMap, DeleteMap, GetUsers, CreateUser, DeleteUser, Highlight, Request, List, GetAllOntologiesAndTemplates, GetOntology, CreateAndJoin, JoinComplete, Import, UpdateCursorPosition, Undo, 
	NoAction, Start, SaveLocal, Heartbeat, GetAnswer, AddAnswer, Load, Answer, 
}
