package lasad.gwt.client.ui.workspace.tableview;

import com.google.gwt.user.client.ui.FlexTable;

public class TableCellInfo {

	//*************************************************************************************
	//	Fields
	//*************************************************************************************
	
	private ArgumentMapTable map;
	private FlexTable flexTable;
	
	private int rowNumber;
	private int colNumber;
	
	//*************************************************************************************
	//	Constructor
	//*************************************************************************************

	public TableCellInfo(ArgumentMapTable map, FlexTable flexTable) {
		this.map = map;
		this.flexTable = flexTable;
	}


	public TableCellInfo(ArgumentMapTable map, FlexTable flexTable, int rowNumber, int colNumber) {
		this.map = map;
		this.flexTable = flexTable;
		this.rowNumber = rowNumber;
		this.colNumber = colNumber;
	}

	
	//*************************************************************************************
	// getter & setter
	//*************************************************************************************
	
	public ArgumentMapTable getMap() {
		return map;
	}

	public void setMap(ArgumentMapTable map) {
		this.map = map;
	}

	public FlexTable getFlexTable() {
		return flexTable;
	}

	public void setFlexTable(FlexTable flexTable) {
		this.flexTable = flexTable;
	}

	public int getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}

	public int getColNumber() {
		return colNumber;
	}

	public void setColNumber(int colNumber) {
		this.colNumber = colNumber;
	}
	
}
