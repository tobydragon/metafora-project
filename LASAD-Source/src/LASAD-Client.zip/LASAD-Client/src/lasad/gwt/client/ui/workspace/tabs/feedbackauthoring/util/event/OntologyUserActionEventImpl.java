package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public abstract class OntologyUserActionEventImpl extends UserActionEventImpl {

	public OntologyUserActionEventImpl(String ontology, String agent) {
		addProperty(ActionUserEventProperty.ontology, ontology);
		addProperty(ActionUserEventProperty.agent, agent);
	}

}
