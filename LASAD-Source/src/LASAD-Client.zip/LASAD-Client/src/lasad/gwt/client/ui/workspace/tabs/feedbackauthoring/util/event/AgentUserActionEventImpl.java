package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public class AgentUserActionEventImpl extends UserActionEventImpl {

	public AgentUserActionEventImpl(String agent) {
		// TODO Auto-generated constructor stub
	}

}
