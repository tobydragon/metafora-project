package lasad.gwt.client.ui.workspace.tableview;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import lasad.gwt.client.communication.LASADActionSender;
import lasad.gwt.client.communication.objects.ActionFactory;
import lasad.gwt.client.logger.Logger;
import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.model.MVCViewRecipient;
import lasad.gwt.client.model.MVCViewSession;
import lasad.gwt.client.model.UnspecifiedElementModel;
import lasad.gwt.client.ui.workspace.tableview.elements.RatingElement;
import lasad.gwt.client.ui.workspace.tableview.elements.TextElement;
import lasad.gwt.client.ui.workspace.tableview.elements.TranscriptElement;
import lasad.gwt.client.ui.workspace.tableview.elements.UrlElement;

import com.extjs.gxt.ui.client.Style.Scroll;
import com.extjs.gxt.ui.client.event.BaseEvent;
import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.event.IconButtonEvent;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.util.Margins;
import com.extjs.gxt.ui.client.util.Point;
import com.extjs.gxt.ui.client.util.Size;
import com.extjs.gxt.ui.client.widget.Component;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.LayoutContainer;
import com.extjs.gxt.ui.client.widget.button.IconButton;
import com.extjs.gxt.ui.client.widget.button.ToolButton;
import com.extjs.gxt.ui.client.widget.layout.FitData;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.extjs.gxt.ui.client.widget.layout.RowData;
import com.extjs.gxt.ui.client.widget.layout.RowLayout;
import com.google.gwt.user.client.Event;

/**
 * A Component with child components(text, user, ...) for the Relation, which is created with 
 * an Element and a Relation. 
 * 
 * @author erkang
 *
 */
public class RelatedRelation extends ContentPanel implements MVCViewRecipient, CellContainer{

	//*************************************************************************************
	//	Fields
	//*************************************************************************************
	
	private final ActionFactory actionFactory = ActionFactory.getInstance();
	private final LASADActionSender actionSender = LASADActionSender.getInstance();
	
	private UnspecifiedElementModel model;
	private ElementInfo info;
	
	private TableCellTypeEnum type;
	private TableZoomEnum zoom;
	private Size size;
	
	private LayoutContainer cellBody;
	private TableCellInfo tableCellInfo;
	
	private String rootElementId;
//	private boolean editMode;
	
	private String color;
	
	private MVCViewSession session;
	
	//*************************************************************************************
	//	Constructor
	//*************************************************************************************
	
	public RelatedRelation(final ElementInfo info, TableCellTypeEnum type) {
		
		this.info = info;
		this.type = type;
		
		setBodyBorder(false);
		setLayout(new FitLayout());
		setCollapsible(true);
		
		//***********************
		// Header
		//***********************
		setHeading(info.getElementOption("heading"));
		getHeader().setStyleAttribute("background", info.getUiOption("background-color"));
		getHeader().setStyleAttribute("color", info.getUiOption("font-color"));

		color = info.getUiOption("background-color");
		
		//***********************
		// Body
		//***********************
		cellBody = new LayoutContainer();
		cellBody.setLayout(new RowLayout());
		cellBody.setBorders(false);
		cellBody.setScrollMode(Scroll.AUTOY);
//		cellBody.setEnabled(false);
		
		add(cellBody, new FitData(1));
		
		//***********************
		// Bottom Bar
		//***********************
		AwarenessElement awarenessElement = new AwarenessElement(new ElementInfo());
		awarenessElement.setHeight(20);
		awarenessElement.setVisible(true);
		setBottomComponent(awarenessElement);
		
	}
	
	@Override
	protected void afterRender() {
		super.afterRender();
		
		Listener<BaseEvent> listener = new Listener<BaseEvent>() {
			
			@Override
			public void handleEvent(BaseEvent be) {
				
				if (be.getType().equals(Events.OnMouseMove)) {
					
					setupToolButtons();
				}
				
				if (be.getType().equals(Events.OnMouseOut)) {
					
					hideToolButtons();
				}
			}
		};
		
		el().addEventsSunk(Event.ONMOUSEMOVE);
		el().addEventsSunk(Event.ONMOUSEOUT);
		addListener(Events.OnMouseMove, listener);
		addListener(Events.OnMouseOut, listener);
		
	}
	
	
	public void setDefaultSize(TableZoomEnum zoom) {
		
		this.zoom = zoom;
		size = ArgumentMapTable.cellSize.get(zoom);
		setSize(size.width, size.height);
	}
	
	//*************************************************************************************
	//	Methods
	//*************************************************************************************
	
	public void setupToolButtons() {
		
		removeAllTools();
		
		initXButton();
		initHelpButton();
		
	}
	
	
	private void hideToolButtons() {
		
		for(int i= 0; i < getHeader().getToolCount() ; i++) {
			getHeader().getTool(i).setVisible(false);
		}
	}
	
	
	private void removeAllTools() {
		
		List<Component> buttons = new ArrayList<Component>();
		
		for(int i= 0; i < getHeader().getToolCount() ; i++) {
			buttons.add(getHeader().getTool(i));
		}
		
		for (Component button: buttons) {
			
			getHeader().removeTool(button);
		}
		
	}
	
	
	private void initXButton() {
		
		ToolButton xButton = new ToolButton("x-tool-close", new SelectionListener<IconButtonEvent>() {

			@Override
			public void componentSelected(IconButtonEvent ce) {
				
				Logger.log("===== X button model id = " + model.getId() + " =====", Logger.DEBUG_DETAILS);
				
				if (tableCellInfo.getMap().isDeleteElementsWithoutConfirmation()) {
					
					//*************************************************************************************
					//	ACTIONPACKAGE: 
					//		ACTION: 
					//			Category: MAP
					//			Command: REMOVE-ELEMENT
					//			Parameter: MAP-ID : 49
					//			Parameter: ID : 7
					//*************************************************************************************
					
					int mapId = Integer.parseInt(model.getValue("MAP-ID"));
					int modelId = model.getId();
					
					actionSender.sendActionPackage(actionFactory.removeElement(mapId, modelId));
					

				} else {		

					IconButton button = ce.getIconButton();
					Point point = button.getPosition(false);
					
					final BoxClosePopup popup = new BoxClosePopup();
					popup.showAt(point.x, point.y);
					
					
					if (getParent() instanceof RelatedRelationDialog) {
						
						RelatedRelationDialog dialog = (RelatedRelationDialog)getParent();
						dialog.setEnabled(false);
					
						popup.addListener(Events.Hide, new Listener<BaseEvent>() {

							@Override
							public void handleEvent(BaseEvent be) {
								RelatedRelationDialog dialog = (RelatedRelationDialog)getParent();
								dialog.setEnabled(true);
								
								Boolean isClose = popup.isClose();
								Boolean conformChecked = popup.getConform().getValue();
								
								if (isClose) {
									
									int mapId = Integer.parseInt(model.getValue("MAP-ID"));
									int modelId = model.getId();
									
									actionSender.sendActionPackage(actionFactory.removeElement(mapId, modelId));
									
								}
								
								tableCellInfo.getMap().setDeleteElementsWithoutConfirmation(conformChecked);
								
							}
						});
					} 
				}
			}
		});
		
		getHeader().addTool(xButton);
		
	}
	
	
	private void initHelpButton() {
		
		if (TableCellTypeEnum.RELEATION == type) {
			
			Vector<UnspecifiedElementModel> children = model.getChildren();
			final Vector<UnspecifiedElementModel> relatedRelationModels = new Vector<UnspecifiedElementModel>();
			
			for (UnspecifiedElementModel m: children) {
				
				if (m.getParents().size() == 2 && m.getParents().get(1) == model) {
					
					relatedRelationModels.add(m);
				}
				
			}
			
			ToolButton helpButton = new ToolButton("x-tool-help", new SelectionListener<IconButtonEvent>() {

				@Override
				public void componentSelected(IconButtonEvent ce) {
					
					setEnabled(false);
					
					RelatedRelationDialog dialog = new RelatedRelationDialog(relatedRelationModels, session);
					dialog.setPosition(ce.getClientX() + 10, ce.getClientY() + 10);
					dialog.addListener(Events.Hide, new Listener<BaseEvent>() {

						@Override
						public void handleEvent(BaseEvent be) {
							setEnabled(true);
//							cellBody.setEnabled(false);
						}
					
					});
				}
				
			});
			
			if (relatedRelationModels.size() > 0) {
				
				getHeader().addTool(helpButton);
			}
			
		}
	}
	
	private int calElementPosition(String newChildElementID){

		if(cellBody.getItemCount() == 0){
			return 0;
		}

		// Calculate ElementID before
		String beforeElementID = "";
		for (String tempElementID: info.getChildElements().keySet()) {
			if (!tempElementID.equals(newChildElementID)) {
				
				for(Component component : cellBody.getItems()){	
					if (component instanceof TextElement) {
						TextElement tempElement = (TextElement)component;
						if(tempElement.getConnectedModel().getElementid().equals(tempElementID)){
							beforeElementID = tempElementID;
							break;
						}
					}
					
				}
			}
			else{
				break;
			}
		}

		// Calculate new Position
		int pos = 0;
		boolean elementIDreached = false;
		boolean beforeElementIDreached = false;
		for(Component component : cellBody.getItems()){
			if (component instanceof TextElement) {
				
				TextElement tempElement = (TextElement)component;
				String tempElementID = tempElement.getConnectedModel().getElementid();		

				if(beforeElementID.equals(tempElementID)){
					beforeElementIDreached= true;
					pos++;
					continue;
				}

				if(beforeElementIDreached && !tempElementID.equals(beforeElementID)){
					break;
				}

				if(tempElementID.equals(newChildElementID)){
					elementIDreached=true;
					pos++;
					continue;
				}

				if(elementIDreached && !tempElementID.equals(newChildElementID)){
					break;
				}

				pos++;
			}
		}
		return pos;
	}

	
	//*************************************************************************************
	//  add by Erkang:  display Argument with another ViewSession
	//
	//  ACTION: 
	//		Category: MAP
	//		Command: CREATE-ELEMENT
	//		Parameter: ID : 7
	//		Parameter: TYPE : box
	//		Parameter: USERNAME : t1
	//		Parameter: MAP-ID : 49
	//		Parameter: ELEMENT-ID : fact
	//		Parameter: POS-X : 2772
	//		Parameter: POS-Y : 2747
	//		Parameter: USERACTION-ID : xrlcfgk49z7u1277471052924
	//		Parameter: NUM-ACTIONS : 3
	//		Parameter: ROOTELEMENTID : 1
	//
	//*************************************************************************************
	
	//*************************************************************************************
	// methods of Inteface MVCViewRecipient
	//*************************************************************************************
	
	@Override
	public void changeValueMVC(UnspecifiedElementModel model, String vname) {
		
		if (vname.equals("ROOTELEMENTID")) {
			rootElementId = model.getValue("ROOTELEMENTID");
			
			// UI View
			if (zoom != TableZoomEnum.SIZE25) {
				
				setHeading(rootElementId + " . " + getHeading());
				
			} else {
				
				setHeading(rootElementId);
			}
		}
		
	}

	@Override
	public void deleteModelConnection(UnspecifiedElementModel model) {
		
//		removeFromParent();		
	}

	@Override
	public boolean establishModelConnection(UnspecifiedElementModel model) {
		
		if (this.model == null) {
			this.model = model;
			return true;
		}
		else{
			return false;
		}
	}
	

	@Override
	public UnspecifiedElementModel getConnectedModel() {
		return model;
	}

	
	//*************************************************************************************
	// CellContainer
	//*************************************************************************************

	@Override
	public MVCViewRecipient addComponent(String type, String id) {
		
		RowData areaElementData = new RowData(0.95, 1, new Margins(1, 0, 1, 12));
		RowData otherElementData = new RowData(0.95, 18, new Margins(1, 0, 1, 12));
		
		if ("awareness".equalsIgnoreCase(type)) {
			
			// UI View
			if (zoom != TableZoomEnum.SIZE25) {
				
				getBottomComponent().setVisible(true);
			}
			
			MVCViewRecipient recipient = (MVCViewRecipient)getBottomComponent();
			
			return recipient;
			
		} else if ("text".equalsIgnoreCase(type)) {
			
			ElementInfo childInfo = info.getChildElements().get(id);
			TextElement textElement = new TextElement(childInfo);
			textElement.setArgumentMapTable(tableCellInfo.getMap());
			textElement.setReadOnly(true);
			
			cellBody.insert(textElement, calElementPosition(id));
			
			if ("textfield".equalsIgnoreCase(textElement.getTexttype())) {
				
				cellBody.setLayoutData(textElement, otherElementData);
			} else {
				
				cellBody.setLayoutData(textElement, areaElementData);
			}
			
			cellBody.layout();
			
			
			// UI View
			if (getParent() instanceof RelatedRelationDialog) {
				
				cellBody.setVisible(true);
				
			} else {
				
				if (zoom == TableZoomEnum.SIZE100) {
					cellBody.setVisible(true);
				} else {
					cellBody.setVisible(false);
				}
			}
			
			return textElement;
			
		} else if ("rating".equalsIgnoreCase(type)) {
			
			ElementInfo childInfo = info.getChildElements().get(id);
			RatingElement ratingElement = new RatingElement(childInfo);
			ratingElement.setArgumentMapTable(tableCellInfo.getMap());
			ratingElement.setReadOnly(true);
			
			cellBody.insert(ratingElement, calElementPosition(id));
			cellBody.setLayoutData(ratingElement, otherElementData);
			cellBody.layout();
			
			return ratingElement;
			
		} else if ("url".equalsIgnoreCase(type)) {
			
			ElementInfo childInfo = info.getChildElements().get(id);
			UrlElement urlElement = new UrlElement(childInfo);
			urlElement.setArgumentMapTable(tableCellInfo.getMap());
			urlElement.setReadOnly(true);
			
			cellBody.insert(urlElement, calElementPosition(id));
			cellBody.setLayoutData(urlElement, otherElementData);
			cellBody.layout();
			
			return urlElement;
			
		} else if ("transcript-link".equalsIgnoreCase(type)) {
			
			ElementInfo childInfo = info.getChildElements().get(id);
			TranscriptElement transcriptElement = new TranscriptElement(childInfo);
			transcriptElement.setArgumentMapTable(tableCellInfo.getMap());
			transcriptElement.setReadOnly(true);
			
			cellBody.insert(transcriptElement, calElementPosition(id));
			cellBody.setLayoutData(transcriptElement, otherElementData);
			cellBody.layout();
			
			return transcriptElement;
			
		} else {
			
			
		}
		
		
		return null;
	}

	
	
	@Override
	public void removeComponent(UnspecifiedElementModel model) {
		
		List<Component> components = cellBody.getItems();
		
		for (Component component : components) {
			
			if (component instanceof MVCViewRecipient) {
				
				MVCViewRecipient recipient = (MVCViewRecipient)component;
				UnspecifiedElementModel elementModel = recipient.getConnectedModel();
				
				if (model.equals(elementModel)) {
					
					cellBody.remove(component);
					cellBody.layout();
					
					break;
				}
				
			}
		}
		
	}

	
	public TableCellInfo getTableCellInfo() {
		return tableCellInfo;
	}


	public void setTableCellInfo(TableCellInfo tableCellInfo) {
		this.tableCellInfo = tableCellInfo;
	}

	
	
	public void changeView(TableZoomEnum zoom) {
		
	}
	
	
	//*************************************************************************************
	// getter & setter
	//*************************************************************************************
	
	@SuppressWarnings("unchecked")
	public UnspecifiedElementModel getModel() {
		return model;
	}


	public void setModel(UnspecifiedElementModel model) {
		this.model = model;
	}


	/**
	 * @return the info
	 */
	public ElementInfo getInfo() {
		return info;
	}


	/**
	 * @param info the info to set
	 */
	public void setInfo(ElementInfo info) {
		this.info = info;
	}



	public Size getInitSize() {
		
		return size;
		
	}


	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}


	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}



	/**
	 * @return the type
	 */
	public TableCellTypeEnum getType() {
		return type;
	}



	/**
	 * @param type the type to set
	 */
	public void setType(TableCellTypeEnum type) {
		this.type = type;
	}



	/**
	 * @return the session
	 */
	public MVCViewSession getSession() {
		return session;
	}



	/**
	 * @param session the session to set
	 */
	public void setSession(MVCViewSession session) {
		this.session = session;
	}

}
