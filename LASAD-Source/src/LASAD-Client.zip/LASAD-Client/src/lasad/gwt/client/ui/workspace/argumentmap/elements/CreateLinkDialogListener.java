package lasad.gwt.client.ui.workspace.argumentmap.elements;

import lasad.gwt.client.communication.LASADActionSender;
import lasad.gwt.client.communication.helper.ActionFactory;
import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.ui.box.Box;
import lasad.gwt.client.ui.link.Link;
import lasad.gwt.client.ui.workspace.argumentmap.ArgumentMap;
import lasad.shared.communication.objects.parameters.ParameterTypes;

import com.extjs.gxt.ui.client.event.Events;
import com.google.gwt.dom.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;



public class CreateLinkDialogListener implements EventListener {

    private final LASADActionSender communicator = LASADActionSender.getInstance();
    private final ActionFactory actionBuilder = ActionFactory.getInstance();

    private ArgumentMap myMap;
    private CreateLinkDialog myDialogue;
    private Box b1, b2;
    private Link l1, l2;

    public CreateLinkDialogListener(ArgumentMap map, CreateLinkDialog dialogue, Box b1, Box b2) {
	this.myMap = map;
	this.myDialogue = dialogue;
	this.b1 = b1;
	this.b2 = b2;
    }

    public CreateLinkDialogListener(ArgumentMap map, CreateLinkDialog dialogue, Box b1, Link l2) {
	this.myMap = map;
	this.myDialogue = dialogue;
	this.b1 = b1;
	this.l2 = l2;
    }

    public void onBrowserEvent(Event be) {
	if (be.getTypeInt() == Events.OnMouseOver.getEventCode()) {
	    handleMouseOver(be);
	} else if (be.getTypeInt() == Events.OnClick.getEventCode()) {
	    handleOnClick(be);
	} else if (be.getTypeInt() == Events.OnMouseOut.getEventCode()) {
	    handleMouseOut(be);

	}
	be.stopPropagation();
    }

    private void handleOnClick(Event be) {
	for (ElementInfo info : myMap.getMyViewSession().getController().getMapInfo().getElementsByType("relation").values()) {
	    if (((Element) be.getEventTarget().cast()).getInnerText().equals(info.getElementOption(ParameterTypes.Heading))) {

		// Send Action --> Server
		if (b1 != null && b2 != null) {
		    communicator.sendActionPackage(actionBuilder.createLinkWithElements(info, myMap.getID(), b1.getConnectedModel().getId() + "", b2.getConnectedModel().getId() + ""));
		} else if (b1 != null && l2 != null) {
		    communicator.sendActionPackage(actionBuilder.createLinkWithElements(info, myMap.getID(), b1.getConnectedModel().getId() + "", l2.getConnectedModel().getId() + ""));
		}
	    }
	}
	myDialogue.removeFromParent();
    }

    private void handleMouseOut(Event be) {
	// End hover effect
	if (((Element) be.getEventTarget().cast()).getClassName().equals("dialog-text-highlighted")) {
	    ((Element) be.getEventTarget().cast()).setClassName("dialog-text");
	}
    }

    private void handleMouseOver(Event be) {
	// Start hover effect
	if (((Element) be.getEventTarget().cast()).getClassName().equals("dialog-text")) {
	    ((Element) be.getEventTarget().cast()).setClassName("dialog-text-highlighted");
	}
    }
}