package lasad.gwt.client.ui.workspace.feedback;

import java.util.HashMap;

import lasad.gwt.client.LASAD_Client;
import lasad.gwt.client.model.MVController;
import lasad.gwt.client.ui.workspace.AbstractArgumentMap;

import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.EventListener;

public class FeedbackPanel extends ContentPanel {
	AbstractArgumentMap myMap = null;
	MVController controller = null;
	
	public MVController getController() {
		if(controller == null) {
			LASAD_Client.getMVCController(myMap.getID());
		}
		return controller;
	}

	public void setController(MVController controller) {
		this.controller = controller;
	}

	public AbstractArgumentMap getMyMap() {
		return myMap;
	}

	public void setMyMap(AbstractArgumentMap myMap) {
		this.myMap = myMap;
	}

	HashMap<Integer, Element> clusterToMessage = new HashMap<Integer, Element>();

	public FeedbackPanel(AbstractArgumentMap map) {
		this.myMap = map;

		this.setHeading("Feedback");

		this.setBodyBorder(false);
			
		controller = LASAD_Client.getMVCController(myMap.getID());
	}

	Element chat = null;
	EventListener domListener = null;

	private void buildGUI() {
		chat = DOM.createDiv();
		chat.setClassName("chatChat-div");

		this.getBody().appendChild(chat);
		DOM.setStyleAttribute(this.getBody().dom, "position", "relative");

		Element textFieldDummy = DOM.createDiv();
		textFieldDummy.setClassName("chatTextField-div");
		this.getBody().appendChild(textFieldDummy);
	}

	public void addFeedbackMessage(int clusterID, String feedback) {
		Element messageFrame = DOM.createDiv();
		messageFrame.setClassName("chatChatMessageFrame");
		DOM.appendChild(chat, messageFrame);

		// Name
		Element chatMessage = DOM.createDiv();
		chatMessage.setClassName("feedbackText-div");
		chatMessage.setInnerHTML(feedback + "<br>");
		DOM.appendChild(messageFrame, chatMessage);

		DOM.scrollIntoView(messageFrame);

		clusterToMessage.put(clusterID, messageFrame);
		
		FeedbackPanelListener myListener = new FeedbackPanelListener(this, clusterID);
		DOM.sinkEvents(chatMessage, Events.OnClick.getEventCode() | Events.OnContextMenu.getEventCode() | Events.OnMouseOver.getEventCode() | Events.OnMouseOut.getEventCode());
		DOM.setEventListener(chatMessage, myListener);
	}

	public void removeFeedbackMessage(int clusterID) {
		Element msg = null;
		if (clusterToMessage.get(clusterID) != null) {
			msg = clusterToMessage.get(clusterID);
		}

		try {
			DOM.removeChild(chat, msg);
		} catch (Exception E) {}

		clusterToMessage.remove(clusterID);
	}

	protected void afterRender() {
		super.afterRender();

		buildGUI();
	}
}