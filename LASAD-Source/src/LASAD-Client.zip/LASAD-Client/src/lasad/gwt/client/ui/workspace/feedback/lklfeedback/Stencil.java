/**
 *
 */
package lasad.gwt.client.ui.workspace.feedback.lklfeedback;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import lasad.gwt.client.ui.workspace.feedback.lklfeedback.CallOut.Point;


import com.google.gwt.canvas.client.Canvas;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.ComplexPanel;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

/**
 * Implements a 'stencil' which blocks all UI events except those widgets that are 'holes' in the stencil
 * The stencil uses a semi-transparent mask.
 * Holes are implemented by moving the hole widgets on top of the stencil.
 *
 * Loosely based upon uk.ac.lkl.common.ui.jft.Stencil
 *
 * @author Ken Kahn
 *
 */
public class Stencil extends AbsolutePanel {
   
    private ArrayList<Widget> holes = new ArrayList<Widget>();
   
    private FeedbackCanvas mask = null;
   
    private CallOut callOut = null;
   
    private class HolePosition {
        private Widget parent;
        private int index;
        private int left;
        private int top;
        private Widget holeReplacement;
        public HolePosition(Widget parent, int index, int left, int top, Widget holeReplacement) {
            this.parent = parent;
            this.index = index;
            this.left = left;
            this.top = top;
            this.holeReplacement = holeReplacement;
        }
        public Widget getParent() {
            return parent;
        }
        public int getIndex() {
            return index;
        }
        public int getLeft() {
            return left;
        }
        public int getTop() {
            return top;
        }
        public Widget getHoleReplacement() {
            return holeReplacement;
        }
    }
   
    private HashMap<Widget, HolePosition> holePositions = new HashMap<Widget, HolePosition>();
   
    public Stencil() {
        super();
        mask = new FeedbackCanvas(Canvas.createIfSupported());          
//      mask.setStylePrimaryName("feedback-stencil-mask");
    }
   
    @Override
    public void onLoad() {
        super.onLoad();
        fullSize();
    }
   
    public void testCallOuts() {
        // put a pink dialogue with an OK button on the call out panel
        final CallOut testCallOut = new CallOut();
        VerticalPanel contents = new VerticalPanel();
        testCallOut.add(contents);
        contents.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
        contents.setSpacing(6);
        contents.add(new HTML("Test of <b>Callout</b><br>All holes are targets."));
        Button okButton = new Button("OK");
        ClickHandler clickHandler = new ClickHandler() {

            @Override
            public void onClick(ClickEvent event) {
                removeCallOut(testCallOut);
                setMaskVisible(false);
            }
           
        };
        okButton.addClickHandler(clickHandler);
        contents.add(okButton);
        testCallOut.getElement().getStyle().setBackgroundColor("Pink");
        for (Widget hole : holes) {
            testCallOut.addTarget(hole);
        }
        addCallOut(testCallOut, getOffsetWidth()/4, getOffsetHeight()/2);
        testCallOut.setPixelSize(contents.getOffsetWidth(), contents.getOffsetHeight());
    }

    /** Adds newCallOut to the stencil and removes any previous call out
     *  the left and top specify the default location and it will be moved
     *  if that conflicts with the location of the targets
     * @param newCallOut
     * @param left
     * @param top
     */
    public void addCallOut(CallOut newCallOut, int left, int top) {
        if (this.callOut != null) {
            this.callOut.removeFromParent();
        }
        this.callOut = newCallOut;
        if (newCallOut != null) {
            add(newCallOut, left, top);
            Point place = newCallOut.findPlaceFor();
            insert(newCallOut, place.x, place.y, getWidgetCount()-1);
            for (Widget target : newCallOut.getTargets()) {
                mask.drawArrow(newCallOut, target);
            }
        }
    }
   
    public void removeCallOut(CallOut currentCallOut) {
        currentCallOut.removeFromParent();
        this.callOut = null;
    }

    /**
     * Both stencil and mask become the same size as the parent
     */
    public void fullSize() {
        int width = getParent().getOffsetWidth();
        int height = getParent().getOffsetHeight();
        setPixelSize(width, height);
        Canvas canvas = mask.getCanvas();
        if (canvas == null) {
            return;
        }
        canvas.setPixelSize(width, height);
        canvas.setCoordinateSpaceWidth(width);
        canvas.setCoordinateSpaceHeight(height);
    }
   
    @Override
    public void setWidth(String width) {
        super.setWidth(width);
        Canvas canvas = mask.getCanvas();
        if (canvas == null) {
            return;
        }
        canvas.setWidth(width);
        canvas.setCoordinateSpaceWidth(canvas.getOffsetWidth());
    }
   
    @Override
    public void setHeight(String height) {
        super.setHeight(height);
        Canvas canvas = mask.getCanvas();
        if (canvas == null) {
            return;
        }
        canvas.setHeight(height);
        canvas.setCoordinateSpaceHeight(canvas.getOffsetHeight());
    }
   
//    /* (non-Javadoc)
//     * @see com.google.gwt.user.client.ui.AbsolutePanel#insert(com.google.gwt.user.client.ui.Widget, int)
//     *
//     * This override ensures that if the widget is a hole it is before the mask otherwise after it.
//     */
//    @Override
//    public void insert(Widget widget, int beforeIndex) {
//      int maskIndex = getWidgetIndex(mask);
//      if (holes.contains(widget)) {
//          super.insert(widget, Math.min(maskIndex, beforeIndex));
//      } else if (beforeIndex < maskIndex) {
//          super.insert(widget, maskIndex+1);
//      } else {
//          super.insert(widget, maskIndex);
//      }
//    }
   
    public boolean isMaskVisible() {
        if (mask.getCanvas() == null) {
            return false;
        }
        return mask.getCanvas().isAttached();
    }
   
    public void setMaskVisible(boolean maskVisible) {
        if  (isMaskVisible() == maskVisible) {
            return;
        }
        Canvas canvas = mask.getCanvas();
        if (canvas == null) {
            return;
        }
        if (maskVisible) {
            fullSize();
            // need to temporarily move all the 'holes' above the mask
            // get the widget count without the mask
            canvas.removeFromParent();
            insert(canvas, 0, 0, getWidgetCount());
            mask.reset();
            int stencilLeft = getAbsoluteLeft();
            int stencilTop = getAbsoluteTop();
            // save all the locations in order to restore things
            // need to do this before moving the holes on top of the stencil
            // since if there removal may change the position of others
            for (Widget hole : holes) {
                if (hole.isAttached()) {
                    Widget parent = hole.getParent();
                    if (parent instanceof Panel) {
                        ComplexPanel panel = (ComplexPanel) parent;
                        int index = panel.getWidgetIndex(hole);
                        int relativeLeft = -1;
                        int relativeTop = -1;
                        if (panel instanceof AbsolutePanel) {
                            AbsolutePanel absolutePanel = (AbsolutePanel) panel;
                            relativeLeft = absolutePanel.getWidgetLeft(hole);
                            relativeTop = absolutePanel.getWidgetTop(hole);
                        }
                        int left = hole.getAbsoluteLeft()-stencilLeft;
                        int top = hole.getAbsoluteTop()-stencilTop;
                        int width = hole.getOffsetWidth();
                        int height = hole.getOffsetHeight();
                        insert(hole, left, top, getWidgetCount());
                        HTML holeReplacement = new HTML("<div></div>");
                        holeReplacement.setPixelSize(width, height);
                        HolePosition holePosition = new HolePosition(parent, index, relativeLeft, relativeTop, holeReplacement);
                        putWidgetInHole(holeReplacement, panel, index, relativeLeft, relativeTop);
                        holePositions.put(hole, holePosition);
                    }
                }
            }
        } else {
            // restore things
            Set<Entry<Widget, HolePosition>> entrySet = holePositions.entrySet();
            for (Entry<Widget, HolePosition> entry : entrySet) {
                Widget widget = entry.getKey();
                HolePosition position = entry.getValue();
                Widget parent = position.getParent();
                ((ComplexPanel) parent).remove(position.getHoleReplacement());
                putWidgetInHole(widget, parent, position.getIndex(), position.getLeft(), position.getTop());
            }
            canvas.removeFromParent();
            holePositions.clear();
        }
    }
   
    private void putWidgetInHole(Widget widget, Widget parent, int index, int relativeLeft, int relativeTop) {
        if (parent instanceof HorizontalPanel) {
            ((HorizontalPanel) parent).insert(widget, index);
        } else if (parent instanceof VerticalPanel) {
            ((VerticalPanel) parent).insert(widget, index);
        } else if (parent instanceof AbsolutePanel) {
            ((AbsolutePanel) parent).insert(widget, relativeLeft, relativeTop, index);
        } else {
            System.err.println("Currently there is no support for holes that are contained in anything other than HorizontalPanel, VerticalPanel, and AbsolutePanel.");
            System.err.println("Container class is " + parent.getClass().getName());
        }  
    }

    public void addHole(Widget widget) {
        if (!holes.contains(widget)) {
            holes.add(widget);
        }
    }
   
    public void removeHole(Widget widget) {
        holes.remove(widget);
        holePositions.remove(widget);
    }
   
    public void removeAllHoles() {
        holes.clear();
        holePositions.clear();
    }
   
    public CallOut getCallOut() {
        return callOut;
    }

}
