package lasad.gwt.client.helper.connection.ending;

import lasad.gwt.client.helper.connection.data.Point;

import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;

public class DrawEndingCanvas extends DrawEnding {

	private Element styledDiv;

	/**
	 * Private constructor. Do not instantiate directly @see BezierCurve
	 */
	protected DrawEndingCanvas() {
	// Do not instantiate directly
	}

	private Element canvas;

	{
		initCanvas();
	}

	protected void initCanvas() {
		this.canvas = DOM.createElement("canvas");
		String prev = DOM.getElementAttribute(canvas, "class");
		DOM.setElementAttribute(canvas, "class", prev + " gwt-diagrams-canvas");
	}

	public void update(int left, int top, float angle) {
		if (angle < 0.0f || angle >= 360.0f) {
			throw new IllegalArgumentException("Angle must from [0.0f, 360.0f)");
		}

		int arrowheadWidth = 12;
		int arrowheadHeight = 12;

		Point start = new Point(left, top);

		int size = Math.max(arrowheadWidth, arrowheadHeight);
		Point realStart = new Point(start.left - size, start.top - size);

		DOM.setElementAttribute(canvas, "left", Integer.toString(realStart.left) + "px");
		DOM.setElementAttribute(canvas, "top", Integer.toString(realStart.top) + "px");
		DOM.setStyleAttribute(canvas, "left", Integer.toString(realStart.left) + "px");
		DOM.setStyleAttribute(canvas, "top", Integer.toString(realStart.top) + "px");
		DOM.setElementAttribute(canvas, "width", Integer.toString(arrowheadWidth + size * 2) + "px");
		DOM.setElementAttribute(canvas, "height", Integer.toString(arrowheadHeight + size * 2) + "px");
		DOM.setStyleAttribute(canvas, "width", Integer.toString(arrowheadWidth + size * 2) + "px");
		DOM.setStyleAttribute(canvas, "height", Integer.toString(arrowheadHeight + size * 2) + "px");

		//		
		if (angle > 315.0f || angle < 45.0f) {
			// UP
			start = start.move(new Point(-arrowheadWidth / 2, 0));

		} else if (angle > 45.0f && angle < 135.0f) {
			// RIGHT
			start = start.move(new Point(-arrowheadHeight, -arrowheadWidth / 2));
		} else if (angle > 135.0f && angle < 225.0f) {
			// DOWN
			start = start.move(new Point(-arrowheadWidth / 2, -arrowheadHeight));
		} else {
			// LEFT
			start = start.move(new Point(0, -arrowheadWidth / 2));
		}

		// start = start.move(new Point(-2,-1));
		Point p1, p2, p3;

		if (angle > 315.0f || angle < 45.0f) {
			// UP
			p1 = new Point(start.getLeft() + arrowheadWidth / 2, start.getTop());
			p2 = new Point(start.getLeft(), start.getTop() + arrowheadHeight);
			p3 = new Point(start.getLeft() + arrowheadWidth, start.getTop() + arrowheadHeight);

		} else if (angle > 45.0f && angle < 135.0f) {
			// RIGHT
			p1 = new Point(start.getLeft() + arrowheadHeight, start.getTop() + arrowheadWidth / 2);
			p2 = new Point(start.getLeft(), start.getTop());
			p3 = new Point(start.getLeft(), start.getTop() + arrowheadWidth);
		} else if (angle > 135.0f && angle < 225.0f) {
			// DOWN
			p1 = new Point(start.getLeft() + arrowheadWidth / 2, start.getTop() + arrowheadHeight);
			p2 = new Point(start.getLeft() + arrowheadWidth, start.getTop());
			p3 = new Point(start.getLeft(), start.getTop());
		} else {
			// LEFT
			p1 = new Point(start.getLeft(), start.getTop() + arrowheadWidth / 2);
			p2 = new Point(start.getLeft() + arrowheadHeight, start.getTop() + arrowheadWidth);
			p3 = new Point(start.getLeft() + arrowheadHeight, start.getTop());
		}

		realStart = realStart.move(new Point(2, 2).negative());

		drawImpl(p1.move(realStart.negative()), p2.move(realStart.negative()), p3.move(realStart.negative()), DOM.getStyleAttribute(styledDiv, "color"),
		// DOM.getStyleAttribute(styledDiv, "width").replace("px",""));
				DOM.getStyleAttribute(styledDiv, "width").replace("px", ""));

	}

	private native void drawImpl(Point p1, Point p2, Point p3, String color, String linewidth)/*-{
		var canvas = this.@lasad.gwt.client.helper.connection.ending.DrawEndingCanvas::canvas;
		var ctx = canvas.getContext('2d');


		ctx.strokeStyle = color;
		ctx.fillStyle = color;
		ctx.lineWidth = linewidth;
		ctx.beginPath();
		ctx.moveTo(p1.@lasad.gwt.client.helper.connection.data.Point::left,
		p1.@lasad.gwt.client.helper.connection.data.Point::top);
		ctx.lineTo(p2.@lasad.gwt.client.helper.connection.data.Point::left,
		p2.@lasad.gwt.client.helper.connection.data.Point::top);
		ctx.lineTo(p3.@lasad.gwt.client.helper.connection.data.Point::left,
		p3.@lasad.gwt.client.helper.connection.data.Point::top);
		ctx.fill();
	}-*/;

	/**
	 * @see lasad.gwt.client.helper.common.bezier.BezierCurve#getElement()
	 */
	public Element getElement() {
		return canvas;
	}

	public Element getCurveStyleElement() {
		return styledDiv;
	}

	public void setCurveStyleElement(Element style) {
		if (styledDiv == null) {
			styledDiv = style;
		}
	}
	// private native static String getComputedStyle(Element element, String
	// cssRule)/*-{
	// if( $doc.defaultView && $doc.defaultView.getComputedStyle ){
	// return $doc.defaultView.getComputedStyle( element, ''
	// ).getPropertyValue(cssRule);
	// } else {
	// return null;
	// }
	// }-*/;
}