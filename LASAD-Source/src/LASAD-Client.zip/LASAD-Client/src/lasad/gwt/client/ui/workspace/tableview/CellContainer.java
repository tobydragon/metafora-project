package lasad.gwt.client.ui.workspace.tableview;

import lasad.gwt.client.model.MVCViewRecipient;
import lasad.gwt.client.model.UnspecifiedElementModel;

public interface CellContainer {

	// ChildElement id und type
	MVCViewRecipient addComponent(String type, String id);
	
	void removeComponent(UnspecifiedElementModel model);
	
	TableCellInfo getTableCellInfo();
	
	void setTableCellInfo(TableCellInfo tableCellInfo);
	
	void changeView(TableZoomEnum zoom);
	
	TableCellTypeEnum getType();
}
