package lasad.gwt.client.xml;

import java.util.List;
import java.util.Vector;

import lasad.gwt.client.settings.DebugSettings;
import lasad.gwt.client.ui.box.Box;
import lasad.gwt.client.ui.common.ExtendedElement;
import lasad.gwt.client.ui.link.LinkPanel;
import lasad.gwt.client.ui.workspace.AbstractArgumentMap;

import com.extjs.gxt.ui.client.widget.Component;
import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.Text;
import com.google.gwt.xml.client.XMLParser;

/**
 * 
 * @author Marcel Bergmann, Frank Loll (modified)
 * 
 *         This class converts a map into an xml-string for saving issues. XML
 *         structure: <lasad> <ontology> <template> <content> <element>
 *         <sub-element> <parameter> <{name}> <{value}> ...(collect all
 *         parameters) Date: November 16th, 2010
 */
public class MapToXMLConverter {

	private AbstractArgumentMap map;
	private String ontology;
	private String template;

	private Vector<Box> boxes = new Vector<Box>();
	private Vector<LinkPanel> linkPanels = new Vector<LinkPanel>();

	private Document doc;
	private String xmlString;

	public MapToXMLConverter(AbstractArgumentMap map, String ontology, String template) {
		this.map = map;

		this.ontology = ontology.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
		this.template = template.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
		this.xmlString = createXML();
	}

	private String createXML() {
		// Fetch all Box and LinkPanel objects
		List<Component> mapComponents = this.map.getItems();
		for (Component mapComponent : mapComponents) {
			if (mapComponent instanceof Box) {
				boxes.add((Box) mapComponent);
			} else if (mapComponent instanceof LinkPanel) {
				linkPanels.add((LinkPanel) mapComponent);
			}
		}

		this.doc = XMLParser.createDocument();

		// root tag
		// lasad
		Element tagLasad = doc.createElement("lasad");
		tagLasad.setAttribute("version", DebugSettings.version);

		Text valueOntology = doc.createTextNode(this.ontology);
		Text valueTemplate = doc.createTextNode(this.template);

		Element tagContent = doc.createElement("content");

		/**
		 * build up the xml-tree
		 */
		doc.appendChild(tagLasad);

		tagLasad.appendChild(valueOntology);
		tagLasad.appendChild(valueTemplate);
		tagLasad.appendChild(tagContent);

		for (Element element : createContentTags()) {
			tagContent.appendChild(element);
		}

		String xml = doc.getDocumentElement().toString();

		xml = xml.replace("&lt;", "<");
		xml = xml.replace("&gt;", ">");

		return xml;
	}

	private Vector<Element> createBoxTags() {
		Vector<Element> returnElements = new Vector<Element>();
		Element element;
		for (Box box : boxes) {
			// create initial element tag <element> and collect attribute values
			element = doc.createElement("element");
			element.setAttribute("id", box.getConnectedModel().getId() + "");
			element.setAttribute("type", box.getConnectedModel().getType());
			element.setAttribute("element-id", box.getElementInfo().getElementID());
			element.setAttribute("root-element-id", box.getConnectedModel().getValue("ROOTELEMENTID"));
			element.setAttribute("pos-x", Integer.toString(box.getPosition(true).x));
			element.setAttribute("pos-y", Integer.toString(box.getPosition(true).y));
			element.setAttribute("height", Integer.toString(box.getSize().height));
			element.setAttribute("width", Integer.toString(box.getSize().width));
			element.setAttribute("username", box.getConnectedModel().getValue("USERNAME"));

			// fetch ExtendedElements of the current mapElement and create tags
			// for them either --> <sub-element>
			for (ExtendedElement extendedElement : box.getExtendedElements()) {
				element.appendChild(createExtendedElementTag(extendedElement));
			}

			returnElements.add(element);
		}

		return returnElements;
	}

	private Vector<Element> createContentTags() {
		Vector<Element> returnElements = new Vector<Element>();
		returnElements.addAll(createBoxTags());
		returnElements.addAll(createLinkTags());

		return returnElements;
	}

	private Vector<Element> createLinkTags() {
		Vector<Element> returnElements = new Vector<Element>();
		Element element;
		for (LinkPanel linkPanel : linkPanels) {
			// create initial element tag <element> and collect attribute values
			element = doc.createElement("element");
			element.setAttribute("type", linkPanel.getElementInfo().getElementType());
			element.setAttribute("element-id", linkPanel.getElementInfo().getElementID());
			element.setAttribute("root-element-id", linkPanel.getMyLink().getConnectedModel().getValue("ROOTELEMENTID"));
			element.setAttribute("start-parent-root-element-id", linkPanel.getMyLink().getConnectedModel().getParents().get(0).getValue("ROOTELEMENTID") + "");
			element.setAttribute("end-parent-root-element-id", linkPanel.getMyLink().getConnectedModel().getParents().get(1).getValue("ROOTELEMENTID") + "");
			element.setAttribute("height", Integer.toString(linkPanel.getSize().height));
			element.setAttribute("width", Integer.toString(linkPanel.getSize().width));
			element.setAttribute("username", linkPanel.getMyLink().getConnectedModel().getValue("USERNAME"));

			// fetch ExtendedElements of the current mapElement and create tags
			// for them either --> <sub-element>
			for (ExtendedElement extendedElement : linkPanel.getMyLink().getExtendedElements()) {
				element.appendChild(createExtendedElementTag(extendedElement));
			}

			returnElements.add(element);
		}

		return returnElements;
	}

	private Element createExtendedElementTag(ExtendedElement extendedElement) {

		Element subElement = doc.createElement("sub-element");
		subElement.setAttribute("type", extendedElement.getConfig().getElementType());

		for (String parameterName : extendedElement.getConnectedModel().getElementValues().keySet()) {
			if (!parameterName.equalsIgnoreCase("STATUS") && !parameterName.equalsIgnoreCase("ID")) {
				this.appendExtendedElementParameter(subElement, parameterName, extendedElement.getConnectedModel().getElementValues().get(parameterName));
			}
		}

		return subElement;
	}

	/**
	 * Adds a "parameter"-tag to parentElement
	 * 
	 * @param parentElement
	 * @param name
	 *            the parameter's name
	 * @param value
	 *            the parameter's value
	 */
	private void appendExtendedElementParameter(Element parentElement, String name, String value) {
		Element tagParameter = doc.createElement("parameter");
		Element tagName = doc.createElement("name");
		Text valueName = doc.createTextNode(name);
		Element tagText = doc.createElement("value");
		
		Text valueText;
		if(name.equalsIgnoreCase("TEXT")) {
			String maskedValue = "<![CDATA["+value+"]]>";
			valueText = doc.createTextNode(maskedValue);
		}
		else {
			valueText = doc.createTextNode(value);
		}
		

		parentElement.appendChild(tagParameter);
		tagParameter.appendChild(tagName);
		tagName.appendChild(valueName);
		tagParameter.appendChild(tagText);
		
		
		tagText.appendChild(valueText);
	}

	public String getXmlString() {
		return xmlString;
	}
}
