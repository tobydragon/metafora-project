package lasad.gwt.client.ui.workspace.tutorial;

import lasad.gwt.client.ui.workspace.AbstractArgumentMap;
import lasad.gwt.client.ui.workspace.argumentmap.ArgumentMap;
import lasad.gwt.client.ui.workspace.questionnaire.QuestionnaireHandler;

import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.layout.AccordionLayout;

public class Tutorial extends ContentPanel {

	private AbstractArgumentMap myMap = null;
	private TutorialConfig tutorialConfig = null;

	public Tutorial(AbstractArgumentMap map) {
		this.myMap = map;

		this.setLayout(new AccordionLayout());
		this.setHeading("Tutorial");
		this.setBodyBorder(true);
		this.setBorders(false);

		this.setHeight("100%");

		// Get TutorialConfig
		this.setTutorialConfig(myMap.getMyViewSession().getController().getMapInfo().getTutorialConfig());
	}

	public void setTutorialConfig(TutorialConfig config) {
		if (config == null) return;

		this.tutorialConfig = config;

		// Remove all further elements
		this.removeAll();

		// Load new Elements
		loadConfig();
	}

	private void loadConfig() {
		for (TutorialStepConfig stepConfig : tutorialConfig.getTutorialSteps()) {
			// Add Step to Panel
			this.add(new TutorialStep(this, stepConfig));
		}
	}

	public AbstractArgumentMap getMyMap() {
		return myMap;
	}

	public void setMyMap(ArgumentMap myMap) {
		this.myMap = myMap;
	}

	private QuestionnaireHandler questionnaireHandler = new QuestionnaireHandler();

	public QuestionnaireHandler getQuestionnaireHandler() {
		return questionnaireHandler;
	}
}
