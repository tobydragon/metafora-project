package lasad.gwt.client.communication.objects.categories;

public enum Categories {
	Auth, Authoring, Error, Info, Management, Map, Notify, Replay, Session, UserEvent, None, 
	Communication, Feedback, Questionnaire, File, 
	Heartbeat,
}
