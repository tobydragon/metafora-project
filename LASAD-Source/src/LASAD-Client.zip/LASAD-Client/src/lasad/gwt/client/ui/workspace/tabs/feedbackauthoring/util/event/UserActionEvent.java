package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public interface UserActionEvent {
	
	public abstract String getProperty(ActionUserEventProperty name);
	
	public abstract void addProperty(ActionUserEventProperty name, String value);
	
}
