package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data;

import java.io.Serializable;

import com.extjs.gxt.ui.client.data.BaseModel;

public class ElementModel extends BaseModel implements Serializable, Comparable<ElementModel> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3846793922195348810L;

	public ElementModel(){
		
	}
	
	public ElementModel(String name, String status) {
		set("name", name);
		set("status", status);
	}
	
	public ElementModel(String name, String status, String id) {
		this(name, status);
		set("id", id);
	}

	public String getName() {
		return (String) get("name");
	}
	
	public String getStatus() {
		return (String) get("status");
	}
	
	public String getId() {
		return (String) get("id");
	}
	
	@Override
	public int compareTo(ElementModel o) {
		return this.getName().compareTo(o.getName());
	}
}
