package lasad.gwt.client.ui.workspace.argumentmap.elements;

import lasad.gwt.client.communication.LASADActionSender;
import lasad.gwt.client.communication.objects.ActionFactory;
import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.ui.workspace.argumentmap.ArgumentMap;

import com.extjs.gxt.ui.client.event.Events;
import com.google.gwt.dom.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;

public class CreateBoxLinkDialogListener implements EventListener {

	private final LASADActionSender communicator = LASADActionSender.getInstance();
	private final ActionFactory actionBuilder = ActionFactory.getInstance();

	private ArgumentMap myMap;
	private CreateBoxLinkDialog myDialog;

	public CreateBoxLinkDialogListener(ArgumentMap map, CreateBoxLinkDialog dialog) {
		this.myMap = map;
		this.myDialog = dialog;
	}

	public void onBrowserEvent(Event be) {
		if (be.getTypeInt() == Events.OnMouseOver.getEventCode()) {
			handleMouseOver(be);
		} else if (be.getTypeInt() == Events.OnClick.getEventCode()) {
			handleOnClick(be);
		} else if (be.getTypeInt() == Events.OnMouseOut.getEventCode()) {
			handleMouseOut(be);

		}
		be.stopPropagation();
	}

	private void handleOnClick(Event be) {
		if (myDialog.getStep() == 1) {
			// Choose a BoxType
			for (ElementInfo info : myMap.getMyViewSession().getController().getMapInfo().getElementsByType("box").values()) {
				if (((Element) be.getEventTarget().cast()).getInnerText().equals(info.getElementOption("heading"))) {
					// Call Step 2
					myMap.add(new CreateBoxLinkDialog(myMap, myDialog.getStartBox(), myDialog.getPosition(true).x, myDialog.getPosition(true).y, 2, info));
					myMap.layout();
					break;
				}
			}
		} else if (myDialog.getStep() == 2) {
			// Box and Link was choosen
			for (ElementInfo info : myMap.getMyViewSession().getController().getMapInfo().getElementsByType("relation").values()) {
				if (((Element) be.getEventTarget().cast()).getInnerText().equals(info.getElementOption("heading"))) {
					// Send Action --> Server

					communicator.sendActionPackage(actionBuilder.createBoxAndLink(myDialog.getBoxConfig(), info, myMap.getID(), myDialog.getPosition(true).x, myDialog.getPosition(true).y, String.valueOf(myDialog.getStartBox().getConnectedModel().getId()), "LAST-ID"));

					// ActionSet actionSet = new ActionSet(myMap.getID());
					//					
					// // Add CreateBoxAction
					// Vector<LASADActionSetEntryInterface> actions =
					// LASADActionFactory.createBoxWithElements(myDialog.getBoxConfig(),myDialog.getPosition(true).x,myDialog.getPosition(true).y);
					// for (LASADActionSetEntryInterface action : actions){
					// actionSet.addAction(action);
					// }
					//					
					// for(LASADActionSetEntryInterface action :
					// LASADActionFactory.createLinkWithElements(info,myDialog.getStartBox().getConnectedModel().getId(),0)){
					// actionSet.addAction(action);
					// }
					//					
					// LASAD_Client.larb.sendActionSet(actionSet);
				}
			}
		}
		myDialog.removeFromParent();
	}

	private void handleMouseOut(Event be) {
		// End hover effect
		if (((Element) be.getEventTarget().cast()).getClassName().equals("dialog-text-highlighted")) {
			((Element) be.getEventTarget().cast()).setClassName("dialog-text");
		}
	}

	private void handleMouseOver(Event be) {
		// Start hover effect
		if (((Element) be.getEventTarget().cast()).getClassName().equals("dialog-text")) {
			((Element) be.getEventTarget().cast()).setClassName("dialog-text-highlighted");
		}
	}
}