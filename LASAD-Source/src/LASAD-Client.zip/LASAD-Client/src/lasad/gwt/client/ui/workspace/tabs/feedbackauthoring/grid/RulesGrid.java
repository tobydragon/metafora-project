package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid;

import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;


public class RulesGrid extends CustomizedGrid {
	
	private static RulesGrid instance = null;
	private AgentDescriptionFE agent;
	
	public static RulesGrid getInstance(GridConf gridConf, AgentDescriptionFE agent) {
		if (instance == null) {
			instance = new RulesGrid(gridConf, agent);
		}
		return instance;
	}
	
	private RulesGrid(GridConf gridConf, AgentDescriptionFE agent) {
		super(gridConf);
		this.agent = agent;
		this.setHeaderVisible(false);
	    this.setBodyBorder(false);
	}

	@Override
	void viewElement(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void editElement(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void deleteElement(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void duplicateElement(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void addElement() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void markReadyElement(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void populateGridForTesting() {
		// TODO Auto-generated method stub
		
	}

	
	
}
