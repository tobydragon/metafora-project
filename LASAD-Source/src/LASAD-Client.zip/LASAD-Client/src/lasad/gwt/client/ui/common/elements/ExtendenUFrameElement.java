package lasad.gwt.client.ui.common.elements;



import lasad.gwt.client.LASAD_Client;
import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.ui.common.ExtendedElement;
import lasad.gwt.client.ui.common.ExtendedElementContainerInterface;

import com.extjs.gxt.ui.client.event.BaseEvent;
import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.MessageBoxEvent;
import com.extjs.gxt.ui.client.util.Size;
import com.extjs.gxt.ui.client.widget.Info;
import com.extjs.gxt.ui.client.widget.MessageBox;
import com.extjs.gxt.ui.client.widget.Window;
import com.extjs.gxt.ui.client.widget.button.ToolButton;
import com.extjs.gxt.ui.client.widget.layout.LayoutData;
import com.google.gwt.event.dom.client.LoadEvent;
import com.google.gwt.event.dom.client.LoadHandler;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.RootPanel;

public class ExtendenUFrameElement extends ExtendedElement {

	
	
	
	public ExtendenUFrameElement(ExtendedElementContainerInterface container, ElementInfo config) {
		super(container, config);

		// Set possible Element Vars
		// Only this Elements would be updates to the model
	
		getConfigs(config);
		this.elementVars.add("LINK");
	}
	
	public ExtendenUFrameElement(ExtendedElementContainerInterface container, ElementInfo config, boolean readOnly, boolean dummy) {
		super(container, config, readOnly);
		this.elementVars.add("LINK");
		
		dummy=false;
		if(dummy) {
			buildElement();
			this.setVarValue("LINK", "http://google.com", LASAD_Client.getInstance().getUsername());
		}
	}

	Element elementContent = null;

	Element logoDiv = null;
	Element editButtonDiv = null;

	Element frameElement = null;
	Element textElement = null;
	
	Element textFrameDiv = null;
	Element _contentFrame=null;
	String defaulttxt="Please enter URL:";
	private boolean editable=false;
	//whether URL is in DB or not
	private boolean urlSetted=false;
	//whether image is loaded or not
	private boolean firstTime=false;
	private boolean isImage=false;
	Element image=null;
	private Image imagewidget=null;
	private Window imagewindow=null;
	private boolean isOpened=false;
	private Size activeSize=null;
	private Size activeimageSize=null;
	private int window_height=400;
	private int window_width=400;
	private String defaultURL="";
	private boolean hasdefaultURL=false;
	private boolean noneditableinitialized=false;
	
	
String sourceURL="";
	
	Element tbody = DOM.createTBody();
	Element framerow = DOM.createTR();
	Element editbuttonrow = DOM.createTR();
	Element componentTable=DOM.createTable();
	
	 
	protected void buildElement() {
		if (elementContent != null) {
			// Already builded		
			if(textElement!=null && frameElement!=null ){
				
				String url=DOM.getElementProperty(textElement, "value");
				if (!url.equals("") && !url.equals(defaulttxt)) {
					if(!url.startsWith("http://") && !url.startsWith("HTTP://") )
						{
						
						url="http://"+url;	
							}
					
					if(isSourceImage(url)){
						
						 frameElement=null;
						 frameElement=DOM.createImg();
						 
						 isImage=true;

					}
					else{
						
						
						frameElement=null;
						frameElement=DOM.createIFrame();
						isImage=false;
					}
				
				 frameElement.setPropertyString("src", url);
				 this.sourceURL=url;
					if(isImage && frameElement!=null && activeSize!=null && elementContent!=null){
				
						adjustElementSize(url,activeSize);
						createImageEvents(frameElement,url);
						
						DOM.setElementProperty(elementContent, "align", "center");
						
					}
					else if(!isImage && frameElement!=null && activeSize!=null ){
						
						if(activeSize.height>19)
						 DOM.setStyleAttribute(frameElement, "height",activeSize.height-19 + "px");
						else
						DOM.setStyleAttribute(frameElement, "height",activeSize.height + "px");
							
						DOM.setStyleAttribute(frameElement, "width",activeSize.width + "px");					
					}
				}
							
			}
			return;
			
		}

		EventListener listener= new EventListener() {
			public void onBrowserEvent(Event be) {
				int code = be.getTypeInt();
				if (code == Events.OnClick.getEventCode() && be.getCurrentEventTarget().cast() != frameElement && be.getCurrentEventTarget().cast()!=textFrameDiv) {
					if (ExtendenUFrameElement.this.isActiveViewMode()) {
						// Ask for Focus
						if(editable){
						ExtendenUFrameElement.this.getContainer().getFocusHandler().setFocus(ExtendenUFrameElement.this);
						}
						}
				} else if (code == Events.OnFocus.getEventCode()) {
					
					String txtvalue=DOM.getElementProperty(textElement, "value");
					if(txtvalue.equals(defaulttxt)){
						
						DOM.setElementAttribute(textElement, "value", "");
						textElement.setPropertyString("value","");
						
					}

					if (ExtendenUFrameElement.this.isActiveViewMode()) {
						if(editable)
							{							
					ExtendenUFrameElement.this.getContainer().getFocusHandler().setFocus(ExtendenUFrameElement.this);
							}
						else{
					ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this);
						}
						
					}
				} 
				
				else if (code == Events.OnBlur.getEventCode()) {
					
					
				
				 if (ExtendenUFrameElement.this.isActiveViewMode()) {
						// Focus was lost by TABULATOR
						
					 if(editable)
						{	
						ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this);
						}
					 else{
						 ExtendenUFrameElement.this.getContainer().getFocusHandler().setFocus(ExtendenUFrameElement.this);
						 
						// ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this);//**
					 }
				 
				 }
					
				}
				
				
				
				
			
				
				
				be.stopPropagation();
			}
		};

		elementContent = DOM.createDiv();
		elementContent.setClassName("ExtendenUFrameElement");

		

		// TEXTFIELD
		textFrameDiv = DOM.createDiv();
		textFrameDiv.setClassName("TextFrameDiv");
		DOM.appendChild(elementContent, textFrameDiv);
		
		
		textElement=DOM.createInputText();
		textElement.setClassName("extendedUFrame-TextField-EditMode");
		DOM.setElementAttribute(textElement, "value", defaulttxt);		
		DOM.appendChild(textFrameDiv,textElement);
		DOM.sinkEvents( textElement, Events.Focus.getEventCode());
		DOM.setEventListener(textElement, listener);
		

		// OneRowTextfield
		
		
		 
		
		//FrameElement
		 frameElement= DOM.createIFrame();
		 frameElement.setClassName("extendedFrameElement");
		 
		 if(hasdefaultURL){
			 frameElement.setPropertyString("src",defaultURL);	 
		 }
		
//		elementContent.setPropertyString("src", "http://web-expresser.appspot.com/?userKey=x5Spdu9XABVAVTSKxzQl67&thumbnail=64");
		// frameElement.setPropertyString("src", );
	    //frameElement.setClassName("ExtendenUFrameElement-TextField-EditMode");

		//DOM.sinkEvents( frameElement, Events.Focus.getEventCode());
		//DOM.setEventListener(frameElement, listener);
		
		
		//DOM.appendChild(elementContent, frameElement);

		
	
		
		// VIEW MODE

		// URL FIELD
		//urlField = DOM.createDiv();
		//urlField.setClassName("ExtendenUFrameElement-TextField-ViewMode");

		// Add an EventListener to the URL Element to prevent a switch to the
		// editmode by clicking on the url
		//DOM.sinkEvents(urlField, Events.OnClick.getEventCode());
		//DOM.setEventListener(urlField, listener);

		// Edit Button
		 
		//buttonContainer=DOM.createDiv();
		editButtonDiv = DOM.createDiv();
		editButtonDiv.setClassName("extendedUFrameElement-EditButton");
		
		DOM.sinkEvents(this.editButtonDiv, Events.OnClick.getEventCode());
		DOM.setEventListener(this.editButtonDiv, listener);
		
		DOM.setStyleAttribute(editButtonDiv, "width",  30+ "px");
		
		//editButtonDiv.setInnerText("Change URL");
		
		//DOM.appendChild(buttonContainer, editButtonDiv);
		DOM.appendChild(elementContent,editButtonDiv);
		if(!editable)
		DOM.setStyleAttribute(editButtonDiv, "visibility", "hidden");
		

		setElementSize(new Size(getActualViewModeWidth(), getActualViewModeHeight()));
	}

	
	// Getting configuration from ML
	void getConfigs(ElementInfo config){
		if (config.getUiOption("editable") != null && config.getUiOption("editable")!="" && !config.getUiOption("editable").isEmpty()) {
			editable = Boolean.parseBoolean(config.getUiOption("editable"));
		}
		else {
			editable =true;
		}
		
		if (config.getUiOption("defaulturl") != null && config.getUiOption("defaulturl")!="" && !config.getUiOption("defaulturl").isEmpty()) {
			defaultURL= config.getUiOption("defaulturl");
			hasdefaultURL=true;
		}
		else {
			
			hasdefaultURL=false;
		}
		
		if (config.getUiOption("windowheight") != null && config.getUiOption("windowheight")!="") {
			window_height= Integer.parseInt(config.getUiOption("windowheight"));
			
		}
		else {
			window_height=400;
		}
		
		
		if (config.getUiOption("windowwidth") != null && config.getUiOption("windowwidth")!="") {
			window_width= Integer.parseInt(config.getUiOption("windowwidth"));
			
		}
		else {
			
			window_width=400;
		}
	}
	
	protected void setElementSize(Size size) {
		int balanceHeight = 4; // 1px distance to the
		

		activeSize=size;
		if (textFrameDiv != null) {
			DOM.setStyleAttribute(textFrameDiv, "width", size.width + "px");
			DOM.setStyleAttribute(textFrameDiv, "height", Math.max(0, size.height - balanceHeight)-12 + "px");
		}
		if ( frameElement != null) {
			DOM.setStyleAttribute(frameElement, "width", size.width + "px");
			DOM.setStyleAttribute(frameElement, "height", Math.max(0, size.height - balanceHeight)-19 + "px");
		
			 
		}
	
		if (textElement != null ) {
			
			if(size.width>10)
			DOM.setStyleAttribute(textElement, "width",  size.width-10 + "px");
			else
			DOM.setStyleAttribute(textElement, "width",  size.width + "px");
		}
		
		if(activeSize!=null && sourceURL!=null&& !sourceURL.equalsIgnoreCase("")){
			
			adjustElementSize(sourceURL,activeSize);
			
		}
		
		if(editButtonDiv!=null){
			
			DOM.setStyleAttribute(editButtonDiv, "width",  size.width+ "px");
		}
		
		
		
	}

	protected void switchToEditMode(Element contentFrame) {
		
		
		if(editable)
		{	
			
			if (!contentFrame.hasChildNodes()) {
				DOM.appendChild(contentFrame, elementContent);
			}
			if (frameElement!= null && DOM.isOrHasChild(textFrameDiv,frameElement)) {
				DOM.removeChild(textFrameDiv,frameElement);
			}
			if (textElement != null && !DOM.isOrHasChild(textFrameDiv, textElement)) {
				DOM.appendChild(textFrameDiv, textElement);
			}
		}
		else{
		String url="";
		if(textElement!=null)
		url=DOM.getElementProperty(textElement, "value");
		
		
		if (!contentFrame.hasChildNodes()) {
			DOM.appendChild(contentFrame, elementContent);
			
		}
		
		
		
		if (!url.equals("") && !url.equals(defaulttxt)) {
		
			if(isSourceImage(url) && !noneditableinitialized){
				
				
				
				
				 frameElement=null;
				 frameElement=DOM.createImg();
				 
				 
				 if(!url.startsWith("http://") && !url.startsWith("HTTP://") )
					{
					
					url="http://"+url;
			
					
						}
				 
				 
				 
				 frameElement.setPropertyString("src", url);
				 
				 
					ExtendenUFrameElement.this.sourceURL=url;
					ExtendenUFrameElement.this.getContainer().getFocusHandler().setFocus(ExtendenUFrameElement.this);
					ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this);
				
				
					
					if(frameElement!=null && activeSize!=null && elementContent!=null){
				
						adjustElementSize(url,activeSize);
						createImageEvents(frameElement,url);
						
						DOM.setElementProperty(elementContent, "align", "center");
						noneditableinitialized=true;
						
						ExtendenUFrameElement.this.sourceURL=url;
						ExtendenUFrameElement.this.getContainer().getFocusHandler().setFocus(ExtendenUFrameElement.this);
						ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this);
					
						
					}
					
					
					
					if (frameElement != null && !DOM.isOrHasChild(textFrameDiv, frameElement)) {
						DOM.appendChild(textFrameDiv, frameElement);
						}
					
					
					 this.setElementFocus(false);

			}else if(!noneditableinitialized){
			
				noneditableinitialized=true;
				
				 frameElement=null;
				 frameElement=DOM.createIFrame();
				 
				 if(!url.startsWith("http://") && !url.startsWith("HTTP://") )
					{
					
					url="http://"+url;
			
					
						}
				 frameElement.setPropertyString("src", url);
				 
				
				
				 
					ExtendenUFrameElement.this.sourceURL=url;
					//ExtendenUFrameElement.this.getContainer().getFocusHandler().setFocus(ExtendenUFrameElement.this);
					//ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this);
				
				 if (frameElement != null && !DOM.isOrHasChild(textFrameDiv, frameElement) && activeSize!=null) {
					 
					 DOM.setStyleAttribute(frameElement, "width",  activeSize.width-4+ "px");
					 DOM.setStyleAttribute(frameElement, "height",  activeSize.height-4+ "px");
					 DOM.appendChild(textFrameDiv, frameElement);
					
					 
						}
				 
				 
				 this.setElementFocus(true);
				
				 this.setElementFocus(false);
				 
			}
		
	
		if (textElement != null && DOM.isOrHasChild(textFrameDiv, textElement)) {
			DOM.removeChild(textFrameDiv,textElement);
		}
		

		
		
		}
		else{
			
			textElement.setPropertyString("value", defaulttxt);
							
				MessageBox box = new MessageBox();
			    box.setButtons(MessageBox.OK);
			    box.setIcon(MessageBox.WARNING);
			    box.setTitle("URL");			  
			    box.setMessage("You did not enter any url to display!");
			    box.show();
		}
		

	//	ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this);
	
		}
		
		
	}
	
	
	
	
	
	Size adjustImageSize(Size windowsize, Size newimagesize, int minheight, int minwidth, String Type) {
		double image_height = newimagesize.height;
		double image_width = newimagesize.width;
		double aspectratio = image_height / image_width;

		int cal_heigth = 0;
		int cal_width = 0;

		if (newimagesize.height >= newimagesize.width) {
			cal_heigth = windowsize.height;
			cal_width = (int) (cal_heigth / aspectratio);

			if (cal_width > windowsize.width) {

				cal_width = windowsize.width;
				cal_heigth = (int) (cal_width * aspectratio);

			}
		}

		else if (newimagesize.height < newimagesize.width) {
			cal_width = windowsize.width;
			cal_heigth = (int) (cal_width * aspectratio);

			if (cal_heigth > windowsize.height) {
				cal_heigth = windowsize.height;
				cal_width = (int) (cal_heigth / aspectratio);
			}

		}
		if (Type.equalsIgnoreCase("window")) {
			if (cal_heigth < minheight) {
				cal_heigth = minheight;

			}
			if (cal_width < minwidth) {

				cal_width = minwidth;
			}
		}
		if (cal_width < 0) {

			cal_width = 5;
		}
		if (cal_heigth < 0) {

			cal_heigth = 5;

		}
		Size mysize = new Size(cal_width, cal_heigth);
		return mysize;
	}
	
	
	

	void adjustElementSize(String imagesource,final Size _activeSize){
		
	
		final Image tempimage = new Image();
		tempimage.setUrl(imagesource);
		
		tempimage.addLoadHandler(new LoadHandler() {
			@Override
			public void onLoad(LoadEvent event) {

				Size newimageSize = new Size(tempimage.getWidth(), tempimage.getHeight());
				
				activeimageSize= newimageSize;
				System.out.println("Result:" + RootPanel.get().remove(tempimage));
				
				
			Size adjustedSize=adjustImageSize(_activeSize,newimageSize,0,0,"");
			if(frameElement!=null){
				if(adjustedSize.height>17)
			DOM.setStyleAttribute(frameElement, "height", adjustedSize.height-17 + "px");
				else
			DOM.setStyleAttribute(frameElement, "height", adjustedSize.height+ "px");

			DOM.setStyleAttribute(frameElement, "width", adjustedSize.width + "px");
			}
				
				}

			
		});
		RootPanel.get().add(tempimage);
		
		
		
		
	
	}
	
	
	boolean isSourceImage(String Url){
		
		if(Url.endsWith(".jpg") || Url.endsWith(".jpeg") || Url.endsWith(".gif") || Url.endsWith(".png") || Url.endsWith(".bmp") )
		{
			
		return true;	
		}
		else{
		
		return false;
		}
	}

	protected void switchToViewMode(Element contentFrame) {
		buildElement();
		if(editable)
		{	
			if(!firstTime){	
				if(hasdefaultURL && isSourceImage(defaultURL)){
					// Editable with Defualt Image
				 frameElement=null;
			     frameElement=DOM.createImg();
				 frameElement.setPropertyString("src", defaultURL);
				 this.sourceURL=defaultURL;
				 if(frameElement!=null && activeSize!=null && elementContent!=null){
				adjustElementSize(defaultURL,activeSize);
				createImageEvents(frameElement,defaultURL);		
				DOM.setElementProperty(elementContent, "align", "center");
					}
				if (!contentFrame.hasChildNodes()) {
					DOM.appendChild(contentFrame, elementContent);
						}
					if (frameElement != null && !DOM.isOrHasChild(textFrameDiv, frameElement)) {
						DOM.appendChild(textFrameDiv, frameElement);
					}
					if (textElement != null && DOM.isOrHasChild(textFrameDiv, textElement)) {
						DOM.removeChild(textFrameDiv,textElement);
					}
					firstTime=true;
				}
				else{	
			if (!contentFrame.hasChildNodes()) {DOM.appendChild(contentFrame, elementContent);}
			if (frameElement != null && !DOM.isOrHasChild(textFrameDiv, frameElement)) {DOM.appendChild(textFrameDiv, frameElement);}
			if (textElement != null && DOM.isOrHasChild(textFrameDiv, textElement)) {DOM.removeChild(textFrameDiv,textElement);}
			firstTime=true;}}
				else {
					String url="";
					if(textElement!=null)
					url=DOM.getElementProperty(textElement, "value");
					if (url.equals("") && !url.equals(defaulttxt)) {
					textElement.setPropertyString("value", defaulttxt);
						MessageBox box = new MessageBox();
					    box.setButtons(MessageBox.OK);
					    box.setIcon(MessageBox.WARNING);
					    box.setTitle("URL");			  
					    box.setMessage("You did not enter any url to display!");
					    box.show();
					}
					else{
						if (!contentFrame.hasChildNodes()) {
							DOM.appendChild(contentFrame, elementContent);	
						}
						if (frameElement != null && !DOM.isOrHasChild(textFrameDiv, frameElement)) {
							DOM.appendChild(textFrameDiv, frameElement);
						}
						if (textElement != null && DOM.isOrHasChild(textFrameDiv, textElement)) {
							DOM.removeChild(textFrameDiv,textElement);
						}
						
					}
				}
		}
		else{
			
	if(!urlSetted && !editable && !hasdefaultURL){
		if (!contentFrame.hasChildNodes()) {
			DOM.appendChild(contentFrame, elementContent);
		}
		if (frameElement!= null && DOM.isOrHasChild(textFrameDiv,frameElement)) {
			DOM.removeChild(textFrameDiv,frameElement);
		}
		if (textElement != null && !DOM.isOrHasChild(textFrameDiv, textElement)) {
			DOM.appendChild(textFrameDiv, textElement);
		}
		urlSetted=true;
		
		}
	else if(hasdefaultURL){
		
		if(isSourceImage(defaultURL)){	
		 frameElement=null;
		 frameElement=DOM.createImg();
		 frameElement.setPropertyString("src", defaultURL);
		 this.sourceURL=defaultURL;
		 if(frameElement!=null && activeSize!=null && elementContent!=null){
		
		 adjustElementSize(defaultURL,activeSize);
		 createImageEvents(frameElement,defaultURL);
		 DOM.setElementProperty(elementContent, "align", "center");	
			}
			
			if (!contentFrame.hasChildNodes()) {
				DOM.appendChild(contentFrame, elementContent);	
			}
			if (frameElement != null && !DOM.isOrHasChild(textFrameDiv, frameElement)) {
				DOM.appendChild(textFrameDiv, frameElement);
			}
			if (textElement != null && DOM.isOrHasChild(textFrameDiv, textElement)) {
				DOM.removeChild(textFrameDiv,textElement);
			}}
		
		else{
			if (!contentFrame.hasChildNodes()) {
			DOM.appendChild(contentFrame, elementContent);
		}
		if (frameElement != null && !DOM.isOrHasChild(textFrameDiv, frameElement)) {
			DOM.appendChild(textFrameDiv, frameElement);
		}
		if (textElement != null && DOM.isOrHasChild(textFrameDiv, textElement)) {
			DOM.removeChild(textFrameDiv,textElement);
		}}}
	ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this);
	
		}
	
	
	
	}
	


	
	void showMessage(){
		
		
		
		String txtvalue=DOM.getElementProperty(textElement, "value");
		if(textElement!=null && txtvalue.equalsIgnoreCase("") ){
			MessageBox box = new MessageBox();
		    box.setButtons(MessageBox.OK);
		    box.setIcon(MessageBox.WARNING);
		    box.setTitle("Source URL");
		  
		    box.setMessage("You did not enter any url to display!");
		    box.show();
		    
		    return;
		}
		
		
	}
	
	void createImageEvents(Element image,final String _url){
		
		
		
		EventListener textboxlistener = new EventListener() {
			public void onBrowserEvent(Event be) {
				int code = be.getTypeInt();
	 if (code == Events.OnClick.getEventCode()) {
					

		 if(!isOpened)
			{
		 
		 
		 imagewidget = new Image();
		 imagewidget.setUrl(_url);
		 Size adjustedSize=new Size(0,0);
		 if(activeimageSize!=null){
			 Size tempSize=new Size(window_width,window_height);
			 adjustedSize= adjustImageSize(tempSize,activeimageSize,0,0,"");
		 }
		 imagewidget.setWidth(adjustedSize.width + "px");
		 imagewidget.setHeight(adjustedSize.height + "px");
		 imagewindow = new Window();
		
		if(adjustedSize!=null){
		imagewindow.setWidth(adjustedSize.width + "px");
		imagewindow.setHeight(adjustedSize.height+ "px");
		}
		imagewindow.add(imagewidget);
		imagewindow.setTitle("Image");
		imagewindow.setClosable(false);
		//
		imagewindow.setResizable(false);		
		imagewindow.setDraggable(true);
		
			
		DOM.setElementProperty(imagewindow.getElement(), "align", "center");
		
		
		ToolButton closeBtn = new ToolButton("x-tool-close");

		closeBtn.addListener(Events.OnClick, new Listener<BaseEvent>() {

			@Override
			public void handleEvent(BaseEvent be) {

				imagewindow.hide();
				isOpened = false;

			}
		});

		closeBtn.setTitle("Close");

		imagewindow.getHeader().addTool(closeBtn);
		
		
			imagewindow.show();
			isOpened=true;
			
		}
		
				}
              
				
				be.stopPropagation();
			}
		};
		
		
		DOM.sinkEvents(image, Events.OnClick.getEventCode());
		
		DOM.setEventListener(image, textboxlistener);
		
		
		
		
		
	}
	protected String getVarValue(String name) {
		if (name.equals("LINK")) {
			if (frameElement != null) {
							
				return this.sourceURL;
			}
		}
		return null;
	}

	protected void setVarValue(String name, String value, String username) {
		this.checkForHighlight(username);

		if (name.equals("LINK")) {
			if (value.startsWith("http://") || value.startsWith("HTTP://")) {
				if (frameElement != null) {
					frameElement.setPropertyString("src", value);
					
					this.sourceURL = value;
					
				//	ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this);
					urlSetted=true;
			
					
					
					
					
				}
				
				if(textElement!=null){
					
					DOM.setElementAttribute(textElement, "value", value);
					this.sourceURL = value;
					//urlSetted=true;
					//00ExtendenUFrameElement.this.getContainer().getFocusHandler().setFocus(ExtendenUFrameElement.this);
					//00ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this);
					
				ExtendenUFrameElement.this.getContainer().getFocusHandler().setFocus(ExtendenUFrameElement.this);
			ExtendenUFrameElement.this.getContainer().getFocusHandler().releaseFocus(ExtendenUFrameElement.this); 
					
					
				}
				
				}
			} 
			
		}
	

	@Override
	protected void setElementHighlight(boolean highlight) {
	}

	@Override
	protected void onEstablishModelConnection() {
	}

	@Override
	protected void onRemoveModelConnection() {
	}
}