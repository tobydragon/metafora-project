package lasad.gwt.client.ui.workspace.argumentmap;

import lasad.gwt.client.LASAD_Client;
import lasad.gwt.client.helper.connection.Connection;
import lasad.gwt.client.helper.connection.StraightTwoEndedConnection;
import lasad.gwt.client.helper.connector.Connector;
import lasad.gwt.client.helper.connector.Direction;
import lasad.gwt.client.model.MVCViewSession;
import lasad.gwt.client.ui.box.Box;
import lasad.gwt.client.ui.box.SimpleConnector;
import lasad.gwt.client.ui.common.FocusHandler;
import lasad.gwt.client.ui.common.FocusableInterface;
import lasad.gwt.client.ui.common.SelectionHandler;
import lasad.gwt.client.ui.common.fade.FadeableElementHandler;
import lasad.gwt.client.ui.common.highlight.HighlightHandler;
import lasad.gwt.client.ui.common.highlight.HighlightableElementInterface;
import lasad.gwt.client.ui.workspace.AbstractArgumentMap;
import lasad.gwt.client.ui.workspace.argumentmap.elements.CreateBoxDialog;
import lasad.gwt.client.ui.workspace.argumentmap.elements.CreateBoxLinkDialog;
import lasad.gwt.client.ui.workspace.transcript.TranscriptLinkData;

import com.extjs.gxt.ui.client.Style.Scroll;
import com.extjs.gxt.ui.client.dnd.DropTarget;
import com.extjs.gxt.ui.client.event.ComponentEvent;
import com.extjs.gxt.ui.client.event.DNDEvent;
import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.util.Size;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.layout.AbsoluteLayout;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.Timer;


public class ArgumentMap extends AbstractArgumentMap implements FocusableInterface, HighlightableElementInterface {

	// For Drag and drop
	private DropTarget dropTarget = null;
	private Connector startPoint, endPoint;
	private Connection myCon;
	private SimpleConnector endConnector;
	
	private Listener<ComponentEvent> baseEventListener;
	private ContentPanel scrollPanel;
	
	private boolean clicked = false;
	private boolean cursorTrackingEnabled = false;

	public ArgumentMap(ArgumentMapSpace parentElement) {
		super(parentElement);
		
		sinkEvents(Event.ONCONTEXTMENU);

		this.setHeaderVisible(false);
		this.setBodyBorder(false);
		this.setBorders(false);
		this.setLayout(new AbsoluteLayout());

		baseEventListener = new Listener<ComponentEvent>() {

			public void handleEvent(ComponentEvent be) {
				// This seams to be buggy. Even if one does not move the mouse
				// there is a OnMouseMove event. Thus we need to calculate of
				// there is a position change...
				if (be.getType() == Events.OnMouseMove) {
					clicked = false;
					if (cursorTrackingEnabled && myAwarenessCursorID != -1 && LASAD_Client.getInstance().isAuthed()) {
						int newMouseX = (be.getClientX() - getAbsoluteLeft() + getHScrollPosition());
						int newMouseY = (be.getClientY() - getAbsoluteTop() + getVScrollPosition());

						int totalChange = Math.abs((oldMouseX - newMouseX)) + Math.abs((oldMouseY - newMouseY));

						if (refreshMyCursor && !disableNormalCursorUpdates) {
							// If the number is too low there will be to many
							// messages.
							if (totalChange > 20) {
								communicator.sendActionPackage(actionBuilder.updateMyCursorPositionNonPersistent(ID, myAwarenessCursorID, LASAD_Client.getInstance().getUsername(), newMouseX, newMouseY));
								oldMouseX = newMouseX;
								oldMouseY = newMouseY;
								refreshMyCursor = false;
							}
						}

						else if (totalChange > 20 && refreshMyCursorPersistent) {
							communicator.sendActionPackage(actionBuilder.updateMyCursorPositionPersistent(ID, myAwarenessCursorID, LASAD_Client.getInstance().getUsername(), newMouseX, newMouseY));
							oldMouseX = newMouseX;
							oldMouseY = newMouseY;
							refreshMyCursorPersistent = false;
							numberOfCursorRecords++;
						}
					}
				}
				else if (be.getType() == Events.OnMouseDown) {
					clicked = true;
				}
				else if ((be.getType() == Events.OnClick && clicked) || be.getType() == Events.OnDoubleClick) {
					focusHandler.releaseAllFocus();
				} 
				else if (be.getType() == Events.OnContextMenu) {
					be.preventDefault();
					eventContextMenu(be.getClientX() - getAbsoluteLeft() + getHScrollPosition(), be.getClientY() - getAbsoluteTop() + getVScrollPosition());

				}
				be.cancelBubble();
			}
		};

		this.addListener(Events.OnDoubleClick, baseEventListener);
		this.addListener(Events.OnContextMenu, baseEventListener);
		this.addListener(Events.OnClick, baseEventListener);
		this.addListener(Events.OnMouseDown, baseEventListener);
		
		this.addListener(Events.OnMouseMove, baseEventListener);
		this.sinkEvents(Events.OnMouseMove.getEventCode());

		this.sinkEvents(Events.OnClick.getEventCode() | Events.OnDoubleClick.getEventCode() | Events.OnContextMenu.getEventCode() | Events.OnMouseDown.getEventCode());

		scrollPanel = new ContentPanel();
		scrollPanel.setBodyStyleName("connectorPanel_normal");
		scrollPanel.setHeaderVisible(false);
		scrollPanel.setBorders(false);
		scrollPanel.setBodyBorder(false);
		this.add(scrollPanel);

		initMapDimensions();
		this.setScrollMode(Scroll.ALWAYS);
		createDropTarget();
	}

	public DropTarget createBoxDropTarget(Box b) {
		// The Map Target must be added after the Box Targets to work on the boxes
		this.dropTarget.release();
		DropTarget target = new DropTarget(b);
		createDropTarget();
		return target;
	}

	private void createDropTarget() {
		dropTarget = new DropTarget(this) {

			@Override
			protected void onDragDrop(DNDEvent e) {
				
				if (e.getData() instanceof TranscriptLinkData) {
					
					ArgumentMap.this.add(new CreateBoxDialog(ArgumentMap.this, e.getXY().x - ArgumentMap.this.getAbsoluteLeft() + getHScrollPosition(), e.getXY().y - ArgumentMap.this.getAbsoluteTop() + getVScrollPosition(), (TranscriptLinkData) e.getData()));
					ArgumentMap.this.layout();
				} else if (e.getData() instanceof Box) {
					
					myCon.remove();
//					myCon.disconnect(endConnector.getConnector());
					myCon = null;
					endConnector.removeFromParent();
					endConnector = null;
					startPoint = null;
					endPoint = null;
					ArgumentMap.this.add(new CreateBoxLinkDialog(ArgumentMap.this, ((Box) e.getData()), e.getXY().x - ArgumentMap.this.getAbsoluteLeft() + getHScrollPosition(), e.getXY().y - ArgumentMap.this.getAbsoluteTop() + getVScrollPosition(), 1));
					ArgumentMap.this.layout();
				}
			}

			@Override
			protected void onDragFail(DNDEvent event) {
				super.onDragFail(event);
				myCon.remove();
//				myCon.disconnect(endConnector.getConnector());
				myCon = null;
				endConnector.removeFromParent();
				endConnector = null;
				startPoint = null;
				endPoint = null;
				
			}

			@Override
			protected void onDragEnter(DNDEvent e) {
			
				e.getStatus().setStatus(true);
				e.getStatus().update("Create new Box");
		
				if (e.getDragSource().getData() instanceof Box) {
					
					if(ArgumentMap.this.myArgumentMapSpace.isDirectLinkingDenied()) {
						e.getStatus().setStatus(false);
						e.getStatus().update("");
					}
					
					if (startPoint == null) {
						startPoint = ((Box) e.getData()).getConnector();
					}
					if (endConnector == null) {
						endConnector = new SimpleConnector(e.getClientX() - ArgumentMap.this.getAbsoluteLeft() + getHScrollPosition(), e.getClientY() - ArgumentMap.this.getAbsoluteTop() + getVScrollPosition());
						ArgumentMap.this.add(endConnector);
					}
					if (endPoint == null) {
						endPoint = endConnector.getConnector();
					}
					if (myCon == null) {
						myCon = new StraightTwoEndedConnection(ArgumentMap.this, startPoint, endPoint, "2px", "#000000");
						myCon.appendTo(ArgumentMap.this);
						ArgumentMap.this.layout();
					}
					

				}
			}

			@Override
			protected void onDragLeave(DNDEvent e) {
				e.getStatus().setStatus(false);
				e.getStatus().update("");

				super.onDragLeave(e);
			}

			@Override
			protected void onDragMove(DNDEvent e) {
				super.onDragMove(e);
				if (endConnector != null && myCon != null) {
					endConnector.setPosition(e.getClientX() - ArgumentMap.this.getAbsoluteLeft() + getHScrollPosition(), e.getClientY() - ArgumentMap.this.getAbsoluteTop() + getVScrollPosition());
					myCon.update();
				}
			}
		};
	}

	public void enableCursorTracking() {
		if (!LASAD_Client.getInstance().getRole().equalsIgnoreCase("Observer")) {
			this.cursorTrackingEnabled = true;

			// Timer to allow cursor update
			com.google.gwt.user.client.Timer t = new com.google.gwt.user.client.Timer() {
				public void run() {
					refreshMyCursor = true;
				}
			};
			t.scheduleRepeating(1500);
		}
	}

	/**
	 * Shows up the context menu
	 * 
	 * @param x
	 *            X Position
	 * @param y
	 *            Y Position
	 */
	private void eventContextMenu(int x, int y) {
		add(new CreateBoxDialog(this, x, y));
		this.layout();
	}

	public void extendMapDimension(Direction dir, int value) {
		mapDimensions.put(dir, mapDimensions.get(dir) + value);
		scrollPanel.setSize(getMapDimensionSize().width, getMapDimensionSize().height);
	}

	public SimpleConnector getEndConnector() {
		return endConnector;
	}

	public Connector getEndPoint() {
		return endPoint;
	}

	public FadeableElementHandler getFadeHandler() {
		return fadeHandler;
	}

	public FocusHandler getFocusHandler() {
		return focusHandler;
	}

	public FocusableInterface getFocusParent() {
		// The Map is the Focus Root, so return null
		return null;
	}

	public HighlightHandler getHighlightHandler() {
		return highlightHandler;
	}

	public HighlightableElementInterface getHighlightParent() {
		return null;
	}

	public Size getMapDimensionSize() {
		return new Size(mapDimensions.get(Direction.LEFT) + mapDimensions.get(Direction.RIGHT), mapDimensions.get(Direction.UP) + mapDimensions.get(Direction.DOWN));
	}

	public int getMyAwarenessCursorID() {
		return myAwarenessCursorID;
	}

	public Connection getMyCon() {
		return myCon;
	}

	public MVCViewSession getMyViewSession() {
		return myViewSession;
	}

	public SelectionHandler getSelectionHandler() {
		return selectionHandler;
	}

	public Connector getStartPoint() {
		return startPoint;
	}

	private void initMapDimensions() {
		mapDimensions.put(Direction.UP, 2500);
		mapDimensions.put(Direction.RIGHT, 2500);
		mapDimensions.put(Direction.DOWN, 2500);
		mapDimensions.put(Direction.LEFT, 2500);
		scrollPanel.setSize(getMapDimensionSize().width, getMapDimensionSize().height);
	}

	public boolean isDeleteElementsWithoutConfirmation() {
		return deleteElementsWithoutConfirmation;
	}

	public void recordCursorTracking() {
		if (!LASAD_Client.getInstance().getRole().equalsIgnoreCase("Observer")) {
			if (disableNormalCursorUpdates == false) {

				// Timer to allow cursor update
				disableNormalCursorUpdates = true;

				t = new Timer() {
					public void run() {
						if (numberOfCursorRecords < 10) {
							refreshMyCursorPersistent = true;
						} else {
							numberOfCursorRecords = 0;
							refreshMyCursorPersistent = false;
							disableNormalCursorUpdates = false;

							if (ArgumentMap.this.t != null) {
								ArgumentMap.this.t.cancel();
							}
						}
					}
				};
				t.scheduleRepeating(750);
			}
		}
	}

	public void setDeleteElementsWithoutConfirmation(boolean deleteElementsWithoutConfirmation) {
		this.deleteElementsWithoutConfirmation = deleteElementsWithoutConfirmation;
	}

	public void setElementFocus(boolean focus) {
	}

	public void setEndConnector(SimpleConnector endConnector) {
		this.endConnector = endConnector;
	}

	public void setEndPoint(Connector endPoint) {
		this.endPoint = endPoint;
	}

	public void setFadeHandler(FadeableElementHandler fadeHandler) {
		this.fadeHandler = fadeHandler;
	}

	public void setFocusHandler(FocusHandler focusHandler) {
		this.focusHandler = focusHandler;
	}

	public void setHighlight(boolean highlight) {
	}

	public void setHighlightHandler(HighlightHandler highlightHandler) {
		this.highlightHandler = highlightHandler;
	}

	public void setMyAwarenessCursorID(int myAwarenessCursorID) {
		this.myAwarenessCursorID = myAwarenessCursorID;
	}

	public void setMyCon(Connection myCon) {
		this.myCon = myCon;
	}

	public void setMyViewSession(MVCViewSession myViewSession) {
		this.myViewSession = myViewSession;
	}

	public void setRefreshMyCursor(boolean refreshMyCursor) {
		this.refreshMyCursor = refreshMyCursor;
	}

	public void setSelectionHandler(SelectionHandler selectionHandler) {
		this.selectionHandler = selectionHandler;
	}

	public void setStartPoint(Connector startPoint) {
		this.startPoint = startPoint;
	}
	
	public void releaseAllListeners()
	{
		this.dropTarget.release();
		this.removeAllListeners();
	}
}