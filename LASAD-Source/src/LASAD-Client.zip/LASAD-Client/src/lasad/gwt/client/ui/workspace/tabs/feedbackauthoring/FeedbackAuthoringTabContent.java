package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lasad.gwt.client.communication.LASADActionSender;
import lasad.gwt.client.communication.helper.ActionFactory;
import lasad.gwt.client.logger.Logger;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.DatabaseFA;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.OntologyFA;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.SessionFA;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.TreeFolder;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.TreeFolderChild;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.AgentsGrid;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.ColumnConf;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.GridConf;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.tree.CustomizedTreeGridView;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.FeedbackAuthoringStrings;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.ActionUserEventProperty;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.AddAgentToOntologyEvent;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.AddAgentToSessionEvent;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.OntologyUserActionEventImpl;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.RemoveAgentFromOntologyEvent;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.RemoveAgentFromSessionEvent;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.SessionUserActionEventImpl;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.SessionsUserActionEventImpl;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.StartSessionEvent;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.StopSessionEvent;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.UserActionEventImpl;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.window.AddAgent2Ontology;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.window.AddAgent2Session;
import lasad.shared.communication.objects.parameters.ParameterTypes;
import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;
import lasad.shared.dfki.meta.ServiceStatus;
import lasad.shared.dfki.meta.agents.SupportedOntologiesDef;

import com.extjs.gxt.ui.client.Style.Orientation;
import com.extjs.gxt.ui.client.Style.Scroll;
import com.extjs.gxt.ui.client.Style.SelectionMode;
import com.extjs.gxt.ui.client.data.BaseTreeModel;
import com.extjs.gxt.ui.client.data.ModelData;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.MessageBoxEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.store.ListStore;
import com.extjs.gxt.ui.client.store.TreeStore;
import com.extjs.gxt.ui.client.util.Margins;
import com.extjs.gxt.ui.client.widget.Component;
import com.extjs.gxt.ui.client.widget.ComponentManager;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.Dialog;
import com.extjs.gxt.ui.client.widget.Info;
import com.extjs.gxt.ui.client.widget.MessageBox;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.grid.ColumnConfig;
import com.extjs.gxt.ui.client.widget.grid.ColumnData;
import com.extjs.gxt.ui.client.widget.grid.ColumnModel;
import com.extjs.gxt.ui.client.widget.grid.Grid;
import com.extjs.gxt.ui.client.widget.grid.GridCellRenderer;
import com.extjs.gxt.ui.client.widget.layout.AccordionLayout;
import com.extjs.gxt.ui.client.widget.layout.FillLayout;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.extjs.gxt.ui.client.widget.layout.RowData;
import com.extjs.gxt.ui.client.widget.layout.RowLayout;
import com.extjs.gxt.ui.client.widget.treegrid.TreeGrid;
import com.extjs.gxt.ui.client.widget.treegrid.TreeGridCellRenderer;
import com.extjs.gxt.ui.client.widget.treegrid.TreeGridSelectionModel;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.ui.Widget;




public class FeedbackAuthoringTabContent extends ContentPanel{
	
	private final LASADActionSender communicator = LASADActionSender.getInstance();
	private final ActionFactory actionBuilder = ActionFactory.getInstance();
	
	public int status = 0;
	
	private static FeedbackAuthoringTabContent instance = null;
	
	private DatabaseFA db = new DatabaseFA();
	
	private AgentsGrid agentsPanel;
	
	private static TreeStore<ModelData> sessionsTreeStore = new TreeStore<ModelData>();
	private static TreeStore<ModelData> agent2OntologyTreeStore = new TreeStore<ModelData>();
	private static TreeStore<ModelData> agent2SessionTreeStore = new TreeStore<ModelData>();
	private TreeGrid<ModelData> agents2OntologyTree;
	private TreeGrid<ModelData> agents2SessionTree;
	private TreeGrid<ModelData> sessionsTree;
	
	private LinkedList<UserActionEventImpl> eventsQueue = new LinkedList<UserActionEventImpl>();  //used to update sessions panel after modif. on ontology or session panel.
	
	public static FeedbackAuthoringTabContent getInstance() {
		if (instance == null) {
			instance = new FeedbackAuthoringTabContent();
		}
		return instance;
	}
	
	private FeedbackAuthoringTabContent() {
		super(new RowLayout(Orientation.HORIZONTAL));
	}
	
	private void initContent(){
		//setUpTestData();
		getAgentList();
		getMapList();
		getOntologyList();
		getAgent2Session();
		getAgent2Ontology();
		getSessionsStatus();
	}
	
	private void getAgentList(){
		communicator.sendActionPackage(actionBuilder.getAgentListFA());
	}
	
	private void getMapList(){
		communicator.sendActionPackage(actionBuilder.getMapListFA());
	}
	
	private void getOntologyList(){
		communicator.sendActionPackage(actionBuilder.getOntologyListFA());
	}
	
	private void getAgent2Ontology(){
		communicator.sendActionPackage(actionBuilder.getAgent2OntologyFA());
	}
	
	private void getAgent2Session(){
		communicator.sendActionPackage(actionBuilder.getAgent2SessionFA());
	}
	
	private void getSessionsStatus(){
		communicator.sendActionPackage(actionBuilder.getSessionsStatusFA());
	}	
	
//	private void setUpTestData(){
//		//Setup sessions
//		List<SessionFA> sessionList = TestData.getSessions();
//		for(SessionFA session: sessionList){
//			db.addSession(session);
//		}
//		//Setup ontologies
//		List<OntologyFA> ontoList = TestData.getOntologiesAsOnt();
//		for(OntologyFA ontology: ontoList){
//			db.addOntology(ontology);
//		}
//	}
	
	@Override  
	  protected void onRender(Element parent, int index) {  
	    super.onRender(parent, index);
	    
	    this.setHeaderVisible(false);
	    this.setBodyBorder(false);
//	    this.setLayout(new RowLayout(Orientation.HORIZONTAL));
		
		add(initLeftPanel(), new RowData(0.5, 1.0, new Margins(5)));
		add(initRightPanel(), new RowData(0.5, 1.0, new Margins(5)));
		
		layout();
		initContent();
	}
	
	private ContentPanel initRightPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		//panel.setBodyBorder(false);
		panel.setHeaderVisible(false);
		panel.add(createSessionsPanel());
//		panel.add(new ContentPanel());
		
		return panel;
	}
	
	private ContentPanel initLeftPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new AccordionLayout());
		panel.setHeaderVisible(false);
		panel.add(initLeftPanelContent());
		return panel;
	}
	
	private ContentPanel initLeftPanelContent() {
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new RowLayout(Orientation.VERTICAL));
		panel.setHeaderVisible(false);
		
		agentsPanel = (AgentsGrid) getAgentsPanel();
		panel.add(agentsPanel, new RowData(1.0, 0.34, new Margins(3)));
		panel.add(createOntologiesAgentsPanel(), new RowData(1.0, 0.33, new Margins(3)));
		panel.add(createSessionAgentsPanel(), new RowData(1.0, 0.33, new Margins(3)));
//		panel.add(new ContentPanel(), new RowData(1.0, 0.33, new Margins(3)));
		
		return panel;
	}

//    public void addAgents2Agentpanel(List<AgentDescriptionFE> agentList){
//    	//Clean previous data
//    	agentsPanel.resetGrid();
//    	resetAgentsDB();
//    	//Add new data
//    	for(AgentDescriptionFE agent: agentList){
//    		addAgent2UI(agent);
//        	addAgent2DB(agent);
//        }
//    	agentsPanel.refreshView();
//    }
    
//    public void addAgent2Agentpanel(AgentDescriptionFE agent){
//    	addAgent2UI(agent);
//    	addAgent2DB(agent);
//    	agentsPanel.refreshView();
//    }
    
    /*
     * Add the Agent to the Agent Panel in the UI
     */
    private void addAgent2UI(AgentDescriptionFE agent){
    	String agentId = agent.getAgentID();
    	String agentDisplayname = agent.getDisplayName();
    	String ontology = null;
    	SupportedOntologiesDef supportedOnt = agent.getSupportedOntology();
    	if(supportedOnt != null)
	    	if (supportedOnt.isAllOntologies()){
	    		//TODO add code handle this,
	    		//this happens when "any" is selected on the GUI
	    	}else{
	    		//TODO ask about this multiple ontology support to update code accordingly
	    		List<String> ontList =  supportedOnt.getSupportedOntologies();
	    		if (ontList.size() >= 1){
	    			ontology = ontList.get(0);
	    		}
	    	}
    	boolean configCompleted = agent.isConfigCompleted();
    	boolean readable = agent.isConfReadable();
    	boolean writeable = agent.isConfWritable();
    	agentsPanel.addAgent2Grid(agentId, agentDisplayname, ontology, readable, writeable, configCompleted);
    }

	
	private ContentPanel getAgentsPanel(){
		ContentPanel panel;
		GridConf gridConf = new GridConf();
		
		gridConf.setHeader(FeedbackAuthoringStrings.HEADING_AGENTS);
		gridConf.setMarkReadyButtonFlag(true);
		gridConf.setAddButtonFlag(true);
		gridConf.setViewButtonFlag(true);
		gridConf.setEditButtonFlag(true);
		gridConf.setDeleteButtonFlag(true);
		gridConf.setDuplicateButtonFlag(true);
		gridConf.setCommonLabel(FeedbackAuthoringStrings.AGENT_LABEL);
		
		ColumnConf colTmp = new ColumnConf("name", "Name", 140);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("status", "Status", 180);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("actions", "Actions", 180);
		gridConf.addColConfig(colTmp);
		
		panel = AgentsGrid.getInstance(gridConf, this);
		return panel;
	}
	
	private ContentPanel createOntologiesAgentsPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());

		final ColumnConfig nameCol = new ColumnConfig("name", "<div style=\"color:#000000;\">Ontology</div>", 440);
		ColumnConfig actionsCol = new ColumnConfig("actions", "<div style=\"color:#000000;\">Actions</div>", 80);
		ColumnModel treeCM = new ColumnModel(Arrays.asList(nameCol, actionsCol));
		
		agents2OntologyTree = new TreeGrid<ModelData>(agent2OntologyTreeStore, treeCM);
		
		nameCol.setRenderer(new TreeGridCellRenderer<ModelData>());
		actionsCol.setRenderer(new GridCellRenderer<ModelData>() {
			
			private ContentPanel getAddActionButtonPanel(final ModelData model, String property,
                    ColumnData config, int rowIndex, int colIndex,
                    ListStore<ModelData> store, Grid<ModelData> grid){
				ContentPanel panel = new ContentPanel();
				panel.setLayout(new FillLayout(Orientation.HORIZONTAL));
				panel.setHeaderVisible(false);
				panel.setBodyBorder(false);
				panel.setLayoutOnChange(true);
				panel.setBodyStyle("backgroundColor: transparent;");
				
				Button addButton = new Button();
				addButton.setStyleName("xfa-btn");
				addButton.setStyleName("x-btn-text", true);
				addButton.setStyleName("x-btn", true);
				addButton.setStylePrimaryName("xfa-btn");
				addButton.setIconStyle("icon-plus-circle");//icon-plus-std
				addButton.setWidth(16);
				addButton.setHeight(16);
				addButton.setToolTip(FeedbackAuthoringStrings.ADD_AGENT_LABEL);
				
				addButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  String element = (String) model.get(nameCol.getId());
				    	  //viewElement(element);
				    	  Info.display(element, element);
				    	  BaseTreeModel ontBTM = (BaseTreeModel) agents2OntologyTree.getStore().findModel("name", element);
				    	  List<String> agentList = db.getAgents();
				    	  AddAgent2Ontology selOnt = new AddAgent2Ontology(agentList, (String)ontBTM.get("name"), instance);
				    	  selOnt.show();
				      }
				});
				
				panel.add(addButton, new RowData(0.25, 1.0, new Margins(0)));
				return panel;
			}
			
			private ContentPanel getDeleteActionButtonPanel(final ModelData model, String property,
                    ColumnData config, int rowIndex, int colIndex,
                    ListStore<ModelData> store, Grid<ModelData> grid){
				ContentPanel panel = new ContentPanel();
				panel.setLayout(new FillLayout(Orientation.HORIZONTAL));
				panel.setHeaderVisible(false);
				panel.setBodyBorder(false);
				panel.setLayoutOnChange(true);
				panel.setBodyStyle("backgroundColor: transparent;");
				
				Button deleteButton = new Button();
				
				deleteButton.setStyleName("xfa-btn");
				deleteButton.setStyleName("x-btn-text", true);
				deleteButton.setStyleName("x-btn", true);
				deleteButton.setStylePrimaryName("xfa-btn");
				deleteButton.setIconStyle("icon-delete-circle");//icon-minus-std
				deleteButton.setWidth(16);
				deleteButton.setHeight(16);
				deleteButton.setToolTip(FeedbackAuthoringStrings.REMOVE_AGENT_LABEL);
				deleteButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  final String element = (String) model.get(nameCol.getId());
				    	  BaseTreeModel agBTM = (BaseTreeModel) agents2OntologyTree.getStore().findModel("name", element);
				    	  final String agent = agBTM.get("name");
				    	  final String ontology = agBTM.get("aux"); //the ontology is store here
				    	  			    	  
				    	  ce.setCancelled(true);
				    	  //Initialize message box
				    	  MessageBox box = new MessageBox();
				    	  box.setButtons(MessageBox.YESNO);
				    	  box.setIcon(MessageBox.QUESTION);
				    	  box.setTitle(FeedbackAuthoringStrings.REMOVE_AGENT_LABEL);
				    	  box.setMessage(FeedbackAuthoringStrings.REMOVE_LABEL + " " + agent + " " 
				    			  		+ FeedbackAuthoringStrings.FROM_LABEL + " " 
				    			  		+ ontology + FeedbackAuthoringStrings.QUESTION_MARK);
				    	  box.addCallback(new Listener<MessageBoxEvent>() {
				    		  public void handleEvent(MessageBoxEvent be) {
				    			  if (be.getButtonClicked().getItemId().equals(Dialog.YES)) {
//				    				  BaseTreeModel agBTM = (BaseTreeModel) agents2OntologyTree.getStore().findModel("name", element);
//							    	  String agent = agBTM.get("name");
//							    	  //BaseTreeModel ontBTM = (BaseTreeModel) agBTM.getParent();
//							    	  String ontology = agBTM.get("aux"); //the ontology is store here
							    	  Info.display(element, element + "-" + agent + "-" + ontology);
							    	  handleUserActionEvent(new RemoveAgentFromOntologyEvent(ontology, agent));
				    			  }
				    		  }
				    	  });
				    	  box.show();
				      }
				});
				
				panel.add(deleteButton, new RowData(0.25, 0.25, new Margins(0)));
				return panel;
			}

            @Override
            public Widget render(final ModelData model, String property,
                    ColumnData config, int rowIndex, int colIndex,
                    ListStore<ModelData> store, Grid<ModelData> grid) {
            	if (model instanceof TreeFolderChild){
                	//System.out.println("Is TreeFolderChild!!!!");
                	return getDeleteActionButtonPanel(model, property,
                            config, rowIndex, colIndex, store, grid);
                }
                if (model instanceof TreeFolder){
                	//System.out.println("Is TreeFolder!!!!");
                }
                return getAddActionButtonPanel(model, property,
                        config, rowIndex, colIndex, store, grid);

            }
        });
		
		agents2OntologyTree.setBorders(true);
		agents2OntologyTree.setAutoExpand(false);
		agents2OntologyTree.setAutoExpandColumn("name");
		agents2OntologyTree.setAutoExpandMax(1000);
		agents2OntologyTree.setTrackMouseOver(true);
		agents2OntologyTree.getStyle().setNodeCloseIcon(null);
		agents2OntologyTree.getStyle().setNodeOpenIcon(null);
		
		CustomizedTreeGridView treeGridView = new CustomizedTreeGridView();
		agents2OntologyTree.setView(treeGridView);
//		agentsOntoTree.getTreeView().setRowHeight(28);
//		agentsOntoTree.getTreeView().setRowSelectorDepth(20);
//		agentsOntoTree.getTreeView().setCellSelectorDepth(10);
		
		TreeGridSelectionModel<ModelData> selectionModel = new TreeGridSelectionModel<ModelData>();
		selectionModel.setSelectionMode(SelectionMode.SINGLE);
		selectionModel.setLocked(true);
		agents2OntologyTree.setSelectionModel(selectionModel);

		panel.setHeading(FeedbackAuthoringStrings.HEADING_ONTO_AGENTS);
		panel.setScrollMode(Scroll.AUTOY);
		panel.add(agents2OntologyTree);
		
		return panel;
	}
	
	/*
	 * Functions that interact with Agent to Ontology Panel
	 */
	public void addElems2Agent2OntPanel(Map<String, List<String>> map){
		//Clean previous data
		//here we remove the agents, the ontologies are kept
		for(String ont : getOntologiesDB()){
			ModelData parent = agents2OntologyTree.getTreeStore().findModel("name", ont);
			agents2OntologyTree.getTreeStore().removeAll(parent);
			deleteAllAgentsFromOntologyDB(ont);
		}
		
		Set<String> ontlist = map.keySet();
        for(String ontology: ontlist){
        	List<String> agentList = map.get(ontology);
        	for(String agentId:agentList){
        		addElem2Agent2OntPanel(ontology, agentId);
        	}
        }
	}
	public void addElem2Agent2OntPanel(String ontology, String agentId){
		addAgent2OntologyUI(ontology, agentId);
		addAgent2OntologyDB(ontology, agentId);
	}
	public void deleteElemFromAgent2OntPanel(String ontology, String agent){
		deleteAgentFromOntologyUI(ontology, agent);
		deleteAgentFromOntologyDB(ontology, agent);
	}
	public void addOntologies2OntPanel(List<String> ontologyList){
		addOntologies2OntologyUI(ontologyList);
		addOntologiesDB(ontologyList);
	}
	private void addAgent2OntologyUI(String ontology, String agent){
		ModelData parent = agents2OntologyTree.getTreeStore().findModel("name", ontology);
		TreeFolderChild child = new TreeFolderChild(agent, null, ontology);
		agents2OntologyTree.getTreeStore().add(parent, child, false);
		//agents2OntologyTree.setExpanded(parent, true);
	}
	private void deleteAgentFromOntologyUI(String ontology, String agent){
		ModelData parent = agents2OntologyTree.getTreeStore().findModel("name", ontology);
		List<ModelData> children = agents2OntologyTree.getTreeStore().getChildren(parent);
		ModelData child = null;
		for(int i=0; i < children.size(); i++){
			String agName = children.get(i).get("name"); 
			if(agName.equals(agent)){
				child = children.get(i);
				break;
			}
		}
		agents2OntologyTree.getTreeStore().remove(parent, child);
	}
	private void refreshViewAgent2OntologyUI(){
		if(agents2OntologyTree.isRendered())
			agents2OntologyTree.getView().refresh(false);
	}
	private void addOntologies2OntologyUI(List<String> ontologyList){
		TreeFolder model = new TreeFolder("root", null, null);
		for(String ont: ontologyList){
			TreeFolder child = new TreeFolder(ont, null, null, new TreeFolderChild[]{});
			model.add(child);
		}
		agent2OntologyTreeStore.add(model.getChildren(), true);
	}
	
	/*
	 * Functions that interact with Agent to Session Panel
	 */
	public void addElems2Agent2SesPanel(Map<String, List<String>> map){
		//Clean previous data
		//here we remove the agents, the sessions are kept
		for(String ses : getSessionsDB()){
			ModelData parent = agents2SessionTree.getTreeStore().findModel("name", ses);
			agents2SessionTree.getTreeStore().removeAll(parent);
			deleteAllAgentsFromSessionDB(ses);
		}
		Set<String> seslist = map.keySet();
        for(String sessionId: seslist){
        	String sessionName = getSessionNameDB(sessionId);
        	if(sessionName != null){
        		List<String> agentList = map.get(sessionId);
            	for(String agentName:agentList){
            		addElem2Agent2SesPanel(sessionName, agentName);
            	}
        	}else{
        		Logger.log("[lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.FeedbackAuthoringTabContent]"
						+ "[addElems2Agent2SesPanel]"
						+ "sessionId '" + sessionId + "' is not registered" , Logger.DEBUG_ERRORS);
        	}
        	
        }
		refreshViewAgent2SessionUI();
	}	
	public void addElem2Agent2SesPanel(String sessionName, String agentName){
		addAgent2SessionUI(sessionName, agentName);
		addAgent2SessionDB(sessionName, agentName);
	}
	public void deleteElemFromAgent2SesPanel(String sessionName, String agentName){
		deleteAgentFromSessionUI(sessionName, agentName);
		deleteAgentFromSessionDB(sessionName, agentName);
	}
	public void addSessions2SesPanel(Map<String, String> id2OntMap, Map<String, String> id2NameMap){
		addSessions2SessionUI(id2OntMap, id2NameMap);
		addSessionsDB(id2OntMap, id2NameMap);
	}
	private void addAgent2SessionUI(String sessionName, String agentName){
		ModelData parent = agents2SessionTree.getTreeStore().findModel("name", sessionName);
		TreeFolderChild child = new TreeFolderChild(agentName, null, sessionName);
		agents2SessionTree.getTreeStore().add(parent, child, false);
		//agents2SessionTree.setExpanded(parent, true);
	}
	private void deleteAgentFromSessionUI(String sessionName, String agentName){
		ModelData parent = agents2SessionTree.getTreeStore().findModel("name", sessionName);
		List<ModelData> children = agents2SessionTree.getTreeStore().getChildren(parent);
		ModelData child = null;
		for(int i=0; i < children.size(); i++){
			String agName = children.get(i).get("name"); 
			if(agName.equals(agentName)){
				child = children.get(i);
				break;
			}
		}
		agents2SessionTree.getTreeStore().remove(parent, child);
	}
	private void refreshViewAgent2SessionUI(){
		if(agents2SessionTree.isRendered())
			agents2SessionTree.getView().refresh(false);
	}
	private void addSessions2SessionUI(Map<String, String> id2OntMap, Map<String, String> id2NameMap){
		Set<String> ids = id2OntMap.keySet();
		TreeFolder model = new TreeFolder("root", null, null);
		for(String sessionId: ids){
			String sessionOnt = id2OntMap.get(sessionId);
			String sessionName = id2NameMap.get(sessionId);
			TreeFolder child = new TreeFolder(sessionName, "("+sessionOnt+")", null, new TreeFolderChild[]{});
			model.add(child);
			Logger.log("[lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.FeedbackAuthoringTabContent]"
						+ "[addSessions2SessionUI]"
						+ "Agent -id:" + sessionId + " -name:" + sessionName + " -Ont:" + sessionOnt , Logger.DEBUG);
		}
		agent2SessionTreeStore.add(model.getChildren(), false);
	}
	
	
	private ContentPanel createSessionAgentsPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());

		final ColumnConfig nameCol = new ColumnConfig("name", "<div style=\"color:#000000;\">Session</div>", 160);
		ColumnConfig statusCol = new ColumnConfig("status", "<div style=\"color:#000000;\">Ontology</div>", 280);
		ColumnConfig actionsCol = new ColumnConfig("actions", "<div style=\"color:#000000;\">Actions</div>", 80);
		ColumnModel treeCM = new ColumnModel(Arrays.asList(nameCol, statusCol, actionsCol));
		
		agents2SessionTree = new TreeGrid<ModelData>(agent2SessionTreeStore, treeCM);
		
		nameCol.setRenderer(new TreeGridCellRenderer<ModelData>());
		actionsCol.setRenderer(new GridCellRenderer<ModelData>() {
			
			private ContentPanel getAddActionButtonPanel(final ModelData model, String property,
                    ColumnData config, int rowIndex, int colIndex,
                    ListStore<ModelData> store, Grid<ModelData> grid){
				ContentPanel panel = new ContentPanel();
				panel.setLayout(new FillLayout(Orientation.HORIZONTAL));
				panel.setHeaderVisible(false);
				panel.setBodyBorder(false);
				panel.setLayoutOnChange(true);
				panel.setBodyStyle("backgroundColor: transparent;");
				
				Button addButton = new Button();
				addButton.setStyleName("xfa-btn");
				addButton.setStyleName("x-btn-text", true);
				addButton.setStyleName("x-btn", true);
				addButton.setStylePrimaryName("xfa-btn");
				addButton.setIconStyle("icon-plus-circle");//icon-plus-std
				addButton.setWidth(16);
				addButton.setHeight(16);
				addButton.setToolTip(FeedbackAuthoringStrings.ADD_AGENT_LABEL);
				
				addButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  String element = (String) model.get(nameCol.getId());
				    	  //viewElement(element);
				    	  Info.display(element, element);
				    	  BaseTreeModel ontBTM = (BaseTreeModel) agents2SessionTree.getStore().findModel("name", element);
				    	  List<String> agentList = db.getAgents();
				    	  
				    	  AddAgent2Session selSe = new AddAgent2Session(agentList, (String)ontBTM.get("name"), instance);
				    	  selSe.show();
				      }
				});
				
				panel.add(addButton, new RowData(0.25, 1.0, new Margins(0)));
				return panel;
			}
			
			private ContentPanel getDeleteActionButtonPanel(final ModelData model, String property,
                    ColumnData config, int rowIndex, int colIndex,
                    ListStore<ModelData> store, Grid<ModelData> grid){
				ContentPanel panel = new ContentPanel();
				panel.setLayout(new FillLayout(Orientation.HORIZONTAL));
				panel.setHeaderVisible(false);
				panel.setBodyBorder(false);
				panel.setLayoutOnChange(true);
				panel.setBodyStyle("backgroundColor: transparent;");
				
				Button deleteButton = new Button();
				
				deleteButton.setStyleName("xfa-btn");
				deleteButton.setStyleName("x-btn-text", true);
				deleteButton.setStyleName("x-btn", true);
				deleteButton.setStylePrimaryName("xfa-btn");
				deleteButton.setIconStyle("icon-delete-circle");
				deleteButton.setWidth(16);
				deleteButton.setHeight(16);
				deleteButton.setToolTip(FeedbackAuthoringStrings.REMOVE_AGENT_LABEL);
				deleteButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  final String element = (String) model.get(nameCol.getId());
				    	  BaseTreeModel agBTM = (BaseTreeModel) agents2SessionTree.getStore().findModel("name", element);
				    	  final String agent = agBTM.get("name");
				    	  final String session = agBTM.get("aux"); //the session is store here
				    	  
				    	  ce.setCancelled(true);
				    	  //Initialize message box
				    	  MessageBox box = new MessageBox();
				    	  box.setButtons(MessageBox.YESNO);
				    	  box.setIcon(MessageBox.QUESTION);
				    	  box.setTitle(FeedbackAuthoringStrings.REMOVE_AGENT_LABEL);
				    	  box.setMessage(FeedbackAuthoringStrings.REMOVE_LABEL + " " + agent + " " 
			    			  		+ FeedbackAuthoringStrings.FROM_LABEL + " " 
			    			  		+ session + FeedbackAuthoringStrings.QUESTION_MARK);
//				    	  box.setMessage(FeedbackAuthoringStrings.CONFIRMATION_DELETE + agent + FeedbackAuthoringStrings.QUESTION_MARK);
				    	  box.addCallback(new Listener<MessageBoxEvent>() {
				    		  public void handleEvent(MessageBoxEvent be) {
				    			  if (be.getButtonClicked().getItemId().equals(Dialog.YES)) {
//				    				  BaseTreeModel agBTM = (BaseTreeModel) agents2SessionTree.getStore().findModel("name", element);
//							    	  String agent = agBTM.get("name");
//							    	  //BaseTreeModel ontBTM = (BaseTreeModel) agBTM.getParent();
//							    	  String session = agBTM.get("aux"); //the session is store here
							    	  Info.display(element, element + "-" + agent + "-" + session);
							    	  handleUserActionEvent(new RemoveAgentFromSessionEvent(session, agent));
				    			  }
				    		  }
				    	  });
				    	  box.show();
				      }
				});
				
				panel.add(deleteButton, new RowData(0.25, 0.25, new Margins(0)));
				return panel;
			}

            @Override
            public Widget render(final ModelData model, String property,
                    ColumnData config, int rowIndex, int colIndex,
                    ListStore<ModelData> store, Grid<ModelData> grid) {
            	if (model instanceof TreeFolderChild){
                	//System.out.println("Is TreeFolderChild!!!!");
                	return getDeleteActionButtonPanel(model, property,
                            config, rowIndex, colIndex, store, grid);
                }
                if (model instanceof TreeFolder){
                	//System.out.println("Is TreeFolder!!!!");
                }
                return getAddActionButtonPanel(model, property,
                        config, rowIndex, colIndex, store, grid);
            }
        });
		
		agents2SessionTree.setBorders(true);
		agents2SessionTree.setAutoExpand(false);
		agents2SessionTree.setAutoExpandColumn("name");
		agents2SessionTree.setAutoExpandMax(1000);
		agents2SessionTree.setTrackMouseOver(true);
		agents2SessionTree.getTreeView().setRowHeight(28);
		agents2SessionTree.getStyle().setNodeCloseIcon(null);
		agents2SessionTree.getStyle().setNodeOpenIcon(null);
		
		TreeGridSelectionModel<ModelData> selectionModel = new TreeGridSelectionModel<ModelData>();
		selectionModel.setSelectionMode(SelectionMode.SINGLE);
		selectionModel.setLocked(true);
		agents2SessionTree.setSelectionModel(selectionModel);//new TreeGridSelectionModel<ModelData>()

		panel.setHeading(FeedbackAuthoringStrings.HEADING_SESSIONS_AGENTS);
		panel.setScrollMode(Scroll.AUTOY);
		panel.add(agents2SessionTree);
		
		return panel;
	}
	
	
	public void addElem2SessionsPanel(String session, ServiceStatus status){
		add2SessionsUI(session, status);
	}
	public void addElem2SessionsPanel(String session, String agent, ServiceStatus agentStatus){
		add2SessionsUI(session, agent, agentStatus);
	}
	public void removeElemFromSessionsPanel(String session, String agent){
		removeFromSessionsUI(session, agent);
	}
	public void updateParentOnSessionsPanel(String sessionName, ServiceStatus oldStatus, ServiceStatus newStatus){
		updateOnSessionsUI(sessionName, oldStatus, newStatus);
	}
	
	private void add2SessionsUI(String session, ServiceStatus status){
		TreeFolder model = new TreeFolder("root", null, null);
		TreeFolder child = new TreeFolder(session, status.toString(), null, new TreeFolderChild[]{});
		model.add(child);
		sessionsTree.getTreeStore().add(model.getChildren(), false);
	}
	private void add2SessionsUI(String session, String agent, ServiceStatus status){
		ModelData parent = sessionsTree.getTreeStore().findModel("name", session);
		TreeFolderChild child = new TreeFolderChild(agent, status.toString(), session);
		sessionsTree.getTreeStore().add(parent, child, false);
		//sessionsTree.setExpanded(parent, true);
	}
	private void removeFromSessionsUI(String session, String agent){
		ModelData parent = sessionsTree.getTreeStore().findModel("name", session);
		TreeFolderChild child = new TreeFolderChild(agent, "", session);
		int index = sessionsTree.getTreeStore().getChildren(parent).indexOf(child);
		child = (TreeFolderChild) sessionsTree.getTreeStore().getChild(parent, index);
		sessionsTree.getTreeStore().remove(parent, child);
	}
	private void updateOnSessionsUI(String sessionName, ServiceStatus oldStatus, ServiceStatus newStatus){
		ModelData parent = sessionsTree.getTreeStore().findModel("name", sessionName);
		parent.set("status", newStatus.toString());
		String name = parent.get("name");
		if(ServiceStatus.isActive(newStatus)){
			//String name = (String) model.get(nameCol.getId());
			Component temp = ComponentManager.get().get(name + "play"); 
			ComponentManager.get().get(name + "play").setVisible(false);
			ComponentManager.get().get(name + "stop").setVisible(true);
		} else{
			ComponentManager.get().get(name + "play").setVisible(true);
			ComponentManager.get().get(name + "stop").setVisible(false);
		}
		
		
//		set("name", name);
//		set("status", status);
//		set("aux", aux);
//		ModelData parentActionsCol = sessionsTree.getTreeStore().findModel("actions", sessionName);
//		com.google.gwt.dom.client.Element changeRow = sessionsTree.getTreeView().getRow(parentActionsCol);
	}
	
	public boolean removeAllElemInstancesFromSessionsPanel(List<String> sessionList, String agent){
		boolean retVal = false;
		TreeFolderChild child = new TreeFolderChild(agent, "", "");
		for(String session:sessionList){
			if(!isAgentInSessionDB(session, agent)){
				ModelData parent = sessionsTree.getTreeStore().findModel("name", session);
				int index = sessionsTree.getTreeStore().getChildren(parent).indexOf(child);
				child = (TreeFolderChild) sessionsTree.getTreeStore().getChild(parent, index);
				sessionsTree.getTreeStore().remove(parent, child);
				retVal = true;
			}
		}
		return retVal;
	}
	
	//public void deleteAgentFromSessionsTree(AgentFA agent, String session){
//	
//	ModelData parent = sessionsTree.getTreeStore().findModel("name", session);
//	List<ModelData> children = sessionsTree.getTreeStore().getChildren(parent);
//	ModelData child = null;
//	for(int i=0; i < children.size(); i++){
//		String agName = children.get(i).get("name"); 
//		if(agName.equals(agent.getAgentName())){
//			child = children.get(i);
//			break;
//		}
//	}
//	sessionsTree.getTreeStore().remove(parent, child);
//	sessionsTree.getView().refresh(false);
//}
	
	
	private void refreshViewSessionsUI(){
		if(sessionsTree.isRendered())
			sessionsTree.getView().refresh(true);
	}
	
	private ContentPanel createSessionsPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		
		TreeFolder model = new TreeFolder("root", null, null);

		sessionsTreeStore = new TreeStore<ModelData>();
		sessionsTreeStore.add(model.getChildren(), true);

		final ColumnConfig nameCol = new ColumnConfig("name", "<div style=\"color:#000000;\">Session</div>", 160);
		final ColumnConfig statusCol = new ColumnConfig("status", "<div style=\"color:#000000;\">Status</div>", 280);
		ColumnConfig actionsCol = new ColumnConfig("actions", "<div style=\"color:#000000;\">Actions</div>", 80);
		
		ColumnModel treeCM = new ColumnModel(Arrays.asList(nameCol, statusCol, actionsCol));
		
		nameCol.setRenderer(new TreeGridCellRenderer<ModelData>());
		actionsCol.setRenderer(new GridCellRenderer<ModelData>() {
			
			private ContentPanel getEmptyActionButtonsPanel(){
				ContentPanel panel = new ContentPanel();
				panel.setHeaderVisible(false);
				panel.setBodyBorder(false);
				panel.setBodyStyle("backgroundColor: transparent;");
				return panel;
			}
			private ContentPanel getStartStopButtonPanel(final ModelData model, String property,
                    ColumnData config, int rowIndex, int colIndex,
                    ListStore<ModelData> store, Grid<ModelData> grid, boolean isActive, String name){
				ContentPanel panel = new ContentPanel();
				panel.setLayout(new FillLayout(Orientation.HORIZONTAL));
				panel.setHeaderVisible(false);
				panel.setBodyBorder(false);
				panel.setLayoutOnChange(true);
				panel.setBodyStyle("backgroundColor: transparent;");
				
				Button playButton = new Button();
				playButton.setId(name+"play");
				playButton.setStyleName("xfa-btn");
				playButton.setStyleName("x-btn-text", true);
				playButton.setStyleName("x-btn", true);
				playButton.setStylePrimaryName("xfa-btn");
				playButton.setIconStyle("icon-play");
				playButton.setWidth(16);
				playButton.setHeight(16);
				playButton.setToolTip(FeedbackAuthoringStrings.START_SESSION_LABEL);
				playButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  String element = (String) model.get(nameCol.getId());
				    	  Info.display(element, element);
				    	  //TODO define what actions to do here
//				    	  BaseTreeModel ontBTM = (BaseTreeModel) sessionsTree.getStore().findModel("name", element);
				    	//String session = agBTM.get("name");
				    	  //handleStartSessionEvent(element);
				    	  handleUserActionEvent(new StartSessionEvent(element, null));
				      }
				});
				panel.add(playButton, new RowData(0.25, 1.0, new Margins(0)));
				
				Button stopButton = new Button();
				stopButton.setId(name+"stop");
				stopButton.setStyleName("xfa-btn");
				stopButton.setStyleName("x-btn-text", true);
				stopButton.setStyleName("x-btn", true);
				stopButton.setStylePrimaryName("xfa-btn");
				stopButton.setIconStyle("icon-stop");
				stopButton.setWidth(16);
				stopButton.setHeight(16);
				stopButton.setToolTip(FeedbackAuthoringStrings.STOP_SESSION_LABEL);
				stopButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  String element = (String) model.get(nameCol.getId());
				    	  Info.display(element, element);
				    	  //BaseTreeModel agBTM = (BaseTreeModel) sessionsTree.getStore().findModel("name", element);
				    	  //String session = agBTM.get("name");
				    	  //TODO define what actions to do here
				    	  //handleStopSessionEvent(element);
				    	  handleUserActionEvent(new StopSessionEvent(element, null));
				      }
				});
				panel.add(stopButton, new RowData(0.25, 0.25, new Margins(0)));
				if(isActive){
					stopButton.setVisible(true);
					playButton.setVisible(false);
				} else{
					stopButton.setVisible(false);
					playButton.setVisible(true);
				}
				return panel;
			}
			
            @Override
            public Widget render(final ModelData model, String property,
                    ColumnData config, int rowIndex, int colIndex,
                    ListStore<ModelData> store, Grid<ModelData> grid) {
            	
                if (model instanceof TreeFolderChild){
                	return getEmptyActionButtonsPanel();
                } else{ //(model instanceof TreeFolder)
                	String status = (String) model.get(statusCol.getId());
                	String name = (String) model.get(nameCol.getId());
                	boolean isActive = ServiceStatus.isActive(ServiceStatus.valueOf(status));
                	return getStartStopButtonPanel(model, property, config, rowIndex, colIndex, store, grid, isActive, name);
//                	ContentPanel testPanel = getStartStopButtonPanel(model, property, config, rowIndex, colIndex, store, grid, isActive);
//                	Button button = (Button) testPanel.getItemByItemId("play");
//                	button.setVisible(true);
//                	button = (Button) testPanel.getItemByItemId("stop");
//                	button.setVisible(false);
//                	return testPanel;
//
//                	if(ServiceStatus.isActive(ServiceStatus.valueOf(status))){
//                		return getStopButtonPanel(model, property, config, rowIndex, colIndex, store, grid);
//                	}else{
//                		return getStartButtonPanel(model, property, config, rowIndex, colIndex, store, grid);
//                	}
                }

            }
        });
		
		sessionsTree = new TreeGrid<ModelData>(sessionsTreeStore, treeCM);
		sessionsTree.setBorders(true);
		sessionsTree.setAutoExpand(false);
		sessionsTree.setAutoExpandColumn("name");
		sessionsTree.setAutoExpandMax(1000);
		sessionsTree.setTrackMouseOver(true);
		sessionsTree.getStyle().setNodeCloseIcon(null);
		sessionsTree.getStyle().setNodeOpenIcon(null);
		
		CustomizedTreeGridView treeGridView = new CustomizedTreeGridView();
		sessionsTree.setView(treeGridView);
		
		TreeGridSelectionModel<ModelData> selectionModel = new TreeGridSelectionModel<ModelData>();
		selectionModel.setSelectionMode(SelectionMode.SINGLE);
		selectionModel.setLocked(true);
		sessionsTree.setSelectionModel(selectionModel);

		panel.setHeading(FeedbackAuthoringStrings.HEADING_SESSIONS);
		panel.setScrollMode(Scroll.AUTOY);
		panel.add(sessionsTree);
		
		return panel;
	}
	
	/*
	 * DB methods wrappers
	 */
	public void addOntologyDB(String ontology){
		db.addOntology(new OntologyFA(ontology));
	}
	public void addOntologiesDB(List<String> ontologyList){
		for(String ont: ontologyList){
			db.addOntology(new OntologyFA(ont));
		}
	}
	public void resetOntologies(){
		db.resetOntologies();
	}
	public Set<String> getOntologiesDB(){
		return db.getOntologies();
	}
	
	public AgentDescriptionFE getAgentFromDB(String agentName){
		return db.getAgent(agentName);
	}
	public void deleteAgentFromDB(String agentName){
		db.deleteAgent(agentName);
	}
	public void addAgent2DB(AgentDescriptionFE agent){
		db.addAgent(agent);
	}
	public void resetAgentsDB(){
		db.resetAgents();
	}
	public List<String> getOnt4AgentFromDB(String agentName){
		return db.getOnt4Ag(agentName);
	}
	public List<String> getSes4AgentFromDB(String agentName){
		return db.getSes4Ag(agentName);
	}
	public void deleteAllAgentsFromSessionDB(String session){
		db.deleteAllAgentsFromSession(session);
	}
	public List<String> getSessionsWithOntologyFromDB(String ontology){
		return db.getSessionsWithOntology(ontology);
	}
	public void addAgent2OntologyDB(String ontology, String agent){
		db.addAgent2Ontology(agent, ontology);
	}
	public void deleteAgentFromOntologyDB(String ontology, String agent){
		db.deleteAgentFromOntology(agent, ontology);
	}
	public void deleteAllAgentsFromOntologyDB(String ontology){
		db.deleteAllAgentsFromOntology(ontology);
	}
	public boolean isAgentInOntologyDB(String ontology, String agent){ 
		return db.isAgentInOntology(ontology, agent);
	}
	
	public void addAgent2SessionDB(String session, String agent){
		db.addAgent2Session(agent, session);
	}
	public boolean isAgentInSessionDB(String session, String agent){ 
		return db.isAgentInSession(session, agent);
	}
	public void deleteAgentFromSessionDB(String session, String agent){
		db.deleteAgentFromSession(agent, session);
	}
	public void addSessionDB(SessionFA session){
		db.addSession(session);
	}
	public void addSessionsDB(Map<String, String> id2OntMap, Map<String, String> id2NameMap){
		Set<String> ids = id2OntMap.keySet();
		for(String sessionId: ids){
			String sessionOnt = id2OntMap.get(sessionId);
			String sessionName = id2NameMap.get(sessionId);
			SessionFA sessionFA = new SessionFA(sessionId, sessionName, sessionOnt, ""); 
			addSessionDB(sessionFA);
		}
	}
	public void resetSessionDB(){
		db.resetSessions();
	}
	public Set<String> getSessionsDB(){
		return db.getSessions();
	}
	public String getSessionNameDB(String sessionId){
		return db.getSessionName(sessionId);
	}
	public String getSessionIdDB(String sessionName){
		return db.getSessionId(sessionName);
	}
	public SessionFA getSessionDB(String sessionName){
		return db.getSession(sessionName);
	}
	
	/*
	 * Methods to handle incoming messages from Feedback Engine
	 */
	public void handleListOntologies(List<String> ontologyList){
		addOntologies2OntPanel(ontologyList);
		refreshViewAgent2OntologyUI();
	}
	public void handleGetOntologyDetails(){
		//TODO
	}
	public void handleListMap(Map<String, String> id2OntMap, Map<String, String> id2NameMap){
		addSessions2SesPanel(id2OntMap, id2NameMap);
		refreshViewAgent2SessionUI();
	}
	public void handleMapdetails(){
		//TODO
	}
	public void handleListAgentsInfo(List<AgentDescriptionFE> agentList){
		//Clean previous data
    	agentsPanel.resetGrid();
    	resetAgentsDB();
    	//Add new data
    	for(AgentDescriptionFE agent: agentList){
    		addAgent2UI(agent);
        	addAgent2DB(agent);
        }
    	agentsPanel.refreshView();
	}
	public void handleAddAgentToOntology(String agentId, String ontology){
		addElem2Agent2OntPanel(ontology, agentId);
		refreshViewAgent2OntologyUI();
		
		//add agent to all sessions with the given ontology in sessions panel
		boolean flag = false;
		List<String> sessionList =  getSessionsWithOntologyFromDB(ontology);
		for(String session:sessionList){
			if(!isAgentInSessionDB(session, agentId)){
				//the agent is not assigned in session panel
				addElem2SessionsPanel(session, agentId, ServiceStatus.READY_TO_START);
				flag = true;
			}
		}
		if (flag){
			refreshViewSessionsUI();
		}
		
	}
	public void handleRemoveAgentFromOntology(String agentId, String ontology){
		deleteElemFromAgent2OntPanel(ontology, agentId);
		refreshViewAgent2OntologyUI();
		
		//delete from all sessions with the given ontology in sessions panel
		//but not if the agent is assigned in session panel
		List<String> sessionList =  getSessionsWithOntologyFromDB(ontology);
		if (removeAllElemInstancesFromSessionsPanel(sessionList, agentId)){
			refreshViewSessionsUI();
		}
	}
	public void handleListAgentsToOntologies(Map<String, List<String>> map){
		addElems2Agent2OntPanel(map);
		refreshViewAgent2OntologyUI();
	}
	public void handleAddAgentToSession(String agentId, String sessionId){
		//TODO check if we need to get the session name or we have it already
		String sessionName = getSessionNameDB(sessionId);
		addElem2Agent2SesPanel(sessionName, agentId);
		refreshViewAgent2SessionUI();
		
		//add agent to session in sessions panel
		SessionFA sessionFA = getSessionDB(sessionName);
		if(!isAgentInOntologyDB(sessionFA.getOntology(), agentId)){
			//the agent is not assigned in ontology panel
			addElem2SessionsPanel(sessionName, agentId, ServiceStatus.READY_TO_START);
			refreshViewSessionsUI();
		}
	}
	public void handleRemoveAgentFromSession(String agentId, String sessionId){
		//TODO check if we need to get the session name or we have it already
		String sessionName = getSessionNameDB(sessionId);
		deleteElemFromAgent2SesPanel(sessionName, agentId);
		refreshViewAgent2SessionUI();
		
		//delete agent from session in sessions panel
		//but not if the agent is assigned in session panel
		SessionFA sessionFA = getSessionDB(sessionName);
		if(!isAgentInOntologyDB(sessionFA.getOntology(), agentId)){
			//the agent is not assigned in ontology panel
			removeFromSessionsUI(sessionName, agentId);
			refreshViewSessionsUI();
		}
	}
	public void handleListAgentsToSessions(Map<String, List<String>> map){
		addElems2Agent2SesPanel(map);
		refreshViewAgent2SessionUI();
	}
	public void handleListSessionStatus(Map<String, ServiceStatus> sessionID2Status, Map<String, Map<String, ServiceStatus>> sessionID2agent2Status){
		//Clean previous data
		//here we remove the agents, the sessions are kept
		for(String ses : getSessionsDB()){
			ModelData parent = sessionsTree.getTreeStore().findModel("name", ses);
			sessionsTree.getTreeStore().removeAll();
			deleteAllAgentsFromSessionDB(ses);   //TODO check if we really need to store all this.
		}
		
		Set<String> seslist = sessionID2Status.keySet();
        for(String session: seslist){
        	//String sessionStatus = sessionID2Status.get(session).toString();
        	ServiceStatus sessionStatus = sessionID2Status.get(session);
        	String sessionName = getSessionNameDB(session);
        	addElem2SessionsPanel(sessionName, sessionStatus);
        	
        	Map<String, ServiceStatus> agent2StatusMap = sessionID2agent2Status.get(session);
        	if(agent2StatusMap != null){
        		Set<String> agentList = agent2StatusMap.keySet();
            	for(String agent : agentList){
            		//String agentStatus = agent2StatusMap.get(agent).toString();
            		ServiceStatus agentStatus = agent2StatusMap.get(agent);
            		addElem2SessionsPanel(sessionName, agent, agentStatus);
            	}
        	}
        	
        }
        refreshViewSessionsUI();
	}
	public void handleCompileAgent(String agentId){
		//TODO
	}
	public void handleAgentMappingDeleted(String agentId, List<String> ontologyList, List<String> sessionIdList){
		//TODO check if this works
		//remove agent from ontology panel
		for(String ontology:ontologyList){
			deleteAgentFromOntologyUI(ontology, agentId);
		}
		refreshViewAgent2OntologyUI();
		//remove agent from session panel
		for(String sessionId: sessionIdList){
			String sessionName = getSessionNameDB(sessionId);
			deleteAgentFromSessionUI(sessionName, agentId);
		}
		refreshViewAgent2SessionUI();
		//remove agent from sessions panel
		if (removeAllElemInstancesFromSessionsPanel(sessionIdList, agentId)){
			refreshViewSessionsUI();
		}
	}
	public void handleComponentRuntimeStatusChanged(String componentId, ServiceStatus oldStatus, ServiceStatus newStatus){
		//TODO
	}
	public void handleSessionRuntimeStatusChanged(String sessionId, ServiceStatus oldStatus, ServiceStatus newStatus){
		String sessionName = getSessionNameDB(sessionId);
		updateParentOnSessionsPanel(sessionName, oldStatus, newStatus);
		refreshViewSessionsUI();
	}
	
	/*
	 * Method to handle user action events on GUI
	 */
	public void handleUserActionEvent(UserActionEventImpl event){
		if (event instanceof OntologyUserActionEventImpl){
			if (event instanceof AddAgentToOntologyEvent){
				AddAgentToOntologyEvent ev = (AddAgentToOntologyEvent)event;
				String agent = ev.getProperty(ActionUserEventProperty.agent);
				String ontology = ev.getProperty(ActionUserEventProperty.ontology);
				communicator.sendActionPackage(actionBuilder.getAddAgentToOntologyFA(agent, ontology));
			}else if (event instanceof RemoveAgentFromOntologyEvent){
				RemoveAgentFromOntologyEvent ev = (RemoveAgentFromOntologyEvent)event;
				String agent = ev.getProperty(ActionUserEventProperty.agent);
				String ontology = ev.getProperty(ActionUserEventProperty.ontology);
				communicator.sendActionPackage(actionBuilder.getRemoveAgentFromOntologyFA(agent, ontology));
			}
		}else if (event instanceof SessionUserActionEventImpl){
			if (event instanceof AddAgentToSessionEvent){
				AddAgentToSessionEvent ev = (AddAgentToSessionEvent)event;
				String agent = ev.getProperty(ActionUserEventProperty.agent);
				String session = ev.getProperty(ActionUserEventProperty.session);
				String sessionID = getSessionIdDB(session);
				communicator.sendActionPackage(actionBuilder.getAddAgentToSessionFA(agent, sessionID));
			}else if (event instanceof RemoveAgentFromSessionEvent){
				RemoveAgentFromSessionEvent ev = (RemoveAgentFromSessionEvent)event;
				String agent = ev.getProperty(ActionUserEventProperty.agent);
				String session = ev.getProperty(ActionUserEventProperty.session);
				String sessionID = getSessionIdDB(session);
				communicator.sendActionPackage(actionBuilder.getRemoveAgentFromSessionFA(agent, sessionID));
			}
		}else if (event instanceof SessionsUserActionEventImpl){
			if (event instanceof StartSessionEvent){
				StartSessionEvent ev = (StartSessionEvent)event;
				String session = ev.getProperty(ActionUserEventProperty.session);
				String sessionID = getSessionIdDB(session);
				communicator.sendActionPackage(actionBuilder.getStartSessionFA(sessionID));
			}else if (event instanceof StopSessionEvent){
				StopSessionEvent ev = (StopSessionEvent)event;
				String session = ev.getProperty(ActionUserEventProperty.session);
				String sessionID = getSessionIdDB(session);
				communicator.sendActionPackage(actionBuilder.getStopSessionFA(sessionID));
			}
		}else{
			Logger.log("[lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.FeedbackAuthoringTabContent]"
					+ "[handleUserActionEvent]"
					+ "Invalid event", Logger.DEBUG_ERRORS);
		}
	}
	
	/*
	 * Functions to Handle User Actions on GUI
	 */
	//Agents Panel
	public void handleAddOrUpdateAgentEvent(AgentDescriptionFE agent){
		communicator.sendActionPackage(actionBuilder.getAddOrUpdateAgentFA(agent));
	}
	public void handleDeleteAgentEvent(String agent){
		communicator.sendActionPackage(actionBuilder.getDeleteAgentFA(agent));
	}
	
	
//		agentsStore = new TreeStore<ModelData>();
//		agentsTree.addListener(Events.OnMouseOver, new Listener<TreeGridEvent>() {
//			public void handleEvent(TreeGridEvent be) {
//				ModelData m = be.getModel();
//				if (m != null) {
//					if (m.get("name") != null) {
//						System.out.println("OnMouseOver Agent: name - " + m.get("name"));
//						//loadMapDetails(Integer.parseInt((String) m.get("mapid")));
//					}
//				}
//			}
//		});

//	public void addAgentToSessionTree(String agent, String session){
//	
//	//Add agent to Tree, i.e. in GUI
//	ModelData parent = agents2SessionTree.getTreeStore().findModel("name", session);
//	TreeFolderChild child = new TreeFolderChild(agent, null, session);
//	agents2SessionTree.getTreeStore().add(parent, child, false);
//	agents2SessionTree.setExpanded(parent, true);
//	agents2SessionTree.getView().refresh(false);
//	//Add agent to Sessions Tree (right panel)
//	AgentFA agentObj = db.getAgent(agent);
//	addAgentToSessionsTree(agentObj, session);
//	sessionsTree.setExpanded(parent, true);
//	sessionsTree.getView().refresh(false);
//	//Reflect change in  DB
//	db.addAgent2Session(agent, session);
//}


//public void deleteAgentFromSessionTree(String agent, String session){
//	//Remove agent from Tree, i.e. in GUI
//	ModelData parent = agents2SessionTree.getTreeStore().findModel("name", session);
//	List<ModelData> children = agents2SessionTree.getTreeStore().getChildren(parent);
//	ModelData child = null;
//	for(int i=0; i < children.size(); i++){
//		String agName = children.get(i).get("name"); 
//		if(agName.equals(agent)){
//			child = children.get(i);
//			break;
//		}
//	}
//	agents2SessionTree.getTreeStore().remove(parent, child);
//	agents2SessionTree.getView().refresh(false);
//	//Remove agent from Sessions Tree (right panel)
//	AgentFA agentObj = db.getAgent(agent);
//	deleteAgentFromSessionsTree(agentObj, session);
//	sessionsTree.getView().refresh(false);
//	//Reflect change in DB
//	db.deleteAgentFromSession(agent, session);
//}

//public void addAgentToOntologyTree(String agent, String ontology){
////Add agent to Tree, i.e. in GUI
//ModelData parent = agents2OntologyTree.getTreeStore().findModel("name", ontology);
//TreeFolderChild child = new TreeFolderChild(agent, null, ontology);
//agents2OntologyTree.getTreeStore().add(parent, child, false);
//agents2OntologyTree.setExpanded(parent, true);
//agents2OntologyTree.getView().refresh(false);
////Add agent to Sessions Tree (right panel)
////the agent needs to be added to all the sessions with the same provided ontology
//List<String> sessions = getSessionsWithOntologyFromDB(ontology);
//for(String sessionName:sessions){
//	AgentDescriptionFE agentObj = getAgentFromDB(agent);
//	addAgentToSessionsTree(agentObj, sessionName);
//	sessionsTree.setExpanded(parent, true);
//}
//sessionsTree.getView().refresh(false);
////Reflect change in  DB
//db.addAgent2Ontology(agent, ontology);
//}

//public void deleteAgentFromOntologyTree(String agent, String ontology){
//	//Remove agent from Tree, i.e. in GUI
//	ModelData parent = agents2OntologyTree.getTreeStore().findModel("name", ontology);
//	List<ModelData> children = agents2OntologyTree.getTreeStore().getChildren(parent);
//	ModelData child = null;
//	for(int i=0; i < children.size(); i++){
//		String agName = children.get(i).get("name"); 
//		if(agName.equals(agent)){
//			child = children.get(i);
//			break;
//		}
//	}
//	agents2OntologyTree.getTreeStore().remove(parent, child);
//	agents2OntologyTree.getView().refresh(false);
//	//Remove agent from Sessions Tree (right panel)
//	//the agent needs to be removed from all the sessions with the provided ontology
//	List<String> sessions = db.getSessionsForOntology(ontology);
//	for(String sessionName:sessions){
//		AgentFA agentObj = db.getAgent(agent);
//		deleteAgentFromSessionsTree(agentObj, sessionName);
//	}
//	sessionsTree.getView().refresh(false);
//	//Reflect change in  DB
//	db.deleteAgentFromOntology(agent, ontology);
//}
//	
//	public void addAgentToSessionsTree(AgentDescriptionFE agent, String session){
//		ModelData parent = sessionsTree.getTreeStore().findModel("name", session);
//		TreeFolderChild child = new TreeFolderChild(agent.getAgentID(), getAgentStatusLabel(agent), session);
//		sessionsTree.getTreeStore().add(parent, child, false);
//		sessionsTree.setExpanded(parent, true);
//		sessionsTree.getView().refresh(false);
//	}
//
//	private String getAgentStatusLabel(AgentDescriptionFE agent){
//		StringBuffer buf = new StringBuffer();
//		buf.append("(");
//		if(agent.getStatus() == FATConstants.ACTIVE_STATUS){
//			buf.append(FeedbackAuthoringStrings.ACTIVE_LABEL);
//		}
//		else{
//			buf.append(FeedbackAuthoringStrings.INACTIVE_LABEL);
//		}
//		buf.append(", ");
//		switch(agent.getStatusReason()){
//			case FATConstants.RUNNING_STATUS:{
//				buf.append(FeedbackAuthoringStrings.RUNNING_LABEL);
//				break;
//			}
//			case FATConstants.STOPPED_STATUS:{
//				buf.append(FeedbackAuthoringStrings.STOPPED_LABEL);
//				break;
//			}
//			case FATConstants.WAITING_4_SESSION_RESTART_STATUS:{
//				buf.append(FeedbackAuthoringStrings.WAITING_4_SESSION_RESTART_LABEL);
//				break;
//			}
//			case FATConstants.MARKED_4_DEL_STATUS:{
//				buf.append(FeedbackAuthoringStrings.MARKED_4_DEL_LABEL);
//				break;
//			}
//		}
//		buf.append(")");
//		return buf.toString();
//	}

//public void deleteAgentFromSessionsTree(AgentFA agent, String session){
//	
//	ModelData parent = sessionsTree.getTreeStore().findModel("name", session);
//	List<ModelData> children = sessionsTree.getTreeStore().getChildren(parent);
//	ModelData child = null;
//	for(int i=0; i < children.size(); i++){
//		String agName = children.get(i).get("name"); 
//		if(agName.equals(agent.getAgentName())){
//			child = children.get(i);
//			break;
//		}
//	}
//	sessionsTree.getTreeStore().remove(parent, child);
//	sessionsTree.getView().refresh(false);
//}

}