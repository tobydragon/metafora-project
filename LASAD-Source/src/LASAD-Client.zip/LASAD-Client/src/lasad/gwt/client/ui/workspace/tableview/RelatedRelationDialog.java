package lasad.gwt.client.ui.workspace.tableview;

import java.util.Vector;

import lasad.gwt.client.model.MVCViewRecipient;
import lasad.gwt.client.model.MVCViewSession;
import lasad.gwt.client.model.UnspecifiedElementModel;

import com.extjs.gxt.ui.client.widget.Dialog;
import com.extjs.gxt.ui.client.widget.layout.AccordionLayout;

public class RelatedRelationDialog extends Dialog{

	//*************************************************************************************
	//	Fields
	//*************************************************************************************
	
	private Vector<UnspecifiedElementModel> models;
	
	private MVCViewSession session;
	
	//*************************************************************************************
	//	Constructor
	//*************************************************************************************
	
	public RelatedRelationDialog(Vector<UnspecifiedElementModel> models, MVCViewSession session) {
		
		this.models = models;
		this.session = session;
		
		setHeading("Related relations ...");
		setHideOnButtonClick(true);
		setButtons(Dialog.OK);
		setModal(true);
		setClosable(false);
		setResizable(false);
		 
		setLayout(new AccordionLayout());
		addComponents();
		
		setSize(350, 350);
		show();
	}
	
	
	//*************************************************************************************
	//	Methods
	//*************************************************************************************
	
	private void addComponents() {
		
		for (UnspecifiedElementModel model: models) {
			
			Vector<MVCViewRecipient> recipients = session.getMVCViewRecipientsByModel(model);
			
			for (MVCViewRecipient recipient: recipients) {
				
				if (recipient instanceof RelatedRelation) {
					
					RelatedRelation relatedRelation = (RelatedRelation)recipient;
					
					if (relatedRelation.getType() == TableCellTypeEnum.RELEATION) {
						
						add(relatedRelation);
					}
					
				}
				
			}
			
		}
		
	}
	
	
	
	public void removeComponent(RelatedRelation relation) {
		
		remove(relation);
		
		if (getItemCount() == 0) {
			hide();
		}
		
	}
	
}
