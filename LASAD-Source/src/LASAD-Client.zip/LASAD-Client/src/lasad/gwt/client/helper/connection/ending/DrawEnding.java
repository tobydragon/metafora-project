package lasad.gwt.client.helper.connection.ending;

import com.google.gwt.user.client.Element;

public class DrawEnding extends ConnectionEnding {

	public DrawEnding() {
	// throw new UnsupportedOperationException("Unsupported browser");
	}

	public void update(int left, int top, float angle) {
	// throw new UnsupportedOperationException("Unsupported browser");
	}

	public Element getElement() {
		throw new UnsupportedOperationException("Unsupported browser");
	}

	public Element getCurveStyleElement() {
		throw new UnsupportedOperationException("Unsupported browser");
	}

	public void setCurveStyleElement(Element style) {
	// throw new UnsupportedOperationException("Unsupported browser");
	}

}
