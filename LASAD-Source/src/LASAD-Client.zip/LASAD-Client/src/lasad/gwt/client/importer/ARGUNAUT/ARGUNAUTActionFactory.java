package lasad.gwt.client.importer.ARGUNAUT;

import java.util.Date;
import java.util.Vector;

import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.logger.Logger;
import lasad.gwt.client.model.ElementInfo;

/**
 * Specialized factory to generate ActionPackages for the Digalo / ARGUNAUT
 * parser
 **/
public class ARGUNAUTActionFactory {

	private static ARGUNAUTActionFactory instance = null;

	public static ARGUNAUTActionFactory getInstance() {
		if (instance == null) {
			instance = new ARGUNAUTActionFactory();
		}
		return instance;
	}

	private ARGUNAUTActionFactory() {

	}

	public ActionPackage createBoxWithElementsAndContent(ElementInfo currentElement, String nodeId, int mapID, int posX, int posY, String headline, String text, String author, String creationDate, String modificationDate, String nodeFirstModificationDate) {
		ActionPackage p = createActionPackage();
		Action a = createBox(currentElement, nodeId, mapID, posX, posY, creationDate, modificationDate, nodeFirstModificationDate);
		p.addAction(a);

		Vector<Action> b = createBoxElementsAndContentAction(currentElement, mapID, headline, text, author, creationDate);
		if (b.size() > 0) {
			for (Action c : b) {
				p.addAction(c);
			}
		}
		return p;
	}

	private ActionPackage createActionPackage() {
		return new ActionPackage();
	}

	private Action createSpecificAction(String cmd, String category) {
		return new Action(cmd, category);
	}
	
	public ActionPackage parsingFinished(String importType) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("IMPORT-FINISHED", "FILE");
		a.addParameter("IMPORT-TYPE", importType);
		p.addAction(a);
		return p;
	}

	private Action createBox(ElementInfo config, String objectID, int mapID, int posX, int posY, String creationDate, String modificationDate, String nodeFirstModificationDate) {
		Action a = createSpecificAction("CREATE-ELEMENT", "MAP");
		a.addParameter("TYPE", "box");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ELEMENT-ID", config.getElementID());
		a.addParameter("OBJECTID", objectID);
		a.addParameter("POS-X", String.valueOf(posX));
		a.addParameter("POS-Y", String.valueOf(posY));
		a.addParameter("CREATIONDATE", creationDate);
		a.addParameter("MODIFICATIONDATE", modificationDate);
		a.addParameter("FIRSTMODIFICATIONDATE", nodeFirstModificationDate);
		a.addParameter("REPLAY", "true");
		return a;
	}

	private Vector<Action> createBoxElementsAndContentAction(ElementInfo currentElement, int mapID, String headline, String text, String author, String creationdate) {

		Vector<Action> allActions = new Vector<Action>();

		for (ElementInfo childElement : currentElement.getChildElements().values()) {
			Logger.log("Creating action for ChildElement: " + childElement.getElementType(), Logger.DEBUG_DETAILS);
			for (int i = 0; i < childElement.getQuantity(); i++) {
				Action b = null;

				b = createSpecificAction("CREATE-ELEMENT", "MAP");
				b.addParameter("TYPE", childElement.getElementType());
				b.addParameter("MAP-ID", mapID + "");
				b.addParameter("PARENT", "LAST-ID");
				b.addParameter("ELEMENT-ID", String.valueOf(childElement.getElementID()));
				b.addParameter("REPLAY", "true");

				if ((childElement.getElementType().equals("text")) || (childElement.getElementType().equals("url"))) {
					// In case the child element is a headline element
					if (childElement.getElementID().equals("headline")) {
						b.addParameter("TEXT", headline);
					}
					// In case the child element is a text field element
					else if (childElement.getElementID().equals("text")) {
						b.addParameter("TEXT", text);
					}
				} else if (childElement.getElementType().equals("rating")) {
					b.addParameter("SCORE", childElement.getElementOption("score"));
				} else if (childElement.getElementType().equals("awareness")) {

					Date date = new Date(Long.parseLong(creationdate));
					String dateString = date.toString();
					dateString = dateString.substring(4, 16);

					b.addParameter("TEXT", author + ", " + dateString);

				}
				if (b != null) {
					allActions.add(b);
				}
			}
		}
		return allActions;
	}

	public ActionPackage createLinkWithElements(ElementInfo info, int mapID, String startElementID, String endElementID, String author, String creationDate) {

		ActionPackage p = createActionPackage();

		Vector<Action> b = createLinkWithElementsAction(info, mapID, startElementID, endElementID, author, creationDate);
		if (b.size() > 0) {
			for (Action c : b) {
				p.addAction(c);
			}
		}
		return p;
	}

	private Vector<Action> createLinkWithElementsAction(ElementInfo info, int mapID, String startElementID, String endElementID, String author, String creationDate) {

		Vector<Action> resultingActions = new Vector<Action>();

		Action a = createSpecificAction("CREATE-ELEMENT", "MAP");
		a.addParameter("TYPE", info.getElementType());
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ELEMENT-ID", String.valueOf(info.getElementID()));
		a.addParameter("PARENT", startElementID);
		a.addParameter("PARENT", endElementID);
		a.addParameter("TIME", creationDate);
		a.addParameter("CREATIONDATE", creationDate);
		a.addParameter("REPLAY", "true");

		resultingActions.add(a);

		for (ElementInfo childElement : info.getChildElements().values()) {
			Logger.log("Creating action for ChildElement: " + childElement.getElementType(), Logger.DEBUG_DETAILS);
			for (int i = 0; i < childElement.getQuantity(); i++) {
				Action b = null;
				b = createSpecificAction("CREATE-ELEMENT", "MAP");
				b.addParameter("TYPE", childElement.getElementType());
				b.addParameter("MAP-ID", mapID + "");
				b.addParameter("PARENT", "LAST-ID");
				b.addParameter("ELEMENT-ID", String.valueOf(childElement.getElementID()));
				b.addParameter("REPLAY", "true");

				if ((childElement.getElementType().equals("text")) || (childElement.getElementType().equals("url"))) {

				} else if (childElement.getElementType().equals("rating")) {
					b.addParameter("SCORE", childElement.getElementOption("score"));
				} else if (childElement.getElementType().equals("awareness")) {
					Date date = new Date(Long.parseLong(creationDate));
					String dateString = date.toString();
					dateString = dateString.substring(4, 16);

					b.addParameter("TEXT", author + ", " + dateString);
				}
				if (b != null) {
					resultingActions.add(b);
				}
			}
		}
		return resultingActions;
	}
}
