package lasad.gwt.client.communication;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import java.util.Vector;

import lasad.gwt.client.LASAD_Client;
import lasad.gwt.client.communication.objects.Action;
import lasad.gwt.client.communication.objects.ActionFactory;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.communication.objects.Parameter;
import lasad.gwt.client.communication.objects.categories.Categories;
import lasad.gwt.client.communication.objects.commands.Commands;
import lasad.gwt.client.communication.objects.parameters.ParameterTypes;
import lasad.gwt.client.constants.lasad_clientConstants;
import lasad.gwt.client.importer.ARGUNAUT.ArgunautParser;
import lasad.gwt.client.importer.LARGO.LARGOParser;
import lasad.gwt.client.logger.Logger;
import lasad.gwt.client.model.MVCViewSession;
import lasad.gwt.client.model.MVController;
import lasad.gwt.client.model.MapInfo;
import lasad.gwt.client.model.UnspecifiedElementModel;
import lasad.gwt.client.model.events.LasadEvent;
import lasad.gwt.client.ui.LASADStatusBar;
import lasad.gwt.client.ui.box.Box;
import lasad.gwt.client.ui.replay.ReplayInitializer;
import lasad.gwt.client.ui.workspace.AbstractArgumentMap;
import lasad.gwt.client.ui.workspace.LASADInfo;
import lasad.gwt.client.ui.workspace.argumentmap.ArgumentMap;
import lasad.gwt.client.ui.workspace.argumentmap.ArgumentMapMVCViewSession;
import lasad.gwt.client.ui.workspace.argumentmap.ArgumentMapMenuBar;
import lasad.gwt.client.ui.workspace.loaddialogues.ImportingMapDialogue;
import lasad.gwt.client.ui.workspace.loaddialogues.LoadingLoginDialogue;
import lasad.gwt.client.ui.workspace.loaddialogues.LoadingMapDialogue;
import lasad.gwt.client.ui.workspace.loaddialogues.LoadingMapFromFileDialogue;
import lasad.gwt.client.ui.workspace.loaddialogues.LoadingReplayDialogue;
import lasad.gwt.client.ui.workspace.loaddialogues.ReloadingMapsDialogue;
import lasad.gwt.client.ui.workspace.tableview.ArgumentEditionStyleEnum;
import lasad.gwt.client.ui.workspace.tableview.ArgumentMapTableMVCViewSession;
import lasad.gwt.client.ui.workspace.tabs.LoginTab;
import lasad.gwt.client.ui.workspace.tabs.MapTab;
import lasad.gwt.client.ui.workspace.tabs.authoring.AuthoringTab;
import lasad.gwt.client.ui.workspace.tabs.authoring.steps.CreateAndDeleteSessions;
import lasad.gwt.client.ui.workspace.tabs.authoring.steps.CreateAndDeleteTemplate;
import lasad.gwt.client.ui.workspace.tabs.authoring.steps.CreateAndDeleteUsers;
import lasad.gwt.client.ui.workspace.tabs.authoring.steps.CreateModifyAndDeleteOntology;
import lasad.gwt.client.ui.workspace.tabs.map.JoinSessionContentPanel;
import lasad.gwt.client.ui.workspace.tabs.map.MapLoginTab;
import lasad.gwt.client.xml.OntologyReader;

import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.MessageBoxEvent;
import com.extjs.gxt.ui.client.widget.Component;
import com.extjs.gxt.ui.client.widget.Dialog;
import com.extjs.gxt.ui.client.widget.MessageBox;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.google.gwt.core.client.GWT;
import com.google.gwt.xml.client.impl.DOMParseException;

/**
 * Manages all incoming actions from the servlet and, hence, from the EJB server
 * Uses Singleton Pattern
 * 
 * Refactoring Step 1 by Sabine Niebuhr
 */
public class LASADActionReceiver {

	lasad_clientConstants myConstants = GWT.create(lasad_clientConstants.class);
	private static LASADActionReceiver myInstance = null;

	// David Drexler Edit-BEGIN
	private TreeMap<Integer, ActionPackage> treeForwReplay;
	private TreeMap<String, List<Integer>> treeUserReplay;
	private List<Integer> elementReplay;
	private ReplayInitializer init;

	// David Drexler Edit-END

	public static LASADActionReceiver getInstance() {
		if (myInstance == null) {
			myInstance = new LASADActionReceiver();
		}
		return myInstance;
	}

	private LASADActionReceiver() {
	}

	public void doActionPackage(ActionPackage p) {

		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][doActionPackage] ActionPackage arrived:", Logger.DEBUG);

		Logger.log("[Details]: \n" + p.toString(), Logger.DEBUG);

		for (Action a : p.getActions()) {
			// Sort Action parameters so that USERNAME is at Position 0
			// Necessary for Highlighting
			a.sortParameterUsername();

			// Check if the given MapID relates to an controller or not

			Logger.log(a.toString(), Logger.DEBUG_DETAILS);

			String mapIDString = a.getParameterValue(ParameterTypes.MapId);

			MVController controller = null;
			if (mapIDString != null) {
				controller = LASAD_Client.getMVCController(Integer.parseInt(a.getParameterValue(ParameterTypes.MapId)));
			} else {
				controller = null;
			}
//			TODO anschauen, was mit Categories.Info ist...
			if (controller != null&&a.getCategory()!=Categories.Info) {
				// Valid controller found.
				Logger.log("--> workOnMVCControlledAction", Logger.DEBUG);
				workOnMVCControlledAction(controller, a);
			} else {
				// No valid controller found.

				Logger.log("--> workOnGlobalAction", Logger.DEBUG);
				workOnGlobalAction(a);
			}
		}
	}

	/**
	 * Work on ActionSets with valid/registered MAPIDs
	 * 
	 * @param controller
	 * @param actionSet
	 */
	private void workOnMVCControlledAction(MVController controller, Action a) {

		Logger.log("workOnMVCControlledAction entered, Category: " + a.getCategory().toString(), Logger.DEBUG);
//		Logger.log("workOnMVCControlledAction entered, Category: " + a.getCategory(), Logger.DEBUG);

		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][workOnMVCControlledAction] Action arrived: \n" + a.toString(), Logger.DEBUG);

		switch (a.getCategory()){
		case Heartbeat:
			processHeartbeatAction(controller, a);
			break;
		case Map:
			processMapAction(controller, a);
			break;
		case Management:
			processManagementAction(controller, a);
			break;
		case Communication:
			processChatAction(controller, a);
			break;
		case UserEvent:
			processUserEventAction(controller, a);
			break;
		case Questionnaire:
			processQuestionnaireAction(controller, a);
			break;
		default:
			Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][workOnMVCControlledActionPackage] Error: Unknown action category!", Logger.DEBUG);
		}
			
		// Set new Revision to the Model, if controller is still registered
		if (controller != null && a.getParameterValue(ParameterTypes.ToRev) != null) {
			if (controller.getActualRevision() < Integer.parseInt(a.getParameterValue(ParameterTypes.ToRev))) {
				Logger.log("setActualRevision to: " + a.getParameterValue(ParameterTypes.ToRev), Logger.DEBUG);
				controller.setActualRevision(Integer.parseInt(a.getParameterValue(ParameterTypes.ToRev)));

			}
		}
	}

	private void processManagementAction(Action a) {
		{
			Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processManagementAction] Processing global management action...", Logger.DEBUG);
			Logger.log("[Details] " + a.toString(), Logger.DEBUG);
		}

		switch (a.getCmd()){
			case Login:
				if (a.getParameterValue(ParameterTypes.Status).equals("OK") || a.getParameterValue(ParameterTypes.Status).equals("ALREADYAUTHED")) {
					LASAD_Client.getInstance().setAuthed(true);
					LASAD_Client.getInstance().setUsername(a.getParameterValue(ParameterTypes.UserName));

					if (a.getParameterValue(ParameterTypes.Role) != null) {
						LASAD_Client.getInstance().setRole(a.getParameterValue(ParameterTypes.Role));
					}

					LoginTab myLoginTab = LoginTab.getInstance();
					myLoginTab.updateAuthStatus(true);

					LoadingLoginDialogue.getInstance().closeLoadingScreen();

					myLoginTab.getMapLoginPanel().updateOverviews();
					
					if (LASAD_Client.urlParameterConfig.isAutoLogin() && LASAD_Client.urlParameterConfig.getMapId() != null){
						LoadingMapDialogue.getInstance().showLoadingScreen();
						LASADActionSender.getInstance().sendActionPackage(ActionFactory.getInstance().joinMap(LASAD_Client.urlParameterConfig.getMapId()));
					}
					
				} else if (a.getParameterValue(ParameterTypes.Status).equals("DENIED")) {
					LASAD_Client.getInstance().setAuthed(false);
					LASADStatusBar.getInstance().setLoginStatus("not logged in");

					LoginTab myLoginTab = LoginTab.getInstance();
					myLoginTab.updateAuthStatus(false);

					LoadingLoginDialogue.getInstance().closeLoadingScreen();

					LASADInfo.display("Login failed!", "Password and/or username incorrect.");

					Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processManagementAction] Login denied!", Logger.DEBUG);
				}
				break;
			case LoginFailed:
				LoadingLoginDialogue.getInstance().closeLoadingScreen();
				LASADInfo.display("Error", a.getParameterValue(ParameterTypes.Message));
				break;
			case Logout:
				if (a.getParameterValue(ParameterTypes.Status).equals("OK")) {

					JoinSessionContentPanel.getInstance().clearMapDetails();

					LASAD_Client.getInstance().setAuthed(false);
					LASAD_Client.getInstance().setUsername("unknown");
					LASAD_Client.statusBar.setLoginStatus("not logged in");
					LASAD_Client.getInstance().refreshWorkspace();
					LASAD_Client.getInstance().setConfirmedTabClose(false);
				}
				break;
			case ForcedLogout:
				if (a.getParameterValue(ParameterTypes.Status).equals("OK")) {
					JoinSessionContentPanel.getInstance().clearMapDetails();
					LASAD_Client.getInstance().setConfirmedTabClose(true);
				}
				break;
			case ListMap:
				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processManagementAction] LISTMAP", Logger.DEBUG);
				MapLoginTab.getInstance().addListOfMaps(a, false);
				break;
			case MapDetails:
				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processManagementAction] Map details received.", Logger.DEBUG);
				MapLoginTab.getInstance().openMapDetails(a);
				break;
			case TemplateDetails:
				MapLoginTab.getInstance().openTemplateDetails(a);
				break;
			case AddTemplateToList:
				MapLoginTab.getInstance().addTemplateItem(a.getParameterValue(ParameterTypes.Ontology), a.getParameterValue(ParameterTypes.Template), a.getParameterValue(ParameterTypes.TemplateId), a.getParameterValue(ParameterTypes.TemplateMaxId));
				break;
			case Join:
				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processManagementAction] JOINMAP: Creating new MapArea", Logger.DEBUG);

				// Create MapInfo
				MapInfo mapInfo = new MapInfo(Integer.valueOf(a.getParameterValue(ParameterTypes.MapId)));

				mapInfo.setTitle(a.getParameterValue(ParameterTypes.MapName));

				mapInfo.setOntologyName(a.getParameterValue(ParameterTypes.OntologyName));
				mapInfo.setXmlOntology(a.getParameterValue(ParameterTypes.Ontology));

				mapInfo.setTemplateName(a.getParameterValue(ParameterTypes.TemplateName));
				mapInfo.setTemplateTitle(a.getParameterValue(ParameterTypes.TemplateTitle));
				mapInfo.setXmlTemplate(a.getParameterValue(ParameterTypes.Template));

				mapInfo = OntologyReader.buildTemplateInfosFromXML(mapInfo, a.getParameterValue(ParameterTypes.Template));
				mapInfo = OntologyReader.buildOntologyInfosFromXML(mapInfo, a.getParameterValue(ParameterTypes.Ontology));

				Logger.log("MAPINFO: " + mapInfo.toString(), Logger.DEBUG);
				// Create the MVC Controller for the New Map
				MVController newController = LASAD_Client.registerMVCController(new MVController(mapInfo));

				// Create the MapTab
				MapTab mapTab = LASAD_Client.getInstance().createMapTab(newController);

				// *************************************************************************************
				// add by Erkang:
				// Display Argument with another ViewSession, here setup a new
				// Session for Table
				// *************************************************************************************

				String mapId = a.getParameterValue(ParameterTypes.MapId);

				// TODO this two choice can be combined with MVCViewSession
				if (LASAD_Client.getMapEditionStyle(mapId) == ArgumentEditionStyleEnum.TABLE) {
					// Start table view
					MVCViewSession mapSession = new ArgumentMapTableMVCViewSession(newController, mapTab);
					newController.registerViewSession(mapSession);

				} else {
					// Start graph view (Default)
					ArgumentMapMVCViewSession mapSession = new ArgumentMapMVCViewSession(newController, mapTab);
					newController.registerViewSession(mapSession);
				}
				
				// This is needed for auto-reconnect. Once the connection crashes, the user will have to rejoin all maps. After that, the infinite loading screen has to disappear. This will be done here.
				ReloadingMapsDialogue.getInstance().decreaseMapCount();
				break;
		}
		
//		if (a.getCmd().equals(Commands.Login)) {
//			if (a.getParameter("STATUS").equals("OK") || a.getParameter("STATUS").equals("ALREADYAUTHED")) {
//				LASAD_Client.getInstance().setAuthed(true);
//				LASAD_Client.getInstance().setUsername(a.getParameter("USERNAME"));
//
//				if (a.getParameter("ROLE") != null) {
//					LASAD_Client.getInstance().setRole(a.getParameter("ROLE"));
//				}
//
//				LoginTab myLoginTab = LoginTab.getInstance();
//				myLoginTab.updateAuthStatus(true);
//
//				LoadingLoginDialogue.getInstance().closeLoadingScreen();
//
//				myLoginTab.getMapLoginPanel().updateOverviews();
//				
//				if (LASAD_Client.autoLogin && LASAD_Client.autoMapId != null){
//					LoadingMapDialogue.getInstance().showLoadingScreen();
//					LASADActionSender.getInstance().sendActionPackage(ActionFactory.getInstance().joinMap(LASAD_Client.autoMapId));
//				}
//				
//			} else if (a.getParameter("STATUS").equals("DENIED")) {
//				LASAD_Client.getInstance().setAuthed(false);
//				LASADStatusBar.getInstance().setLoginStatus("not logged in");
//
//				LoginTab myLoginTab = LoginTab.getInstance();
//				myLoginTab.updateAuthStatus(false);
//
//				LoadingLoginDialogue.getInstance().closeLoadingScreen();
//
//				LASADInfo.display("Login failed!", "Password and/or username incorrect.");
//
//				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processManagementAction] Login denied!", Logger.DEBUG);
//			}
//		} else if (a.getCmd().equals(Commands.LoginFailed)) {
//			LoadingLoginDialogue.getInstance().closeLoadingScreen();
//
//			LASADInfo.display("Error", a.getParameter("MESSAGE"));
//
//		} else if (a.getCmd().equals(Commands.Logout)) {
//			if (a.getParameter("STATUS").equals("OK")) {
//
//				JoinSessionContentPanel.getInstance().clearMapDetails();
//
//				LASAD_Client.getInstance().setAuthed(false);
//				LASAD_Client.getInstance().setUsername("unknown");
//				LASAD_Client.statusBar.setLoginStatus("not logged in");
//				LASAD_Client.getInstance().refreshWorkspace();
//				LASAD_Client.getInstance().setConfirmedTabClose(false);
//			}
//		} else if (a.getCmd().equals(Commands.ForcedLogout)) {
//			if (a.getParameter("STATUS").equals("OK")) {
//				JoinSessionContentPanel.getInstance().clearMapDetails();
//				LASAD_Client.getInstance().setConfirmedTabClose(true);
//			}
//		} else if (a.getCmd().equals(Commands.ListMap)) {
//			Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processManagementAction] LISTMAP", Logger.DEBUG);
//			MapLoginTab.getInstance().addListOfMaps(a, false);
//		} else if (a.getCmd().equals(Commands.MapDetails)) {
//
//			Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processManagementAction] Map details received.", Logger.DEBUG);
//			MapLoginTab.getInstance().openMapDetails(a);
//		} else if (a.getCmd().equals(Commands.TemplateDetails)) {
//			MapLoginTab.getInstance().openTemplateDetails(a);
//		} else if (a.getCmd().equalsIgnoreCase(Commands.AddTemplateToList)) {
//			MapLoginTab.getInstance().addTemplateItem(a.getParameter("ONTOLOGY"), a.getParameter("TEMPLATE"), a.getParameter("TEMPLATE-ID"), a.getParameter("TEMPLATE-MAXID"));
//		} else if (a.getCmd().equals(Commands.Join)) {

//			Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processManagementAction] JOINMAP: Creating new MapArea", Logger.DEBUG);
//
//			// Create MapInfo
//			MapInfo mapInfo = new MapInfo(Integer.valueOf(a.getParameter("MAP-ID")));
//
//			mapInfo.setTitle(a.getParameter("MAPNAME"));
//
//			mapInfo.setOntologyName(a.getParameter("ONTOLOGYNAME"));
//			mapInfo.setXmlOntology(a.getParameter("ONTOLOGY"));
//
//			mapInfo.setTemplateName(a.getParameter("TEMPLATENAME"));
//			mapInfo.setTemplateTitle(a.getParameter("TEMPLATETITLE"));
//			mapInfo.setXmlTemplate(a.getParameter("TEMPLATE"));
//
//			mapInfo = OntologyReader.buildTemplateInfosFromXML(mapInfo, a.getParameter("TEMPLATE"));
//			mapInfo = OntologyReader.buildOntologyInfosFromXML(mapInfo, a.getParameter("ONTOLOGY"));
//
//			Logger.log("MAPINFO: " + mapInfo.toString(), Logger.DEBUG);
//			// Create the MVC Controller for the New Map
//			MVController newController = LASAD_Client.registerMVCController(new MVController(mapInfo));
//
//			// Create the MapTab
//			MapTab mapTab = LASAD_Client.getInstance().createMapTab(newController);
//
//			// *************************************************************************************
//			// add by Erkang:
//			// Display Argument with another ViewSession, here setup a new
//			// Session for Table
//			// *************************************************************************************
//
//			String mapId = a.getParameter("MAP-ID");
//
//			// TODO this two choice can be combined with MVCViewSession
//			if (LASAD_Client.getMapEditionStyle(mapId) == ArgumentEditionStyleEnum.TABLE) {
//				// Start table view
//				MVCViewSession mapSession = new ArgumentMapTableMVCViewSession(newController, mapTab);
//				newController.registerViewSession(mapSession);
//
//			} else {
//				// Start graph view (Default)
//				ArgumentMapMVCViewSession mapSession = new ArgumentMapMVCViewSession(newController, mapTab);
//				newController.registerViewSession(mapSession);
//			}
//			
//			// This is needed for auto-reconnect. Once the connection crashes, the user will have to rejoin all maps. After that, the infinite loading screen has to disappear. This will be done here.
//			ReloadingMapsDialogue.getInstance().decreaseMapCount();
//		}
	}

	private void processSessionAction(Action a) {
		if (a.getCmd().equals(Commands.HeartbeatRequest)) {

			Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processSessionAction] HeartbeatRequest received.", Logger.DEBUG);
			// Send an heartbeat back to the server
			LASADActionSender.getInstance().sendActionPackage(ActionFactory.getInstance().sendHeartbeat());

			Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processSessionAction] HeartbeatRequest sent back to server.", Logger.DEBUG);
		}
	}

	/**
	 * Processes MVC controlled management actions
	 * 
	 * @param controller
	 *            MVC controller
	 * @param a
	 *            Action to be processed
	 */
	private void processManagementAction(MVController controller, Action a) {
		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processManagementAction] Processing map action...", Logger.DEBUG);
		Logger.log("[Details] " + a.toString(), Logger.DEBUG_DETAILS);

		if (a.getCmd().equals(Commands.Leave)) {
			ArgumentMap.mapIDtoCursorID.remove(controller.getMapID());

			// Unregister the MVController and removes it
			LASAD_Client.unregisterMVCController(controller);
			LASAD_Client.removeMapTab(controller.getMapID());

		}
	}

	private void processChatAction(MVController controller, Action a) {

		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processChatAction] Processing chat action...", Logger.DEBUG);

		Logger.log("[Details] " + a.toString(), Logger.DEBUG_DETAILS);

		if(! controller.getMapInfo().isSentenceOpener()){
			//TODO: Das laesst sich hier viel sch�ner machen...
		if ("TRUE".equalsIgnoreCase(a.getParameterValue(ParameterTypes.Replay))) {
			LASAD_Client.getMapTab(controller.getMapID()).getMyMapSpace().getChatPanel().addChatMessage(a.getParameterValue(ParameterTypes.UserName), a.getParameterValue(ParameterTypes.Time), a.getParameterValue(ParameterTypes.Message), true);
		} else {
			LASAD_Client.getMapTab(controller.getMapID()).getMyMapSpace().getChatPanel().addChatMessage(a.getParameterValue(ParameterTypes.UserName), a.getParameterValue(ParameterTypes.Time), a.getParameterValue(ParameterTypes.Message), false);
		}
		}
		// TODO: dieses if kann man sich hier wohl schenken, das sollte immer true sein ;-)
		else if(controller.getMapInfo().isSentenceOpener()){
			if ("TRUE".equalsIgnoreCase(a.getParameterValue(ParameterTypes.Replay))) {
				LASAD_Client.getMapTab(controller.getMapID()).getMyMapSpace().getExtendedChatPanel().addChatMessage(a.getParameterValue(ParameterTypes.UserName), a.getParameterValue(ParameterTypes.Time), a.getParameterValue(ParameterTypes.Message), a.getParameterValue(ParameterTypes.Opener), a.getParameterValue(ParameterTypes.TextColor), true);
			} else {
				LASAD_Client.getMapTab(controller.getMapID()).getMyMapSpace().getExtendedChatPanel().addChatMessage(a.getParameterValue(ParameterTypes.UserName), a.getParameterValue(ParameterTypes.Time), a.getParameterValue(ParameterTypes.Message), a.getParameterValue(ParameterTypes.Opener), a.getParameterValue(ParameterTypes.TextColor), false);
			}
			}

	}

	private void processMapAction(MVController controller, Action a) {

		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processMapAction] Processing map action...", Logger.DEBUG);

		Logger.log("[Details] " + a.toString(), Logger.DEBUG_DETAILS);

		String mapId = a.getParameterValue(ParameterTypes.MapId);
		
		//TODO vereinfachen
		if (LASAD_Client.getMapEditionStyle(mapId) == ArgumentEditionStyleEnum.GRAPH) {

			if (a.getCmd().equals(Commands.CreateElement)) {

				// Check if the feedback is for the current user, if not -->
				// ignore
				String elementType = a.getParameterValue(ParameterTypes.Type);
				if (elementType.equalsIgnoreCase("FEEDBACK-CLUSTER")) {
					if (!a.getParameterValue(ParameterTypes.ForUser).equalsIgnoreCase(LASAD_Client.getInstance().getUsername()) && !a.getParameterValue(ParameterTypes.ForUser).equals("")) {
						return;
					}
				}

				// Currently feedback engines count as "element", thus we have
				// to filter them here...
				else if (elementType.equalsIgnoreCase("FEEDBACK-AGENT")) {
					processRegisterFeedbackAgent(controller, a);
				}

				String elementIDString = a.getParameterValue(ParameterTypes.Id);

				int elementID = -1;

				if (elementIDString != null) {
					elementID = Integer.parseInt(elementIDString);
				}

				String username = a.getParameterValue(ParameterTypes.UserName);

				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver] Create Model: " + elementID + ", Type: " + elementType, Logger.DEBUG);
				UnspecifiedElementModel elementModel = new UnspecifiedElementModel(elementID, elementType, username);

				if(a.getParameterValue(ParameterTypes.ReplayTime)!= null)
				{
					elementModel.setIsReplay(true);
				}
				// Needed to enable the add and del buttons in box header
				if (a.getParameterValue(ParameterTypes.ElementId) != null) {
					elementModel.setElementId(a.getParameterValue(ParameterTypes.ElementId));
				}

				// Add more specific data to the model
				for (Parameter param : a.getParameters()) {
					if (!param.getType().equals(ParameterTypes.Parent) && !param.getType().equals(ParameterTypes.HighlightElementId)) {
						elementModel.setValue(param.getType().getOldParameter(), param.getValue());
					}
				}

				// Work on parent relations
				if (a.getParameterValues(ParameterTypes.Parent) != null) {
					for (String parentID : a.getParameterValues(ParameterTypes.Parent)) {
						controller.setParent(elementModel, controller.getElement(Integer.parseInt(parentID)));

						Logger.log("[lasad.gwt.client.communication.LASADActionReceiver] Added ParentElement: " + parentID, Logger.DEBUG);
					}
				}

				// Now Register new Element to the Model
				controller.addElementModel(elementModel);

				if (elementType.equalsIgnoreCase("FEEDBACK-CLUSTER")) {
					LASAD_Client.getMapTab(controller.getMapID()).getMyMapSpace().getFeedbackPanel().addFeedbackMessage(elementID, a.getParameterValue(ParameterTypes.Message));

					Vector<String> highlights = new Vector<String>();
					highlights = a.getParameterValues(ParameterTypes.HighlightElementId);

					if (highlights != null) {
						Vector<Parameter> highlightParam = new Vector<Parameter>();
						for (String s : a.getParameterValues(ParameterTypes.HighlightElementId)) {
							highlightParam.add(new Parameter(ParameterTypes.HighlightElementId, s));
						}

						if (highlightParam.size() > 0) {
							controller.updateElement(elementModel.getId(), highlightParam);
						}
					} else {

						Logger.log("WARNING: There is no highlight for this feedback", Logger.DEBUG);
					}

				}
			} else if (a.getCmd().equals(Commands.UpdateElement)) {

				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver.processMapAction] UPDATE-ELEMENT", Logger.DEBUG);
				if (a.getParameterValue(ParameterTypes.UserName) != null && a.getParameterValue(ParameterTypes.UserName).equalsIgnoreCase(LASAD_Client.getInstance().getUsername()) && a.getParameterValue(ParameterTypes.Status) != null) {
					a = Action.removeParameter(a, ParameterTypes.Status);
				} else {
					controller.updateElement(Integer.parseInt(a.getParameterValue(ParameterTypes.Id)), a.getParameters());
				}
			} else if (a.getCmd().equals(Commands.UpdateCursorPosition)) {

				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver.processMapAction] UPDATE-CURSOR-POSITION", Logger.DEBUG);
				Logger.log(a.toString(), Logger.DEBUG_DETAILS);
				controller.updateElement(Integer.parseInt(a.getParameterValue(ParameterTypes.Id)), a.getParameters());
			} else if (a.getCmd().equals(Commands.DeleteElement)) {

				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver.processMapAction] DELETE-ELEMENT", Logger.DEBUG);

				int elementID = Integer.parseInt(a.getParameterValue(ParameterTypes.Id));
				if (controller.getElement(elementID) != null) {
					if (controller.getElement(elementID).getType().equalsIgnoreCase("FEEDBACK-AGENT")) {
						processRemoveFeedbackAgent(controller, a);
					}
					try {
						controller.deleteElement(Integer.parseInt(a.getParameterValue(ParameterTypes.Id)), a.getParameterValue(ParameterTypes.UserName));
					} catch (Exception e) {
						e.printStackTrace();
						Logger.log("Can not delete element, because ID is no int!", Logger.DEBUG_ERRORS);
					}

				} else {
					// This occurs when another user deletes his/her feedback
					Logger.log("Cannot delete delete, because element ID is unknown.", Logger.DEBUG_ERRORS);
				}
			} else if (a.getCmd().equals(Commands.ListMap)) {
				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver.processMapAction] LISTMAP", Logger.DEBUG);
				MapLoginTab.getInstance().addListOfMaps(a, true);
			} else if (a.getCategory().equals(Commands.Error)) {
				LASADInfo.display("Error", a.getParameterValue(ParameterTypes.Message));
			} else if (a.getCmd().equals(Commands.Import)) {
				//IMPORT ActionPackage holds a Parameter XMLTEXT 
				//This parameter's value is the map to be imported
				MVController newController = LASAD_Client.getMapTab(Integer.parseInt(a.getParameterValue(ParameterTypes.MapId))).getMyMapSpace().getSession().getController();

				if (newController.getMapInfo().getOntologyName().equalsIgnoreCase("ARGUNAUT")){
					ArgunautParser parser = new ArgunautParser(a.getParameterValue(ParameterTypes.XMLText), LASAD_Client.getMapTab(Integer.parseInt(a.getParameterValue(ParameterTypes.MapId))).getMyMapSpace(), newController);
					try {
						if (a.getParameterValue(ParameterTypes.XMLText).trim().equals("")) {
							MessageBox.info("No gml text found", "Please enter a proper gml-file text!", null);
						} else {
							parser.parseText();							
						}
					} catch (DOMParseException e) {
						MessageBox.alert("Error", "The gml-file does not match the argunaut pattern!\n " + e.toString(), null);
//						e.printStackTrace();
					} catch (Exception e) {
						MessageBox.alert("Unknown Error", "An error occured in class ArgumentMapMenuBar.java. Contact the system developer for further information.\n " + e.toString(), null);
						MessageBox.alert("Unknown Error", e.toString(), null);
//						e.printStackTrace();
					}
				}
				else {
					LARGOParser parser = new LARGOParser(a.getParameterValue(ParameterTypes.XMLText), newController.getMapInfo().getTemplateName(), LASAD_Client.getMapTab(Integer.parseInt(a.getParameterValue(ParameterTypes.MapId))).getMyMapSpace(), newController);
					try {
						if (a.getParameterValue(ParameterTypes.XMLText).trim().equals("")) {
							MessageBox.info("No gml text found", "Please enter a proper gml-file text!", null);
						} else {
							parser.parseText();
						}
					} catch (DOMParseException e) {
						MessageBox.alert("Error", "The xml-file does not match the largo pattern!", null);
//						e.printStackTrace();
					} catch (Exception e) {
						MessageBox.alert("Unknown Error", "An error occured in class ArgumentMapMenuBar.java. Contact the system developer for further information.", null);
//						e.printStackTrace();
					}
				}
//				LoadingLoginDialogue.getInstance().closeLoadingScreen();
			}
		} else if (LASAD_Client.getMapEditionStyle(mapId) == ArgumentEditionStyleEnum.TABLE) {
//			switch (a.getCmd()){
//			case CreateElement:
//				// Check if the feedback is for the current user, if not -->
//				// ignore
//				String elementType = a.getParameter("TYPE");
//				if (elementType.equalsIgnoreCase("FEEDBACK-CLUSTER")) {
//					if (!a.getParameter("USERNAME").equalsIgnoreCase(LASAD_Client.getInstance().getUsername()) && !a.getParameter("USERNAME").equals("")) {
//						return;
//					}
//				}
//
//				// Currently feedback engines count as "element", thus we have
//				// to filter them here...
//				else if (elementType.equalsIgnoreCase("FEEDBACK-AGENT")) {
//					processRegisterFeedbackAgent(controller, a);
//				}
//
//				String elementIDString = a.getParameter("ID");
//				int elementID = -1;
//				if (elementIDString != null) {
//					elementID = Integer.parseInt(elementIDString);
//				}
//
//				String username = a.getParameter("USERNAME");
//
//				UnspecifiedElementModel elementModel = new UnspecifiedElementModel(elementID, elementType, username);
//				
//				if(a.getParameter("REPLAY-TIME")!= null)
//				{
//					elementModel.setIsReplay(true);
//				}
//
//				// Needed to enable the add and del buttons in box header
//				if (a.getParameter("ELEMENT-ID") != null) {
//					elementModel.setElementid(a.getParameter("ELEMENT-ID"));
//				}
//
//				// Add more specific data to the model
//				for (Parameter param : a.getParameters()) {
//					if (!param.getName().equalsIgnoreCase("PARENT"))
//						elementModel.setValue(param.getName(), param.getValue());
//				}
//
//				// Work on parent relations
//				if (a.getParameterVector("PARENT") != null) {
//
//					for (String parentID : a.getParameterVector("PARENT")) {
//						controller.setParent(elementModel, controller.getElement(Integer.parseInt(parentID)));
//
//						Logger.log("[lasad.gwt.client.communication.LASADActionReceiver] Added ParentElement: " + parentID, Logger.DEBUG);
//					}
//				}
//
//				// Now Register new Element to the Model
//				controller.addElementModel(elementModel);
//
//				if (elementType.equalsIgnoreCase("FEEDBACK-CLUSTER")) {
//					LASAD_Client.getMapTab(controller.getMapID()).getMyMapSpace().getFeedbackPanel().addFeedbackMessage(elementID, a.getParameter("MESSAGE"));
//				}
//				break;
//			case UpdateElement:
//				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver.processMapAction] UPDATE-ELEMENT", Logger.DEBUG);
//
//				if (a.getParameter("USERNAME") != null && a.getParameter("USERNAME").equalsIgnoreCase(LASAD_Client.getInstance().getUsername()) && a.getParameter("STATUS") != null && a.getParameter("TEXT") == null) {
//					Action.removeParameter(a, "STATUS");
//				} else {
//
//					// Action.removeParameter(a, "STATUS");
//					controller.updateElement(Integer.parseInt(a.getParameter("ID")), a.getParameters());
//				}
//				break;
//			case UpdateCursorPosition:
//				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver.processMapAction] UPDATE-CURSOR-POSITION", Logger.DEBUG);
//				Logger.log(a.toString(), Logger.DEBUG_DETAILS);
//				controller.updateElement(Integer.parseInt(a.getParameter("ID")), a.getParameters());
//				break;
//			case DeleteElement:
//				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver.processMapAction] DELETE-ELEMENT", Logger.DEBUG);
//
//				int elementID = Integer.parseInt(a.getParameter("ID"));
//				if (controller.getElement(elementID).getType().equalsIgnoreCase("FEEDBACK-AGENT")) {
//					processRemoveFeedbackAgent(controller, a);
//				}
//
//				try {
//					controller.deleteElement(Integer.parseInt(a.getParameter("ID")), a.getParameter("USERNAME"));
//
//				} catch (Exception e) {
//					Logger.log("Can not delete element, because ELEMENT-ID is no int!", Logger.DEBUG_ERRORS);
//				}
//				break;
//			}

		

			//TODO vereinfachen!!!
			
			if (a.getCmd().equals(Commands.CreateElement)) {

				// Check if the feedback is for the current user, if not -->
				// ignore
				String elementType = a.getParameterValue(ParameterTypes.Type);
				if (elementType.equalsIgnoreCase("FEEDBACK-CLUSTER")) {
					if (!a.getParameterValue(ParameterTypes.UserName).equalsIgnoreCase(LASAD_Client.getInstance().getUsername()) && !a.getParameterValue(ParameterTypes.UserName).equals("")) {
						return;
					}
				}

				// Currently feedback engines count as "element", thus we have
				// to filter them here...
				else if (elementType.equalsIgnoreCase("FEEDBACK-AGENT")) {
					processRegisterFeedbackAgent(controller, a);
				}

				String elementIDString = a.getParameterValue(ParameterTypes.Id);
				int elementID = -1;
				if (elementIDString != null) {
					elementID = Integer.parseInt(elementIDString);
				}

				String username = a.getParameterValue(ParameterTypes.UserName);

				UnspecifiedElementModel elementModel = new UnspecifiedElementModel(elementID, elementType, username);
				
				if(a.getParameterValue(ParameterTypes.ReplayTime)!= null)
				{
					elementModel.setIsReplay(true);
				}

				// Needed to enable the add and del buttons in box header
				if (a.getParameterValue(ParameterTypes.ElementId) != null) {
					elementModel.setElementId(a.getParameterValue(ParameterTypes.ElementId));
				}

				// Add more specific data to the model
				for (Parameter param : a.getParameters()) {
					if (!param.getType().equals(ParameterTypes.Parent))
						elementModel.setValue(param.getType().getOldParameter(), param.getValue());
				}

				// Work on parent relations
				if (a.getParameterValues(ParameterTypes.Parent) != null) {

					for (String parentID : a.getParameterValues(ParameterTypes.Parent)) {
						controller.setParent(elementModel, controller.getElement(Integer.parseInt(parentID)));

						Logger.log("[lasad.gwt.client.communication.LASADActionReceiver] Added ParentElement: " + parentID, Logger.DEBUG);
					}
				}

				// Now Register new Element to the Model
				controller.addElementModel(elementModel);

				if (elementType.equalsIgnoreCase("FEEDBACK-CLUSTER")) {
					LASAD_Client.getMapTab(controller.getMapID()).getMyMapSpace().getFeedbackPanel().addFeedbackMessage(elementID, a.getParameterValue(ParameterTypes.Message));
				}

			} else if (a.getCmd().equals(Commands.UpdateElement)) {

				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver.processMapAction] UPDATE-ELEMENT", Logger.DEBUG);

				if (a.getParameterValue(ParameterTypes.UserName) != null && a.getParameterValue(ParameterTypes.UserName).equalsIgnoreCase(LASAD_Client.getInstance().getUsername()) && a.getParameterValue(ParameterTypes.Status) != null && a.getParameterValue(ParameterTypes.Text) == null) {
					Action.removeParameter(a, ParameterTypes.Status);
				} else {

					// Action.removeParameter(a, "STATUS");
					controller.updateElement(Integer.parseInt(a.getParameterValue(ParameterTypes.Id)), a.getParameters());
				}

			} else if (a.getCmd().equals(Commands.UpdateCursorPosition)) {

				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver.processMapAction] UPDATE-CURSOR-POSITION", Logger.DEBUG);
				Logger.log(a.toString(), Logger.DEBUG_DETAILS);
				controller.updateElement(Integer.parseInt(a.getParameterValue(ParameterTypes.Id)), a.getParameters());

			} else if (a.getCmd().equals(Commands.DeleteElement)) {

				Logger.log("[lasad.gwt.client.communication.LASADActionReceiver.processMapAction] DELETE-ELEMENT", Logger.DEBUG);

				int elementID = Integer.parseInt(a.getParameterValue(ParameterTypes.Id));
				if (controller.getElement(elementID).getType().equalsIgnoreCase("FEEDBACK-AGENT")) {
					processRemoveFeedbackAgent(controller, a);
				}

				try {
					controller.deleteElement(Integer.parseInt(a.getParameterValue(ParameterTypes.Id)), a.getParameterValue(ParameterTypes.UserName));

				} catch (Exception e) {
					Logger.log("Can not delete element, because ELEMENT-ID is no int!", Logger.DEBUG_ERRORS);
				}

			} 
			
			else if (a.getCategory().equals(Categories.Error)) {
				LASADInfo.display("Error", a.getParameterValue(ParameterTypes.Message));
			}

		}

	}

	private void processRegisterFeedbackAgent(MVController controller, Action a) {

		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processRegisterFeedbackAgent] Processing new feedback agent...", Logger.DEBUG);

		Logger.log("[Details] " + a.toString(), Logger.DEBUG_DETAILS);
		ArgumentMapMenuBar currentMenu = LASAD_Client.getMapTab(controller.getMapID()).getMyMapSpace().getMenuBar();
		if (a.getParameterValue(ParameterTypes.AgentType) != null) {
			currentMenu.addFeedbackEngine(a.getParameterValue(ParameterTypes.AgentId), a.getParameterValue(ParameterTypes.TypeId), a.getParameterValue(ParameterTypes.AgentType));
		} else {
			currentMenu.addFeedbackEngine(a.getParameterValue(ParameterTypes.AgentId), a.getParameterValue(ParameterTypes.TypeId));
		}
	}

	private void processRemoveFeedbackAgent(MVController controller, Action a) {

		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processRegisterFeedbackAgent] Processing new feedback agent...", Logger.DEBUG);

		Logger.log("[Details] " + a.toString(), Logger.DEBUG_DETAILS);
		ArgumentMapMenuBar currentMenu = LASAD_Client.getMapTab(controller.getMapID()).getMyMapSpace().getMenuBar();
		currentMenu.removeFeedbackEngine(controller.getElement(Integer.parseInt(a.getParameterValue(ParameterTypes.Id))).getValue("AGENT-ID"), controller.getElement(Integer.parseInt(a.getParameterValue(ParameterTypes.Id))).getValue("TYPE-ID"));
	}

	private void processHeartbeatAction(MVController controller, Action a) {
		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processHeartbeatAction] Processing heartbeat action...", Logger.DEBUG);
	}

	private void processUserEventAction(MVController controller, Action a) {

		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processUserEventAction] Processing userevent action...", Logger.DEBUG);
		Logger.log("[Details] " + a.toString(), Logger.DEBUG_DETAILS);
		
		Commands command = a.getCmd();

		// Generate new LASAD Event
		LasadEvent newEvent = new LasadEvent();

		newEvent.setType("USER_" + command);

		if (command.equals(Commands.UserJoin)) {
			// A New User Joined the map
			HashMap<String, String> data = new HashMap<String, String>();
			data.put("USERNAME", a.getParameterValue(ParameterTypes.UserName));
			data.put("CLIENT", LASAD_Client.getInstance().getUsername());
			newEvent.setData(data);
		} else if (command.equals(Commands.UserLeave)) {
			newEvent.setData(a.getParameterValue(ParameterTypes.UserName));
		} else if (command.equals(Commands.UserList)) {
			Vector<String> client = new Vector<String>();
			client.addElement(LASAD_Client.getInstance().getUsername());
			// A complete list of the actual users arrived
			Vector<String> userList = a.getParameterValues(ParameterTypes.UserName);
			HashMap<String, Vector<String>> data = new HashMap<String, Vector<String>>();
			data.put("CLIENT", client);
			data.put("USERLIST", userList);

			newEvent.setData(data);
		}

		if (command != null) {
			controller.fireLasadEvent(newEvent);
		}
	}

	private void processQuestionnaireAction(MVController controller, Action a) {

		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][processQuestionnaireAction] Processing questionnaire action...", Logger.DEBUG);

		Logger.log("[Details] " + a.toString(), Logger.DEBUG_DETAILS);

		// Questionnaire related Stuff
		if (a.getCmd().equals(Commands.Answer)) {
			String questionID = a.getParameterValue(ParameterTypes.QuestionId);
			String answer = a.getParameterValue(ParameterTypes.QuestionAnswer);

			if (questionID != null) {
				LASAD_Client.getMapTab(controller.getMapID()).getMyMapSpace().getTutorial().getQuestionnaireHandler().publishQuestionnaireAnswer(questionID, answer);
			}
		}
	}

	// David Drexler Edit-BEGIN
	// Code outsourcing by Marcel Bergmann

	/**
	 * Processes replay actions
	 * 
	 * @param a
	 *            Action to be processed
	 */
	private void processReplayAction(Action a) {
		switch (a.getCmd()){
		case InitStart:
			// Start to initialize the HashMaps needed for replay...
			// Initialize HashMaps
			this.treeForwReplay = new TreeMap<Integer, ActionPackage>();
			this.treeUserReplay = new TreeMap<String, List<Integer>>();
			this.elementReplay = new ArrayList<Integer>();
			init = new ReplayInitializer(treeForwReplay, treeUserReplay, elementReplay);
			break;
		case InitEnd:
			init.finishInitialization(a);
			break;
		case CreateElement:
		case UpdateElement:
		case DeleteElement:
		case ChatMsg:
			init.createAllReplayActions(a);
			break;
//		case ChatMsg:
//			System.err.println("There are no Methods to handle the Chat Messages!");
//			System.err.println(a.toString());
//			break;
		default:
			// An error has occured
			// Close wait-MessageBox
			LoadingReplayDialogue.getInstance().closeLoadingScreen();
			// Show error
			MapLoginTab.getInstance().infoReplayError(a.getCmd());
		}
		
//		if (a.getCmd().equals(Commands.InitStart)) {
//			// Start to initialize the HashMaps needed for replay...
//			// Initialize HashMaps
//			this.treeForwReplay = new TreeMap<Integer, ActionPackage>();
//			this.treeUserReplay = new TreeMap<String, List<Integer>>();
//			this.elementReplay = new ArrayList<Integer>();
//			init = new ReplayInitializer(treeForwReplay, treeUserReplay, elementReplay);
//		} else if (a.getCmd().equals(Commands.InitEnd)) {
//			init.finishInitialization(a);
//		} else if (a.getCmd().equals(Commands.CreateElement) || a.getCmd().equals(Commands.UpdateElement) || a.getCmd().equals(Commands.DeleteElement)) {
//			init.createAllReplayActions(a);
//		} else if(a.getCmd().equals(Commands.ChatMsg)){
//			System.err.println("There are no Methode to handle the Chat Messages!");
//			System.err.println(a.toString());
//		} else {
//			// An error has occured
//			// Close wait-MessageBox
//			LoadingReplayDialogue.getInstance().closeLoadingScreen();
//			// Show error
//			MapLoginTab.getInstance().infoReplayError(a.getCmd());
//		}
	}

	// David Drexler Edit-END

	/**
	 * Work on ActionSets with no valid/registered MAPIDs
	 * 
	 * @param actionSet
	 */
	private void workOnGlobalAction(Action a) {
		//TODO Vereinfachen!!! Switch und so...
		Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][workOnGlobalAction]", Logger.DEBUG_DETAILS);
		Logger.log(a.toString(), Logger.DEBUG_DETAILS);

		if (a.getCategory().equals(Categories.Auth) || a.getCategory().equals(Categories.Map) || a.getCategory().equals(Categories.Management)) {
			processManagementAction(a);
		} else if (a.getCategory().equals(Categories.Error)) {
			LASADInfo.display("Error", a.getParameterValue(ParameterTypes.Message));
		} else if (a.getCategory().equals(Categories.Notify)) {
			
			if(a.getCmd().equals(Commands.UserCreated)) {
				CreateAndDeleteUsers.resetUserData();
			} 
			else if(a.getCmd().equals(Commands.OntologyCreated)) {
				CreateModifyAndDeleteOntology.resetOntologyData();
			}
			else if(a.getCmd().equals(Commands.TemplateCreated)) {
				CreateAndDeleteTemplate.resetTemplateData();
			}
			else if(a.getCmd().equals(Commands.SessionCreated)) {
				CreateAndDeleteSessions.resetSessionData();
			}
			else if(a.getCmd().equals(Commands.ErrorInfo)) {
				String msg = " Please check with the administrator, or reload the page and login again.";
				MessageBox.wait("Account problem", a.getParameterValue(ParameterTypes.Message) + msg, null);
			}
			
			LASADInfo.display("Notification", a.getParameterValue(ParameterTypes.Message));
		} else if (a.getCategory().equals(Categories.Session)) {
			processSessionAction(a);
		} else if (a.getCategory().equals(Categories.Authoring)) {
			processAuthoringAction(a);
		} else if (a.getCategory().equals(Categories.Replay)) {
			processReplayAction(a);
		} else if (a.getCategory().equals(Categories.Info)) {
			if (a.getCmd().equals(Commands.JoinComplete)) {
				LoadingMapDialogue.getInstance().closeLoadingScreen();
				
				this.centerMap(a);
				
			} else if (a.getCmd().equals(Commands.Ready)) {
				if (a.getParameterValue(ParameterTypes.ImportType).equalsIgnoreCase("LASAD")) {
					LoadingMapFromFileDialogue.getInstance().closeLoadingScreen();					
				}
				if (a.getParameterValue(ParameterTypes.ImportType).equalsIgnoreCase("LARGO") || a.getParameterValue(ParameterTypes.ImportType).equalsIgnoreCase("ARGUNAUT")) {
					ImportingMapDialogue.getInstance().closeLoadingScreen();
				}
			} else if (a.getCmd().equals(Commands.AuthoringFailed)) {
				LASADInfo.display("Error", a.getParameterValue(ParameterTypes.Message));
			}
		} else {
			Logger.log("[lasad.gwt.client.communication.LASADActionReceiver][workOnGlobalAction] Error: Unknown action category! [CATEGORY: " + a.getCategory() + "]", Logger.DEBUG);
		}
	}

	/**
	 * Calculates the center of all existing boxes and scrolls the map to this position
	 * @param a the join-complete action with the map information
	 */
	private void centerMap(Action a) {
		//Scroll the map to the center of all boxes
		int xsum = 0;
		int ysum = 0;
		int numberOfObjects = 0;
		
		//Map-Id-Hack... normal tag would be filtered by ActionReceiver, that's why this action has its own mapid-attribute
		AbstractArgumentMap map = LASAD_Client.getMapTab(Integer.parseInt(a.getParameterValue(ParameterTypes.MapId))).getMyMapSpace().getMyMap();
		List<Component> mapComponents = map.getItems();
		Iterator<Component> iter = mapComponents.iterator();
		while (iter.hasNext()) {
			Component component = iter.next();
			if (component instanceof Box ) {
				Box box = (Box) component;
				xsum += box.getPosition(true).x + box.getWidth() / 2;
				ysum += box.getPosition(true).y + box.getHeight() / 2;
				numberOfObjects++;
			}
		}
		
		if (numberOfObjects > 0) {
			map.getLayoutTarget().dom.setScrollLeft(xsum / numberOfObjects - map.getInnerWidth() / 2);
			map.getLayoutTarget().dom.setScrollTop(ysum / numberOfObjects - map.getInnerHeight() / 2);
		}
		else {
			map.getLayoutTarget().dom.setScrollLeft(map.getMapDimensionSize().width / 2 - map.getInnerWidth() / 2);
			map.getLayoutTarget().dom.setScrollTop(map.getMapDimensionSize().height / 2 - map.getInnerHeight() / 2);
		}
	}
	
	private void processAuthoringAction(final Action a) {
		if (AuthoringTab.active) {
			switch (a.getCmd()){
			case AddUserToList:
				CreateAndDeleteUsers.addUserItem(a.getParameterValue(ParameterTypes.UserName), a.getParameterValue(ParameterTypes.Role), a.getParameterValue(ParameterTypes.UserId), a.getParameterValue(ParameterTypes.UserMaxId));
				break;
			case AddTemplateToList:
				CreateAndDeleteTemplate.addTemplateItem(a.getParameterValue(ParameterTypes.Ontology), a.getParameterValue(ParameterTypes.Template), a.getParameterValue(ParameterTypes.TemplateId), a.getParameterValue(ParameterTypes.TemplateMaxId));				
				break;
			case AddMapToList:
				CreateAndDeleteSessions.addSessionItem(a.getParameterValue(ParameterTypes.MapName), a.getParameterValue(ParameterTypes.Template), a.getParameterValue(ParameterTypes.MapId), a.getParameterValue(ParameterTypes.MapMaxId));
				break;
			case DeleteTemplateFromList:
				CreateAndDeleteTemplate.removeTemplateItem(a.getParameterValue(ParameterTypes.Ontology), a.getParameterValue(ParameterTypes.Template));
				break;
			case DeleteUserFromList:
				CreateAndDeleteUsers.removeUserItem(a.getParameterValue(ParameterTypes.Role), a.getParameterValue(ParameterTypes.UserName));
				break;
			case DeleteMapFromList:
				CreateAndDeleteSessions.removeSessionItem(a.getParameterValue(ParameterTypes.MapName), a.getParameterValue(ParameterTypes.Template));
				break;
			case DeleteOntologyFromList:
				CreateModifyAndDeleteOntology.removeOntologyItem(a.getParameterValue(ParameterTypes.OntologyName));
				break;
			case ListUsers:
				CreateAndDeleteSessions.createUserList(a.getParameterValues(ParameterTypes.UserName));
				break;
			case ListOntologies:
				CreateModifyAndDeleteOntology.updateOntologyView(a.getParameterValues(ParameterTypes.OntologyName));
				break;
			case OntologyDetails:
				CreateModifyAndDeleteOntology.updateOntologyDetailsView(a.getParameterValue(ParameterTypes.Ontology));
				break;
			case ConfirmationRequest:
				final Listener<MessageBoxEvent> l = new Listener<MessageBoxEvent>() {
					public void handleEvent(MessageBoxEvent ce) {
						Button btn = ce.getButtonClicked();

						if (btn.getItemId().equals(Dialog.YES)) {
							ActionPackage p = ActionFactory.getInstance().recoverRequestFromConfirmation(a);
							LASADActionSender.getInstance().sendActionPackage(p);
						}
					}
				};

				MessageBox.confirm("Confirm", a.getParameterValue(ParameterTypes.Message), l);
				break;
			}
			
			//code aus switch-block
//			if (a.getCmd().equalsIgnoreCase("ADD-USER-TO-LIST")) {
//				CreateAndDeleteUsers.addUserItem(a.getParameter("USERNAME"), a.getParameter("ROLE"), a.getParameter("USER-ID"), a.getParameter("USER-MAXID"));
//			} else if (a.getCmd().equalsIgnoreCase("ADD-TEMPLATE-TO-LIST")) {
//				CreateAndDeleteTemplate.addTemplateItem(a.getParameter("ONTOLOGY"), a.getParameter("TEMPLATE"), a.getParameter("TEMPLATE-ID"), a.getParameter("TEMPLATE-MAXID"));
//			} else if (a.getCmd().equalsIgnoreCase("ADD-MAP-TO-LIST")) {
//				CreateAndDeleteSessions.addSessionItem(a.getParameter("MAPNAME"), a.getParameter("TEMPLATE"), a.getParameter("MAP-ID"), a.getParameter("MAP-MAXID"));
//			} else if (a.getCmd().equalsIgnoreCase("DELETE-TEMPLATE-FROM-LIST")) {
//				CreateAndDeleteTemplate.removeTemplateItem(a.getParameter("ONTOLOGY"), a.getParameter("TEMPLATE"));
//			} else if (a.getCmd().equalsIgnoreCase("DELETE-USER-FROM-LIST")) {
//				CreateAndDeleteUsers.removeUserItem(a.getParameter("ROLE"), a.getParameter("USERNAME"));
//			} else if (a.getCmd().equalsIgnoreCase("DELETE-MAP-FROM-LIST")) {
//				CreateAndDeleteSessions.removeSessionItem(a.getParameter("MAPNAME"), a.getParameter("TEMPLATE"));
//			} else if (a.getCmd().equalsIgnoreCase("DELETE-ONTOLOGY-FROM-LIST")) {
//				CreateModifyAndDeleteOntology.removeOntologyItem(a.getParameter("ONTOLOGYNAME"));
//			} else if (a.getCmd().equalsIgnoreCase("LIST-USERS")) {
//				CreateAndDeleteSessions.createUserList(a.getParameterVector("USERNAME"));
//			} else if (a.getCmd().equalsIgnoreCase("LIST-ONTOLOGIES")) {
//				CreateModifyAndDeleteOntology.updateOntologyView(a.getParameterVector("ONTOLOGYNAME"));
//			} else if (a.getCmd().equalsIgnoreCase("ONTOLOGY-DETAILS")) {
//				CreateModifyAndDeleteOntology.updateOntologyDetailsView(a.getParameter("ONTOLOGY"));
//			} else if (a.getCmd().equalsIgnoreCase("CONFIRMATION-REQUEST")) {
//
//				final Listener<MessageBoxEvent> l = new Listener<MessageBoxEvent>() {
//					public void handleEvent(MessageBoxEvent ce) {
//						Button btn = ce.getButtonClicked();
//
//						if (btn.getItemId().equals(Dialog.YES)) {
//							ActionPackage p = ActionFactory.getInstance().recoverRequestFromConfirmation(a);
//							LASADActionSender.getInstance().sendActionPackage(p);
//						}
//					}
//				};
//
//				MessageBox.confirm("Confirm", a.getParameter("MESSAGE"), l);
//			}
			
			
		}
	}
	
}