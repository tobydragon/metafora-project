package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;


public class TestData {

	public static Map<String, String> getAgents() {
		Map<String, String> agents = new HashMap<String, String>();
        agents.put("largo-default", "largo, read / write");
        agents.put("largo-v2", "largo, read / -");
        agents.put("deeploop-default", "largo, - / -");
        agents.put("largo-test", "largo, read / write");
        agents.put("argunaut-default", "argunaut read / write");
        agents.put("argunaut-test", "argunaut - / -");
        return agents;
    }
	
	public static List<PatternFA> getPatterns() {
		Vector<PatternFA> patterns	 = new Vector<PatternFA>();
		patterns.add(new PatternFA("no_hypos", "counter", ""));
		patterns.add(new PatternFA("no_facts", "counter", ""));
		patterns.add(new PatternFA("no_relations", "counter", "user-specific"));
		patterns.add(new PatternFA("test_without_condition", "structure", ""));
        return patterns;
    }
	
	public static List<OntologyFA> getOntologiesAsOnt(){
		Vector<OntologyFA> ontoList = new Vector<OntologyFA>();
		/*
		 * TODO obtain the ontologies from the server
		 */
		List<String> strList = TestData.getOntologiesAsStr();
		
		for(String s: strList){
			OntologyFA o = new OntologyFA(s);
			ontoList.add(o);
		}
		return ontoList;
	}
	
	public static List<String> getOntologiesAsStr() {
        List<String> list = new ArrayList<String>();
        list.add("argunaut");
        list.add("largo");
        return list;
    }
	
	public static TreeFolder getTreeModel() {
		TreeFolder[] ontologies = new TreeFolder[]{
				new TreeFolder("argunaut", null, null, new TreeFolderChild[] {
						new TreeFolderChild("argunaut-default", "argunaut read / write"),
						new TreeFolderChild("argunaut-test", "argunaut - / -"),
			        }),
			    new TreeFolder("largo", null, null, new TreeFolderChild[] {
			    		new TreeFolderChild("largo-default", "largo, read / write"),
			    		new TreeFolderChild("largo-v2", "largo, read / -"),
			    	}),
		};
		
		TreeFolder root = new TreeFolder("root", null, null);
	    for (int i = 0; i < ontologies.length; i++) {
	      root.add((TreeFolder) ontologies[i]);
	    }

	    return root;
	}
	
	public static List<SessionFA> getSessions() {
		List<SessionFA> list = new ArrayList<SessionFA>();
        list.add(new SessionFA("1", "LARGO Carney Petitioner - Map 1", "largo", "running"));
        list.add(new SessionFA("2", "LARGO Carney Petitioner - Map 2", "largo", "running"));
        list.add(new SessionFA("3", "ARGUNAUT - Map 3", "argunaut", "running"));

	    return list;
	}
	
	public static List<String> getSessionsAsStr() {
		List<String> list = new ArrayList<String>();
        list.add("LARGO Carney Petitioner - Map 1");
        list.add("LARGO Carney Petitioner - Map 2");
        list.add("ARGUNAUT - Map 3");
	    return list;
	}
	
	public static TreeFolder getSessionsModel() {
//		TreeFolder[] ontologies = new TreeFolder[]{
//				new TreeFolder("LARGO Carney Petitioner - Map 1 (largo)", new Agent[] {}),
//			    new TreeFolder("LARGO Carney Petitioner - Map 2 (largo)", new Agent[] {}),
//		    	new TreeFolder("ARGUNAUT - Map 3 (argunaut)", new Agent[] {}),
//		};
		TreeFolder[] ontologies = new TreeFolder[]{
				new TreeFolder("LARGO Carney Petitioner - Map 1", "largo", "running...", new TreeFolderChild[] {}),
				new TreeFolder("LARGO Carney Petitioner - Map 2", "largo", "running...", new TreeFolderChild[] {}),
		    	new TreeFolder("ARGUNAUT - Map 3", "argunaut", "running...", new TreeFolderChild[] {}),
		};
		
		TreeFolder root = new TreeFolder("root", null, null);
	    for (int i = 0; i < ontologies.length; i++) {
	      root.add((TreeFolder) ontologies[i]);
	    }

	    return root;
	}
	
	public static TreeFolder getTreeModelAgent2Session() {
		TreeFolder[] ontologies = new TreeFolder[]{
				new TreeFolder("LARGO Carney Petitioner", "(largo)", null, new TreeFolderChild[] {
						new TreeFolderChild("One", "largo"),
		                new TreeFolderChild("two", "largo"),
			        }),
			    new TreeFolder("LARGO Carney Petitioner", "(largo)", null, new TreeFolderChild[] {
			    		new TreeFolderChild("largo-default", "largo"),
			    		new TreeFolderChild("largo-test", "largo"),
			    	}),
		    	new TreeFolder("ARGUNAUT", "(argunaut)", null, new TreeFolderChild[] {
			    		new TreeFolderChild("argunaut-default", "argunaut"),
			    		new TreeFolderChild("argunaut-test", "argunaut"),
			    	}),
		};
		
		TreeFolder root = new TreeFolder("root", null, null);
	    for (int i = 0; i < ontologies.length; i++) {
	      root.add((TreeFolder) ontologies[i]);
	    }

	    return root;
	}
	
	public static TreeFolder getTreeModelSessions() {
		TreeFolder[] ontologies = new TreeFolder[]{
				new TreeFolder("LARGO Carney Petitioner - Map 1", "(largo, running...)", null, new TreeFolderChild[] {
						new TreeFolderChild("One", "(active)"),
		                new TreeFolderChild("two", "(active)"),
			        }),
			    new TreeFolder("LARGO Carney Petitioner - Map 2", "(largo, running...)", null, new TreeFolderChild[] {
			    		new TreeFolderChild("largo-default", "(inactive, waiting for session restart)"),
			    		new TreeFolderChild("largo-test", "(active, marked for deletion)"),
			    	}),
		    	new TreeFolder("ARGUNAUT - Map 3", "(argunaut, running...)", null, new TreeFolderChild[] {
			    		new TreeFolderChild("argunaut-default", "(active)"),
			    		new TreeFolderChild("argunaut-test", "(active)"),
			    	}),
		};
		
		TreeFolder root = new TreeFolder("root", null, null);
	    for (int i = 0; i < ontologies.length; i++) {
	      root.add((TreeFolder) ontologies[i]);
	    }

	    return root;
	}
	
	
}
