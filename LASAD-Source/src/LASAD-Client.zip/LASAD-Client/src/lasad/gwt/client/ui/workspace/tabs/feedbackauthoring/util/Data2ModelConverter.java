package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util;

import java.util.ArrayList;
import java.util.List;

import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.AgentFA;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.ElementModel;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.OntologyFA;


public class Data2ModelConverter {
	
//	public static List<OntologyModel> getOntAsModel(List<Ontology> list){
//        List<OntologyModel> listModel = new ArrayList<OntologyModel>();
//        for(Ontology ont:list){
//        	listModel.add(new OntologyModel(ont.getName(), null));
//        }
//        return listModel;
//	}
	
	public static List<ElementModel> getOntAsModel(List<OntologyFA> list){
        List<ElementModel> listModel = new ArrayList<ElementModel>();
        for(OntologyFA ont:list){
        	listModel.add(new ElementModel(ont.getName(), null));
        }
        return listModel;
	}
	
//	public static List<AgentModel> getAgAsModel(List<String> agList){
//        List<AgentModel> listModel = new ArrayList<AgentModel>();
//        for(String ag:agList){
//        	listModel.add(new AgentModel(ag, null));
//        }
//        return listModel;
//	}
	
	public static List<ElementModel> getStrAsModel(List<String> agList){
        List<ElementModel> listModel = new ArrayList<ElementModel>();
        for(String ag:agList){
        	listModel.add(new ElementModel(ag, null));
        }
        return listModel;
	}
	
	public static List<ElementModel> getAgAsModel(List<AgentFA> list){
        List<ElementModel> listModel = new ArrayList<ElementModel>();
        for(AgentFA ag:list){
        	listModel.add(new ElementModel(ag.getAgentName(), null));
        }
        return listModel;
	}
	
}
