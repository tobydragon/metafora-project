package lasad.gwt.client.ui.workspace.argumentmap.elements;

import java.util.Vector;

import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.ui.box.Box;
import lasad.gwt.client.ui.common.FocusableInterface;
import lasad.gwt.client.ui.link.Link;
import lasad.gwt.client.ui.workspace.argumentmap.ArgumentMap;

import com.extjs.gxt.ui.client.widget.BoxComponent;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;

public class CreateLinkDialog extends BoxComponent implements FocusableInterface {

	private ArgumentMap myMap;
	private Element rootElement, headerElement;
	private Vector<Element> actions = null;

	private EventListener linkDialogListener;

	//Constructor not even called? 
	public CreateLinkDialog(ArgumentMap map, Box start, Box end) {
		this.myMap = map;

		linkDialogListener = new CreateLinkDialogListener(myMap, this, start, end);

		actions = new Vector<Element>();

		rootElement = DOM.createDiv();
		rootElement.setClassName("dialog-root");

		initHeading();

		initMenu();
		for (int i = 0; i < actions.size(); i++) {
			DOM.appendChild(rootElement, actions.get(i));
		}

		int posX = Math.abs(start.getPosition(true).x + end.getPosition(true).x + end.getWidth()) / 2 - this.getWidth() / 2;
		int posY = Math.abs(start.getPosition(true).y + end.getPosition(true).y + end.getHeight()) / 2;

		setPosition(posX, posY);
		
		//Get Focus
		myMap.getFocusHandler().releaseAllFocus();
		myMap.getFocusHandler().setFocus(this);
	}

	public CreateLinkDialog(ArgumentMap map, Box start, Box end, int posX, int posY) {
		this.myMap = map;

		linkDialogListener = new CreateLinkDialogListener(myMap, this, start, end);

		actions = new Vector<Element>();

		rootElement = DOM.createDiv();
		rootElement.setClassName("dialog-root");

		initHeading();

		initMenu();
		for (int i = 0; i < actions.size(); i++) {
			DOM.appendChild(rootElement, actions.get(i));
		}


		setPosition(Math.abs(posX), Math.abs(posY));

		//Get Focus
		myMap.getFocusHandler().releaseAllFocus();
		myMap.getFocusHandler().setFocus(this);
	}

	public CreateLinkDialog(ArgumentMap map, Box start, Link end, int posX, int posY) {
		this.myMap = map;

		linkDialogListener = new CreateLinkDialogListener(myMap, this, start, end);

		actions = new Vector<Element>();

		rootElement = DOM.createDiv();
		rootElement.setClassName("dialog-root");

		initHeading();

		initMenu();
		for (int i = 0; i < actions.size(); i++) {
			DOM.appendChild(rootElement, actions.get(i));
		}

		setPosition(Math.abs(posX), Math.abs(posY));
		myMap.getFocusHandler().releaseAllFocus();
		myMap.getFocusHandler().setFocus(this);
	}


	public void initHeading() {
		this.headerElement = DOM.createDiv();
		this.headerElement.setInnerText("Please choose link...");
		this.headerElement.setClassName("dialog-heading");
		DOM.setStyleAttribute(headerElement, "backgroundColor", "#E6E6E6");
		DOM.appendChild(rootElement, headerElement);
	}

	public void initMenu() {
		for (ElementInfo info : myMap.getMyViewSession().getController().getMapInfo().getElementsByType("relation").values()) {

			Element tmpElement = DOM.createDiv();
			tmpElement.setClassName("dialog-text");
			tmpElement.setInnerText(info.getElementOption("heading"));
			this.actions.add(tmpElement);

			DOM.sinkEvents(tmpElement, Event.ONMOUSEOUT | Event.ONMOUSEOVER | Event.ONCLICK);
			DOM.setEventListener(tmpElement, linkDialogListener);
		}

		Element cancelElement = DOM.createDiv();
		cancelElement.setClassName("dialog-text");
		cancelElement.setInnerText("Cancel");
		this.actions.add(cancelElement);

		DOM.sinkEvents(cancelElement, Event.ONMOUSEOUT | Event.ONMOUSEOVER | Event.ONCLICK);
		DOM.setEventListener(cancelElement, linkDialogListener);
	}

	protected void onRender(Element target, int index) {
		super.onRender(target, index);
		setElement(this.rootElement, target, index);
	}

	@Override
	protected void afterRender() {
		super.afterRender();
		CreateLinkDialog.this.el().updateZIndex(1);
	}

	public FocusableInterface getFocusParent() {
		return myMap;
	}

	public void setElementFocus(boolean focus) {
		if (!focus) {
			// focus got lost
			removeFromParent();
		}
	}
}