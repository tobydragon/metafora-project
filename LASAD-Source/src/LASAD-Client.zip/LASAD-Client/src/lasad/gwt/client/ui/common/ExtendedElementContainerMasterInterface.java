package lasad.gwt.client.ui.common;

import lasad.gwt.client.model.MVCViewSession;
import lasad.gwt.client.ui.common.highlight.HighlightHandler;

public interface ExtendedElementContainerMasterInterface {

	
	public FocusHandler getFocusHandler();

	public HighlightHandler getHighlightHandler();

	public MVCViewSession getMVCViewSession();
	
	public void extendedElementContainerCallNewHeight(int height);

	public void extendedElementContainerPublishedNewMaxHeight(int height);
	public void extendedElementContainerPublishedNewMinHeight(int height);

}
