package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;




public class DatabaseFA {
//	Log logger = LogFactory.getLog(Database.class);
	private static int agentCounter = 0;
	
	/*
	 * These HashMaps are used to stored all the Agents, Ontologies and Sessions 
	 */
	private HashMap<String, AgentDescriptionFE> agentStore = new HashMap<String, AgentDescriptionFE>();
	private HashMap<String, OntologyFA> ontologyStore = new HashMap<String, OntologyFA>();
	private HashMap<String, SessionFA> sessionStore = new HashMap<String, SessionFA>();
	/*
	 * Used to track session name and ID
	 */
	private HashMap<String, String> id2NameSession = new HashMap<String, String>();
	
	/*
	 * These HashMaps are used to: 
	 */
	// track the Agents in Ontologies     <Ontology, HashMap<Agent, 0>
	private HashMap<String, HashMap<String, Integer>> agent2OntologyTracker = new HashMap<String, HashMap<String, Integer>>();
	// track the Agents in Sessions     <Sessions, HashMap<Agent, 0>
	private HashMap<String, HashMap<String, Integer>> agent2SessionTracker = new HashMap<String, HashMap<String, Integer>>();
	// used to track the Ontologies where the agent is assigned
	private HashMap<String, List<String>> ontology2AgentTracker = new HashMap<String, List<String>>();
	// used to track the Sessions where the agent is assigned
	private HashMap<String, List<String>> session2AgentTracker = new HashMap<String, List<String>>();
	
	// used to track the sessions with the same ontology <ontologyName, List<sessionName>
	private HashMap<String, List<String>> session2OntoTracker = new HashMap<String, List<String>>();
	
	public boolean addAgent(AgentDescriptionFE agent){
		boolean error = true;
		String agentName = agent.getAgentID();
		if(!agentStore.containsKey(agentName)){
			agentStore.put(agentName, agent);
			error = false;
		}
		return error;
	}
	
	public boolean deleteAgent(String agentName){
		boolean error = true;
		if(agentStore.containsKey(agentName)){
			agentStore.remove(agentName);
			//TODO ask if we need to delete agent from session and ontologies as well.
			error = false;
		}
		return error;
	}
	
	public boolean existAgent(String agentName){
		boolean returnVal = false;
		if(agentStore.containsKey(agentName)){
			returnVal = true;
		}
		return returnVal;
	}
	
	public AgentDescriptionFE getAgent(String agentName){
		return agentStore.get(agentName);
	}
	
	public List<String> getAgents(){
		List<String> tmp = new Vector<String>();
		Set<String> setAg = agentStore.keySet();
		tmp.addAll(setAg);
		
		return tmp;
	}
	
	public void resetAgents(){
		agentStore.clear();
	}
	
	public boolean addOntology(OntologyFA ontology){
		boolean error = true;
		String ontologyName = ontology.getName();
		if(!ontologyStore.containsKey(ontologyName)){
			ontologyStore.put(ontologyName, ontology);
			error = false;
		}
		return error;
	}
	
	public Set<String> getOntologies(){
		return ontologyStore.keySet();
	}
	
	public boolean existOntology(String ontologyName){
		boolean returnVal = false;
		if(ontologyStore.containsKey(ontologyName)){
			returnVal = true;
		}
		return returnVal;
	}
	
	public void resetOntologies(){
		ontologyStore.clear();
	}
	
	public boolean addSession(SessionFA session){
		boolean error = true;
		String sessionName = session.getName();
		if(!sessionStore.containsKey(sessionName)){
			sessionStore.put(sessionName, session);
			addSes2OntoTracker(sessionName, session.getOntology());
			id2NameSession.put(session.getId(), session.getName());
			
			error = false;
		}
		return error;
	}
	public Set<String> getSessions(){
		return sessionStore.keySet();
	}
	
	public void resetSessions(){
		sessionStore.clear();
	}
	
	public boolean existSession(String sessionName){
		boolean returnVal = false;
		if(sessionStore.containsKey(sessionName)){
			returnVal = true;
		}
		return returnVal;
	}
	
	public SessionFA getSession(String sessionName){
		return sessionStore.get(sessionName);
	}
	
//	public boolean deleteSession(String sessionName){
//	boolean error = true;
//	if(sessionStore.containsKey(sessionName)){
//		SessionFA session = sessionStore.remove(sessionName);
//		deleteSesFromOntoTracker(sessionName, session.getOntology());
//		id2NameSession.remove(session.getId());
//		error = false;
//	}
//	return error;
//}
	
	public List<String> getSessionsWithOntology(String ontology){
		List<String> tmp = new Vector<String>();
		if(session2OntoTracker.containsKey(ontology)){
			tmp.addAll(session2OntoTracker.get(ontology));
		}
		return tmp;
	}
	
	public String getSessionName(String sessionId){
		return id2NameSession.get(sessionId);
	}
	
	public String getSessionId(String sessionName){
		SessionFA session = sessionStore.get(sessionName);
		return session.getId(); 
	}
	
	/**
     * Adds an agent to an Ontology
     *
     * @param  agent agent's name
     * @param  ontology ontology's name
     * @throws NullPointerException if any of agent and ontology are null .
     */
	public boolean addAgent2Ontology(String agent, String ontology) throws NullPointerException{
		boolean error = true;
		
		if (agent == null) throw new NullPointerException("agent is null");
		if (ontology == null) throw new NullPointerException("ontology is null");
		
		if(existOntology(ontology)){ //check if the ontology is in the ontology store
			if(agent2OntologyTracker.containsKey(ontology)){ //check if the ontology is in the agent2Ontology tracker
				HashMap<String, Integer> ht = agent2OntologyTracker.get(ontology);
				if(!ht.containsKey(agent)){ //check if the agent is already there
					ht.put(agent, 0);
					addOnt2Ont2AgTracker(agent, ontology);
					//logger.debug("Agent -" + agent + "- assigned to ontology -"+ ontology + "' ontology");
				}
				error = false;
			}
		}
		return error;
	}
	
	/**
     * Adds an ontology to an agent
     *
     * @param  agent agent's name
     * @param  ontology ontology's name
     * @throws NullPointerException if any of agent and ontology are null .
     */
	private void addOnt2Ont2AgTracker(String agent, String ontology){
		if(ontology2AgentTracker.containsKey(agent)){
			List<String> listAgOnto = ontology2AgentTracker.get(agent);
			listAgOnto.add(ontology);
		}else{
			List<String> listAgOnto = new Vector<String>();
			listAgOnto.add(ontology);
			ontology2AgentTracker.put(agent, listAgOnto);
		}
	}
	
	/**
	 * get agents in ontology
     * gets a list of agents assigned to the ontology
     * @param  ontology ontology's name
     * @return List<String> the list of agents
     */
	public List<String> getAgInOnt(String ontology){
		List<String> list;
		if(agent2OntologyTracker.containsKey(ontology)){
			HashMap<String, Integer> tmp = agent2OntologyTracker.get(ontology);
			list = new Vector<String>(tmp.keySet());
		}else{
			list = new Vector<String>();
		}
		return list;
	}
	
	/**
	 * tests if an ontology has assigned an agent
     * 
     * @param  ontology ontology's name
     * @param  agent agent's name
     * @return true if agent is already assigned in ontology, false otherwise
     */
	public boolean isAgentInOntology(String ontology, String agent){
		boolean retVal = false;
		if(agent2OntologyTracker.containsKey(ontology)){
			HashMap<String, Integer> tmp = agent2OntologyTracker.get(ontology);
			if (tmp.containsKey(agent)){
				retVal = true;
			}
		}
		return retVal;
	}
	
	
	/**
	 * get ontologies for agent
     * gets a list of ontologies where agent is assigned to
     * @param  agent agent name
     * @return List<String> the list of ontologies
     */
	public List<String> getOnt4Ag(String agent){
		List<String> list;
		if(ontology2AgentTracker.containsKey(agent)){
			list = ontology2AgentTracker.get(agent);
		}else{
			list = new Vector<String>();
		}
		return list;
	}
	
	/**
     * deletes all the agent from an ontology
     *
     * @param  ontology name
     * @throws NullPointerException if ontology is null .
     */
	public boolean deleteAllAgentsFromOntology(String ontology) throws NullPointerException{
		boolean error = true;
		
		if (ontology == null) throw new NullPointerException("ontology is null");
		
		if(existOntology(ontology)){ //check if the ontology is in the ontology store
			if(agent2OntologyTracker.containsKey(ontology)){ //check if the ontology is in the agent2Ontology tracker
				HashMap<String, Integer> agentsHM = agent2OntologyTracker.get(ontology);
				Set<String> agentsList = agentsHM.keySet();
				
				for(String agent : agentsList){
					deleteOntFromOnt2AgTracker(agent, ontology);
				}
				agentsHM.clear();
			}
		}
		return error;
	}
	
	/**
     * deletes an agent from an ontology
     *
     * @param  agent agent's name
     * @param  ontology ontology's name
     * @throws NullPointerException if any of agent and ontology are null .
     */
	public boolean deleteAgentFromOntology(String agent, String ontology) throws NullPointerException{
		boolean error = true;
		
		if (agent == null) throw new NullPointerException("agent is null");
		if (ontology == null) throw new NullPointerException("ontology is null");
		
		if(existOntology(ontology)){ //check if the ontology is in the ontology store
			if(agent2OntologyTracker.containsKey(ontology)){ //check if the ontology is in the agent2Ontology tracker
				HashMap<String, Integer> ht = agent2OntologyTracker.get(ontology);
				if(ht.containsKey(agent)){ //check if the agent is there
					ht.remove(agent);
					deleteOntFromOnt2AgTracker(agent, ontology);
					error = false;
					//logger.warn("Agent -" + agent + "- deleted from ontology");
				}
			}
		}
		return error;
	}
	
	/**
     * deletes an ontology from an agent
     *
     * @param  agent agent's name
     * @param  ontology ontology's name
     * @throws NullPointerException if any of agent and ontology are null .
     */
	private void deleteOntFromOnt2AgTracker(String agent, String ontology){
		
		if(ontology2AgentTracker.containsKey(agent)){
			List<String> listAgOnto = ontology2AgentTracker.get(agent);
			listAgOnto.remove(ontology);
		}
	}
	
	/**
     * Adds an agent to a session
     *
     * @param  agent agent's name
     * @param  ontology ontology's name
     * @throws NullPointerException if any of agent and ontology are null .
     */
	public boolean addAgent2Session(String agent, String session) throws NullPointerException{
		boolean error = true;
		
		if (agent == null) throw new NullPointerException("agent is null");
		if (session == null) throw new NullPointerException("session is null");
		
		if(existSession(session)){ //check if the session is in the session store
			if(agent2SessionTracker.containsKey(session)){ //check if the session is in the agent2Session tracker
				HashMap<String, Integer> ht = agent2SessionTracker.get(session);
				if(!ht.containsKey(agent)){ //check if the agent is there
					ht.put(agent, 0);
					addSes2AgSesTracker(agent, session);
					//logger.warn("Agent -" + agent + "- is already assigned to session -"+ session + "'");
				}
				error = false;
			}
		}
		return error;
	}
	
	/**
     * Adds a session to an agent
     *
     * @param  agent agent's name
     * @param  ontology ontology's name
     * @throws NullPointerException if any of agent and ontology are null .
     */
	private void addSes2AgSesTracker(String agent, String session){
		
		if(session2AgentTracker.containsKey(agent)){
			List<String> listAgOnto = session2AgentTracker.get(agent);
			listAgOnto.add(session);
		}else{
			List<String> listAgOnto = new Vector<String>();
			listAgOnto.add(session);
			session2AgentTracker.put(agent, listAgOnto);
		}
	}
	
	/**
	 * tests if a session has assigned an agent
     * 
     * @param  session session's name
     * @param  agent agent's name
     * @return true if agent is already assigned in session, false otherwise
     */
	public boolean isAgentInSession(String session, String agent){
		boolean retVal = false;
		if(agent2SessionTracker.containsKey(session)){
			HashMap<String, Integer> tmp = agent2SessionTracker.get(session);
			if (tmp.containsKey(agent)){
				retVal = true;
			}
		}
		return retVal;
	}
	
	/**
	 * get agents in session
     * gets a list of agents assigned to the session
     * @param  session session's name
     * @return List<String> the list of agents
     */
	public List<String> getAgInSes(String session){
		List<String> list;
		if(agent2SessionTracker.containsKey(session)){
			HashMap<String, Integer> tmp = agent2SessionTracker.get(session);
			list = new Vector<String>(tmp.keySet());
		}else{
			list = new Vector<String>();
		}
		return list;
	}
	
	/**
	 * get sessions for agent
     * gets a list of sessions where agent is assigned to
     * @param  agent agent name
     * @return List<String> the list of sessions
     */
	public List<String> getSes4Ag(String agent){
		List<String> list;
		if(session2AgentTracker.containsKey(agent)){
			list = session2AgentTracker.get(agent);
		}else{
			list = new Vector<String>();
		}
		return list;
	}
	
	/**
     * deletes all the agents from an session
     *
     * @param  ontology name
     * @throws NullPointerException if session is null .
     */
	public boolean deleteAllAgentsFromSession(String session) throws NullPointerException{
		boolean error = true;
		
		if (session == null) throw new NullPointerException("session is null");
		
		if(existSession(session)){ //check if the session is in the session store
			if(agent2SessionTracker.containsKey(session)){ //check if the session is in the agent2Session tracker
				HashMap<String, Integer> agentsHM = agent2SessionTracker.get(session);
				Set<String> agentsList = agentsHM.keySet();
				
				for(String agent : agentsList){
					deleteSesFromSes2AgTracker(agent, session);
				}
				agentsHM.clear();
			}
		}
		return error;
	}
	
	
	
	/**
     * deletes an agent from a session
     *
     * @param  agent agent's name
     * @param  ontology ontology's name
     * @throws NullPointerException if any of agent and ontology are null .
     */
	public boolean deleteAgentFromSession(String agent, String session) throws NullPointerException{
		boolean error = true;
		
		if (agent == null) throw new NullPointerException("agent is null");
		if (session == null) throw new NullPointerException("session is null");
		
		if(existSession(session)){ //check if the session is in the session store
			if(agent2SessionTracker.containsKey(session)){ //check if the session is in the agent2Session tracker
				HashMap<String, Integer> ht = agent2SessionTracker.get(session);
				if(ht.containsKey(agent)){ //check if the agent is there
					ht.remove(agent);
					error = false;
					deleteSesFromSes2AgTracker(agent, session);
					//logger.warn("Agent -" + agent + "- deleted from session");
				}
			}
		}
		
		return error;
	}
	
	/**
     * deletes a session from an agent
     *
     * @param  agent agent's name
     * @param  ontology ontology's name
     * @throws NullPointerException if any of agent and ontology are null .
     */
	private void deleteSesFromSes2AgTracker(String agent, String session){
		
		if(session2AgentTracker.containsKey(agent)){
			List<String> listAgOnto = session2AgentTracker.get(agent);
			listAgOnto.remove(session);
		}
	}
	
	/**
     * Adds a session to an ontology
     *
     * @param  session agent's name
     * @param  ontology ontology's name
     */
	private void addSes2OntoTracker(String session, String ontology){
		
		if(session2OntoTracker.containsKey(ontology)){
			List<String> listOnto = session2OntoTracker.get(ontology);
			listOnto.add(session);
		}else{
			List<String> listOnto = new Vector<String>();
			listOnto.add(session);
			session2OntoTracker.put(ontology, listOnto);
		}
	}
	
	/**
     * deletes a session from an ontology
     *
     * @param  session agent's name
     * @param  ontology ontology's name
     */
	private void deleteSesFromOntoTracker(String session, String ontology){
		
		if(session2AgentTracker.containsKey(ontology)){
			List<String> listAgOnto = session2OntoTracker.get(ontology);
			listAgOnto.remove(session);
		}
	}
	
}
