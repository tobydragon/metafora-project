package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid;

import java.util.Map;
import java.util.Vector;

import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.ElementModel;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.TestData;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.FATConstants;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.FeedbackAuthoringStrings;
import lasad.shared.dfki.meta.ServiceStatus;


import com.extjs.gxt.ui.client.Style.HorizontalAlignment;
import com.extjs.gxt.ui.client.Style.Orientation;
import com.extjs.gxt.ui.client.Style.Scroll;
import com.extjs.gxt.ui.client.data.BaseTreeModel;
import com.extjs.gxt.ui.client.data.ModelData;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.ComponentEvent;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.MessageBoxEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.store.ListStore;
import com.extjs.gxt.ui.client.util.Margins;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.Dialog;
import com.extjs.gxt.ui.client.widget.Info;
import com.extjs.gxt.ui.client.widget.MessageBox;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.grid.ColumnConfig;
import com.extjs.gxt.ui.client.widget.grid.ColumnModel;
import com.extjs.gxt.ui.client.widget.grid.Grid;
import com.extjs.gxt.ui.client.widget.grid.GridCellRenderer;
import com.extjs.gxt.ui.client.widget.layout.FillLayout;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.extjs.gxt.ui.client.widget.layout.RowData;
import com.extjs.gxt.ui.client.widget.toolbar.ToolBar;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.ui.Widget;

public abstract class CustomizedGrid extends ContentPanel{
	
	private GridConf gridConf;
//	private Observer listener;
	public int status = 0;
	
	private ListStore<ElementModel> gridStore = new ListStore<ElementModel>();
	Grid<ElementModel> agentsGrid;
	
	public CustomizedGrid(GridConf gridConf) {
		super(new FitLayout());
		this.setHeaderVisible(false);
	    this.setBodyBorder(false);
		this.gridConf = gridConf;
//		this.listener = listener;
	}
	
	@Override  
	  protected void onRender(Element parent, int index) {  
	    super.onRender(parent, index);
	    
	    this.setHeaderVisible(false);
	    this.setBodyBorder(false);
		
	    add(createGridPanel());
		layout();
	    
	}
	
	
	abstract void markReadyElement(String name);
	abstract void viewElement(String name);
	abstract void editElement(String name);
	abstract void deleteElement(String name);
	abstract void duplicateElement(String name);
	abstract void addElement();
	abstract void populateGridForTesting();
	
	public void resetGrid(){
		gridStore.removeAll();
	}
	
	public ListStore<ElementModel> getGridStore(){
		return gridStore;
	}
	
	public void refreshView(){
		if(agentsGrid.isRendered())
			agentsGrid.getView().refresh(false);
	}
	
	private ContentPanel createGridPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setHeading(gridConf.getHeader());
		panel.setScrollMode(Scroll.AUTOY);
		
		if (gridConf.isAddButtonFlag()){
			Button buttonAdd = new Button("ADD" + " " + gridConf.getCommonLabel()){
				@Override
				protected void onClick(ComponentEvent ce) {
					System.out.println("ADD" + " " + gridConf.getCommonLabel() + " Button pressed");
					addElement();
					
				}
			};
			
			buttonAdd.setIconStyle("icon-plus-circle");//## icon-round-add
			ToolBar toolBar = new ToolBar();
			toolBar.setAlignment(HorizontalAlignment.RIGHT);
			toolBar.add(buttonAdd);
			panel.setTopComponent(toolBar);
		}
		
		final Vector<ColumnConf> colConfigList = gridConf.getColConfigList();
		Vector<ColumnConfig> colList = new Vector<ColumnConfig>();
		
		for(ColumnConf colConf: colConfigList){
			ColumnConfig tmpCol = new ColumnConfig(colConf.getId(), "<div style=\"color:#000000;\">" + 
									colConf.getLabel() + "</div>", colConf.getWidth());
			colList.add(tmpCol);
		}
		
		//ColumnConfig actionsCol = new ColumnConfig("actions", "<div style=\"color:#000000;\">Actions</div>", 150);
		//actionsCol.setDataIndex("actionsCell");
		
		ColumnConfig actionsCol = colList.lastElement();
		
		ColumnModel activeSessionsCM = new ColumnModel(colList);
		//final Grid<ElementModel> agentsGrid = new Grid<ElementModel>(gridStore, activeSessionsCM);
		agentsGrid = new Grid<ElementModel>(gridStore, activeSessionsCM);
		
		actionsCol.setRenderer(new GridCellRenderer(){
			
			@Override
			public Widget render(ModelData model, String property,
					com.extjs.gxt.ui.client.widget.grid.ColumnData config,
					int rowIndex, int colIndex, ListStore store, Grid grid) {
				
				return getActionButtonsPanel(model, property, config, rowIndex, colIndex, store, grid);
			}
			
			private ContentPanel getActionButtonsPanel(final ModelData model, String property,
					com.extjs.gxt.ui.client.widget.grid.ColumnData config,
					int rowIndex, int colIndex, final ListStore<ElementModel> store, final Grid<ElementModel> grid){
				ContentPanel panel = new ContentPanel();
				panel.setLayout(new FillLayout(Orientation.HORIZONTAL));
				panel.setHeaderVisible(false);
				panel.setBodyBorder(false);
				panel.setLayoutOnChange(true);
				panel.setBodyStyle("backgroundColor: transparent;");
				
				Button markReadyButton = new Button();
				Button viewButton = new Button();
				Button editButton = new Button();
				Button deleteButton = new Button();
				Button duplicateButton = new Button();
				
				markReadyButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  String element = (String) model.get(colConfigList.get(0).getId());
				    	  markReadyElement(element);
				      }
				});
				
				viewButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  String element = (String) model.get(colConfigList.get(0).getId());
				    	  viewElement(element);
				    	  //Info.display((String) model.get(colConfigList.get(0).getId()), "<ul><li>" + model.get(colConfigList.get(0).getLabel()) + "</li></ul>");
				      }
				});
				editButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  String element = (String) model.get(colConfigList.get(0).getId());
				    	  editElement(element);
				      }
				});
				deleteButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  final String element = (String) model.get(colConfigList.get(0).getId());
				    	  //String status = (String) model.get(colConfigList.get(2).getId());
				    	  //ElementModel bm = agentsGrid.getStore().findModel("name", element);
				    	  final ElementModel bm = (ElementModel) store.findModel("name", element);
				    	  
				    	  ce.setCancelled(true);
				    	  //Initialize message box
				    	  MessageBox box = new MessageBox();
				    	  box.setButtons(MessageBox.YESNO);
				    	  box.setIcon(MessageBox.QUESTION);
				    	  box.setTitle(FeedbackAuthoringStrings.DELETE_AGENT_LABEL);
				    	  box.setMessage(FeedbackAuthoringStrings.CONFIRMATION_DELETE + element + FeedbackAuthoringStrings.QUESTION_MARK);
				    	  box.addCallback(new Listener<MessageBoxEvent>() {
				    		  public void handleEvent(MessageBoxEvent be) {
				    			  if (be.getButtonClicked().getItemId().equals(Dialog.YES)) {
				    				  //agentsGrid.getStore().remove(bm);
				    				  grid.getStore().remove(bm);
							    	  deleteElement(element);
				    			  }
				    		  }
				    	  });
				    	  box.show();
				      }
				});
				duplicateButton.addSelectionListener(new SelectionListener<ButtonEvent>(){  
				      @Override
				      public void componentSelected(ButtonEvent ce){
				    	  String element = (String) model.get(colConfigList.get(0).getId());
				    	  duplicateElement(element);
				      }
				});
				
				markReadyButton.setStyleName("xfa-btn");
				viewButton.setStyleName("xfa-btn");
				editButton.setStyleName("xfa-btn");
				deleteButton.setStyleName("xfa-btn");
				duplicateButton.setStyleName("xfa-btn");
				
				markReadyButton.setStyleName("x-btn-text", true);
				viewButton.setStyleName("x-btn-text", true);
				editButton.setStyleName("x-btn-text", true);
				deleteButton.setStyleName("x-btn-text", true);
				duplicateButton.setStyleName("x-btn-text", true);
				
				markReadyButton.setStyleName("x-btn", true);
				viewButton.setStyleName("x-btn", true);
				editButton.setStyleName("x-btn", true);
				deleteButton.setStyleName("x-btn", true);
				duplicateButton.setStyleName("x-btn", true);
				
				markReadyButton.setStylePrimaryName("xfa-btn");
				viewButton.setStylePrimaryName("xfa-btn");
				editButton.setStylePrimaryName("xfa-btn");
				deleteButton.setStylePrimaryName("xfa-btn");
				duplicateButton.setStylePrimaryName("xfa-btn");
				
				//TODO
				String compileStatus = "";  //(String) model.get(statusCol.getId());
				
            	if(compileStatus.equals(FATConstants.AGENT_STATUS_OK)){
            		markReadyButton.setIconStyle("icon-compile-green");
            	} else if(compileStatus.equals(FATConstants.AGENT_STATUS_ERROR)){
            		markReadyButton.setIconStyle("icon-compile-red");
            	} else{ //FATConstants.AGENT_STATUS_COMPILED
            		markReadyButton.setIconStyle("icon-compile-gray");
            	}
				
				//markReadyButton.setIconStyle("icon-compile-green");
				viewButton.setIconStyle("icon-view");
				duplicateButton.setIconStyle("icon-duplicate");
				editButton.setIconStyle("icon-edit-gear");
				deleteButton.setIconStyle("icon-delete-circle");
				
				markReadyButton.setWidth(16);
				viewButton.setWidth(16);
				editButton.setWidth(16);
				deleteButton.setWidth(16);
				duplicateButton.setWidth(16);
				
				markReadyButton.setHeight(16);
				viewButton.setHeight(16);
				editButton.setHeight(16);
				deleteButton.setHeight(16);
				duplicateButton.setHeight(16);
				
				markReadyButton.setMinWidth(16);
				viewButton.setMinWidth(16);
				editButton.setMinWidth(16);
				deleteButton.setMinWidth(16);
				duplicateButton.setMinWidth(16);
				
				markReadyButton.setToolTip(FeedbackAuthoringStrings.MARK_READY_AGENT_LABEL);
				viewButton.setToolTip(FeedbackAuthoringStrings.VIEW_AGENT_LABEL);
				editButton.setToolTip(FeedbackAuthoringStrings.EDIT_AGENT_LABEL);
				deleteButton.setToolTip(FeedbackAuthoringStrings.DELETE_AGENT_LABEL);
				duplicateButton.setToolTip(FeedbackAuthoringStrings.DUPLICATE_AGENT_LABEL);
				
				//display buttons.
				if(gridConf.isMarkReadyButtonFlag()){
					panel.add(markReadyButton, new RowData(0.25, 1.0, new Margins(0)));
				}
				if(gridConf.isViewButtonFlag()){
					panel.add(viewButton, new RowData(0.25, 1.0, new Margins(0)));
				}
				if(gridConf.isDuplicateButtonFlag()){
					panel.add(duplicateButton, new RowData(0.25, 0.25, new Margins(0)));
				}
				if(gridConf.isEditButtonFlag()){
					panel.add(editButton, new RowData(0.25, 0.25, new Margins(0)));
				}
				if(gridConf.isDeleteButtonFlag()){
					panel.add(deleteButton, new RowData(0.25, 0.25, new Margins(0)));
				}

				return panel;
			}

		});
		
		CustomizedGridView gridView = new CustomizedGridView();

//	    Grid<ElementModel> agentsGrid = new Grid<ElementModel>(gridStore, activeSessionsCM);
	    //the view is used to handle the mouseOver and mouserOut events 
	    agentsGrid.setView(gridView);
	    agentsGrid.setLazyRowRender(0);
	    	    
	    agentsGrid.setHideHeaders(true);//for column headers
	    agentsGrid.setBorders(true);
	    agentsGrid.setAutoExpandColumn(colList.firstElement().getId());
	    agentsGrid.setAutoExpandMax(700);
	    agentsGrid.setAutoWidth(true);
	    
	    agentsGrid.setTrackMouseOver(true);
	    agentsGrid.getSelectionModel().setLocked(true);
	    agentsGrid.setStripeRows(true);
	    panel.add(agentsGrid);
	    
	    return panel;
	}
	
	public void addElement2GridStore(ElementModel element){
		gridStore.add(element);
		//agentsOntoTree.getView().refresh(false);
	}
	
	public void deleteElementFromStore(ElementModel element){
		gridStore.remove(element);
	}
	
	private void populateGrid(){
		Map<String, String> agents = TestData.getAgents();
		
		for(String a : agents.keySet()){
			ElementModel m = new ElementModel();
			m.set("name", a);
			m.set("status", agents.get(a));
			
			gridStore.add(m);
		}		
	}
	
	
}
