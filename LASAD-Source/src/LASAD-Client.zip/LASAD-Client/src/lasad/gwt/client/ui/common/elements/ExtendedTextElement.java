package lasad.gwt.client.ui.common.elements;

import lasad.gwt.client.communication.LASADActionSender;
import lasad.gwt.client.communication.objects.ActionFactory;
import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.ui.common.ExtendedElement;
import lasad.gwt.client.ui.common.ExtendedElementContainerInterface;
import lasad.gwt.client.ui.workspace.LASADInfo;

import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.util.Size;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;

public class ExtendedTextElement extends ExtendedElement {

	private final boolean DEBUG = false;

	private final LASADActionSender communicator = LASADActionSender
			.getInstance();
	private final ActionFactory actionBuilder = ActionFactory.getInstance();

	private boolean labelOnTop = false; // Used for text fields and areas in the
										// details panel. These will be shown
										// with the label on top instead of the
										// left-hand side.

	private Element elementContent = null;
	private Element labelDiv = null;
	private Element textArea = null;
	private Element textField = null;
	private Element textFrameDiv = null;

	EventListener listener = null;

	private boolean wantFocus = false;
	private boolean readOnly = false;

	
	public ExtendedTextElement(ExtendedElementContainerInterface container,
			ElementInfo config) {
		super(container, config);

		// Set possible Element Vars
		// Only this Elements would be updates to the model
		this.elementVars.add("TEXT");
		this.elementVars.add("STATUS");
		/*if (config.getUiOption("resizable") != null || config.getUiOption("resizable")!="") {
			resizable =Boolean.parseBoolean(config.getUiOption("resizable"));
		}
		else {
			resizable=true;
		}*/
	}

	public ExtendedTextElement(boolean readOnly,
			ExtendedElementContainerInterface container, ElementInfo config) {
		super(container, config);
		this.readOnly = readOnly;
	}

	public ExtendedTextElement(ExtendedElementContainerInterface container,
			ElementInfo config, boolean labelOnTop) {
		this(container, config);
		if ("textfield".equalsIgnoreCase(config.getElementOption("texttype"))) {
			this.labelOnTop = false;
		} else {
			this.labelOnTop = labelOnTop;
		}
		
	
	}

	protected void buildElement() {
		if (elementContent != null) {
			// Already built
			return;
		}

		String tmpValue;

		elementContent = DOM.createDiv();
		elementContent.setClassName("extendedTextElement");

		if (!readOnly) {

			listener = new EventListener() {
				public void onBrowserEvent(Event be) {
					int code = be.getTypeInt();
					if (code == Events.OnMouseDown.getEventCode()) {
						be.stopPropagation();
						if (isBlocked() == false) {
							if (ExtendedTextElement.this.isActiveViewMode()) {
								// Ask for Focus
								ExtendedTextElement.this.getContainer()
										.getFocusHandler()
										.setFocus(ExtendedTextElement.this);
							}
						} else {
							wantFocus = true;
						}
					} else if (code == Events.OnClick.getEventCode()) {
						be.stopPropagation();
					} else if (code == Events.OnFocus.getEventCode()) {
						be.stopPropagation();
						if (ExtendedTextElement.this.isActiveViewMode()) {
							// Ask for Focus by TABULATOR
							ExtendedTextElement.this.getContainer()
									.getFocusHandler()
									.setFocus(ExtendedTextElement.this);
						}
					} else if (code == Events.OnBlur.getEventCode()) {
						be.stopPropagation();
						if (!ExtendedTextElement.this.isActiveViewMode()) {
							// Focus was lost by TABULATOR
							ExtendedTextElement.this.getContainer()
									.getFocusHandler()
									.releaseFocus(ExtendedTextElement.this);
						}
					}

				}
			};
			DOM.sinkEvents(this.elementContent,
					Events.OnMouseDown.getEventCode());
			DOM.setEventListener(this.elementContent, listener);

		}

		tmpValue = getConfig().getElementOption("label");
		if (tmpValue != null) {
			labelDiv = DOM.createDiv();

			if (labelOnTop) {
				labelDiv.setClassName("extendedTextElement-TextLabel-Top");
			} else {
				labelDiv.setClassName("extendedTextElement-TextLabel-Left");
			}

			labelDiv.setInnerHTML(tmpValue);
			DOM.appendChild(elementContent, labelDiv);
		}

		// TEXT
		textFrameDiv = DOM.createDiv();
		DOM.appendChild(elementContent, textFrameDiv);

		tmpValue = getConfig().getElementOption("texttype");

		if (tmpValue != null && tmpValue.equals("textfield")) {
			// OneRowTextfield
			textField = DOM.createInputText();

			// if(labelOnTop) {
			// textField.setClassName("extendedTextElement-TextField-ViewModeTop");
			// }
			// else {
			textField.setClassName("extendedTextElement-TextField-ViewMode");
			// }



				DOM.appendChild(textFrameDiv, textField);

			if (!readOnly) {
				DOM.sinkEvents(textField, Events.Focus.getEventCode());
				DOM.sinkEvents(textField, Events.Blur.getEventCode());
				DOM.sinkEvents(textField, Events.OnMouseOver.getEventCode());
				DOM.setEventListener(textField, listener);

			}
		} else {
			// TextArea
			textArea = DOM.createTextArea();

			if (labelOnTop) {
				textArea.setClassName("extendedTextElement-TextArea-ViewModeTop");
			} else {
				textArea.setClassName("extendedTextElement-TextArea-ViewMode");
			}

			DOM.appendChild(textFrameDiv, textArea);

			if (!readOnly) {
				DOM.sinkEvents(textArea, Events.Focus.getEventCode());
				DOM.sinkEvents(textArea, Events.Blur.getEventCode());
				DOM.sinkEvents(textArea, Events.OnMouseOver.getEventCode());
				DOM.sinkEvents(textArea, Events.OnClick.getEventCode());
				DOM.setEventListener(textArea, listener);
			}
		}
		setElementSize(new Size(getActualViewModeWidth(),
				getActualViewModeHeight()));
	}

	protected void setElementSize(Size size) {
		int balanceWidth = 4, balanceHeight = 4; // 1px distance to the
													// frameborder, 1 px padding
													// in each direction

		if (textFrameDiv != null) {
			
			DOM.setStyleAttribute(textFrameDiv, "width",
					Math.max(0, size.width - balanceWidth) + "px");
			
			DOM.setStyleAttribute(textFrameDiv, "height",
					Math.max(0, size.height - balanceHeight) + "px");
		}
		if (textArea != null) {
			if (labelOnTop && labelDiv != null) {
				
				DOM.setStyleAttribute(
						textArea,
						"height",
						Math.max(
								0,
								size.height - balanceHeight
										- labelDiv.getOffsetHeight())
								+ "px");
			} else {
				
				DOM.setStyleAttribute(textArea, "height",
						Math.max(0, size.height - balanceHeight) + "px");
			}

			if (labelDiv != null) {
				DOM.setStyleAttribute(
						textArea,
						"width",
						Math.max(
								0,
								size.width - balanceWidth
										- labelDiv.getOffsetWidth())
								+ "px");
			} else {
				DOM.setStyleAttribute(textArea, "width",
						Math.max(0, size.width - balanceWidth) + "px");
			}
		}
		if (textField != null) {
			// if(labelOnTop && labelDiv != null) {
			// DOM.setStyleAttribute(textField,"height",Math.max(0,size.height-balanceHeight-labelDiv.getOffsetHeight())+"px");
			// }
			// else {
		
			DOM.setStyleAttribute(textField, "height",
					Math.max(0, size.height - balanceHeight) + "px");
			// }
			if (labelDiv != null) {
				DOM.setStyleAttribute(
						textField,
						"width",
						Math.max(
								0,
								size.width - balanceWidth
										- labelDiv.getOffsetWidth())
								+ "px");
			} else {
				DOM.setStyleAttribute(textField, "width",
						Math.max(0, size.width - balanceWidth) + "px");
			}
		}
	}

	protected void switchToEditMode(Element contentFrame) {
		if(!readOnly) {
		if (!isBlocked()) {
			buildElement();
			if (!contentFrame.hasChildNodes()) {
				DOM.appendChild(contentFrame, elementContent);
			}

			if (textArea != null) {
				if (labelOnTop) {
					textArea.setClassName("extendedTextElement-TextArea-EditModeTop");
				} else {
					textArea.setClassName("extendedTextElement-TextArea-EditMode");
				}

				textArea.removeAttribute("readonly");
			}
			if (textField != null) {
				// if(labelOnTop) {
				// textField.setClassName("extendedTextElement-TextField-EditModeTop");
				// }
				// else {
				textField
						.setClassName("extendedTextElement-TextField-EditMode");
				// }
				textField.removeAttribute("readonly");
			}
		} else {
			if (DEBUG)
				LASADInfo.display("Error",
						"This element is locked because another user is working on it currently...");
		}
		}
	}

	protected void switchToViewMode(Element contentFrame) {
		buildElement();
		if (!contentFrame.hasChildNodes()) {
			DOM.appendChild(contentFrame, elementContent);
		}
		if (textArea != null) {
			if (labelOnTop) {
				textArea.setClassName("extendedTextElement-TextArea-ViewModeTop");
			} else {
				textArea.setClassName("extendedTextElement-TextArea-ViewMode");
			}
			textArea.setAttribute("readonly", "readonly");
		}
		if (textField != null) {
			// if(labelOnTop) {
			// textField.setClassName("extendedTextElement-TextField-ViewModeTop");
			// }
			// else {
			textField.setClassName("extendedTextElement-TextField-ViewMode");
			// }
			textField.setAttribute("readonly", "readonly");
		}
	}

	protected String getVarValue(String name) {
		if (name.equals("TEXT")) {
			if (textArea != null) {
				return DOM.getElementProperty(this.textArea, "value");
			}
			if (textField != null) {
				return DOM.getElementProperty(this.textField, "value");
			}
		}
		return null;
	}

	protected void setVarValue(String name, String value, String username) {
		if (name.equals("TEXT")) {
			this.checkForHighlight(username);

			if (textArea != null) {
				DOM.setElementProperty(this.textArea, "value", value);
			}
			if (textField != null) {
				DOM.setElementProperty(this.textField, "value", value);
			}
		} else if (name.equalsIgnoreCase("STATUS")) {
			if (value.equalsIgnoreCase("LOCK")) {
				this.setBlocked(true);
			} else if (value.equalsIgnoreCase("UNLOCK")) {
				this.setBlocked(false);
			}
		}
	}

	@Override
	public void setBlocked(boolean blocked) {
		if (DEBUG)
			LASADInfo.display("setBlocked", blocked + "");
		super.setBlocked(blocked);

		if (blocked) {
			if (!ExtendedTextElement.this.isActiveViewMode()) {
				this.setViewMode(true);
			}

			if (textArea != null) {
				if (labelOnTop) {
					textArea.setClassName("extendedTextElement-TextArea-LockedModeTop");
				} else {
					textArea.setClassName("extendedTextElement-TextArea-LockedMode");
				}
				textArea.setAttribute("readonly", "readonly");
			}
			if (textField != null) {
				// if(labelOnTop) {
				// textField.setClassName("extendedTextElement-TextField-LockedModeTop");
				// }
				// else {
				textField
						.setClassName("extendedTextElement-TextField-LockedMode");
				// }
				textField.setAttribute("readonly", "readonly");
			}
			this.setElementFocus(false);
		}

		else {
			if (ExtendedTextElement.this.isActiveViewMode()) {
				if (textArea != null) {
					if (labelOnTop) {
						textArea.setClassName("extendedTextElement-TextArea-ViewModeTop");
					} else {
						textArea.setClassName("extendedTextElement-TextArea-ViewMode");
					}
					textArea.removeAttribute("readonly");
				}
				if (textField != null) {
					// if(labelOnTop) {
					// textField.setClassName("extendedTextElement-TextField-ViewModeTop");
					// }
					// else {
					textField
							.setClassName("extendedTextElement-TextField-ViewMode");
					// }
					textField.removeAttribute("readonly");
				}
			}

			if (wantFocus) {
				if (ExtendedTextElement.this.isActiveViewMode()) {
					// Ask for Focus
					ExtendedTextElement.this.getContainer().getFocusHandler()
							.setFocus(ExtendedTextElement.this);
					wantFocus = false;
				}
			}
		}
	}

	@Override
	public void setElementFocus(boolean focus) {
		super.setElementFocus(focus);
		if (isBlocked() == false) {
			if (focus) {
				if (DEBUG)
					LASADInfo.display("setElementFocus", "LOCK");
				communicator.sendActionPackage(actionBuilder.lockElement(this
						.getConnectedModel().getValue("MAP-ID"), this
						.getConnectedModel().getId()));
			} else {
				if (DEBUG)
					LASADInfo.display("setElementFocus", "UNLOCK");
				communicator.sendActionPackage(actionBuilder.unlockElement(this
						.getConnectedModel().getValue("MAP-ID"), this
						.getConnectedModel().getId()));
			}
		}
	}

	@Override
	protected void setElementHighlight(boolean highlight) {
	}

	@Override
	protected void onEstablishModelConnection() {
	}

	@Override
	protected void onRemoveModelConnection() {
	}
}