package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid;

import java.util.List;

import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.FeedbackAuthoringTabContent;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.ElementModel;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.TestData;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.FeedbackAuthoringStrings;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.window.AgentWindow;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.window.AgentWindowConf;
import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;
import lasad.shared.dfki.meta.agents.ActionAgentConfigData;
import lasad.shared.dfki.meta.agents.SupportedOntologiesDef;

import com.extjs.gxt.ui.client.widget.Info;




public class AgentsGrid extends CustomizedGrid { 
	
	private static AgentsGrid instance = null;
//	private DatabaseFA db;
	private FeedbackAuthoringTabContent faTab;
	
	public static AgentsGrid getInstance(GridConf gridConf, FeedbackAuthoringTabContent faTab) {
		if (instance == null) {
			instance = new AgentsGrid(gridConf, faTab);
		}
		return instance;
	}
	
	private AgentsGrid(GridConf gridConf, FeedbackAuthoringTabContent faTab) {
		super(gridConf);
		this.faTab = faTab;
		this.setHeaderVisible(false);
	    this.setBodyBorder(false);
	}
	
	@Override
	void markReadyElement(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void viewElement(String name) {
		//System.out.println("Button view");
		Info.display("View", name);
		AgentDescriptionFE agent = faTab.getAgentFromDB(name);
		AgentWindow agentAddWin = new AgentWindow(getAgWinConf4ViewAg(), agent, this);
		agentAddWin.show();
		
	}
	private AgentWindowConf getAgWinConf4ViewAg(){
		AgentWindowConf awc = new AgentWindowConf(FeedbackAuthoringStrings.VIEW_AGENT_LABEL,  
												AgentWindow.VIEW_MODE,
												TestData.getOntologiesAsOnt());
		return awc;
	}

	/* 
	 * Edit agent, Agent Window is prompted
	 * Method call when the edit agent button is pressed
	 * (non-Javadoc)
	 * @see lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.CustomizedGrid#editElement(java.lang.String)
	 */
	@Override
	void editElement(String name) {
		 //System.out.println("Button edit");
		 Info.display("Edit", name);
//		 AgentDescriptionFE agent = db.getAgent(name);
		 AgentDescriptionFE agent = faTab.getAgentFromDB(name);
			AgentWindow agentAddWin = new AgentWindow(getAgWinConf4EditAg(), agent, this);
			agentAddWin.show();
	}
	private AgentWindowConf getAgWinConf4EditAg(){
		AgentWindowConf awc = new AgentWindowConf(FeedbackAuthoringStrings.EDIT_AGENT_LABEL,  
												AgentWindow.EDIT_MODE,
												TestData.getOntologiesAsOnt());
		return awc;
	}

	/*
	 * Deletes an agent from the GUI and the DB
	 * Method call when the delete agent button is pressed
	 * (non-Javadoc)
	 * @see lasad.gwt.feedbackauthoringtool.client.grid.CustomizedGrid#deleteElement(java.lang.String)
	 */
	@Override
	void deleteElement(String name) {
		//MessageBox.info("Button click", "delete", null);
		faTab.deleteAgentFromDB(name);
		
		List<String> listOnt = faTab.getOnt4AgentFromDB(name);
		List<String> listSes = faTab.getSes4AgentFromDB(name);
		
		/*
		 * TODO check if this is okay
		 */
		for(String ont:listOnt){
			faTab.deleteAgentFromOntologyDB(ont, name);
		}
		for(String ses:listSes){
			faTab.deleteAgentFromSessionDB(ses, name);
		}
		
		System.out.println("Button delete");
		Info.display("Delete", name);
	}

	/*
	 * Duplicates an agent
	 * Method call when the duplicate agent button is pressed
	 * (non-Javadoc)
	 * @see lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.CustomizedGrid#duplicateElement(java.lang.String)
	 */
	@Override
	void duplicateElement(String name) {
		//MessageBox.info("Button click", "duplicate", null);
		System.out.println("Button duplicate");
		Info.display("Duplicate", name);
	}

	/*
	 * Add agent, , Agent Window is prompted so the user can provide the agent conf
	 * Method call when the add agent button is pressed
	 * (non-Javadoc)
	 * @see lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.CustomizedGrid#addElement()
	 */
	@Override
	void addElement() {
		//MessageBox.info("Button click", "add", null);
		System.out.println("Button add");
		AgentDescriptionFE agent = new AgentDescriptionFE();
		agent.setConfData(new ActionAgentConfigData(null));
		//agent.setAgentConf(new AgentDescriptionFE());
		AgentWindow agentAddWin = new AgentWindow(getAgWinConf4AddAg(), agent, this);
		agentAddWin.show();
	}
	
	/*
	 * Method called from AgentWindow save button
	 */
	public void saveAgent(AgentDescriptionFE agent){
		/*
		 * TODO send message to server to get confirmed that has been saved
		 * validate that information entered by the user is correct
		 */
		String agentId = agent.getAgentID();
    	String agentDisplayname = agent.getDisplayName();
    	SupportedOntologiesDef supportedOnt = agent.getSupportedOntology();
    	String ontology = null;
    	if (supportedOnt != null && supportedOnt.getSupportedOntologies().size() >=1){
    		//TODO validate this asking about multiple support for ontonlogies.
    		supportedOnt.getSupportedOntologies().get(0);
    	}
    	boolean configCompleted = agent.isConfigCompleted();
    	boolean readable = agent.isConfReadable();
    	boolean writeable = agent.isConfWritable();
    	addAgent2Grid(agentId, agentDisplayname, ontology, readable, writeable, configCompleted);
		//Save agent
    	faTab.addAgent2DB(agent);
	}
	
	public void addAgent2Grid(String agentId, String agentDisplayName, String ontology, boolean isRead, boolean isWrite, boolean configCompleted){
		//TODO handle configCompleted
		ElementModel agentStub = new ElementModel();
		agentStub.set("name", agentId);
		StringBuffer status = new StringBuffer(); 
		status.append("(" + ontology +	", ");
		status.append(isRead ? "read":"-");
		status.append(" / ");
		status.append(isWrite ? "write":"-");
		status.append(")");
		agentStub.set("status", status.toString());
		addElement2GridStore(agentStub);
	}
	
	private AgentWindowConf getAgWinConf4AddAg(){
		AgentWindowConf awc = new AgentWindowConf(FeedbackAuthoringStrings.ADD_AGENT_LABEL,  
												AgentWindow.ADD_MODE,
												TestData.getOntologiesAsOnt());
		return awc;
	}

	@Override
	void populateGridForTesting() {
		// TODO Auto-generated method stub
		
	}
	
}
