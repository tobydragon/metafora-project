package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public class AddAgentToOntologyEvent extends OntologyUserActionEventImpl {

	public AddAgentToOntologyEvent(String ontology, String agent) {
		super(ontology, agent);
		// TODO Auto-generated constructor stub
	}
	
}
