package lasad.gwt.client.ui.box.helper;

public interface hasFixedHeightInterface {
	
	public boolean hasFixedHeight();
	public int getMinHeight();
}