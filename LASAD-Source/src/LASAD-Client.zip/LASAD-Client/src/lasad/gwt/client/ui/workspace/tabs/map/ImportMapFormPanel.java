package lasad.gwt.client.ui.workspace.tabs.map;

import lasad.gwt.client.LASAD_Client;
import lasad.gwt.client.communication.LASADActionSender;
import lasad.gwt.client.communication.objects.ActionFactory;
import lasad.gwt.client.communication.objects.ActionPackage;
import lasad.gwt.client.importer.ImportFileChecker;
import lasad.gwt.client.logger.Logger;
import lasad.gwt.client.ui.workspace.LASADInfo;
import lasad.gwt.client.ui.workspace.loaddialogues.ImportingMapDialogue;
import lasad.gwt.client.ui.workspace.loaddialogues.LoadingMapFromFileDialogue;
import lasad.gwt.client.xml.LoadSessionFromXMLFileParser;

import com.extjs.gxt.ui.client.event.ComponentEvent;
import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.event.FormEvent;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.CheckBox;
import com.extjs.gxt.ui.client.widget.form.FileUploadField;
import com.extjs.gxt.ui.client.widget.form.FormPanel;
import com.extjs.gxt.ui.client.widget.form.Radio;
import com.extjs.gxt.ui.client.widget.form.RadioGroup;
import com.extjs.gxt.ui.client.widget.form.TextField;
import com.google.gwt.core.client.GWT;

public class ImportMapFormPanel extends FormPanel {

	private TextField<String> sessionName;
	private FileUploadField file;
	private Radio privateMap, publicMap;
	
	private CheckBox privateMapChk;
	
	public ImportMapFormPanel() {
		super();
		
		setHeading("Import existing map session from local file system");
		setLabelWidth(130);
		
		sessionName = new TextField<String>();
		sessionName.setFieldLabel("Session Name");
		sessionName.setAllowBlank(false);
		sessionName.setMinLength(3);
		sessionName.setEmptyText("Enter name of session that will be created from file");
		
		add(sessionName);
		
		file = new FileUploadField();
		file.setAllowBlank(false);
		file.setName("uploadedfile");
		file.setFieldLabel("File");		
		
		add(file);
		
		privateMapChk = new CheckBox();
		privateMapChk.setFieldLabel("Private session");
		add(privateMapChk);
		
		Button loadMap = new Button("Load") {
			@Override
			protected void onClick(ComponentEvent ce) {
				
				if(sessionName.validate()) {
					if(file.validate()) {
						try {
							ImportMapFormPanel.this.submit();
						}
						catch (Exception e) {
							Logger.log("File upload failed", Logger.DEBUG_ERRORS);
						}
					}
					else {
						LASADInfo.display("Error", "Please choose a file!");
					}
				}
				else {
					LASADInfo.display("Error", "Please specify a name for the new session with at least 3 characters!");
				}
			}
		};

		addListener(Events.Submit, new Listener<FormEvent>() {
            public void handleEvent(FormEvent be) {
				String result = be.getResultHtml();
				
				if (!result.startsWith("<H2>HTTP ERROR: 400</H2><PRE>file type invalid</PRE>") && !result.startsWith("<h2>HTTP ERROR: 400</h2><pre>file type invalid</pre>")) {

					result = result.replaceAll("THISISABRACKETSUBSTITUTE1", "<");
					result = result.replaceAll("THISISABRACKETSUBSTITUTE2", ">");

					// the following if-block is needed because of some
					// compiled-mode problems
					if (result.contains("<pre>")) {
						result = result.replaceAll("<pre>", "");
						result = result.replaceAll("</pre>", "");
					}

					// the following if-block is needed because of some
					// parser problems
					if (result.contains("nbsp")) {
						result = result.replaceAll("&nbsp;", " ");
					}

					String ontology, template, content;

					if (result.startsWith("GML-FILE")) {
						ontology = ImportFileChecker.getArgunautOntologyName();
						template = ImportFileChecker.getArgunautTemplateName();
						ActionPackage p = ActionFactory.getInstance().importAndJoinMap(sessionName.getValue(), ontology, template, result.substring(8));
						LASADActionSender.getInstance().sendActionPackage(p);
						
						ImportingMapDialogue.getInstance().showLoadingScreen();
					}
					else if (result.startsWith("LARGO-FILE")){
						ontology = ImportFileChecker.getLargoOntologyName();

						String[] parts = result.split(";;");
						template = ImportFileChecker.getLargoTemplateName(parts[1]);

						int startIndex = 14 + parts[1].length();

						ActionPackage p = ActionFactory.getInstance().importAndJoinMap(sessionName.getValue(), ontology, template, result.substring(startIndex));
						LASADActionSender.getInstance().sendActionPackage(p);
						
						ImportingMapDialogue.getInstance().showLoadingScreen();
					}
					else {
						ontology = LoadSessionFromXMLFileParser.getOntology(result);
						template = LoadSessionFromXMLFileParser.getTemplate(result);
						content = LoadSessionFromXMLFileParser.getContent(result);
						
						String username = null;
						if(ImportMapFormPanel.this.privateMapChk.getValue()) {
							username = LASAD_Client.getInstance().getUsername();
						}
						LASADActionSender.getInstance().sendActionPackage(ActionFactory.getInstance().loadSessionFromXML(sessionName.getValue(), ontology, template, content, username));
						LoadingMapFromFileDialogue.getInstance().showLoadingScreen();
					}
				}
				else {
					LASADInfo.display("Error", "The file type is invalid.");
				}
            }
        });       
        
		add(loadMap);
		
		

		// set the form to use the POST method, and multipart MIME encoding for file upload
		setEncoding(FormPanel.Encoding.MULTIPART);
		setMethod(FormPanel.Method.POST);
		setAction(GWT.getModuleBaseURL() + "fileupload");
		
		layout();
	}
	
}
