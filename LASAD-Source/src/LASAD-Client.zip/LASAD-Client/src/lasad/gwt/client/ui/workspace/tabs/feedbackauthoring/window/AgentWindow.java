package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.window;

import java.util.List;
import java.util.Vector;

import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.ElementModel;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.AgentsGrid;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.ColumnConf;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.ControlThreadGrid;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.FeedbackGrid;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.GridConf;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.PatternsGrid;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid.RowEditorGrid;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.Data2ModelConverter;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.FATConstants;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.FeedbackAuthoringStrings;
import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;
import lasad.shared.dfki.meta.agents.SupportedOntologiesDef;

import com.extjs.gxt.ui.client.Style.HorizontalAlignment;
import com.extjs.gxt.ui.client.Style.LayoutRegion;
import com.extjs.gxt.ui.client.Style.Orientation;
import com.extjs.gxt.ui.client.Style.Scroll;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.ComponentEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.event.WindowEvent;
import com.extjs.gxt.ui.client.event.WindowListener;
import com.extjs.gxt.ui.client.store.ListStore;
import com.extjs.gxt.ui.client.util.Margins;
import com.extjs.gxt.ui.client.util.Padding;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.Info;
import com.extjs.gxt.ui.client.widget.Label;
import com.extjs.gxt.ui.client.widget.LayoutContainer;
import com.extjs.gxt.ui.client.widget.Slider;
import com.extjs.gxt.ui.client.widget.TabItem;
import com.extjs.gxt.ui.client.widget.TabPanel;
import com.extjs.gxt.ui.client.widget.Window;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.CheckBox;
import com.extjs.gxt.ui.client.widget.form.ComboBox;
import com.extjs.gxt.ui.client.widget.form.ComboBox.TriggerAction;
import com.extjs.gxt.ui.client.widget.form.DualListField;
import com.extjs.gxt.ui.client.widget.form.DualListField.Mode;
import com.extjs.gxt.ui.client.widget.form.FormPanel;
import com.extjs.gxt.ui.client.widget.form.Radio;
import com.extjs.gxt.ui.client.widget.form.RadioGroup;
import com.extjs.gxt.ui.client.widget.form.SliderField;
import com.extjs.gxt.ui.client.widget.form.TextArea;
import com.extjs.gxt.ui.client.widget.form.TextField;
import com.extjs.gxt.ui.client.widget.layout.BorderLayout;
import com.extjs.gxt.ui.client.widget.layout.BorderLayoutData;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.extjs.gxt.ui.client.widget.layout.FormData;
import com.extjs.gxt.ui.client.widget.layout.RowData;
import com.extjs.gxt.ui.client.widget.layout.RowLayout;
import com.extjs.gxt.ui.client.widget.layout.VBoxLayout;
import com.extjs.gxt.ui.client.widget.layout.VBoxLayout.VBoxLayoutAlign;
import com.extjs.gxt.ui.client.widget.layout.VBoxLayoutData;
import com.extjs.gxt.ui.client.widget.toolbar.ToolBar;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.user.client.ui.Widget;



public class AgentWindow{
	public static final int ADD_MODE = 1;
	public static final int EDIT_MODE = 2;
	public static final int VIEW_MODE = 3;
	
//	private DatabaseFA db;
	private final Window window = new Window();
	
	private FormData formData = new FormData("-20"); //100%
	
	private AgentWindowConf awc;
	private AgentDescriptionFE agent;
	private AgentsGrid agGrid;
	
	/*
	 * General Agent Settings
	 */
	//Basic tab
	private TextField<String> agentIdField;
	private ComboBox<ElementModel> supportedOntCombo;
	private TextArea agentDescriptionTA;
	//Phases tab
	
	/*
	 * Patterns
	 */
	//structure (workspace)
	//counter
	private RadioGroup instTypeRestRG;
	private TextField<String> specificTypesField;
	private RadioGroup userRestRG;
	private Label userRestNoteLabel;
	private RadioGroup timeRestRG;
	private TextField<String> timeRestSecsOp2Field;
	private TextField<String> timeRestSecsOp3Field;
	private ComboBox<ElementModel> countCondCombo;
	private TextField<String> countVaueField;
	
	/*
	 * Feedback
	 */
	//Basic
	private TextField<String> feedbackNameField;
	private TextArea feedbackDescriptionTA;
	private ComboBox<ElementModel> feedbackTriggerByCombo = new ComboBox<ElementModel>();
	private Label feedbackBasicNoteLabel;
	//Filter
	private RadioGroup userRestFeedFilterRG;
	private Label userRestFeedFilterNoteLabel;
	private RadioGroup timeRestFeedFilterRG;
	private TextField<String> timeRestSecsOp2FeedFilterField;
	private TextField<String> timeRestSecsOp3FeedFilterField;
	//Content
	private TextField<String> shortMsgContField;
	private TextArea longMsgContTA;
	private RadioGroup highlightingContRG;
	//Priority
	private SliderField prioritySF = null;
	private ComboBox<ElementModel> phaseIdCombo;
	private SliderField phasePrioritySF = null;
	
	/*
	 * Feedback
	 */
	//Basic
	private TextField<String> controlThreadNameField;
	private TextArea controlThreadDescriptionTA;
	private RadioGroup controlThreadProvTimeRG;
	private TextField<String> controlThreadProvTimeDispNameField;
	private TextField<String> controlThreadProvTimeInterField;
	//Messages
	//Sort&Filter
	
	public AgentWindow(AgentWindowConf awc, AgentDescriptionFE agent, AgentsGrid agGrid){
		this.awc = awc;
//		this.db = db;
		this.agent = agent;
		this.agGrid = agGrid;
		initAgentWindow();
	}
	
	public void show(){
		window.show();
	}
	
	private Window initAgentWindow(){
		
		window.setPlain(true);
		window.setModal(true);
		window.setBlinkModal(true);
		window.setSize("90%", "650px");
		window.setMaximizable(true);
		window.setHeading(awc.getTitle());
		
		window.setLayout(new BorderLayout());
		window.add(initAgentConfPanel(), new BorderLayoutData(LayoutRegion.NORTH, (float)0.90));
		window.add(initStatusPanel(), new BorderLayoutData(LayoutRegion.SOUTH, (float)0.10));
		window.addWindowListener(new WindowListener() {  
			@Override
			public void windowHide(WindowEvent we) {
				//Button open = we.getWindow().getData("open");  
				//open.focus();
				if(awc.getMode() == ADD_MODE){
					agGrid.saveAgent(agent);
				}else if(awc.getMode() == EDIT_MODE){
					//TODO what action to take.
					//agGrid.saveAgent(agent);
				}
			}
		});
		window.layout();
		
		Button saveBtn = new Button(FeedbackAuthoringStrings.SAVE_CONFIG_LABEL, new SelectionListener<ButtonEvent>() {  
			@Override  
			public void componentSelected(ButtonEvent ce) {
				//TODO save all the fields
				agent.setAgentID(agentIdField.getValue());
				ElementModel value = (ElementModel) supportedOntCombo.getValue();
				
				List<String> ontList =  new Vector<String>();
				ontList.add((String)value.get("name"));
				SupportedOntologiesDef supportedOnt = new SupportedOntologiesDef(ontList);
				agent.setSupportedOntology(supportedOnt);
				
				agent.setDescription(agentDescriptionTA.getValue());
				
				agent.setConfReadable(true);
				agent.setConfWritable(true);
		    }
		});
		window.addButton(saveBtn);
		if(awc.getMode() == VIEW_MODE){
			saveBtn.setEnabled(false);
		}
		
		window.addButton(new Button(FeedbackAuthoringStrings.CLOSE_LABEL, new SelectionListener<ButtonEvent>() {  
			@Override  
			public void componentSelected(ButtonEvent ce) {  
				window.hide();  
			}  
		}));
		
		return window;
	}
	
	private ContentPanel initStatusPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setBodyBorder(false);
		panel.setHeaderVisible(false);
		
		TextArea statusArea = new TextArea();
		statusArea.setEnabled(false);
		panel.add(statusArea);
		
		return panel;
	}
	
	private ContentPanel initAgentConfPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setBodyBorder(false);
		panel.setHeaderVisible(false);
		
		TabPanel mainTabPanel = new TabPanel();
		mainTabPanel.setSize("100%", "100%");
		mainTabPanel.setMinTabWidth(115);
		mainTabPanel.setTabScroll(true);
		
		//General Tab
		TabItem generalTabItem = new TabItem();
		generalTabItem.setText(FeedbackAuthoringStrings.HEADING_GENERAL);
		generalTabItem.setLayout(new FitLayout()); //always add a layout to the tab item.
		generalTabItem.add(getGeneralTabItemContent());
		generalTabItem.setEnabled(true);
		
		//Patterns Tab
		TabItem patternTabItem = new TabItem();
		patternTabItem.setText(FeedbackAuthoringStrings.HEADING_PATTERNS);
		patternTabItem.setLayout(new FitLayout());
		patternTabItem.add(getPatternsTabItemContent());
		
		//Feedback Tab
		TabItem feedbackTabItem = new TabItem();
		feedbackTabItem.setText(FeedbackAuthoringStrings.HEADING_FEEDBACK);
		feedbackTabItem.setLayout(new FitLayout());
		feedbackTabItem.add(getFeedbackTabItemContent());
		
		//Provision Tab
		TabItem provisionTabItem = new TabItem();
		provisionTabItem.setText(FeedbackAuthoringStrings.HEADING_PROVISION);
		provisionTabItem.setLayout(new FitLayout());
		provisionTabItem.add(getProvisionTabItemContent());
		
		mainTabPanel.add(generalTabItem);
		mainTabPanel.add(patternTabItem);
		mainTabPanel.add(feedbackTabItem);
		mainTabPanel.add(provisionTabItem);
		
		mainTabPanel.setSelection(generalTabItem);
		
		panel.add(mainTabPanel);
		return panel;
	}
	
	private ContentPanel getGeneralTabItemContent(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setHeading(FeedbackAuthoringStrings.HEADING_GENERAL_AGENT_SETTINGS);
		panel.setScrollMode(Scroll.AUTOY);
		panel.add(createGeneralTabInnerTabPanel());
		
		return panel;
	}
	
	private Widget createGeneralTabInnerTabPanel(){
		
		TabPanel innerTabPanel = new TabPanel();
		innerTabPanel.setSize("100%", "100%");
		innerTabPanel.setMinTabWidth(115);
		innerTabPanel.setTabScroll(true);
		innerTabPanel.setStyleName("faSubTab");

		TabItem basicTabItem = new TabItem();
		basicTabItem.setText(FeedbackAuthoringStrings.HEADING_BASIC);
		basicTabItem.setLayout(new FitLayout());
		basicTabItem.add(getGeneralBasicTabContent());
		
		TabItem phasesTabItem = new TabItem();
		phasesTabItem.setText(FeedbackAuthoringStrings.HEADING_PHASES);
		phasesTabItem.setLayout(new FitLayout());
		phasesTabItem.add(getGeneralPhaseTabContent());
		
		TabItem propsTabItem = new TabItem();
		propsTabItem.setText("Properties");
		propsTabItem.setLayout(new FitLayout());
		propsTabItem.add(getPropsTabContent());
		
		innerTabPanel.add(phasesTabItem);
		innerTabPanel.add(basicTabItem);
		innerTabPanel.add(propsTabItem);
		
		innerTabPanel.setSelection(propsTabItem);
		
		return innerTabPanel;
	}
	
	private Widget getPropsTabContent(){
		ContentPanel panel = new ContentPanel(new FitLayout());//ColumnLayout()
		panel.setHeaderVisible(false);
		panel.setBodyBorder(true);
		panel.setHeight("100%");
		panel.setFrame(true);
		
//		panel.setLayout(new ColumnLayout()); //new RowLayout(Orientation.HORIZONTAL)
//		panel.setLayout(new RowLayout(Orientation.HORIZONTAL));
		
//		ColumnData cd = new ColumnData();
//		cd.setWidth(0.5);
//		panel.add(initTestLeftPanel(), cd);
		panel.add(initTestLeftPanelContent());  //,cd
//		panel.add(initTestLeftPanelContent(), cd);
//		panel.add(initTestLeftPanelContent(), new RowData(0.5, 1.0, new Margins(5)));
//		panel.add(initTestLeftPanelContent(), new RowData(0.5, 1.0, new Margins(5)));
		
		panel.layout();
		return initTestLeftPanelContent();

	}
	
	private ContentPanel initTestLeftPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setHeaderVisible(false);
		panel.add(initTestLeftPanelContent());
		return panel;
	}
	
	private Widget initTestLeftPanelContent() {
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setHeaderVisible(false);
		panel.setBodyBorder(true);
//		panel.setSize("100%", "600px");
		panel.setFrame(true);
		panel.setScrollMode(Scroll.AUTOY);
		
		
		LayoutContainer c = new LayoutContainer();  
        VBoxLayout layout = new VBoxLayout();  
        layout.setPadding(new Padding(5));  
        layout.setVBoxLayoutAlign(VBoxLayoutAlign.STRETCH);  
        c.setLayout(layout);
        c.setScrollMode(Scroll.AUTOY);
        c.setHeight("500px");
  
        VBoxLayoutData flex = new VBoxLayoutData(new Margins(0, 0, 5, 0));  
        flex.setFlex(1);
        
		
		
//		ContentPanel p1 = new ContentPanel(new FitLayout());
//		p1.add(getTestPanelText());
//		ContentPanel p2 = new ContentPanel(new FitLayout());
//		p2.add(getTestPanelText());
//		ContentPanel p3 = new ContentPanel(new FitLayout());
//		p3.add(getTestPanelText());
//		
//		panel.add(getTestPanelText(), new RowData(1.0, 0.34, new Margins(3)));
//		panel.add(getTestPanelText(), new RowData(1.0, 0.33, new Margins(3)));
//		panel.add(getTestPanelText(), new RowData(1.0, 0.33, new Margins(3)));
		
//		panel.add(new ContentPanel(new FitLayout()), new RowData(1.0, 0.34, new Margins(3)));
//		panel.add(new ContentPanel(new FitLayout()), new RowData(1.0, 0.33, new Margins(3)));
//		panel.add(new ContentPanel(new FitLayout()), new RowData(1.0, 0.33, new Margins(3)));
		
		
		GridConf gridConf = new GridConf();
		gridConf.setHeader("type");
		gridConf.setAddButtonFlag(true);
		gridConf.setDeleteButtonFlag(true);
		gridConf.setCommonLabel("constraint");
		ColumnConf colTmp = new ColumnConf("name", "Name", 100);
		colTmp.setType(FATConstants.TEXT_TYPE);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("status", "Status", 100);
		colTmp.setType(FATConstants.TEXT_TYPE);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("actions", "Actions", 50);
		gridConf.addColConfig(colTmp);
		RowEditorGrid gridType = new RowEditorGrid(gridConf);
		
		gridConf = new GridConf();
		gridConf.setHeader("creator");
		gridConf.setAddButtonFlag(true);
		gridConf.setDeleteButtonFlag(true);
		gridConf.setCommonLabel("constraint");
		colTmp = new ColumnConf("name", "Name", 100);
		colTmp.setType(FATConstants.TEXT_TYPE);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("status", "Status", 100);
		colTmp.setType(FATConstants.TEXT_TYPE);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("actions", "Actions", 50);
		gridConf.addColConfig(colTmp);
		RowEditorGrid gridCreator = new RowEditorGrid(gridConf);
		
		gridConf = new GridConf();
		gridConf.setHeader("modifiers");
		gridConf.setAddButtonFlag(true);
		gridConf.setDeleteButtonFlag(true);
		gridConf.setCommonLabel("constraint");
		colTmp = new ColumnConf("name", "Name", 100);
		colTmp.setType(FATConstants.TEXT_TYPE);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("status", "Status", 100);
		colTmp.setType(FATConstants.TEXT_TYPE);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("actions", "Actions", 50);
		gridConf.addColConfig(colTmp);
		RowEditorGrid gridModifiers = new RowEditorGrid(gridConf);
		
		gridConf = new GridConf();
		gridConf.setHeader("something");
		gridConf.setAddButtonFlag(true);
		gridConf.setDeleteButtonFlag(true);
		gridConf.setCommonLabel("constraint");
		colTmp = new ColumnConf("name", "Name", 100);
		colTmp.setType(FATConstants.TEXT_TYPE);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("status", "Status", 100);
		colTmp.setType(FATConstants.TEXT_TYPE);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("actions", "Actions", 50);
		gridConf.addColConfig(colTmp);
		RowEditorGrid gridSomething = new RowEditorGrid(gridConf);
		
		RowEditorGrid gridSomething2 = new RowEditorGrid(gridConf);
		
		c.add(gridType.createGridPanel(), flex);  
        c.add(gridCreator.createGridPanel(), flex);  
        c.add(gridModifiers.createGridPanel(), flex);
        c.add(gridSomething.createGridPanel(), flex);
        c.add(gridSomething2.createGridPanel(), flex);
        
        panel.add(c);
		
		return panel;
	}
	
	private Widget getGeneralBasicTabContent(){
		
		ContentPanel panel = new ContentPanel();
		panel.setHeaderVisible(false);
		panel.setBodyBorder(false);
		
		FormPanel formPanel = new FormPanel();
		formPanel.setHeaderVisible(false);
		formPanel.setBodyBorder(false);
		formPanel.setWidth(450);
		
		agentIdField = new TextField<String>();
		agentIdField.setFieldLabel(FeedbackAuthoringStrings.AGENT_ID_LABEL);
		agentIdField.setAllowBlank(false);
		if(awc.getMode() != ADD_MODE){
			agentIdField.setValue(agent.getAgentID());
		}
		if(awc.getMode() == VIEW_MODE){
			agentIdField.setReadOnly(true);
		}
	    formPanel.add(agentIdField, formData);
	    
	    ListStore<ElementModel> ontologies = new ListStore<ElementModel>();
//	    ElementModel anyOnt = new ElementModel(FeedbackAuthoringStrings.ANY_LABEL, null);
//	    ontologies.add(anyOnt);
	    ontologies.add(Data2ModelConverter.getOntAsModel(awc.getOntologyList()));  
	  
	    supportedOntCombo = new ComboBox<ElementModel>();
	    supportedOntCombo.setFieldLabel(FeedbackAuthoringStrings.SUPPORTED_ONTOLOGY_LABEL);
	    //comboSupportedOnto.setEmptyText("...");
	    supportedOntCombo.setDisplayField("name");  
	    supportedOntCombo.setWidth(150);  
	    supportedOntCombo.setStore(ontologies);  
	    supportedOntCombo.setTypeAhead(true);  
	    supportedOntCombo.setTriggerAction(TriggerAction.ALL);
	    //comboSupportedOnto.select(0); //selecting any by default
	    if(ontologies.getCount() > 0)
	    	supportedOntCombo.setValue(ontologies.getAt(0));
	    
	    if(awc.getMode() != ADD_MODE){
	    	SupportedOntologiesDef supportedOnt = agent.getSupportedOntology();
	    	String ontology = null;
	    	if (supportedOnt != null && supportedOnt.getSupportedOntologies().size() >=1){
	    		//TODO validate this asking about multiple support for ontonlogies.
	    		supportedOnt.getSupportedOntologies().get(0);
	    	}
	    	ElementModel value = new ElementModel(ontology, null);
	    	supportedOntCombo.setValue(value);
		}
	    if(awc.getMode() == VIEW_MODE){
	    	supportedOntCombo.setReadOnly(true);
		}
	    formPanel.add(supportedOntCombo, formData);
	    
	    agentDescriptionTA = new TextArea();  
	    agentDescriptionTA.setPreventScrollbars(true);  
	    agentDescriptionTA.setFieldLabel(FeedbackAuthoringStrings.DESCRIPTION_LABEL);
	    agentDescriptionTA.setOriginalValue("");
	    if(awc.getMode() != ADD_MODE){
	    	if(agent != null)
	    		agentDescriptionTA.setValue(agent.getDescription());
		}
	    if(awc.getMode() == VIEW_MODE){
	    	agentDescriptionTA.setReadOnly(true);
		}
	    formPanel.add(agentDescriptionTA, formData);
	    
	    panel.add(formPanel);
		
		return panel;
	}
	
	private Widget getGeneralPhaseTabContent(){
		
//		ContentPanel tpanel = new ContentPanel();
//		tpanel.setHeaderVisible(false);
//		tpanel.setBodyBorder(false);
		
		GridConf gridConf = new GridConf();
		gridConf.setHeader(FeedbackAuthoringStrings.HEADING_ANALYSIS_PHASES);
		gridConf.setAddButtonFlag(true);
		gridConf.setDeleteButtonFlag(true);
		gridConf.setCommonLabel(FeedbackAuthoringStrings.PHASE2_LABEL);
		
		ColumnConf colTmp = new ColumnConf("name", "Name", 150);
		colTmp.setType(FATConstants.TEXT_TYPE);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("status", "Status", 200);
		colTmp.setType(FATConstants.TEXT_TYPE);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("actions", "Actions", 50);
		gridConf.addColConfig(colTmp);
		
		RowEditorGrid phases = new RowEditorGrid(gridConf);
		//phases.setSize(500, 400);
		
		
		return phases.createGridPanel();
	}
	
	private ContentPanel getPatternsTabItemContent(){
		ContentPanel panel = new ContentPanel();
		panel.setHeaderVisible(false);
		panel.setBodyBorder(false);
		panel.setLayout(new RowLayout(Orientation.VERTICAL));
		panel.add(createPatternsTopPanel(), new RowData(1.0, 0.35, new Margins(3)));
		panel.add(createPatternsBottomPanel(), new RowData(1.0, 0.65, new Margins(3)));
		
		return panel;
	}
	
	private Widget createPatternsTopPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setHeaderVisible(false);
		panel.setBodyBorder(false);
		panel.setWidth("100%");
		panel.setHeight("100%");
		panel.setLayout(new RowLayout(Orientation.HORIZONTAL));
		panel.add(createPatternsTopLeftPanel(), new RowData(0.65, 1.0, new Margins(1)));
		panel.add(createPatternsTopRightPanel(), new RowData(0.35, 1.0, new Margins(1)));
		return panel;
	}
	
	private Widget createPatternsBottomPanel(){
		ContentPanel panel = new ContentPanel();
		panel.setHeaderVisible(false);
		panel.setBodyBorder(false);
		panel.setWidth("100%");
		panel.setHeight("100%");
		panel.setLayout(new RowLayout(Orientation.VERTICAL));
		panel.add(createPatternsBottomPatStructPanel(), new RowData(1.0, 1.00, new Margins(1)));
		//panel.add(createPatternsBottomPatCountPanel(), new RowData(1.0, 0.50, new Margins(1)));
		return panel;
		
		
//		ContentPanel panel = new ContentPanel();
//		panel.setLayout(new FitLayout());
//		panel.setHeaderVisible(true);
//		panel.setHeading(FeedbackAuthoringStrings.HEADING_SELECTED_PATERN);
//		panel.setBodyBorder(false);
//		
//		FormPanel fPanel = new FormPanel();
//		fPanel.setHeaderVisible(false);
//		fPanel.setBodyBorder(false);
//		fPanel.setWidth("100%");
//		fPanel.add(new Label(FeedbackAuthoringStrings.HEADING_EXPERT), formData);
//	    panel.add(fPanel);
//		return panel;
	}
	
	private Widget createPatternsBottomPatStructPanel(){
		//here we need to specify code to draw the boxes
		//use code already available in LASAD-Client
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setHeaderVisible(true);
		panel.setHeading(FeedbackAuthoringStrings.HEADING_PATERN_STRUCTURE);
		panel.setBodyBorder(false);
		
		FormPanel fPanel = new FormPanel();
		fPanel.setHeaderVisible(false);
		fPanel.setBodyBorder(false);
		fPanel.setWidth("100%");
		fPanel.setHeight("100%");
		fPanel.add(new Label("Workspace to draw patterns goes here :-)"), formData);
	    panel.add(fPanel);
		
		return panel;
	}
	
	private Widget createPatternsBottomPatCountPanel(){
		
		ContentPanel panel = new ContentPanel();
		panel.setHeaderVisible(true);
		panel.setHeading(FeedbackAuthoringStrings.HEADING_PATERN_COUNTER);
		panel.setBodyBorder(false);
		panel.setLayout(new FitLayout());
		panel.setScrollMode(Scroll.AUTOY);
		
		//"Instance type restrictions
		FormPanel instTypeRestPanel = new FormPanel();
		//instTypeRestPanel.setHeaderVisible(false);
		instTypeRestPanel.setHeading(FeedbackAuthoringStrings.INSTANCE_TYPE_RESTRICTIONS_HEADER);
		instTypeRestPanel.setBodyBorder(true);
		instTypeRestPanel.setWidth(500);
		
		Radio gralInstClassR1 = new Radio();  
	    gralInstClassR1.setBoxLabel(FeedbackAuthoringStrings.BOX_LABEL);
	    gralInstClassR1.setValue(true);
	    Radio gralInstClassR2 = new Radio();
	    gralInstClassR2.setBoxLabel(FeedbackAuthoringStrings.LINK_LABEL);
	    Radio gralInstClassR3 = new Radio();
	    gralInstClassR3.setBoxLabel(FeedbackAuthoringStrings.BOX_OR_LINK_LABEL);
	    Radio gralInstClassR4 = new Radio();
	    gralInstClassR4.setBoxLabel(FeedbackAuthoringStrings.PATTERN_LABEL);
	    instTypeRestRG = new RadioGroup();
	    instTypeRestRG.setFieldLabel(FeedbackAuthoringStrings.GENERAL_INSTANCE_CLASS_LABEL);
	    instTypeRestRG.add(gralInstClassR1);
	    instTypeRestRG.add(gralInstClassR2);
	    instTypeRestRG.add(gralInstClassR3);
	    instTypeRestRG.add(gralInstClassR4);
	    instTypeRestRG.setOrientation(Orientation.VERTICAL);
	    instTypeRestPanel.add(instTypeRestRG, formData);
	    
	    specificTypesField = new TextField<String>();
	    specificTypesField.setFieldLabel(FeedbackAuthoringStrings.SPECIFIC_TYPES_LABEL);
	    specificTypesField.setAllowBlank(false);
	    instTypeRestPanel.add(specificTypesField, formData);
	    panel.add(instTypeRestPanel);
	    
	    //User restrictions
	    FormPanel userRestPanel = new FormPanel();
		//panel.setHeaderVisible(false);
		userRestPanel.setHeading(FeedbackAuthoringStrings.USER_RESTRICTIONS_HEADER);
		userRestPanel.setBodyBorder(true);
		userRestPanel.setWidth(600);
		
		userRestNoteLabel = new Label(FeedbackAuthoringStrings.PAT_USER_REST_INFO_LABEL);
		Button userRestHelpButton = new Button(){
			@Override
			protected void onClick(ComponentEvent ce) {
				System.out.println(FeedbackAuthoringStrings.HELP_LABEL);
				Info.display(FeedbackAuthoringStrings.HELP_LABEL, FeedbackAuthoringStrings.PAT_USER_REST_HELP_LABEL);
			}
		};
		userRestHelpButton.setToolTip(FeedbackAuthoringStrings.HELP_LABEL);
		userRestHelpButton.setIconStyle("icon-question");
		Button userRestOpt2HelpButton = new Button(){
			@Override
			protected void onClick(ComponentEvent ce) {
				System.out.println(FeedbackAuthoringStrings.HELP_LABEL);
				Info.display(FeedbackAuthoringStrings.HELP_LABEL, FeedbackAuthoringStrings.PAT_USER_REST_OPT2_HELP_LABEL);
				
			}
		};
		userRestOpt2HelpButton.setToolTip(FeedbackAuthoringStrings.HELP_LABEL);
		userRestOpt2HelpButton.setIconStyle("icon-question");
		
		Radio userRestR1 = new Radio();  
		userRestR1.setBoxLabel(FeedbackAuthoringStrings.PAT_USER_REST_OPT1_LABEL);
		userRestR1.setValue(true);
	    Radio userRestR2 = new Radio();
	    userRestR2.setBoxLabel(FeedbackAuthoringStrings.PAT_USER_REST_OPT2_LABEL);
	    Radio userRestR3 = new Radio();
	    userRestR3.setBoxLabel(FeedbackAuthoringStrings.PAT_USER_REST_OPT3_LABEL);
	    Radio userRestR4 = new Radio();
	    userRestR4.setBoxLabel(FeedbackAuthoringStrings.PAT_USER_REST_OPT4_LABEL);
	    userRestRG = new RadioGroup();
	    //userRestRG.setFieldLabel(FeedbackAuthoringStrings.GENERAL_INSTANCE_CLASS_LABEL);
	    userRestRG.add(userRestR1);
	    userRestRG.add(userRestR2);
	    userRestRG.add(userRestR3);
	    userRestRG.add(userRestR4);
	    userRestRG.setOrientation(Orientation.VERTICAL);
	    userRestRG.setLabelSeparator("");
	    userRestPanel.add(userRestRG, formData);
	    userRestPanel.add(userRestNoteLabel, formData);
	    userRestPanel.add(userRestHelpButton, formData);
	    userRestPanel.add(userRestOpt2HelpButton, formData);
	    
//	    specificTypesField = new TextField<String>();
//	    specificTypesField.setFieldLabel(FeedbackAuthoringStrings.SPECIFIC_TYPES_LABEL);
//	    specificTypesField.setAllowBlank(false);
//	    userRestPanel.add(specificTypesField, formData);
	    panel.add(userRestPanel);
	    
	    //Time restrictions
	    FormPanel timeRestPanel = new FormPanel();
	    timeRestPanel.setHeading(FeedbackAuthoringStrings.TIME_REST_HEADER);
	    timeRestPanel.setBodyBorder(true);
	    timeRestPanel.setWidth(500);
		
		Radio timeRestR1 = new Radio();  
		timeRestR1.setBoxLabel(FeedbackAuthoringStrings.PAT_TIME_REST_OPT1_LABEL);
		timeRestR1.setValue(true);
	    Radio timeRestR2 = new Radio();
	    timeRestR2.setBoxLabel(FeedbackAuthoringStrings.PAT_TIME_REST_OPT2_1_LABEL);
	    Radio timeRestR3 = new Radio();
	    timeRestR3.setBoxLabel(FeedbackAuthoringStrings.PAT_TIME_REST_OPT3_1_LABEL);
	    timeRestRG = new RadioGroup();
	    //timeRestRG.setFieldLabel(FeedbackAuthoringStrings.GENERAL_INSTANCE_CLASS_LABEL);
	    timeRestRG.add(timeRestR1);
	    timeRestRG.add(timeRestR2);
	    timeRestRG.add(timeRestR3);
	    timeRestRG.setOrientation(Orientation.VERTICAL);
	    timeRestRG.setLabelSeparator("");
	    timeRestPanel.add(timeRestRG, formData);
	    
	    timeRestSecsOp2Field = new TextField<String>();
	    timeRestSecsOp2Field.setFieldLabel(FeedbackAuthoringStrings.PAT_TIME_REST_OPT2_2_LABEL);
	    timeRestSecsOp2Field.setAllowBlank(false);
	    timeRestPanel.add(timeRestSecsOp2Field, formData);
	    timeRestSecsOp3Field = new TextField<String>();
	    timeRestSecsOp3Field.setFieldLabel(FeedbackAuthoringStrings.PAT_TIME_REST_OPT3_2_LABEL);
	    timeRestSecsOp3Field.setAllowBlank(false);
	    timeRestPanel.add(timeRestSecsOp3Field, formData);
	    panel.add(timeRestPanel);
	    
	    //Count condition
	    FormPanel countCondPanel = new FormPanel();
	    countCondPanel.setHeading(FeedbackAuthoringStrings.COUNT_CONDITION_HEADER);
	    countCondPanel.setBodyBorder(true);
	    countCondPanel.setWidth(500);
	    
	    ListStore<ElementModel> countCondStore = new ListStore<ElementModel>();
//	    ElementModel anyOnt = new ElementModel(FeedbackAuthoringStrings.ANY_LABEL, null);
//	    ontologies.add(anyOnt);
	    countCondStore.add(Data2ModelConverter.getOntAsModel(awc.getOntologyList()));  

	    countCondCombo = new ComboBox<ElementModel>();
	    countCondCombo.setFieldLabel(FeedbackAuthoringStrings.COUNT_LABEL);
	    //comboSupportedOnto.setEmptyText("...");
	    countCondCombo.setDisplayField("countCondCombo");  
	    countCondCombo.setWidth(150);  
	    countCondCombo.setStore(countCondStore);  
	    countCondCombo.setTypeAhead(true);  
	    countCondCombo.setTriggerAction(TriggerAction.ALL);
	    countCondCombo.setWidth("100px");
	    //comboSupportedOnto.select(0); //selecting any by default
	    if(countCondStore.getCount() > 0)
	    	countCondCombo.setValue(countCondStore.getAt(0));
	    
	    countCondPanel.add(countCondCombo, formData);
	    countVaueField = new TextField<String>();
	    //countVaueField.setFieldLabel(FeedbackAuthoringStrings.SPECIFIC_TYPES_LABEL);
	    countVaueField.setLabelSeparator("");
	    countVaueField.setAllowBlank(false);
	    countVaueField.setWidth("30px");
	    countCondPanel.add(countVaueField, formData);
	    panel.add(countCondPanel);
	    
		
		return panel;
	}

	
	private Widget createPatternsTopLeftPanel(){
		
		ContentPanel panel;
		GridConf gridConf = new GridConf();
		
		gridConf.setHeader(FeedbackAuthoringStrings.HEADING_PATTERN_DB);
		gridConf.setAddButtonFlag(true);
		//gridConf.setViewButtonFlag(true);
		gridConf.setEditButtonFlag(true);
		gridConf.setDeleteButtonFlag(true);
		gridConf.setDuplicateButtonFlag(true);
		gridConf.setCommonLabel(" "+FeedbackAuthoringStrings.PATTERN_LABEL);
		
		ColumnConf colTmp = new ColumnConf("name", "Name", 140);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("status", "Type", 120);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("id", "Info", 120);
		gridConf.addColConfig(colTmp);

		colTmp = new ColumnConf("actions", "Actions", 150);
		gridConf.addColConfig(colTmp);
		
		panel = PatternsGrid.getInstance(gridConf, agent);
		
		return panel;
	}
	
	private Widget createPatternsTopRightPanel(){
		
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setHeaderVisible(true);
		panel.setHeading(FeedbackAuthoringStrings.HEADING_SELECTED_PATERN);
		panel.setBodyBorder(true);
		
		TabPanel innerTabPanel = new TabPanel();
		innerTabPanel.setSize("100%", "100%");
		innerTabPanel.setMinTabWidth(115);
		innerTabPanel.setTabScroll(true);
		innerTabPanel.setStyleName("faSubTab");		

		TabItem basicTabItem = new TabItem();
		basicTabItem.setText(FeedbackAuthoringStrings.HEADING_BASIC);
		basicTabItem.setLayout(new FitLayout());
		basicTabItem.add(createPatternsTopRightBasicPanel());
		
		TabItem phasesTabItem = new TabItem();
		phasesTabItem.setText(FeedbackAuthoringStrings.HEADING_EXPERT);
		phasesTabItem.setLayout(new FitLayout());
		phasesTabItem.add(createPatternsTopRightExpertPanel());
		
		innerTabPanel.add(phasesTabItem);
		innerTabPanel.add(basicTabItem);
		
		innerTabPanel.setSelection(basicTabItem);
		panel.add(innerTabPanel);
		
		return panel;
	}
	
	private Widget createPatternsTopRightBasicPanel(){
		
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setHeaderVisible(false);
		panel.setBodyBorder(false);
		
		FormPanel formPanel = new FormPanel();
		formPanel.setHeaderVisible(false);
		formPanel.setBodyBorder(false);
		formPanel.setWidth("100%");
		
		TextField<String> patternIdField = new TextField<String>();
		patternIdField.setFieldLabel(FeedbackAuthoringStrings.NAME_LABEL);
		//patternIdField.setAllowBlank(false);
	    formPanel.add(patternIdField, formData);
	    
	    TextArea patternDescription = new TextArea();  
	    patternDescription.setPreventScrollbars(true);  
	    patternDescription.setFieldLabel(FeedbackAuthoringStrings.DESCRIPTION_LABEL);
	    patternDescription.setOriginalValue("");
	    patternDescription.setDeferHeight(true);
	    formPanel.add(patternDescription, formData);
	    
	    panel.add(formPanel);
		
		return panel;
	}
	
	private Widget createPatternsTopRightExpertPanel(){
		
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setHeaderVisible(false);
		panel.setBodyBorder(false);
		
		FormPanel fPanel = new FormPanel();
		fPanel.setHeaderVisible(false);
		fPanel.setBodyBorder(false);
		fPanel.setWidth("100%");
		
	    fPanel.add(new Label(FeedbackAuthoringStrings.HEADING_EXPERT), formData);
	    panel.add(fPanel);
		
		return panel;
	}
	
	private ContentPanel getFeedbackTabItemContent(){
		ContentPanel panel = new ContentPanel();
		panel.setHeaderVisible(false);
		panel.setBodyBorder(false);
		panel.setLayout(new RowLayout(Orientation.VERTICAL));
		panel.add(createFeedbackTopPanel(), new RowData(1.0, 0.35, new Margins(3)));
		panel.add(createFeedbackBottomPanel(FATConstants.PATTERN_PANEL), new RowData(1.0, 0.65, new Margins(3)));
		
		return panel;
	}
	
	private Widget createFeedbackTopPanel(){
		ContentPanel panel;
		GridConf gridConf = new GridConf();
		
		gridConf.setHeader(FeedbackAuthoringStrings.FEEDBACK_DB_HEADING);
		gridConf.setAddButtonFlag(true);
		//gridConf.setViewButtonFlag(true);
		gridConf.setEditButtonFlag(true);
		gridConf.setDeleteButtonFlag(true);
		gridConf.setDuplicateButtonFlag(true);
		gridConf.setCommonLabel(" " + FeedbackAuthoringStrings.FEEDBACK_LABEL);
		
		ColumnConf colTmp = new ColumnConf("name", "Name", 160);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("type", "Type", 150);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("info", "Info", 200);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("actions", "Actions", 150);
		gridConf.addColConfig(colTmp);
		
		panel = FeedbackGrid.getInstance(gridConf, agent);
		
		return panel;
	}
	
	private Widget createFeedbackBottomPanel(int panelType){
		return createFeedbackBottomPanel();
//		switch(panelType){
//			case FATConstants.PATTERN_PANEL:{
//				return createFeedbackPatternBottomPanel();
//			}
//			case FATConstants.RULE_PANEL:{
//				return createFeedbackFilterBottomPanel();
//			}
//			default:
//				assert false;
//				return null;
//		}
		
	}
	
	private Widget createFeedbackBottomPanel(){
		
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setHeaderVisible(true);
		panel.setHeading(FeedbackAuthoringStrings.FEEDBACK_STD_MSG_HEADING);
		panel.setBodyBorder(true);
		
		TabPanel innerTabPanel = new TabPanel();
		innerTabPanel.setSize("100%", "100%");
		innerTabPanel.setMinTabWidth(115);
		innerTabPanel.setTabScroll(true);
		innerTabPanel.setStyleName("faSubTab");		

		TabItem basicTabItem = new TabItem();
		basicTabItem.setText(FeedbackAuthoringStrings.HEADING_BASIC);
		basicTabItem.setLayout(new FitLayout());
		basicTabItem.add(createFeedbackBottomBasicPanel());
		
		TabItem filterTabItem = new TabItem();
		filterTabItem.setText(FeedbackAuthoringStrings.HEADING_FILTER);
		filterTabItem.setLayout(new FitLayout());
		filterTabItem.add(createFeedbackBottomFilterPanel());
		
		TabItem messageTabItem = new TabItem();
		messageTabItem.setText(FeedbackAuthoringStrings.HEADING_CONTENT);
		messageTabItem.setLayout(new FitLayout());
		messageTabItem.add(createFeedbackBottomContentPanel());
		
		TabItem phasesTabItem = new TabItem();
		phasesTabItem.setText(FeedbackAuthoringStrings.HEADING_PRIORITY);
		phasesTabItem.setLayout(new FitLayout());
		phasesTabItem.add(createFeedbackBottomPriorityPanel());
		
		innerTabPanel.add(phasesTabItem);
		innerTabPanel.add(messageTabItem);
		innerTabPanel.add(filterTabItem);
		innerTabPanel.add(basicTabItem);
		
		innerTabPanel.setSelection(basicTabItem); //TODO check if this is required
		panel.add(innerTabPanel);
		
		return panel;
	}
	
	private Widget createFeedbackBottomBasicPanel(){
		
		ContentPanel tpanel = new ContentPanel();
		tpanel.setHeaderVisible(false);
		tpanel.setBodyBorder(false);
		tpanel.setScrollMode(Scroll.AUTOY);
		
		FormPanel formPanel = new FormPanel();
		formPanel.setHeaderVisible(false);
		formPanel.setBodyBorder(false);
		formPanel.setWidth(450);
		
		feedbackNameField = new TextField<String>();
		feedbackNameField.setFieldLabel(FeedbackAuthoringStrings.NAME_LABEL);
		feedbackNameField.setWidth(50);
		feedbackNameField.setAllowBlank(false);
		if(awc.getMode() != ADD_MODE){
//			feedbackNameField.setValue(agent.getRuleName());
		}
		if(awc.getMode() == VIEW_MODE){
			feedbackNameField.setReadOnly(true);
		}
	    formPanel.add(feedbackNameField, formData);
	    
//	    ruleDisplayNameField = new TextField<String>();
//		ruleDisplayNameField.setFieldLabel(FeedbackAuthoringStrings.DISPLAY_NAME_LABEL);
//		ruleDisplayNameField.setAllowBlank(false);
//		if(awc.getMode() != ADD_MODE){
////			ruleDisplayNameField.setValue(agent.getRuleDisplayName());
//		}
//		if(awc.getMode() == VIEW_MODE){
//			ruleDisplayNameField.setReadOnly(true);
//		}
//	    panel.add(ruleDisplayNameField, formData);
	    
	    feedbackDescriptionTA = new TextArea();  
	    feedbackDescriptionTA.setPreventScrollbars(true);  
	    feedbackDescriptionTA.setFieldLabel(FeedbackAuthoringStrings.DESCRIPTION_LABEL);
	    feedbackDescriptionTA.setOriginalValue("");
	    if(awc.getMode() != ADD_MODE){
//	    	feedbackDescriptionTA.setValue(agent.getRuleDescription());
		}
	    if(awc.getMode() == VIEW_MODE){
	    	feedbackDescriptionTA.setReadOnly(true);
		}
	    formPanel.add(feedbackDescriptionTA, formData);
	    
	    ListStore<ElementModel> feedbackTriggerByStore = new ListStore<ElementModel>();
//	    ElementModel anyOnt = new ElementModel(FeedbackAuthoringStrings.ANY_LABEL, null);
//	    patterns.add(anyOnt);
//	    patterns.add(Data2ModelConverter.getOntAsModel(awc.getOntologyList()));  
	  
	    Button feedbackTriggedHelpButton = new Button(){
			@Override
			protected void onClick(ComponentEvent ce) {
				System.out.println(FeedbackAuthoringStrings.HELP_LABEL);
				Info.display(FeedbackAuthoringStrings.HELP_LABEL, FeedbackAuthoringStrings.FEEDBACK_BASIC_TRIGGERED_HELP_LABEL);
			}
		};
		feedbackTriggedHelpButton.setToolTip(FeedbackAuthoringStrings.HELP_LABEL);
		feedbackTriggedHelpButton.setIconStyle("icon-question");
	    
	    feedbackTriggerByCombo = new ComboBox<ElementModel>();
	    feedbackTriggerByCombo.setFieldLabel(FeedbackAuthoringStrings.TRIGGER_BY_LABEL);
	    //feedbackTriggerByCombo.setEmptyText("...");
	    feedbackTriggerByCombo.setDisplayField(FeedbackAuthoringStrings.SELECT_LABEL);  
	    feedbackTriggerByCombo.setWidth(150);  
	    feedbackTriggerByCombo.setStore(feedbackTriggerByStore);  
	    feedbackTriggerByCombo.setTypeAhead(true);  
	    feedbackTriggerByCombo.setTriggerAction(TriggerAction.ALL);
	    feedbackTriggerByCombo.setAutoWidth(true);
//	    feedbackTriggerByCombo.setValue(anyOnt);
	    if(awc.getMode() != ADD_MODE){
//	    	ElementModel value = new ElementModel(agent.getRulePattern(), null);
//	    	feedbackTriggerByCombo.setValue(value);
		}
	    if(awc.getMode() == VIEW_MODE){
	    	feedbackTriggerByCombo.setReadOnly(true);
		}
	    formPanel.add(feedbackTriggedHelpButton, formData);
	    formPanel.add(feedbackTriggerByCombo, formData);
	    
	    feedbackBasicNoteLabel  = new Label(FeedbackAuthoringStrings.FEEDBACK_BASIC_INFO_LABEL);
	    formPanel.add(feedbackBasicNoteLabel, formData);
	    
	    Button feedbackNoteHelpButton = new Button(){
			@Override
			protected void onClick(ComponentEvent ce) {
				System.out.println(FeedbackAuthoringStrings.HELP_LABEL);
				Info.display(FeedbackAuthoringStrings.HELP_LABEL, FeedbackAuthoringStrings.FEEDBACK_BASIC_INFO_HELP_LABEL);
			}
		};
		feedbackNoteHelpButton.setToolTip(FeedbackAuthoringStrings.HELP_LABEL);
		feedbackNoteHelpButton.setIconStyle("icon-question");
		formPanel.add(feedbackNoteHelpButton, formData);
	    
	    tpanel.add(formPanel);
		
		return tpanel;
	}
	
	private Widget createFeedbackBottomFilterPanel(){
		ContentPanel tpanel = new ContentPanel();
		tpanel.setHeaderVisible(false);
		tpanel.setBodyBorder(false);
		tpanel.setScrollMode(Scroll.AUTOY);
		
//		FormPanel formPanel = new FormPanel();
//		formPanel.setHeaderVisible(false);
//		formPanel.setBodyBorder(false);
//		formPanel.setWidth(500);
		
		//User restrictions
	    FormPanel userRestPanel = new FormPanel();
		//panel.setHeaderVisible(false);
		userRestPanel.setHeading(FeedbackAuthoringStrings.USER_RESTRICTIONS_HEADER);
		userRestPanel.setBodyBorder(true);
		userRestPanel.setWidth(450);
		
		userRestFeedFilterNoteLabel = new Label(FeedbackAuthoringStrings.FEEDBACK_FILTER_USER_REST_INFO_LABEL);
		Button userRestHelpButton = new Button(){
			@Override
			protected void onClick(ComponentEvent ce) {
				System.out.println(FeedbackAuthoringStrings.HELP_LABEL);
				Info.display(FeedbackAuthoringStrings.HELP_LABEL, FeedbackAuthoringStrings.FEEDBACK_FILTER_USER_REST_HELP_LABEL);
			}
		};
		userRestHelpButton.setToolTip(FeedbackAuthoringStrings.HELP_LABEL);
		userRestHelpButton.setIconStyle("icon-question");
		Button userRestOpt2HelpButton = new Button(){
			@Override
			protected void onClick(ComponentEvent ce) {
				System.out.println(FeedbackAuthoringStrings.HELP_LABEL);
				Info.display(FeedbackAuthoringStrings.HELP_LABEL, FeedbackAuthoringStrings.FEEDBACK_FILTER_USER_REST_OPT2_HELP_LABEL);
				
			}
		};
		userRestOpt2HelpButton.setToolTip(FeedbackAuthoringStrings.HELP_LABEL);
		userRestOpt2HelpButton.setIconStyle("icon-question");
		
		Radio userRestR1 = new Radio();  
		userRestR1.setBoxLabel(FeedbackAuthoringStrings.FEEDBACK_FILTER_USER_REST_OPT1_LABEL);
		userRestR1.setValue(true);
	    Radio userRestR2 = new Radio();
	    userRestR2.setBoxLabel(FeedbackAuthoringStrings.FEEDBACK_FILTER_USER_REST_OPT2_LABEL);
	    Radio userRestR3 = new Radio();
	    userRestR3.setBoxLabel(FeedbackAuthoringStrings.FEEDBACK_FILTER_USER_REST_OPT3_LABEL);
	    Radio userRestR4 = new Radio();
	    userRestR4.setBoxLabel(FeedbackAuthoringStrings.FEEDBACK_FILTER_USER_REST_OPT4_LABEL);
	    userRestFeedFilterRG = new RadioGroup();
	    //userRestFeedFilterRG.setFieldLabel(FeedbackAuthoringStrings.GENERAL_INSTANCE_CLASS_LABEL);
	    userRestFeedFilterRG.add(userRestR1);
	    userRestFeedFilterRG.add(userRestR2);
	    userRestFeedFilterRG.add(userRestR3);
	    userRestFeedFilterRG.add(userRestR4);
	    userRestFeedFilterRG.setOrientation(Orientation.VERTICAL);
	    userRestPanel.add(userRestFeedFilterRG, formData);
	    userRestPanel.add(userRestFeedFilterNoteLabel, formData);
	    userRestPanel.add(userRestHelpButton, formData);
	    userRestPanel.add(userRestOpt2HelpButton, formData);
	    tpanel.add(userRestPanel);
	    
	    //Time restrictions
	    FormPanel timeRestPanel = new FormPanel();
	    timeRestPanel.setHeading(FeedbackAuthoringStrings.TIME_REST_HEADER);
	    timeRestPanel.setBodyBorder(true);
	    timeRestPanel.setWidth(450);
		
		Radio timeRestR1 = new Radio();  
		timeRestR1.setBoxLabel(FeedbackAuthoringStrings.FEEDBACK_FILTER_TIME_REST_OPT1_LABEL);
		timeRestR1.setValue(true);
	    Radio timeRestR2 = new Radio();
	    timeRestR2.setBoxLabel(FeedbackAuthoringStrings.FEEDBACK_FILTER_TIME_REST_OPT2_1_LABEL);
	    Radio timeRestR3 = new Radio();
	    timeRestR3.setBoxLabel(FeedbackAuthoringStrings.FEEDBACK_FILTER_TIME_REST_OPT3_1_LABEL);
	    timeRestFeedFilterRG = new RadioGroup();
	    //timeRestFeedFilterRG.setFieldLabel(FeedbackAuthoringStrings.GENERAL_INSTANCE_CLASS_LABEL);
	    timeRestFeedFilterRG.add(timeRestR1);
	    timeRestFeedFilterRG.add(timeRestR2);
	    timeRestFeedFilterRG.add(timeRestR3);
	    timeRestFeedFilterRG.setOrientation(Orientation.VERTICAL);
	    timeRestPanel.add(timeRestFeedFilterRG, formData);
	    
	    timeRestSecsOp2FeedFilterField = new TextField<String>();
	    timeRestSecsOp2FeedFilterField.setFieldLabel(FeedbackAuthoringStrings.FEEDBACK_FILTER_TIME_REST_OPT2_2_LABEL);
	    timeRestSecsOp2FeedFilterField.setAllowBlank(false);
	    timeRestPanel.add(timeRestSecsOp2FeedFilterField, formData);
	    timeRestSecsOp3FeedFilterField = new TextField<String>();
	    timeRestSecsOp3FeedFilterField.setFieldLabel(FeedbackAuthoringStrings.FEEDBACK_FILTER_TIME_REST_OPT3_2_LABEL);
	    timeRestSecsOp3FeedFilterField.setAllowBlank(false);
	    timeRestPanel.add(timeRestSecsOp3FeedFilterField, formData);
	    tpanel.add(timeRestPanel);
		
		tpanel.add(userRestPanel);
		tpanel.add(timeRestPanel);
		
		return tpanel;
	}
	
	private Widget createFeedbackBottomContentPanel(){
		
		ContentPanel tpanel = new ContentPanel();
		tpanel.setHeaderVisible(false);
		tpanel.setBodyBorder(false);
		tpanel.setScrollMode(Scroll.AUTOY);
		
		FormPanel formPanel = new FormPanel();
		formPanel.setHeaderVisible(false);
		formPanel.setBodyBorder(false);
		formPanel.setWidth(450);
		
		shortMsgContField = new TextField<String>();
		shortMsgContField.setFieldLabel(FeedbackAuthoringStrings.SHORT_MESSAGE_LABEL);
		shortMsgContField.setWidth(50);
		shortMsgContField.setAllowBlank(false);
		if(awc.getMode() != ADD_MODE){
			//shortMsgContField.setValue(agent.getRuleName());
		}
		if(awc.getMode() == VIEW_MODE){
			shortMsgContField.setReadOnly(true);
		}
	    formPanel.add(shortMsgContField, formData);
	    
	    longMsgContTA = new TextArea();  
	    longMsgContTA.setPreventScrollbars(false);  
	    longMsgContTA.setFieldLabel(FeedbackAuthoringStrings.LONG_MESSAGE_LABEL);
	    longMsgContTA.setOriginalValue("");
	    if(awc.getMode() != ADD_MODE){
	    	//longMsgContTA.setValue(agent.getRuleDescription());
		}
	    if(awc.getMode() == VIEW_MODE){
	    	longMsgContTA.setReadOnly(true);
		}
	    formPanel.add(longMsgContTA, formData);
	    
	    Radio highlightingR1 = new Radio();  
	    highlightingR1.setBoxLabel(FeedbackAuthoringStrings.YES_LABEL);
	    highlightingR1.setValue(true);
	    Radio highlightingR2 = new Radio();
	    highlightingR2.setBoxLabel(FeedbackAuthoringStrings.NO_LABEL);
	    highlightingContRG = new RadioGroup();
	    highlightingContRG.setFieldLabel(FeedbackAuthoringStrings.HIGHLIGHTING_IMPACT_LABEL);
	    highlightingContRG.add(highlightingR1);
	    highlightingContRG.add(highlightingR2);
	    formPanel.add(highlightingContRG, formData);
	    
	    tpanel.add(formPanel);
		
		return tpanel;
	}
	
	private Widget createFeedbackBottomPriorityPanel(){
		ContentPanel tpanel = new ContentPanel();
		tpanel.setHeaderVisible(false);
		tpanel.setBodyBorder(false);
		tpanel.setScrollMode(Scroll.AUTOY);
		
		FormPanel defSetFormPanel = new FormPanel();
		defSetFormPanel.setHeaderVisible(false);
		defSetFormPanel.setBodyBorder(true);
		defSetFormPanel.setWidth(450);
		
		ToolBar toolBar = new ToolBar();
		toolBar.setAlignment(HorizontalAlignment.LEFT);
		Label titleLabel = new Label(FeedbackAuthoringStrings.DEFAULT_SETTING_LABEL);
		toolBar.add(titleLabel);
		defSetFormPanel.setTopComponent(toolBar);
		
		Slider prioritySlider = new Slider();
	    prioritySlider.setMinValue(FATConstants.SLIDER_MIN_VAL);
	    prioritySlider.setMaxValue(FATConstants.SLIDER_MAX_VAL);
	    prioritySlider.setValue(FATConstants.SLIDER_DEFAULT_VAL);
	    prioritySlider.setIncrement(FATConstants.SLIDER_INC_VAL);
	    prioritySlider.setMessage(FeedbackAuthoringStrings.HEADING_PRIORITY + " {0}");
	    
	    prioritySF = new SliderField(prioritySlider);
	    prioritySF.setFieldLabel(FeedbackAuthoringStrings.HEADING_PRIORITY);
		defSetFormPanel.add(prioritySF, formData);
		tpanel.add(defSetFormPanel);
		
				
		FormPanel phaseSpecificFormPanel = new FormPanel();
		phaseSpecificFormPanel.setHeaderVisible(false);
		phaseSpecificFormPanel.setBodyBorder(true);
		phaseSpecificFormPanel.setWidth(450);
		
		ToolBar toolBar2 = new ToolBar();
		toolBar2.setAlignment(HorizontalAlignment.LEFT);
		Label titleLabel2 = new Label(FeedbackAuthoringStrings.PHASE_SPECIFIC_SET_LABEL);
		toolBar2.add(titleLabel2);
		phaseSpecificFormPanel.setTopComponent(toolBar2);
		
		ListStore<ElementModel> phaseStore = new ListStore<ElementModel>();
//	    ElementModel anyOnt = new ElementModel(FeedbackAuthoringStrings.ANY_LABEL, null);
//	    patterns.add(anyOnt);
//	    patterns.add(Data2ModelConverter.getOntAsModel(awc.getOntologyList()));  
	  
		phaseIdCombo = new ComboBox<ElementModel>();
		phaseIdCombo.setFieldLabel(FeedbackAuthoringStrings.PHASE_ID_LABEL);
	    //phaseIdCombosetEmptyText("...");
		phaseIdCombo.setDisplayField("name");
		phaseIdCombo.setStore(phaseStore);  
		phaseIdCombo.setTypeAhead(true);  
		phaseIdCombo.setTriggerAction(TriggerAction.ALL);
	    phaseIdCombo.setAutoWidth(true);
//	    ruphaseIdCombo.setValue(anyOnt);
	    if(awc.getMode() != ADD_MODE){
	    	//ElementModel value = new ElementModel(agent.getRulePattern(), null);
	    	//phaseIdCombo.setValue(value);
		}
	    if(awc.getMode() == VIEW_MODE){
	    	phaseIdCombo.setReadOnly(true);
		}
	    phaseSpecificFormPanel.add(phaseIdCombo, formData);
		
		Slider phasePrioritySlider = new Slider();
		phasePrioritySlider.setMinValue(FATConstants.SLIDER_MIN_VAL);
		phasePrioritySlider.setMaxValue(FATConstants.SLIDER_MAX_VAL);
		phasePrioritySlider.setValue(FATConstants.SLIDER_DEFAULT_VAL);
		phasePrioritySlider.setIncrement(FATConstants.SLIDER_INC_VAL);
		phasePrioritySlider.setMessage(FeedbackAuthoringStrings.HEADING_PRIORITY + " {0}");
	    
		phasePrioritySF = new SliderField(phasePrioritySlider);
		phasePrioritySF.setFieldLabel(FeedbackAuthoringStrings.HEADING_PRIORITY);
		phaseSpecificFormPanel.add(phasePrioritySF, formData);
		tpanel.add(phaseSpecificFormPanel);
		
		return tpanel;
	}
	
//	private Widget createFeedbackFilterBottomPanel(){
//		
//		ContentPanel panel = new ContentPanel();
//		panel.setLayout(new FitLayout());
//		panel.setHeaderVisible(true);
//		panel.setHeading(FeedbackAuthoringStrings.HEADING_FILTER_RULE);
//		panel.setBodyBorder(true);
//		
//		TabPanel innerTabPanel = new TabPanel();
//		innerTabPanel.setSize("100%", "100%");
//		innerTabPanel.setMinTabWidth(115);
//		innerTabPanel.setTabScroll(true);
//		innerTabPanel.setStyleName("faSubTab");		
//
//		TabItem basicTabItem = new TabItem();
//		basicTabItem.setText(FeedbackAuthoringStrings.HEADING_BASIC);
//		basicTabItem.setLayout(new FitLayout());
////		basicTabItem.add(createRulesBottomFilterBasicPanel());
//		
//		TabItem componentsTabItem = new TabItem();
//		componentsTabItem.setText(FeedbackAuthoringStrings.HEADING_COMPONENTS);
//		componentsTabItem.setLayout(new FitLayout());
////		componentsTabItem.add(createRulesBottomFilterComponentsPanel());
//		
//		TabItem priorityTabItem = new TabItem();
//		priorityTabItem.setText(FeedbackAuthoringStrings.HEADING_PRIORITY);
//		priorityTabItem.setLayout(new FitLayout());
////		priorityTabItem.add(createRulesBottomFilterPriority());
//		
//		innerTabPanel.add(priorityTabItem);
//		innerTabPanel.add(componentsTabItem);
//		innerTabPanel.add(basicTabItem);
//		
//		innerTabPanel.setSelection(basicTabItem); //TODO check if this is required
//		panel.add(innerTabPanel);
//		
//		return panel;
//	}
	
	private ContentPanel getProvisionTabItemContent(){
		ContentPanel panel = new ContentPanel();
		panel.setHeaderVisible(false);
		panel.setBodyBorder(false);
		panel.setLayout(new RowLayout(Orientation.VERTICAL));
		panel.add(createProvisionTopPanel(), new RowData(1.0, 0.35, new Margins(3)));
		panel.add(createProvisionBottomPanel(FATConstants.PATTERN_PANEL), new RowData(1.0, 0.65, new Margins(3)));
		
		return panel;
	}
	
	private Widget createProvisionTopPanel(){
		ContentPanel panel;
		GridConf gridConf = new GridConf();
		
		gridConf.setHeader(FeedbackAuthoringStrings.CONTROL_THREAD_DB_HEADING);
		gridConf.setAddButtonFlag(true);
		//gridConf.setViewButtonFlag(true);
		gridConf.setEditButtonFlag(true);
		gridConf.setDeleteButtonFlag(true);
		gridConf.setDuplicateButtonFlag(true);
		gridConf.setCommonLabel(" " + FeedbackAuthoringStrings.CONTROL_THREAD_LABEL);
		
		ColumnConf colTmp = new ColumnConf("name", "Name", 160);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("type", "Type", 150);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("info", "Info", 200);
		gridConf.addColConfig(colTmp);
		colTmp = new ColumnConf("actions", "Actions", 150);
		gridConf.addColConfig(colTmp);
		
		panel = ControlThreadGrid.getInstance(gridConf, agent);
		
		return panel;
	}
	
	
	private Widget createProvisionBottomPanel(int panelType){
		return createProvisionBottomPanel();
//		switch(panelType){
//			case FATConstants.GROUP_THREAD:{
//				return createProvisionGroupThreadBottomPanel();
//			}
//			case FATConstants.USER_THREAD:{ 
//				return createProvisionUserThreadBottomPanel();
//			}
//			default:
//				assert false;
//				return null;
//		}
		
	}

	private Widget createProvisionBottomPanel(){
		
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setHeaderVisible(true);
		String headerTitle = FeedbackAuthoringStrings.CONTROL_THREAD_LABEL 
							+ " (" + FeedbackAuthoringStrings.GROUP_THREAD_LABEL + ")";
		panel.setHeading(headerTitle);
		panel.setBodyBorder(true);
		
		TabPanel innerTabPanel = new TabPanel();
		innerTabPanel.setSize("100%", "100%");
		innerTabPanel.setMinTabWidth(115);
		innerTabPanel.setTabScroll(true);
		innerTabPanel.setStyleName("faSubTab");		

		TabItem basicTabItem = new TabItem();
		basicTabItem.setText(FeedbackAuthoringStrings.HEADING_BASIC);
		basicTabItem.setLayout(new FitLayout());
		basicTabItem.add(createProvisionBottomBasicPanel());
		
		TabItem messagesTabItem = new TabItem();
		messagesTabItem.setText(FeedbackAuthoringStrings.MESSAGES_HEADING);
		messagesTabItem.setLayout(new FitLayout());
		messagesTabItem.add(createProvisionBottomMessagesPanel());
		
		TabItem sortAndFilterTabItem = new TabItem();
		sortAndFilterTabItem.setText(FeedbackAuthoringStrings.SORT_AND_FILTER_HEADING);
		sortAndFilterTabItem.setLayout(new FitLayout());
		sortAndFilterTabItem.add(createProvisionBottomSortAndFilterPanel());
		
		innerTabPanel.add(sortAndFilterTabItem);
		innerTabPanel.add(messagesTabItem);
		innerTabPanel.add(basicTabItem);
		
		innerTabPanel.setSelection(basicTabItem); //TODO check if this is required
		panel.add(innerTabPanel);
		
		return panel;
	}
	
	private Widget createProvisionBottomBasicPanel(){
		
		ContentPanel tpanel = new ContentPanel();
		tpanel.setHeaderVisible(false);
		tpanel.setBodyBorder(false);
		tpanel.setScrollMode(Scroll.AUTOY);
		
		FormPanel formPanel = new FormPanel();
		formPanel.setHeaderVisible(false);
		formPanel.setBodyBorder(false);
		formPanel.setWidth(450);
		
		controlThreadNameField = new TextField<String>();
		controlThreadNameField.setFieldLabel(FeedbackAuthoringStrings.NAME_LABEL);
		controlThreadNameField.setWidth(50);
		controlThreadNameField.setAllowBlank(false);
		if(awc.getMode() != ADD_MODE){
			//controlThreadNameField.setValue(agent.getRuleName());
		}
		if(awc.getMode() == VIEW_MODE){
			controlThreadNameField.setReadOnly(true);
		}
	    formPanel.add(controlThreadNameField, formData);
	    
	    controlThreadDescriptionTA = new TextArea();  
	    controlThreadDescriptionTA.setPreventScrollbars(false);  
	    controlThreadDescriptionTA.setFieldLabel(FeedbackAuthoringStrings.DESCRIPTION_LABEL);
	    controlThreadDescriptionTA.setOriginalValue("");
	    if(awc.getMode() != ADD_MODE){
	    	//controlThreadDescriptionTA.setValue(agent.getRuleDescription());
		}
	    if(awc.getMode() == VIEW_MODE){
	    	controlThreadDescriptionTA.setReadOnly(true);
		}
	    formPanel.add(controlThreadDescriptionTA, formData);
	    
	    Radio provTimeR1 = new Radio();  
	    provTimeR1.setBoxLabel(FeedbackAuthoringStrings.PROVISION_TIME_OPT1_LABEL);
	    provTimeR1.setValue(true);
	    Radio provtimeR2 = new Radio();
	    provtimeR2.setBoxLabel(FeedbackAuthoringStrings.PROVISION_TIME_OPT2_LABEL);
	    controlThreadProvTimeRG = new RadioGroup();
	    controlThreadProvTimeRG.setFieldLabel(FeedbackAuthoringStrings.PROVISION_TIME_LABEL);
	    controlThreadProvTimeRG.add(provTimeR1);
	    controlThreadProvTimeRG.add(provtimeR2);
	    formPanel.add(controlThreadProvTimeRG, formData);
	    
	    controlThreadProvTimeDispNameField = new TextField<String>();
	    controlThreadProvTimeDispNameField.setFieldLabel(FeedbackAuthoringStrings.DISPLAY_NAME_LABEL);
	    controlThreadProvTimeDispNameField.setAllowBlank(false);
	    formPanel.add(controlThreadProvTimeDispNameField, formData);
	    controlThreadProvTimeInterField = new TextField<String>();
	    controlThreadProvTimeInterField.setFieldLabel(FeedbackAuthoringStrings.CHECK_INTER_EVERY_LABEL);
	    controlThreadProvTimeInterField.setAllowBlank(false);
	    controlThreadProvTimeInterField.setValue("0");
	    formPanel.add(controlThreadProvTimeInterField, formData);
	    
	    tpanel.add(formPanel);
		
		return tpanel;
	}
	
	private Widget createProvisionBottomMessagesPanel(){
		
		ContentPanel tpanel = new ContentPanel();
		tpanel.setHeaderVisible(false);
		tpanel.setBodyBorder(false);
		tpanel.setScrollMode(Scroll.AUTOY);
		
		FormPanel formPanel = new FormPanel();
		formPanel.setHeaderVisible(false);
		formPanel.setBodyBorder(false);
		formPanel.setWidth(450);
		
		Label availMsgTypesLabel  = new Label(FeedbackAuthoringStrings.AVAILABLE_MSG_TYPES_LABEL);
	    formPanel.add(availMsgTypesLabel, formData);
	    Label selMsgTypesLabel  = new Label(FeedbackAuthoringStrings.SELECTED_MSG_TYPES_LABEL);
	    formPanel.add(selMsgTypesLabel, formData);
		
		ListStore<ElementModel> leftStore = new ListStore<ElementModel>();
		ListStore<ElementModel> rightStore = new ListStore<ElementModel>();
		
		DualListField<ElementModel> messageDualList = new DualListField<ElementModel>();
		messageDualList.setMode(Mode.INSERT);
		
	    formPanel.add(messageDualList, formData);
	    
	    tpanel.add(formPanel);
		
		return tpanel;
	}
	
	private Widget createProvisionBottomSortAndFilterPanel(){
		
		ContentPanel tpanel = new ContentPanel();
		tpanel.setHeaderVisible(false);
		tpanel.setBodyBorder(false);
		tpanel.setScrollMode(Scroll.AUTOY);
		
		FormPanel formPanel = new FormPanel();
		formPanel.setHeaderVisible(false);
		formPanel.setBodyBorder(false);
		formPanel.setWidth(600);
		
		FormPanel sortMsgsFormPanel = new FormPanel();
		sortMsgsFormPanel.setHeading(FeedbackAuthoringStrings.SORT_MSGS_LABEL);
		sortMsgsFormPanel.setBodyBorder(true);
		sortMsgsFormPanel.setWidth(600);
		
		Label availSortCritLabel  = new Label(FeedbackAuthoringStrings.AVAILABLE_SORT_CRIT_LABEL);
		sortMsgsFormPanel.add(availSortCritLabel, formData);
	    Label selSortCritLabel  = new Label(FeedbackAuthoringStrings.SELECTED_SORT_CRIT_LABEL);
	    sortMsgsFormPanel.add(selSortCritLabel, formData);
	    Button selSortCritHelpButton = new Button(){
			@Override
			protected void onClick(ComponentEvent ce) {
				System.out.println(FeedbackAuthoringStrings.HELP_LABEL);
				Info.display(FeedbackAuthoringStrings.HELP_LABEL, FeedbackAuthoringStrings.SELECTED_SORT_CRIT_HELP_LABEL);
				
			}
		};
		selSortCritHelpButton.setToolTip(FeedbackAuthoringStrings.HELP_LABEL);
		selSortCritHelpButton.setIconStyle("icon-question");
		sortMsgsFormPanel.add(selSortCritHelpButton, formData);
	    
		DualListField<ElementModel> sortCriteriaDualList = new DualListField<ElementModel>();
		sortCriteriaDualList.setMode(Mode.INSERT);
		sortMsgsFormPanel.add(sortCriteriaDualList, formData);
		
		
		FormPanel filterMsgsFormPanel = new FormPanel();
		filterMsgsFormPanel.setHeading(FeedbackAuthoringStrings.FILTER_MSGS_LABEL);
		filterMsgsFormPanel.setBodyBorder(true);
		filterMsgsFormPanel.setWidth(600);
		
		ValueChangeHandler<Boolean> filterMsgOptHandler = new ValueChangeHandler<Boolean>() {
			@Override
			public void onValueChange(ValueChangeEvent<Boolean> event) {
				CheckBox check = (CheckBox)event.getSource();
				Info.display("Music Changed", check.getBoxLabel() + " " + (event.getValue() ? "selected" : "not selected"));
			}
		};
		 
		CheckBox filterMsgOpt1CB = new CheckBox();
		filterMsgOpt1CB.setBoxLabel(FeedbackAuthoringStrings.FILTER_MSGS_OPT1_LABEL);
//		filterMsgOpt1CB.addValueChangeHandler(filterMsgOptHandler);
		CheckBox filterMsgOpt2CB = new CheckBox();
		filterMsgOpt2CB.setBoxLabel(FeedbackAuthoringStrings.FILTER_MSGS_OPT2_LABEL);
//		filterMsgOpt2CB.addValueChangeHandler(filterMsgOptHandler);
		CheckBox filterMsgOpt3CB = new CheckBox();
		filterMsgOpt3CB.setBoxLabel(FeedbackAuthoringStrings.FILTER_MSGS_OPT3_LABEL);
//		filterMsgOpt3CB.addValueChangeHandle(filterMsgOptHandler);
	    
		filterMsgsFormPanel.add(filterMsgOpt1CB, formData);
		filterMsgsFormPanel.add(filterMsgOpt2CB, formData);
		filterMsgsFormPanel.add(filterMsgOpt3CB, formData);
		
	    tpanel.add(formPanel);
		
		return tpanel;
	}
	
	
	private Widget getTestPanelText(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new RowLayout(Orientation.VERTICAL));
		//panel.setHeaderVisible(false);
		panel.setBodyBorder(true);
//		panel.setHeight("100%");
//		panel.setSize("100%", "100%");
		
		panel.setFrame(true);
		panel.setScrollMode(Scroll.AUTO);
		
		panel.setHeading("SubTabPanelText");
		panel.setLayout(new FitLayout());
		panel.addText("For the imeasure elearning application, I needed an abstract list of search results. "
				+"Abstract in the way that the search results did not link to a specific item, they did not even "
				+"have a title or any metadata assigned. the only relevant property was wether an item was considered "
				+"relevant or not-relevant. As a first version, I created a grid with only one column, with the "
				+"text relevant or not relevant. To add some visual aid, relevant items had a green font-color, "
				+"irrelevant items were red.");
		return panel;
	}

}
