package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public class AddAgentToSessionEvent extends SessionUserActionEventImpl {

	public AddAgentToSessionEvent(String session, String agent) {
		super(session, agent);
		// TODO Auto-generated constructor stub
	}

	
}
