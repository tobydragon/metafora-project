package lasad.gwt.client.ui.common.elements;

import lasad.gwt.client.LASAD_Client;
import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.ui.common.ExtendedElement;
import lasad.gwt.client.ui.common.ExtendedElementContainerInterface;

import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.util.Size;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;

public class ExtendedFrameElement extends ExtendedElement {

	String link = "http://web-expresser.appspot.com/?userKey=x5Spdu9XABVAVTSKxzQl67&thumbnail=64";
	private EventListener myOnloadEventListener = null;
	
	public ExtendedFrameElement(ExtendedElementContainerInterface container, ElementInfo config) {
		super(container, config);

		// Set possible Element Vars
		// Only this Elements would be updates to the model
		this.elementVars.add("LINK");
		this.setVarValue("LINK", link, LASAD_Client.getInstance().getUsername());
	}

	Element elementContent = null;

	protected void buildElement() {
		if (elementContent != null) {
			// Already built
			return;
		}

		elementContent = DOM.createIFrame();
		elementContent.setClassName("extendedFrameElement");
		
		elementContent.setPropertyString("src", link);
		
		createOnloadListener(elementContent);

		setElementSize(new Size(getActualViewModeWidth(), getActualViewModeHeight()));
	}

	protected void setElementSize(Size size) {
		int balanceWidth = 4, balanceHeight = 4; // 1px distance to the frameborder, 1 px padding in each direction
		if (elementContent!= null ){
			DOM.setStyleAttribute(elementContent, "width", Math.max(0, size.width - balanceWidth) + "px");
			DOM.setStyleAttribute(elementContent, "height", Math.max(0, size.height - balanceHeight) + "px");
		}
	}

	protected void switchToEditMode(Element contentFrame) {
		buildElement();
		if (contentFrame != null){
			if (elementContent != null && !contentFrame.hasChildNodes()) {
				DOM.appendChild(contentFrame, elementContent);
			}
		}
	}

	protected void switchToViewMode(Element contentFrame) {
		buildElement();
		if (contentFrame != null){
			if (elementContent != null && contentFrame.hasChildNodes()) {
				DOM.appendChild(contentFrame, elementContent);
			}
		}
	}

	protected String getVarValue(String name) {
		if (name.equals("LINK")) {
			return link;
		}
		return null;
	}

	protected void setVarValue(String name, String value, String username) {
		this.checkForHighlight(username);

		if (name.equals("LINK")) {
			if (value.startsWith("http://") || value.startsWith("HTTP://")) {
				if (elementContent != null) {
					link = value;
					elementContent.setPropertyString("src", value);
				}
			} 
		}
	}
	
	public void createOnloadListener(Element content) {
		this.myOnloadEventListener = new EventListener() {
			public void onBrowserEvent(Event be) {
				if (be.getTypeInt() == Events.OnLoad.getEventCode()) {
					System.out.println("[onBrowserEvent] loaded");
					if (ExtendedFrameElement.this.isActiveViewMode()) {
						System.out.println("[onBrowserEvent] active Mode");
						elementContent.setPropertyString("src", link);
						setElementSize(new Size(getActualViewModeWidth(), getActualViewModeHeight()));
					}
				}

				be.stopPropagation();
			}
		};

		DOM.sinkEvents(content, Events.OnLoad.getEventCode());
		DOM.setEventListener(content, myOnloadEventListener);

	}

	@Override
	protected void setElementHighlight(boolean highlight) {
	}

	@Override
	protected void onEstablishModelConnection() {
	}

	@Override
	protected void onRemoveModelConnection() {
	}
}