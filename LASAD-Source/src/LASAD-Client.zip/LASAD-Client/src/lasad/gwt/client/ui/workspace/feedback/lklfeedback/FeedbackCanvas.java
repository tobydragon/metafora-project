/**
 *
 */
package lasad.gwt.client.ui.workspace.feedback.lklfeedback;


import com.google.gwt.canvas.client.Canvas;
import com.google.gwt.canvas.dom.client.Context2d;
import com.google.gwt.canvas.dom.client.CssColor;
import com.google.gwt.canvas.dom.client.FillStrokeStyle;
import com.google.gwt.user.client.ui.Widget;

/**
 * The canvas where call outs are drawn
 *
 * @author Ken Kahn
 *
 */
public class FeedbackCanvas {
   
    private static final CssColor MASK_COLOR = createColor(64, 64, 255, 0.5);
    private static final FillStrokeStyle ARROW_COLOR = createColor(255, 64, 64, 1);
    private double arrowStrokeThickness = 4.0; // the JFT default
    private Context2d context;
    private Canvas canvas;
   
    public FeedbackCanvas(Canvas canvas) {
        if (canvas != null) {
            this.context = canvas.getContext2d();
        }
        this.canvas = canvas;
    }

    /**
     * Draws an arrow from source to target.
     * It draws uses the centers of the sides of the bounding boxes of the widgets
     *
     * @param source -- the widget where the arrow originates
     * @param target -- the widget where the arrow terminates
     */
    public void drawArrow(Widget source, Widget target) {
        if (context == null) {
            // TODO: support older browsers somehow
            return;
        }
        int startX = source.getAbsoluteLeft();
        int startY = source.getAbsoluteTop();  
        int endX = target.getAbsoluteLeft();
        int endY = target.getAbsoluteTop();
        int sourceWidth = source.getOffsetWidth();
        boolean startOnRight = startX < endX;
        if (startOnRight) {
            // use right side of source instead
            startX += sourceWidth;
        }
        int sourceHeight = source.getOffsetHeight();
        boolean startOnBottom = startY < endY;
        if (startOnBottom) {
            // use bottom of source instead
            startY += sourceHeight;
        }
        int deltaX = endX - startX;
        int deltaY = endY - startY;
        if (Math.abs(deltaY) >  Math.abs(deltaX)) {
            // point to the top or bottom of the widget
            // point to horizontal center
            if (startOnRight) {
                startX -= sourceWidth/2;
            } else {
                startX += sourceWidth/2;
            }
            endX += target.getOffsetWidth()/2;
            if (deltaY < 0) {
                // point to bottom
                endY += target.getOffsetHeight();
            }
        } else {
            // point to the left or right side of the widget
            // point to vertical centre
            if (startOnBottom) {
                startY -= sourceHeight/2;
            } else {
                startY += sourceHeight/2;
            }
            endY += target.getOffsetHeight()/2;
            if (deltaX < 0) {
                // point to right side
                endX += target.getOffsetWidth();
            }
        }
        // originally based upon PaperNoteCallOut.drawArrow
        double arrowHeadSize = 10.0 * arrowStrokeThickness;
        // re-compute
        deltaX = endX - startX;
        deltaY = endY - startY;
        double arrowLength = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        if (arrowLength == 0) return;
        context.setStrokeStyle(ARROW_COLOR);
        context.setFillStyle(ARROW_COLOR);
        context.beginPath();
        context.moveTo(startX, startY);
        context.lineTo(endX, endY);
        context.stroke();
        double xArrowheadBase = deltaX * arrowHeadSize / arrowLength;
        double yArrowheadBase = deltaY * arrowHeadSize / arrowLength;
        drawTriangle((endX - xArrowheadBase - yArrowheadBase / 4.0),
                     (endY - yArrowheadBase + xArrowheadBase / 4.0),
                     endX, endY,
                     (endX - xArrowheadBase + yArrowheadBase / 4.0),
                     (endY - yArrowheadBase - xArrowheadBase / 4.0));
    }

    private void drawTriangle(double x0, double y0, double x1, double y1, double x2, double y2)  {
        context.beginPath();
        context.moveTo((float) x0, (float) y0);
        context.lineTo((float) x1, (float) y1);
        context.lineTo((float) x2, (float) y2);
        context.closePath();
        context.fill();
    }

    public double getArrowStrokeThickness() {
        return arrowStrokeThickness;
    }

    public void setArrowStrokeThickness(double arrowStrokeThickness) {
        this.arrowStrokeThickness = arrowStrokeThickness;
    }

    public void reset() {
        if (context == null) {
            return;
        }
        context.setFillStyle(MASK_COLOR);
        context.fillRect(0, 0, canvas.getOffsetWidth(), canvas.getOffsetHeight());
    }

    public Context2d getContext() {
        return context;
    }

    public Canvas getCanvas() {
        return canvas;
    }

    public static CssColor createColor(int red, int green, int blue, double alpha) {
        return CssColor.make("rgba(" + red + ", " + green + "," + blue + ", " + alpha + ")");
    }

}

