package lasad.gwt.client.communication.processors;

import java.util.List;
import java.util.Map;

import lasad.gwt.client.logger.Logger;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.FeedbackAuthoringTabContent;
import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.parameters.ParameterTypes;
import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionFE;
import lasad.shared.dfki.authoring.frontenddata.AgentDescriptionListFE;
import lasad.shared.dfki.authoring.frontenddata.Agents2OntologiesFE;
import lasad.shared.dfki.authoring.frontenddata.Agents2SessionsFE;
import lasad.shared.dfki.authoring.frontenddata.OntologiesFE;
import lasad.shared.dfki.authoring.frontenddata.SessionStatusMapFE;
import lasad.shared.dfki.authoring.frontenddata.SessionsFE;
import lasad.shared.dfki.meta.ServiceStatus;

public class FeedbackAuthoringActionProcessor {

	public static void translate(Action a) {
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][translate]", Logger.DEBUG);

        if(FeedbackAuthoringTabContent.getInstance() == null){
            return;
        }
        
        switch (a.getCmd()) {
			case ListOntologies:// Check
				processListOntologies(a);
				break;
			case GetOntologyDetails:// Check
				processGetOntologyDetails(a);
				break;
			case ListMap:// Check
				processListMap(a);
				break;
			case MapDetails:// Check
				processMapDetails(a);
				break;
			case ListAgentsInfo:// Check
				processListAgentsInfo(a);
				break;
			case ListAgentsToOntologies:// Check
				processListAgentsToOntologies(a);
				break;
			case ListAgentsToSessions:// Check
				processListAgentsToSessions(a);
				break;
			case ListSessionStatus:// Check
				processListSessionStatus(a);
				break;
			case AddOrUpdateAgent:
				processAddOrUpdateAgent(a);
				break;
			case DeleteAgent:
				processDeleteAgent(a);
				break;
			case AddAgentToOntology:
				processAddAgentToOntology(a);
				break;
			case AddAgentToSession:
				processAddAgentToSession(a);
				break;
			case RemoveAgentFromOntology:
				processRemoveAgentFromOntology(a);
				break;
			case RemoveAgentFromSession:
				processRemoveAgentFromSession(a);
				break;
			case CompileAgent:
				processCompileAgent(a);
				break;
			case AgentMappingsDeleted:
				processAgentMappingDeleted(a);
				break;
			case ComponentRuntimeStatusChanged:
				processComponentRuntimeStatusChanged(a);
				break;
			case SessionRuntimeStatusChanged:
				processSessionRuntimeStatusChanged(a);
				break;
			default:
				Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][translate] Error: Unknown action category!", Logger.DEBUG);
				break;
		}
	}
	
	private static void processListOntologies(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processListOntologies]", Logger.DEBUG);
        if(a.getObjectFE() == null){
        	return;
        }
        OntologiesFE ontFE = (OntologiesFE)a.getObjectFE();
        List<String> ontologyList = ontFE.getElements();
        FeedbackAuthoringTabContent.getInstance().handleListOntologies(ontologyList);
	}
	private static void processGetOntologyDetails(Action a){
		 Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processGetOntologyDetails]", Logger.DEBUG);
         if(a.getObjectFE() == null){
         	return;
         }
         FeedbackAuthoringTabContent.getInstance().handleGetOntologyDetails();
	}
	private static void processListMap(Action a){
		 Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processListMap]", Logger.DEBUG);
         if(a.getObjectFE() == null){
         	return;
         }
         SessionsFE sesFE = (SessionsFE)a.getObjectFE();
         Map<String, String> id2OntMap = sesFE.getId2OntMap();
         Map<String, String> id2NameMap = sesFE.getId2NameMap();
         FeedbackAuthoringTabContent.getInstance().handleListMap(id2OntMap, id2NameMap);
	}
	private static void processMapDetails(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processMapDetails]", Logger.DEBUG);
        if(a.getObjectFE() == null){
        	return;
        }
        FeedbackAuthoringTabContent.getInstance().handleMapdetails();
	}
	private static void processListAgentsInfo(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processListAgentsInfo]", Logger.DEBUG);
        if(a.getObjectFE() == null){
        	return;
        }
        AgentDescriptionListFE value = (AgentDescriptionListFE)a.getObjectFE();
        FeedbackAuthoringTabContent.getInstance().handleListAgentsInfo(value.getAgentDescriptions());
	}
	private static void processListAgentsToOntologies(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processListAgentsToOntologies]", Logger.DEBUG);
        if(a.getObjectFE() == null){
        	return;
        }
        //TODO should we get a fresh version of the Ontologies???
        Agents2OntologiesFE value = (Agents2OntologiesFE)a.getObjectFE();
        Map<String, List<String>> map = value.getMappings();
        String changed = a.getParameterValue(ParameterTypes.Changed);
        FeedbackAuthoringTabContent.getInstance().handleListAgentsToOntologies(map);
	}
	private static void processListAgentsToSessions(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processListAgentsToSessions]", Logger.DEBUG);
        if(a.getObjectFE() == null){
        	return;
        }
        Agents2SessionsFE value = (Agents2SessionsFE)a.getObjectFE();
        Map<String, List<String>> map = value.getMappings();
        String changed = a.getParameterValue(ParameterTypes.Changed);
        FeedbackAuthoringTabContent.getInstance().handleListAgentsToSessions(map);
	}
	private static void processListSessionStatus(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processListSessionStatus]", Logger.DEBUG);
        if(a.getObjectFE() == null){
        	return;
        }
        SessionStatusMapFE value = (SessionStatusMapFE)a.getObjectFE();
        Map<String, ServiceStatus> sessionID2Status = value.getSessionID2Status();
        Map<String, Map<String, ServiceStatus>> sessionID2agent2Status = value.getSessionID2agent2Status();
        FeedbackAuthoringTabContent.getInstance().handleListSessionStatus(sessionID2Status, sessionID2agent2Status);
	}
	private static void processAddOrUpdateAgent(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processAddOrUpdateAgent]", Logger.DEBUG);
		String changedStr = a.getParameterValue(ParameterTypes.Changed);
		if (changedStr != null && Boolean.parseBoolean(changedStr)){
			AgentDescriptionFE agentDescriptionFE = (AgentDescriptionFE)a.getObjectFE();
			//TODO
		}
	}
	private static void processDeleteAgent(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processDeleteAgent]", Logger.DEBUG);
		String changedStr = a.getParameterValue(ParameterTypes.Changed);
		if (changedStr != null && Boolean.parseBoolean(changedStr)){
			String agentId = a.getParameterValue(ParameterTypes.AgentId);
			//TODO
		}
	}
	private static void processAddAgentToOntology(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processAddAgentToOntology]", Logger.DEBUG);
		String changedStr = a.getParameterValue(ParameterTypes.Changed);
		if (changedStr != null && Boolean.parseBoolean(changedStr)){
			String agentId = a.getParameterValue(ParameterTypes.AgentId);
			String ontology = a.getParameterValue(ParameterTypes.Ontology);
			FeedbackAuthoringTabContent.getInstance().handleAddAgentToOntology(agentId, ontology);
		}
	}
	private static void processRemoveAgentFromOntology(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processRemoveAgentFromOntology]", Logger.DEBUG);
		String changedStr = a.getParameterValue(ParameterTypes.Changed);
		if (changedStr != null && Boolean.parseBoolean(changedStr)){
			String agentId = a.getParameterValue(ParameterTypes.AgentId);
			String ontology = a.getParameterValue(ParameterTypes.Ontology);
			FeedbackAuthoringTabContent.getInstance().handleRemoveAgentFromOntology(agentId, ontology);
		}
	}
	private static void processAddAgentToSession(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processAddAgentToSession]", Logger.DEBUG);
		String changedStr = a.getParameterValue(ParameterTypes.Changed);
		if (changedStr != null && Boolean.parseBoolean(changedStr)){
			String agentId = a.getParameterValue(ParameterTypes.AgentId);
			String sessionId = a.getParameterValue(ParameterTypes.SessionId);
			FeedbackAuthoringTabContent.getInstance().handleAddAgentToSession(agentId, sessionId);
		}
	}
	private static void processRemoveAgentFromSession(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processRemoveAgentFromSession]", Logger.DEBUG);
		String changedStr = a.getParameterValue(ParameterTypes.Changed);
		if (changedStr != null && Boolean.parseBoolean(changedStr)){
			String agentId = a.getParameterValue(ParameterTypes.AgentId);
			String sessionId = a.getParameterValue(ParameterTypes.SessionId);
			FeedbackAuthoringTabContent.getInstance().handleRemoveAgentFromSession(agentId, sessionId);
		}
	}
	private static void processCompileAgent(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processCompileAgent]", Logger.DEBUG);
		String changedStr = a.getParameterValue(ParameterTypes.Changed);
		String successful = a.getParameterValue(ParameterTypes.Successful);
		if (changedStr != null && Boolean.parseBoolean(changedStr) && successful != null){
			String agentId = a.getParameterValue(ParameterTypes.AgentId);
			FeedbackAuthoringTabContent.getInstance().handleCompileAgent(agentId);
		}
	}
	private static void processAgentMappingDeleted(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processAgentMappingDeleted]", Logger.DEBUG);
		String changedStr = a.getParameterValue(ParameterTypes.Changed);
		if (changedStr != null && Boolean.parseBoolean(changedStr)){
			String agentId = a.getParameterValue(ParameterTypes.AgentId);
			List<String> ontologyList = a.getParameterValues(ParameterTypes.Ontology); 
			List<String> sessionIdList = a.getParameterValues(ParameterTypes.SessionId);
			FeedbackAuthoringTabContent.getInstance().handleAgentMappingDeleted(agentId, ontologyList, sessionIdList);
		}
	}
	private static void processComponentRuntimeStatusChanged(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processComponentRuntimeStatusChanged]", Logger.DEBUG);
		String changedStr = a.getParameterValue(ParameterTypes.Changed);
		if (changedStr != null && Boolean.parseBoolean(changedStr)){
			String componentId = a.getParameterValue(ParameterTypes.ChangedComponentID);
			String oldStatus = a.getParameterValue(ParameterTypes.OldStatus);
			String newStatus = a.getParameterValue(ParameterTypes.NewStatus);
			FeedbackAuthoringTabContent.getInstance().handleComponentRuntimeStatusChanged(componentId, ServiceStatus.valueOf(oldStatus) , ServiceStatus.valueOf(newStatus));
		}
	}
	private static void processSessionRuntimeStatusChanged(Action a){
		Logger.log("[lasad.gwt.client.communication.FeedbackAuthoringActionProcessor][processSessionRuntimeStatusChanged]", Logger.DEBUG);
		String changedStr = a.getParameterValue(ParameterTypes.Changed);
		if (changedStr != null && Boolean.parseBoolean(changedStr)){
			String sessionId = a.getParameterValue(ParameterTypes.SessionId);
			String oldStatus = a.getParameterValue(ParameterTypes.OldStatus);
			String newStatus = a.getParameterValue(ParameterTypes.NewStatus);
			FeedbackAuthoringTabContent.getInstance().handleSessionRuntimeStatusChanged(sessionId, ServiceStatus.valueOf(oldStatus), ServiceStatus.valueOf(newStatus));
		}
	}
	
}
