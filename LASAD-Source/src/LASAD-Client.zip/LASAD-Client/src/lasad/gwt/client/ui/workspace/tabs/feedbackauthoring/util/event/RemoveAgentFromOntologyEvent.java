package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public class RemoveAgentFromOntologyEvent extends OntologyUserActionEventImpl {

	public RemoveAgentFromOntologyEvent(String ontology, String agent) {
		super(ontology, agent);
		// TODO Auto-generated constructor stub
	}

}
