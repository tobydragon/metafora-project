package lasad.gwt.client.model;

import java.util.Vector;

public class MVCHelper {

	public static Vector<UnspecifiedElementModel> getChildModelsByElementID(UnspecifiedElementModel parent, String type) {
		Vector<UnspecifiedElementModel> childs = new Vector<UnspecifiedElementModel>();
		for (UnspecifiedElementModel child : parent.getChildren()) {
			if (child.getElementid() != null) {
				if (child.getElementid().equalsIgnoreCase(type)) {
					childs.add(child);
				}
			}
		}
		return childs;
	}

	public static Vector<UnspecifiedElementModel> getChildModelsByType(UnspecifiedElementModel parent, String type) {
		Vector<UnspecifiedElementModel> childs = new Vector<UnspecifiedElementModel>();
		for (UnspecifiedElementModel child : parent.getChildren()) {
			if (child.getType() != null) {
				if (child.getType().equalsIgnoreCase(type)) {
					childs.add(child);
				}
			}
		}
		return childs;
	}

	public static Vector<UnspecifiedElementModel> getParentModelsByElementID(UnspecifiedElementModel child, String type) {
		Vector<UnspecifiedElementModel> parents = new Vector<UnspecifiedElementModel>();
		for (UnspecifiedElementModel parent : child.getParents()) {
			if (parent.getElementid() != null) {
				if (parent.getElementid().equalsIgnoreCase(type)) {
					parents.add(parent);
				}
			}
		}
		return parents;
	}

	public static Vector<UnspecifiedElementModel> getParentModelsByType(UnspecifiedElementModel child, String type) {
		Vector<UnspecifiedElementModel> parents = new Vector<UnspecifiedElementModel>();
		for (UnspecifiedElementModel parent : child.getParents()) {
			if (parent.getType() != null) {
				if (parent.getType().equalsIgnoreCase(type)) {
					parents.add(parent);
				}
			}
		}
		return parents;
	}
}
