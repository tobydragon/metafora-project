package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.grid;

public class EditGridConf {

}
