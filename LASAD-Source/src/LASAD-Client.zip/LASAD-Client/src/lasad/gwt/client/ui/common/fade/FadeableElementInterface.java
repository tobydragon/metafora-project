package lasad.gwt.client.ui.common.fade;

public interface FadeableElementInterface {
	
	public void setFadedOut(boolean fadedOut);
	
}