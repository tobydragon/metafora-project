package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public class StopSessionEvent extends SessionsUserActionEventImpl {

	public StopSessionEvent(String session, String agent) {
		super(session, agent);
		// TODO Auto-generated constructor stub
	}

}
