package lasad.gwt.client.ui.common;

import java.util.Vector;

import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.model.MVCViewSession;
import lasad.gwt.client.ui.common.highlight.HighlightHandler;
import lasad.gwt.client.ui.common.highlight.HighlightableElementInterface;

public interface ExtendedElementContainerInterface extends FocusableInterface, HighlightableElementInterface {
	
	public void addExtendedElement(ExtendedElement element);

	public void addExtendedElement(ExtendedElement element, int pos);

	public void removeExtendedElement(ExtendedElement element);

	public Vector<ExtendedElement> getExtendedElements();
	
	public FocusHandler getFocusHandler();

	public HighlightHandler getHighlightHandler();

	public ElementInfo getElementInfo();
	
	public MVCViewSession getMVCViewSession();
}
