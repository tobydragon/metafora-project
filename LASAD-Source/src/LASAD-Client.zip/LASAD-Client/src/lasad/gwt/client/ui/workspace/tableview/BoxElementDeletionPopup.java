package lasad.gwt.client.ui.workspace.tableview;

import java.util.HashMap;
import java.util.Map;

import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.model.MVCHelper;
import lasad.gwt.client.model.UnspecifiedElementModel;

import com.extjs.gxt.ui.client.widget.Popup;
import com.extjs.gxt.ui.client.widget.layout.FillLayout;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Label;

public class BoxElementDeletionPopup extends Popup{
	
	//*************************************************************************************
	//	Fields
	//*************************************************************************************
	
	private final Label heading;
	private final Label cancel;
	private final String separator;
	
	private Map<Label, UnspecifiedElementModel> labels;
	private UnspecifiedElementModel selectedModel;
	
	
	//*************************************************************************************
	//	Constructor
	//*************************************************************************************
	
	public BoxElementDeletionPopup() {
		
		setBorders(true);
		setWidth(225);
		setAutoHide(false);
		setLayout(new FillLayout());
		setStyleName("dialog-root");
		
		heading = new Label("Please choose an element to delete...", false);
		heading.setStyleName("dialog-heading");
		add(heading);
		
		labels = new HashMap<Label, UnspecifiedElementModel>();
		
		cancel = new Label("Cancel");
		cancel.setStyleName("dialog-text");
		cancel.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				hide();
			}
		});
		add(cancel);
		
		separator = ":";
	}
	
	
	//*************************************************************************************
	//	Methods
	//*************************************************************************************
	
	public void addLabel(UnspecifiedElementModel model, AbstractChildElement childElement) {
		
		ElementInfo childInfo = childElement.info;
		
		int count = MVCHelper.getChildModelsByElementID(model, childInfo.getElementID()).size();
		
		if (count > childInfo.getMinQuantity()) {
			
			String text = childElement.model.getValue("TEXT");
			String suffix = new String();
			
			if (text != null) {
				
				if (text.length() > 5) {
					suffix = text.substring(0, 5);
				} else {
					suffix = text;
				}
			}
			
			
			String str = new String();
			if (childInfo.getElementOption("longlabel") != null) {
			
				str = childInfo.getElementOption("longlabel") + separator + suffix;
			
			} else if (childInfo.getElementOption("label") != null) {
			
				str = childInfo.getElementOption("label") + separator + suffix;
			
			} else {
			
				str = childInfo.getElementID() + separator + suffix;
			}
		
			insetLabel(str, childElement.model);
		}
		
	}
	
	
	private void insetLabel(String str, final UnspecifiedElementModel model) {
		
		final Label label = new Label(str, false);
		label.setStyleName("dialog-text");
		labels.put(label, model);
		label.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				selectedModel = model;
				hide();
			}
		});

		insert(label, getItemCount() - 1);
	}

	//*************************************************************************************
	//	getter & setter
	//*************************************************************************************
	
	public UnspecifiedElementModel getSelectedModel() {
		
		return selectedModel;
	}
	
}
