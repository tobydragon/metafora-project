package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.window;

import java.util.List;

import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.FeedbackAuthoringTabContent;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data.ElementModel;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.Data2ModelConverter;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.FeedbackAuthoringStrings;

import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.event.WindowEvent;
import com.extjs.gxt.ui.client.event.WindowListener;
import com.extjs.gxt.ui.client.store.ListStore;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.Info;
import com.extjs.gxt.ui.client.widget.Window;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.ComboBox;
import com.extjs.gxt.ui.client.widget.form.ComboBox.TriggerAction;
import com.extjs.gxt.ui.client.widget.form.FormPanel;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.extjs.gxt.ui.client.widget.layout.FormData;

public abstract class SelectAgentWindow {
	
	private final Window window = new Window();
	private ComboBox<ElementModel> comboAgents;
	private FormData formData = new FormData("-20"); //100%
	private List<String> agentList;
	private String helper;
	private FeedbackAuthoringTabContent faTabRef;
	
	public SelectAgentWindow(List<String> agentList, String helper, FeedbackAuthoringTabContent faTabRef){
		this.agentList = agentList;
		this.helper = helper;
		this.faTabRef = faTabRef;
		initSelectAgentWindow();
		
	}
	
	public void show(){
		window.show();
	}

	private void initSelectAgentWindow(){
		window.setPlain(true);
		window.setModal(true);
		window.setBlinkModal(true);
		window.setSize("350px", "200px");
		//window.setMaximizable(true);
		window.setHeading(FeedbackAuthoringStrings.SELECT_AGENT_LABEL);
		
		window.setLayout(new FitLayout());
		window.add(getPanelContent());
		window.addWindowListener(new WindowListener() {  
			@Override
			public void windowHide(WindowEvent we) {
				//TODO check if we need to do something else before closing
			}
		});
		window.layout();
		
		Button saveBtn = new Button(FeedbackAuthoringStrings.SAVE_LABEL, new SelectionListener<ButtonEvent>() {  
			@Override  
			public void componentSelected(ButtonEvent ce) {  
				ElementModel value = (ElementModel) comboAgents.getValue();
				System.out.println("Selected element:" + value.getName());
				Info.display("Selected element", value.getName());
				//faTabRef.addAgentToOntologyTree(value.getName(), helper);
				doAction(value.getName(), helper);
				window.hide();
		    }
		});
		window.addButton(saveBtn);
		
		Button cancelBtn = new Button(FeedbackAuthoringStrings.CANCEL_LABEL, new SelectionListener<ButtonEvent>() {  
			@Override  
			public void componentSelected(ButtonEvent ce) {  
				window.hide();  
			}  
		});
		window.addButton(cancelBtn);
	}
	
	public abstract void doAction(String agentName, String helper);
	
	private ContentPanel getPanelContent(){
		ContentPanel panel = new ContentPanel();
		panel.setLayout(new FitLayout());
		panel.setBodyBorder(false);
		panel.setHeaderVisible(false);
		
		FormPanel fPanel = new FormPanel();
		fPanel.setHeaderVisible(false);
		fPanel.setBodyBorder(false);
		fPanel.setWidth(350);
		
		ListStore<ElementModel> agentsStore = new ListStore<ElementModel>();
		agentsStore.add(Data2ModelConverter.getStrAsModel(agentList));  
	  
	    comboAgents = new ComboBox<ElementModel>();
	    comboAgents.setFieldLabel(FeedbackAuthoringStrings.SELECT_AGENT_LABEL);
	    comboAgents.setDisplayField("name");  
	    comboAgents.setWidth(150);  
	    comboAgents.setStore(agentsStore);  
	    comboAgents.setTypeAhead(true);  
	    comboAgents.setTriggerAction(TriggerAction.ALL);
		
	    fPanel.add(comboAgents, formData);
	    panel.add(fPanel);
	    return panel;
	}

	protected FeedbackAuthoringTabContent getFATabRef() {
		return faTabRef;
	}
}
