package lasad.gwt.client.ui.workspace.argumentmap.elements;

import lasad.gwt.client.communication.LASADActionSender;
import lasad.gwt.client.communication.helper.ActionFactory;
import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.ui.workspace.argumentmap.ArgumentMap;
import lasad.gwt.client.ui.workspace.transcript.TranscriptLinkData;
import lasad.shared.communication.objects.Action;
import lasad.shared.communication.objects.ActionPackage;
import lasad.shared.communication.objects.parameters.ParameterTypes;

import com.extjs.gxt.ui.client.event.Events;
import com.google.gwt.dom.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;



public class CreateBoxDialogListener implements EventListener {

    private final LASADActionSender communicator = LASADActionSender.getInstance();
    private final ActionFactory actionBuilder = ActionFactory.getInstance();

    private ArgumentMap myMap;
    private CreateBoxDialog myDialog;
    private TranscriptLinkData myTData = null;

    public CreateBoxDialogListener(ArgumentMap map, CreateBoxDialog dialog) {
	this.myMap = map;
	this.myDialog = dialog;
    }

    public CreateBoxDialogListener(ArgumentMap map, CreateBoxDialog dialog, TranscriptLinkData tData) {
	this.myMap = map;
	this.myDialog = dialog;
	this.myTData = tData;
    }

    public void onBrowserEvent(Event be) {
	if (be.getTypeInt() == Events.OnMouseOver.getEventCode()) {
	    handleMouseOver(be);
	} else if (be.getTypeInt() == Events.OnClick.getEventCode()) {
	    handleOnClick(be);
	} else if (be.getTypeInt() == Events.OnMouseOut.getEventCode()) {
	    handleMouseOut(be);

	}
	be.stopPropagation();
    }

    private void handleOnClick(Event be) {
	for (ElementInfo info : myMap.getMyViewSession().getController().getMapInfo().getElementsByType("box").values()) {
	    if (((Element) be.getEventTarget().cast()).getInnerText().equals(info.getElementOption(ParameterTypes.Heading))) {

		Action transcriptLinkAction = null;
		for (ElementInfo childInfo : info.getChildElements().values()) {
		    if (childInfo.getElementType().equals("transcript-link")) {
			// TranscriptLink for this element allowed
			if (myTData != null) {
			    transcriptLinkAction = actionBuilder.createTranscriptLink(myMap.getID(), "LAST-ID", myTData);
			}
		    }
		}
		// Send Action --> Server
		ActionPackage actionPackage = actionBuilder.createBoxWithElements(info, myMap.getID(), myDialog.getPosition(true).x, myDialog.getPosition(true).y);
		actionPackage.addAction(transcriptLinkAction);

		communicator.sendActionPackage(actionPackage);
	    }
	}
	myDialog.removeFromParent();
    }

    private void handleMouseOut(Event be) {
	// End hover effect
	if (((Element) be.getEventTarget().cast()).getClassName().equals("dialog-text-highlighted")) {
	    ((Element) be.getEventTarget().cast()).setClassName("dialog-text");
	}
    }

    private void handleMouseOver(Event be) {
	// Start hover effect
	if (((Element) be.getEventTarget().cast()).getClassName().equals("dialog-text")) {
	    ((Element) be.getEventTarget().cast()).setClassName("dialog-text-highlighted");
	}
    }
}