package lasad.gwt.client.ui.workspace.tableview;

import java.util.Set;

import lasad.gwt.client.model.UnspecifiedElementModel;
import lasad.shared.communication.objects.parameters.ParameterTypes;

public class RelationInfo {

	// *************************************************************************************
	// Fields
	// *************************************************************************************

	private UnspecifiedElementModel fromModel;

	private Set<UnspecifiedElementModel> toModels;
	
	private UnspecifiedElementModel selectedToModel;

	// *************************************************************************************
	// getter & setter
	// *************************************************************************************

	public void selectToModel(String id) {
		
		for (UnspecifiedElementModel m: toModels) {
			
			String str = m.getValue(ParameterTypes.RootElementId);
			
			if (str.equals(id)) {
				
				selectedToModel = m;
				
				break;
			}
		}
		
	}
	
	
	public UnspecifiedElementModel getFromModel() {
		return fromModel;
	}

	public void setFromModel(UnspecifiedElementModel fromModel) {
		this.fromModel = fromModel;
	}

	public Set<UnspecifiedElementModel> getToModels() {
		return toModels;
	}

	public void setToModels(Set<UnspecifiedElementModel> toModels) {
		this.toModels = toModels;
	}


	public UnspecifiedElementModel getSelectedToModel() {
		return selectedToModel;
	}

	public void setSelectedToModel(UnspecifiedElementModel selectedToModel) {
		this.selectedToModel = selectedToModel;
	}


}
