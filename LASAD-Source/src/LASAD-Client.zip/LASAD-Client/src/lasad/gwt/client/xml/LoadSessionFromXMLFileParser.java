package lasad.gwt.client.xml;

import lasad.gwt.client.ui.workspace.LASADInfo;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.Node;
import com.google.gwt.xml.client.NodeList;
import com.google.gwt.xml.client.XMLParser;
import com.google.gwt.xml.client.impl.DOMParseException;

public class LoadSessionFromXMLFileParser {

	private static String getFilePart(String XML, String part) {
		Document doc = null; 
		try {
		    doc = XMLParser.parse(XML);
		}
		catch (DOMParseException ex) {
		    LASADInfo.display("Error", "An error occured while parsing the xml-file. File could not be loaded.");
		    ex.printStackTrace();
		}

		Element lasadElement = doc.getDocumentElement();
		XMLParser.removeWhitespace(lasadElement);
		
		NodeList nodes = lasadElement.getChildNodes();
		
		for(int i = 0; i<nodes.getLength(); i++) {
			Node n = nodes.item(i);
			if(n.getNodeName().equalsIgnoreCase(part)) {
				return (n.toString()).trim();
			}
		}

		// Part definition is missing
		return null;
	}
	
	public static String getOntology(String XML) {
		return LoadSessionFromXMLFileParser.getFilePart(XML, "ontology");
	}
	
	public static String getTemplate(String XML) {
		return LoadSessionFromXMLFileParser.getFilePart(XML, "maptemplate");
	}

	public static String getContent(String XML) {
		return LoadSessionFromXMLFileParser.getFilePart(XML, "content");
	}
	
}
