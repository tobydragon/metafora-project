package lasad.gwt.client.xml;

import lasad.gwt.client.ui.workspace.LASADInfo;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.Node;
import com.google.gwt.xml.client.NodeList;
import com.google.gwt.xml.client.XMLParser;
import com.google.gwt.xml.client.impl.DOMParseException;

public class LoadSessionFromXMLFileParser {

	private static String getFilePart(String XML, String part) {
		Document doc = null; 
		try {
			System.out.println("-> LoadSessionFromXMLFileParser ->getFilePart Part="+part);
		    doc = XMLParser.parse(XML);
			Element lasadElement = doc.getDocumentElement();
			XMLParser.removeWhitespace(lasadElement);
			
			NodeList nodes = lasadElement.getChildNodes();
			
			for(int i = 0; i<nodes.getLength(); i++) {
				Node n = nodes.item(i);
				if(n.getNodeName().equalsIgnoreCase(part)) {
					return (n.toString()).trim();
				}
			}
		}
		catch (DOMParseException ex) {
//		    LASADInfo.display("Error", "An error occured while parsing the xml-file. File could not be loaded.");
		    ex.printStackTrace();
		}
		

		// Part definition is missing
		return null;
	}
	
	public static String getOntology(String XML) {
		System.out.println("-> LoadSessionFromXMLFileParser ->getOntology");
		return LoadSessionFromXMLFileParser.getFilePart(XML, "ontology");
	}
	
	public static String getTemplate(String XML) {
		System.out.println("-> LoadSessionFromXMLFileParser ->getTemplate");
		return LoadSessionFromXMLFileParser.getFilePart(XML, "maptemplate");
	}

	public static String getContent(String XML) {
		System.out.println("-> LoadSessionFromXMLFileParser ->getContent");
		return LoadSessionFromXMLFileParser.getFilePart(XML, "content");
	}
	
	public static String getChatlog(String XML) {
		System.out.println("-> LoadSessionFromXMLFileParser ->getChatlog");
		return LoadSessionFromXMLFileParser.getFilePart(XML, "chatlog");
	}
	
}
