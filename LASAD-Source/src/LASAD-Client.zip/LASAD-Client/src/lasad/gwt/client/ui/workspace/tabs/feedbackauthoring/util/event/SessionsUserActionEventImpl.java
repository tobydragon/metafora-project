package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public class SessionsUserActionEventImpl extends UserActionEventImpl {
	
	public SessionsUserActionEventImpl(String session, String agent) {
		addProperty(ActionUserEventProperty.session, session);
		addProperty(ActionUserEventProperty.agent, agent);
	}
}
