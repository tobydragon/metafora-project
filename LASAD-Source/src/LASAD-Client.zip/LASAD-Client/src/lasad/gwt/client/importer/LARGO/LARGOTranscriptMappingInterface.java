package lasad.gwt.client.importer.LARGO;

public interface LARGOTranscriptMappingInterface {
	public void mapChars(int charNumber, boolean start);

	public int getLine();

	public int getPoint();
}