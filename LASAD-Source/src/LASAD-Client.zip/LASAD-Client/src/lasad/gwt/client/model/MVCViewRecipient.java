package lasad.gwt.client.model;

public interface MVCViewRecipient {
	public UnspecifiedElementModel getConnectedModel();

	public void changeValueMVC(UnspecifiedElementModel model, String vname);

	public void deleteModelConnection(UnspecifiedElementModel model);

	public boolean establishModelConnection(UnspecifiedElementModel model);
}