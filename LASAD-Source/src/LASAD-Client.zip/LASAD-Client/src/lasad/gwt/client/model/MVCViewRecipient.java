package lasad.gwt.client.model;

import lasad.shared.communication.objects.parameters.ParameterTypes;

public interface MVCViewRecipient {
	public UnspecifiedElementModel getConnectedModel();

	public void changeValueMVC(UnspecifiedElementModel model, ParameterTypes vname);

	public void deleteModelConnection(UnspecifiedElementModel model);

	public boolean establishModelConnection(UnspecifiedElementModel model);
}