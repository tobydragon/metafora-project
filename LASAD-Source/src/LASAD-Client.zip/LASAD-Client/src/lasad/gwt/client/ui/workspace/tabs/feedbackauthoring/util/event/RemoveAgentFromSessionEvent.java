package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public class RemoveAgentFromSessionEvent extends SessionUserActionEventImpl{

	public RemoveAgentFromSessionEvent(String session, String agent) {
		super(session, agent);
		// TODO Auto-generated constructor stub
	}

}
