package lasad.gwt.client.ui.box.helper;

import lasad.gwt.client.communication.LASADActionSender;
import lasad.gwt.client.communication.objects.ActionFactory;
import lasad.gwt.client.ui.box.Box;
import lasad.gwt.client.ui.workspace.argumentmap.elements.DeleteDialog;

import com.extjs.gxt.ui.client.event.Events;
import com.google.gwt.dom.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;

public class BoxHeaderButtonListener implements EventListener {

	private Box boxReference;
	
	private final LASADActionSender communicator = LASADActionSender.getInstance();
	private final ActionFactory actionBuilder = ActionFactory.getInstance();
	
	public BoxHeaderButtonListener(Box boxReference) {
		this.boxReference = boxReference;
	}
	
	public void onBrowserEvent(Event be) {
		if (be.getTypeInt() == Events.OnClick.getEventCode()){
			handleOnClick(be);
				
		}
		else if (be.getTypeInt() == Events.OnMouseOver.getEventCode()){
			handleOnMouseOver(be);
			
			
		}
		else if (be.getTypeInt() == Events.OnMouseOut.getEventCode()){
			handleOnMouseOut(be);
			
		}
		be.stopPropagation();
	}		
	
	private void handleOnClick(Event be) {
		
		if(((Element) be.getEventTarget().cast()).getClassName().equals("close-button-highlighted")) {
			if (!boxReference.getMap().isDeleteElementsWithoutConfirmation()) {
				//position it at the close-button
				new DeleteDialog(boxReference.getMap(), boxReference, boxReference.getPosition(true).x + boxReference.getWidth(true) - boxReference.getBORDER_WIDTH() - boxReference.getCONNECTOR_WIDTH(), boxReference.getPosition(true).y + boxReference.getCONNECTOR_HEIGHT() + boxReference.getBORDER_HEIGHT());
			}
			else {		
				// Build ActionSet with all needed Updates
				boxReference.getMap().getFocusHandler().releaseAllFocus();
				communicator.sendActionPackage(actionBuilder.removeElement(boxReference.getMap().getID(), boxReference.getConnectedModel().getId()));
			}
		}
		else if(((Element) be.getEventTarget().cast()).getClassName().equals("add-button-highlighted")) {
			new AddElementToBoxDialog(boxReference.getMap(), boxReference, boxReference.getPosition(true).x, boxReference.getPosition(true).y);
		}else if(((Element) be.getEventTarget().cast()).getClassName().equals("del-button-highlighted")) {
			new DelElementFromBoxDialog(boxReference.getMap(), boxReference, boxReference.getPosition(true).x, boxReference.getPosition(true).y);
		}
	}
	
	private void handleOnMouseOver(Event be) {	
		if(((Element) be.getEventTarget().cast()).getClassName().equals("close-button")) {
			((Element) be.getEventTarget().cast()).setClassName("close-button-highlighted");
		}
		else if(((Element) be.getEventTarget().cast()).getClassName().equals("add-button")) {
			((Element) be.getEventTarget().cast()).setClassName("add-button-highlighted");		
			//((Element) be.getEventTarget().cast()).setAttribute("visibility", "visible");
		}
		else if(((Element) be.getEventTarget().cast()).getClassName().equals("del-button")) {
			((Element) be.getEventTarget().cast()).setClassName("del-button-highlighted");
			//((Element) be.getEventTarget().cast()).setAttribute("visibility", "visible");
		}
	}
	
	private void handleOnMouseOut(Event be) {
		if(((Element) be.getEventTarget().cast()).getClassName().equals("close-button-highlighted")) {
			((Element) be.getEventTarget().cast()).setClassName("close-button");
		}
		else if(((Element) be.getEventTarget().cast()).getClassName().equals("add-button-highlighted")) {
			((Element) be.getEventTarget().cast()).setClassName("add-button");
		}
		else if(((Element) be.getEventTarget().cast()).getClassName().equals("del-button-highlighted")) {
			((Element) be.getEventTarget().cast()).setClassName("del-button");
		}
	}
}