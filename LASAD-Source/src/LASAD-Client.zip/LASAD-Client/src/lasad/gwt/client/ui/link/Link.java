package lasad.gwt.client.ui.link;

import java.util.Iterator;
import java.util.Vector;

import lasad.gwt.client.constants.lasad_clientConstants;
import lasad.gwt.client.helper.connection.BezierTwoEndedConnection;
import lasad.gwt.client.helper.connection.Connection;
import lasad.gwt.client.helper.connection.data.BezierConnectionData;
import lasad.gwt.client.helper.connection.data.ConnectionData;
import lasad.gwt.client.helper.connection.data.Point;
import lasad.gwt.client.helper.connector.Connector;
import lasad.gwt.client.helper.connector.Direction;
import lasad.gwt.client.helper.connector.UIObjectConnector;
import lasad.gwt.client.logger.Logger;
import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.model.MVCViewRecipient;
import lasad.gwt.client.model.MVCViewSession;
import lasad.gwt.client.model.UnspecifiedElementModel;
import lasad.gwt.client.ui.GraphicalElementInterface;
import lasad.gwt.client.ui.common.ExtendedElement;
import lasad.gwt.client.ui.common.ExtendedElementContainerInterface;
import lasad.gwt.client.ui.common.FocusHandler;
import lasad.gwt.client.ui.common.FocusableInterface;
import lasad.gwt.client.ui.common.highlight.HighlightHandler;
import lasad.gwt.client.ui.common.highlight.HighlightableElementInterface;
import lasad.gwt.client.ui.workspace.argumentmap.ArgumentMap;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.DOM;

public class Link extends BezierTwoEndedConnection implements MVCViewRecipient,
		ExtendedElementContainerInterface,
		// SelectableElementInterface,
		GraphicalElementInterface {

	lasad_clientConstants myConstants = GWT.create(lasad_clientConstants.class);

	protected LinkPanel linkPanel;

	private ArgumentMap myMap;
	private Connector cn, startConnector, endConnector;
	private Point position;
	private float v = 0.5f;
	
	protected boolean editMode = false;
	protected boolean principles = false;

	public Link(ArgumentMap myMap, ElementInfo config, Connector cn1,
			Connector cn2, boolean isReplay) {
		super(cn1, cn2, config.getUiOption("linewidth"), config
				.getUiOption("linecolor"), (config.getElementOption("endings")
				.equals("true")) ? true : false);
		this.config = config;
		this.myMap = myMap;
		this.setStartConnector(cn1);
		this.setEndConnector(cn2);
		DOM.setIntStyleAttribute(this.getElement(), "zIndex", 0);
		initLinkPanel(isReplay);
		
	}

	private void initLinkPanel(boolean isReplay) {

		if (config.getUiOption("details") != null) {
			linkPanel = new LinkPanel(this, config.getUiOption("details"),isReplay);
		} else {
			linkPanel = new LinkPanel(this, "true",isReplay);
		}
		update();
		myMap.add(linkPanel);
		myMap.layout();
	}

	/**
	 * Calculate the point of a beziercurve
	 * 
	 * @param p1
	 *            Point 1
	 * @param p2
	 *            Controlpoint 1
	 * @param p3
	 *            Controlpoint 2
	 * @param p4
	 *            Point 2
	 * @return Middlepoint
	 */
	private Point calculatePosition(Point p1, Point p2, Point p3, Point p4,float v) {
		float a = 1 - v;
		float b = a * a * a;
		float c = v * v * v;
		float resultX = b * p1.getLeft() + 3 * v * a * a * p2.getLeft() + 3 * v
				* v * a * p3.getLeft() + c * p4.getLeft();
		int X = Math.round(resultX);
		float resultY = b * p1.getTop() + 3 * v * a * a * p2.getTop() + 3 * v
				* v * a * p3.getTop() + c * p4.getTop();
		int Y = Math.round(resultY);
		Point result = new Point(X, Y);
		return result;
	}

	public Connector getConnector() {
		if (cn == null) {
			cn = UIObjectConnector.wrap(linkPanel);
		}
		return cn;
	}

	public ArgumentMap getMap() {
		return myMap;
	}

	@Override
	public void remove() {
		linkPanel.removeFromParent();
		super.remove();
	}

	public void setLineColor(String color) {
		DOM.setStyleAttribute(this.getCurveStyleElement(), "color", color);
	}

	public void setLineWidth(String width) {
		DOM.setStyleAttribute(this.getCurveStyleElement(), "width", width);
	}
	//ZyG,19.05.2011 TODO
	BezierConnectionData bdata;
	public BezierConnectionData getBezierConnectionData()
	{
		return bdata;
	}
	
	@Override
	protected void update(ConnectionData data) {
		try {

			bdata = (BezierConnectionData) data;

			Point p1 = (Point) bdata.getPoints().get(0); // get start and end
															// points
			Point p2 = (Point) bdata.getPoints().get(1);
			Point p3 = (Point) bdata.getControlPoints().get(0);
			Point p4 = (Point) bdata.getControlPoints().get(1);
			/*
			 * recalculate positions source: the center of the connection
			 */			
			position = calculatePosition(p1, p3, p4, p2,v);

			updateLinkPanelPosition();

			// recalculate all connected connections
			if (cn != null) {
				for (Iterator<Connection> i = cn.getConnections().iterator(); i.hasNext();) {
					Connection con = (Connection) i.next();
					con.update();
				}
			}
			super.update(data);
		} catch (Exception e) {
			Logger.log("update(ConnectionData) in class Link.java failed.", Logger.DEBUG_ERRORS);
		}
	} 

	protected void updateLinkPanelPosition() {
		if (position != null) {
			int x = position.getLeft();
			int y = position.getTop();
			
			int posX = (x - 2) - (linkPanel.getWidth() / 2);
			int posY = (y - 2) - (linkPanel.getHeight() / 2);
						
			if (this.connectedModel != null) {
				this.connectedModel.setValue("POS-X", posX + "");
				this.connectedModel.setValue("POS-Y", posY + "");
			}
			
			linkPanel.setPosition(posX, posY);
			
		}
	}

	public Connector getConnector(Direction dir) {
		return getConnector();
	}

	public Direction getDirection() {
		return null;
	}

	public LinkPanel getLinkPanel() {
		return linkPanel;
	}

	public void changeValueMVC(UnspecifiedElementModel model, String vName) {
		
		if (vName.equals("PERCENT")) {
			Point p1 = (Point) bdata.getPoints().get(0); // get start and end
			Point p2 = (Point) bdata.getPoints().get(1);
			Point p3 = (Point) bdata.getControlPoints().get(0);
			Point p4 = (Point) bdata.getControlPoints().get(1);
			v = Float.parseFloat(model.getValue("PERCENT"));
			position = calculatePosition(p1, p3, p4, p2,v);
			updateLinkPanelPosition();
		} else if (vName.equals("HEIGHT")) {
			this.linkPanel.setHeight(Integer.parseInt(model.getValue("HEIGHT")) + 2);
		}
		else if (vName.equals("ROOTELEMENTID")) {
			this.linkPanel.setRootElementID(model.getValue("ROOTELEMENTID"));
		}
		else if (vName.equals("HIGHLIGHTED")) {
			if (model.getValue("HIGHLIGHTED").equalsIgnoreCase("TRUE")) {
				this.setHighlight(true);
			} else if (model.getValue("HIGHLIGHTED").equalsIgnoreCase("FALSE")) {
				this.setHighlight(false);
			}
		}
		else if (vName.equals("FADED")) {
			if (model.getValue("FADED").equalsIgnoreCase("TRUE")) {
				this.linkPanel.setFadedOut(true);
				return;
			} else if (model.getValue("FADED").equalsIgnoreCase("FALSE")) {
				this.linkPanel.setFadedOut(false);
				return;
			}
		}

		else if (vName.equals("DIRECTION")) {
			this.setEndings(this.getEnding(1), this.getEnding(0));
			this.update();
//			this.getConnectedModel().setValue("DIRECTION", "unchanged");
		}

		// check if update results in an highlight
		this.getLinkPanel().checkForHighlight(model.getValue("USERNAME"));
	}

	@Override
	public void deleteModelConnection(UnspecifiedElementModel model) {
		try {
			if (cn != null) {
				cn.disconnect();
			}
		} catch (Exception e) {
			Logger.log("Could not disconnect connector of element: "
					+ model.getId(), Logger.DEBUG_ERRORS);
		} finally {
			myMap.remove(this);
			this.remove();
		}
	}

	@Override
	public boolean establishModelConnection(UnspecifiedElementModel model) {
		if (connectedModel == null) {
			connectedModel = model;
			return true;
		} else {
			return false;
		}
	}

	private UnspecifiedElementModel connectedModel = null;

	public UnspecifiedElementModel getConnectedModel() {
		return connectedModel;
	}

	public void setConnectedModel(UnspecifiedElementModel connectedModel) {
		this.connectedModel = connectedModel;
	}

	private ElementInfo config = null;

	public ElementInfo getElementInfo() {
		return config;
	}

	public void addExtendedElement(ExtendedElement element) {
		linkPanel.addExtendedElement(element);
	}

	public void addExtendedElement(ExtendedElement element, int pos) {
		linkPanel.addExtendedElement(element, pos);
	}

	public void removeExtendedElement(ExtendedElement element) {
		linkPanel.removeExtendedElement(element);
	}

	@Override
	public FocusHandler getFocusHandler() {
		return getMap().getFocusHandler();
	}

	@Override
	public FocusableInterface getFocusParent() {
		return getMap();
	}

	@Override
	public void setElementFocus(boolean focus) {
	}

	@Override
	public MVCViewSession getMVCViewSession() {
		return this.getMap().getMyViewSession();
	}

	@Override
	public Vector<ExtendedElement> getExtendedElements() {
		return linkPanel.getExtendedElements();
	}

	@Override
	public HighlightHandler getHighlightHandler() {
		return getMap().getHighlightHandler();
	}

	public HighlightableElementInterface getHighlightParent() {
		return getMap();
	}

	public void setHighlight(boolean highlight) {
		linkPanel.setHighlight(highlight);
	}

	public Connector getStartConnector() {
		return startConnector;
	}

	public void setStartConnector(Connector startConnector) {
		this.startConnector = startConnector;
	}

	public Connector getEndConnector() {
		return endConnector;
	}

	public void setEndConnector(Connector endConnector) {
		this.endConnector = endConnector;
	}
	
	public void setPercentage(float v)
	{
		this.v = v;
	}
}