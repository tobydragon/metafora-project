package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util;

public class FeedbackAuthoringStrings {
	
	public static final String PATTERN2_LABEL = "Pattern";
	public static final String STRUCTURE_LABEL = "structure";
	public static final String COUNTER_LABEL = "counter";
	public static final String TRIGGER_BY_LABEL = "Trigger by";
	public static final String SELECT_LABEL = "Select...";
	
	public static final String FEEDBACK_AUTHORING_TOOL = "Feedback Authoring tool";
	
	public static final String HEADING_SESSIONS = "Sessions";
	public static final String HEADING_AGENTS = "Agents";
	public static final String HEADING_ONTO_AGENTS = "Ontologies -> Agents";
	public static final String HEADING_SESSIONS_AGENTS = "Sessions -> Agents";
	public static final String HEADING_ADD_AGENT = "Add Agent";
	public static final String HEADING_GENERAL = "General";
	public static final String HEADING_PATTERNS = "Patterns";
	public static final String HEADING_FEEDBACK = "Feedback";
	public static final String HEADING_PROVISION = "Provision";
	public static final String HEADING_GENERAL_AGENT_SETTINGS = "General Agent Settings";
	public static final String HEADING_BASIC = "Basic";
	public static final String HEADING_FILTER = "Filter";
	public static final String HEADING_CONTENT = "Content";
	
	public static final String CONTROL_THREAD_DB_HEADING = "Control-Thread DB";
	public static final String MESSAGES_HEADING = "Messages";
	public static final String SORT_AND_FILTER_HEADING = "Sort & Filter";
	public static final String CONTROL_THREAD_LABEL = "Control-Thread";
	public static final String GROUP_THREAD_LABEL = "Group-thread";
	public static final String USER_THREAD_LABEL = "User-Thread";

	
	public static final String HEADING_PHASES = "Phases";
	public static final String HEADING_ANALYSIS_PHASES = "Analysis phases";
	public static final String HEADING_EXPERT = "Expert";
	public static final String HEADING_MESSAGE = "Message";
	public static final String HEADING_COMPONENTS = "Components";
	public static final String HEADING_PRIORITY = "Priority";
	public static final String HEADING_PATTERN_DB = "Pattern DB";
	public static final String HEADING_SELECTED_PATERN = "Selected Pattern";
	public static final String HEADING_PATERN_STRUCTURE = PATTERN2_LABEL + " (" + STRUCTURE_LABEL + ")";
	public static final String HEADING_PATERN_COUNTER = PATTERN2_LABEL + " (" + COUNTER_LABEL + ")";
	public static final String HEADING_RULE_DB = "Rule DB";
	public static final String FEEDBACK_DB_HEADING = "Feedback DB";
	public static final String FEEDBACK_STD_MSG_HEADING = "Feedback (std-message)";
	public static final String HEADING_PATTERN_RULE = "Rule (pattern rule)";
	public static final String HEADING_FILTER_RULE = "Rule (filter rule)";
	public static final String HEADING_ADD_NEW_AGENT = "Add new Agent";
	public static final String HEADING_EDIT_AGENT = "Edit Agent";
	public static final String HEADING_VIEW_AGENT = "View Agent";
	public static final String HEADING_DUPLICATE_AGENT = "Duplicate Agent";
	public static final String HEADING_USER_RESTRICTIONS = "User restrictions";
	public static final String HEADING_TIME_RESTRICTIONS = "Time restrictions";
	
	
	public static final String MARK_READY_AGENT_LABEL = "Mark Agent Ready";
	public static final String VIEW_AGENT_LABEL = "View Agent";
	public static final String EDIT_AGENT_LABEL = "Edit Agent";
	public static final String ADD_AGENT_LABEL = "Add Agent";
	public static final String DELETE_AGENT_LABEL = "Delete Agent";
	public static final String REMOVE_AGENT_LABEL = "Remove Agent";
	public static final String DUPLICATE_AGENT_LABEL = "Duplicate Agent";
	public static final String AGENT_LABEL = " agent";
	public static final String PATTERN_LABEL = "pattern";
	public static final String RULE_LABEL = " rule";
	public static final String NAME_LABEL = "Name";
	public static final String AGENT_ID_LABEL = "Agent ID";
	public static final String RULE_ID_LABEL = "Rule ID";
	public static final String PROVISION_LABEL = "Provision";
	public static final String RECIPIENT_LABEL = "Recipient";
	public static final String FEEDBACK_LABEL = "feedback";
	public static final String START_SESSION_LABEL = "Start session";
	public static final String STOP_SESSION_LABEL = "Stop session";
	
	public static final String INSTANCE_TYPE_RESTRICTIONS_HEADER = "<b>Instance type restrictions</b>";
	public static final String GENERAL_INSTANCE_CLASS_LABEL = "general instance class";
	public static final String BOX_LABEL = "box";
	public static final String LINK_LABEL = "link";
	public static final String BOX_OR_LINK_LABEL = BOX_LABEL + " or " + LINK_LABEL;
	public static final String SPECIFIC_TYPES_LABEL = "specific types";
	
	public static final String USER_RESTRICTIONS_HEADER = "<b>User restrictions</b>";
	public static final String TIME_REST_HEADER = "<b>Time restrictions</b>";
	public static final String COUNT_CONDITION_HEADER = "<b>Count condition</b>";
	
	public static final String NOTE_BOLD_LABEL = "<b>Note:<\b> ";
	public static final String USER_SPECIFIC_LABEL = "user-specific";
	public static final String PAT_USER_REST_INFO_LABEL = NOTE_BOLD_LABEL + "Selecting one of the following options "
									+ "turns the pattern into a <u>" + USER_SPECIFIC_LABEL + "</u> pattern";
	public static final String PAT_USER_REST_HELP_LABEL = "<b>\"" + USER_SPECIFIC_LABEL + "\"<\b>"
									+ "patterns can " + "<b>" + "ONLY" + "<\b>"
									+ "serve as basis for " + USER_SPECIFIC_LABEL+ " feedback messages";
	public static final String PAT_USER_REST_OPT2_HELP_LABEL = "<b>\"Contributor\":<\b> user has created or modified one of "
									+ "the pattern components (resize or move actions are ignored)";
	public static final String PAT_USER_REST_OPT1_LABEL = "No user restriction";
	public static final String PAT_USER_REST_OPT2_LABEL = "Count instances \"owned\" by user (one and only <u>contributor</u>)";
	public static final String PAT_USER_REST_OPT3_LABEL = "Count instances modified by user (other contributors possible)";
	public static final String PAT_USER_REST_OPT4_LABEL = "Count instances <b>not modified by user</b>";
	public static final String PAT_TIME_REST_OPT1_LABEL = "No time restriction";
	public static final String PAT_TIME_REST_OPT2_1_LABEL = "Count instances last modified more than ";
	public static final String PAT_TIME_REST_OPT2_2_LABEL = " secs ago (\"old\" instances)";
	public static final String PAT_TIME_REST_OPT3_1_LABEL = "Count instances last modified less than ";
	public static final String PAT_TIME_REST_OPT3_2_LABEL = " secs ago (\"recent\" instances)";
	
	public static final String FEEDBACK_BASIC_INFO_LABEL = NOTE_BOLD_LABEL + "Selecting a " 
															+ USER_SPECIFIC_LABEL + " pattern will turn the message into a "
															+ "<u>" + USER_SPECIFIC_LABEL + "</u> message";
	public static final String FEEDBACK_BASIC_TRIGGERED_HELP_LABEL = "Select a pattern that enables this message";
	public static final String FEEDBACK_BASIC_INFO_HELP_LABEL = "<b>\"" + USER_SPECIFIC_LABEL + "\"<\b>"
															+ "messages can " + "<b>" + "ONLY" + "<\b>"
															+ " be provided to individual users " 
															+ "(i.e., they cannot be broadcasted to the whole group";
	public static final String FEEDBACK_FILTER_USER_REST_INFO_LABEL = NOTE_BOLD_LABEL + "Selecting one of the following options "
															+ "turns the message into a <u>" + USER_SPECIFIC_LABEL + "</u> message";
	public static final String FEEDBACK_FILTER_USER_REST_HELP_LABEL = "<b>\"" + USER_SPECIFIC_LABEL + "\"<\b>"
															+ "messages can be provided to individual users "
															+ "(i.e., they cannot be broadcasted to the whole group)";
	public static final String FEEDBACK_FILTER_USER_REST_OPT2_HELP_LABEL = "<b>\"Contributor\":<\b> user has created or modified one of "
															+ "the pattern components (resize or move actions are ignored)";
	public static final String FEEDBACK_FILTER_USER_REST_OPT1_LABEL = "No user restriction";
	public static final String FEEDBACK_FILTER_USER_REST_OPT2_LABEL = "User is owner of the pattern (one and only <u>contributor</u>)";
	public static final String FEEDBACK_FILTER_USER_REST_OPT3_LABEL = "User contributed to pattern (other contributors possible)";
	public static final String FEEDBACK_FILTER_USER_REST_OPT4_LABEL = "User did not contribute to pattern";
	public static final String FEEDBACK_FILTER_TIME_REST_OPT1_LABEL = "No time restriction";
	public static final String FEEDBACK_FILTER_TIME_REST_OPT2_1_LABEL = "Pattern last modified more than ";
	public static final String FEEDBACK_FILTER_TIME_REST_OPT2_2_LABEL = " secs ago (\"old\" patterns)";
	public static final String FEEDBACK_FILTER_TIME_REST_OPT3_1_LABEL = "Pattern last modified less than ";
	public static final String FEEDBACK_FILTER_TIME_REST_OPT3_2_LABEL = " secs ago (\"recent\" patterns)";
	
	public static final String PROVISION_TIME_LABEL = "Provision Time";
	public static final String PROVISION_TIME_OPT1_LABEL = "On request (add to feedback menu)";
	public static final String PROVISION_TIME_OPT2_LABEL = "Periodically";
	public static final String CHECK_INTER_EVERY_LABEL = "Check interval every";
	public static final String AVAILABLE_MSG_TYPES_LABEL = "Available message types";
	public static final String SELECTED_MSG_TYPES_LABEL = "Selected message types";
	public static final String MAX_NUM_MSGS_PROV_LABEL = "Max Number of messages provided at a time";
	public static final String SORT_MSGS_LABEL = "Sort Messages";
	public static final String AVAILABLE_SORT_CRIT_LABEL = "Available Sort Criteria";
	public static final String SELECTED_SORT_CRIT_LABEL = "Selected Sort Criteria";
	public static final String SELECTED_SORT_CRIT_HELP_LABEL = "Sort criteria will be applied in order. Result will sorted "
															+ "according to the first criteria, the second criterion will be used "
															+ "to break ties of the first iteration, the third criterion will be used "
															+ "to break ties after the second iteration and so on.";
	public static final String FILTER_MSGS_LABEL = "Filter Messages";
	public static final String FILTER_MSGS_OPT1_LABEL = "Discard all but one instance per message type";
	public static final String FILTER_MSGS_OPT2_LABEL = "Discard all but one instance per message group";
	public static final String FILTER_MSGS_OPT3_LABEL = "Discard instances already pointed to";
	
	
	public static final String COUNT_LABEL = "count";
	
	public static final String DISPLAY_NAME_LABEL = "Display name";
	public static final String SUPPORTED_ONTOLOGY_LABEL = "Supported Ontology";
	public static final String SELECT_AGENT_LABEL = "Select Agent";
	//public static final String SELECT_AGENT_TO_ASSIGN_LABEL = "Select Agent to Assign";
	public static final String DESCRIPTION_LABEL = "Description";
	public static final String SAVE_CONFIG_LABEL = "Save configuration";
	public static final String SAVE_LABEL = "Save";
	public static final String CLOSE_LABEL = "Close";
	public static final String CANCEL_LABEL = "Cancel";
	public static final String OK_LABEL = "Ok";
	public static final String ANY_LABEL = "Any";
	public static final String PROVISION_OPT1_LABEL = "no direct provision to user (filter rule component)";
	public static final String PROVISION_OPT2_LABEL = "on request (add to feedback menu)";
	public static final String PROVISION_OPT3_LABEL = "periodically, check every ";
	public static final String DISCARD_ALL_PATTERN_LABEL = "Discard all but one match of this pattern";
	public static final String SEC_LABEL = "sec";
	public static final String INDIVIDUAL_LABEL = "individual";
	public static final String GROUP_LABEL = "group";
	public static final String ADD_AGENT_TOOLTIP = "Add a new Agent";
	public static final String USER_RESTRICTIONS_OPT1_LABEL = "no user restriction";
	public static final String USER_RESTRICTIONS_OPT2_LABEL = "user is owner of the pattern (one and only one contributor)";
	public static final String USER_RESTRICTIONS_OPT3_LABEL = "user contributed to pattern (other contributors possible)";
	public static final String USER_RESTRICTIONS_OPT4_LABEL = "user did not contribute to pattern";
	public static final String TIME_RESTRICTIONS_OPT1_LABEL = "no time restriction";
	public static final String TIME_RESTRICTIONS_OPT2_LABEL = "pattern exists for more than";//TODO remove these strings
	public static final String TIME_RESTRICTIONS_OPT3_LABEL = "pattern exists for less than";
	public static final String TIME_RESTRICTIONS_OPT2B_LABEL = "secs (\"old patterns\")";
	public static final String TIME_RESTRICTIONS_OPT3B_LABEL = "secs (recent patterns)";
	public static final String SHORT_MESSAGE_LABEL = "Short message";
	public static final String LONG_MESSAGE_LABEL = "Long message";
	public static final String HIGHLIGHTING_IMPACT_LABEL = "impact of Highlighting";
	public static final String YES_LABEL = "yes";
	public static final String NO_LABEL = "no";
	public static final String HELP_LABEL = "Help";
	public static final String DEFAULT_SETTING_LABEL = "Default setting";
	public static final String PHASE_LABEL = "Phase";
	public static final String PHASE2_LABEL = "phase";
	public static final String PHASE_ID_LABEL = "Phase ID";
	public static final String PHASE_SPECIFIC_SET_LABEL = "Phase-specific settings (overrides default setting)";
	
	public static final String CONFIRMATION_DELETE = "Delete ";
	public static final String REMOVE_LABEL = "Remove";
	public static final String FROM_LABEL = "from";
	public static final String QUESTION_MARK = " ?";
	
	public static final String ADD_LABEL = "Add...";
	public static final String CONTRIBUTION_MENU_ITEM_LABEL = "ContributionMenuItem";
	public static final String RELATION_LABEL = "Relation";
	
	
}

