package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.window;

import java.util.List;

import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.FeedbackAuthoringTabContent;
import lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event.AddAgentToSessionEvent;


public class AddAgent2Session extends SelectAgentWindow {

	public AddAgent2Session(List<String> agentList, String helper, FeedbackAuthoringTabContent td) {
		super(agentList, helper, td);
	}

	@Override
	public void doAction(String agentName, String helper) {
		//getFATabRef().handleAddAgentToSessionEvent(agentName, helper);
		getFATabRef().handleUserActionEvent(new AddAgentToSessionEvent(helper, agentName));
	}

}
