package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public class StartSessionEvent extends SessionsUserActionEventImpl {

	public StartSessionEvent(String session, String agent) {
		super(session, agent);
		// TODO Auto-generated constructor stub
	}

}
