package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.data;


public class OntologyFA{
	
	private String name;

	public OntologyFA(){
		
	}

	public OntologyFA(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
