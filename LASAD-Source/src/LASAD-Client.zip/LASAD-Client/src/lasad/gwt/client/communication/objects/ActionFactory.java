package lasad.gwt.client.communication.objects;

import java.util.Collection;
import java.util.Vector;

import lasad.gwt.client.LASAD_Client;
import lasad.gwt.client.logger.Logger;
import lasad.gwt.client.model.ElementInfo;
import lasad.gwt.client.model.UnspecifiedElementModel;
import lasad.gwt.client.ui.common.ExtendedElement;
import lasad.gwt.client.ui.workspace.argumentmap.ArgumentMap;
import lasad.gwt.client.ui.workspace.questionnaire.QuestionConfig;
import lasad.gwt.client.ui.workspace.transcript.TranscriptLinkData;

/**
 * Creates ActionPackages and Actions
 * 
 * @author Frank Loll
 * 
 */
public class ActionFactory {

	private ActionFactory() {
	}

	public static ActionFactory getInstance() {
		if (instance == null) {
			instance = new ActionFactory();
		}
		return instance;
	}

	private static ActionFactory instance = null;

	public ActionPackage leaveMap(int mapID) {
		ActionPackage p = new ActionPackage();

		if (ArgumentMap.mapIDtoCursorID.containsKey(mapID)) {
			p.addAction(removeElementAction(mapID, ArgumentMap.mapIDtoCursorID.get(mapID)));
		}

		Action a = new Action("LEAVE", "MANAGEMENT");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		p.addAction(a);

		return p;
	}

	public ActionPackage joinMap(String mapID) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("JOIN", "MANAGEMENT");
		a.addParameter("MAP-ID", mapID);
		a.addParameter("SUMMARY", "TRUE");
		p.addAction(a);
		return p;
	}

	public ActionPackage getMaps() {
		ActionPackage p = new ActionPackage();
		Action a = new Action("LIST", "MANAGEMENT");
		p.addAction(a);
		return p;
	}

	// David Drexler Edit-BEGIN
	public ActionPackage startReplay(String mapID) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("START", "REPLAY");
		a.addParameter("MAP-ID", mapID);
		p.addAction(a);
		return p;
	}

	// David Drexler Edit-END

	public ActionPackage saveMapToXMLFile(int mapID, String xmlString) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("SAVELOCAL", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("XML-SAVE-FILE", xmlString);
		p.addAction(a);
		return p;
	}

	public ActionPackage updateBoxPosition(int mapID, int boxID, int x, int y) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ID", String.valueOf(boxID));
		a.addParameter("POS-X", String.valueOf(x));
		a.addParameter("POS-Y", String.valueOf(y));
		p.addAction(a);
		return p;
	}
	
	public ActionPackage updateLinkPosition(int mapID, int linkID, float per) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ID", String.valueOf(linkID));
		a.addParameter("PERCENT", String.valueOf(per));
		p.addAction(a);
		return p;
	}

	public ActionPackage updateBoxSize(int mapID, int boxID, int width, int height) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ID", String.valueOf(boxID));
		a.addParameter("WIDTH", String.valueOf(width));
		a.addParameter("HEIGHT", String.valueOf(height));
		p.addAction(a);
		return p;
	}

	/**
	 * 
	 * @param mapID
	 *            Map ID
	 * @param elementID
	 *            Element ID
	 * @param attribute
	 *            The attribute to change
	 * @param value
	 *            The new value of that attribute
	 * @return action package
	 */
	public ActionPackage editAttribute(int mapID, String elementID, String attribute, String value) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", Integer.toString(mapID));
		a.addParameter("ID", elementID);
		a.addParameter(attribute, value);
		p.addAction(a);
		return p;
	}

	public ActionPackage lockElement(String mapID, int elementID) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", mapID);
		a.addParameter("ID", String.valueOf(elementID));
		// Will be created by Server ActionFactory 20.07.2010
		// a.addParameter("USERNAME", LASAD_Client.getInstance().getUsername());
		a.addParameter("STATUS", "LOCK");
		p.addAction(a);
		return p;
	}

	public ActionPackage unlockElement(String mapID, int elementID) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", mapID);
		a.addParameter("ID", String.valueOf(elementID));
		// Will be created by Server ActionFactory 20.07.2010
		// a.addParameter("USERNAME", LASAD_Client.getInstance().getUsername());
		a.addParameter("STATUS", "UNLOCK");
		p.addAction(a);
		return p;
	}

	public ActionPackage updateLinkSize(int mapID, int linkID, int height) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ID", String.valueOf(linkID));
		a.addParameter("HEIGHT", String.valueOf(height));
		p.addAction(a);
		return p;
	}

	public ActionPackage switchLinkDirection(int mapID, int linkID) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ID", String.valueOf(linkID));
		a.addParameter("DIRECTION", "changed");
		p.addAction(a);
		return p;
	}
	
	public ActionPackage setLinkDirection(int mapID, int linkID, String startParentID, String endParentID) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ID", String.valueOf(linkID));
		a.addParameter("DIRECTION", startParentID + "," + endParentID);
		p.addAction(a);
		return p;
	}

	public Action createTranscriptLink(int mapID, String boxID, TranscriptLinkData tData) {
		Action a = new Action("CREATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("BOX-ID", boxID);
		a.addParameter("TYPE", "transcript-link");

		if (tData.getElementID() == 0) {
			// No Parent is set, so use the last added element as parent
			a.addParameter("PARENT", "LAST-ID");
		} else {
			a.addParameter("PARENT", String.valueOf(tData.getElementID()));
		}

		a.addParameter("ELEMENT-ID", "transcriptlink");
		a.addParameter("STARTROW", tData.getStartRow().getLineNumber() + "");
		a.addParameter("STARTPOINT", tData.getStartRow().getTextPassages().indexOf(tData.getStartPassage()) + "");
		a.addParameter("ENDROW", tData.getEndRow().getLineNumber() + "");
		a.addParameter("ENDPOINT", tData.getEndRow().getTextPassages().indexOf(tData.getEndPassage()) + "");

		return a;
	}

	public ActionPackage updateTranscriptLink(int mapID, int elementID, TranscriptLinkData tData) {
		UnspecifiedElementModel tModel = tData.getModel();

		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ID", String.valueOf(tModel.getId()));

		if (!String.valueOf(tData.getStartRow().getLineNumber()).equals(tModel.getValue("STARTROW"))) {
			a.addParameter("STARTROW", String.valueOf(tData.getStartRow().getLineNumber()));
		}
		if (!String.valueOf(tData.getStartRow().getTextPassages().indexOf(tData.getStartRow().getSelectionStartTextPassage())).equals(tModel.getValue("STARTPOINT"))) {
			a.addParameter("STARTPOINT", tData.getStartRow().getTextPassages().indexOf(tData.getStartPassage()) + "");
		}
		if (!String.valueOf(tData.getEndRow().getLineNumber()).equals(tModel.getValue("ENDROW"))) {
			a.addParameter("ENDROW", String.valueOf(tData.getEndRow().getLineNumber()));
		}
		if (!String.valueOf(tData.getEndRow().getTextPassages().indexOf(tData.getEndRow().getSelectionEndTextPassage())).equals(tModel.getValue("ENDPOINT"))) {
			a.addParameter("ENDPOINT", tData.getEndRow().getTextPassages().indexOf(tData.getEndPassage()) + "");
		}

		p.addAction(a);
		return p;
	}

	public ActionPackage updateElementWithMultipleValues(int mapID, int id, Vector<String[]> values) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ID", String.valueOf(id));
		for (int i = 0; i < values.size(); i++) {
			a.addParameter(values.get(i)[0], values.get(i)[1]);
		}
		p.addAction(a);
		return p;
	}

	public ActionPackage addElement(int mapID, int boxID, String elementType, String elementID) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("CREATE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("TYPE", elementType);
		a.addParameter("PARENT", String.valueOf(boxID));
		a.addParameter("ELEMENT-ID", elementID);
		// a.addParameter("TIME", "CURRENT-TIME");

		p.addAction(a);
		return p;
	}
	
	//###################################################
	//##	3 Procedures to load boxes/links from xml-file   ##
	//###################################################

	public ActionPackage createBoxWithElementsAndContent(String ontologyId, int rootElementId, int mapID, int posX, int posY, int width, int height, Vector<String[]> subElements) {
	    ActionPackage p = new ActionPackage();
	    Action a = createEmptyBox(ontologyId, rootElementId, mapID, posX, posY, width, height);
	    p.addAction(a);

	    //actions erstellen f�r alle subElemente
	    for(String[] subElement : subElements) {
		p.addAction(addElementWithContent(mapID, subElement[1], subElement[0], subElement[2]));
	    }
	    return p;
	}
	
	public ActionPackage createLinkWithElementsAndContent(String ontologyId, int rootElementId, int mapID, int startBoxId, int endBoxId, Vector<String[]> subElements) {
	    ActionPackage p = new ActionPackage();
	    Action a = createEmptyLink(ontologyId, rootElementId, mapID, startBoxId, endBoxId);
	    p.addAction(a);

	    //actions erstellen f�r alle subElemente
	    for(String[] subElement : subElements) {
		p.addAction(addElementWithContent(mapID, subElement[1], subElement[0], subElement[2]));
	    }
	    return p;
	}

	private Action createEmptyBox(String ontologyId, int rootElementId, int mapID, int posX, int posY, int width, int height) {
	    Action a = new Action("CREATE-ELEMENT", "MAP");
	    a.addParameter("TYPE", "emptybox");
	    //Used for identification
	    a.addParameter("OBJECTID", String.valueOf(rootElementId));
	    a.addParameter("MAP-ID", String.valueOf(mapID));
	    a.addParameter("ELEMENT-ID", ontologyId);
	    a.addParameter("POS-X", String.valueOf(posX));
	    a.addParameter("POS-Y", String.valueOf(posY));
	    a.addParameter("WIDTH", String.valueOf(width));
	    a.addParameter("HEIGHT", String.valueOf(height));

	    return a;
	}
	
	private Action createEmptyLink(String ontologyId, int rootElementId, int mapID, int startBoxId, int endBoxId) {
		Action a = new Action("CREATE-ELEMENT", "MAP");
		a.addParameter("TYPE", "emptyrelation");
		a.addParameter("OBJECTID", String.valueOf(rootElementId));
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ELEMENT-ID", String.valueOf(ontologyId));
		a.addParameter("PARENT", String.valueOf(startBoxId));
		a.addParameter("PARENT", String.valueOf(endBoxId));
		
		return a;
	}

	private Action addElementWithContent(int mapID, String elementType, String elementID, String elementValue) {
	    Action a = new Action("CREATE-ELEMENT", "MAP");
	    a.addParameter("MAP-ID", mapID + "");
	    a.addParameter("TYPE", elementType);
	    a.addParameter("PARENT", "LAST-ID");
	    a.addParameter("ELEMENT-ID", elementID);
	    a.addParameter("TEXT", elementValue);

	    return a;
	}

	private Action removeElementAction(int mapID, int id) {
		Action a = new Action("DELETE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ID", String.valueOf(id));
		return a;
	}

	public ActionPackage removeElement(int mapID, int id) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("DELETE-ELEMENT", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ID", String.valueOf(id));

		p.addAction(a);
		return p;
	}

	public Action createBox(ElementInfo config, int mapID, int posX, int posY) {
		Action a = new Action("CREATE-ELEMENT", "MAP");
		a.addParameter("TYPE", "box");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ELEMENT-ID", config.getElementID());
		a.addParameter("POS-X", String.valueOf(posX));
		a.addParameter("POS-Y", String.valueOf(posY));

		return a;
	}

	private Vector<Action> createBoxElementsAction(ElementInfo currentElement, int mapID) {

		Vector<Action> allActions = new Vector<Action>();

		for (ElementInfo childElement : currentElement.getChildElements().values()) {
			Logger.log("Creating action for ChildElement: " + childElement.getElementType(), Logger.DEBUG_DETAILS);
			for (int i = 0; i < childElement.getQuantity(); i++) {

				Action b = new Action("CREATE-ELEMENT", "MAP");
				b.addParameter("TYPE", childElement.getElementType());
				b.addParameter("MAP-ID", mapID + "");
				b.addParameter("PARENT", "LAST-ID");
				b.addParameter("ELEMENT-ID", String.valueOf(childElement.getElementID()));
				b.addParameter("USERNAME", LASAD_Client.getInstance().getUsername());

				if (childElement.getElementType().equals("rating")) {
					b.addParameter("SCORE", childElement.getElementOption("score"));
				} else if (childElement.getElementType().equals("awareness")) {
					b.addParameter("TIME", "CURRENT-TIME"); // The time will be

					// filled in by the
					// server
				}

				if (b != null) {
					allActions.add(b);
				}
			}
		}
		return allActions;
	}

	public ActionPackage createBoxWithElements(ElementInfo currentElement, int mapID, int posX, int posY) {
		ActionPackage p = new ActionPackage();
		Action a = createBox(currentElement, mapID, posX, posY);
		p.addAction(a);

		Vector<Action> b = createBoxElementsAction(currentElement, mapID);
		if (b.size() > 0) {
			for (Action c : b) {
				p.addAction(c);
			}
		}
		return p;
	}

	public ActionPackage undo(int mapID) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UNDO", "MAP");
		a.addParameter("MAP-ID", String.valueOf(mapID));

		p.addAction(a);
		return p;
	}

	public ActionPackage createBoxAndLink(ElementInfo boxInfo, ElementInfo linkInfo, int mapID, int x, int y, String start, String end) {
		ActionPackage p = new ActionPackage();
		Action a = createBox(boxInfo, mapID, x, y);
		p.addAction(a);

		Vector<Action> b = createBoxElementsAction(boxInfo, mapID);
		if (b.size() > 0) {
			for (Action c : b) {
				p.addAction(c);
			}
		}

		Vector<Action> c = createLinkWithElementsAction(linkInfo, mapID, start, end, null);
		if (c.size() > 0) {
			for (Action d : c) {
				p.addAction(d);
			}
		}

		return p;
	}

	public ActionPackage sendChatMessage(int mapID, String msg) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("CHAT-MSG", "COMMUNICATION");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("MESSAGE", msg);
		p.addAction(a);
		return p;
	}

	public ActionPackage createLinkWithElements(ElementInfo info, int mapID, String startElementID, String endElementID) {
		ActionPackage p = new ActionPackage();

		Vector<Action> b = createLinkWithElementsAction(info, mapID, startElementID, endElementID, null);
		if (b.size() > 0) {
			for (Action c : b) {
				p.addAction(c);
			}
		}
		return p;
	}

	public ActionPackage createLinkWithElements(ElementInfo info, int mapID, String startElementID, String endElementID, Vector<ExtendedElement> existingChildElements) {
		ActionPackage p = new ActionPackage();

		Vector<Action> b = createLinkWithElementsAction(info, mapID, startElementID, endElementID, existingChildElements);
		if (b.size() > 0) {
			for (Action c : b) {
				p.addAction(c);
			}
		}
		return p;
	}

	private Vector<Action> createLinkWithElementsAction(ElementInfo info, int mapID, String startID, String endID, Vector<ExtendedElement> existingChildElements) {

		Vector<Action> resultingActions = new Vector<Action>();

		Action a = new Action("CREATE-ELEMENT", "MAP");
		a.addParameter("TYPE", info.getElementType());
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("ELEMENT-ID", String.valueOf(info.getElementID()));
		a.addParameter("PARENT", startID);
		a.addParameter("PARENT", endID);

		resultingActions.add(a);

		if (existingChildElements == null) {
			Collection<ElementInfo> childElements = info.getChildElements().values();
			for (ElementInfo childElement : childElements) {
				Logger.log("Creating action for ChildElement: " + childElement.getElementType(), Logger.DEBUG);

				// Initializing loop variable and changing it in case there're
				// no existing child elements
				int quantity = childElement.getQuantity();
				int i = 0;
				while (i < quantity) {
					Action b = new Action("CREATE-ELEMENT", "MAP");
					b.addParameter("TYPE", childElement.getElementType());
					b.addParameter("MAP-ID", mapID + "");
					b.addParameter("PARENT", "LAST-ID");
					b.addParameter("ELEMENT-ID", String.valueOf(childElement.getElementID()));

					if (childElement.getElementType().equals("rating")) {
						b.addParameter("SCORE", childElement.getElementOption("score"));
					} else if (childElement.getElementType().equals("awareness")) {
						b.addParameter("TIME", "CURRENT-TIME"); // The time will
						// be filled in
						// by the server
					}
					if (b != null) {
						resultingActions.add(b);
					}

					i++;
				}
			}
		} else {
			for (ExtendedElement element : existingChildElements) {
				Logger.log("Creating action for ChildElement: " + element.getConfig().getElementType(), Logger.DEBUG);

				Action b = new Action("CREATE-ELEMENT", "MAP");
				b.addParameter("TYPE", element.getConfig().getElementType());
				b.addParameter("MAP-ID", mapID + "");
				b.addParameter("PARENT", "LAST-ID");
				b.addParameter("ELEMENT-ID", String.valueOf(element.getConfig().getElementID()));

				if (element.getConfig().getElementType().equals("rating")) {
					b.addParameter("SCORE", element.getConfig().getElementOption("score"));
				} else if (element.getConfig().getElementType().equals("text")) {
					String text;
					if (element.getConnectedModel().getValue("TEXT") == null) {
						text = "";
					} else {
						text = element.getConnectedModel().getValue("TEXT");
					}
					b.addParameter("TEXT", text);
				} else if (element.getConfig().getElementType().equals("awareness")) {
					b.addParameter("TIME", "CURRENT-TIME"); // The time will be
					// filled in by the
					// server
				}
				if (b != null) {
					resultingActions.add(b);
				}
			}
		}
		return resultingActions;
	}

	public ActionPackage createLogin(String username, String pw) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("LOGIN", "MANAGEMENT");
		a.addParameter("USERNAME", username);
		a.addParameter("PW", pw);
		p.addAction(a);
		return p;
	}

	public ActionPackage logout(String username) {
		ActionPackage p = new ActionPackage();

		Action a = new Action("LOGOUT", "MANAGEMENT");
		a.addParameter("USERNAME", username);
		p.addAction(a);

		Logger.log(a.toString(), Logger.DEBUG);
		return p;
	}

	public ActionPackage sendHeartbeat() {
		ActionPackage p = new ActionPackage();
		Action a = new Action("HEARTBEAT", "SESSION");
		p.addAction(a);
		return p;
	}

	public ActionPackage getMapDetails(int mapID) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("MAPDETAILS", "MANAGEMENT");
		a.addParameter("MAP-ID", mapID + "");
		p.addAction(a);
		return p;
	}

	public ActionPackage createAndJoinMap(String mapName, String selectedOntology, String selectedTemplate) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("CREATEANDJOIN", "MANAGEMENT");
		a.addParameter("MAPNAME", mapName);
		a.addParameter("ONTOLOGY", selectedOntology);
		a.addParameter("TEMPLATE", selectedTemplate);
		p.addAction(a);
		return p;
	}
	
	/**
	 * Basically this method works like createAndJoinMap but transfers an xml-text to be loaded after joining the map
	 * @param mapName
	 * @param selectedOntology
	 * @param selectedTemplate
	 * @param xmlText The xml-file to be imported
	 * @return
	 */
	public ActionPackage importAndJoinMap(String mapName, String selectedOntology, String selectedTemplate, String xmlText) {
		ActionPackage p = createAndJoinMap(mapName, selectedOntology, selectedTemplate);
		p.getActions().get(0).addParameter("XMLTEXT", xmlText);
		return p;
	}

	public ActionPackage getAllOntologgiesAndTemplates() {
		ActionPackage p = new ActionPackage();
		Action a = new Action("GETALLONTOLOGIESANDTEMPLATES", "MANAGEMENT");
		p.addAction(a);
		return p;
	}

	public ActionPackage getMapsAndTemplates() {
		ActionPackage p = new ActionPackage();
		Action a = new Action("GET-MAPS-AND-TEMPLATES", "AUTHORING");
		p.addAction(a);
		return p;
	}

	public ActionPackage getQuestionnaireAnswers(int mapID, Vector<QuestionConfig> questions) {
		ActionPackage p = new ActionPackage();
		for (QuestionConfig qc : questions) {
			Action a = new Action("GETANSWER", "QUESTIONNAIRE");
			a.addParameter("MAP-ID", mapID + "");
			a.addParameter("QUESTIONID", qc.getId());
			p.addAction(a);
		}

		return p;
	}

	public Action addQuestionnaireAnswer(int mapID, String questionID, String answer) {
		Action a = new Action("ADDANSWER", "QUESTIONNAIRE");
		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("QUESTIONID", questionID);
		a.addParameter("QUESTIONANSWER", answer);

		return a;
	}

	public ActionPackage updateMyCursorPositionNonPersistent(int mapID, int cursorID, String username, int x, int y) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-CURSOR-POSITION", "MAP");
		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("ID", String.valueOf(cursorID));
		a.addParameter("USERNAME", username);
		a.addParameter("POS-X", x + "");
		a.addParameter("POS-Y", y + "");
		a.addParameter("PERSISTENT", "FALSE");
		p.addAction(a);
		return p;
	}

	public ActionPackage updateMyCursorPositionPersistent(int mapID, int cursorID, String username, int x, int y) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-CURSOR-POSITION", "MAP");
		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("ID", String.valueOf(cursorID));
		a.addParameter("USERNAME", username);
		a.addParameter("POS-X", x + "");
		a.addParameter("POS-Y", y + "");
		a.addParameter("PERSISTENT", "TRUE");
		p.addAction(a);
		return p;
	}

	public ActionPackage updateGroupCursorPositionPersistent(int mapID, int cursorID, int x, int y) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-CURSOR-POSITION", "MAP");
		a.addParameter("MAP-ID", mapID + "");
		a.addParameter("ID", String.valueOf(cursorID));
		a.addParameter("POS-X", x + "");
		a.addParameter("POS-Y", y + "");
		a.addParameter("PERSISTENT", "TRUE");
		p.addAction(a);
		return p;
	}

	public ActionPackage createAwarenessCursor(int mapID, String username) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("CREATE-ELEMENT", "MAP");
		a.addParameter("TYPE", "awareness-cursor");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("USERNAME", username);
		a.addParameter("ELEMENT-ID", "awareness-cursor-" + username);
		a.addParameter("POS-X", "0");
		a.addParameter("POS-Y", "0");
		p.addAction(a);
		return p;
	}

	public ActionPackage createGroupCursor(int mapID, String username, int posX, int posY) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("CREATE-ELEMENT", "MAP");
		a.addParameter("TYPE", "group-cursor");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("USERNAME", username);
		a.addParameter("ELEMENT-ID", "group-cursor-" + username);
		a.addParameter("POS-X", posX + "");
		a.addParameter("POS-Y", posY + "");
		p.addAction(a);
		return p;
	}

	public ActionPackage requestFeedback(int mapID, String username, String agentName, String feedbackName) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("REQUEST", "FEEDBACK");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("USERNAME", username);
		a.addParameter("AGENT-ID", agentName);
		a.addParameter("TYPE-ID", feedbackName);
		p.addAction(a);
		return p;
	}

	public ActionPackage requestFeedback(int mapID, String username, String agentName, String feedbackName, String agentType) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("REQUEST", "FEEDBACK");
		a.addParameter("MAP-ID", String.valueOf(mapID));
		a.addParameter("USERNAME", username);
		a.addParameter("AGENT-ID", agentName);
		a.addParameter("TYPE-ID", feedbackName);
		a.addParameter("AGENT-TYPE", agentType);
		p.addAction(a);
		return p;
	}

	public ActionPackage createTemplate(String useTemplateName, String useTemplateDescription, String useOntologyWithName, boolean useSeperateViewForDetails, int maxUserCount, boolean useChat, boolean useUserList, boolean useCursorTracking, boolean useTranscript, String transcriptText) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("CREATE-TEMPLATE", "AUTHORING");

		// General
		a.addParameter("TEMPLATE-NAME", useTemplateName);

		if (useTemplateDescription == null) {
			a.addParameter("TEMPLATE-DESCRIPTION", "");
		} else {
			a.addParameter("TEMPLATE-DESCRIPTION", useTemplateDescription);
		}
		a.addParameter("ONTOLOGY-NAME", useOntologyWithName);
		a.addParameter("USE-SELECTION-DETAILS", useSeperateViewForDetails + "");

		// Collaboration
		a.addParameter("MAX-USERS", maxUserCount + "");
		a.addParameter("USE-CHAT", useChat + "");
		a.addParameter("USE-USERLIST", useUserList + "");
		a.addParameter("USE-CURSOR-TRACKING", useCursorTracking + "");

		// Transcript
		if (useTranscript) {
			a.addParameter("TRANSCRIPT", transcriptText);
		}
		p.addAction(a);
		return p;
	}

	public ActionPackage getTemplatesForOverview() {
		ActionPackage p = new ActionPackage();
		Action a = new Action("GET-TEMPLATES", "MANAGEMENT");
		p.addAction(a);
		return p;
	}
	
	public ActionPackage getTemplates() {
		ActionPackage p = new ActionPackage();
		Action a = new Action("GET-TEMPLATES", "AUTHORING");
		p.addAction(a);
		return p;
	}

	public ActionPackage deleteTemplate(String templateName) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("DELETE-TEMPLATE", "AUTHORING");
		a.addParameter("TEMPLATE", templateName);
		p.addAction(a);
		return p;
	}

	public ActionPackage createUser(String useNickname, String usePassword, String useRole) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("CREATE-USER", "AUTHORING");
		a.addParameter("USERNAME", useNickname);
		a.addParameter("PW", usePassword);
		a.addParameter("ROLE", useRole);
		p.addAction(a);
		return p;
	}

	public ActionPackage getUsers() {
		ActionPackage p = new ActionPackage();
		Action a = new Action("GET-USERS", "AUTHORING");
		a.addParameter("GET-ROLES", "TRUE");
		p.addAction(a);
		return p;
	}

	public ActionPackage deleteUser(String userName) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("DELETE-USER", "AUTHORING");
		a.addParameter("USERNAME", userName);
		p.addAction(a);
		return p;
	}

	public ActionPackage createMap(String useMapName, String useTemplate, Vector<String> allUserRestrictions, boolean persistent) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("CREATE-MAP", "AUTHORING");
		a.addParameter("MAPNAME", useMapName);
		a.addParameter("TEMPLATE", useTemplate);
		
		for(String s : allUserRestrictions) {
			a.addParameter("RESTRICTED-TO", s);	
		}
		
		if(persistent) {
			a.addParameter("PERSISTENT", "TRUE");
		}
		p.addAction(a);
		return p;
	}

	public ActionPackage getUserListWithoutRole() {
		ActionPackage p = new ActionPackage();
		Action a = new Action("GET-USERS", "AUTHORING");
		a.addParameter("GET-ROLES", "FALSE");
		p.addAction(a);
		return p;
	}

	public ActionPackage deleteMap(String mapName) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("DELETE-MAP", "AUTHORING");
		a.addParameter("MAPNAME", mapName);
		p.addAction(a);
		return p;
	}

	public ActionPackage deleteOntology(String ontologyName) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("DELETE-ONTOLOGY", "AUTHORING");
		a.addParameter("ONTOLOGYNAME", ontologyName);
		p.addAction(a);
		return p;
	}

	public ActionPackage getOntologyList() {
		ActionPackage p = new ActionPackage();
		Action a = new Action("GET-ONTOLOGIES", "AUTHORING");
		p.addAction(a);
		return p;
	}

	public ActionPackage getOntologyDetails(String selectedOntology) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("GET-ONTOLOGY-DETAILS", "AUTHORING");
		a.addParameter("ONTOLOGYNAME", selectedOntology);
		p.addAction(a);
		return p;
	}

	public ActionPackage getTemplateDetails(String templateName) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("TEMPLATEDETAILS", "MANAGEMENT");
		a.addParameter("TEMPLATE", templateName);
		p.addAction(a);
		return p;
	}

	public ActionPackage loadSessionFromXML(String sessionName, String ontology, String template, String content, String username) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("LOAD", "FILE");
		a.addParameter("SESSION", sessionName);
		a.addParameter("ONTOLOGY-XML", ontology);
		a.addParameter("TEMPLATE-XML", template);
		a.addParameter("CONTENT-XML", content);
		
		if(username != null) {
			a.addParameter("RESTRICTED-TO", username);
		}
		p.addAction(a);
		return p;
	}

	public ActionPackage createOntology(String name, String createEmptyOntology, String clonedOntologyName) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("CREATE-ONTOLOGY", "AUTHORING");
		a.addParameter("ONTOLOGYNAME", name);
		a.addParameter("ONTOLOGY-XML", createEmptyOntology);
		
		if(clonedOntologyName != null) {
			a.addParameter("CLONE", clonedOntologyName);	
		}
		p.addAction(a);
		return p;
	}

	public ActionPackage updateOntology(String name, String xml) {
		ActionPackage p = new ActionPackage();
		Action a = new Action("UPDATE-ONTOLOGY", "AUTHORING");
		a.addParameter("ONTOLOGYNAME", name);
		a.addParameter("ONTOLOGY-XML", xml);
		p.addAction(a);
		return p;
	}

	public ActionPackage recoverRequestFromConfirmation(Action a) {
		ActionPackage p = new ActionPackage();
		
		Action action = new Action(a.getParameter("ORIGINAL-COMMAND"), "AUTHORING");
		action.getParameters().addAll(a.getParameters());
		action.addParameter("CONFIRMED", "TRUE");
		p.addAction(action);
		
		return p;
	}
}