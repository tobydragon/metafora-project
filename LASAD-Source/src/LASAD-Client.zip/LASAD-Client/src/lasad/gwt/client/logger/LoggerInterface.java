package lasad.gwt.client.logger;

public interface LoggerInterface {
	public void log(String logText);
	public void logErr(String logText);
}
