package lasad.gwt.client.ui.common.highlight;

public interface HighlightableElementInterface {

	public void setHighlight(boolean highlight);
	public HighlightableElementInterface getHighlightParent();
	
}