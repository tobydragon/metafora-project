package lasad.gwt.client.ui.link.helper;

import lasad.gwt.client.communication.LASADActionSender;
import lasad.gwt.client.communication.objects.ActionFactory;
import lasad.gwt.client.ui.link.LinkPanel;
import lasad.gwt.client.ui.workspace.argumentmap.elements.DeleteDialog;

import com.extjs.gxt.ui.client.event.Events;
import com.google.gwt.dom.client.Element;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventListener;

public class LinkHeaderButtonListener implements EventListener {

	private final LASADActionSender communicator = LASADActionSender.getInstance();
	private final ActionFactory actionBuilder = ActionFactory.getInstance();

	private LinkPanel linkPanelReference;

	public LinkHeaderButtonListener(LinkPanel linkPanelReference) {
		this.linkPanelReference = linkPanelReference;
	}

	public void onBrowserEvent(Event be) {
		if (be.getTypeInt() == Events.OnClick.getEventCode()) {
			handleOnClick(be);
			be.stopPropagation();
		} else if (be.getTypeInt() == Events.OnMouseOver.getEventCode()) {
			handleOnMouseOver(be);
		} else if (be.getTypeInt() == Events.OnMouseOut.getEventCode()) {
			handleOnMouseOut(be);
		}
	}

	private void handleOnClick(Event be) {
		if (((Element) be.getEventTarget().cast()).getClassName().equals("link-close-button-highlighted")) {
			if (!linkPanelReference.getMyLink().getMap().isDeleteElementsWithoutConfirmation()) {
				//Position it at close button
				new DeleteDialog(linkPanelReference.getMyLink().getMap(), linkPanelReference,  linkPanelReference.getPosition(true).x + linkPanelReference.getWidth(true) - linkPanelReference.getGeneralOffsetWidth(), linkPanelReference.getPosition(true).y + linkPanelReference.getGeneralOffsetHeight());
			} else {
				// Build ActionSet with all needed Updates
				linkPanelReference.getMyLink().getMap().getFocusHandler().releaseAllFocus();
				communicator.sendActionPackage(actionBuilder.removeElement(linkPanelReference.getMyLink().getMap().getID(), linkPanelReference.getMyLink().getConnectedModel().getId()));
			}
		} else if (((Element) be.getEventTarget().cast()).getClassName().equals("add-button-highlighted")) {
			new AddElementToLinkDialog(linkPanelReference.getMyLink().getMap(), linkPanelReference, linkPanelReference.getPosition(true).x, linkPanelReference.getPosition(true).y);
		} else if (((Element) be.getEventTarget().cast()).getClassName().equals("del-button-highlighted")) {
			new DelElementFromLinkDialog(linkPanelReference.getMyLink().getMap(), linkPanelReference, linkPanelReference.getPosition(true).x, linkPanelReference.getPosition(true).y);
		} else if (((Element) be.getEventTarget().cast()).getClassName().equals("switch-direction-button-highlighted")) {
			String start;
			String end;
			
			//In case the direction value has not been set until now
			if (linkPanelReference.getMyLink().getConnectedModel().getValue("DIRECTION") == null){
				start = Integer.toString(linkPanelReference.getMyLink().getConnectedModel().getParents().get(1).getId());
				end = Integer.toString(linkPanelReference.getMyLink().getConnectedModel().getParents().get(0).getId());
			} 
			else {
				start = linkPanelReference.getMyLink().getConnectedModel().getValue("DIRECTION").split(",")[1];
				end = linkPanelReference.getMyLink().getConnectedModel().getValue("DIRECTION").split(",")[0];
			}
			communicator.sendActionPackage(actionBuilder.setLinkDirection(linkPanelReference.getMyLink().getMap().getID(), linkPanelReference.getMyLink().getConnectedModel().getId(), start, end));
//			communicator.sendActionPackage(actionBuilder.switchLinkDirection(linkPanelReference.getMyLink().getMap().getID(), linkPanelReference.getMyLink().getConnectedModel().getId()));
		}
	}

	private void handleOnMouseOver(Event be) {
		if (((Element) be.getEventTarget().cast()).getClassName().equals("link-close-button")) {
			((Element) be.getEventTarget().cast()).setClassName("link-close-button-highlighted");
		} else if (((Element) be.getEventTarget().cast()).getClassName().equals("add-button")) {
			((Element) be.getEventTarget().cast()).setClassName("add-button-highlighted");
		} else if (((Element) be.getEventTarget().cast()).getClassName().equals("del-button")) {
			((Element) be.getEventTarget().cast()).setClassName("del-button-highlighted");
		} else if (((Element) be.getEventTarget().cast()).getClassName().equals("switch-direction-button")) {
			((Element) be.getEventTarget().cast()).setClassName("switch-direction-button-highlighted");
		}
	}

	private void handleOnMouseOut(Event be) {
		if (((Element) be.getEventTarget().cast()).getClassName().equals("link-close-button-highlighted")) {
			((Element) be.getEventTarget().cast()).setClassName("link-close-button");
		} else if (((Element) be.getEventTarget().cast()).getClassName().equals("add-button-highlighted")) {
			((Element) be.getEventTarget().cast()).setClassName("add-button");
		} else if (((Element) be.getEventTarget().cast()).getClassName().equals("del-button-highlighted")) {
			((Element) be.getEventTarget().cast()).setClassName("del-button");
		} else if (((Element) be.getEventTarget().cast()).getClassName().equals("switch-direction-button-highlighted")) {
			((Element) be.getEventTarget().cast()).setClassName("switch-direction-button");
		}
	}
}