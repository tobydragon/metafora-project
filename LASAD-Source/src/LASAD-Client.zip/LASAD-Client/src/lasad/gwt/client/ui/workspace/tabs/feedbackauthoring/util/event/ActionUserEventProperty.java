package lasad.gwt.client.ui.workspace.tabs.feedbackauthoring.util.event;

public enum ActionUserEventProperty {

	session,
	agent,
	ontology;
}
