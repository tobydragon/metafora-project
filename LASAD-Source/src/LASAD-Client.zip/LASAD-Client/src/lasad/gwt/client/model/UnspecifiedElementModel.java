package lasad.gwt.client.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class UnspecifiedElementModel {

	private int id;
	private String type;
	private String elementid;
	private String author;

	private Vector<UnspecifiedElementModel> parents = new Vector<UnspecifiedElementModel>();
	private Vector<UnspecifiedElementModel> children = new Vector<UnspecifiedElementModel>();
	private Vector<Integer> highlights = new Vector<Integer>();
	
	private Map<String, String> elementValues = new HashMap<String, String>();
	private MVController controller;

	public UnspecifiedElementModel(int id, String type) {
		this.id = id;
		this.type = type;
	}

	public UnspecifiedElementModel(int id, String type, String author) {
		this.id = id;
		this.type = type;
		this.author = author;
	}

	public void register2MVController(MVController controller) {
		this.controller = controller.addElementModel(this);
	}

	// Model Stuff
	public boolean setValue(String vName, String value) {
		if (elementValues.containsKey(vName) && elementValues.get(vName).equals(value)) {
			// Nothing to do, Value doesn't change
			return false;
		} else {
			elementValues.put(vName, value);
			return true;
		}
	}

	public String getValue(String vName) {
		return elementValues.get(vName);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getElementid() {
		return elementid;
	}

	public void setElementid(String elementid) {
		this.elementid = elementid;
	}

	public Map<String, String> getElementValues() {
		return elementValues;
	}

	public void setElementValues(Map<String, String> elementValues) {
		this.elementValues = elementValues;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	// Parent Child Stuff

	public Vector<UnspecifiedElementModel> getParents() {
		return parents;
	}

	public void setParents(Vector<UnspecifiedElementModel> parents) {
		this.parents = parents;
	}

	public Vector<UnspecifiedElementModel> getChildren() {
		return children;
	}

	public void setChilds(Vector<UnspecifiedElementModel> children) {
		this.children = children;
	}

	public void addParent(UnspecifiedElementModel parent) {
		this.parents.add(parent);
	}

	public void addChild(UnspecifiedElementModel child) {
		this.children.add(child);
		child.addParent(this);
	}

	public void removeChild(UnspecifiedElementModel child) {
		this.children.remove(child);
		child.removeParent(this);
	}

	public void removeParent(UnspecifiedElementModel parent) {
		this.parents.remove(parent);
	}

	public Vector<Integer> getHighlights() {
		return highlights;
	}

	public void setHighlights(Vector<Integer> highlights) {
		this.highlights = highlights;
	}
	
	public void showHighlights(boolean show) {
		
	}
	
}